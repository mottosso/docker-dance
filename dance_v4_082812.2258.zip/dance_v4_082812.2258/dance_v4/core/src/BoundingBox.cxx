/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "BoundingBox.h"
#include <math.h>
#include "danceInterp.h"
#include <fltk/gl.h>

#define	min(x,y) (((x) < (y)) ?	(x) : (y))
#define	max(x,y) (((x) > (y)) ?	(x) : (y))


BoundingBox::BoundingBox()
{
	xMin = 0.0; yMin = 0.0;	zMin = 0.0;
	xMax = 0.0; yMax = 0.0;	zMax = 0.0;
}

void BoundingBox::mergePoint(double *p) {
  
  xMin = min(p[0], xMin);
  yMin = min(p[1], yMin);
  zMin = min(p[2], zMin);

  xMax = max(p[0], xMax);
  yMax = max(p[1], yMax);
  zMax = max(p[2], zMax);

}

void BoundingBox::merge(BoundingBox &b) {
  
  xMin = min(b.xMin, xMin);
  yMin = min(b.yMin, yMin);
  zMin = min(b.zMin, zMin);

  xMax = max(b.xMax, xMax);
  yMax = max(b.yMax, yMax);
  zMax = max(b.zMax, zMax);
}

BoundingBox *BoundingBox::merge(BoundingBox *b1, BoundingBox *b2)
{
  // Special case if merging with an empty box.
  if (b1->xMin-b2->xMax	== 0.0
   && b1->yMin-b2->yMax	== 0.0
   && b1->zMin-b2->zMax	== 0.0)	{
     b1->xMin =	b2->xMin;
     b1->yMin =	b2->yMin;
     b1->zMin =	b2->zMin;
     b1->xMax =	b2->xMax;
     b1->yMax =	b2->yMax;
     b1->zMax =	b2->zMax;

  }
  else {
     b1->xMin =	min(b1->xMin, b2->xMin)	;
     b1->xMax =	max(b1->xMax, b2->xMax)	;
     b1->yMin =	min(b1->yMin, b2->yMin)	;
     b1->yMax =	max(b1->yMax, b2->yMax)	;
     b1->zMin =	min(b1->zMin, b2->zMin)	;
     b1->zMax =	max(b1->zMax, b2->zMax)	;
  }

  return b1 ;
}


void  BoundingBox::copy(BoundingBox *b)
{
    xMin = b->xMin ;
    xMax = b->xMax ;
    yMin = b->yMin ;
    yMax = b->yMax ;
    zMin = b->zMin ;
    zMax = b->zMax ;
}

void BoundingBox::display(float r, float g, float b, float a)
{
	double xAmount = (xMax - xMin) * .15;
	double yAmount = (yMax - yMin) * .15;
	double zAmount = (zMax - zMin) * .15;
    glColor4f(r,g,b,a);


    glBegin(GL_LINES);
	glVertex3d(xMin, yMin, zMin);
	glVertex3d(xMin, yMin, zMin + zAmount);

	glVertex3d(xMin, yMin, zMax);
	glVertex3d(xMin, yMin, zMax - zAmount);

	glVertex3d(xMax, yMin, zMin);
	glVertex3d(xMax, yMin, zMin + zAmount);

	glVertex3d(xMax, yMin, zMax);
	glVertex3d(xMax, yMin, zMax - zAmount);

	glVertex3d(xMax, yMax, zMin);
	glVertex3d(xMax, yMax, zMin + zAmount);

	glVertex3d(xMax, yMax, zMax);
	glVertex3d(xMax, yMax, zMax - zAmount);

	glVertex3d(xMin, yMax, zMin);
	glVertex3d(xMin, yMax, zMin + zAmount);

	glVertex3d(xMin, yMax, zMax);
	glVertex3d(xMin, yMax, zMax - zAmount);

	glVertex3d(xMin,yMin,zMin);
	glVertex3d(xMin,yMin + yAmount, zMin);

	glVertex3d(xMin,yMax,zMin);
	glVertex3d(xMin,yMax - yAmount, zMin);

	glVertex3d(xMax,yMin,zMin);
	glVertex3d(xMax,yMin + yAmount, zMin);

	glVertex3d(xMax,yMax,zMin);
	glVertex3d(xMax,yMax - yAmount, zMin);

	glVertex3d(xMin,yMin,zMax);
	glVertex3d(xMin,yMin + yAmount, zMax);

	glVertex3d(xMin,yMax,zMax);
	glVertex3d(xMin,yMax - yAmount, zMax);

	glVertex3d(xMax,yMin,zMax);
	glVertex3d(xMax,yMin + yAmount,zMax);

	glVertex3d(xMax,yMax,zMax);
	glVertex3d(xMax,yMax - yAmount,zMax);

	glVertex3d(xMin,yMin,zMin);
	glVertex3d(xMin + xAmount,yMin,zMin);

	glVertex3d(xMax,yMin,zMin);
	glVertex3d(xMax - xAmount,yMin,zMin);

	glVertex3d(xMin,yMax,zMin);
	glVertex3d(xMin + xAmount,yMax,zMin);

	glVertex3d(xMax,yMax,zMin);
	glVertex3d(xMax - xAmount,yMax,zMin);

	glVertex3d(xMin,yMin,zMax);
	glVertex3d(xMin + xAmount,yMin,zMax);

	glVertex3d(xMax,yMin,zMax);
	glVertex3d(xMax - xAmount,yMin,zMax);

	glVertex3d(xMin,yMax,zMax);
	glVertex3d(xMin + xAmount,yMax,zMax);

	glVertex3d(xMax,yMax,zMax);
	glVertex3d(xMax - xAmount,yMax,zMax);

/*	
	glVertex3d(xMin,yMin,zMin);
	glVertex3d(xMin,yMin,zMax);

	glVertex3d(xMin,yMax,zMin);
	glVertex3d(xMin,yMax,zMax);

	glVertex3d(xMax,yMin,zMin);
	glVertex3d(xMax,yMin,zMax);

	glVertex3d(xMax,yMax,zMin);
	glVertex3d(xMax,yMax,zMax);

	glVertex3d(xMin,yMin,zMin);
	glVertex3d(xMin,yMax,zMin);

	glVertex3d(xMax,yMin,zMin);
	glVertex3d(xMax,yMax,zMin);

	glVertex3d(xMin,yMin,zMax);
	glVertex3d(xMin,yMax,zMax);

	glVertex3d(xMax,yMin,zMax);
	glVertex3d(xMax,yMax,zMax);

	glVertex3d(xMin,yMin,zMin);
	glVertex3d(xMax,yMin,zMin);

	glVertex3d(xMin,yMax,zMin);
	glVertex3d(xMax,yMax,zMin);

	glVertex3d(xMin,yMin,zMax);
	glVertex3d(xMax,yMin,zMax);

	glVertex3d(xMin,yMax,zMax);
	glVertex3d(xMax,yMax,zMax);
*/
    glEnd();

}

void BoundingBox::getDimensions(double dim[3])
{
	dim[0] = xMax - xMin;
	dim[1] = yMax - yMin;
	dim[2] = zMax - zMin;
}

// isEmpty:
//	return 1 if box is empty, 0 if not
int BoundingBox::isEmpty()
{
	double dim[3]; getDimensions(dim);
	if (fabs(dim[0]) < 0.000001 && fabs(dim[1]) < 0.000001 && fabs(dim[2]) < 0.000001)
		return 1;
	return 0;
}

// update:
//	Given the transformation matrix, update	the bounding box after
//	transforming it.
//
void	BoundingBox::update(double transMat[4][4])
{
	// We must transform each of the points	in the bounding	box,
	// the convex hull, to find and	choose the min and max from
	// these transformed points.
	double xmin = xMin, ymin = yMin, zmin =	zMin;
	double xmax = xMax, ymax = yMax, zmax =	zMax;

	double trans_point[3];
	trans_point[0] = xmin; trans_point[1] =	ymin; trans_point[2] = zmin;
	transformPoint_mat(trans_point,transMat);
	update(trans_point,1);

	trans_point[0] = xmin; trans_point[1] =	ymin; trans_point[2] = zmax;
	transformPoint_mat(trans_point,transMat);
	update(trans_point);

	trans_point[0] = xmin; trans_point[1] =	ymax; trans_point[2] = zmin;
	transformPoint_mat(trans_point,transMat);
	update(trans_point);

	trans_point[0] = xmin; trans_point[1] =	ymax; trans_point[2] = zmax;
	transformPoint_mat(trans_point,transMat);
	update(trans_point);

	trans_point[0] = xmax; trans_point[1] =	ymin; trans_point[2] = zmin;
	transformPoint_mat(trans_point,transMat);
	update(trans_point);

	trans_point[0] = xmax; trans_point[1] =	ymin; trans_point[2] = zmax;
	transformPoint_mat(trans_point,transMat);
	update(trans_point);

	trans_point[0] = xmax; trans_point[1] =	ymax; trans_point[2] = zmin;
	transformPoint_mat(trans_point,transMat);
	update(trans_point);

	trans_point[0] = xmax; trans_point[1] =	ymax; trans_point[2] = zmax;
	transformPoint_mat(trans_point,transMat);
	update(trans_point);
}

// update:
//	Given the point, updates the bounding box to include the point.
//
// returns: 0 on failure, 1 on success

int	BoundingBox::update(Vector point, int init)
{
	int retval = 0;

	if (init) {
	    xMin = xMax	= point[0];
	    yMin = yMax	= point[1];
	    zMin = zMax	= point[2];
	    return(1);
	}

	if (point[0] < xMin) {
	      xMin = point[0];
	      retval = 1;
	}
	if (point[0] > xMax) {
	      xMax = point[0];
	      retval = 1;
	}
	if (point[1] < yMin) {
	      yMin = point[1];
	      retval = 1;
	}
	if (point[1] > yMax) {
	      yMax = point[1];
	      retval = 1;
	}
	if (point[2] < zMin) {
	      zMin = point[2];
	      retval = 1;
	}
	if (point[2] > zMax) {
	      zMax = point[2];
	      retval = 1;
	}
	return(retval);
}

void BoundingBox::scale(double x, double y, double z)
{
  xMin = x*xMin;
  yMin = y*yMin;
  zMin = z*zMin;
  xMax = x*xMax;
  yMax = y*yMax;
  zMax = z*zMax;
}

void BoundingBox::scaleCenter(double x, double y, double z) {
  
  double cx, cy, cz;
  
  cx = (xMin+xMax)/2.0;
  cy = (yMin+yMax)/2.0;
  cz = (zMin+zMax)/2.0;
  
  xMin = cx - (cx-xMin)*x;
  xMax = cx + (xMax-cx)*x;

  yMin = cy - (cy-yMin)*y;
  yMax = cy + (yMax-cy)*y;

  zMin = cz - (cz-zMin)*z;
  zMax = cz + (zMax-cz)*z;

}

void BoundingBox::MakeEmpty()
{
	xMin = yMin = zMin = 0.0;
	xMax = yMax = zMax = 0.0;
}

BoundingBox& BoundingBox::operator=(const BoundingBox &b) {
  
  xMin = b.xMin;
  yMin = b.yMin;
  zMin = b.zMin;

  xMax = b.xMax;
  yMax = b.yMax;
  zMax = b.zMax;

  return *this;
}

bool BoundingBox::overlap(const BoundingBox &b) const {
  
  int ox, oy, oz;

  if (xMax<b.xMin || b.xMax<xMin) {
    return false;
  }
  if (yMax<b.yMin || b.yMax<yMin) {
    return false;
  }
  if (zMax<b.zMin || b.zMax<zMin) {
    return false;
  }

  if ((b.xMin<xMax && b.xMin>xMin) || (b.xMax<xMax && b.xMax>xMin)) {
    ox = 1;
  } else {
    ox = 0;
  }

  if ((b.yMin<yMax && b.yMin>yMin) || (b.yMax<yMax && b.yMax>yMin)) {
    oy = 1;
  } else {
    oy = 0;
  }

  if ((b.zMin<zMax && b.zMin>zMin) || (b.zMax<zMax && b.zMax>zMin)) {
    oz = 1;
  } else {
    oz = 0;
  }

  return (ox&&oy&&oz);
}

void BoundingBox::printInterp() {
  
  danceInterp::OutputMessage("bbox <%f %f> <%f %f> <%f %f>", 
			  xMin, xMax, yMin, yMax, zMin, zMax);
}

void BoundingBox::intersect(const BoundingBox &a, const BoundingBox &b) {
  
  if (!a.overlap(b)) {
    MakeEmpty();
    return;
  }

  xMin = max(a.xMin, b.xMin);
  xMax = min(a.xMax, b.xMax);

  yMin = max(a.yMin, b.yMin);
  yMax = min(a.yMax, b.yMax);

  zMin = max(a.zMin, b.zMin);
  zMax = min(a.zMax, b.zMax);

  /* __min(), __max()
   * incompatible with g++. Try to use min(), max()

  xMin = __max(a.xMin, b.xMin);
  xMax = __min(a.xMax, b.xMax);

  yMin = __max(a.yMin, b.yMin);
  yMax = __min(a.yMax, b.yMax);

  zMin = __max(a.zMin, b.zMin);
  zMax = __min(a.zMax, b.zMax);
  */
  
}

void BoundingBox::getMidPoint(double *vec) {
  
  vec[0] = (xMin+xMax)/2.0;
  vec[1] = (yMin+yMax)/2.0;
  vec[2] = (zMin+zMax)/2.0;
}

double BoundingBox::getVolume() {
  
  return (xMax-xMin)*(yMax-yMin)*(zMax-zMin);
  
}

bool BoundingBox::contains(double pos[3]) {
  
  return (pos[0]>xMin&&pos[0]<xMax &&
	  pos[1]>yMin&&pos[1]<yMax &&
	  pos[2]>zMin&&pos[2]<zMax);
}

void BoundingBox::getVertex(int index, double pos[3]) {
  
  if ((index&0x1)==0) {
    pos[0] = xMax;
  } else {
    pos[0] = xMin;
  }

  if ((index&0x2)==0) {
    pos[1] = yMax;
  } else {
    pos[1] = yMin;
  }

  if ((index&0x4)==0) {
    pos[2] = zMax;
  } else {
    pos[2] = zMin;
  }
}

bool BoundingBox::findCollisionPoint(double *pos, double *vel, 
				     double *intPos) {
  double min[3] = {
    xMin, yMin, zMin};
  double max[3] = {
    xMax, yMax, zMax };
  double minV, currV;
  double tmpPos[3];
  int i, j;

  bool result;

  result = false;
  minV = 0;

  for (i=0 ; i < 3 ; i++) {
    
    if (vel[i]==0) {
      continue;
    }

    for (j=0 ; j < 2 ; j++) {
      
      if (j%2==0) {
	currV = (min[i]-pos[i])/vel[i];
      } else {
	currV = (max[i]-pos[i])/vel[i];
      }

      if (currV<0) {
	// the plane is behind us
	continue;
      }

      // make certain it's contained within the other two dimensions
      
      tmpPos[0] = pos[0] + currV*vel[0];
      tmpPos[1] = pos[1] + currV*vel[1];
      tmpPos[2] = pos[2] + currV*vel[2];
      
      tmpPos[i] = (min[i]+max[i])/2.0;
      
      if (contains(tmpPos)){
	
	// we have a winner
	// restore tmpPos[i]

	//danceInterp::OutputMessage("Intersected with vel <%f %f %f> currV %f j %d at <%f %f %f>", 
	//vel[0], vel[1], vel[2], currV, 
	//j, tmpPos[0], tmpPos[1], tmpPos[2]);

#if 0
	if (j) {
	  danceInterp::OutputMessage("intersect max %f", max[i]);
	} else {
	  danceInterp::OutputMessage("intersect min %f", min[i]);
	}
#endif

	tmpPos[i] = pos[i]+currV*vel[i];
	
	if (result) {
	  // we already had a previous result, make certain the 
	  // current intersection is closer

	  if (currV<minV) {
	    minV = currV;
	    intPos[0] = tmpPos[0];
	    intPos[1] = tmpPos[1];
	    intPos[2] = tmpPos[2];
	  }
	} else {
	  
	  result = true;

	  // we're the first intersection. Init the value
	  minV = currV;
	  
	  intPos[0] = tmpPos[0];
	  intPos[1] = tmpPos[1];
	  intPos[2] = tmpPos[2];
	}
      } 
    }    
  }
  
  return result;

}
