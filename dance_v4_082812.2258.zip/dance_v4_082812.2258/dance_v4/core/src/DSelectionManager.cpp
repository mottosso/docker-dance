#include "DSelectionManager.h"
#include "DObject.h"
#include "DAttribute.h"

DSelectionManager::DSelectionManager()
{
}

DSelectionManager::~DSelectionManager()
{
}

void DSelectionManager::addSelectedObject(DObject* object)
{
	m_selectedObjects[object->getName()] = object;
}

void DSelectionManager::removeSelectedObject(DObject* object)
{
	std::map<std::string, DObject*>::iterator iter = m_selectedObjects.find(object->getName());
	if (iter != m_selectedObjects.end())
		m_selectedObjects.erase(iter);
}

std::map<std::string, DObject*>& DSelectionManager::getSelectedObjects()
{
	return m_selectedObjects;
}

bool DSelectionManager::isObjectSelected(std::string name)
{
	std::map<std::string, DObject*>::iterator iter = m_selectedObjects.find(name);
	if (iter != m_selectedObjects.end())
		return true;
	else
		return false;
}

void DSelectionManager::addSelectedAttribute(DAttribute* attribute)
{
	m_selectedAttributes.insert(attribute);
}

void DSelectionManager::removeSelectedAttribute(DAttribute* attribute)
{
	m_selectedAttributes.erase(attribute);
}

std::set<DAttribute*>& DSelectionManager::getSelectedAttributes()
{
	return m_selectedAttributes;
}

bool DSelectionManager::isAttributeSelected(DAttribute* attribute)
{
	std::set<DAttribute*>::iterator iter = m_selectedAttributes.find(attribute);
	if (iter != m_selectedAttributes.end())
		return true;
	else
		return false;

}

