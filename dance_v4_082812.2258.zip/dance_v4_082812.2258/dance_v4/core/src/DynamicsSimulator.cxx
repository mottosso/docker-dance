/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "DynamicsSimulator.h"

using namespace std;

DynamicsSimulator::DynamicsSimulator() : DSimulator()
{
}

DynamicsSimulator::~DynamicsSimulator()
{
}

int DynamicsSimulator::commandPlugIn(int argc, char **argv)
{
	return DANCE_OK;
}


int DynamicsSimulator::GetVelSize()
{
	return 0;
}

int DynamicsSimulator::SetVel(int index, double value)
{
	return 0;
}

int DynamicsSimulator::SetVel(int startIndex, int size, double *q)
{
	return 0;
}

double DynamicsSimulator::GetVel(int index)
{
	return 0.0;
}


double *DynamicsSimulator::GetVel()
{
	return NULL;
}

double *DynamicsSimulator::GetVel(int startIndex, int size, double *q)
{
	return NULL;
}

double DynamicsSimulator::GetAcc(int index)
{
	return MINFLOAT;
}

double *DynamicsSimulator::GetAcc()
{
	return NULL;
}

void DynamicsSimulator::GetAngAcc(int group, double *acc)
{
}

double *DynamicsSimulator::GetAcc(int startIndex, int size, double *q)
{
	return NULL;
}
int DynamicsSimulator::GetIndex(int group, int subgroup)
{
	return 0;
}

int DynamicsSimulator::GetIndex(int argc, char **argv)
{
	return 0;
}

void DynamicsSimulator::FieldForce(double *force)
{
}

void DynamicsSimulator::FieldForce(double *force, double *dampConst)
{ 
}

void DynamicsSimulator::PointForce(int group, double *point, double *force) 
{
}
 
void DynamicsSimulator::PointForce(DSystem *sys, double *pointWorldCoord, double *force)
{
}

void DynamicsSimulator::PointForce(int argc, char *argv[])
{
}

void DynamicsSimulator::PFJ_dv(int pointIndex, Matrix3x3 &J)
{
}

void DynamicsSimulator::PFJ_dx(int pointIndex, Matrix3x3 &J)
{
}

void DynamicsSimulator::BodyTorque(int group, double *torque)
{
}

void DynamicsSimulator::GeneralizedForce(int coord, double force)
{
}

void DynamicsSimulator::GeneralizedForce(int *index, double *force, int size)
{
}

void DynamicsSimulator::GeneralizedForce(double *Q)
{
}

void DynamicsSimulator::GeneralizedForce(int group, int subgroup, double force)
{
}

void DynamicsSimulator::GetVel(DSystem *sys, double *localPoint, double *vel)
{
}

void DynamicsSimulator::GetVel(DSystem *sys, double *localPoint, int index, double *vel)
{
}

void DynamicsSimulator::GetVel(int group, double *point, double *vel)
{
}

void DynamicsSimulator::GetAcc(int group, double *point, double *acc)
{
}

void DynamicsSimulator::GetAcc(DSystem *sys, double *localPoint, double *acc)
{
}

int DynamicsSimulator::GetPosition(DSystem *sys, double *localPoint, double *position)
{
	return 0;
}

int DynamicsSimulator::GetPosition(int group, double *localPoint, double *position)
{
	return 0;
}

int DynamicsSimulator::GetOrientation(DSystem *sourceSystem, double *sourceVec, DSystem *targetSystem, double *targetVec)
{
	return 0;
}

int DynamicsSimulator::GetOrientation(int sourceGroup, double *localVec, int targetGroup, double *rotated)
{
	return 0;
}

int DynamicsSimulator::Transform(int argc, char **argv)
{
	return 0;
}




