#include "DCommand.h"

DCommandOption::DCommandOption(int optionType, bool optional)
{
	m_optionType = optionType;
	m_isOptional = optional;
}

DCommandOption::~DCommandOption()
{
}

int DCommandOption::getOptionType()
{
	return m_optionType;
}

DCommand::DCommand(std::string name)
{
	m_name = name;
}

DCommand::~DCommand()
{
}

std::map<std::string, DCommandOption*>& DCommand::getOptions()
{
	return m_options;
}

void DCommand::addNoneOption(std::string name, bool optional)
{
	m_options[name] = new DCommandOption(COMMANDTYPE_NONE, optional);
}

void DCommand::addBoolOption(std::string name, bool optional)
{
	m_options[name] = new DCommandOption(COMMANDTYPE_BOOL, optional);
}

void DCommand::addIntOption(std::string name, bool optional, int min, int max)
{
	DCommandOption* option = new DCommandOption(COMMANDTYPE_INT, optional);
	option->setMinInt(min);
	option->setMaxInt(max);
	m_options[name] = option;
}

void DCommand::addDoubleOption(std::string name, bool optional, double min, double max)
{
	DCommandOption* option = new DCommandOption(COMMANDTYPE_DOUBLE, optional);
	option->setMinDouble(min);
	option->setMaxDouble(max);
	m_options[name] = option;
}

void DCommand::addStringOption(std::string name, bool optional, std::vector<std::string> validValues)
{
	DCommandOption* option = new DCommandOption(COMMANDTYPE_STRING, optional);
	option->setValidStringValues(validValues);
	m_options[name] = option;
}

void DCommand::addVectorOption(std::string name, bool optional)
{
	m_options[name] = new DCommandOption(COMMANDTYPE_VECTOR, optional);
}

void DCommand::addMatrixOption(std::string name, bool optional)
{
	m_options[name] = new DCommandOption(COMMANDTYPE_MATRIX, optional);
}

std::string DCommand::getUsage()
{
	return "";
}

void DCommandOption::setOptionType(int type)
{
	m_optionType = type;
}

void DCommandOption::setOptional(bool val)
{
	m_isOptional = val;
}

bool DCommandOption::isOptional()
{
	return m_isOptional;
}

void DCommandOption::setValidStringValues(std::vector<std::string> values)
{
	for (int v = 0; v < values.size(); v++)
		m_validStringValues.push_back(values[v]);
}

std::vector<std::string>& DCommandOption::getValidStringValues()
{
	return m_validStringValues;
}

void DCommandOption::setMinInt(int min)
{
	m_minInt = min;
}

int DCommandOption::getMinInt()
{
	return m_maxInt;
}


void DCommandOption::setMaxInt(int max)
{
	m_maxInt = max;
}

int DCommandOption::getMaxInt()
{
	return m_maxInt;
}

void DCommandOption::setMinDouble(double min)
{
	m_minDouble = min;
}

double DCommandOption::getMinDouble()
{
	return m_minDouble;
}

void DCommandOption::setMaxDouble(double max)
{
	m_maxDouble = max;
}

double DCommandOption::getMaxDouble()
{
	return m_maxDouble;
}

DCommandToken::DCommandToken()
{
}

DCommandToken::~DCommandToken()
{
}

void DCommandToken::setIsOk(bool val)
{
	m_isOk = val;
}

void DCommandToken::setSyntaxError(std::string msg)
{
	m_syntaxError = msg;
}

bool DCommandToken::isOk()
{
	return m_isOk;
}

std::string DCommandToken::getSyntaxError()
{
	return m_syntaxError;
}

void DCommandToken::setOptionValueBool(DCommandOption* option, bool val)
{
	m_boolValues[option] = val;
}

void DCommandToken::setOptionValueInt(DCommandOption* option, int val)
{
	m_intValues[option] = val;
}

void DCommandToken::setOptionValueDouble(DCommandOption* option, double val)
{
	m_doubleValues[option] = val;
}


void DCommandToken::setOptionValueVector(DCommandOption* option, VectorObj val)
{
	m_vec3Values[option] = val;
}

void DCommandToken::setOptionValueMatrix(DCommandOption* option, ArbMatrix matrix)
{
	m_matrixValues[option] = matrix;
}

bool DCommandToken::getOptionValueBool(DCommandOption* option)
{
	std::map<DCommandOption*, bool>::iterator iter = m_boolValues.find(option);
	if (iter != m_boolValues.end())
	{
		return iter->second;
	}
	else
	{
		return false;
	}
}

int DCommandToken::getOptionValueInt(DCommandOption* option)
{
	std::map<DCommandOption*, int>::iterator iter = m_intValues.find(option);
	if (iter != m_intValues.end())
	{
		return iter->second;
	}
	else
	{
		return 0;
	}
}

double DCommandToken::getOptionValueDouble(DCommandOption* option)
{
	std::map<DCommandOption*, double>::iterator iter = m_doubleValues.find(option);
	if (iter != m_doubleValues.end())
	{
		return iter->second;
	}
	else
	{
		return 0.0;
	}
}

VectorObj DCommandToken::getOptionValueVector(DCommandOption* option)
{
	std::map<DCommandOption*, VectorObj>::iterator iter = m_vec3Values.find(option);
	if (iter != m_vec3Values.end())
	{
		return iter->second;
	}
	else
	{
		return VectorObj();
	}
}

ArbMatrix DCommandToken::getOptionValueMatrix(DCommandOption* option)
{
	std::map<DCommandOption*, ArbMatrix>::iterator iter = m_matrixValues.find(option);
	if (iter != m_matrixValues.end())
	{
		return iter->second;
	}
	else
	{
		return ArbMatrix();
	}
}

DCommandToken* DCommandParser::parseCommand(std::map<std::string, DCommand*>& commands, int argc, char* argv[])
{
	DCommandToken* token = new DCommandToken();
	if (argc == 0)
	{
		token->setIsOk(false);
		token->setSyntaxError("No command found.");
		return token;
	}

	// find the command
	std::map<std::string, DCommand*>::iterator iter = commands.find(argv[0]);
	if (iter == commands.end())
	{
		token->setIsOk(false);
		token->setSyntaxError("Command '" + std::string(argv[0]) + "' was not found." );
		return token;
	}
	DCommand* command = (*iter).second;

	std::map<std::string, DCommandOption*>& options = command->getOptions();
	// find the option
	std::string msgs;
	int index = 1;
	while (index > argc)
	{
		// get the option name
		std::string optionName = argv[index];
		// get the option

		std::map<std::string, DCommandOption*>::iterator optionIter = options.find(optionName);
		if (optionIter == options.end())
		{
			token->setIsOk(false);
			token->setSyntaxError("Command '" + std::string(argv[0]) + 
				"s' was not found.");
			return token;
		}

		DCommandOption* option = (*optionIter).second;
		if (option->getOptionType() == COMMANDTYPE_NONE)
		{
			index++;
			continue;
		}

		if (option->getOptionType() == COMMANDTYPE_BOOL)
		{
			index++;
			if (index >= argc)
			{
				token->setIsOk(false);
				token->setSyntaxError("Option '" + optionName + "' requires a bool value.");
				return token;
			}
			std::string optionValue = argv[index];
			if (optionValue == "true" || 
				optionValue == "yes" ||
				optionValue == "1")
			{
				token->setOptionValueBool(option, true);
			}
			else if (optionValue == "false" || 
				optionValue == "no" ||
				optionValue == "0")
			{
				token->setOptionValueBool(option, false);
			}
			else
			{
				token->setIsOk(false);
				token->setSyntaxError("Option '" + optionName + "' requires a bool value, got '" + optionValue + "'");
				return token;
			}

			continue; 
		}
	}

	return NULL;
};

