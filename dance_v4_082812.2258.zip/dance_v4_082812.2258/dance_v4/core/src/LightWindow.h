/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _LIGHTWINDOW_
#define _LIGHTWINDOW_

#include "DLight.h"
#include "opengl.h"
#include <fltk/Window.h>
#include <fltk/GlWindow.h>
#include <fltk/Window.h>
#include <fltk/glut.h>
#include <fltk/CheckButton.h>
#include <fltk/Choice.h>
#include <fltk/draw.h>
#include <fltk/Box.h>
//#include <fltk/Counter.h>
#include <fltk/ValueInput.h>
#include <fltk/ValueSlider.h>
#include <fltk/ThumbWheel.h>
//#include <fltk/RoundButton.h>
#include <fltk/Output.h>
#include <fltk/Input.h>
#include <fltk/Button.h>
#include <fltk/ColorChooser.h>

//#include <GL/glu.h>

// Comments: The style of this code was adapted from GeometryWindow.cpp/.h

class DLight;

class DLLENTRY LightWindow : public fltk::Group
{
public:
	LightWindow(DLight*, int,int,int,int,const char*);
	void show();

	DLight* getLight();

	void updateGUI();

	uchar type() const { return LIGHTWINDOWTYPE; }

	static void TranslateKeyCB(fltk::Widget *w, void *data);
	static void TranslateCB(fltk::Widget *w, void *data);

	static void AmbientColorCB(fltk::Widget *w, void *data);
	static void AmbientCB(fltk::Widget *w, void *data);
	static void AmbientKeyCB(fltk::Widget *w, void *data);
	
	static void DiffuseColorCB(fltk::Widget *w, void *data);
	static void DiffuseKeyCB(fltk::Widget *w, void *data);
	static void DiffuseCB(fltk::Widget *w, void *data);
	
	static void SpecularColorCB(fltk::Widget *w, void *data);
	static void SpecularKeyCB(fltk::Widget *w, void *data);
	static void SpecularCB(fltk::Widget *w, void *data);

	static void DirectionalCB(fltk::Widget *w, void *data);
	static void AttenuationCB(fltk::Widget *w, void *data);
	static void SpotlightCB(fltk::Widget *w, void *data);
	static void SpotlightParametersCB(fltk::Widget *w, void *data);
	static void RelativeToCameraCB(fltk::Widget *w, void *data);
	static void VisibleCB(fltk::Widget *w, void *data);

private:
	static const uchar LIGHTWINDOWTYPE = (uchar)400;

	fltk::ValueInput *m_inputX;
	fltk::ThumbWheel* m_thumbWheelX;
	double oldX;
	fltk::ValueInput *m_inputY;
	fltk::ThumbWheel* m_thumbWheelY;
	double oldY;
	fltk::ValueInput *m_inputZ;
	fltk::ThumbWheel* m_thumbWheelZ;
	double oldZ;

	fltk::ValueInput *m_inputAmbientR;
	fltk::ValueSlider *m_sliderAmbientR;
	double oldAmbientR;
	fltk::ValueInput *m_inputAmbientG;
	fltk::ValueSlider *m_sliderAmbientG;
	double oldAmbientG;
	fltk::ValueInput *m_inputAmbientB;
	fltk::ValueSlider *m_sliderAmbientB;
	double oldAmbientB;

	fltk::ValueInput *m_inputDiffuseR;
	fltk::ValueSlider* m_sliderDiffuseR;
	double oldDiffuseR;
	fltk::ValueInput *m_inputDiffuseG;
	fltk::ValueSlider* m_sliderDiffuseG;
	double oldDiffuseG;
	fltk::ValueInput *m_inputDiffuseB;
	fltk::ValueSlider* m_sliderDiffuseB;
	double oldDiffuseB;

	fltk::ValueInput *m_inputSpecularR;
	fltk::ValueSlider* m_sliderSpecularR;
	double oldSpecularR;
	fltk::ValueInput *m_inputSpecularG;
	fltk::ValueSlider* m_sliderSpecularG;
	double oldSpecularG;
	fltk::ValueInput *m_inputSpecularB;
	fltk::ValueSlider* m_sliderSpecularB;
	double oldSpecularB;

	// These buttons will open up the color chooser to set ambient, diffuse, specular settings
	fltk::Button* m_buttonAmbient;
	fltk::Button* m_buttonDiffuse;
	fltk::Button* m_buttonSpecular;

	fltk::CheckButton* checkDirectional;
	fltk::CheckButton* checkRelativeToCamera;
	fltk::CheckButton* checkVisible;

	fltk::Input* inputConstantAttentuation;
	fltk::Input* inputLinearAttentuation;
	fltk::Input* inputQuadraticAttentuation;

	fltk::CheckButton* checkSpotlight;
	fltk::Input* inputSpotDirection[3];
	fltk::Input* inputSpotCutoffAngle;
	fltk::Input* inputSpotExponent;


	DLight* m_light;
};

#endif
