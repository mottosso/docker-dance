/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "ParserASFAMC.h"

#include <iostream>
#include <stack>
#include <vector>
#include <sstream>
#include <cstdlib>
#include "danceInterp.h"
#include "dance.h"
#include "stuff.h"
#include "DConnectionManager.h"

using namespace std;

Character* ParserASFAMC::parse(std::string name, std::ifstream &metaFile, std::ifstream &dataFile)
{
	// check to make sure we have properly opened the file
	if (!metaFile.good())
	{
		danceInterp::OutputMessage("Could not open meta file.\n");
		if (dataFile.good())
			dataFile.close();
		return NULL;
	}

	if (!dataFile.good())
	{
		danceInterp::OutputMessage("Could not open data file.\n");
		metaFile.close();
		return NULL;
	}

	char line[4096];
	Character* c = new Character();
	c->setName(name.c_str());
	c->setIsBVH(false);

	int state = 0;
	char* str;
	stack<CharJoint*> stack;
	CharJoint* cur = NULL;
	int curFrame = -1;
	double frameTime = .033; // assume 30 frames/sec
	vector<CharJoint*> jointList;
	int jointNumber = 0;
	Vector curDirection = {0.0, 0.0, 0.0};
	bool useDegrees = true;
	char frameStr[128];

	while(!metaFile.eof() && metaFile.good())
	{
		metaFile.getline(line, 4096, '\n');
                if (line[strlen(line) - 1] == '\r')
                        line[strlen(line) - 1] = '\0';

		if (strlen(line) == 0) // ignore blank lines
			continue;
		if (strncmp(line, "#", 1) == 0) // ignore comment lines
			continue;

		switch (state)
		{
			case 0:	// looking for ':version'
				str = strtok(line, " ");
				if (strcmp(str, ":version") == 0)
				{
					state = 1;
				}
				else
				{
					danceInterp::OutputMessage(":version not found...\n");
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 1:	// looking for ':name'
				str = strtok(line, " ");
				if (strcmp(str, ":name") == 0)
				{
					str = strtok(NULL, " ");
					if (str != NULL)
					{
						StringAttribute* nameAttr = dynamic_cast<StringAttribute*>(c->getAttribute("namefromfile"));
						if (nameAttr)
							nameAttr->setValue(str);
					}
					state = 2;
				}
				else
				{
					danceInterp::OutputMessage(":name not found...\n");
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 2: // looking for ':units'
				str = strtok(line, " ");
				if (strcmp(str, ":units") == 0)
				{
					state = 3;
				}
				else
				{
					danceInterp::OutputMessage(":units not found...\n");
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 3: // units parameters or // looking for ':documentation'
				str = strtok(line, " ");
				if (strcmp(str, ":documentation") == 0)
				{
					state = 4;
				}
				else
				{
					char *value = strtok(NULL, " ");
					if (value != NULL)
					{
						danceInterp::OutputMessage("Found parameter %s = %s.", str, value);
					}
					else
					{
						danceInterp::OutputMessage("Problem parsing :units values...\n");
						metaFile.close();
						dataFile.close();
						return c;
					}
				}
				break;
			case 4: // documentation values
				str = strtok(line, " ");
				if (strcmp(str, ":root") == 0)
				{
					std::stringstream str;
					str << c->getName() << "_root";
					cur = new CharJoint(str.str().c_str());
					dance::AllGenericPlugins->add(cur);
					dance::connectionManager->makeConnection(c, "rootjoint", cur);
					cur->setFrameTime(frameTime);
					jointList.push_back(cur);
					jointNumber++;
					state = 5;
				}
				else // assume documentaion data
				{
					// ignore it
				}
				break;
			case 5: // root parameters or // looking for ':bonedata'
				str = strtok(line, " ");
				if (strcmp(str, ":bonedata") == 0)
				{
					state = 6;
				}
				else
				{
					if (strcmp(str, "order") == 0)
					{
						int channels[6] = {0};
						int numChannels = 0;
						while ((str = strtok(NULL, " ")) != NULL)
						{
#ifdef WIN32
                                                        #define strcasecmp stricmp
#endif
							if (strcasecmp(str, "tx") == 0)
							{
								channels[numChannels] = CharJoint::XPOSITION;
								numChannels++;
							}
							else if (strcasecmp(str, "ty") == 0)
							{
								channels[numChannels] = CharJoint::YPOSITION;
								numChannels++;
							}
							else if (strcasecmp(str, "tz") == 0)
							{
								channels[numChannels] = CharJoint::ZPOSITION;
								numChannels++;
							}
							else if (strcasecmp(str, "rx") == 0)
							{
								channels[numChannels] = CharJoint::XROTATION;
								numChannels++;
							}
							else if (strcasecmp(str, "ry") == 0)
							{
								channels[numChannels] = CharJoint::YROTATION;
								numChannels++;
							}
							else if (strcasecmp(str, "rz") == 0)
							{
								channels[numChannels] = CharJoint::ZROTATION;
								numChannels++;
							}
							else
							{
								danceInterp::OutputMessage("Unrecognized channel '%s', continuing...", str);
							}
						}
						cur->setChannels(numChannels, channels);
					}
					else if (strcmp(str, "axis") == 0)
					{
						// assume axis is XYZ for orientation parameters that follow
						// ignore it
					}
					else if (strcmp(str, "orientation") == 0)
					{
						Vector axis = {0.0, 0.0, 0.0};
						int axisCount = 0;
						while ((str = strtok(NULL, " ")) != NULL)
						{
							axis[axisCount] = atof(str);
							axisCount++;
						}
						// convert to radians
//						danceInterp::OutputMessage("Axis %s: %f %f %f", cur->getName(), axis[0], axis[1], axis[2]);
						if (useDegrees)
							for (int a = 0; a < 3; a++)
								axis[a] *= M_PI / 180.0;
						cur->setAxis(axis);
					}
					else if (strcmp(str, "position") == 0)
					{
						Vector pos = {0.0, 0.0, 0.0};
						int posCount = 0;
						while ((str = strtok(NULL, " ")) != NULL)
						{
							pos[posCount] = atof(str);
							posCount++;
						}
						cur->setOffset(pos[0], pos[1], pos[2]);
						cur->setDirection(0.0, 0.0, 0.0);
						cur->setLength(0.0);
					}
					else
					{
						danceInterp::OutputMessage("Unknown token '%s', expected ':bonedata', 'order', 'axis', 'position', 'orientation'...\n", str);
						metaFile.close();
						dataFile.close();
						return c;
					}
				}
				break;
			case 6: // in bonedata or // looking for ':hierarchy'
				str = strtok(line, " ");
				if (strcmp(str, ":hierarchy") == 0)
				{
					state = 15;
				}
				else if (strcmp(str, "begin") == 0)
				{
					state = 7;
				}
				else
				{
					danceInterp::OutputMessage("Unknown token '%s', expected ':hierarchy' or 'begin'...\n", str);
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 7: // found begin, looking for an id
				str = strtok(line, " ");
				if (strcmp(str, "id") == 0)
				{
					state = 8;
				}
				else
				{
					danceInterp::OutputMessage("Unknown token '%s', expected 'id'...\n", str);
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 8: // found begin, looking for name
				str = strtok(line, " ");
				if (strcmp(str, "name") == 0)
				{
					str = strtok(NULL, " ");
					if (str != NULL)
					{
						std::stringstream strstr;
						strstr << c->getName() << "_" << str;
						cur = new CharJoint(strstr.str().c_str());
						dance::AllGenericPlugins->add(cur);
						state = 9;
					}
					else // assign a name based on the joint number
					{
						danceInterp::OutputMessage("Unknown name for joint....\n", str);
						metaFile.close();
						dataFile.close();
						return c;
					}
				}
				else
				{
					danceInterp::OutputMessage("Unknown token '%s', expected 'name'...\n", str);
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 9: // found begin, looking for direction
				str = strtok(line, " ");
				if (strcmp(str, "direction") == 0)
				{
					zeroVector(curDirection);
					int posCount = 0;
					while ((str = strtok(NULL, " ")) != NULL)
					{
						curDirection[posCount] = atof(str);
						posCount++;
					}
//					danceInterp::OutputMessage("Current direction of %s is %f %f %f...\n", cur->getName(), curDirection[0], curDirection[1], curDirection[2]);
					state = 10;
				}
				else
				{
					danceInterp::OutputMessage("Unknown token '%s', expected 'direction'...\n", str);
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 10: // found begin, looking for length
				str = strtok(line, " ");
				if (strcmp(str, "length") == 0)
				{
					str = strtok(NULL, " ");
					double length = atof(str);
					cur->setLength(length);
					//VecNumMul(curDirection, curDirection, length);
					cur->setDirection(curDirection[0], curDirection[1], curDirection[2]);
					state = 11;
				}
				else
				{
					danceInterp::OutputMessage("Unknown token '%s', expected 'length'...\n", str);
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 11: // found begin , looking for axis;
				str = strtok(line, " ");
				if (strcmp(str, "axis") == 0)
				{
					Vector axis = {0.0, 0.0, 0.0};
					int axisCount = 0;
					while ((str = strtok(NULL, " ")) != NULL && axisCount < 3)
					{
						axis[axisCount] = atof(str);
						axisCount++;
					}
					if (useDegrees)
						for (int a = 0; a < 3; a++)
							axis[a] *= M_PI / 180.0;
					cur->setAxis(axis);
//					danceInterp::OutputMessage("Axis %s: %f %f %f", cur->getName(), axis[0], axis[1], axis[2]);
					// assume that the axis rotation order is XYZ
					// TODO: parse this rotation order value here and reorder data if necessary instead
					state = 12;
				}
				else
				{
					danceInterp::OutputMessage("Unknown token '%s', expected 'axis'...\n", str);
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 12: // found begin, looking for dof
				str = strtok(line, " ");
				if (strcmp(str, "dof") == 0)
				{
					int channels[6] = {0};
					int numChannels = 0;
					while ((str = strtok(NULL, " ")) != NULL)
					{
						if (strcasecmp(str, "RX") == 0)
						{
							channels[numChannels] = CharJoint::XROTATION;
							numChannels++;
						}
						else if (strcasecmp(str, "RY") == 0)
						{
							channels[numChannels] = CharJoint::YROTATION;
							numChannels++;
						}
						else if (strcasecmp(str, "RZ") == 0)
						{
							channels[numChannels] = CharJoint::ZROTATION;
							numChannels++;
						}
						else if (strcasecmp(str, "TX") == 0)
						{
							channels[numChannels] = CharJoint::XPOSITION;
							numChannels++;
						}
						else if (strcasecmp(str, "TY") == 0)
						{
							channels[numChannels] = CharJoint::YPOSITION;
							numChannels++;
						}
						else if (strcasecmp(str, "TZ") == 0)
						{
							channels[numChannels] = CharJoint::ZPOSITION;
							numChannels++;
						}
						else
						{
							danceInterp::OutputMessage("Unrecognized channel '%s', continuing...", str);
						}
					}
					cur->setChannels(numChannels, channels);
					state = 13;
				}
				else if (strcmp(str, "limits") == 0) // no dof found, passed to limits
				{
					cur->setChannels(0, NULL);
					state = 14;
				}
				else if (strcmp(str, "end") == 0) // no dof found, passed to end
				{
					cur->setChannels(0, NULL);
					jointList.push_back(cur);
					state = 6;
				}
				else
				{
					danceInterp::OutputMessage("Unknown token '%s', expected 'dof'...\n", str);
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 13: // found begin , looking for limits;
				str = strtok(line, " ");
				if (strcmp(str, "limits") == 0)
				{
					// ignore limits
					state = 14;
				}
				else
				{
					danceInterp::OutputMessage("Unknown token '%s', expected 'limits'...\n", str);
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 14: // found begin , looking for limit data or // looking for end;
				str = strtok(line, " ");
				if (strcmp(str, "end") == 0)
				{
					jointList.push_back(cur);
					// return to previous state, look for :hierarchy or another begin
					state = 6;
				}
				else if (strncmp(str, "(", 1) == 0)
				{
					// found more limits, ignore
				}
				else
				{
					danceInterp::OutputMessage("Unknown token '%s', expected ':hierarchy' or limit data...\n", str);
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 15: // found :hierarchy, looking for begin
				str = strtok(line, " ");
				if (strcmp(str, "begin") == 0)
				{
					state = 16;
				}
				else
				{
					danceInterp::OutputMessage("Unknown token '%s', expected 'begin'...\n", str);
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 16: // parent-child joint mapping
				str = strtok(line, " ");
				if (strcmp(str, "end") == 0)
				{
					state = 17;
				}
				else
				{
					// retrieve the parent
					std::string characterName = c->getName();
					CharJoint* parent = NULL;
					for (unsigned int p = 0; p < jointList.size(); p++)
					{
						std::string jointName = ParserASFAMC::extractJointName(c, jointList[p]);
						if (jointName == str)
						{
							parent = jointList[p];
							break;
						}
					}
					if (parent == NULL)
					{
						danceInterp::OutputMessage("Unknown parent '%s' when determining joint hierarchy...\n", str);
						metaFile.close();
						dataFile.close();
						return c;
					}
					while ((str = strtok(NULL, " ")) != NULL)
					{
						CharJoint* child = NULL;
						for (unsigned int cnum = 0; cnum < jointList.size(); cnum++)
						{
							std::string jointName =  ParserASFAMC::extractJointName(c, jointList[cnum]);
							if (jointName == str)
							{
								child = jointList[cnum];
								break;
							}
						}
						if (child == NULL)
						{
							danceInterp::OutputMessage("Unknown child '%s' when determining joint hierarchy...\n", str);
							metaFile.close();
							dataFile.close();
							return c;
						}
						dance::connectionManager->makeConnection(parent, "jointchild", child);
						// set the offset
						Vector direction;
						parent->getDirection(direction);
						Vector offset;
						VecNumMul(offset, direction, parent->getLength());
						child->setOffset(offset[0], offset[1], offset[2]);
//						danceInterp::OutputMessage("Joint %s direction %f %f %f length %f offset %f %f %f", child->getName(), direction[0], direction[1], direction[2], child->getLength(), offset[0], offset[1], offset[2]);
					}
				}
				break;
			case 17:
				metaFile.close();
				break;
			default:
				cerr << "State " << state << " not expected..." << endl;
				metaFile.close();


				dataFile.close();
				return c;
		}

	}

	// add the end effectors
	for (unsigned int j = 0; j < jointList.size(); j++)
	{
		CharJoint* joint = jointList[j];
		//vector<CharJoint*> children;
		//children = joint->getChildren();
		if (joint->getNumChildren() == 0)
		{
			joint->setEndEffector(true);
			Vector direction;
			joint->getDirection(direction);
			double length = joint->getLength();
			VecNumMul(direction, direction, length);
			joint->setEndEffectorOffset(direction[0], direction[1], direction[2]);
		}
	}

	curFrame = 0;
	int parsedFrameNum;

	// create a lookup table for the joint names
	std::map<std::string, int> jointMap;
	for (unsigned int j = 0; j < jointList.size(); j++)
	{
		CharJoint* joint = jointList[j];
		if (joint->getCharacter())
		{
			std::string localName = ParserASFAMC::extractJointName(joint->getCharacter(), joint);
			jointMap[localName] = j;
		}
		else
		{
			danceInterp::OutputMessage("Joint %d %s does not have a character attached. Why?", j, joint->getName());
		}
	}

	while(!dataFile.eof() && dataFile.good())
	{
		dataFile.getline(line, 4096, '\n');
                if (line[strlen(line) - 1] == '\r')
                        line[strlen(line) - 1] = '\0';

		if (strlen(line) == 0) // ignore blank lines
			continue;
		if (strncmp(line, "#", 1) == 0) // ignore comment lines
			continue;

		switch (state)
		{
			case 17: // start of motion data file parse
				str = strtok(line, " ");
				if (strcasecmp(str, ":FULLY-SPECIFIED") == 0)
				{
					// ignore
				}
				else if (strcasecmp(str, ":DEGREES") == 0)
				{
					useDegrees = true;
				}
				else if (strcasecmp(str, ":RADIANS") == 0)
				{
					useDegrees = false;
				}
				else if (atoi(str) != 0)
				{
					jointNumber = -1;
					parsedFrameNum = atoi(str);
					curFrame = parsedFrameNum;
					//std::cout << "FRAME NUMBER " << curFrame << std::endl;
					state = 18;
				}
				else
				{
					danceInterp::OutputMessage("Unknown token '%s', continuing...", str);
				}
				break;
			case 18:
				// get the joint name
				str = strtok(line, " ");
				// is this a frame nunmber and not a joint?
				parsedFrameNum = atoi(str);
				sprintf(frameStr, "%d", parsedFrameNum);
				if (strcmp(frameStr, str) == 0)
				{
					// calculate joint positions for previous frame
					//c->calculatePoints(curFrame - 1);
					
					curFrame++;
					//std::cout << "FRAME NUMBER " << curFrame << std::endl;
					jointNumber = -1;
					// calculate the maximum number of frames in use
					int max = -1;
					for (unsigned int x = 0; x < jointList.size(); x++)
					{
						CharJoint* curJoint = jointList[x];
						int num = curJoint->getNumFrames();
						if (num > max)
							max = num;
					}
					// make sure that all joints have that number of frames
					double frames[6] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
					for (unsigned int x = 0; x < jointList.size(); x++)
					{
						CharJoint* curJoint = jointList[x];
						int num = curJoint->getNumFrames();
						if (num < max)
						{
							curJoint->addFrame(frames);
						}
					}
					break;
				}

				// find the joint
				bool found = false;
				// search for the joint
				std::map<std::string, int>::iterator iter = jointMap.find(str);
				if (iter != jointMap.end())
				{
					cur = jointList[(*iter).second];
					found = true;
				}
				else
				{
					danceInterp::OutputMessage("Could not find joint %s...", str);
					dataFile.close();
					return c;
				}

				int channels[6] = {0};
				double frames[6] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
				cur->getChannels(channels);
				int curChannel = 0;
				while ((str = strtok(NULL, " ")) != NULL)
				{
					frames[curChannel] = atof(str);
					if (channels[curChannel] == CharJoint::XROTATION || channels[curChannel] == CharJoint::YROTATION || channels[curChannel] == CharJoint::ZROTATION )
					{
						if (!useDegrees)
							frames[curChannel] *= 180.0 / M_PI;
					}
					curChannel++;
				}
				cur->addFrame(frames);
				break;
		}
	}
	c->calculatePoints(curFrame-1);
	dataFile.close();

	if (state != 18)
	{
		danceInterp::OutputMessage("Motion incompletely parsed, finished at state %d...", state);
		dataFile.close();
	}
	else
	{
		danceInterp::OutputMessage("Finished parsing motion with %d frames...", curFrame);
	}

/*
	// determine which parent-child relationships do not match
	// this is done to eliminate joints with no DOF
	for (unsigned int x = 0; x < jointList.size(); x++)
	{
		CharJoint* parent = jointList[x]->getParent();
		if (parent != NULL)
		{
			if (parent->getNumChannels() == 0)
			{
				// move any child joints to this joints parent
				for (int x = 0; x < parent->getNumChildren(); x++)
				{
					CharJoint* child = parent->getChild(x);
					CharJoint* grandParent = parent->getParent();
					dance::connectionManager->removeConnection(parent, "jointchild", child);
					if (grandParent)				
						dance::connectionManager->makeConnection(grandParent, "jointchild", child);
				}

				// make sure that any joint who has this joint as a child removes it from the child list
				for (unsigned int x = 0; x < jointList.size(); x++)
				{
					CharJoint* check = jointList[x];
					for (int c = check->getNumChildren() - 1; c >= 0; c--)
					{
						CharJoint* checkChild = check->getChild(c);
						if (checkChild == parent)
						{
							dance::connectionManager->removeConnection(check, "jointchild", checkChild);
						}
					}
				}
				dance::AllGenericPlugins->remove(parent);
			}
		}

	}
	*/

	c->recalculateJointList();
	return c;
}


std::string ParserASFAMC::extractJointName(Character* c, CharJoint* joint)
{
	std::string characterName = c->getName();
	std::string fullJointName = joint->getName();
	int pos = fullJointName.find(characterName);
	if (pos != std::string::npos)
	{
		std::string jointName = fullJointName.substr(pos + characterName.size() + 1);
		return jointName;
	}
	else
	{
		return fullJointName;
	}
}