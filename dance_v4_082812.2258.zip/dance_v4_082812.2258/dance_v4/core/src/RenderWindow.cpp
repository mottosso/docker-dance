/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "RenderWindow.h"
#include "dance.h"
#include "DSimulatorManager.h"
#include <fltk/ask.h>
//#include <fltk/file_chooser.h>
#include <fltk/FileChooser.h>
#include "DRenderer.h"
#include "DSystem.h"
#include <Magick++.h>
#include "Preference.h"
#include <sstream>
#include "stuff.h"
#include "VideoWriter.h"

using namespace fltk;

RenderWindow::RenderWindow(int w, int h, const char* name) : Window(w, h, name)
{
	this->begin();

	browserRenderers = new Browser(20, 20, 150, 40, "Renderers");
	browserRenderers->callback(selectrenderer_cb, this);

	buttonRenderOptions = new Button(200, 20, 60, 20, "Options");
	buttonRenderOptions->callback(renderoptions_cb, this);

	checkCurrentFrame = new CheckButton(20, 70, 100, 20, "Render only current frame.");
	checkCurrentFrame->value(true);
	checkCurrentFrame->callback(checkcurrentframeonly_cb, this);

	inputStartTime = new FloatInput(90, 95, 40, 20, "Start Time");
	inputEndTime = new FloatInput(190, 95, 40, 20, "End Time");
	inputFPS = new FloatInput(260, 95, 40, 20, "FPS");
	inputFPS->value(30);

	checkMovie = new CheckButton(20, 120, 100, 20, "Render MPEG2 (.mpg) movie.");
	checkMovie->value(false);
	checkMovie->callback(checkmovie_cb, this);

	inputMovieName = new Input(100, 155, 150, 20, "Movie Name");
	inputMovieName->value("dancemovie.mpg");

	inputDirectory = new Input(100, 180, 150, 20, "Render Directory");
	buttonChangeRenderDirectory = new Button(260, 180, 30, 20, "...");
	buttonChangeRenderDirectory->callback(changerenderdir_cb, this);

	
	buttonRender = new Button(20, 240, 60, 20, "Render");
	buttonRender->callback(render_cb, this);
	buttonCancel = new Button(100, 240, 60, 20, "Cancel");
	buttonCancel->callback(cancel_cb, this);

	inputFrameNum = new Input(140, 210, 60, 20, "Start Frame Number:");
	inputFrameNum->callback(this->setframenum_cb, this);

	this->end();

	startTime = 0.0;
	endTime = 100.0;
	this->renderCounter = 1;

	renderDirectory[0] = '\0';

	isRendering = false;
}

RenderWindow::~RenderWindow()
{
}

void RenderWindow::show()
{
	this->updateGUI();
	Window::show();
}

void RenderWindow::updateGUI()
{
	browserRenderers->clear();
	
	for (int x = 0; x < dance::AllRenderers->size(); x++)
	{
		DRenderer* renderer = (DRenderer*) dance::AllRenderers->get(x);
		browserRenderers->add(renderer->getName());
		if (dance::AllViews->getRenderer() == renderer)
			browserRenderers->select(x);
	}

	if (renderDirectory[0] == '\0')
	{
		DRenderer* renderer = dance::AllViews->getRenderer();
		if (renderer != NULL)
			strcpy(renderDirectory, renderer->getRenderDirectory().c_str());
	}
	if (checkCurrentFrame->value())
	{
		inputStartTime->deactivate();
		inputEndTime->deactivate();
		inputFPS->deactivate();
		checkMovie->deactivate();
	}
	else
	{
		inputStartTime->activate();
		inputEndTime->activate();
		inputFPS->activate();
		checkMovie->activate();
		inputMovieName->activate();
	}

	if (inputStartTime->fvalue() < 0.0)
		inputStartTime->value(0.0);
	//if (inputEndTime->fvalue() > dance::AllSimulators->getPlaybackEndTime())
		inputEndTime->value(dance::AllSimulators->getPlaybackEndTime());

	std::stringstream fnum;
	if (dance::AllViews->getViewFocus() != NULL)
		fnum << dance::AllViews->getViewFocus()->getFrameNumber();
	else
		fnum << "1";
	this->inputFrameNum->value(fnum.str().c_str());

	inputDirectory->value(this->renderDirectory);

	std::stringstream strCounter;
	strCounter << dance::AllViews->getViewFocus()->getFrameNumber();
	this->inputFrameNum->value(strCounter.str().c_str());

	if (this->checkMovie->value())
	{
		this->inputMovieName->activate();
	}
	else
	{
		this->inputMovieName->deactivate();
	}

}

void RenderWindow::addRenderedFrame(const char* frameNames)
{
	renderedFrames.push_back(frameNames);
}

void RenderWindow::clearRenderedFrameList()
{
	renderedFrames.clear();
}

int RenderWindow::getNumFrames()
{
	return renderedFrames.size();
}

const char* RenderWindow::getFrameNum(unsigned int num)
{
	if (renderedFrames.size() > num)
		return renderedFrames[num].c_str();
	else
		return 0;
}

void RenderWindow::checkcurrentframeonly_cb(fltk::Widget* widget, void* data)
{
	RenderWindow* win = (RenderWindow*) data;

	if (!win->checkCurrentFrame->value())
	{
		win->inputStartTime->value(0.0);
		win->inputEndTime->value(dance::AllSimulators->getPlaybackEndTime());
	}
	win->updateGUI();
}

void RenderWindow::checkmovie_cb(fltk::Widget* widget, void* data)
{
	RenderWindow* win = (RenderWindow*) data;

	win->updateGUI();
}

void RenderWindow::renderoptions_cb(fltk::Widget* widget, void* data)
{
	RenderWindow* win = (RenderWindow*) data;

	// display the gui for the chosen renderer
	DRenderer* renderer = dance::AllViews->getRenderer();
	if (renderer == NULL)
	{
		fltk::alert("No renderer found. Please create a renderer and register it with the View Manager: dance.viewmanager(\"renderer\", \"<renderer_name>\")");
		return;
	}

	Widget* rendererWidget = renderer->getInterface();
	dance::rootWindow->parameterWindow->addInterface(rendererWidget, renderer->getName());
	dance::rootWindow->parameterWindow->floatInterface(rendererWidget);

	win->updateGUI();
}

std::string RenderWindow::makeCommandPath(std::string commandTemplate, std::string renderedFile)
{
	// replace the %1 in the command with the filename
	std::string file = renderedFile;
	#ifdef WIN32
	// change the unix-style file to a windows-style file
	// make sure that the filename starts with a drive letter
	int pos = file.find_first_of(":");
	if (pos == std::string::npos)
	{
		// append the c:
		std::string temp = "c:";
		if (file[0] != '/')
			temp.append("/");
		temp.append(file);
		file = temp;
	}
	// remove any dot paths
	pos = file.find("/./");
	if (pos != std::string::npos)
	{
		std::string temp = file.substr(0, pos);
		temp.append("/");
		std::string temp2 = file.substr(pos + 3, file.length() - pos - 3);
		temp.append(temp2);
		file = temp;
	}
	char windowsfile[1024];
	changechar((char*) file.c_str(), windowsfile, '/', '\\');
	std::stringstream strstr;
	for (int x = 0; x < file.length(); x++)
	{
		if (file[x] == '/')
			strstr << "\\";
		else
			strstr << file[x];
	}
	file = strstr.str();
	#endif
	for (unsigned int j = 0; (j = commandTemplate.find("%1")) != std::string::npos;)
	{
		commandTemplate.replace(j, 2, file);
	}

	return commandTemplate;
}

void RenderWindow::render_cb(fltk::Widget* widget, void* data)
{
	RenderWindow* win = (RenderWindow*) data;

	// make sure that a renderer is present
	DRenderer* renderer = dance::AllViews->getRenderer();
	if (renderer == NULL)
	{
		fltk::alert("No renderer found. Please create a renderer and register it with the View Manager: dance.viewmanager(\"renderer\", \"<renderer_name>\")");
		return;
	}

	if (win->checkCurrentFrame->value())
	{
		dance::AllViews->getViewFocus()->SaveFrame();

		std::stringstream renderedFile;
		//if (dance::rootWindow->commandWindow->getCurrentDirectory() != NULL &&
		//	(dance::rootWindow->commandWindow->getCurrentDirectory()[0] == '/' ||
		//	dance::rootWindow->commandWindow->getCurrentDirectory()[0] == '\\'))
		//	renderedFile << dance::rootWindow->commandWindow->getCurrentDirectory() << "/";
		renderedFile << dance::AllViews->getRenderer()->getLastRenderedFileName();

		if (renderer->isRunImageViewer())
		{
			std::string commandTemplate = renderer->getImageViewerCommand();
			std::string command = makeCommandPath(commandTemplate, renderedFile.str());
			
			danceInterp::OutputMessage("Running command: %s", command.c_str());
			int ret = system(command.c_str());
			danceInterp::OutputMessage("Frame has been rendered to:\n%s", renderedFile.str().c_str());
			if (ret == 0)
			{
                danceInterp::OutputMessage("Image successfully viewed using: %s", command.c_str());
			}
			else
			{
				danceInterp::OutputMessage("Image not successfully viewed using: %s", command.c_str());
				fltk::alert("Frame has been rendered to:\n%s.\nProblem running viewer command: %s", renderedFile.str().c_str(), command.c_str());
			}
		}
		else
		{
			danceInterp::OutputMessage("Frame has been rendered to:\n%s", renderedFile.str().c_str());
			fltk::alert("Frame has been rendered to:\n%s", renderedFile.str().c_str());
		}

		Preference::setWindowPreference("dance.renderwindow", win);
		dance::writePreferences();

		win->hide();
	}
	else
	{
		win->startTime = win->inputStartTime->fvalue();
		win->endTime = win->inputEndTime->fvalue();

		win->isRendering = true;
		win->currentRenderTime = -1.0;
		win->buttonRender->deactivate();
		win->browserRenderers->deactivate();
		win->inputEndTime->deactivate();
		win->inputStartTime->deactivate();
		win->inputFPS->deactivate();
		win->checkCurrentFrame->deactivate();

		fltk::add_idle(RenderWindow::idle_render, win);
	
	}

}

void RenderWindow::cancel_cb(fltk::Widget* widget, void* data)
{
	RenderWindow* win = (RenderWindow*) data;

	if (win->isRendering)
	{
		win->isRendering = false;
		fltk::remove_idle(RenderWindow::idle_render, win);
		fltk::alert("Rendering cancelled.");
	}
	else
	{
		Preference::setWindowPreference("dance.renderwindow", win);
		dance::writePreferences();
		win->hide();
	}
}

void RenderWindow::starttime_cb(fltk::Widget* widget, void* data)
{
	RenderWindow* win = (RenderWindow*) data;

	FloatInput* f = (FloatInput*) widget;

	win->startTime = f->fvalue();
}


void RenderWindow::endtime_cb(fltk::Widget* widget, void* data)
{
	RenderWindow* win = (RenderWindow*) data;

	FloatInput* f = (FloatInput*) widget;

	win->endTime = f->fvalue();
}

void RenderWindow::directory_cb(fltk::Widget* widget, void* data)
{
	RenderWindow* win = (RenderWindow*) data;

	Input* input = (Input*) widget;
	strcpy(win->renderDirectory, input->value());

}

void RenderWindow::selectrenderer_cb(fltk::Widget* widget, void* data)
{
	Browser* browser = (Browser*) widget;

	for (int x = 0; x < dance::AllRenderers->size(); x++)
	{
		DRenderer* renderer = (DRenderer*) dance::AllRenderers->get(x);
		if (browser->value() == x)
			dance::AllViews->setRenderer(renderer);
	}
}


void RenderWindow::idle_render(void* data)
{
	RenderWindow* win = (RenderWindow*) data;

	if (win->isRendering)
	{
		if (win->currentRenderTime == -1.0)
		{
			win->currentRenderTime = win->startTime;
			win->renderCounter = 0;
			win->clearRenderedFrameList();
		}

		// rewind the playback to the start time
		double timeStep = 1.0 / win->inputFPS->fvalue();

		bool isFlushed = false;
		while (win->currentRenderTime <= win->endTime)
		{ // playback and render
			dance::AllSimulators->setPlaybackTime(win->currentRenderTime);

			// set the state of all the systems
			for (int x = 0; x < dance::AllSystems->size(); x++)
			{
				DSystem* system = (DSystem*) dance::AllSystems->get(x);
				if (system->isPlayback())
					system->setState(win->currentRenderTime);
			}

			dance::AllViews->postRedisplay();
			if (!isFlushed)
			{
				dance::rootWindow->danceWindow->flush();
				isFlushed = true;
			}
			dance::AllViews->getViewFocus()->SaveFrame();
			win->addRenderedFrame(dance::AllViews->getRenderer()->getLastRenderedFileName().c_str());
			char buff[256];

			sprintf(buff, "%d", dance::AllViews->getViewFocus()->getFrameNumber());
			win->inputFrameNum->value(buff);
			win->inputFrameNum->show();

			win->currentRenderTime += timeStep;
			win->renderCounter++;
			win->redraw();
			return;
		}
		win->isRendering = false;

		fltk::alert("%d frames has been rendered to directory %s.", win->renderCounter, dance::AllViews->getRenderer()->getRenderDirectory().c_str());
		fltk::remove_idle(RenderWindow::idle_render);

		if (win->checkMovie->value() == 1) // create a movie from the frames
		{
			const char* animFileName = win->inputMovieName->value();
			if (animFileName != NULL && strlen(animFileName) > 0)
			{
				VideoWriter vw;

				try {
					for (int x = 0; x < win->getNumFrames(); x++) 
					{
						Magick::Image pic(win->getFrameNum(x)); // = base;
						vw.addFrame(pic);
					}
					//vw.setDelay(3.3);
					vw.setQuality(99);
					vw.saveVideo((char*) animFileName);
					fltk::alert("Created file: %s/%s",  dance::AllViews->getRenderer()->getRenderDirectory().c_str(), animFileName);
				}
				catch( exception &error_ ) {
					fltk::alert("Problem creating movie: %s", error_.what());
				}
			}
		}


		win->inputFrameNum->hide();
		win->buttonRender->activate();
		win->browserRenderers->activate();
		win->inputEndTime->activate();
		win->inputStartTime->activate();
		win->inputFPS->activate();
		win->checkCurrentFrame->activate();

		Preference::setWindowPreference("dance.renderwindow", win);
		dance::writePreferences();
		win->hide();
	}
}


void RenderWindow::changerenderdir_cb(fltk::Widget* widget, void* data)
{
	RenderWindow* win = (RenderWindow*) data;

	DRenderer* renderer = dance::AllViews->getRenderer();
	if (renderer == NULL)
	{
		alert("No renderer is present. Please select or create a renderer first.");
		return;
	}

	//const char* renderDir = renderer->getRenderDirectory();

	//const char* dir = fltk::file_chooser("Please choose a folder to render to:", NULL, renderDir);
//	const char* dir = fltk::file_chooser("Please choose a folder to render to:", NULL,renderDir);

	FileChooser chooser(".", NULL, FileChooser::SINGLE, "Chooser a folder:") ;
#ifdef WIN32
	chooser.exec(win, TRUE) ;
#else
	chooser.exec(win, TRUE) ;
#endif
    // Block until user picks something.
    //     (The other way to do this is to use a callback())
    //
    while(chooser.visible()) {
        fltk::wait();
    }
	
	if (chooser.directory() == NULL)
		return;
	else
		renderer->setRenderDirectory(chooser.directory());

	win->updateGUI();

}

void RenderWindow::setframenum_cb(fltk::Widget* widget, void* data)
{
	RenderWindow* win = (RenderWindow*) data;
	Input* input = (Input*) widget;

	dance::AllViews->getViewFocus()->setFrameNumber(atoi(input->value()));
	win->updateGUI();
}






