/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef DCOLLISION
#define DCOLLISION

#include "defs.h"
#include "vector.h"
class DSystem;

class DLLENTRY DCollision
{
	public:
		DCollision(int num);
		~DCollision();

		void setID(int id);
		int getID();

		int getNumPoints();
		void setNumPoints(int num);
		double* getPoint(int num);
		void setPoint(int num, Vector point);

		double* getPointCurPosition(int num);
		void setPointCurPosition(int num, Vector point);

		void getPointPrevPosition(int num, Vector point);
		void setPointPrevPosition(int num, Vector point);
		double getPointPrevTime(int num);
		void setPointPrevTime(int num, double time);
		bool isPointInCollision(int num);
		void setPointInCollision(int num, bool val);
		void setAllPointsCollision(bool val);

		void reset(int num);
		void resetAll();

		void setSystem(DSystem* sys);
		DSystem* getSystem();

	protected:
		int id;
		Vector* points;  //< local Link coordinates 
		Vector* prevPoints; //< global coordinates
		Vector* curPoints; //< global coordinates
		double* prevTimes;
		int numPoints;
		bool* inCollision;
		DSystem* system;

};


class DLLENTRY DSphereCollision : public DCollision
{
	public:
		DSphereCollision(int num);
		~DSphereCollision();

		void setNumPoints(int num);

		double getRadius(int num);
		void setRadius(int num, double val);	

	private:
		double* radii;
};

#endif

