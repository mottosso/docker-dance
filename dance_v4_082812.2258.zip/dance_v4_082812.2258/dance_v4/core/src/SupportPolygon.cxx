/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include <cstdio>
#include "opengl.h"
#include "dance.h"
#include "myMath.h"
#include "convexHull.h"
#include "SupportPolygon.h"

#include <cassert>
#include <cfloat>

SupportPolygon::SupportPolygon()
{
    nvertex = 0 ;
	contactPointCount = 0;
    nl = nr = 0	;
    for( int i = 0 ; i < MAX_NUM_PTS ; i++ )
    {
        	zeroVector(lVertices[i]) ;
		zeroVector(wVertices[i]) ;
		zeroVector(spVertices[i]);
		index[i] = 0;
    }
}

void 
SupportPolygon::output(int mode)
{

    int	light =	0 ;

    if(	nvertex	== 0 ) return ;

    if (glIsEnabled(GL_LIGHTING) == GL_TRUE )
    {
		glDisable(GL_LIGHTING) ;
		light =	1 ;
    }
	double height = 2.0;

    // DRAW the	polygon as lines cause it may not be planar.
    //if( mode & LDISPLAY_WIRE)
    //	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)  ;
    //else
    //	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL) ;

    glLineWidth(4.5) ;
    glPointSize(4.5) ;
	glEnable( GL_POINT_SMOOTH );
	glEnable( GL_LINE_SMOOTH );
    glColor4f(0.1f, 0.1f, 0.6f, 1.0f) ;
    glBegin(GL_LINE_LOOP) ;

	Vector drawPoint;
	if( nvertex > 1 )
	{
    for( int i = 0 ; i < nvertex ; i++ )
    {
			drawPoint[0] = spVertices[i][0];
			drawPoint[1] = height;  // draw overhead
			drawPoint[2] = spVertices[i][2];
			glVertex3dv( drawPoint );
		}
	}
	glEnd();

	glBegin( GL_LINE_LOOP );
	if( nvertex > 1 )
	{
		for( int i = 0 ; i < nvertex ; i++ )
		{
			glVertex3dv( spVertices[i] ) ;  // draw on ground
		}
	}
	glEnd() ;

	// Draw all contact points
	glColor4f( 0.6f, 0.1f, 0.1f, 1.0f );
	glBegin( GL_POINTS );
	{
		for( int i = 0; i < contactPointCount; ++i )
		{
			VecCopy( drawPoint, wVertices[i] );
			drawPoint[1] += height;
			glVertex3dv( drawPoint );
		}
	}
	glEnd();

	glColor3f( 0, 0, 0 );
	Vector gc;
	VecCopy( gc, myGeometricCenter );
	gc[1] = height;
	glBegin( GL_POINTS );
	{
		glVertex3dv( gc );
    }
    glEnd() ;

    glLineWidth(1.0) ;
    glPointSize(1.0) ;

    // restore lighting	if needed
    if(	light == 1 )
	{
		glEnable(GL_LIGHTING) ;
	}
}

// PROC:   compute
// DOES:   given that all the fields have already been filled
//	   properly it computes	the support polygon
void SupportPolygon::compute(void)
{
    int	i ;

//     VecCopy(spVertices[0], wVertices[1]) ;
//     VecCopy(spVertices[1], wVertices[0]) ;
//     VecCopy(spVertices[2], wVertices[2]) ;
//     VecCopy(spVertices[3], wVertices[3]) ;

//     VecCopy(spVertices[4], wVertices[6]) ;
//     VecCopy(spVertices[5], wVertices[7]) ;
//     VecCopy(spVertices[6], wVertices[5]) ;
//     VecCopy(spVertices[7], wVertices[4]) ;

//     nvertex = 8 ;


    // compute the convex hull of the given points
    VertexStruct v[MAX_NUM_PTS]	;
    VertexStruct cv[MAX_NUM_PTS] ;

    for( i = 0 ; i < MAX_NUM_PTS /*8*/ ; i++ )
    {
		v[i].x1	= wVertices[i][0] ;
		v[i].x2	= wVertices[i][2] ;
		v[i].index = i ;
    }

    convexHull( contactPointCount, v /* all verts */, &nvertex, cv /* convex hull */) ;
	// nvertex now holds the number of points in the convex hull, contained in cv
	int lastGood = -1; //< workaround for bug in convexHull
    for( i = 0 ; i < nvertex ; i++ )
    {
		// looks like convexHull() above can supply faulty indexes
		int idx = cv[i].index;
		if( (idx >= 0) && (idx < MAX_NUM_PTS) )
		{
			VecCopy(spVertices[i], wVertices[idx]) ;
			lastGood = idx;
		}
		else if( lastGood >= 0 )
		{
			VecCopy( spVertices[i], wVertices[lastGood] );
		}
		else
		{
			VecCopy( spVertices[i], myGeometricCenter );
		}
    }
	// now spVertices and nvertex hold the convex hull

	computeGeometricCenter( myGeometricCenter );

    //special case for debugging
//     nvertex = 4 ;
//     VecCopy(spVertices[0], wVertices[3]) ;
//     VecCopy(spVertices[1], wVertices[1]) ;
//     VecCopy(spVertices[2], wVertices[4]) ;
//     VecCopy(spVertices[3], wVertices[6]) ;
}

double *SupportPolygon::computeGeometricCenter(Vector gc)
{
    if( nvertex == 0 )
	return NULL ;
    
    VecCopy(gc, spVertices[0]) ;
    for( int i = 1 ; i < nvertex ; i++ )
	VecAdd(gc, gc, spVertices[i]) ;

    VecScale(gc, 1.0 / (double) nvertex) ;
    // printf("Geometric center: ") ; printVector(gc) ;


    return &gc[0] ;
}
    

// PROC:  intesectLineSeg
// DOES:  calculates the intersection of a line segment and the support polygon.
//        If there is none NULL is returned.
double *SupportPolygon::intersectLineSeg( const Vector point1, const Vector point2, Vector intersect)
{
    Vector v1, v2 ;
  
    Vector p1, p2 ;
    VecCopy(p1, point1) ;
    VecCopy(p2, point2) ;
  
    //printf("============ %d =================\n", nvertex) ;
    for( int i = 0 ; i < nvertex ; i++ )
    {
		int next  ;
		if( i == (nvertex - 1) ) next = 0 ;
		else next = i+1 ;
		VecCopy(v1, spVertices[i]) ;
		VecCopy(v2, spVertices[next]) ;
		v1[1] = v2[1] = 0 ;
		p1[1] = p2[1] = 0 ;
 		//printf("---------------\n") ;
 		//printVector(v1) ;
 		//printVector(v2) ;
 		//printVector(p1) ;
 		//printVector(p2) ;
    	if( lineIntersection(v1, v2, p1, p2, intersect, 0) != NULL ) 
		{
			return &intersect[0] ;
		}
    }

    return NULL ;
}


/// Sets outNearestPointOnSP to the nearest point on the support polygon from argPoint,
/// and returns the distance from the nearest point to argPoint.  The sign of the return
/// is positive if the argPoint is inside the SupportPolygon, otherwise negative if outside.
double SupportPolygon::nearestPoint( Vector outNearestPointOnSP, const Vector argPoint )
{
	Vector v1, v2 ;

	// myGeometricCenter -> argPoint vs all spVertex's

	bool argHavePoint = false;
	computeGeometricCenter(myGeometricCenter);
	Vector p1, p2 ;
	VecCopy(p2, myGeometricCenter );
	p2[1] = 0.0;
	VecCopy(p1, argPoint );
	p1[1] = 0.0;

	// Default value of nearest, right on the center
	VecCopy( outNearestPointOnSP, myGeometricCenter );

//	Vector intersect;
	double bestDist = DBL_MAX;
	int bestIdx = -1;
	for( int i = 0 ; i < nvertex ; i++ )
	{
		int next = ( i + 1 ) % nvertex;
		zeroVector( nearCMPts[i] );
		VecCopy(v1, spVertices[i]) ;
		VecCopy(v2, spVertices[next]) ;
		v1[1] = v2[1] = 0.0 ; // ground

		if( 1 == lineIntersection2D( nearCMPts[i], p1, p2, false, v1, v2, true ) )
		{
			double dist = VecDist( nearCMPts[i], argPoint );
			if( dist < bestDist )
			{
				bestDist = dist;
				bestIdx = i;
				argHavePoint = true;
			}
			if( dist < 0 || bestDist < 0 )
			{
				danceInterp::OutputMessage( "This should never be!" );
			}
		}
	}

	if( argHavePoint )
	{
		VecCopy( outNearestPointOnSP, nearCMPts[bestIdx] );
		// if (center to SP) < (center to argPoint)
		if( VecDist( outNearestPointOnSP, p2 ) < VecDist( p1, p2 ) )
		{
			// distance is negative if outside the support polygon
			bestDist *= -1.0;
		}
	}
	else
	{
		bestDist = -DBL_MAX;
	}
	return bestDist;
}
