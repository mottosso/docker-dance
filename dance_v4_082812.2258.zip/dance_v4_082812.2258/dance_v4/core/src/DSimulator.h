/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef DSimulator_h
#define DSimulator_h

#include "defs.h"
#include "vector.h"
#include "PlugIn.h"
#include "DObjectRefList.h"
#include "DSystem.h"
#include "matrix3x3.h"
#include <vector>
#include <cstring>

#define WORLDFRAME -1


class DLLENTRY DSimulatorEvent {
public:
	DSimulatorEvent(double time, char *str) { SetTime(time);  m_script = str ;} ;
	double GetTime(void) { return m_time;} ;
	void SetTime(double t) {m_time = t;} ;
	char *GetScript(void) { return (char *) m_script.c_str();} ;
	void Execute(double time)  ;
private:
	std::string m_script ;
	double m_time ;
} ;


/// This is the DSimulator class that serves as the base class API for simulators
/// @author Victor Ng-Thow-Hing
///  @author Petros Faloutsos
///  @version $Id: DSimulator.h,v 1.25 2008/06/07 01:00:12 vector Exp $
/// @see PlugIn
 
class DLLENTRY DSimulator: public PlugIn {
public:
    DSimulator() ;
    virtual ~DSimulator()  ;

	void setActive(bool val);
	bool isActive();

	virtual void addSystem(DSystem *sys);
	virtual void removeSystem(DSystem *sys);
	int getNumSystems();
	DSystem* getSystem(int index); 

	virtual void getStateFromSystem();
	virtual void saveSystemState(double time);
	
	// Initialization functions
    virtual void SetTime(double currentTime);
    virtual double GetTime(); 

    virtual int Start(double time);
	virtual int Step(DSystem *sys, double destinationTime); 
    virtual int Stop();

	void StepBase(double destinationTime);
	int StartBase(double time);  
    int StopBase();
 
    // State functions
    virtual int getStateSize() { NotImpl("GetStateSize") ; return 0 ; } ;
    // returns -1 on error else non zero
    virtual int SetState(int index, double value) { NotImpl("SetState") ; return 0 ; } ;  
    virtual int SetState(int startIndex, int size, double *q) 
                { NotImpl("SetState") ; return 0 ;} ;
    virtual int SetStateFromObjectState(DSystem *sys, bool setVelocities = true, bool useCurrent = false) { return 0; } ;
    virtual int SetObjectStateFromState(DSystem *sys, bool setVelocities = true) { return 0; } ;
    virtual double GetState(int index) { NotImpl("GetState") ; return MINFLOAT ; } ;
    // fast access, returns the pointer
    virtual double *GetState() { NotImpl("GetState") ; return NULL ; } ;
    virtual double *GetState(int startIndex, int size, double *q)  // q must be allocated
                   { NotImpl("GetState") ; return NULL ; } ;       // by the calller
    virtual int GetVelSize() { NotImpl("GetVelSize") ; return 0 ; } ;
    // returns -1 on error else non zero
    virtual int SetVel(int index, double value) { NotImpl("SetVel") ; return 0 ; } ;   
  
    virtual int SetVel(int startIndex, int size, double *q) { NotImpl("SetVel") ; return 0 ; } ;
    virtual double GetVel(int index) { NotImpl("GetVelA") ; return MINFLOAT ; } ; 
    // fast access, returns the pointer
    virtual double *GetVel() { NotImpl("GetVelB") ; return NULL ; } ;
    // q must be allocated by the calller
    virtual double *GetVel(int startIndex, int size, double *q) 
                   { NotImpl("GetVelC") ; return NULL ; } ;
	virtual void GetAngVel(int group, double* vel)
					{ NotImpl("GetAngVel") ; } ; 

    virtual double GetAcc(int index) { NotImpl("GetAccA") ; return MINFLOAT ; } ;
    // fast access, returns the pointer
    virtual double *GetAcc() { NotImpl("GetAccB") ; return NULL ; } ;	
    virtual void GetAngAcc(int group, double *acc) {
      NotImpl("GetAngAcc"); }

    // q must be allocated by the calller
    virtual double *GetAcc(int startIndex, int size, double *q) 
                   { NotImpl("GetAcc") ; return NULL ; } ; 
    virtual int GetIndex(int group, int subgroup) { NotImpl("GetIndex") ; return 0; };
    virtual int GetIndex(int argc, char **argv) { NotImpl("GetIndex") ; return 0; } ; // generic
    
   // Force functions
  
    virtual void FieldForce(double *force) {NotImpl("FieldForce") ; } ;
    virtual void FieldForce(double *force, double *dampConst) { 
      NotImpl("FieldForceDamping");}

    // force vector and point relative to the given part of the object
    virtual void PointForce(int group, double *point, double *force) 
                 { NotImpl("PointForceA") ; };
  // point and force in world coordinates
    virtual void PointForce(DSystem *sys, double *pointWorldCoord, double *force){ NotImpl("PointForceB") ;} ;
  // the most general form of point force
    virtual void PointForce(int argc, char *argv[]){ NotImpl("PointForceC") ;} ;  
    // point force jacobian for df/dv 
    virtual void PFJ_dv(int pointIndex, Matrix3x3 &J) {}
    // point force jacobian for df/dx
    virtual void PFJ_dx(int pointIndex, Matrix3x3 &J) {}

    virtual void BodyTorque(int group, double *torque) { NotImpl("BodyTorque") ; } ;
    virtual void GeneralizedForce(int coord, double force) 
            { NotImpl("GeneralizedForce(int coord, double force") ; } ;
    virtual void GeneralizedForce(int *index, double *force, int size) 
            { NotImpl("GeneralizedForce(int *index, double *force, int size)") ; };
    virtual void GeneralizedForce(double *Q) { NotImpl("GeneralizedForce(double *Q)") ; } ;
    virtual void GeneralizedForce(int group, int subgroup, double force) 
            { NotImpl("GeneralizedForce") ;};
	
	// drive functions
	virtual void ApplyVelocityDrive( int group, Vector argTargetAngularVelocity )
	{
		//NotImpl("ApplyVelocityDrive");
	}
	virtual void ApplyPositionDrive( int group, Quaternion argTargetOrientation )
	{
		NotImpl("ApplyPositionDrive");
	}
	virtual void SetupPositionDrive( int group, double argSpring, double argDamping, double argMaxForce )
	{
		NotImpl("SetupPositionDrive");
	}
	virtual void SetupVelocityDrive( int group, Vector argSpring, Vector argDamping, Vector argMaxForce )
	{
		//NotImpl("SetupVelocityDrive");
	}

    // transformation utilities
   virtual void GetVel(DSystem *sys, double *localPoint, double *vel) 
         { NotImpl("GetVelD") ; return ; } ;
   virtual void GetVel(DSystem *sys, double *localPoint, int index, double *vel) 
         { NotImpl("GetVelE") ; return ; } ;
    virtual void GetVel(int group, double *point, double *vel) 
                 { NotImpl("GetVelF") ; } ;
    virtual void GetAcc(int group, double *point, double *acc)
                 { NotImpl("GetAccA")  ; } ;
    virtual void GetAcc(DSystem *sys, double *localPoint, double *acc) 
          { NotImpl("GetAccB") ; } ;

    virtual int SetPosition(int group, double *position)							{ NotImpl("SetPosition") ; return 0 ; } ;
    virtual int SetOrientation(int group, double orientation[3][3])						{ NotImpl("SetOrientation") ; return 0 ; } ;

    virtual int GetPosition(DSystem *sys, double *localPoint, double *position)		{ NotImpl("GetPositionA") ; return 0 ; } ;
    virtual int GetPosition(int group, double *localPoint, double *position)		{ NotImpl("GetPositionB") ; return 0 ; } ;
    virtual int GetLocalPosition(DSystem *sys, double *localPoint, double *position){ NotImpl("GetPositionA") ; return 0 ; } ;
    virtual int GetLocalPosition(int group, double *localPoint, double *position)	{ NotImpl("GetPositionB") ; return 0 ; } ;
    virtual int GetOrientation(DSystem *sourceSystem, double *sourceVec,  DSystem *targetSystem, double *targetVec) 
																					{ NotImpl("GetOrientationA") ; return 0;};
    virtual int GetOrientation(int sourceGroup, double *localVec, int targetGroup, double *rotated)
																					{ NotImpl("GetOrientationB") ; return 0 ; } ;
    virtual int Transform(int argc, char **argv)									{ NotImpl("Tranform") ; return 0; } ;

	virtual void getGlobalAxes( int group, Vector outAxes[3] )						{ NotImpl("getGlobalAxes"); }
	virtual void getComputedLinkAxes( int group, Vector outAxes[] )					{ NotImpl("getComputedLinkAxes"); }
    virtual int commandPlugIn(int argc, char **argv);
  
	virtual void saveState() { return; };
	virtual void loadState(double time) { return; };

	virtual void RollbackState() { return; };
	virtual void CheckpointState() { return; };

	void setKinematicControl(bool val);
	bool isKinematicControl();

	void setTimeStep(double val);
	double getTimeStep();
	void setUseMainTimeStep(bool val);
	bool isUseMainTimeStep();

	virtual void resetPhysicalProperties(DSystem* system);

	void onDependencyRemoval(DObject* obj);

	void save(int mode, std::ofstream& file);

	virtual void checkAttachments();

	static void getEulerDerivativesFromAngularVelocity(int order, double* omega, double* eulerAngles, double* eulerDerivs);
	static void getAngularVelocityFromEulerDerivatives(int order, double* eulerDerivs, double* eulerAngles, double* omega);

	/// Call to add the applied torques to running totals
	virtual void accumulateTorques( void );

	/// Provides a single joint's applied torque
	virtual void acquireTorque( Vector outTorque, int argGroupId /*Joint*/ );

	/// Allows retrieval of the torques applied since last zeroTorques()
	virtual void acquireTorques( std::vector<double>& outTorques /* treated as state space */ );

	/// Reset all the accumulated torques to zero.  Call once per controller update.
	virtual void zeroTorques( void );

	protected:
		int Command(int argc, char **argv) ;
		void ApplyActuatorForces(DSystem *sys, double time, double dt, double *state, 
					double *dstate) ;

		void NotImpl(const char *funcName) ;
		DObjectRefList m_systems;

		/** if true the base code the function xxxxBase is ignored and corresponding
			virtual functions are called immediately */
		int m_ignoreBaseFlag ;
		int m_initSystemsFlag ;
		int m_initActuatorsFlag ;
		double m_timeStep;
		bool m_useMainTimeStep;

private:
    bool isKinematic;
	bool active;
	double currentTime;

	static void simstep(DObject* data, double time);
	static void simstart(DObject* data, double time);
	static void simstop(DObject* data, double time);
	static void recordstate(DObject* data, double time);

	std::vector <DSimulatorEvent *> m_simEvents ;
	void AddEvent(double t, char *s) ;
	void ExecuteEvents(double t) ;
	void RemoveEvent(char *s) ;

} ;
    
#endif
