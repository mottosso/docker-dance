#include "DNode.h"

DNode::DNode()
{
	m_dirty = true;
}

DNode::~DNode()
{
}

void DNode::addInput(DInput* input, int index)
{
	m_inputs.push_back(input);
}

DInput* DNode::getInput(int index)
{
	return m_inputs[index];
}

DInput* DNode::getInput(std::string name)
{
/*
	for (int x = 0; x < m_inputs.size(); x++)
		if (m_inputs[x]->getName() == name)
			return m_inputs[x];
*/
	return NULL;
}

std::vector<DInput*>& DNode::getInputs()
{
	return m_inputs;
}

void DNode::addOutput(DOutput* output, int index)
{
	m_outputs.push_back(output);
}

DOutput* DNode::getOutput(int index)
{
	return m_outputs[index];
}

DOutput* DNode::getOutput(std::string name)
{
/*	for (int x = 0; x < m_outputs.size(); x++)
		if (m_outputs[x]->getName() == name)
			return m_outputs[x];
*/
	return NULL;
}


std::vector<DOutput*>& DNode::getOutputs()
{
	return m_outputs;
}

void DNode::setDirty(bool val)
{
	m_dirty = val;

	// set all the children dirty
	for (int i = 0; i < m_outputs.size(); i++)
	{
		DInput* input = m_outputs[i]->getInput();
		if (input)
		{
			DNode* node = input->getNode();
			node->setDirty(true);
		}
	}
}

bool DNode::isDirty()
{
	return m_dirty;
}

void DNode::evaluate()
{
	std::vector<DInput*>& inputs = getInputs();
	for (int i = 0; i < inputs.size(); i++)
	{
		DOutput* output = inputs[i]->getOutput();
		if (output)
		{
			DNode* node = output->getNode();
			if (node->isDirty())
				node->evaluate();
		}
	}
	setDirty(false);
}

DPipe::DPipe(std::string name)
{
	m_name = name;
}

std::string DPipe::getPipeName()
{
	return m_name;
}


void DPipe::setNode(DNode* node)
{
	m_node = node;
}

DNode* DPipe::getNode()
{
	return m_node;
}

DInput::DInput(std::string name) : DPipe(name)
{
	m_output = NULL;
}

DInput::~DInput()
{
}

void DInput::setOutput(DOutput* output)
{
	m_output = output;
}

DOutput* DInput::getOutput()
{
	return m_output;
}

DOutput::DOutput(std::string name) : DPipe(name)
{
	m_name = name;
}

DOutput::~DOutput()
{
}

void DOutput::setInput(DInput* input)
{
	m_input = input;
}

DInput* DOutput::getInput()
{
	return m_input;
}

DBoolInput::DBoolInput(std::string name) : DInput(name)
{
	m_nodeValue = false;
}

DBoolInput::~DBoolInput()
{
}

bool DBoolInput::getNodeValue()
{
	return m_nodeValue;
}

void DBoolInput::setNodeValue(bool val)
{
	m_nodeValue = val;
}

DBoolOutput::DBoolOutput(std::string name) : DOutput(name)
{
	m_nodeValue = false;
}

DBoolOutput::~DBoolOutput()
{
}

bool DBoolOutput::getNodeValue()
{
	DNode* node = getNode();

	if (node->isDirty())
	{
		node->evaluate();
	}

	return m_nodeValue;
}

void DBoolOutput::setNodeValue(bool val)
{
	m_nodeValue = val;
}

DBoolNode::DBoolNode() : DNode()
{
	m_in = new DBoolInput("in");
	m_out = new DBoolOutput("out");
	addInput(m_in, 0);
	addOutput(m_out, 0);
}

DBoolNode::~DBoolNode()
{
	delete m_in;
	delete m_out;
}

void DBoolNode::evaluate()
{
	DNode::evaluate();

	m_out->setNodeValue(m_in->getNodeValue());
}

DOrNode::DOrNode() : DNode()
{
	m_in1 = new DBoolInput("in1");
	m_in2 = new DBoolInput("in2");
	m_out = new DBoolOutput("out");
	addInput(m_in1, 0);
	addInput(m_in2, 1);
	addOutput(m_out, 0);
}

DOrNode::~DOrNode()
{
	delete m_in1;
	delete m_in2;
	delete m_out;
}

void DOrNode::evaluate()
{
	DNode::evaluate();

	if (m_in1 && m_in2)
		m_out->setNodeValue(m_in1->getNodeValue() || m_in2->getNodeValue());
	else if (m_in1)
		m_out->setNodeValue(m_in1->getNodeValue());
	else
		m_out->setNodeValue(m_in2->getNodeValue());
}


