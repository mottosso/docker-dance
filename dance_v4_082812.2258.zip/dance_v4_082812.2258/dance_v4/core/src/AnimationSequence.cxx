/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "defs.h"
#include <cstdio>
#include <cstdlib>
#include <math.h>

#include "danceInterp.h"
#include "KeyFrame.h"
#include "AnimationSequence.h"

#ifndef EPS
#define EPS 0.00001
#endif

static void parseComment(FILE *fp)
{
        // Read comment until newline.
        while (fgetc(fp) != (int)'\n');
        return;
}

static double EuclideanDist(double *v1, double *v2, int n, int *exclude, int m)
{
	double res = 0;
	for( int i = 0 ; i < n ; i++)
	{
		
		bool ignore = false ;
		if( m != 0 ) 
		{
			for( int j = 0 ; j < m ; j++ )
			{
				if( i == exclude[j] ) ignore = true;
			}
		}
		if( !ignore )
		{
			double dv = v1[i]-v2[i] ;
			res  +=  dv*dv ;
		}
	}
	return sqrt(res) ;
}

AnimationSequence::AnimationSequence()
{
    m_numKeyFrames = 0;
    m_first = NULL;
    m_last = NULL;
    m_numLegends = 0;
    m_legends = NULL;
}

AnimationSequence::~AnimationSequence()
{
    clear();
}

void AnimationSequence::clear()
{
    deleteKeyFrames();
    deleteLegend();
}

int AnimationSequence::getNumKeyFrames()
{
	return m_numKeyFrames;
}

void AnimationSequence::insertKeyFrame(KeyFrame *kf)
{
    if (getNumKeyFrames() == 0) 
    {
		m_first = kf;
		m_last = kf;
		m_numKeyFrames++;
    }
	else if (kf->getTime() > m_last->getTime()) 
    {
		// insert at the end
		m_last->setNext(kf);
		kf->setPrevious(m_last);
		m_last = kf;
		m_numKeyFrames++;
    }
    else if (kf->getTime() < m_first->getTime())
    {
		// insert in the beginning
		m_first->setPrevious(kf);
		kf->setNext(m_first);
		m_first = kf;
		m_numKeyFrames++;
    }
    else if (fabs(kf->getTime() - m_last->getTime()) < EPS)
    {
		// replace the last one
		replaceKeyFrame(m_last, kf);
    }
    else if (fabs(kf->getTime() - m_first->getTime()) < EPS)
    {
		// replace the first one
		replaceKeyFrame(m_first, kf);
    }
    else
    {
		KeyFrame *temp;
		for (temp = m_first; ( (temp != NULL) &&	(temp->getTime() < kf->getTime())); temp = temp->getNext());
		// put it between kf->previous and kf but first
		// check to see if it should override ont of the two

		if (fabs(temp->getTime() - temp->getPrevious()->getTime()) < EPS)
			replaceKeyFrame(temp->getPrevious(), kf);
		else if (fabs(kf->getTime() - temp->getTime()) < EPS)
			replaceKeyFrame(temp, kf);
		else
		{
			// put it between kf->getPrevious() and kf
			kf->setPrevious(temp->getPrevious());
			kf->setNext(temp);
			(temp->getPrevious())->setNext(kf);
			temp->setPrevious(kf);
			m_numKeyFrames++;
		}
    }

}

int AnimationSequence::save(char *fname)
{
    FILE *fp;
    if ((fp = fopen(fname,"w")) == NULL)
    {
		danceInterp::OutputMessage("Cannot open file %s\n", fname);
		return -1;
    }
	int ret = this->save(fp);
    fclose(fp);

    return ret;
}

int AnimationSequence::save(FILE* fp)
{
	fprintf(fp, "AnimationSequence {\n");
    fprintf(fp, "\tlegend {\n");
    for (int i = 0; i < m_numLegends; i++)
		fprintf(fp, "\t\t%s %d\n", m_legends[i].name, m_legends[i].index);
    fprintf(fp, "\t}\n");
    fprintf(fp, "\tkeyFrames {\n");
    for (KeyFrame *kf = m_first; kf != NULL; kf = kf->getNext())
		kf->save(fp);
    fprintf(fp, "\t}\n");
    fprintf(fp, "}\n");

    return m_numKeyFrames;
}

int AnimationSequence::load(char *fname, int N1, int N2)
{
    FILE *fp;
    if ((fp = fopen(fname,"r")) == NULL)
    {
		danceInterp::OutputMessage("Cannot open file %s\n", fname);
		return -1;
    }
    int res = load(fp);
    fclose(fp);

	
    return res;
}

int AnimationSequence::load(FILE *fp)
{
    char token[MAX_LINE];
    int result;

    // clear anything that used to be there
    clear();
    do {
		result = fscanf(fp,"%s", token);
		if (result > 0)
		{
			if (strcmp(token, "#") == 0)
				parseComment(fp);
			else if (strcmp(token, "keyFrames") == 0)
				readKeyFrames(fp);
			else if (strcmp(token, "legend") == 0) 
				readLegend(fp);
			else if (strcmp(token, "}") == 0)
			{
				danceInterp::OutputMessage("Animation sequence successfully read\n");
				return m_numKeyFrames;
			}
		}
	
    } while (!feof(fp));

    return 0;
}
		
int AnimationSequence::readKeyFrames(FILE *fp)
{
    int result;
    char token[MAX_LINE];

    if (m_first != NULL)
    {
		deleteKeyFrames();
    }

    // get the opening bracket
    int scanResult = fscanf(fp, "%s", token);
    if (scanResult == 0)
    {
		danceInterp::OutputMessage("ERROR: ReadKeyFrames: no data\n");
		return 0;
    }
    if (!(strcmp(token ,"{") == 0))
    {
		danceInterp::OutputMessage("ERROR: ReadKeyFrames: missing '{'\n");
		return 0;
    }
    
    do {
	result = fscanf(fp, "%s", token);
	if (result > 0)
	{
	    if (strcmp(token, "#") == 0)
	    {
			parseComment(fp);
	    }
	    else if (strcmp(token, "keyFrame") == 0)
	    {
			KeyFrame *kf = new KeyFrame();
			if (kf == NULL)
			{
				danceInterp::OutputMessage("ERROR: ReadKeyFrames: cannot allocate memory.\n");
				return 0;
			}
			
			if (!(kf->load(fp) > 0))
			{
				danceInterp::OutputMessage("Error reading key frame number %d\n", m_numKeyFrames);
				danceInterp::OutputMessage("Animation sequence partially read\n");
				delete kf;

				return m_numKeyFrames;
			}
			
			insertKeyFrame(kf);
	    }
	    else if (strcmp(token, "}") == 0)
	    {
		danceInterp::OutputMessage("Read %d key frames.\n", m_numKeyFrames);
		return m_numKeyFrames;
	    }
	}
	else
	{
	    danceInterp::OutputMessage("ERROR: ReadKeyFrames: Unexpected end of file!\n");
	    deleteKeyFrames();
	    return m_numKeyFrames;
	}
    } while( !feof(fp));
    
    danceInterp::OutputMessage("ERROR: unexpectd end of file.\n");
    deleteKeyFrames();
    return  m_numKeyFrames;
}

void AnimationSequence::deleteKeyFrames()
{
    KeyFrame *prev;

    if (m_first == NULL)
		return;

    for (KeyFrame *k = m_first; k != NULL; k = k->getNext())
    {
		if (k->getPrevious() != NULL)
			delete k->getPrevious();

		prev = k;
    }

    if (prev != NULL)
		delete prev;

    m_first = NULL;
    m_last = NULL;
    m_numKeyFrames = 0;
}

void AnimationSequence::deleteKeyFramesAfter(double time)
{
    if (m_last == NULL)
		return;

	KeyFrame* k = m_last;

	while (k != NULL && k->getTime() > time)
	{
		KeyFrame* temp = k;
		if (k->getPrevious() != NULL)
		{
			k->getPrevious()->setNext(NULL);
			k = k->getPrevious();
		}
		m_last = k;

		delete temp;	

	    m_numKeyFrames--;
	}
}

void AnimationSequence::deleteKeyFramesBefore(double time)
{
    if (m_last == NULL)
		return;

	KeyFrame* k = m_first;
	while (k != NULL && k->getTime() < time)
	{
		KeyFrame* temp = k;
		if (k->getNext() != NULL)
		{
			k->getNext()->setPrevious(NULL);
			k = k->getNext();
		}
		m_first = k;

		delete temp;	

	    m_numKeyFrames--;
	}

	this->resetTime();
}

int AnimationSequence::readLegend(FILE *fp)
{

    int done = FALSE, expectingIndex = FALSE;
    int result;
    char token[MAX_LINE];
    
    int index[MAX_NUM_PARAM];
    char legend[MAX_NUM_PARAM][MAX_LINE];

    // clear previous legends
    if (m_legends != NULL)
		deleteLegend();

    
    // get the opening bracket
    int scanResult = fscanf(fp, "%s", token);
    if (scanResult == 0)
    {
	danceInterp::OutputMessage("ERROR: ReadLegend: no data{'\n");
	return 0;
    }
    if (!(strcmp(token ,"{") == 0))
    {
	danceInterp::OutputMessage("ERROR: ReadLegend: missing '{'\n");
	return 0;
    }
    do {
	result = fscanf(fp, "%s", token);
	if (result > 0)
	{
	    if (strcmp(token, "#") == 0)
	    {
		parseComment(fp);
	    }
	    else if (strcmp(token, "}") == 0)
	    {
		done = TRUE;
	    }
	    else
	    {
		if (expectingIndex == FALSE)
		{
		    strcpy(legend[m_numLegends], token);
		    expectingIndex = TRUE;
		}
		else
		{
		    index[m_numLegends] = atoi(token);
		    m_numLegends++;
		    expectingIndex = FALSE;
		}
	    }
	}
    } while(( !feof(fp)) && (done == FALSE));

    if (done == FALSE)
    {
		danceInterp::OutputMessage("ERROR: ReadLegend: Unexpected end of file.\n");
		deleteLegend();
    }

    if (m_numLegends > 0)
    {
		m_legends = new Legend [m_numLegends];
		if (m_legends == NULL)
		{
			danceInterp::OutputMessage("ERROR: no more memory!\n");
			m_numLegends = 0;
		}
		for (int i = 0; i < m_numLegends; i++)
		{
			strcpy(m_legends[i].name, legend[i]);
			m_legends[i].index = index[i];
		}
		danceInterp::OutputMessage("Read %d legends.\n", m_numLegends);
    }

    return m_numLegends;

}
	    
void AnimationSequence::deleteLegend()
{
    if (m_legends != NULL)
    {
	delete [] m_legends;
	m_legends = NULL;
    }
    m_numLegends = 0;
}


void AnimationSequence::deleteKeyFrame(int index)
{
    int count = 0;

    for (KeyFrame *kf = m_first; kf != NULL; kf = kf->getNext())
	if (count == index)
	{
	    deleteKeyFrame(kf);
	    return;
	}
}

void AnimationSequence::deleteKeyFrame(KeyFrame *kfdel)
{
    for (KeyFrame *kf = m_first; kf != NULL; kf = kf->getNext())
    {
	if (kf == kfdel)
	{
	    if (kf->getPrevious() != NULL)
			(kf->getPrevious())->setNext(kf->getNext());
	    if (kf->getNext() != NULL)
			(kf->getNext())->setPrevious(kf->getPrevious());

	    if (kf == m_first)
	    {
		if (m_last == m_first)
		{
		    // all null
		    m_last = NULL;
		    m_first = NULL;
		}
		else
		{
		    // delete the head
		    (m_first->getNext())->setPrevious(NULL);
		    m_first = m_first->getNext();
		}
	    }
	    else if (kf == m_last)
	    {
		(m_last->getPrevious())->setNext(NULL);
		m_last = m_last->getPrevious();
	    }
	    delete kf;
	    m_numKeyFrames--;
	    return;
	}
    }
}

// replaces the kf_old with kf_new in the sequence and deletes kf_old
void AnimationSequence::replaceKeyFrame(KeyFrame *kf_old, KeyFrame *kf_new)
{
    if (kf_old == NULL)
		return;

    deleteKeyFrame(kf_old);
    insertKeyFrame(kf_new);
}

double AnimationSequence::getStartTime()
{
    if (m_first != NULL)
		return m_first->getTime();
    else
		return -1;
}


double AnimationSequence::getEndTime()
{
    if (m_last != NULL)
		return m_last->getTime();
    else
		return -1;
}


/*
int AnimationSequence::getKeyFrame(double time, double *params, int interpolation)
{
    // find the key frames and interpolate if needed
    if (GetSize() == 0) 
    {
	return 0;
    }
    else if ((time > m_last->m_time) && 
	     (time < m_first->m_time))
    {
	return 0;
    }
    else if (fabs(time - m_last->m_time) < EPS)
    {
	// return the last one
	memcpy(params, m_last->m_param, 
	       sizeof(double)*m_last->m_nparam);
    }
    else if (fabs(time - m_first->m_time) < EPS)
    {
	// return the first one
	memcpy(params, m_first->m_param, 
	       sizeof(double)*m_first->m_nparam);
    }
    else
    {
	KeyFrame *kf;
	for( kf = m_first; ( (kf != NULL) && 
				      (kf->m_time < time)); kf = kf->getNext());
	// somewhere between kf->previous and kf but first
	// check to see if it should override one of the two
	if (fabs(time - kf->getPrevious()->m_time) < EPS)
	    memcpy(params, kf->getPrevious()->m_param,
		   sizeof(double)*kf->getPrevious()->m_nparam);
	else if (fabs(time - kf->m_time) < EPS)
	    memcpy(params, kf->m_param, sizeof(double)*kf->m_nparam);
	else
	{
	    if (interpolation == TRUE) 
			InterpolateKeyFrames(kf->getPrevious(), kf, time, params);
	    else
			memcpy(params, kf->getPrevious()->m_param,
			 sizeof(double)*kf->getPrevious()->m_nparam);
	}
    }
    return m_first->m_nparam;
}
*/

KeyFrame* AnimationSequence::getKeyFrame(double time)
{
    KeyFrame *kf = 0;
    for (kf = m_first; kf != m_last; kf = kf->getNext())
	{
		if (fabs(time - kf->getTime()) < EPS)
			return kf;//break;
		else if (time > kf->getTime())
		{
			if (kf->getNext() == NULL)
				return kf;
			else if (kf->getNext()->getTime() > time)
				break;
		}
	}
    return kf;
}

KeyFrame* AnimationSequence::getKeyFrameByIndex(int index)
{
	if (index < this->getNumKeyFrames() && index >= 0)
	{
		KeyFrame *kf = 0;
		int counter = 0;
		for (kf = m_first; ; kf = kf->getNext())
		{
			if (index == counter)
				return kf;
			counter++;
			if (kf == m_last)
				return kf;
		}
		return NULL;
	}
	else
	{
		return NULL;
	}
}

KeyFrame* AnimationSequence::getFirstKeyFrame()
{
	return m_first;
}

KeyFrame* AnimationSequence::getLastKeyFrame()
{
	return m_last;
}



/*
void AnimationSequence::InterpolateKeyFrames(KeyFrame *kf1, KeyFrame *kf2, double time,
					     double *paramInt, double *vel)
{
    if ((kf2->m_time - kf1->m_time) <= (double) 0.0)
    {
	danceInterp::OutputMessage("ERROR: interpolation of key frames that are at the same time"
	       " or at the wrong order!\n");
	return;
    }
    double a = (time - kf1->m_time) / (kf2->m_time - kf1->m_time);
	for( int i = 0; i < kf1->getNumParams(); i++)
    {
		// linear interpolation			
		paramInt[i] = kf1->m_param[i]*(1 - a) + a*kf2->m_param[i];
		vel[i] = kf1->m_vel[i]*(1 - a) + a*kf2->m_vel[i];
    }
    return;
}

void AnimationSequence::InterpolateKeyFrames(KeyFrame *kf1, KeyFrame *kf2, double time,
					     double *paramInt)
{
    if ((kf2->m_time - kf1->m_time) <= (double) 0.0)
    {
	danceInterp::OutputMessage("ERROR: interpolation of key frames that are at the same time"
	       " or at the wrong order!\n");
	return;
    }
    double a = (time - kf1->m_time) / (kf2->m_time - kf1->m_time);
    for( int i = 0; i < kf1->getNumParams(); i++)
    {
		// linear interpolation			
		paramInt[i] = kf1->m_param[i]*(1 - a) + a*kf2->m_param[i];
    }
    return;
}
*/

void AnimationSequence::deleteKeyFrame(double time)
{
    KeyFrame *kf = getKeyFrame(time);
    if (kf == NULL) 
    {
		danceInterp::OutputMessage("No key frame at time %lf\n", time);
		return;
    }
    deleteKeyFrame(kf);
}

void AnimationSequence::retimeFrames(int fps)
{
	double frameInc = 1.0 / fps;
	double curTime = 0.0;

	for (KeyFrame* kf = m_first; kf != NULL; kf = kf->getNext())
	{
		kf->setTime(curTime);
		curTime += frameInc;
	}
}

void AnimationSequence::resetTime()
{
	if (m_first == NULL)
		return;

	double offset = m_first->getTime();


	for (KeyFrame* kf = m_first; kf != NULL; kf = kf->getNext())
		kf->setTime(kf->getTime() - offset);
}

void AnimationSequence::offsetFrames( double argOffsetSecs )
{
	for( KeyFrame*  kf = m_first; kf != NULL; kf = kf->getNext())
	{
		kf->setTime( kf->getTime() + argOffsetSecs );
	}
}

void AnimationSequence::offsetFrames( double argStartingTimeSecs, double argOffsetSecs )
{
	for( KeyFrame*  kf = m_first; kf != NULL; kf = kf->getNext())
	{
		if( kf->getTime() >= argStartingTimeSecs )
		{
			kf->setTime( kf->getTime() + argOffsetSecs );
		}
	}
}

void AnimationSequence::copy(AnimationSequence* anim)
{
	this->clear();
	KeyFrame* kf = anim->getKeyFrame(anim->getStartTime());
	while (kf != NULL)
	{
		KeyFrame* kf2 = new KeyFrame(kf);
		this->insertKeyFrame(kf2);
		kf = kf->getNext();
	}
}

// find match: 
int AnimationSequence::FindMatch(int index, int startIndex, int endIndex, 
								 int *channels, int nc, double epsVal, int offsetIndex)
{
	int nf = this->getNumKeyFrames() ;
	if( nf < 1 ) return  -1;
	KeyFrame* kf, *kfsource ;
	kfsource  = this->getKeyFrameByIndex(index) ;
	if( !kfsource ) return -1 ;

	if( endIndex > nf ) endIndex = nf ;
	if( startIndex < 0 ) startIndex = 0 ;

	int np = kfsource->getNumParams() ;
	if( np < 1) return -1 ;

	double *fp = new double[np] ;
	double *p = new double [np] ;
	if( !fp || !p ) return -1 ;
	kfsource->getParams(fp) ;
	for ( int i = startIndex ; i < endIndex  ; i++ )
	{
		kf = this->getKeyFrameByIndex(i) ;
		kf->getParams(p) ;
		double x = fabs(EuclideanDist(fp,p,np,channels,nc)) / (np -nc) ;
		danceInterp::OutputMessage("x = %lf", x) ;
 		if((x  < epsVal) && ( fabs(((double) index - i)) > offsetIndex) )
		{

			delete [] p ;
			delete [] fp ;
			return i ;
		}
	}
	delete [] p ;
	delete [] fp ;
	return -1 ;
}


bool operator==( const AnimationSequence& argLeft, const AnimationSequence& argRight )
{
	bool areSame = ( argLeft.m_numKeyFrames == argRight.m_numKeyFrames );
	areSame = areSame && ( argLeft.m_first == argRight.m_last );
	areSame = areSame && ( argLeft.m_last == argRight.m_last );
	areSame = areSame && ( argLeft.m_legends == argRight.m_legends );
	return areSame;
}
