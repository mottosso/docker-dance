/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "stuff.h"
#include "danceInterp.h"
#include <stdlib.h>
#include <fltk/filename.h>
#include <fltk/string.h>

#if defined(_WIN32) && !defined(__CYGWIN__)
# include <direct.h>
//# define getcwd(a,b) _getdcwd(0,a,b)
#else
# include <unistd.h>
# ifdef __EMX__
#  define getcwd _getcwd2
# endif
#endif

/* Tokenizes the file. The spaces (tabs, etc) are always separators (you do not need to include them in the seps). 
Returns the characters in seps as tokens. Call the first time with my_C_tokenizer(file, NULL), to init state 
Ignores C comments / *  and * /   */

std::string my_C_tokenizer(std::ifstream &file, char *seps) {
	static char c=0;
	char car;
	std::string tmp="";
	int i, n;

	if (seps==NULL) {
		c=0;
		return tmp;
	} else 
		n=strlen(seps);

	if (c!=0) {
		tmp=c;
		c=0;
		return tmp;
	}

	while (!file.eof()) {
		file.get(car);
		// is a comment?
		if (car=='/' && file.peek()=='*') {
			file.get(car);
			// keep on reading until */
			do {
				file.get(car);
				if (file.eof()) return tmp;
			} while (car!='*' || file.peek()!='/');
			file.get(car);
			if (tmp!="") return tmp;
			continue;
		}

		// is a separator?
		for (i=0; i<n; i++) 
			if (car == seps[i]) {
				if (tmp=="") tmp=car;
				else c=car;
				return tmp;
			}

		// is an space
		if (isspace(car))
		{
			if (tmp!="")
				return tmp;
			else 
				continue;
		}

		// it is a regular char
		tmp+=car;
	}
	return tmp;   // Note that in case of an empty file, we return ""
}


/* Tokenizes the file. The spaces (tabs, etc) are always separators (you do not need to include them in the seps). 
Returns the characters in seps as tokens. Call the first time with my_VRML_tokenizer(file, NULL), to init state 
Ignores VRML comment, from # until the end of the line   */

std::string my_VRML_tokenizer(std::ifstream &file, char *seps) {
	static char c=0;
	char car, *p;
	std::string tmp="";

	if (seps==NULL) {
		c=0;
		return tmp;
	} 

	if (c!=0) {
		tmp=c;
		c=0;
		return tmp;
	}

	while (!file.eof()) {
		file.get(car);
		// is a comment?
		if (car=='#') {
			// keep on reading until \n
			do {
				file.get(car);
				if (file.eof()) return tmp;
			} while (car!='\n');
			continue;
		}

		// is a separator?
		p=seps;
		while (*p) {
			if (car == *p) {
				if (tmp=="") tmp=car;
				else c=car;
				return tmp;
			}
			p++;
		}
		// is an space
		if (isspace(car))
		{
			if (tmp!="")
				return tmp;
			else 
				continue;
		}

		// it is a regular char
		tmp+=car;
	}
	return tmp;   // Note that in case of an empty file, we return ""
}


/* Reads a povray color from the file. See Material::read_povray. Although it accept rgbft, only reads rgbt */
int read_povray_color(std::ifstream &file, float *color) {
	char seps[]=",<>";
	std::string tmp;
	int caso;


	tmp=my_C_tokenizer(file, seps);
	if (tmp=="rgb") caso=1;
	else if (tmp=="rgbt") caso=2;
	else if (tmp=="rgbf") caso=3;
	else if (tmp=="rgbft") caso=4;
	else return -1;

	if (my_C_tokenizer(file, seps)!="<") return -1;

	tmp=my_C_tokenizer(file, seps);
	if (tmp=="") return -1;
	color[0]=(float)atof(tmp.data());
	tmp=my_C_tokenizer(file, seps);
	if (tmp!=",") return -1;
	tmp=my_C_tokenizer(file, seps);
	if (tmp=="") return -1;
	color[1]=(float)atof(tmp.data());
	tmp=my_C_tokenizer(file, seps);
	if (tmp!=",") return -1;
	tmp=my_C_tokenizer(file, seps);
	if (tmp=="") return -1;
	color[2]=(float)atof(tmp.data());

	switch (caso) {
		case 1:
			color[3]=1;
			break;
		case 2:
			tmp=my_C_tokenizer(file, seps);
			if (tmp!=",") return -1;
			tmp=my_C_tokenizer(file, seps);
			if (tmp=="") return -1;
			color[3]=1.0f-(float)atof(tmp.data());
			break;
		case 3:
			tmp=my_C_tokenizer(file, seps);
			if (tmp!=",") return -1;
			tmp=my_C_tokenizer(file, seps);
			if (tmp=="") return -1;
			color[3]=1;
			break;
		case 4:
			tmp=my_C_tokenizer(file, seps);
			if (tmp!=",") return -1;
			tmp=my_C_tokenizer(file, seps);
			if (tmp=="") return -1;
			tmp=my_C_tokenizer(file, seps);
			if (tmp!=",") return -1;
			tmp=my_C_tokenizer(file, seps);
			if (tmp=="") return -1;
			color[3]=1.0f-(float)atof(tmp.data());
			break;
	}

	if (my_C_tokenizer(file, seps)!=">") return -1;
	return 0;

}

// Writes --n-- components of --vector-- in the file. Depending on --mode--:
// mode=VPOVRAY   ->   <v0, v1, v2...vn>
// mode=VSPACES   ->   v0 v1 v2 ... vn
void write_vector(std::ofstream &file, float *vector, int n, int mode) {
	
	int i;

	// prefix
	if (mode==VPOVRAY) file << "<";

	// components
	for (i=0; i<n; i++) {
		file << vector[i];
		
		// separator
		if (i!=n-1) 
			switch (mode) {
				case VPOVRAY:
					file << ", ";
					break;
				case VSPACES:
					file << " ";
					break;
			}
	}

	// suffix
	if (mode==VPOVRAY) file << ">";
}



// Writes --n-- components of --vector-- in the file. Depending on --mode--:
// mode=VPOVRAY   ->   <v0, v1, v2...vn>
// mode=VSPACES   ->   v0 v1 v2 ... vn
void write_vector(std::ofstream &file, double *vector, int n, int mode) {
	
	int i;

	// prefix
	if (mode==VPOVRAY) file << "<";

	// components
	for (i=0; i<n; i++) {
		file << vector[i];
		
		// separator
		if (i!=n-1) 
			switch (mode) {
				case VPOVRAY:
					file << ", ";
					break;
				case VSPACES:
					file << " ";
					break;
			}
	}

	// suffix
	if (mode==VPOVRAY) file << ">";
}


void bwtorgba(unsigned char *b,unsigned char *l,int n)
{
    while(n--) {
	l[0] = *b;
	l[1] = *b;
	l[2] = *b;
	l[3] = 0xff;
	l += 4; b++;
    }
}

void latorgba(unsigned char *b, unsigned char *a,unsigned char *l,int n)
{
    while(n--) {
	l[0] = *b;
	l[1] = *b;
	l[2] = *b;
	l[3] = *a;
	l += 4; b++; a++;
    }
}

void rgbtorgba(unsigned char *r,unsigned char *g,unsigned char *b,unsigned char *l,int n)
{
    while(n--) {
	l[0] = r[0];
	l[1] = g[0];
	l[2] = b[0];
	l[3] = 0xff;
	l += 4; r++; g++; b++;
    }
}

void rgbatorgba(unsigned char *r,unsigned char *g,unsigned char *b,unsigned char *a,unsigned char *l,int n)
{
    while(n--) {
	l[0] = r[0];
	l[1] = g[0];
	l[2] = b[0];
	l[3] = a[0];
        l += 4; r++; g++; b++; a++;
    }
}

void ConvertShort(unsigned short *array, long length) 
{
    unsigned b1, b2;
    unsigned char *ptr;

    ptr = (unsigned char *)array;
    while (length--) {
	b1 = *ptr++;
	b2 = *ptr++;
	*array++ = (b1 << 8) | (b2);
    }
}

void ConvertLong(unsigned *array, long length)
{
    unsigned long b1, b2, b3, b4;
    unsigned char *ptr;

    ptr = (unsigned char *)array;
    while (length--) {
	b1 = *ptr++;
	b2 = *ptr++;
	b3 = *ptr++;
	b4 = *ptr++;
	*array++ = (b1 << 24) | (b2 << 16) | (b3 << 8) | (b4);
    }
}

// Reads from the file a line and writes it in --*dest--, removing spaces leading and trailing spaces
// 0: OK, -1: EOF
int readTrimmedLine(std::ifstream & file, char *dest, int sizedest)
{
	char *head, *dest1;

	if (!file.getline(dest, sizedest)) return -1;

	head=dest1=dest;

	// leading
	while (*head && isspace(*head)) head++;
	if (head!=dest) {
		while (*head) 
			*dest1++=*head++;
		*dest1=0;
		head=dest1;
	} else 
		while (*head) head++;

	// head is on the \0 
	head--;
	while (head>dest && isspace(*head)) {
		*head=0;
		head--;
	}

    return 0;	
}


// Removes the file name from the path
void removeFilename(char *path)
{
	char *s;

    s = strrchr(path, '/');
	if (!s) s = strrchr(path,'\\');

	if (s)
		s[1] = '\0';
	else
		path[0] = '\0';
}


// Checks if a file is readable
DLLENTRY int fileReadable(char *path) {
	std::ifstream file(path);

	if (!file.is_open()) return 0;

	file.close();

	return 1;
}


// Builds an absolute file name from the path and the file name (--dest-- can be --path--)
void buildPathName(char *dest, char *path, char *file) {
	
	int l;

	if (dest!=path) strcpy(dest, path);
	// checks if there is a '\'

	l=strlen(dest);
	if (l>0 && dest[l-1]!='\\' && dest[l-1]!='/') 
#ifdef _WIN32
		strcat(dest, "\\");
#else
		strcat(dest, "/");
#endif

	strcat(dest, file);

}

void getPathName(char *path, char *file)
{
	int l = strlen(file);

	for (int c = l - 1; c >=0; c--)
	{
		if (file[c] == '\\' || file[c] == '/')
		{
			strncpy(path, file, c);
			path[c] = '\0' ;
			return;
		}
	}
	strcpy(path, "");
}

void getFilename(char *pathname, bool remove_extension, char *filename) {
	char tmp2[MAXPATHLENGTH], *fn1, *fn2, *fn;

	fn=NULL;
	fn1 = strrchr(pathname, '\\');
	fn2 = strrchr(pathname, '/');

	if (fn1 && fn2) 
		if (fn1>fn2) fn=fn1;
		else fn=fn2;
	else 
	if (fn1==NULL) 
		fn=fn2;
	else 
		fn=fn1;

	if (fn==NULL) 
		fn=pathname;
	else 
		fn++;

    strcpy(tmp2, fn);

	if (remove_extension) {
		fn=strrchr(tmp2, '.');
		if (fn) *fn=0;
	}
	
	strcpy(filename, tmp2);
}


// Returns the smaller power of two that is non smaller that n
unsigned int ceilPower2(unsigned int n) {
	unsigned int i;

	if (n & 1U<<31) return 1U<<31;
	i=1;
	while (i<n) 
		i<<=1;
	return i;
}


void convertbackslashes(const char* in, char* out)
{
	// replace all backslashes by forward slashes
	strcpy(out, in);
	int len = strlen(out);
	for (int x = 0; x < len; x++)
	{
		if (out[x] == '\\')
			out[x] = '/';
	}
}

void convertbackslashesinplace(char* out)
{
	// replace all backslashes by forward slashes
	int len = strlen(out);
	for (int x = 0; x < len; x++)
	{
		if (out[x] == '\\')
			out[x] = '/';
	}
}

void trim(const char* in, char* out)
{
	strcpy(out, in);
	int len = strlen(out);
	for (int x = len - 1; x >= 0; x--)
	{
		if (out[x] == '\n' || out[x] == '\r')
			out[x] = '\0';
	}
}

void eliminatespaces(const char* in, char* out)
{
	// replace all backslashes by forward slashes
	int len = strlen(in);
	int count = 0;
	for (int x = 0; x < len; x++)
	{
		if (in[x] != ' ')
		{
			out[count] = in[x];
			count++;
		}
	}
	out[count] = '\0';
}

void changechar(const char* in, char* out, char lookfor, char changeto)
{
	strcpy(out, in);
	int len = strlen(out);
	for (int x = 0; x < len; x++)
	{
		if (out[x] == lookfor)
			out[x] = changeto;
	}
}

#if defined(_WIN32) || defined(__EMX__) && !defined(__CYGWIN__)
static inline bool isdirsep(char c) {return c=='/' || c=='\\';}
#else
#define isdirsep(c) ((c)=='/')
#endif

/**
  Return the filename \a from expanded to a full "absolute" path name
  by prepending the current directory or by prepending the "home"
  directory if it starts with '~'.
  - \a output is a pointer to a buffer that \a may be used to write
    the result to.
  - \a length is the size of \a output. No more than \a length-1 characters
    are written, plus a trailing nul.
  - \a input is the initial filename.
  - \a directory is the directory that filename is relative to. If
    this is NULL then the current directory is gotten from the OS.

  If there is no change \a input is returned. Otherwise perhaps the
  suffix of \a input is returned, or the result is copied to \a output
  and a pointer to that is returned.

  Leading "./" sequences in \a input are removed, and "../" sequences
  are removed as well as the matching trailing part of the prefixed
  directory.  Technically this is incorrect if symbolic links are used
  but this matches the behavior of most programs.

  To expand a filename starting with ~ in the current directory
  you must start it with "./~".
*/
const char*
fltk_filename_normalize(char* output, int length, const char* input, const char* pwd)
{
  const char* prefix = 0;
  int prefixlen = 0;
  if (!pwd && input[0] == '~') {
    prefix = getenv("HOME");
    if (prefix && *prefix) {
      prefixlen = strlen(prefix);
      input++;
      if (isdirsep(*input)) {
	input++;
      } else if (*input) {
	// another user. Fake it for now by assumming it is at the same
	// level as the current user and has that user's name. The real
	// real way is to call getpwnam(name):
	while (prefixlen > 0 && !isdirsep(prefix[--prefixlen]));
      }
    }
  } else if (isdirsep(input[0]) /*|| input[0] == '|' // for tcl pipes? */
#if defined(_WIN32) || defined(__EMX__) && !defined(__CYGWIN__)
	     || input[0] && input[1]==':'
#endif
	     ) {
    ;
  } else {
    // current directory
    if (pwd) prefix = pwd;
    else if ((prefix = getenv("PWD")));
    else prefix = getcwd(output, length);
    if (prefix) prefixlen = strlen(prefix);
  }
  while (*input == '.') {
    if (isdirsep(input[1])) {
      input += 2;
    } else if (input[1] == '.' && isdirsep(input[2])) {
      if (!prefixlen) break;
      while (prefixlen > 0 && !isdirsep(prefix[--prefixlen]));
      input += 3;
    } else break;
  }
  if (!prefix) return input;
  if (prefixlen > length-2) prefixlen = length-2;
  if (prefix != output) memcpy(output, prefix, prefixlen);
  if (!prefixlen || !isdirsep(prefix[prefixlen-1])) output[prefixlen++] = '/';
  strlcpy(output+prefixlen, input, length-prefixlen);
  return output;
}

// Back-compatability with fltk1 functions:

/**
  Back-compatability version of filename_normalize().
  This did not let you specify the size of the buffer, it did a useless
  copy in the common case that there was no change in the name.
  It also did not do the home-directory prefix.
*/
bool fl_filename_absolute(char *output, const char *input, const char* pwd) {
  char temp[PATH_MAX];
  if (input == output) {strlcpy(temp, input, PATH_MAX); input = temp;}
  const char* t = fltk_filename_normalize(output, PATH_MAX, input, pwd);
  if (t != output) {
    strlcpy(output, input, PATH_MAX);
    return false;
  }
  return true;
}

/**
  Back-compatability function. Expands home directories (the old one
  would also expand $environment variables, but that is no longer
  supported).
*/
bool fl_filename_expand(char *output, const char *input) {
  if (*input == '~') return fl_filename_absolute(output, input, 0);
  if (output != input) strlcpy(output, input, PATH_MAX);
  return false;
}

//
// End of "$Id: filename_normalize.cxx,v 1.1 2006/02/23 02:16:04 ashapiro Exp $".
//


