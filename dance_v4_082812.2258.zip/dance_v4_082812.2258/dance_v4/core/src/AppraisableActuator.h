#ifndef APPRAISABLEACTUACTOR_H
#define APPRAISABLEACTUACTOR_H

#include "DActuator.h"

class ArticulatedObject;
class EquilibriumPose;

/// Interface for physical drivers (controllers or physically driven-animation) that 
/// can provide an appraisal of their ability to handle a system state.
class DLLENTRY AppraisableActuator : public DActuator
{
public:
	virtual ~AppraisableActuator();

	/// Returns a non-negative number that indicates how successful the controller
	/// is at its defined task.  Zero means complete failure, or indicates a 
	/// "dumb" controller that cannot appraise its success.  
	/// If multiple poses are used, the highest value of all applied poses is used.
	/// Static poses are expected to return 0.0, as the success of a static pose
	/// cannot be usefully be measured by the pose itself.
	virtual double success( void );

	/// Returns a non-negative number that indicates how well this actuator 
	/// could handle the current state of the character.  Note that the actuator
	/// may not be enabled or in use when this method is called-- it is a speculative
	/// evaluation of the AppraisableActuator's capability.
	/// Default returns 0.0, indicating complete inability to handle the state.
	/// A return of 1.0 indicates minimal competency to handle the state.
	virtual double canHandle( ArticulatedObject* argAO, const EquilibriumPose& argTargetPose, double argStartTimeSecs );
};

#endif
