/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _DYNAMICSSIMULATOR_
#define _DYNAMICSSIMULATOR_

#include "defs.h"
#include "DSimulator.h"

#define WORLDFRAME -1

class DLLENTRY DynamicsSimulator : public DSimulator
{
	public:
		DynamicsSimulator();
		virtual ~DynamicsSimulator();

		int commandPlugIn(int argc, char **argv);

		virtual int GetVelSize();
		// returns -1 on error else non zero
		virtual int SetVel(int index, double value); 
		virtual int SetVel(int startIndex, int size, double *q);
		virtual double GetVel(int index);
		// fast access, returns the pointer
		virtual double *GetVel();
		// q must be allocated by the calller
		virtual double *GetVel(int startIndex, int size, double *q);
		virtual double GetAcc(int index);
		// fast access, returns the pointer
		virtual double *GetAcc();
		virtual void GetAngAcc(int group, double *acc);

		// q must be allocated by the calller
		virtual double *GetAcc(int startIndex, int size, double *q);
		virtual int GetIndex(int group, int subgroup);
		virtual int GetIndex(int argc, char **argv);
	    
	// Force functions
		virtual void FieldForce(double *force);
		virtual void FieldForce(double *force, double *dampConst);

		// force vector and point relative to the given part of the object
		virtual void PointForce(int group, double *point, double *force);
	// point and force in world coordinates
		virtual void PointForce(DSystem *sys, double *pointWorldCoord, double *force);
	// the most general form of point force
		virtual void PointForce(int argc, char *argv[]);
		// point force jacobian for df/dv 
		virtual void PFJ_dv(int pointIndex, Matrix3x3 &J);
		// point force jacobian for df/dx
		virtual void PFJ_dx(int pointIndex, Matrix3x3 &J);

		virtual void BodyTorque(int group, double *torque);
		virtual void GeneralizedForce(int coord, double force);
		virtual void GeneralizedForce(int *index, double *force, int size);
		virtual void GeneralizedForce(double *Q);
		virtual void GeneralizedForce(int group, int subgroup, double force);

		// transformation utilities
		virtual void GetVel(DSystem *sys, double *localPoint, double *vel);
		virtual void GetVel(DSystem *sys, double *localPoint, int index, double *vel);
		virtual void GetVel(int group, double *point, double *vel);
		virtual void GetAcc(int group, double *point, double *acc);
		virtual void GetAcc(DSystem *sys, double *localPoint, double *acc);
	    
		virtual int GetPosition(DSystem *sys, double *localPoint, double *position);
		virtual int GetPosition(int group, double *localPoint, double *position);
		virtual int GetOrientation(DSystem *sourceSystem, double *sourceVec, DSystem *targetSystem, double *targetVec);
		virtual int GetOrientation(int sourceGroup, double *localVec, int targetGroup, double *rotated);
		virtual int Transform(int argc, char **argv);

	private:
		static void simstep(DObject* data, double time);
		static void simstart(DObject* data, double time);
		static void simstop(DObject* data, double time);
		static void recordstate(DObject* data, double time);

};
    
#endif
