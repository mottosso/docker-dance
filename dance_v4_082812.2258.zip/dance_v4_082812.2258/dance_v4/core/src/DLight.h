/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_DLIGHT_H
#define	_DLIGHT_H

#include "DObject.h"

#include "opengl.h"

/** Types of lights */

enum LightType {
	ePoint,
	eDirectional,
	eSpotLight,
	eAmbient
};


class LightWindow;

class DLLENTRY DLight: public DObject {

	public:
		DLight(char *name,	int argc, char **argv);
		~DLight();

		void output(int mode = 0);
		int commandPlugIn(int argc, char** argv);

		void getAmbient(GLfloat* ambient);
		void getDiffuse(GLfloat* diffuse);
		void getSpecular(GLfloat* specular);
		void getPosition(GLfloat* position);

		void setAmbient(GLfloat ambient[4]);
		void setDiffuse(GLfloat diffuse[4]);
		void setSpecular(GLfloat specular[4]);
		void setPosition(GLfloat position[4]);

		GLenum getLightID();

		void init();

		void setRelativeToCamera(bool val);
		bool isRelativeToCamera();

		void setDirectional(bool val);
		bool isDirectional();
		void setSpotlight(bool val);
		bool isSpotlight();
		void setSpotDirection(GLfloat dir[3]);
		void getSpotDirection(GLfloat dir[3]);
		void setSpotCutoffAngle(double val);
		double getSpotCutoffAngle();
		void setSpotExponent(double val);
		double getSpotExponent();
		void setConstantAttentuation(double val);
		double getConstantAttentuation();
		void setLinearAttentuation(double val);
		double getLinearAttentuation();
		void setQuadraticAttentuation(double val);
		double getQuadraticAttentuation();

		void showStatus();

		fltk::Widget* getInterface();

		// Writes the source properties into the file
		void render(int argc, char ** argv, std::ofstream & file);
		void save(int mode, std::ofstream& file);




	private:
		LightType m_Type;
		GLenum m_ID;

		GLfloat m_Position[4];
		GLfloat m_Diffuse[4];
		GLfloat m_Specular[4];
		GLfloat m_Ambient[4];

		bool m_isRelativeToCamera;
		bool m_isDirectional;
		bool m_isSpotLight;
		GLfloat m_spotDirection[3];
		GLfloat m_spotExponent;
		GLfloat m_spotCutoffAngle;
		GLfloat m_constantAttenuation;
		GLfloat m_linearAttenuation;
		GLfloat m_quadraticAttenuation;

		LightWindow* m_lightWindow;
	

};

#endif
