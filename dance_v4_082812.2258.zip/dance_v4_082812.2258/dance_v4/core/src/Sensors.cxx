#include "Sensors.h"  

Sensors::Sensors()
{
}

double* Sensors::GetCenterMass(Vector v)
{
	return NULL;
}

double* Sensors::GetCMvel(Vector v)
{
	return NULL;
}

double* Sensors::GetCMacc(Vector v)
{
	return NULL;
}

double* Sensors::GetGeomCenterSp(Vector v)
{
	return NULL;
}

void Sensors::ComputeSensors()
{
}

