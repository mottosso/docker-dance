/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	__DLFCN_H__
#define	__DLFCN_H__

#ifdef WIN32

#ifdef __cplusplus
extern "C" {
#endif

#define	DLLEXPORT __declspec(dllexport)
DLLEXPORT void *dlopen(const char	*, int);
DLLEXPORT void *dlsym(void *, const char *);
DLLEXPORT int dlclose(void *);
DLLEXPORT char *dlerror();

/* valid values	for mode argument to dlopen/sgidladd/sgidlopen_version */
#define	RTLD_LAZY	1	/* lazy	function call binding */
#define	RTLD_NOW	2	/* immediate function call binding */
#define	RTLD_GLOBAL	4	/* symbols in this dlopen'ed obj are visible to	other dlopen'ed	objs */

#ifdef __cplusplus
}
#endif

#endif /* WIN32	*/

#endif /* !__DLFCN_H__ */
