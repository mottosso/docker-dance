#ifndef _COLLAPSIBLEGROUP_H
#define _COLLAPSIBLEGROUP_H

#include "defs.h"
#include <string>
#include <fltk/Group.h>
#include <fltk/Style.h>

class DLLENTRY CollapsibleGroup :public fltk::Group
{
public:
        CollapsibleGroup(int x, int y, int w, int h, const char *l) ;
        ~CollapsibleGroup(void);
        int handle(int e);
		void layout();

		static fltk::NamedStyle* default_style;
private:
        bool collapsed; 
        int expandedHeight;  
        static const int COLLAPSED_HEIGHT;   

		std::string origLabel;
		std::string openLabel;
		std::string closedLabel;
};

#endif

