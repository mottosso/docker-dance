/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "dance.h"
#include "ViewManager.h"
#include "danceInterp.h"

#ifndef	WIN32

int main(int argc, char **argv)
{
	std::ios::sync_with_stdio();
    dance::initialize(argc,argv);
    return 0;
}
#else

#ifdef USE_DANCE_CONSOLE
int main(int argc, char **argv)
{
	std::ios::sync_with_stdio();
    dance::initialize(argc,argv);
    return 0;
}
#else

#include <windows.h>

void setargv(int *argc, char ***argv) ;

int APIENTRY
WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR lpszCmdLine, int nCmdShow)
{
    char **argv, *p;
    int	argc;
    char buffer[MAXPATHLENGTH];

#ifdef _DEBUG
	// Memory leaks detection. 
	_CrtSetDbgFlag ( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
	// Set this variable to the number of memory leak you want to check 
	// (the number between {} that appears in the leak list.
	_crtBreakAlloc = -1;
#endif

	FILE *fp = fopen("spacetime/preinit.state", "w");


    setargv(&argc, &argv);

    /*
     * Replace argv[0] with full pathname of executable, and forward
     * slashes substituted for backslashes.
     */

    GetModuleFileName(NULL, buffer, sizeof(buffer));
    argv[0] = buffer;
    for	(p = buffer; *p	!= '\0'; p++) {
	if (*p == '\\')	{
	    *p = '/';
	}
    }

    dance::initialize(argc,argv);
    return 1;
}

/*
 *-------------------------------------------------------------------------
 *
 * setargv --
 *
 *	Parse the Windows command line string into argc/argv.  Done here
 *	because	we don't trust the builtin argument parser in crt0.
 *	Windows	applications are responsible for breaking their	command
 *	line into arguments.
 *
 *	2N backslashes + quote -> N backslashes	+ begin	quoted string
 *	2N + 1 backslashes + quote -> literal
 *	N backslashes +	non-quote -> literal
 *	quote +	quote in a quoted string -> single quote
 *	quote +	quote not in quoted string -> empty string
 *	quote -> begin quoted string
 *
 * Results:
 *	Fills argcPtr with the number of arguments and argvPtr with the
 *	array of arguments.
 *
 * Side	effects:
 *	Memory allocated.
 *
 *--------------------------------------------------------------------------
 */

static void
setargv(int *argcPtr, char ***argvPtr)
{
    char *cmdLine, *p, *arg, *argSpace;
    char **argv;
    int	argc, size, inquote, copy, slashes;

    cmdLine = GetCommandLine();

    /*
     * Precompute an overly pessimistic	guess at the number of arguments
     * in the command line by counting non-space spans.
     */

    size = 2;
    for	(p = cmdLine; *p != '\0'; p++) {
	if (isspace(*p)) {
	    size++;
	    while (isspace(*p))	{
		p++;
	    }
	    if (*p == '\0') {
		break;
	    }
	}
    }
    argSpace = (char *)	malloc((unsigned) (size * sizeof(char *)
	    + strlen(cmdLine) +	1));
    argv = (char **) argSpace;
    argSpace +=	size * sizeof(char *);
    size--;

    p =	cmdLine;
    for	(argc =	0; argc	< size;	argc++)	{
	argv[argc] = arg = argSpace;
	while (isspace(*p)) {
	    p++;
	}
	if (*p == '\0')	{
	    break;
	}

	inquote	= 0;
	slashes	= 0;
	while (1) {
	    copy = 1;
	    while (*p == '\\') {
		slashes++;
		p++;
	    }
	    if (*p == '"') {
		if ((slashes & 1) == 0)	{
		    copy = 0;
		    if ((inquote) && (p[1] == '"')) {
			p++;
			copy = 1;
		    } else {
			inquote	= !inquote;
		    }
		}
		slashes	>>= 1;
	    }

	    while (slashes) {
		*arg = '\\';
		arg++;
		slashes--;
	    }

	    if ((*p == '\0') ||	(!inquote && isspace(*p))) {
		break;
	    }
	    if (copy !=	0) {
		*arg = *p;
		arg++;
	    }
	    p++;
	}
	*arg = '\0';
	argSpace = arg + 1;
    }
    argv[argc] = NULL;

    *argcPtr = argc;
    *argvPtr = argv;
}

#endif


#endif