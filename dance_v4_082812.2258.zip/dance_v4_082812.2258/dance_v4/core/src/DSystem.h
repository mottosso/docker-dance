/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef DSystem_h
#define DSystem_h 1

#include "defs.h"
#include "DObject.h"
#include "PlugIn.h"
#include "DObjectRefList.h"
#include "DCollision.h"
#include "DCollisionHierarchy.h"
#include <vector>

class BoundingBox ;
class DSimulator ;
class MonitorPoints ;
class DSystemWindow;

class DLLENTRY DSystem : public PlugIn {
public:
  DSystem() ;
  virtual ~DSystem() ;

  void addSimulator(DSimulator* sim);
  void removeSimulator(DSimulator* sim);
  int getNumSimulators();
  DSimulator* getSimulator(int index);

  bool isRecording();
  void setRecording(bool val);
  void setRecordStep(double step);
  double getRecordStep();
  void setLastRecordTime(double time);
  virtual double getLastRecordTime();
  virtual void recordState(double time);
  bool isPlayback();
  void setPlayback(bool val);
  virtual void erasePlayback();

  virtual void startSimulation();
  virtual void endSimulation();

  bool isStateModifiedOutsideSimulation();
  void setStateModifiedOutsideSimulation(bool val);

  virtual DSystem *GetGroup(int index) { return NULL ; } ;
  virtual DSystem *GetGroup(char *id) { return NULL ;} ;
  virtual int GetNumGroups() { return 0 ; } ;
  virtual double GetGroupMass(int id) { return 0; } ;
  /** returns the index of the first controllable dof in the state vector */
  virtual int GetIndxFirstConDof() { return 0 ; } ;

  virtual void getLocalCoord(int group, double local[3], double world[3]) { return; };
  virtual void getWorldCoord(int group, double world[3], double local[3]) { return; };


  virtual int KeyboardCB( unsigned char key, int x, int y ) { return 0 ; } ;
  virtual int PassiveMotionCB(DView *view, int x, int y) { return 0 ;} ;

  virtual DCollision** getPointCollisionData();
  virtual int getNumPointCollisionData();

  virtual DSphereCollision** getSphereCollisionData();
  virtual int getNumSphereCollisionData();

  virtual DCollisionHierarchy* getPointCollisionHierarchy();
  virtual DCollisionHierarchy* getSphereCollisionHierarchy();


  fltk::Widget* getInterface();

  /** Used to build and automatically link in an associated simulator */
  virtual void BuildAndLinkSimulator() { return ; } ;

/*
  // must be Called by the DSimulator::Start proc to initialize the system for simulation 
  void InitSimulationBase(double time, DSimulator *sim) { isSimul = TRUE ; InitSimulation(time, sim) ;} ;
  virtual int InitSimulation(double time, DSimulator *sim) { return DANCE_OK ;} ;
  // must be Called by the DSimulator::Step 
  void BeforeSimStepBase(double time, DSimulator *sim) 
		{ BeforeSimStep(time, sim);} ;
  virtual int BeforeSimStep(double time, DSimulator *sim) { return DANCE_OK; } ;
  // must be Called by the DSimulator::Step 
  void AfterSimStepBase(double time, DSimulator *sim) { AfterSimStep(time, sim) ;} ;
  virtual int AfterSimStep(double time, DSimulator *sim) { return -1 ; } ;
  // must be Called by the DSimulator::Step 
  void AtEndSimulBase(double time, DSimulator *sim) { isSimul = FALSE; AtEndSimul(time, sim);} ;
  virtual int AtEndSimul(double time, DSimulator *sim) { return DANCE_OK ;} ;
*/  

	virtual BoundingBox *calcBoundingBox(BoundingBox *b) {return NULL ; } ;
	virtual int commandPlugIn(int argc, char **argv);
	void save(int mode, std::ofstream& file);

	void onDependencyRemoval(DObject* object);
  
private:
	double m_stiffness;
	double m_damping;
	DObjectRefList m_simulators;
	bool m_isRecording;
	double m_lastRecordTime;
	double m_recordStep;
	bool m_isPlayback;
	bool m_stateModified;

	static void recordstate(DObject* data, double time);
	static void startsim(DObject* data, double time);
	static void endsim(DObject* data, double time);

};


#endif
