#ifndef _DSELECTIONMANAGER_
#define _DSELECTIONMANAGER_

#include <string>
#include <map>
#include <set>

class DObject;
class DAttribute;

class DSelectionManager
{
public:
	DSelectionManager();
	~DSelectionManager();

	void addSelectedObject(DObject* object);
	void removeSelectedObject(DObject* object);
	std::map<std::string, DObject*>& getSelectedObjects();
	bool isObjectSelected(std::string name);

	void addSelectedAttribute(DAttribute* attribute);
	void removeSelectedAttribute(DAttribute* attribute);
	std::set<DAttribute*>& getSelectedAttributes();
	bool isAttributeSelected(DAttribute* attribute);

private:
	std::map<std::string, DObject*> m_selectedObjects;
	std::set<DAttribute*> m_selectedAttributes;

};
#endif
