/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "dance.h"
#include "danceInterp.h"
#include "stuff.h"
#include <fltk/ask.h>
#include "DMaterialManager.h"
#include "DGeometry.h"


DMaterialManager::DMaterialManager()
{
	// Load stock materials
}

DMaterialManager::~DMaterialManager()
{
	remove_materials();
}




// Removes all the materials from the data structure. Returns the number of objets deleted
int DMaterialManager::remove_materials() {
	int no;
	std::vector <MaterialCapsule *>::iterator iter;

	no=pool.size();

	for (int i=0; i<no; i++) {
		iter=pool.begin( );
		delete (*iter);	
		pool.erase( iter );
	}
	
	return no;
}

// Returns the capsule that contains the material m, or NULL if it does not exists
MaterialCapsule *DMaterialManager::findCapsule(Material *m) {
	MaterialCapsule *tem;

	std::vector <MaterialCapsule *>::iterator v1_Iter;
   
	for ( v1_Iter = pool.begin( ) ; v1_Iter != pool.end( ) ; v1_Iter++ ) {
      tem=*v1_Iter;  
	  if (&(tem->mat) == m) return tem;
	}
	return NULL;
}



// Cleans up the database, erasing those materials that are not referenced by the geometry list AND do not belong to the stock. 
// Returns the number of deleted records
int DMaterialManager::cleanup(DObjectList *geometry) {
	int deleted=0;
	MaterialCapsule *tem;


	update_in_use_flag(geometry);

	// Remove those materials that do not have its flag IN_USE active

	std::vector <MaterialCapsule *>::iterator v1_Iter;
   
	for ( v1_Iter = pool.begin( ) ; v1_Iter != pool.end( ) ; v1_Iter++ ) {
      tem=*v1_Iter;
		if (!(tem->flags & IN_USE) & !(tem->flags & IN_USE)) {
			pool.erase(v1_Iter);
			deleted++;
		}
	}

	return deleted;
}



// Adds a material to the database. It returns the pointer that should be stored/used by the renderer. 
// It returns NULL if the name of the material exists
Material * DMaterialManager::addMaterial(Material *p) {
	MaterialCapsule *mc;

	if (getMaterialbyName(p->getMaterialName()) !=NULL)
	{
		return NULL;
	}

	mc= new MaterialCapsule;
	if (mc==NULL) return NULL;

	
	mc->mat.copy(p);
	
	mc->flags=DEFAULT_FLAG_SET;

	pool.push_back(mc);

	return &(mc->mat);
}



// Given a set of geometries, updates the status of the IN_USE flag of the material database
void DMaterialManager::update_in_use_flag(DObjectList *geometry) {
	int n, i;
	MaterialCapsule *tem;
	DGeometry *geo;

	// Reset all the 'in use' flags of the material
	std::vector <MaterialCapsule *>::iterator Iter;

	for ( Iter = pool.begin( ) ; Iter != pool.end( ) ; Iter++ ) {
		tem=*Iter;
		tem->flags &= ~IN_USE; 
	}

	// Activate the IN_USE flag of those materials referenced in the geometry 
	n=geometry->size();
	for (i=0 ; i<n; i++) {
		geo=(DGeometry *)geometry->get(i);
		tem=findCapsule(geo->getMaterial());
//		_ASSERT(tem!=NULL);
		if (tem!=NULL) 
			tem->flags |= IN_USE;
	}
}


	// Retrieves from the database the first material which name is -name-
Material *DMaterialManager::getMaterialbyName(const char *name) {

	MaterialCapsule *tem;

	std::vector <MaterialCapsule *>::iterator Iter;

	for ( Iter = pool.begin( ) ; Iter != pool.end( ) ; Iter++ ) {
		tem=*Iter;
		if (!strcmp(name, tem->mat.getMaterialName()))
			return &(tem->mat);
	}

	return NULL;
}


// Returns the index of the material which name is --name--, or -1 if the material does not exist
int DMaterialManager::getMaterialIndexbyName(char * name)
{
	MaterialCapsule *tem;
	int id=0;

	std::vector <MaterialCapsule *>::iterator Iter;

	for ( Iter = pool.begin( ) ; Iter != pool.end( ) ; Iter++ ) {
		tem=*Iter;
		if (!strcmp(name, tem->mat.getMaterialName()))
			return id;
		id++;
	}
	
	return -1;
}


Material * const DMaterialManager::getMaterialbyIndex(int ind) {
	MaterialCapsule *mc;

	mc=pool.at(ind);
	if (mc==NULL) return NULL;
	return &(mc->mat);
}


int DMaterialManager::getNumMaterials() {
	return pool.size();
}


// Saves the materials in several formats
// If saveOnlyInUse==TRUE, then it saves only the materials with its IN_USE flag active
int DMaterialManager::save(const char *filename, int format, bool saveOnlyInUse)
{
	MaterialCapsule *tem;

	std::ofstream file(filename);
	if (file.good())
	{
		// Save the materials where ((geometry==NULL && !STOCK) || (geometry != NULL && IN_USE))

		std::vector <MaterialCapsule *>::iterator Iter;

		for ( Iter = pool.begin( ) ; Iter != pool.end( ) ; Iter++ ) {
			tem=*Iter;
			if (saveOnlyInUse && !(tem->flags & IN_USE)) continue;
			switch (format) {
				case PSEUDO_POVRAY:
					tem->mat.write_povray(file);
					break;
				case WAVEFRONT_MTL:
					tem->mat.write_mtl(file);
					break;
			}

			
		}
	}
	else
	{
		danceInterp::OutputMessage("Could not open file %s for writing...", filename);
	}
	file.close();

	return 0;
}




// Loads from a file the state of the manager in several formats
/* This function returns:
	-3: Texture format non supported
	-2: File not found
	-1: Syntax error in the file
	0: OK
	Those materials that are duplicated are not loaded. If duplicates!=NULL, it returns the names of the
	materials that were skipped.
	Later you can query for the number of actually loaded materials (even when there is an error)
*/
int DMaterialManager::load(char *filename, int format, std::string *duplicates)
{
	char convertedFilename[1024];
	convertbackslashes(filename, convertedFilename);
	std::ifstream file(convertedFilename);
	Material tmp;
	int last_error;
	char path[MAXPATHLENGTH];


	if (!file.is_open()) return -2;

	strcpy(path, convertedFilename);
	removeFilename(path);

	if (duplicates) *duplicates="";

	while (1) {
		switch (format) {
			case PSEUDO_POVRAY:
				last_error=tmp.read_povray(file, path);
				break;
			case WAVEFRONT_MTL:
				last_error=tmp.read_mtl(file, path);
				break;
		}

		if (last_error==0) {
			if (addMaterial(&tmp)==NULL) 
			{
				if (duplicates) {
					duplicates->append(tmp.getMaterialName());
					duplicates->append(" ");
				}
			}
		} else break;
	}
	
	file.close();

	if (last_error!=-1) return -1;

	return 0;
}


// Load the materials from the stock file. This function is equal to --load--, but it sets the materials' STOCK flag 
int DMaterialManager::loadStock(char * filename, std::string *duplicates)
{
	int first, last, result, i;

	first=getNumMaterials();
	result=load(filename, PSEUDO_POVRAY, duplicates);
	last=getNumMaterials();
	
	for (i=first; i<last; i++)
		pool.at(i)->flags|=STOCK_MATERIAL;

	return result;
}



// Returns the default material
Material * DMaterialManager::getDefaultMaterial()
{
	Material *tmp;

	// is 'default' material in the database?
	tmp=getMaterialbyName("default");
	if (tmp!=NULL) return tmp;

	// if not, I create a default material, and insert it into the database
	tmp=new Material();
	tmp->setMaterialName("default");
	tmp->setToDefault();
	return addMaterial(tmp);
}

Material * DMaterialManager::getRandomMaterial()
{
	int numMaterials = this->getNumMaterials();

	int val = rand();

	return this->getMaterialbyIndex(val % numMaterials);
}

int DMaterialManager::commandPlugIn(int argc, char** argv)
{
	if (strcmp(argv[0], "default") == 0)
	{
		Material* material = this->getDefaultMaterial();
		if (material != NULL)
		{
			danceInterp::OutputResult("%s", material->getMaterialName());
		}
		else
		{
			danceInterp::OutputResult("");
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "random") == 0)
	{
		Material* material = this->getRandomMaterial();
		if (material != NULL)
		{
			danceInterp::OutputResult("%s", material->getMaterialName());
		}
		else
		{
			danceInterp::OutputResult("");
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "nummaterials") == 0)
	{
		danceInterp::OutputResult("%d", this->getNumMaterials());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "materialnum") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.materialmanager(\"materialnum\", <number>)");
			return DANCE_ERROR;
		}

		int num = atoi(argv[1]);
		if (num < 0 || num >= this->getNumMaterials())
		{
			danceInterp::OutputMessage("No material number %d found. Only %d materials.", num, this->getNumMaterials());
			return DANCE_ERROR;
		}
		Material* material = this->getMaterialbyIndex(num);
		if (material != NULL)
		{
			danceInterp::OutputResult("%s", material->getMaterialName());
		}
		else
		{
			danceInterp::OutputResult("");
		}
		return DANCE_OK;
	}
	else
	{
		return DANCE_ERROR;
	}
}
