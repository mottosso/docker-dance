/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "DRenderer.h"
#include "dance.h"
#include "ViewManager.h"
#include "PlugIn.h"
#include <sstream>

DRenderer::DRenderer() : PlugIn()
{
	this->setBaseType("renderer");

	m_runViewerAttr = this->createBoolAttribute("runviewer", true, true, "Images", 20);
	m_viewerAttr = this->createStringAttribute("viewer", "C:\\WINDOWS\\system32\\rundll32.exe C:\\WINDOWS\\System32\\shimgvw.dll,ImageView_Fullscreen %1", true, "Images", 30);
	m_renderDirectoryAttr = this->createStringAttribute("renderdir", ".", true, "Images", 40);
	m_lastRenderedFilenameAttr = this->createStringAttribute("lastfilename", "", true, "Images", 50);
	m_usePostRendererAttr = this->createBoolAttribute("use postrenderer", false, true, "Images", 60);
	m_viewerAttr = this->createStringAttribute("postrenderer", "", true, "Images", 70);
}

DRenderer::~DRenderer()
{
	// make sure that this renderer is not the current renderer	
	// of the view manager
	if (dance::AllViews->getRenderer() == this)
	{
		dance::AllViews->setRenderer(NULL);
	}
}

int DRenderer::commandPlugIn(int argc, char** argv)
{
	int ret = PlugIn::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

	if (strcmp(argv[0], "render_directory") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.renderer(\"%s\", \"render_directory\", \"<directory>\")", this->getName());
			return DANCE_ERROR;
		}
		this->setRenderDirectory(argv[1]);
		danceInterp::OutputMessage("Render directory is now %s", argv[1]);
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "set_image_viewer") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.renderer(\"%s\", \"set_image_viewer\", \"<on|off>\")", this->getName());
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "on") == 0)
		{
			this->setRunImageViewer(true);
			danceInterp::OutputMessage("Renderer %s will now use image viewer.", this->getName());
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "off") == 0)
		{
			this->setRunImageViewer(false);
			danceInterp::OutputMessage("Renderer %s will not use image viewer.", this->getName());
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Usage: dance.renderer(\"%s\", \"set_image_viewer\", \"<on|off>\")", this->getName());
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "set_image_viewer_command") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.renderer(\"%s\", \"set_image_viewer_command\", \"<command>\")", this->getName());
			return DANCE_ERROR;
		}
		this->setRunImageViewer(true);
		this->setImageViewerCommand(argv[1]);
		danceInterp::OutputMessage("Renderer %s will now use image viewer command %s.", this->getName(), this->getImageViewerCommand().c_str());
		return DANCE_OK;
	}

	return DANCE_CONTINUE;
}

void DRenderer::setRenderDirectory(const char* dir)
{
	m_renderDirectoryAttr->setValue(dir);
}

std::string DRenderer::getRenderDirectory()
{
	return m_renderDirectoryAttr->getValue();
}

std::string DRenderer::getLastRenderedFileName()
{
	return m_lastRenderedFilenameAttr->getValue();
}

void DRenderer::setLastRenderedFileName(const char* filename)
{
	if (filename == NULL)
		m_lastRenderedFilenameAttr->setValue("");
	else
		m_lastRenderedFilenameAttr->setValue(filename);
}

void DRenderer::save(int mode, std::ofstream& file)
{
	PlugIn::save(mode, file);

	char buff[512];

	if (mode == 1)
	{
		sprintf(buff, "\"render_directory\", \"%s\"", this->getRenderDirectory().c_str());
		pythonSave(file, buff);

		if (this->isRunImageViewer())
			sprintf(buff, "\"set_image_viewer\", \"on\"");
		else
			sprintf(buff, "\"set_image_viewer\", \"off\"");
		pythonSave(file, buff);

		// make sure that any quotes are escaped
		std::string imageViewer = this->getImageViewerCommand();
		std::stringstream viewerFormatted;
		bool hasBackslash = false;
		for (unsigned int x = 0; x < imageViewer.size(); x++)
		{
			if (imageViewer[x] == '\\')
			{
				hasBackslash = true;
				viewerFormatted << "\\";
			}
			else if (imageViewer[x] == '\"' && !hasBackslash)
			{
				viewerFormatted << "\\" << imageViewer[x];
				hasBackslash = false;
			}
			else
			{
				hasBackslash = false;
				viewerFormatted << imageViewer[x];
			}
		}
		sprintf(buff, "\"set_image_viewer_command\", \"%s\"", viewerFormatted.str().c_str());
		pythonSave(file, buff);

	}
}


bool DRenderer::isRunImageViewer()
{
	return m_runViewerAttr->getValue();
}

void DRenderer::setRunImageViewer(bool val)
{
	m_runViewerAttr->setValue(val);
}

std::string DRenderer::getImageViewerCommand()
{
	return m_viewerAttr->getValue();
}

void DRenderer::setImageViewerCommand(const char* command)
{
	m_viewerAttr->setValue(command);
}
