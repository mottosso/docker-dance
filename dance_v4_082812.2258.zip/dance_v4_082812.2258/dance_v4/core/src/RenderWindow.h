/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _RENDERWINDOW_H
#define _RENDERWINDOW_H

#include <fltk/Window.h>
#include <fltk/CheckButton.h>
#include <fltk/FloatInput.h>
#include <fltk/Input.h>
#include <fltk/Output.h>
#include <fltk/Button.h>
#include <fltk/Browser.h>
#include <vector>
#include <string>

class RenderWindow : public fltk::Window
{
	public:
		RenderWindow(int w, int h, const char* name);
		~RenderWindow();

		void addRenderedFrame(const char* frameNames);
		void clearRenderedFrameList();
		int getNumFrames();
		const char* getFrameNum(unsigned int num);

		void show();

		void updateGUI();


		static void render_cb(fltk::Widget* widget, void* data);
		static void cancel_cb(fltk::Widget* widget, void* data);
		static void starttime_cb(fltk::Widget* widget, void* data);
		static void endtime_cb(fltk::Widget* widget, void* data);
		static void directory_cb(fltk::Widget* widget, void* data);
		static void checkcurrentframeonly_cb(fltk::Widget* widget, void* data);
		static void checkmovie_cb(fltk::Widget* widget, void* data);
		static void selectrenderer_cb(fltk::Widget* widget, void* data);
		static void changerenderdir_cb(fltk::Widget* widget, void* data);
		static void setframenum_cb(fltk::Widget* widget, void* data);
		static void renderoptions_cb(fltk::Widget* widget, void* data);

		static std::string makeCommandPath(std::string commandTemplate, std::string renderedFile);

		static void idle_render(void* data);

		fltk::Button* buttonRenderOptions;
		fltk::Button* buttonCancel;
		fltk::Button* buttonRender;
		fltk::CheckButton* checkCurrentFrame;
		fltk::CheckButton* checkMovie;
		fltk::Input* inputMovieName;
		fltk::FloatInput* inputStartTime;
		fltk::FloatInput* inputEndTime;
		fltk::FloatInput* inputFPS;
		fltk::Input* inputDirectory;
		fltk::Browser* browserRenderers;
		fltk::Input* inputFrameNum;
		fltk::Button* buttonChangeRenderDirectory;

		int renderCounter;
		double currentRenderTime;
		bool isRendering;
		double startTime;
		double endTime;
		char renderDirectory[512];

		std::vector<std::string> renderedFrames;

};

#endif

