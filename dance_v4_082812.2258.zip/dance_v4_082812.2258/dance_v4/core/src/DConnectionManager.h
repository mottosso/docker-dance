#ifndef DCONNECTIONMANAGER_H
#define DCONNECTIONMANAGER_H

#include "DConnection.h"
#include <vector>

class DLLENTRY DConnectionManager
{
	public:
		DConnectionManager();
		~DConnectionManager();

		DConnection* makeConnection(DObject* from, std::string type, DObject* to);

		bool addConnection(DConnection* connection);
		void getConnections(DObject* object, std::vector<DConnection*>& list);		
		void getConnections(std::string type, std::vector<DConnection*>& list);		
		void getFromConnections(std::string type, DObject* fromObject, std::vector<DConnection*>& list);		
		void getToConnections(std::string type, DObject* toObject, std::vector<DConnection*>& list);		
		bool removeConnection(DObject* from, std::string type, DObject* to);
		bool removeConnection(DConnection* connection);

	private:
		std::vector<DConnection*> m_connections;
};

#endif
