/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "ParserBVH.h"
#include <iostream>
#include <stack>
#include <sstream>
#include <cstdlib>
#include "danceInterp.h"
#include "dance.h"
#include "stuff.h"
#include "DConnectionManager.h"

using namespace std;

Character* ParserBVH::parse(std::string name, std::ifstream &file, int N1, int N2)
{
	// check to make sure we have properly opened the file
	if (!file.good())
	{
		danceInterp::OutputMessage("Could not open file\n");
		return NULL;
	}
	char line[8192];
	Character* c = new Character();
	c->setName(name.c_str());
	c->setIsBVH(true);
	int state = 0;
	char* str = NULL;
	stack<CharJoint*> stack;
	CharJoint* cur = NULL;
	int numFrames = 0;
	int curFrame = -1;
	double frameTime = 0;
	int foundRoot = 0; // 0 = root not found, 1 = root found, 2 = next joint found

	while(!file.eof() && file.good())
	{
		file.getline(line, 8192, '\n');
                // remove any trailing \r
                if (line[strlen(line) - 1] == '\r')
                        line[strlen(line) - 1] = '\0';
		if (strlen(line) == 0) // ignore blank lines
			continue;
		switch (state)
		{
			case 0:	// looking for 'HIERARCHY'
				str = strtok(line, " \t");	
				if (strncmp(str, "HIERARCHY", strlen("HIERARCHY")) == 0)
					state = 1;
				else
				{
					danceInterp::OutputMessage("HIERARCHY not found...\n");
					file.close();
					return c;
				}
				break;
			case 1:	// looking for 'ROOT'
				str = strtok(line, " \t");	
				if (str != NULL && strncmp(str, "ROOT", strlen("ROOT")) == 0)
				{
					str = strtok(NULL, " \t");
					if (str != NULL)
					{
						char trimmedname[512];
						trim(str, trimmedname);
						std::stringstream strstr;
						strstr << c->getName() << "_" << trimmedname;
						CharJoint* root = new CharJoint(strstr.str().c_str());
						dance::AllGenericPlugins->add(root);
						dance::connectionManager->makeConnection(c, "rootjoint", root);
						cur = root;
						state = 2;
					}
					else
					{
						danceInterp::OutputMessage("ROOT name not found...\n");
						file.close();
						return c;
					}
				}
				else
				{
					danceInterp::OutputMessage("ROOT not found...\n");
					file.close();
					return c;
				}
				break;
			case 2: // looking for '{'
				str = strtok(line, " \t");
				if (str != NULL && strncmp(str, "{", 1) == 0)
				{
					stack.push(cur);
					state = 3;
				}
				else
				{
					danceInterp::OutputMessage("{ not found...\n");
					file.close();
					return c;
				}
				break;
			case 3: // looking for 'OFFSET'
				str = strtok(line, " \t");
				if (str != NULL && strncmp(str, "OFFSET", strlen("OFFSET")) == 0)
				{
					if (foundRoot == 0)
						foundRoot = 1;
					else if (foundRoot == 1)
						foundRoot = 2;
					double x = 0; double y = 0; double z = 0;
					str = strtok(NULL, " \t");
					x = atof(str);
					str = strtok(NULL, " \t");
					y = atof(str);
					str = strtok(NULL, " \t");
					z = atof(str);
					cur->setOffset(x, y, z);
					//cout << "Found offset of " << x << " " << y << " " << z << " " << endl;
					state = 4;
				}
				else
				{
					danceInterp::OutputMessage("OFFSET not found...\n");
					file.close();
					return c;
				}
				break;
			case 4: // looking for 'CHANNELS'
				str = strtok(line, " \t");
				if (str != NULL && strncmp(str, "CHANNELS", strlen("CHANNELS")) == 0)
				{
					str = strtok(NULL, " \t");
					int numChannels = atoi(str);

					// make sure that only the root has > 3 channels
					if (numChannels > 3 && foundRoot == 2)
					{
						//danceInterp::OutputMessage("Too many channels (%d) found for non-root node at %s, reducing to %d...", numChannels, cur->getName(), numChannels - 3);
						//cur->setIgnoreChannels(true);
					}
					int channels[6] = {0};
					//danceInterp::OutputMessage("Found %d channels...\n", numChannels);
					for (int c = 0; c < numChannels; c++)
					{
						str = strtok(NULL, " \t");
						if (strncmp(str, "Xrotation", strlen("Xrotation")) == 0)
						{
							channels[c] = CharJoint::XROTATION;				
						}
						else if (strncmp(str, "Yrotation", strlen("Yrotation")) == 0)
						{
							channels[c] = CharJoint::YROTATION;							
						}
						else if (strncmp(str, "Zrotation", strlen("Zrotation")) == 0)
						{
							channels[c] = CharJoint::ZROTATION;							
						}
						else if (strncmp(str, "Xposition", strlen("Xposition")) == 0)
						{
							channels[c] = CharJoint::XPOSITION;							
						}
						else if (strncmp(str, "Yposition", strlen("Yposition")) == 0)
						{
							channels[c] = CharJoint::YPOSITION;							
						}
						else if (strncmp(str, "Zposition", strlen("Zposition")) == 0)
						{
							channels[c] = CharJoint::ZPOSITION;							
						}
						else
						{
							danceInterp::OutputMessage("Unknown channel: %s...\n", str);;
							file.close();
						}
					}

					//if (cur->isIgnoreChannels())
					//{
					//	for (int i = 0; i < 3; i++)
					//		channels[i] = channels[i + 3];
					//	numChannels -= 3;
					//}
					cur->setChannels(numChannels, channels);
					state = 5;
				}
				else
				{
					danceInterp::OutputMessage("CHANNELS not found...\n");;
					file.close();
					return c;
				}
				break;
			case 5: // looking for 'JOINT' or 'End Site' or '}' or 'MOTION'
				str = strtok(line, " \t");
				if (strncmp(str, "JOINT", strlen("JOINT")) == 0)
				{
					str = strtok(NULL, "");
					if (str != NULL)
					{
						char trimmedname[512];
						trim(str, trimmedname);
						CharJoint* joint = new CharJoint(trimmedname);
						dance::AllGenericPlugins->add(joint);
						CharJoint* top = stack.top();
						dance::connectionManager->makeConnection(top, "jointchild", joint);
						cur = joint;
						//cout << "Found joint " << str << endl;
						state = 2;
					}
					else
					{
						danceInterp::OutputMessage("ROOT name not found...\n");;
						file.close();
						return c;
					}
				}
				else if (strncmp(str, "End", strlen("End")) == 0)
				{
					str = strtok(NULL, " \t");
					if (strncmp(str, "Site", strlen("Site")) == 0)
					{
						state = 6;
					}
					else
					{
						danceInterp::OutputMessage("End site not found...\n");;
						file.close();
						return c;
					}
				}
				else if (strncmp(str, "}", 1) == 0)
				{
					str = strtok(line, " \t");
					if (str != NULL && strncmp(str, "}", 1) == 0)
					{
						stack.pop();
						state = 5;
					}
					else
					{
						danceInterp::OutputMessage("} not found...\n");;
						file.close();
						return c;
					}
				}
				else if (strncmp(str, "MOTION", strlen("MOTION")) == 0)
				{
					state = 9;
				}
				else
				{
					danceInterp::OutputMessage("JOINT or End Site not found...\n");;
					file.close();
					return c;
				}
				break;
			case 6: // looking for 'OFFSET' within end effector
				str = strtok(line, " \t");
				if (str != NULL && strncmp(str, "{", 1) == 0)
				{
					state = 7;
				}
				else
				{
					danceInterp::OutputMessage("{ not found for end effector...\n");;
					cerr << "{ not found for end effector..." << endl;
					file.close();
					return c;
				}
				break;
			case 7:
				str = strtok(line, " \t");
				if (str != NULL && strncmp(str, "OFFSET", strlen("OFFSET")) == 0)
				{
					double x = 0; double y = 0; double z = 0;
					str = strtok(NULL, " \t");
					x = atof(str);
					str = strtok(NULL, " \t");
					y = atof(str);
					str = strtok(NULL, " \t");
					z = atof(str);
					cur->setEndEffectorOffset(x, y, z);
					cur->setEndEffector(true);
					//danceInterp::OutputMessage("Found end effector at %s", cur->getName());
					//cout << "Found end effector offset of " << x << " " << y << " " << z << " " << endl;
					state = 8;
				}
				else
				{
					danceInterp::OutputMessage("End effector OFFSET not found...\n");;
					file.close();
					return c;
				}
				break;
			case 8: // looking for '}' to finish the  end effector
				str = strtok(line, " \t");
				if (str != NULL && strncmp(str, "}", 1) == 0)
				{
					state = 5;
				}
				else
				{
					danceInterp::OutputMessage("} not found for end effector...\n");;
					file.close();
					return c;
				}
				break;
			case 9: // found 'MOTION', looking for 'Frames'
				str = strtok(line, ":");
				if (str != NULL && strncmp(str, "Frames", strlen("Frames")) == 0)
				{
					str = strtok(NULL, " \t");
					numFrames = atoi(str);
					danceInterp::OutputMessage("Found %d frames of animation...\n", numFrames);
					state = 10;
				}
				else
				{
					danceInterp::OutputMessage("Frames: not found...\n");;
					file.close();
					return c;
				}
				break;
			case 10: // found 'Frames', looking for 'Frame time:'
				str = strtok(line, ":");
				if (str != NULL && strncmp(str, "Frame Time", strlen("Frame Time")) == 0)
				{
					str = strtok(NULL, " \t");
					frameTime = atof(str);
					danceInterp::OutputMessage("Frame time is %f...\n", frameTime);
					//curFrame = 0;
					state = 11;
				}
				else
				{
					danceInterp::OutputMessage("Frame Time: not found...\n");;
					file.close();
					return c;
				}
				break;
			case 11: // parsing 
				curFrame++;
				if( (curFrame <= N2) && (curFrame >= N1))
				{
					if (curFrame < numFrames)
					{
						int index = 0;
						str = strtok(line, " \t");
						CharJoint* oldJoint = NULL;
						double frames[6] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
						// clean up any line feeds or carriage returns
						while (str != NULL && str[0] != 13)
						{
							double val = atof(str);
							int channelNum;

							CharJoint* j = c->getCharJoint(index, channelNum);
							if (j != oldJoint)
							{
								// add the values to the old joint
								if (oldJoint != NULL)
								{
									if (oldJoint->isIgnoreChannels())
									{
										// shift the frame values down by three
										for (int i = 0; i < 3; i++)
										{
											frames[i] = frames[i + 3];
										}
										index -= 3;
									}
									oldJoint->addFrame(frames);
								}

								for (int x = 0; x < 6; x++)
									frames[x] = 0.0;
								oldJoint = j;
							}

							frames[channelNum] = val;
							if (j != NULL)
							{
								j->setFrameTime(frameTime);
							}
							else
							{
								danceInterp::OutputMessage("No joint found for index %d and channel #%d on frame %d...\n", index, channelNum, curFrame);
							}
							index++;
						
							str = strtok(NULL, " \t");
						}

						// flush any values to the old joint
						if (oldJoint != NULL)
							oldJoint->addFrame(frames);
						state = 11;
					}
					else
					{
						state = 12;
					}
				}

				break;
			case 12: 
				state = 50;
				break;
			
			case 50:
				danceInterp::OutputMessage("Finished parsing motion with %d frames...", numFrames);
				file.close();
				c->recalculateJointList();
				c->calculateMatrices(0);	

				return c;
			default:
				cerr << "State " << state << " not expected..." << endl;
				file.close();
				return c;
		}
	}
	return c;
}
