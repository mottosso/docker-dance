/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "defs.h"
#include <iostream>
#ifdef WIN32
#include <windows.h>
#endif
#include <math.h>
#include <cstring>
#include <fstream>
//#include <GL/glu.h>
#include <Magick++.h>

#include "dance.h"
#include "defs.h"
#include "danceInterp.h"
#include "texture.h"
#include "stuff.h"


Texture::Texture(char* texname, bool make_mipmaps)
{
	this->fname=NULL;
	m_tex=0;
	loaded=false;
	load(texname, make_mipmaps);
}

Texture::~Texture()
{

	releaseTexture();
}


// Determines if the file provided can be used as a texture (it exists, it is readable
// and it is one of the known formats)
int Texture::isFileAcceptable(char *file) {
	/// we check if the file exists
	if (!fileReadable(file)) return 0;
	return 1;
}



int Texture::load(char *texname, bool make_mipmaps) {
	if (!isFileAcceptable(texname)) return -2;
	releaseTexture();

	this->fname=strdup(texname);
	this->make_mipmaps=make_mipmaps;

	strcpy(extension,fname+strlen(fname)-3);
	#ifdef WIN32
	_strlwr(extension);
	#else
	int len = strlen(extension);
	for (int c = 0; c < len; c++)
		extension[c] = tolower(extension[c]);
	#endif
	if (!strcmp(extension, "bmp")) 
		strcpy(extension, "sys");
	loaded=false;

	return 0;
}



void Texture::initParameters()
{
	mag_filter=GL_NEAREST;
	min_filter=GL_NEAREST;
	wrap_s=GL_REPEAT;
	wrap_t=GL_REPEAT;
	env_mode=GL_MODULATE;  //GL_REPLACE;
	make_mipmaps=false;
}

void Texture::releaseTexture()
{
	if (fname) {
		free(fname);
		fname=NULL;
	}
	if (loaded) {
		dance::MaterialManager->im.unLoadTexture(m_tex);
		m_tex = 0;
		loaded=false;
	}
	initParameters();
}


int Texture::reallyLoad() {

	int tmtex;
	
	tmtex=dance::MaterialManager->im.loadTexture(this, fname);
	if (tmtex>=0) {
		m_tex=tmtex;
		return DANCE_OK;
	} else {
		std::cout << "loadTexture failed. Handle this" << std::endl;
		return DANCE_ERROR;
	}
}





void Texture::ChangeSettings(GLuint mag_filter,
							 GLuint min_filter,
							 GLuint wrap_s,
							 GLuint wrap_t,
							 GLuint env_mode)
{
	this->mag_filter=mag_filter;
	this->min_filter=min_filter;
	this->wrap_s=wrap_s;
	this->wrap_t=wrap_t;
	this->env_mode=env_mode;


if (m_tex){
	glBindTexture(GL_TEXTURE_2D, m_tex);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, mag_filter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, min_filter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrap_s);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrap_t);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, env_mode);
}
else 
{
std::cout << "m_tex " << this->fname << " doesn't exist." << std::endl;
}

}

int Texture::MakeCurrent()
{
	if (!loaded) 
		if (reallyLoad()!=DANCE_OK) return -1;

	glBindTexture(GL_TEXTURE_2D, m_tex);
	loaded=true;
	return 0;
}



void Texture::getSettings(GLuint *mag_filter, GLuint *min_filter,GLuint *wrap_s,
	GLuint *wrap_t, GLuint *env_mode)
{
	if (mag_filter) *mag_filter=this->mag_filter;
	if (min_filter) *min_filter=this->min_filter;
	if (wrap_s) *wrap_s=this->wrap_s;
	if (wrap_t) *wrap_t=this->wrap_t;
	if (env_mode) *env_mode=this->env_mode;
}



// Writes the object properties to the file in PovRay format. PovRay recognizes the alpha values stored 
// in the image file. So, if you want to use transparency, make a PNG with an alpha channel.
int Texture::write_texture_povray(std::ofstream & file, const char* mapType, const char* transform) {
	

	file << "  pigment {\n";
	file << "    image_map {\n";
	file << "      ";
	
	if (!strcmp(extension,"bmp")) 
		file << "sys";
	else if (!strcmp(extension, "jpg"))
		file << "jpeg";
	else 
		file << extension;
	
	std::string fnamew=fname;
	#ifdef WIN32
	for (unsigned i=0; i<fnamew.length(); i++)
		if (fnamew[i]=='/') fnamew[i]='\\';
	#else
	for (unsigned i=0; i<fnamew.length(); i++)
		if (fnamew[i]=='\\') fnamew[i]='/';
	#endif
	
	
	file << " \"" << fnamew << "\"\n";
	file << ((wrap_s==GL_CLAMP || wrap_t==GL_CLAMP) ? "      once\n" : "");

	if (mapType != NULL)
		file << "      " << mapType << "\n";

	file << ((mag_filter == GL_LINEAR || min_filter == GL_LINEAR || min_filter == GL_LINEAR_MIPMAP_LINEAR \
		|| min_filter==GL_LINEAR_MIPMAP_NEAREST) ? "      interpolate 2" : "");
	file << "\n    }\n  }\n";

	if (transform != NULL)
		file << "   " << transform << "\n";

	file << "}\n\n";

#ifdef _DEBUG
	file << "/* Texture: " << this->fname << " ext (" << this->extension << ")\n";
	file << "Id opengl: " << m_tex << "\n";
	file << "(mag_filter, min_filter, wrap_s, wrap_t, env_mode): " << mag_filter << ", " \
		<< min_filter << ", " << wrap_s << ", " << wrap_t  << ", " << env_mode << "\n*/\n\n";
#endif
	return 0;
}


// Reads the texture properties from the file in PovRay format
int Texture::read_texture_povray(std::ifstream & file, char *path) {
	std::string tok, ext, tname;
	static char seps[]="{,<>}=\"";
	int interpol=0, once=0;
	GLuint mag_filter, min_filter,wrap_s, wrap_t, env_mode;
	char pathname[MAXPATHLENGTH];
	int exit_status=0;

	std::string curTok;
	// {
	curTok = my_C_tokenizer(file, seps); 
	if (curTok != "{") 
		return -2;

	// EXT
	ext=my_C_tokenizer(file, seps);
	if (ext=="") 
		return -2; 
	if (ext=="sys") 
		ext="bmp";

	// "
	curTok = my_C_tokenizer(file, seps); 
	if (curTok != "\"") 
		return -2; 

	// texture file name
	tname=my_C_tokenizer(file, seps);
	if (tname=="") return -2; 
	
	strcpy(pathname, tname.data());

	if (!fileReadable(pathname)) {
		buildPathName(pathname, path, (char *)tname.data());
		if (!fileReadable(pathname)) exit_status=-4;
	}
	// "
	curTok = my_C_tokenizer(file, seps); 
	if (curTok != "\"") return -2; 

	tok=my_C_tokenizer(file, seps);
	if (tok=="") return -2;
	while (tok!="}") {
		if (tok=="once")
			once=1;
		else if (tok=="interpolate") {
				if (my_C_tokenizer(file, seps)!="2") return -2;
				interpol=1;
		} else // unsupported keyword
			return -2;

		tok=my_C_tokenizer(file, seps);
		if (tok=="") return -2;
	}

	// }
	curTok = my_C_tokenizer(file, seps); 
	if (curTok !="}") return -2; 

	if (exit_status) return exit_status;

	// Convert to OpenGL

	char fnamew[MAXPATHLENGTH];
	unsigned int i = 0;
	for (i=0; i<strlen(pathname); i++)
		#ifdef WIN32
		if (pathname[i]=='/') 
			fnamew[i]='\\';
		#else
		if (pathname[i] == '\\')
			fnamew[i] = '/';
		#endif
		else 
			fnamew[i]=pathname[i];
	
	fnamew[i]=0;

	if (load(fnamew)) return -5;
	
	getSettings(&mag_filter, &min_filter, &wrap_s, &wrap_t, &env_mode);
	
	if (once) 
		wrap_s=wrap_t=GL_CLAMP;

	if (interpol) {
		mag_filter=GL_LINEAR;
		min_filter = GL_LINEAR;
	}

	ChangeSettings(mag_filter, min_filter, wrap_s, wrap_t, env_mode);
		
	return 0;
}


// Copies the path of the texture file name. -dest- can be NULL. Returns 0 if there is a file name
int Texture::getTextureFileName(char *dest) {
	if (dest) *dest=0;
	if (fname==NULL) return -1;
	if (dest) strcpy(dest, fname);
	return 0;
}
