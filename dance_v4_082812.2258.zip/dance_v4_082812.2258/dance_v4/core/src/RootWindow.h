/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef _ROOTWINDOW_
#define _ROOTWINDOW_

#include "opengl.h"
#include <fltk/Window.h>
#include <fltk/MenuBar.h>
#include "DanceWindow.h"
#include "SelectionWindow.h"
#include "SimControlWindow.h"
#include "CommandWindow.h"
#include "ParameterWindow.h"
#include "InstanceWindow.h"
#include "DMaterialManagerWindow.h"
#include "MaterialEditorWindow.h"
#include "RenderWindow.h"
#include "ViewManager.h"
#include "InteractionWindow.h"
#include "FeedbackWindow.h"
#include "SplashWindow.h"

#define NUMSESSIONPREFS 5

class DLLENTRY RootWindow : public fltk::Window
{
	public:
		RootWindow(int x, int y, int w, int h, const char* name);
		~RootWindow();

		void updateViewMenu(ViewManager* manager);
		void updateFileMenu();

		DanceWindow* danceWindow;
		ParameterWindow* parameterWindow;
		RootWindow* rootWindow;
		SimControlWindow* simControlWindow;
		CommandWindow* commandWindow;
		SelectionWindow* selectionWindow;
		InstanceWindow* instanceWindow;
		DMaterialManagerWindow* materialWindow;
		MaterialEditorWindow* materialEditorWindow;
		RenderWindow* renderWindow;
		InteractionWindow* interactionWindow;
		FeedbackWindow* feedbackWindow;
		SplashWindow* splashWindow;

		fltk::MenuBar* menubar;

		static void select_cb(fltk::Widget*, void*);
		static void multiviewToggle_cb(fltk::Widget*, void*);
		static void fitview_cb(fltk::Widget*, void*);
		static void targetselected_cb(fltk::Widget*, void*);
		static void selectcamera_cb(fltk::Widget*, void*);
		static void saveview_cb(fltk::Widget*, void*);
		static void consoleToggle_cb(fltk::Widget* o, void* p);
		static void resetAll_cb(fltk::Widget*, void*);
		static void loadSession_cb(fltk::Widget*, void*);
		static void loadRecentSession_cb(fltk::Widget*, void*);
		static void saveSession_cb(fltk::Widget*, void*);
		static void runScript_cb(fltk::Widget*, void*);
		static void quit_cb(fltk::Widget*, void*);
		static void helpabout_cb(fltk::Widget*, void*);
		static void feedback_cb(fltk::Widget*, void*);
		static void updateversion_cb(fltk::Widget*, void*);
		static void pluginsCreate_cb(fltk::Widget*, void*);
		static void pluginsSelect_cb(fltk::Widget*, void*);
		static void pluginsInteraction_cb(fltk::Widget*, void*);
		static void materialManager_cb(fltk::Widget*, void*);
		static void switchview_cb(fltk::Widget*, void*);
		static void destroywindow_cb(fltk::Widget*, void*);
		static void changeDir_cb(fltk::Widget*, void*);
		static void reloadscripts_cb(fltk::Widget*, void*);
		static void runUserScript_cb(fltk::Widget*, void*);
		static void rendercontinuous_cb(fltk::Widget*, void*);
		static void rendernow_cb(fltk::Widget*, void*);
		static void rendercurrent_cb(fltk::Widget*, void*);
		static void showSplash(void* data);
		static void hideSplash(void* data);
		static void getaboutinfo(std::vector<std::string>& info);
};
#endif
