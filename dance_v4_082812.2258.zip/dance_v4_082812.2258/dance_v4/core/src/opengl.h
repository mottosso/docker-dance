#ifndef _opengl_h_
#ifdef WIN32
#include "extgl.h"
#endif

#include "fltk/gl.h"
#ifdef __APPLE__
#include <OpenGL/glu.h>
#else

#include <GL/glu.h>
#endif
#include "fltk/glut.h"
#endif
