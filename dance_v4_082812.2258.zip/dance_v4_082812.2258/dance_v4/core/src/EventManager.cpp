#include "EventManager.h"

using namespace std;

EventManager::EventManager()
{
}

EventManager::~EventManager()
{
	clearAllEvents();
}

void EventManager::clearAllEvents()
{
	for (int x = this->cbEvents.size() - 1; x >= 0; x--)
		delete this->cbEvents[x];

	this->cbEvents.clear();
}

void EventManager::registerCollisionEvent(DObject* data, int priority, void (*collisioncb)(DObject*, DObject*, DObject*))
{
	EventCallback* c = new EventCallback();
	c->object = data;
	c->priority = priority;
	c->cb = collisioncb;

	// insert the callback based on priority
	for (vector<EventCallback*>::iterator iter = this->cbEvents.begin(); iter != this->cbEvents.end(); iter++)
	{
		if ((*iter)->priority > c->priority)
		{
			this->cbEvents.insert(iter, c);
			return;
		}
	}

	// priority is greater than all other priorities currently in callback list
	cbEvents.push_back(c);
}

void EventManager::unregisterCollisionEvent(DObject* o)
{
	for (vector<EventCallback*>::iterator iter = this->cbEvents.begin(); iter != this->cbEvents.end(); iter++)
	{
		if ((*iter)->object == o)
		{
			EventCallback* cb = (*iter);
			this->cbEvents.erase(iter);
			delete cb;

			return;
		}
	}
}

void EventManager::pushCollisionEvent(DObject* obj, DObject* obj2)
{
	for (vector<EventCallback*>::iterator iter = cbEvents.begin(); iter != cbEvents.end(); iter++)
	{ 
		(*iter)->cb((*iter)->object, obj, obj2);
	}
}
