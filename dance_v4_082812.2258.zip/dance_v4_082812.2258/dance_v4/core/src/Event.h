/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_EVENT_H_
#define	_EVENT_H_ 1

class DView;

class Event {
	public:
		INLINE void setView(DView* view) { m_view = view; };
		INLINE DView* getView() { return m_view; };
		INLINE void setEventType(int type) { m_eventType = type; };
		INLINE int getEventType() { return m_eventType; };

		DView* Window;
		int winDiffX, winDiffY;
		int winX, winY;
		int winWidth, winHeight;

		double winBasisX[3], winBasisY[3], winBasisZ[3];

		int buttonID;
		int buttonState;

		int pickNumber;
		int pickItem[256];

		INLINE void setWindow(DView *win, int x,	int y, int width, int height)
				{ Window = win;	winX = x; winY = y; winWidth = width; winHeight	= height; };
		INLINE void setWindowDiffs(int diffx, int diffy) { winDiffX = diffx; winDiffY =	diffy;};
		void setWindowBasis(double basisX[3], double basisY[3],	double basisZ[3])
				{ memcpy(winBasisX,basisX,3*sizeof(double));
				memcpy(winBasisY,basisY,3*sizeof(double));
				memcpy(winBasisZ,basisZ,3*sizeof(double)); };
		INLINE void setButtons(int ID, int state) { buttonID	= ID; buttonState = state; };
		void setSelected(int number, int item[256])
				{ pickNumber= number; memcpy(pickItem,item,256*sizeof(int));};
		int getSelected(int **item) { *item = pickItem; return (pickNumber); }; 

	private:
		DView *m_view;
		int m_eventType;

};
#endif
