#include "CollapsibleGroup.h"
#include <iostream>
#include <fltk/events.h>


const int CollapsibleGroup::COLLAPSED_HEIGHT = 18;

// The constructor has the same parameters as Fl_Group and calls the constructor to this parent class.
CollapsibleGroup::CollapsibleGroup(int xpos, int ypos, int width, int height, const char *l) : fltk::Group(xpos,ypos,width,height,l)
{
	if (l)
		origLabel = l;
	else
		origLabel = "";

	openLabel = "- ";
	openLabel.append(origLabel);
	closedLabel = "+ ";
	closedLabel.append(origLabel);

    expandedHeight = height;      // the height of the widget when not collapsed
    collapsed = false; // collapsed state of the group, true = collapsed, false = expanded
	label(openLabel.c_str());
	box(fltk::BORDER_BOX);
	align(fltk::ALIGN_INSIDE_TOPLEFT);
}


CollapsibleGroup::~CollapsibleGroup(void)
{
}

int CollapsibleGroup::handle(int e)
{
	if (e==fltk::PUSH && fltk::event_button()== fltk::LeftButton)  
    {
		int xloc = fltk::event_x();
		int yloc = fltk::event_y();

		if (xloc > COLLAPSED_HEIGHT || yloc > COLLAPSED_HEIGHT)
			return fltk::Group::handle(e);

		if (!collapsed)
		{
			collapsed=true;
			label(closedLabel.c_str());	
			for (int i=0; i<children(); ++i)
			{
				fltk::Widget* c = child(i);
				int height = c->h();
				c->hide();
			}
		}
		else
		{
			collapsed=false;
			label(openLabel.c_str());
			for (int i=0; i<children(); ++i)
			{
				fltk::Widget* c = child(i);
				int height = c->h();
				c->show();
			}	
		}
		return 1;
	}
	else
	{
		return fltk::Group::handle(e);
	}

}

void CollapsibleGroup::layout()
{	
	if (!collapsed)
	{
		int childrenHeight = 0;
		for (int i=0; i<children(); ++i)
		{
			fltk::Widget* c = child(i);
			c->show();
			int startY = c->y();
			int heightY = c->h();
			int sum = startY + heightY;
			if (sum > childrenHeight)
				childrenHeight = sum;
		}

		int desiredHeight = childrenHeight + COLLAPSED_HEIGHT;
		if (desiredHeight != h())
			h(childrenHeight + COLLAPSED_HEIGHT);
	}
	else
	{
		int desiredHeight = COLLAPSED_HEIGHT;
		if (desiredHeight != h())
			h(COLLAPSED_HEIGHT);
	}

	fltk::Group::layout();
}

static void revert(fltk::Style* s) {
	s->box_ = fltk::THIN_UP_BOX;
   s->color_ = fltk::GRAY75;
}

static fltk::NamedStyle style("Collapsible_Group", revert, &fltk::Group::default_style);
/** The default style for a CheckButton reverts to NO_BOX and a default glyph
 (the check mark to the left)
*/

fltk::NamedStyle* CollapsibleGroup::default_style = &::style;


