/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_DSIMULATORMANAGER_H_	
#define	_DSIMULATORMANAGER_H_	1

#include "defs.h"
#include "defs.h"
#include "DObjectList.h"
#include "DSimulator.h"
#include <vector>
#include "Timer.h"

class SimCallback
{
	public:
		DObject* data;
		void (*cb)(DObject*, double);
		int priority;
};

class DLLENTRY DSimulatorManager : public DObjectList
{
	public:
		const static int MODE_SIMULATION = 0;
		const static int MODE_PLAYBACK = 1;
		const static int STATE_RUNNING = 2;
		const static int STATE_NOT_RUNNING = 3;
		const static int STATE_PAUSED = 4;
		
		static DSimulator* CurrentSimulator;

		DSimulatorManager();
		~DSimulatorManager();

		void setDisplayTimeStep(double step);
		double getDisplayTimeStep();

		void setSimulationTimeStep(double step);
		double getSimulationTimeStep();

		void setPlaybackSpeed(double speed);
		double getPlaybackSpeed();

		void setCurrentTime(double);
		double getCurrentTime();

		void setEndTime(double time);
		double getEndTime();

		double getPlaybackTime();
		void setPlaybackTime(double time);

		double getPlaybackEndTime();
		void setPlaybackEndTime(double time);

		double getLastDisplayTime();
		void setLastDisplayTime(double t);

		void SetTime(double currTime, double displayTimeStep);

		int Step();
		void Start();
		void Pause();
		void Continue();
		void Stop();
		void end();
		void reset();

		void recordAllStates();

		void playbackStep();
		void playbackStart();
		void playbackPause();
		void playbackContinue();
		void playbackStop();

		void setLoopPlay(bool val);
		bool isLoopPlay();

		int getSimulationMode();
		void setSimulationMode(int val);
		int getSimulationState();
		void setSimulationState(int val);

		int m_autoMake ;
		int m_stopRequested ;
		int Simul(int argc, char **argv) ;
		void BuildSimulators() ;
		void RequestStop();

		int Command(int argc, char **argv);


		// bisection method variables
		double m_maxDistanceFromTolerance;
		double m_bisectionTolerance;
		bool m_savedOnce;
		bool m_hasPenetration;
		bool m_useBisection;
		double m_SimulationTimeStepUsed;
		double m_checkpointTime;

		// event callbacks
		void addSimStartCB(DObject* data, int priority, void (*stepcb)(DObject* data, double time));
		void addSimStopCB(DObject* data, int priority, void (*stepcb)(DObject* data, double time));
		void addBeforeSimStepCB(DObject* data, int priority, void (*stepcb)(DObject* data, double time));
		void addAfterSimStepCB(DObject* data, int priority, void (*stepcb)(DObject* data, double time));
		void addSimStepCB(DObject* data, int priority, void (*stepcb)(DObject* data, double time));
		void addSimEndCB(DObject* data, int priority, void (*stepcb)(DObject* data, double time));
		void addRecordStateCB(DObject* data, int priority, void (*stepcb)(DObject* data, double time));

		void removeAllCallbacks();
		void removeAllCallbacks(DObject* object);

		void removeSimStartCB(DObject* object);
		void removeSimStopCB(DObject* object);
		void removeBeforeSimStepCB(DObject* object);
		void removeAfterSimStepCB(DObject* object);
		void removeSimStepCB(DObject* object);
		void removeSimEndCB(DObject* object);
		void removeRecordStateCB(DObject* object);

		void setNeedSimInit(bool val);
		bool isNeedsSimInit();
		int calculatePlaybackEndTime();
		bool idle();

		DSimulator*	findSimulatorForSystem(DSystem* system);

	private:
		void StepInternal();

		double m_CurrentTime;
		double m_DisplayTimeStep;
		double m_SimulationTimeStep ;
		double m_EndTime ;
		double m_lastDisplayTime;
		double m_playbackTime;
		double m_playbackSpeed;
		double m_playbackEndTime;
		double m_playbackStartCounter;
		bool m_loopPlay;
		Timer m_timer;

		int m_state;
		int m_mode;
		bool m_needsSimInit;
		bool m_firstTime;

		std::vector<SimCallback*> cbSteps;
		std::vector<SimCallback*> cbBeforeSteps;
		std::vector<SimCallback*> cbAfterSteps;
		std::vector<SimCallback*> cbSimStarts;
		std::vector<SimCallback*> cbSimStops;
		std::vector<SimCallback*> cbSimEnds;
		std::vector<SimCallback*> cbRecordStates;

} ;

#endif
