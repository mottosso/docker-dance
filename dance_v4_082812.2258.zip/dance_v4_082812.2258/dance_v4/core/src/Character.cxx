/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

***************************************************************
******General License Agreement and Lack of Warranty ***********
****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment
-----------------------------------------
AUTHOR:
Ari Shapiro (ashapiro@cs.ucla.edu)
ORIGINAL AUTHORS: 
Victor Ng (victorng@dgp.toronto.edu)
Petros Faloutsos (pfal@cs.ucla.edu)
CONTRIBUTORS:
Yong Cao (abingcao@cs.ucla.edu)
Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "Character.h" 


#include "opengl.h"
#include "danceInterp.h"
#include "myMath.h"
#include "matrix3x3.h"
#include "arbMatrix.h"
#include "CharacterWindow.h"
#include "dance.h"
#include "DConnection.h"
#include "DConnectionManager.h"
#include <fstream>
#include <sstream>
#include <iostream>

//#include "Joint.h"
//#include "CRSpline3D.h" 

using namespace std;

void Ellipse3D(float a, float b, float c) 
{ 
	float PI = 3.141593f; 
	float z2 = 0.0f, d2 = 0.0f; 
	float z1 = 0.0f, d1 = 0.0f; 
	int step = 2; 
	int slice = 20; 
	float phi = PI/slice; 

	z1 = c; 
	d1 = 0; 

	for(int i=step; i<=slice; i+=step) 
	{ 
		z2 = c*cos(i*phi); 
		d2 = sqrt(1-pow(z2/c,2)); 

		glBegin(GL_QUAD_STRIP); 
		for(int j=2*slice; j>=0; j-=step) 
		{ 
			glNormal3f(cos(phi*j)*sin(phi*i), sin(phi*j)*sin(phi*i), cos(phi*i)); 
			glVertex3f(a*d2*cos(phi*j), b*d2*sin(phi*j), z2); 

			glNormal3f(cos(phi*j)*sin((i-step)*phi), sin(phi*j)*sin((i-step)*phi), cos((i-step)*phi)); 
			glVertex3f(a*d1*cos(phi*j), b*d1*sin(phi*j), z1); 
		} 
		glEnd(); 

		z1 = z2; 
		d1 = d2; 
	} 

}

Character::Character() : PlugIn()
{
	m_root = NULL;

	m_showJoints = this->createBoolAttribute("showjoints", true, true, "Display", 30);
	m_showBones = this->createBoolAttribute("showbones",  true, true, "Display", 40);
	m_showBonesAsLines = this->createBoolAttribute("showbonesaslines",  false, true, "Display", 45);
	m_jointColor = this->createVec3Attribute("jointcolor", 1.0, 1.0, 1.0, true, "Display", 50);
	m_boneColor = this->createVec3Attribute("bonecolor", 1.0, 1.0, 1.0, true, "Display", 60);
	m_boneWidth = this->createDoubleAttribute("bonewidth", 1.0, true, "Display", 90);
	m_boneWidth->setMin(0.0001);
	m_jointSize = this->createDoubleAttribute("jointsize", 1.0 / 80.0, true, "Display", 100);
	m_jointSize->setMin(0.0001);
	m_selectedJoint = this->createStringAttribute("joint", "", true, "Display", 110);
	m_nameFromFile = this->createStringAttribute("namefromfile", "", true, "Display", 120);
	m_file = this->createStringAttribute("file", "", true, "Display", 120);
	m_file = this->createStringAttribute("file2", "", true, "Display", 120);
	m_desiredTime = this->createDoubleAttribute("desiredtime", 0.0, true, "Display", 125);
	m_time = this->createDoubleAttribute("time", 0.0, true, "Display", 130);
	m_offsetTime = this->createDoubleAttribute("offsettime", 0.0, true, "Display", 135);
	m_time->getAttributeInfo()->setHidden(true);

	m_cycle = this->createBoolAttribute("cycle", false, true, "Display", 140);
	m_useInterpolation = this->createBoolAttribute("useinterpolation", true, true, "Display", 30);

	m_offset[0] = this->createDoubleAttribute("translatex", 0.0, true, "Transformations", 250);
	m_offset[1] = this->createDoubleAttribute("translatey", 0.0, true, "Transformations", 260);
	m_offset[2] = this->createDoubleAttribute("translatez", 0.0, true, "Transformations", 270);

	m_rotation[0] = this->createDoubleAttribute("rotatex", 0.0, true, "Transformations", 280);
	m_rotation[1] = this->createDoubleAttribute("rotatey", 0.0, true, "Transformations", 290);
	m_rotation[2] = this->createDoubleAttribute("rotatez", 0.0, true, "Transformations", 300);

	m_scale = this->createDoubleAttribute("scale", 1.0, true, "Transformations", 310);



	m_drawType = Character::POINTS;
	m_height = -1.0;
	m_width = -1.0;
	setIsBVH(true);
	setIsPoints(false);
	setMatrixCalculated(false);
	setCombinedFrame(-1);
	setShowPoints(false);
	setAdjustBoneLengths(false);
	setRotation(0,0,0);
	m_time->setValue(0);
	m_gui = NULL;

	setShowJoints(true);
	setShowBones(true);
	Vector boneColor = {.8, .8, .8};
	setBoneColor(boneColor);
	Vector jointColor = {.3, .3, .3};
	setJointColor(jointColor);
	setBoneWidth(1.0);
	setJointSize(1.0 / 80.0);
	
}

Character::~Character()
{
	if (m_gui)
		delete m_gui;
}

void Character::setRoot(CharJoint* root)
{
	m_root = root;
	if (root)
	{
		root->setParent(NULL);
	}
}

CharJoint* Character::getRoot()
{
	return m_root;
}

void Character::setDrawingType(int type)
{
	m_drawType = type;
}

int Character::getDrawingType()
{
	return m_drawType;
}

void Character::drawJoint(double time, CharJoint* joint, bool useInterpolation)
{
	// if this is the root, put an initial rotation, if any
	double matrix[4][4];
	joint->getTransMatrix(matrix);

	if (joint->getParent() == NULL)
	{
		if (this->isPoints())
		{
			glPushMatrix();
			Vector pos;
			joint->getPoint(time, pos);

			// draw the bones from the parent joint to this joint
			CharJoint* parent = joint->getParent();
			// skip over fixed joints
			if (parent != NULL && parent->getNumChannels() == 0)
				parent = parent->getParent();
			if (parent != NULL)
			{
				Vector parentPos;
				parent->getPoint(time, parentPos);
				if (isShowBones())
				{
					glColor3dv(m_boneColor->getValue());
					glBegin(GL_LINES);
					glVertex3d(pos[0], pos[1], pos[2]);
					glVertex3d(parentPos[0], parentPos[1], parentPos[2]);
					glEnd();
				}
			}
			// show the end effector
			if (joint->isEndEffector())
			{
				Vector endEffectorPos;
				joint->getEndEffectorPoint(time, endEffectorPos);
				if (isShowBones())
				{
					glColor3dv(m_boneColor->getValue());
					glBegin(GL_LINES);
					glVertex3d(endEffectorPos[0], endEffectorPos[1], endEffectorPos[2]);
					glVertex3d(pos[0], pos[1], pos[2]);
					glEnd();
				}
			}
			glPopMatrix();
		}
		else // angle representation
		{
			//danceInterp::OutputMessage("Joint %s has %d DOFs...", joint->getName(), joint->getNumChannels());
			joint->calcTransMatrix(time, useInterpolation);
			// add in any translation for cyclic behavior
			if (joint->getCharacter()->isCycle())
			{
				Vector timeOffset;
				joint->getCharacter()->getGlobalOffset(timeOffset);
				joint->addOffset(timeOffset);
			}

			// draw the bones from the parent joint to this joint
			if (joint->getParent() != NULL)
			{
				if (isShowBones())
				{
					/*
					glColor3dv(m_boneColor->getValue());
					glBegin(GL_LINES);
					glVertex3d(0.0, 0.0, 0.0);
					Vector point = {0.0, 0.0, 0.0};
					transformPoint_mat(point, matrix);

					//danceInterp::OutputMessage("BONE START: %f %f %f", point[0], point[1], point[2]);
					glVertex3d(point[0], point[1], point[2]);
					glEnd();
					*/
				}
			}
			else
			{
			}
		}

		Vector rotation;
		this->getRotation(rotation);
		if (rotation[0] != 0.0)
			glRotated(rotation[0], 1.0, 0.0, 0.0); // x rotation
		if (rotation[1] != 0.0)
			glRotated(rotation[1], 0.0, 1.0, 0.0); // y rotation
		if (rotation[2] != 0.0)
			glRotated(rotation[2], 0.0, 0.0, 1.0); // z rotation
	}
	//if we are drawing points, draw them here
	//PACO: don't used>	float oldPointSize[3];

	if (true) // draw all joints, even fixed joints
	{
		if (this->isPoints())
		{
			if (joint->getNumChannels() > 0)
			{
				glPopMatrix();
				//PACO: don't used>			glPointSize(oldPointSize[0]);
			}
			glPopMatrix();
		}
		else // angle representation
		{
			//danceInterp::OutputMessage("Joint %s has %d DOFs...", joint->getName(), joint->getNumChannels());
			CharJoint* parent = joint->getParent();
			if (parent != NULL) // already been calculated if root joint
				joint->calcTransMatrix(time, useInterpolation);
			// draw the bones from the parent joint to this joint
			if (parent != NULL)
			{
				if (isShowBones())
				{
					if (this->isSelected())
						glColor3d(1.0, 1.0, 0.0);
					else
						glColor3dv(m_boneColor->getValue());
				
					if (m_showBonesAsLines->getValue())
					{
						// draw a line indicating the bone
						glBegin(GL_LINES);
						glVertex3d(0.0, 0.0, 0.0);
						Vector point = {0.0, 0.0, 0.0};
						transformPoint_mat(point, matrix);
						glVertex3d(point[0], point[1], point[2]);
						glEnd();
					}
					else
					{
						// draw a pyramid indicating the bone				
						
						Vector parentPos = { 0, 0, 0 };
						Vector localPos = { matrix[3][0], matrix[3][1], matrix[3][2] };
						Vector diff;
						VecSubtract(diff, localPos, parentPos);

						glPushMatrix();

						// determine the orientation to the joint
						VectorObj up(0, 1, 0);
						VectorObj jointDir(diff[0], diff[1], diff[2]);
						jointDir.normalize();
						VectorObj axis;
						if (fabs((up - jointDir).length()) < .00001)
						{
							axis.assign(0, 1, 0);
						}
						else
						{
							axis = up.cross(jointDir);
							if (axis.length() == 0)
								axis.assign(1, 0, 0);
							else
								axis.normalize();
						}
						double angle = -acos(up.dot(jointDir));
						
						Quaternion q(axis.data(), angle);
						Matrix3x3 rotMat;
						q.toMatrix(rotMat);
						double rotMatrix[4][4];
						setIdentMat(&rotMatrix[0][0], 4);
						for (int r = 0; r < 3; r++)
							for (int c = 0; c < 3; c++)
								rotMatrix[r][c] = rotMat[r][c];
						glMultMatrixd(&rotMatrix[0][0]);
						
						double length = (double) VecLength(diff, 3);
						double m[4][4];
						setIdentMat(&m[0][0], 4);
						m[0][0] = 1.0;
						m[1][1] = length;
						m[2][2] = 1.0;
						glMultMatrixd(&m[0][0]);
						
						double boneWidth = m_boneWidth->getValue();
						/*
						glEnable(GL_LIGHTING);
						glPolygonMode(GL_FRONT, GL_LINE);
						glBegin(GL_TRIANGLES);
						glVertex3d(.5 * boneWidth, 0.0, -.5 * boneWidth);
						glVertex3d(-.5 * boneWidth, 0.0, .5 * boneWidth);
						glVertex3d(-.5 * boneWidth, 0.0, -.5 * boneWidth);
						glEnd();

						glBegin(GL_TRIANGLES);
						glVertex3d(.5 * boneWidth, 0.0, -.5 * boneWidth);
						glVertex3d(.5 * boneWidth, 0.0, .5 * boneWidth);
						glVertex3d(-.5 * boneWidth, 0.0, .5 * boneWidth);
						glEnd();

						glBegin(GL_TRIANGLES);
						glVertex3d(.5 * boneWidth, 0.0, .5 * boneWidth);
						glVertex3d(0, 1.0, 0);
						glVertex3d(.5 * boneWidth, 0.0, -.5 * boneWidth);
						glEnd();

						glBegin(GL_TRIANGLES);
						glVertex3d(-.5 * boneWidth, 0.0, .5 * boneWidth);
						glVertex3d(0, 1.0, 0);
						glVertex3d(.5 * boneWidth, 0.0, .5 * boneWidth);
						glEnd();

						glBegin(GL_TRIANGLES);
						glVertex3d(.5 * boneWidth, 0.0, -.5 * boneWidth);
						glVertex3d(0, 1.0, 0);
						glVertex3d(-.5 * boneWidth, 0.0, -.5 * boneWidth);
						glEnd();

						glBegin(GL_TRIANGLES);
						glVertex3d(-.5 * boneWidth, 0.0, -.5 * boneWidth);
						glVertex3d(0, 1.0, 0);
						glVertex3d(-.5 * boneWidth, 0.0, .5 * boneWidth);
						glEnd();
						*/


						glBegin(GL_LINE_LOOP);
						glVertex3d(-.5 * boneWidth, 0.0, -.5 * boneWidth);
						glVertex3d(-.5 * boneWidth, 0.0, .5 * boneWidth);
						glVertex3d(.5 * boneWidth, 0.0, .5 * boneWidth);
						glVertex3d(.5 * boneWidth, 0.0, -.5 * boneWidth);
						glEnd();
						glBegin(GL_LINES);
						glVertex3d(-.5 * boneWidth, 0.0, -.5 * boneWidth);
						glVertex3d(0, 1.0, 0);
						glEnd();

						glBegin(GL_LINES);
						glVertex3d(-.5 * boneWidth, 0.0, .5 * boneWidth);
						glVertex3d(0, 1.0, 0);
						glEnd();

						glBegin(GL_LINES);
						glVertex3d(.5 * boneWidth, 0.0, .5 * boneWidth);
						glVertex3d(0, 1.0, 0);
						glEnd();

						glBegin(GL_LINES);
						glVertex3d(.5 * boneWidth, 0.0, -.5 * boneWidth);
						glVertex3d(0, 1.0, 0);
						glEnd();
						glPopMatrix();
					}					
				}
			}
			else
			{
			}

			// draw the joint

			glPushMatrix();
			glMultMatrixd(&matrix[0][0]);

			// draw any end effector
			if (joint->isEndEffector())
			{
				Vector endOffset;
				joint->getEndEffectorOffset(endOffset);

				// draw the bones for the end effector
				if (isShowBones())
				{	
					glBegin(GL_LINES);
					if (this->isSelected())
						glColor3d(1.0, 1.0, 0.0);
					else
						glColor3dv(m_boneColor->getValue());
					glVertex3f(0.0, 0.0, 0.0);
					//danceInterp::OutputMessage("END EFFECTOR START: %f %f %f", endOffset[0], endOffset[1], endOffset[2]);
					glVertex3d(endOffset[0], endOffset[1], endOffset[2]);
					glEnd();
				}
			}
		}
	}
	
	// show the children
	int numChildren = joint->getNumChildren();

	for (int c = 0; c < numChildren; c++)
		drawJoint(time, joint->getChild(c), useInterpolation);

	if (!this->isPoints())
			glPopMatrix();
}

void Character::draw(double time, bool useInterpolation)
{
	glPushAttrib(GL_ENABLE_BIT | GL_CURRENT_BIT);
	//	danceInterp::OutputMessage("Now drawing %s...\n", getName());
	// display the character via transformation matrices
	CharJoint* root = getRoot();
	if (root == NULL)
		return;

	// if we are drawing passed the last time of the character,
	// then draw the final position only
	double origEndTime = this->getRoot()->getNumFrames() * this->getRoot()->getFrameTime();
	double endTime = origEndTime + m_offsetTime->getValue();
	// determine the parametric time
	if (this->isCycle())
	{
		double pTime = (time - m_offsetTime->getValue()) / origEndTime;
		int numCycles = int(pTime);
		time = pTime - double(numCycles);
		Vector offset;
		this->getCycleOffset(offset);
		VecNumMul(offset, offset, (double) numCycles);
		this->setGlobalOffset(offset);
	}
	if (time > endTime)
		time = endTime;

	// save the old line width
	GLfloat oldLineWidth;
	glGetFloatv(GL_LINE_WIDTH, &oldLineWidth);
	//glLineWidth((GLfloat)this->m_boneWidth->getValue());

	GLboolean smoothing = glIsEnabled(GL_LINE_SMOOTH);
	if (!smoothing)
		glEnable(GL_LINE_SMOOTH);

	glPushMatrix();
	glDisable(GL_LIGHTING);
	drawJoint(time, root, useInterpolation);
	glEnable(GL_LIGHTING);
	glPopMatrix();

	glLineWidth(oldLineWidth);

	if (!smoothing)
		glDisable(GL_LINE_SMOOTH);
	glPopAttrib();	

}

int Character::getNumDOF()
{
	if (m_root == NULL)
		return 0;
	else
		return getNumDOFRecurse(m_root);
}

int Character::getNumDOFRecurse(CharJoint* joint)
{
	int dof = joint->getNumChannels();
	int numChildren = joint->getNumChildren();
	for (int x = 0; x < numChildren; x++)
	{
		dof += getNumDOFRecurse(joint->getChild(x));
	}

	return dof;
}

CharJoint* Character::getCharJoint(int index, int &dof)
{
	int startIndex = 0;
	return getDOFIndexRecurse(m_root, index, startIndex, dof);
}

int Character::getIndex(CharJoint* joint, int dof)
{
	return joint->getCharacterIndex() + dof;
}

int Character::getNumJoints()
{
	if (1)
	{
		return m_allJoints.size();
	}
	else
	{
		int count = 0;
		int numDOF = getNumDOF();
		CharJoint* old = NULL;
		CharJoint* temp = NULL;
		for (int x = 0; x < numDOF; x++)
		{
			int d;
			temp = getCharJoint(x, d);
			if (temp != old)
			{
				count++;
				old = temp;
			}
		}
		return count;
	}
}

CharJoint* Character::getJointByName(char* name)
{
	if (m_allJoints.size() == 0)
		this->recalculateJointList();

	for (unsigned int x = 0; x < m_allJoints.size(); x++)
	{
		if (strcmp(m_allJoints[x]->getName(), name) == 0)
			return m_allJoints[x];
	}

	return NULL;
}


CharJoint* Character::getJointByIndex(int jointNum)
{
	if (m_allJoints.size() == 0)
		this->recalculateJointList();

	if ((unsigned int) jointNum < m_allJoints.size())
		return m_allJoints[jointNum];
	else
		return NULL;

	/*	
	int count = -1;
	int numDOF = getNumDOF();
	CharJoint* old = NULL;
	CharJoint* temp = NULL;
	for (int x = 0; x < numDOF; x++)
	{
	int d;
	temp = getCharJoint(x, d);
	if (temp != old)
	{
	count++;
	old = temp;
	if (count == jointNum)
	return temp;
	}
	}
	return NULL;
	*/

}

CharJoint* Character::getDOFIndexRecurse(CharJoint* joint, int desiredIndex, int &startIndex, int &cur)
{
	int numChannels = joint->getNumChannels(); 
	if (startIndex + numChannels > desiredIndex)
	{
		cur = desiredIndex - startIndex;
		return joint;
	}
	else
	{
		int numChildren = joint->getNumChildren();
		startIndex += numChannels;
		for (int c = 0; c < numChildren; c++)
		{
			CharJoint* childJoint = getDOFIndexRecurse(joint->getChild(c), desiredIndex, startIndex, cur);
			if (childJoint != NULL)
				return childJoint;
		}
	}

	return NULL;
}

int Character::getNumFrames()
{
	if (m_root == NULL)
		return 0;
	else
		return m_root->getNumFrames();
}

void Character::setOffset(double x, double y, double z)
{
//	m_offset[0] = x;
//	m_offset[1] = y;
//	m_offset[2] = z;

	danceInterp::OutputMessage("Offsetting %s by (%f %f %f)...\n", getName(), x , y, z);
	if (m_root == NULL)
	{
		danceInterp::OutputMessage("Cannot offset character %s, no root found...\n", getName());
	}
	/*
	int channels[6];
	int numChannels = m_root->getChannels(channels);
	for (int f = 0; f < m_root->getNumFrames(); f++)
	{
	double frames[6];
	m_root->getFrames(f, frames);

	for (int i = 0; i < numChannels; i++)
	{
	if (channels[i] == CharJoint::XPOSITION)
	{
	m_root->setFrame(f, frames[i] + x, i);
	}
	else if (channels[i] == CharJoint::YPOSITION)
	{
	m_root->setFrame(f, frames[i] + y, i);
	}
	else if (channels[i] == CharJoint::ZPOSITION)
	{
	m_root->setFrame(f, frames[i] + z, i);
	}

	}
	}
	*/

	calcWorldTransMatrix();
}

void Character::getOffset(Vector vec)
{
	vec[0] = m_offset[0]->getValue();
	vec[1] = m_offset[1]->getValue();
	vec[2] = m_offset[2]->getValue();
}

void Character::setRotation(double xrot, double yrot, double zrot)
{
	//m_rotation[0] = xrot;
	//m_rotation[1] = yrot;
	//m_rotation[2] = zrot;

	Matrix3x3 rx;
	Matrix3x3 ry;
	Matrix3x3 rz;
	if (xrot != 0.0) 
		rx.setRotateMatrix(Matrix3x3::X, xrot * M_PI / 180.0);
	else
		rx.identity();
	if (yrot != 0.0) 
		ry.setRotateMatrix(Matrix3x3::Y, yrot * M_PI / 180.0);
	else
		ry.identity();
	if (zrot != 0.0) 
		rz.setRotateMatrix(Matrix3x3::Z, zrot * M_PI / 180.0);
	else
		rz.identity();

//	setIdentMat(m_matrixRotation);
	setIdentMat(&m_matrixRotation[0][0], 4);
	Matrix3x3 result = rz * ry * rx;
	result.to4x4(m_matrixRotation);

	danceInterp::OutputMessage("Rotation %s by (%f %f %f)...\n", getName(), xrot , yrot, zrot);
	if (m_root == NULL)
	{
		danceInterp::OutputMessage("Cannot rotate character %s, no root found...\n", getName());
	}
	
	calcWorldTransMatrix();
}

void Character::getRotation(Vector vec)
{
	vec[0] = m_rotation[0]->getValue();
	vec[1] = m_rotation[1]->getValue();
	vec[2] = m_rotation[2]->getValue();
}

void Character::center()
{
	if (m_root == NULL)
	{
		danceInterp::OutputMessage("Cannot offset character %s, no root found...\n", getName());
		return;
	}

	if (this->getNumFrames() <= 0)
	{
		danceInterp::OutputMessage("Cannot offset character %s, no frames found...\n", getName());
		return;
	}

	// get the global offset
	double x = 0.0, y = 0.0, z = 0.0;
	int channels[6];
	double frames[6];
	m_root->getFrames(0, frames);
	for (int i = 0; i < m_root->getNumChannels(); i++)
	{
		if (channels[i] == CharJoint::XPOSITION)
		{
			x = frames[i];
		}
		else if (channels[i] == CharJoint::YPOSITION)
		{
			y = frames[i];
		}
		else if (channels[i] == CharJoint::ZPOSITION)
		{
			z = frames[i];
		}
	}

	setOffset(-x, -y, -z);
	
	calcWorldTransMatrix();
}

void Character::setScale(double val)
{
	//m_scale = val;
	danceInterp::OutputMessage("Scaling %s by %f...\n", getName(), val);
	if (m_root == NULL)
	{
		danceInterp::OutputMessage("Cannot scale character %s, no root found...\n", getName());
	}

	/*	// scale the motion
	int channels[6];
	int numChannels = m_root->getChannels(channels);
	for (int f = 0; f < m_root->getNumFrames(); f++)
	{
	double frames[6];
	m_root->getFrames(f, frames);

	for (int i = 0; i < numChannels; i++)
	{
	if (channels[i] == CharJoint::XPOSITION)
	{
	m_root->setFrame(f, frames[i] * val, i);
	}
	else if (channels[i] == CharJoint::YPOSITION)
	{
	m_root->setFrame(f, frames[i] * val, i);
	}
	else if (channels[i] == CharJoint::ZPOSITION)
	{
	m_root->setFrame(f, frames[i] * val, i);
	}

	}
	}
	// scale the character
	scaleRecurse(m_root, val);
	*/
	// recalculate the height of the character
	m_height = -1.0;
	this->getHeight();

}

double Character::getScale()
{
	return m_scale->getValue();
}

void Character::scaleRecurse(CharJoint* joint, double val)
{
	Vector o;
	joint->getOffset(o);
	joint->setOffset(o[0] * val, o[1] * val, o[2] * val);
	if (joint->isEndEffector())
	{
		Vector e;
		joint->getEndEffectorOffset(e);
		joint->setEndEffectorOffset(e[0] * val, e[1] * val, e[2] * val);
	}
	int numChildren = joint->getNumChildren();
	for (int x = 0; x < numChildren; x++)
	{
		scaleRecurse(joint->getChild(x), val);
	}

}

Character* Character::copy(char* name)
{
	return this->copy(name, 0, m_root->getNumFrames() - 1);

	/*	Character* c = new Character();
	c->setName(name);
	c->setDrawingType(getDrawingType());
	c->setIsBVH(this->isBVH());
	c->setCombinedFrame(this->getCombinedFrame());

	Vector boneColor;
	this->getBoneColor(boneColor);
	c->setBoneColor(boneColor);
	Vector jointColor;
	this->getJointColor(jointColor);
	c->setJointColor(jointColor);
	c->setShowBones(this->isShowBones());
	c->setShowJoints(this->isShowJoints());
	c->setShowPoints(this->isShowPoints());
	c->setBoneWidth(this->getBoneWidth());
	c->setIsPoints(this->isPoints());
	c->setShowTrajectories(this->isShowTrajectories());

	CharJoint* rootCopy = m_root->copy(c, NULL, 0, );
	c->setRoot(rootCopy);
	copyRecurse(m_root, rootCopy, 0, m_root->getNumFrames() - 1);

	c->recalculateJointList();

	return c;
	*/
}

void Character::copyFrames(Character* to, int frameNum)
{
	for (int j = 0; j < this->getNumJoints(); j++)
	{
		CharJoint* fromJoint = this->getJointByIndex(j);
		CharJoint* toJoint = to->getJointByIndex(j);
		if (fromJoint && toJoint)
		{
			toJoint->addFrame(fromJoint->getFrames(frameNum));
		}
	}
}

Character* Character::copy(char* name, int startFrame, int endFrame)
{
	Character* c = new Character();
	c->setName(name);
	c->setDrawingType(getDrawingType());
	c->setIsBVH(this->isBVH());
	// don't copy the combined frame, if we are copying only a part of the motion
	if (startFrame != 0 || endFrame != m_root->getNumFrames() - 1)
		c->setCombinedFrame(-1);
	else
		c->setCombinedFrame(this->getCombinedFrame());


	Vector boneColor;
	this->getBoneColor(boneColor);
	c->setBoneColor(boneColor);
	Vector jointColor;
	this->getJointColor(jointColor);
	c->setJointColor(jointColor);
	c->setShowBones(this->isShowBones());
	c->setShowJoints(this->isShowJoints());
	c->setBoneWidth(this->getBoneWidth());
	c->setShowPoints(this->isShowPoints());
	c->setIsPoints(this->isPoints());

	CharJoint* rootCopy = m_root->copy(c, NULL, startFrame, endFrame);
	c->setRoot(rootCopy);
	copyRecurse(m_root, rootCopy, startFrame, endFrame);

	c->recalculateJointList();

	return c;
}

void Character::copyRecurse(CharJoint* parent, CharJoint* parentCopy, int startFrame, int endFrame)
{
	int numChildren = parent->getNumChildren();
	for (int x = 0; x < numChildren; x++)
	{
		CharJoint* j = parent->getChild(x)->copy(parentCopy->getCharacter(), parentCopy, startFrame, endFrame);
		parentCopy->addChild(j);
		copyRecurse(parent->getChild(x), j, startFrame, endFrame);
	}
}

void Character::saveASFAMC(char* filename, char* filename2)
{
	ofstream file (filename, ios::out | ios::binary);
	ofstream file2 (filename2, ios::out | ios::binary);

	saveASFAMC(file, file2);

	file.close();
	file2.close();
}

void Character::saveASFAMC(std::ofstream& file, std::ofstream& file2)
{

	// create the meta data .asf file
	file << "# ASF/AMC file generated by DANCE\n";
	file << "# -------------------------------\n";
	file << ":version 1.10\n";
	file << ":name VICON\n";
	file << ":units\n";
	file << " mass 1.0\n";
	file << " length 0.45\n";
	file << " angle deg\n";
	file << ":documentation .asf/.amc automatically generated from DANCE\n";
	file << ":root\n";

	std::vector<CharJoint*> needDummy;
	if (this->isBVH())
	{
		// The asf format handles offsets differently than bvh formats - all child joints
		// in asf format much start at the same location as all their siblings. This
		// differs from bvh format, where child joints can start at any arbitrary location.
		// To accomodate this, dummy joints will be added to the skeleton when a joint
		// has multiple children. The offsets from the parent to the dummy joints will be zero,
		// while each dummy joint will contain the actual offset to the children.
		// The dummy joints will later be removed.
		int numJoints = this->getNumJoints();
		for (int j = 1; j < numJoints; j++)
		{
			CharJoint* joint = this->getJointByIndex(j);
			CharJoint* parent = joint->getParent();
			if (parent)
			{
				int numChildren = parent->getNumChildren();
				if (numChildren > 1)
				{
					// mark the current joint as needing a dummy parent
					needDummy.push_back(joint);
				}
			}
		}

		for (int x = 0; x  < needDummy.size(); x++)
		{
			CharJoint* joint = needDummy[x];
			std::stringstream strstr;
			strstr << joint->getName() << "_Dummy_"; // let's hope that there are no joints named xxx_Dummy_
			CharJoint* dummy  = new CharJoint(strstr.str().c_str());
			dance::AllGenericPlugins->add(dummy);
			CharJoint* parent = joint->getParent();
			dance::connectionManager->makeConnection(parent, "jointchild", dummy);
			dance::connectionManager->removeConnection(parent, "jointchild", joint);
			dance::connectionManager->makeConnection(dummy, "jointchild", joint);
		}
		this->recalculateJointList();
	}

	CharJoint* root = this->getJointByIndex(0);
	if (root != NULL)
	{
		file << " order ";
		int channels[6];
		root->getChannels(channels);
		int numChannels = root->getNumChannels();
		for (int c = 0; c < numChannels; c++)
		{
			if (channels[c] == CharJoint::XPOSITION)
			{
				file << "tx ";
			}
			else if (channels[c] == CharJoint::YPOSITION)
			{
				file << "ty ";
			}
			else if (channels[c] == CharJoint::ZPOSITION)
			{
				file << "tz ";
			}
			else if (channels[c] == CharJoint::XROTATION)
			{
				file << "rx ";
			}
			else if (channels[c] == CharJoint::YROTATION)
			{
				file << "ry ";
			}
			else if (channels[c] == CharJoint::ZROTATION)
			{
				file << "rz ";
			}
		}
		file << "\n";
		// offset axis
		// axis is assumed to be in XYZ order

		file << " axis XYZ" << "\n";

		
		// if this file was originally a bvh file, then there won't be an original root joint
		if (this->isBVH())
		{
			file << " position 0 0 0 \n";
			file << " orientation 0 0 0\n";
		}
		else
		{
			Vector offset;
			root->getOffset(offset);
			file << " position " << offset[0] * getScale()<< " " << offset[1] * getScale()<< " " << offset[2] * getScale()<< "\n";
			Vector axis;
			root->getAxis(axis);
			file << " orientation " << axis[0] * 180.0 / M_PI << " " << axis[1] * 180.0 / M_PI << " " << axis[2] * 180.0 / M_PI << "\n";
		}
	}

	file << ":bonedata\n";
	int numJoints = this->getNumJoints();
	for (int j = 0; j < numJoints; j++)
	{
		file << " begin\n";
		CharJoint* joint = this->getJointByIndex(j);
		file << "  id " << j << "\n";
		file << "  name " << joint->getName() << "\n";
		
		
		if (this->isBVH())
		{
			// original bvh files do not have a length, use offset instead
			int numChildren = joint->getNumChildren();
			if (numChildren > 0)
			{
				CharJoint* child = joint->getChild(0);
				Vector offset;
				child->getOffset(offset);
				double length = VecLength(offset);
				VecNormalize(offset);
				file << "  direction " << offset[0] * getScale()<< " " << offset[1] * getScale()<< " " << offset[2] * getScale() << "\n";
				file << "  length " << length << "\n";
			}
			else
			{
				Vector endEffector;
				joint->getEndEffectorOffset(endEffector);
				double length = VecLength(endEffector);
				VecNormalize(endEffector);
				file << "  direction " << endEffector[0] * getScale()<< " " << endEffector[1] * getScale()<< " " << endEffector[2] * getScale()<< "\n";
				file << "  length " << length << "\n";
			}
		} 
		else
		{
			double length = joint->getLength();
			Vector direction;
			joint->getDirection(direction);
			for (int d = 0; d < 3; d++)
				if (fabs(direction[d]) < .0001)
					direction[d] = 0.0;
			file << "  direction " << direction[0] * getScale()<< " " << direction[1] * getScale()<< " " << direction[2] * getScale()<< "\n";
			file << "  length " << length << "\n";
		}
		
		Vector axis;
		joint->getAxis(axis);
		file << "  axis " << axis[0] * 180.0 / M_PI << " " << axis[1] * 180.0 / M_PI << " " << axis[2] * 180.0 / M_PI << " ";
		file << "  XYZ";
		int channels[6];
		joint->getChannels(channels);
		int numChannels = joint->getNumChannels();
		file << "\n";
		numChannels = joint->getNumChannels();
		if (numChannels > 0)
			file << " dof ";
		
		for (int c = 0; c < numChannels; c++)
		{
			if (channels[c] == CharJoint::XPOSITION)
			{
				file << "tx ";
			}
			else if (channels[c] == CharJoint::YPOSITION)
			{
				file << "ty ";
			}
			else if (channels[c] == CharJoint::ZPOSITION)
			{
				file << "tz ";
			}
			else if (channels[c] == CharJoint::XROTATION)
			{
				file << "rx ";
			}
			else if (channels[c] == CharJoint::YROTATION)
			{
				file << "ry ";
			}
			else if (channels[c] == CharJoint::ZROTATION)
			{
				file << "rz ";
			}
		}
		file << "\n";

		for (int l = 0; l < numChannels; l++)
		{
			if (l == 0)
			{
				file << " limits ";
			}
			double low = -180.0;
			double high = 180.0;
			//joint->getLimitsFromData(l, low, high);
			file << "         (" << low  << " " << high << ")\n";

		}

		file << " end\n";

	}

	file << ":hierarchy\n";
	file << " begin\n";
	if (this->isBVH() && this->getNumJoints() > 0)
	{
		CharJoint* firstJoint = this->getJointByIndex(0);
		file << "root " << firstJoint->getName() << "\n";
	}
	for (int j = 0; j < this->getNumJoints(); j++)
	{
		CharJoint* joint = this->getJointByIndex(j);
		int numChildren = joint->getNumChildren();
		if (numChildren == 0)
			continue;

		if (j == 0)
			file << " root ";
		else
			file << " " << joint->getName();
		for (int c = 0; c < numChildren; c++)
		{
			CharJoint* child = joint->getChild(c);
			
			file << " " << child->getName();
		}
		file << "\n";
	}

	file << " end\n";
	file.close(); // finish .asf file


	// write .amc file
	// create the data file
	file2 << ":FULLY-SPECIFIED\n";
	file2 << ":DEGREES\n";

	double ftime = 0;
	double nframes = 0;
	double origTime = this->getTime();
	if (m_root != NULL)
	{
		ftime = m_root->getFrameTime();
		nframes = m_root->getNumFrames();
	}
	for (int x = 0; x < nframes; x++)
	{
		this->setTime(ftime * float(x));
		calculateMatrices(ftime * float(x));
		file2 << (x + 1) << "\n"; // frame number
		double frame[6];
		for (int j = 0; j < this->getNumJoints(); j++)
		{
			CharJoint* joint = this->getJointByIndex(j);
			// is this an ASF/AMC format file?
			if (joint->getNumChannels() == 0)
				continue;

			if (j == 0)
				file2 << "root ";
			else
				file2 << joint->getName() << " ";
			int numDOF = joint->getNumChannels();
			joint->getFrames(x, frame);
			if (!this->isBVH())
			{ // source animation is non-bvh, so original rotation order can be used
				for (int dof = 0; dof < numDOF; dof++)
				{
					if (dof > 0)
						file2 << " ";
					file2 << frame[dof];
				}
			}
			else
			{ // source animations is bvh, so rotation order must be reversed
				int channels[6];
				joint->getChannels(channels);
				int order = CharJoint::determineRotationOrder(channels, joint->getNumChannels(), joint);
				Quaternion* quat = joint->getQuaternion(float(x) * ftime);
				Matrix3x3 final;
				quat->toMatrix(final);
				final.transpose();

				// now decompose the matrix into the proper order
				VectorObj vec(0, 0, 0);

				switch (order)
				{
					case Matrix3x3::XYZ:
						final.matToEuler(Matrix3x3::ZYX, vec, false);
						break;
					case Matrix3x3::XZY:
						final.matToEuler(Matrix3x3::YZX, vec, false);
						break;
					case Matrix3x3::YXZ:
						final.matToEuler(Matrix3x3::ZXY, vec, false);
						break;
					case Matrix3x3::YZX:
						final.matToEuler(Matrix3x3::XZY, vec, false);
						break;
					case Matrix3x3::ZXY:
						final.matToEuler(Matrix3x3::YXZ, vec, false);
						break;
					case Matrix3x3::ZYX:
						final.matToEuler(Matrix3x3::XYZ, vec, false);
						break;
					case Matrix3x3::XY:
						final.matToEuler2D(Matrix3x3::YX, vec, false);
						break;
					case Matrix3x3::YX:
						final.matToEuler2D(Matrix3x3::XY, vec, false);
						break;
					case Matrix3x3::XZ:
						final.matToEuler2D(Matrix3x3::ZX, vec, false);
						break;
					case Matrix3x3::ZX:
						final.matToEuler2D(Matrix3x3::XZ, vec, false);
						break;
					case Matrix3x3::YZ:
						final.matToEuler2D(Matrix3x3::ZY, vec, false);
						break;
					case Matrix3x3::ZY:
						final.matToEuler2D(Matrix3x3::YZ, vec, false);
						break;
					default:
						break;
				}				
				for (int dof = 0; dof < numDOF; dof++)
				{
					if (dof > 0)
						file2 << " ";
					if (channels[dof] == CharJoint::XPOSITION ||
						channels[dof] == CharJoint::YPOSITION ||
						channels[dof] == CharJoint::ZPOSITION)
					{
						file2 << frame[dof] * this->getScale();
					}
					else if (channels[dof] == CharJoint::XROTATION)
					{
						file2 << vec[0] * 180.0 / M_PI;
					}
					else if (channels[dof] == CharJoint::YROTATION)
					{
						file2 << vec[1] * 180.0 / M_PI;
					}
					else if (channels[dof] == CharJoint::ZROTATION)
					{
						file2 << vec[2] * 180.0 / M_PI;
					}
				}
			}

			file2 << "\n";
		}
	}

	file2.close(); // finish .amc file

	if (this->isBVH())
	{
		// now eliminate the dummy joints created
		for (int x = 0; x < needDummy.size(); x++)
		{
			CharJoint* child = needDummy[x];
			CharJoint* dummy = child->getParent();
			CharJoint* parent = dummy->getParent();
			dance::connectionManager->removeConnection(dummy, "jointchild", child);
			dance::connectionManager->removeConnection(parent, "jointchild", dummy);
			dance::connectionManager->makeConnection(parent, "jointchild", child);			
			dance::AllGenericPlugins->remove(dummy);
		}	
	}
	this->setTime(origTime);

}

void Character::saveSKSKM(char* filename, char* filename2, float fps)
{
	ofstream file (filename, ios::out | ios::binary);
	ofstream file2 (filename2, ios::out | ios::binary);

	saveSKSKM(file, file2, fps);

	file.close();
	file2.close();
}

void Character::saveSKSKM(std::ofstream& file, std::ofstream& file2, float fps)
{
	double ftime = 0;
	double nframes = 0;

	// determine which channels to write

	file << "# SK Skeleton Definition\n";
	file << "# Created by DANCE\n";
	file << "\n";
	file << "set_name " << this->getName() << "\n";
	file << "\n";
	file << "skeleton\n";
	skMetaRecurse(m_root, 0, file);

	file << "end\n";
	file.close(); // finish .sk file


	file2 << "";
	if (m_root != NULL)
	{
		ftime = m_root->getFrameTime();
		nframes = m_root->getNumFrames();
	}

	file2 << "# SKM Motion Definition\n";
	file2 << "# Created by DANCE\n";
	file2 << "\n";
	file2 << "SkMotion\n";
	file2 << "\n";
	file2 << "name \"" << this->getName() << "\"\n";
	file2 << "\n";
	
	// how many channels will be written out?
	// for now, write everything
	// in the future, there should be a mechanism
	// by which only certain channels can be specified
	
	// first pass: get the number of channels
	int numJoints = this->getNumJoints();
	std::vector<bool> writeChannel;
	int totalNumWrittenChannels = 0;
	for (int j = 0; j < numJoints; j++)
	{
		CharJoint* joint = this->getJointByIndex(j);
		std::vector<double*>& rawFrames = joint->getRawFrameData();
		int channels[6];
		int numChannels = joint->getChannels(channels);
		for (int c = 0; c < numChannels; c++)
		{
			bool hasNonZeroData = false;
			if (channels[c] == CharJoint::XPOSITION ||
				channels[c] == CharJoint::YPOSITION ||
				channels[c] == CharJoint::ZPOSITION)
			{
				// check for existence of data
				for (int f = 0; f < joint->getNumFrames(); f++)
				{
					if (rawFrames[f][c] != 0.0)
					{
						hasNonZeroData = true;
						break;
					}
				}
				if (hasNonZeroData)
				{
					writeChannel.push_back(true);
					totalNumWrittenChannels++;
				}
				else
				{
					writeChannel.push_back(false);					
				}
			}
			else if (channels[c] == CharJoint::XROTATION) 
			{
				// only check for xrot, since it is assumed that 
				// if an xrot exists, so will the yrot and zrot
				
				// check for existence of data
				for (int f = 0; f < joint->getNumFrames(); f++)
				{
					if (rawFrames[f][c] != 0.0 || rawFrames[f][c + 1] || rawFrames[f][c  + 2])
					{
						hasNonZeroData = true;
						break;
					}
				}
				if (hasNonZeroData)
				{
					writeChannel.push_back(true);
					totalNumWrittenChannels++;
				}
				else
				{
					//writeChannel.push_back(false);
					
					// EXPERIMENT- WRITE ALL THE ROTATION CHANNELS
					writeChannel.push_back(true);
					totalNumWrittenChannels++;
				}
			}
		}		
	}
	// determine which channels do not contain any data and
	// automatically eliminate those from the .skm output

	file2 << "channels " << totalNumWrittenChannels << "\n";
	
	// second pass: write the channel info
	int curWriteChannel = 0;
	for (int j = 0; j < numJoints; j++)
	{
		CharJoint* joint = this->getJointByIndex(j);
		int channels[6];
		int numChannels = joint->getChannels(channels);
		for (int c = 0; c < numChannels; c++)
		{
			if (channels[c] == CharJoint::XPOSITION)
			{
				if (writeChannel[curWriteChannel])
					file2 << joint->getName() << " XPos\n";
				curWriteChannel++;
			}
			else if (channels[c] == CharJoint::YPOSITION)
			{
				if (writeChannel[curWriteChannel])
					file2 << joint->getName() << " YPos\n";
				curWriteChannel++;
			}
			else if (channels[c] == CharJoint::ZPOSITION)
			{
				if (writeChannel[curWriteChannel])
					file2 << joint->getName() << " ZPos\n";		
				curWriteChannel++;
			}			
			else if (channels[c] == CharJoint::XROTATION) 
			{
				// only check for xrot, since it is assumed that 
				// if an xrot exists, so will the yrot and zrot
				if (writeChannel[curWriteChannel])
					file2 << joint->getName() << " Quat\n";
				curWriteChannel++;
			}
		}		
	}

	// now write the frame information
	file2 << "frames " << nframes << "\n";
	for (int f = 0; f < nframes; f++)
	{
		curWriteChannel = 0;
		file2 << "\nkt " << (f * 1.0 / fps) << " fr ";
		for (int j = 0; j < numJoints; j++)
		{
			CharJoint* joint = this->getJointByIndex(j);
			int channels[6];
			int numChannels = joint->getChannels(channels);
			double frames[6];
			joint->getFrames(f, frames);
			for (int c = 0; c < numChannels; c++)
			{
				if (channels[c] == CharJoint::XPOSITION ||
					channels[c] == CharJoint::YPOSITION ||
					channels[c] == CharJoint::ZPOSITION)
				{
					if (writeChannel[curWriteChannel])
						file2 << frames[c] << " "; 
					curWriteChannel++;
				}
				else if (channels[c] == CharJoint::XROTATION || 
						 channels[c] == CharJoint::YROTATION ||
						 channels[c] == CharJoint::ZROTATION) 
				{
					if (writeChannel[curWriteChannel])
					{
						// get the rotation order
						int order = CharJoint::determineRotationOrder(channels, numChannels, joint);
						// only check for xrot, since it is assumed that 
						// if an xrot exists, so will the yrot and zrot
						
						// convert to axis/angle notation
						Matrix3x3 final;
						VectorObj vec;
						if (order == Matrix3x3::XYZ)
							vec.assign(frames[c] * M_PI / 180.0, frames[c + 1] * M_PI / 180.0, frames[c + 2] * M_PI / 180.0);
						else if (order == Matrix3x3::XZY)
							vec.assign(frames[c] * M_PI / 180.0, frames[c + 2] * M_PI / 180.0, frames[c + 1] * M_PI / 180.0);
						else if (order == Matrix3x3::YXZ)
							vec.assign(frames[c + 1] * M_PI / 180.0, frames[c] * M_PI / 180.0, frames[c + 2] * M_PI / 180.0);
						else if (order == Matrix3x3::ZXY)
							vec.assign(frames[c + 1] * M_PI / 180.0, frames[c + 2] * M_PI / 180.0, frames[c] * M_PI / 180.0);
						else if (order == Matrix3x3::YZX)
							vec.assign(frames[c + 2] * M_PI / 180.0, frames[c] * M_PI / 180.0, frames[c + 1] * M_PI / 180.0);
						else if (order == Matrix3x3::ZYX)
							vec.assign(frames[c + 2] * M_PI / 180.0, frames[c + 1] * M_PI / 180.0, frames[c] * M_PI / 180.0);

//						VectorObj vec(frames[c] * M_PI / 180.0, frames[c + 1] * M_PI / 180.0, frames[c + 2] * M_PI / 180.0);
						// special case - if no rotations, write all zeroes
						if (vec[0] == 0.0 && vec[1] == 0.0 && vec[2] == 0.0)
						{
							file2 << "0 0 0 ";
						}
						else
						{
							if (order == Matrix3x3::XYZ)
								final.matFromEuler(Matrix3x3::ZYX, vec);
							else if (order == Matrix3x3::XZY)
								final.matFromEuler(Matrix3x3::YZX, vec);
							else if (order == Matrix3x3::YXZ)
								final.matFromEuler(Matrix3x3::ZXY, vec);
							else if (order == Matrix3x3::ZXY)
								final.matFromEuler(Matrix3x3::YXZ, vec);
							else if (order == Matrix3x3::YZX)
								final.matFromEuler(Matrix3x3::XZY, vec);
							else if (order == Matrix3x3::ZYX)
								final.matFromEuler(Matrix3x3::XYZ, vec);

							Quaternion q;
							q.fromMatrix(final);
							Vector axis;
							double angle;
							q.getAxisAngle(axis, &angle);

							// scale the axis by the angle
							if (angle != 0.0) 
								VecNumMul(axis, axis, angle);
							file2 << axis[0] << " " << axis[1] << " " << axis[2] << " ";
						}
						c += 2;
						curWriteChannel++;
					}
					else
					{
						curWriteChannel++;
					}
				}
			}		
		}
	}
	file2 << "\n";
	
	file2 << "\n";

	// stroke parameters, if present
	std::string strokeParams[5] = {"ready time:", "strokeStart time:", "emphasis time", "stroke time:", "relax time:" };
	for (int s = 0; s < 5; s++)
	{
		std::string param = this->getParameter(strokeParams[s]);
		if (param != "")
			file2 << param << "\n";
	}
}

void Character::skMetaRecurse(CharJoint* joint, int level, ofstream &file)
{
	if (level == 0)
	{
		indent(level, file, 2);
		file << "root "; 
	}
	else
	{
		file << "\n";
		indent(level, file, 2);
		file << "joint ";
	}
	file << joint->getName() << "\n";
	Vector offset;
	joint->getOffset(offset);
	indent(level, file, 2);
	file << "{ offset " << offset[0] << " " << offset[1] << " " << offset[2] << "\n";
	std::vector<std::string> params = joint->getParameters();
	std::string visgeo = joint->getParameter("visgeo");
	if (visgeo != "")
	{
		indent(level + 1, file, 2);
		file << visgeo << "\n";
	}
	std::string colgeo = joint->getParameter("colgeo");
	if (colgeo != "")
	{
		indent(level + 1, file, 2);
		file << colgeo << "\n";
	}
	int numChannels = joint->getNumChannels();
	int channels[6];
	joint->getChannels(channels);
	for (int c = 0; c < numChannels; c++)
	{
		indent(level + 1, file, 2);
		double lowLimit, highLimit;
		joint->getLimits(c, lowLimit, highLimit);
		if (channels[c] == CharJoint::XPOSITION)
		{
			file << "channel XPos 0";
			if (!joint->getParent())
				file << " free";
			else if (lowLimit != 0 || highLimit != 0)
				file << " lim " << lowLimit << " " << highLimit;
			file << "\n";
		}
		else if (channels[c] == CharJoint::YPOSITION)
		{
			file << "channel YPos 0";
			if (!joint->getParent())
				file << " free";
			else if (lowLimit != 0 || highLimit != 0)
				file << " lim " << lowLimit << " " << highLimit;
			file << "\n";
		}
		else if (channels[c] == CharJoint::ZPOSITION)
		{
			file << "channel ZPos 0";
			if (!joint->getParent())
				file << " free";
			else if (lowLimit != 0 || highLimit != 0)
				file << " lim " << lowLimit << " " << highLimit;
			file << "\n";
		}
		else if (channels[c] == CharJoint::XROTATION)
		{
			file << "channel Quat";
			file << "\n";
		}
		else if (channels[c] == CharJoint::YROTATION ||
				 channels[c] == CharJoint::ZROTATION)
		{
			// this case is implicitly handled by the XPOSITION case
		}
	}

	int numChildren = joint->getNumChildren();
	for (int x = 0; x < numChildren; x++)
	{
		skMetaRecurse(joint->getChild(x), level + 1, file);
	}
	indent(level, file, 2);
	file << "}" << "\n";
}

void Character::saveBVH(char* filename)
{
	ofstream file (filename, ios::out | ios::binary);

	saveBVH(file);

	file.close();
}

void Character::saveBVH(std::ofstream& file)
{
	double ftime = 0;
	double nframes = 0;

	file << "HIERARCHY\n";
	bvhMetaRecurse(m_root, 0, file);


	if (m_root != NULL)
	{
		ftime = m_root->getFrameTime();
		nframes = m_root->getNumFrames();
	}

	file << "MOTION\n";
	file << "Frames: " << nframes << "\n";
	file << "Frame Time: " << ftime << "\n";
	for (int f = 0; f < nframes; f++)
	{
		bvhAnimRecurse(m_root, file, f);
		file << "\n";
	}
}

void Character::bvhMetaRecurse(CharJoint* joint, int level, ofstream &file)
{
	indent(level, file);
	if (level == 0)
	{
		file << "ROOT "; 
	}
	else
	{
		file << "JOINT ";
	}
	file << joint->getName() << "\n";
	indent(level, file);
	file << "{" << "\n";
	Vector offset;
	joint->getOffset(offset);
	indent(level + 1, file);
	file << "OFFSET " << offset[0] << " " << offset[1] << " " << offset[2] << "\n";
	indent(level + 1, file);
	int numChannels = joint->getNumChannels();
	int channels[6];
	joint->getChannels(channels);
	if (joint->useAxis() && joint->getParent() != NULL)
	{
		numChannels = 3;
		channels[0] = CharJoint::XROTATION;
		channels[1] = CharJoint::YROTATION;
		channels[2] = CharJoint::ZROTATION;
	}
	file << "CHANNELS " << numChannels << " ";
	for (int c = 0; c < numChannels; c++)
	{
		if (channels[c] == CharJoint::XPOSITION) 
			file << "Xposition";
		else if (channels[c] == CharJoint::YPOSITION) 
			file << "Yposition";
		else if (channels[c] == CharJoint::ZPOSITION) 
			file << "Zposition";
		else if (channels[c] == CharJoint::XROTATION) 
			file << "Xrotation";
		else if (channels[c] == CharJoint::YROTATION) 
			file << "Yrotation";
		else if (channels[c] == CharJoint::ZROTATION) 
			file << "Zrotation";
		if (c < numChannels - 1)
			file << " ";
	}
	file << "\n";

	if (joint->isEndEffector() || joint->getNumChildren() == 0)
	{
		indent(level + 1, file);
		file << "End Site" << "\n";
		indent(level + 1, file);
		file << "{" << "\n";
		indent(level + 2, file);
		joint->getEndEffectorOffset(offset);
		file << "OFFSET " << offset[0] << " " << offset[1] << " " << offset[2] << "\n";
		indent(level + 1, file);
		file << "}"<< "\n";
	}
	int numChildren = joint->getNumChildren();
	for (int x = 0; x < numChildren; x++)
	{
		bvhMetaRecurse(joint->getChild(x), level + 1, file);
	}
	indent(level, file);
	file << "}" << "\n";
}


void Character::indent(int amount, ostream& o, int spaces)
{
	if (spaces > 0)
	{
		for (int x = 0; x < amount; x++)
			for (int s = 0; s < spaces; s++)
				o << ' ';
	}
	else
	{
		for (int x = 0; x < amount; x++)
			o << '\t';
	}
}

void Character::bvhAnimRecurse(CharJoint* joint, ofstream &file, int frameNum)
{
	double frames[6];
	joint->getFrames(frameNum, frames);

	// apply rotation on the root joint
	if (joint->getParent() == NULL && (m_rotation[0]->getValue() != 0.0 || m_rotation[1]->getValue() != 0.0 || m_rotation[2]->getValue()))
	{
		joint->calcTransMatrix(frameNum * joint->getFrameTime());

		double temp[4][4];
		setIdentMat(&temp[0][0], 4);
		double curTime = joint->getFrameTime() * frameNum;
		double curMatrix[4][4];
		this->calculateMatrices(curTime);
		joint->getTransMatrix(curMatrix);

		// calculate the effect of the rotation matrix
		Matrix3x3 xrot;
		xrot.setRotateMatrix(Matrix3x3::X, -m_rotation[0]->getValue() * M_PI / 180.0);
		Matrix3x3 yrot;
		yrot.setRotateMatrix(Matrix3x3::Y, -m_rotation[1]->getValue() * M_PI / 180.0);
		Matrix3x3 zrot;
		zrot.setRotateMatrix(Matrix3x3::Z, -m_rotation[2]->getValue() * M_PI / 180.0);

		Matrix3x3 finalRot = zrot * yrot * xrot;

		double rotmatrix[4][4];
		setIdentMat(&rotmatrix[0][0], 4);
		finalRot.to4x4(rotmatrix);

//		multArray(&temp[0][0], &curMatrix[0][0], &rotmatrix[0][0], 4, 4, 4);
		multArray4x4(temp, curMatrix, rotmatrix);

		int channels[6];
		joint->getChannels(channels);
		int order = CharJoint::determineRotationOrder(channels, joint->getNumChannels(), joint);

		// determine the rotation
		Matrix3x3 dmat(temp);
		dmat.invert();
		VectorObj obj;
		dmat.matToEuler(order, obj, false);
		switch (order)
		{
		case Matrix3x3::XYZ:
			file << temp[3][0] << " " << temp[3][1] << " " << temp[3][2] << " " << obj[0] * 180.00 / M_PI << " " << obj[1] * 180.00 / M_PI << " " << obj[2] * 180.00 / M_PI << " " ;
			break;
		case Matrix3x3::XZY:
			file << temp[3][0] << " " << temp[3][1] << " " << temp[3][2] << " " << obj[0] * 180.00 / M_PI << " " << obj[2] * 180.00 / M_PI << " " << obj[1] * 180.00 / M_PI << " " ;
			break;
		case Matrix3x3::YXZ:
			file << temp[3][0] << " " << temp[3][1] << " " << temp[3][2] << " " << obj[1] * 180.00 / M_PI << " " << obj[0] * 180.00 / M_PI << " " << obj[2] * 180.00 / M_PI << " " ;
			break;
		case Matrix3x3::YZX:
			file << temp[3][0] << " " << temp[3][1] << " " << temp[3][2] << " " << obj[1] * 180.00 / M_PI << " " << obj[2] * 180.00 / M_PI << " " << obj[0] * 180.00 / M_PI << " " ;
			break;
		case Matrix3x3::ZXY:
			file << temp[3][0] << " " << temp[3][1] << " " << temp[3][2] << " " << obj[2] * 180.00 / M_PI << " " << obj[0] * 180.00 / M_PI << " " << obj[1] * 180.00 / M_PI << " " ;
			break;
		case Matrix3x3::ZYX:
			file << temp[3][0] << " " << temp[3][1] << " " << temp[3][2] << " " << obj[2] * 180.00 / M_PI << " " << obj[1] * 180.00 / M_PI << " " << obj[0] * 180.00 / M_PI << " " ;
			break;
		}
	
	}
	else
	{
		if (joint->useAxis())
		{
			joint->calcTransMatrix(frameNum * joint->getFrameTime(), true);
			double matrix[4][4];
			joint->getTransMatrix(matrix);
			Matrix3x3 mat(matrix);
			mat.invert();
			VectorObj obj;
			mat.matToEuler(Matrix3x3::XYZ, obj, false);
			// all joints that use axis are XYZ ordered
			if (joint->getNumChannels() > 3)
			{
				file << frames[0] << " " << frames[1] << " " << frames[2] << " ";
			}
			file << obj[0] * 180.00 / M_PI << " " << obj[1] * 180.00 / M_PI << " " << obj[2] * 180.00 / M_PI << " " ;
		}
		else
		{
			for (int c = 0; c < joint->getNumChannels(); c++)
			{
				// $HACK
				file << frames[c] << " ";
				//file << 0.000001 << " ";
			}
		}
	}

	int numChildren = joint->getNumChildren();
	for (int x = 0; x < numChildren; x++)
	{
		bvhAnimRecurse(joint->getChild(x), file, frameNum);
	}
}

BoundingBox* Character::calcBoundingBox(BoundingBox* box)
{
	Vector min;
	Vector max;
	this->getBoundingBox(this->getTime(), min, max);

	m_BoundingBox.xMin = min[0];
	m_BoundingBox.xMax = max[0];
	m_BoundingBox.yMin = min[1];
	m_BoundingBox.yMax = max[1];
	m_BoundingBox.zMin = min[2];
	m_BoundingBox.zMax = max[2];

	if (box)
		box->merge(m_BoundingBox);

	return &m_BoundingBox;

}


void Character::getBoundingBox(double time, Vector min, Vector max)
{
 	min[0] = 999999;
	min[1] = 999999;
	min[2] = 999999;

	max[0] = -999999;
	max[1] = -999999;
	max[2] = -999999;

	int numJoints = this->getNumJoints();

	for (int j = 0; j < numJoints; j++)
	{
		CharJoint* joint = this->getJointByIndex(j);
		Vector p;
		joint->getWorldCoord(time, p);
		if (p[0] < min[0])
			min[0] = p[0];
		if (p[1] < min[1])
			min[1] = p[1];
		if (p[2] < min[2])
			min[2] = p[2];

		if (p[0] > max[0])
			max[0] = p[0];
		if (p[1] > max[1])
			max[1] = p[1];
		if (p[2] > max[2])
			max[2] = p[2];
	}
}

bool Character::verify()
{
	bool retVal = true;
	danceInterp::OutputMessage("Character %s:", getName());
	int numFrames = getNumFrames();
	danceInterp::OutputMessage("Character has %d frames.", numFrames);
	int numJoints = getNumJoints();
	danceInterp::OutputMessage("Character has %d joints.", numJoints);
	for (int j = 0; j < numJoints; j++)
	{
		CharJoint* joint = this->getJointByIndex(j);
		// make sure that there is only one root
		if (j != 0 && joint->getParent() == NULL)
		{
			danceInterp::OutputMessage("Joint %s is not the root but has no parent.", joint->getName());
			retVal = false;
		}
		// make sure that the number of frames match properly
		if (joint->getNumFrames() != numFrames)
		{
			danceInterp::OutputMessage("Joint %s has %d frames, not matching overall number of frames %d.", joint->getName(), joint->getNumFrames(), numFrames);
			retVal = false;
		}
		// make sure that the parent-child relationship is intact
		CharJoint* parent = joint->getParent();
		if (parent != NULL)
		{
			int numChildren = parent->getNumChildren();
			bool found = false;
			for (int c = 0; c < numChildren; c++)
			{
				if (parent->getChild(c) == joint)
					found = true;
			}
			if (!found)
			{
				danceInterp::OutputMessage("Joint %s has parent %s, but parent does not have child.", joint->getName(), parent->getName());
				retVal = false;
			}
		}
	}

	return retVal;
}

double Character::getHeight()
{
	if (m_height == -1)
	{
		Vector min;
		Vector max;
		this->setMatrixCalculated(false);
		this->getBoundingBox(-1.0, min, max);
		m_height = abs(max[1] - min[1]);
	}

	return m_height;
}

double Character::getWidth()
{
	if (m_width == -1)
	{
		Vector min;
		Vector max;
		this->getBoundingBox(-1.0, min, max);
		m_width = abs(max[0] - min[0]);
	}

	return m_width;
}

bool Character::isBVH()
{
	return m_isBVH;
}

void Character::setIsBVH(bool val)
{
	m_isBVH = val;
}

bool Character::isPoints()
{
	return m_isPoints;
}

void Character::setIsPoints(bool val)
{
	m_isPoints = val;
}

void Character::compare(Character* character)
{
	// compare the original character to the 'notrans' character

	int numJoints = character->getNumJoints();
	for (int j = 0; j < numJoints; j++)
	{
		CharJoint* origJoint = this->getJointByIndex(j);
		CharJoint* compareJoint = character->getJointByIndex(j);
		if (strcmp(origJoint->getName(), compareJoint->getName()) != 0)
			danceInterp::OutputMessage("Orig joint %s name is not the same as compare joint %s name", origJoint->getName(), compareJoint->getName());
		// compare the frames
		int numFrames = origJoint->getNumFrames();
		if (compareJoint->getNumFrames() != numFrames)
			danceInterp::OutputMessage("Orig joint %s has %d frames, whereas %s has %d frames", origJoint->getName(), numFrames, compareJoint->getName(), compareJoint->getNumFrames());

		int numChannels = origJoint->getNumChannels();
		int numMismatches = 0;
		for (int f = 0; f < numFrames; f++)
		{
			double f1[6];
			double f2[6];
			origJoint->getFrames(f, f1);
			compareJoint->getFrames(f, f2);
			for (int c = 0; c < numChannels; c++)
			{
				if (origJoint->getParent() == NULL)
					continue;
				if (f1[c] != f2[c])
					danceInterp::OutputMessage("Frame %d channel %d: %f %f ", f, c, f1[c], f2[c]);

			}		
			// compare the quaternions
			Quaternion* q1 = origJoint->getQuaternion(f);
			Quaternion* q2 = compareJoint->getQuaternion(f);
			if (numMismatches < 5)
				if (q1->data()[0] != q2->data()[0] ||q1->data()[1] != q2->data()[1] ||q1->data()[2] != q2->data()[2] ||q1->data()[3] != q2->data()[3])
				{
					danceInterp::OutputMessage("Orig q is %f %f %f %f, compare Q is %f %f %f %f", q1->data()[0], q1->data()[1], q1->data()[2], q1->data()[3], q2->data()[0], q2->data()[1], q2->data()[2], q2->data()[3]);
					numMismatches++;
				}
		}

	}
}

bool Character::isPointsCalculated()
{
	return m_pointsCalculated;
}

void Character::setPointsCalculated(bool val)
{
	m_pointsCalculated = val;
}

void Character::calculatePoints(int frameNum)
{
	double matrix[4][4];
	double scale = m_scale->getValue();
	Vector offset = {m_offset[0]->getValue(), m_offset[1]->getValue(), m_offset[2]->getValue()};
	m_scale->setValue(1.0);
	m_offset[0]->setValue(0.0);
	m_offset[1]->setValue(0.0);
	m_offset[2]->setValue(0.0);
	setIdentMat(&matrix[0][0], 4);
	calculatePointsRecurse(frameNum, this->getRoot(), matrix);
	m_scale->setValue(scale);
	m_offset[0]->setValue(offset[0]);
	m_offset[1]->setValue(offset[1]);
	m_offset[2]->setValue(offset[2]);
	this->setPointsCalculated(true);
}

void Character::calculatePointsRecurse(int frameNum, CharJoint* joint, const double parentMatrix[4][4])
{
	double time = (double)frameNum * joint->getFrameTime();
	double matrix[4][4];
	Vector pos;

	// calculate transformation matrix for current joint
	joint->calcTransMatrix(time, false);
	joint->getTransMatrix(matrix);

	// multiply the parent matrix by the current matrix 
	double mat[4][4];
	for (int x  = 0; x < 4; x++)
		for (int y = 0; y < 4; y++)
			mat[x][y] = parentMatrix[y][x];

	double mat2[4][4];
	for (int x  = 0; x < 4; x++)
		for (int y = 0; y < 4; y++)
			mat2[x][y] = matrix[y][x];

	double temp[4][4];
//	multArray(&temp[0][0], &mat[0][0], &mat2[0][0], 4, 4, 4); 
	multArray4x4(temp, mat, mat2); 
	for (int x  = 0; x < 4; x++)
		for (int y = 0; y < 4; y++)
			matrix[y][x] = mat[x][y];

	pos[0] = matrix[3][0];
	pos[1] = matrix[3][1];
	pos[2] = matrix[3][2];

	// set point and global orientation
	if (frameNum < joint->getNumFrames())
	{
		joint->setPoint(frameNum, pos[0], pos[1], pos[2]);
	}

	// calculate points for each child
	int numChildren = joint->getNumChildren();
	for (int x = 0; x < numChildren; x++)
	{
		CharJoint* child = joint->getChild(x);
		calculatePointsRecurse(frameNum, child, matrix);
	}

	// set end effector position
	if (joint->isEndEffector())
	{
		Vector endOffset;
		joint->getEndEffectorOffset(endOffset);
		transformPoint_mat(endOffset, matrix);
		joint->setEndEffectorPoint(frameNum, endOffset[0], endOffset[1], endOffset[2]);
	}
}

bool Character::isMatrixCalculated()
{
	return m_matrixIsCalculated;
}

void Character::setMatrixCalculated(bool val)
{
	m_matrixIsCalculated = val;
}

void Character::calculateMatrices(double time)
{
	calculateMatricesRecurse(time + m_offsetTime->getValue(), this->getRoot());
	setMatrixCalculated(true);
}

void Character::calculateMatricesRecurse(double time, CharJoint* joint)
{
    if (!joint)
		return;
	joint->calcTransMatrix(time);
	double matrix[4][4];
	joint->getTransMatrix(matrix);
	CharJoint* parent = joint->getParent();
	if (parent == NULL)
	{
		joint->setWorldTransMatrix(matrix);
	}
	else
	{
		double parentMatrix[4][4];
		parent->getWorldTransMatrix(parentMatrix);
		double worldMatrix[4][4];
		multArray4x4(worldMatrix, matrix, parentMatrix);
		joint->setWorldTransMatrix(worldMatrix);
	}

	int numChildren = joint->getNumChildren();
	for (int x = 0; x < numChildren; x++)
	{
		calculateMatricesRecurse(time, joint->getChild(x));
	}
}

int Character::getCombinedFrame()
{
	return m_combinedFrame;
}

void Character::setCombinedFrame(int frame)
{
	m_combinedFrame = frame;
}

void Character::addMotion(Character* c)
{
	// make sure that these two characters have identical topologies & DOFs
	// ...
	// ...

	// second, copy the frames of the second character to the first one
	int origNumFrames = this->getNumFrames();
	int numFrames = c->getNumFrames();
	int numJoints = c->getNumJoints();
	for (int j = 0; j < numJoints; j++)
	{
		CharJoint* joint = c->getJointByIndex(j);
		CharJoint* jointCombined = this->getJointByIndex(j);
		for (int f = 0; f < numFrames; f++)
		{
			// added by AS 7/16/04
			if (joint->getCharacter()->isPoints())
			{
				Vector point;
				joint->getPoint(f, point[0], point[1], point[2]);
				jointCombined->addFrame(point[0], point[1], point[2]);
			}
			else
			{
				double frames[6];
				joint->getFrames(f, frames);
				jointCombined->addFrame(frames);
			}
		}
	}
	this->setCombinedFrame(origNumFrames);
}

void Character::savePOVRay(char* filename, int start, int finish, int skipframes)
{
	ofstream file (filename, ios::out | ios::binary);

	int numFrames = 0;
	double frameTime = 0.0;
	CharJoint* root = this->getRoot();

	if (root != NULL)
	{
		numFrames = root->getNumFrames();
		frameTime = root->getFrameTime();
	}

	Vector offset;
	this->getOffset(offset);

	vector<CharJoint*> jointList;
	int numJoints = this->getNumJoints();
	for (int j = 0; j < numJoints; j++)
	{
		CharJoint* joint = this->getJointByIndex(j);
		jointList.push_back(joint);
	}

	for (int f = start; f < numFrames && f < finish; f += skipframes)
	{       
		// determine amount of interpolation if necessary
		double curTime = f * frameTime;
		for (int j = 0; j < numJoints; j++)
		{
			double jointMatrix[4][4];
			double parentMatrix[4][4];

			CharJoint* joint = jointList[j];
			CharJoint* parent = joint->getParent();
			Vector pos;
			if (parent != NULL)
			{
				if (parent->getNumChannels() == 0)
					parent = parent->getParent();
				Vector parentPos;
				if (this->isPoints())
				{
					joint->getPoint(f, pos[0], pos[1], pos[2]);
					parent->getPoint(f, parentPos[0], parentPos[1], parentPos[2]);
					VecAdd(pos, pos, offset);
					VecAdd(parentPos, parentPos, offset);
				}
				else
				{
					joint->getWorldTransMatrix(curTime,jointMatrix);
					pos[0] = jointMatrix[3][0]; pos[1] = jointMatrix[3][1]; pos[2] = jointMatrix[3][2];
					parent->getWorldTransMatrix(curTime, parentMatrix);
					parentPos[0] = parentMatrix[3][0]; parentPos[1] = parentMatrix[3][1]; parentPos[2] = parentMatrix[3][2];
					// invert the scale
					VecNumMul(pos, pos, 1.0 / this->getScale());
					VecNumMul(parentPos, parentPos, 1.0 / this->getScale());
				}
				file << pos[0] << " " << pos[1] << " " << pos[2];
				file << " ";
				file << parentPos[0] << " " << parentPos[1] << " " << parentPos[2];
				file << " ";
			}
			if (joint->isEndEffector())
			{
				Vector endEffPos;
				if (this->isPoints())
				{
					joint->getEndEffectorPoint(f, endEffPos[0], endEffPos[1], endEffPos[2]);
					VecAdd(endEffPos, endEffPos, offset);
				}
				else
				{
					Vector endEffOffset;
					joint->getEndEffectorOffset(endEffOffset);
					transformPoint_mat(endEffOffset, jointMatrix);
					VecCopy(endEffPos, endEffOffset);
					// invert the scale
					VecNumMul(endEffPos, endEffPos, 1.0 / this->getScale());
				}
				file << endEffPos[0] << " " << endEffPos[1] << " " << endEffPos[2];
				file << " ";
				file << pos[0] << " " << pos[1] << " " << pos[2];
				file << " ";
			}
		}
		file << "\n";
	}
	file << "\n";

	file.close();
}


void Character::clearMotion()
{
	int numJoints = this->getNumJoints();
	for (int j = 0; j < numJoints; j++)
	{
		CharJoint* joint = this->getJointByIndex(j);
		joint->clearFrames();
	}
	m_height = -1;
	m_width = -1;
}

void Character::setBoneWidth(double size)
{
	m_boneWidth->setValue(size);
}

double Character::getBoneWidth()
{
	return m_boneWidth->getValue();
}

void Character::setJointSize(double size)
{
	m_jointSize->setValue(size);
}

double Character::getJointSize()
{
	return m_jointSize->getValue();
}

void Character::setBoneColor(Vector color)
{
	m_boneColor->setValue(color);
}

void Character::getBoneColor(Vector color)
{
	VecCopy(color, m_boneColor->getValue());
}

void Character::setJointColor(Vector color)
{
	m_jointColor->setValue(color);
}

void Character::getJointColor(Vector color)
{
	VecCopy(color, m_jointColor->getValue());
}

void Character::setShowBones(bool val)
{
	m_showBones->setValue(val);
}

bool Character::isShowBones()
{
	return m_showBones->getValue();
}

void Character::setShowJoints(bool val)
{
	m_showJoints->setValue(val);
}

bool Character::isAdjustBoneLengths()
{
	return m_adjustBoneLengths;
}

void Character::setAdjustBoneLengths(bool val)
{
	m_adjustBoneLengths = val;
}

bool Character::isShowJoints()
{
	return m_showJoints->getValue();
}

void Character::fixBoneLengths(Character* ref)
{
	// reduce the bone lengths in the point representation to the appropriate length 
	// as indicated by the metadata hierarchy
	//	double scale = this->getScale();
	//	double invScale = 1.0 / scale;

	vector<CharJoint*> joints;
	vector<double> boneLength;
	int numJoints = this->getNumJoints();
	for (int j = 0; j < numJoints; j++)
	{
		CharJoint* joint = this->getJointByIndex(j);
		joints.push_back(joint);
	}

	// determine the desired limb lengths by using the reference model
	for (int j = 0; j < numJoints; j++)
	{
		CharJoint* refJoint = ref->getJointByIndex(j);
		CharJoint* parent = refJoint->getParent();
		if (parent != NULL && parent->getNumChannels() > 0)
		{
			Vector parentPos;
			parent->getWorldCoord(-1.0, parentPos);
			Vector pos;
			refJoint->getWorldCoord(-1.0, pos);
			Vector diff;
			VecSubtract(diff, pos, parentPos);
			double length = VecLength(diff);
			boneLength.push_back(length);
			danceInterp::OutputMessage("Desired limb length for (%s - %s) is %f...", refJoint->getName(), parent->getName(), length);
			if (refJoint->isEndEffector())
			{
				Vector offset;
				refJoint->getEndEffectorOffset(offset);
				double desiredEndEffLength = VecLength(offset);
				boneLength.push_back(desiredEndEffLength);
			}
		}
		else
		{
			boneLength.push_back(0.0);
		}
	}

	// now adjust limb lengths
	int numEndEffectors = 0;
	for (int j = 0; j < numJoints; j++)
	{
		CharJoint* joint = joints[j];
		CharJoint* parentJoint = joint->getParent();
		if (parentJoint != NULL && parentJoint->getNumChannels() > 0)
		{
			for (int f = 0; f < joint->getNumFrames(); f++)
			{
				// determine the size of the bone in this frame
				Vector parentPos;
				parentJoint->getPoint(f, parentPos[0], parentPos[1], parentPos[2]);
				Vector pos;
				joint->getPoint(f, pos[0], pos[1], pos[2]);
				Vector boneVector;
				VecSubtract(boneVector, pos, parentPos);
				double length = VecLength(boneVector);
				double lengthDiff = boneLength[j + numEndEffectors] - length;
				if (abs(lengthDiff) > .001) // lengths are different
				{
					// adjust the bone length
					// get the normal from the parent to the current joint
					Vector boneNormal;
					VecCopy(boneNormal, boneVector);
					VecNormalize(boneNormal);
					// new point = parent_location + (normal * desired length)
					Vector offset;
					VecNumMul(offset, boneNormal, boneLength[j + numEndEffectors]);
					Vector finalPoint;
					VecAdd(finalPoint, parentPos, offset);
					joint->setPoint(f, finalPoint[0], finalPoint[1], finalPoint[2]);
					// now adjust all the children points by the amount that the parent was adjusted by
					Vector diff;
					VecNumMul(diff, boneNormal, lengthDiff);
					fixBoneLengthsRecurse(&joints, j, diff, f);
				}
			}
			if (joints[j]->isEndEffector())
				numEndEffectors++;
		}
	}

	// fix end effector lengths
	numEndEffectors = 0;
	for (int j = 0; j < numJoints; j++)
	{
		CharJoint* joint = joints[j];
		if (joint->isEndEffector())
		{
			for (int f = 0; f < joint->getNumFrames(); f++)
			{
				Vector pos;
				joint->getPoint(f, pos[0], pos[1], pos[2]);
				Vector endEffPos;
				joint->getEndEffectorPoint(f, endEffPos[0], endEffPos[1], endEffPos[2]);
				Vector diffVector;
				VecSubtract(diffVector, endEffPos, pos);
				Vector endEffNormal;
				VecCopy(endEffNormal, diffVector);
				VecNormalize(endEffNormal);
				Vector endEffOffset;
				VecNumMul(endEffOffset, endEffNormal, boneLength[j + numEndEffectors + 1]);
				joint->setEndEffectorPoint(f, pos[0] + endEffOffset[0], pos[1] + endEffOffset[1], pos[2] + endEffOffset[2]);
			}
			numEndEffectors++;
		}
	}


	// verification
	numEndEffectors = 0;
	for (int j = 1; j < numJoints; j++)
	{
		CharJoint* joint = joints[j];
		CharJoint* parentJoint = joint->getParent();
		if (parentJoint != NULL && parentJoint->getNumChannels() > 0)
		{
			for (int f = 0; f < joint->getNumFrames(); f++)
			{
				Vector parentPos;
				parentJoint->getPoint(f, parentPos[0], parentPos[1], parentPos[2]);
				Vector pos;
				joint->getPoint(f, pos[0], pos[1], pos[2]);
				Vector boneVector;
				VecSubtract(boneVector, pos, parentPos);
				double length = VecLength(boneVector);
				double lengthDiff = boneLength[j + numEndEffectors] - length;
				if (abs(lengthDiff) > .001)
					danceInterp::OutputMessage("Discepancy in joint length (%s) : have %f need %f at frame %d", joint->getName(), boneLength[j + numEndEffectors], length, f);
				if (joint->isEndEffector())
				{
					Vector p;
					joint->getEndEffectorPoint(f, p[0], p[1], p[2]);
					Vector diffP;
					VecSubtract(diffP, p, pos);
					double length = VecLength(diffP);
					double eeLengthDiff = length - boneLength[j + numEndEffectors + 1];
					if (abs(eeLengthDiff) > .001)
						danceInterp::OutputMessage("Discrepancy in end effector %s length: have %f need %f at frame %d", joint->getName(), boneLength[j + numEndEffectors + 1], length, f);
				}
			}
			if (joint->isEndEffector())
				numEndEffectors++;
		}
	}
}

void Character::fixBoneLengthsRecurse(vector<CharJoint*>* joints, int jointIndex, Vector offset, int frame)
{
	CharJoint* joint = (*joints)[jointIndex];
	for (int c = 0; c < joint->getNumChildren(); c++)
	{
		CharJoint* child = joint->getChild(c);
		Vector oldPoint;
		child->getPoint(frame, oldPoint[0], oldPoint[1], oldPoint[2]);
		Vector newPoint;
		VecAdd(newPoint, oldPoint, offset);
		child->setPoint(frame, newPoint[0], newPoint[1], newPoint[2]);
		// determine the index of this child joint
		int childIndex = -1;
		for (unsigned int j = jointIndex + 1; j < joints->size(); j++)
		{
			if (child == (*joints)[j])
			{
				childIndex = j;
				break;
			}
		}
		if (childIndex == -1)
			danceInterp::OutputMessage("Child was not found! Please check code!");
		else
			fixBoneLengthsRecurse(joints, childIndex, offset, frame);
	}
	if (joint->isEndEffector())
	{
		// change the location of the end effector by the offset
		Vector endEffPoint;
		joint->getEndEffectorPoint(frame, endEffPoint[0], endEffPoint[1], endEffPoint[2]);
		joint->setEndEffectorPoint(frame, endEffPoint[0] + offset[0], endEffPoint[1] + offset[1], endEffPoint[2] + offset[2]);
	}

}

void Character::setShowPoints(bool val)
{
	m_showPoints = val;
}

bool Character::isShowPoints()
{
	return m_showPoints;
}

void Character::recalculateJointList()
{
	m_allJoints.clear();
	recalculateJointListRecurse(this->getRoot());

	std::vector<std::string> jointNames;
	// now tell the CharJoints where there first DOF
	// sits in the context of the skeleton index
	CharJoint* last = NULL;
	int curDof = 0;
	for (int j = 0; j < m_allJoints.size(); j++)
	{
		CharJoint* cur = m_allJoints[j];
		if (cur != last)
		{
			if (last)
				curDof += last->getNumChannels();
			cur->setCharacterIndex(curDof);
			last = cur;
			jointNames.push_back(cur->getName());
		}
		
	}
	m_selectedJoint->setValidValues(jointNames);
}

void Character::recalculateJointListRecurse(CharJoint* curJoint)
{
	if (curJoint == NULL)
		return;

//	if (curJoint->getNumChannels() > 0) // make sure that we only reference joints that are not fixed
		m_allJoints.push_back(curJoint);

	int numChildren = curJoint->getNumChildren();
	for (int x = 0; x < numChildren; x++)
	{
		recalculateJointListRecurse(curJoint->getChild(x));
	}
}

/**
void Character::AlignWithPath(int axis,CRSpline3D *p)
{
	Vector xaxis = {1,0,0} ;
	Vector yaxis = {0,1,0} ;
	Vector zaxis = {0,0,1} ;
	Vector dist ;

	CharJoint *r = getRoot() ;
	if (r->getNumFrames() < 2) return ;
	static Vector prevOriginalPosition = {0,0,0} ;
	double arcLength = 0 ;
	double tpath = p->GetStartTime() ;
	
	for( int f = 0 ; f < r->getNumFrames() ; f++ )
	{
		Quaternion *rq = r->getQuaternion(f) ;
	
		

		// get the current position and orientation
		int cindex[6] ;
		int numChannels = r->getChannels(cindex) ;
		
		double vals[6] ;
		r->getFrames(f,vals) ;

		double tchar = f*r->getFrameTime() ;
		if( f != 0 )
		{
			// compute the distance travelled ;
			Vector curPos ;
			curPos[0] = vals[0] ;
			curPos[1] = 0 ;
			curPos[2] = vals[2] ;
			VecSubtract(dist,curPos,prevOriginalPosition) ;
			arcLength += VecLength(dist) ;
			tpath = p->ComputeTFromArcLength(arcLength) ;
			
			//danceInterp::OutputMessage("Time %lf Tpath %lf Current Arc Length %lf",tchar, tpath, arcLength) ;
		}
		else
		{
			tpath = p->GetStartTime() ;
		}
		

		// store the current position for the next frame calculations
		prevOriginalPosition[0] = vals[0] ;
		prevOriginalPosition[1] = 0 ;
		prevOriginalPosition[2] = vals[2] ;


		// compute the position and the orientation from the path
		Vector position, tangent ;
		p->Eval(tpath,position,tangent) ;
		double theta = -atan2(tangent[2],tangent[0]) ;
		Vector yaxis = {0,1,0} ;
		Quaternion qpath(yaxis,theta) ;
		danceInterp::OutputMessage("Time = %lf theta = %lf", tchar, theta) ;
	//	danceInterp::OutputMessage(" Position from curve at t = %lf : %lf %lf %lf", tpath,position[0], position[1], position[2]) ;


		

		// compute the new quaternion
		Quaternion q ;
		q.multiply(&qpath,rq);
		q.normalize() ;
		danceInterp::OutputMessage("Orirq %lf %lf %lf %lf", rq->data()[0],rq->data()[1],rq->data()[2],rq->data()[3]) ;
		danceInterp::OutputMessage("qpath %lf %lf %lf %lf", qpath.data()[0],qpath.data()[1],qpath.data()[2],qpath.data()[3]) ;
		danceInterp::OutputMessage("q %lf %lf %lf %lf", q.data()[0],q.data()[1],q.data()[2],q.data()[3]) ;

		//danceInterp::OutputMessage("Original Position %lf %lf %lf", vals[0], vals[1], vals[2]) ;
		

		// set the new position
		vals[0] = position[0] ;
		//vals[1] = position[1] ; do not change the y
		vals[2] = position[2] ;


		//r->setFrame(f,vals) ;
		r->setFrame(f, &q);
		r->setFrame(f,vals[0],0) ;
		r->setFrame(f,vals[1],1) ;
		r->setFrame(f,vals[2],2) ;
		// set the new quaternion

//		r->setFrame(f, rq);


			
	
		
	}

}

**/

std::vector<std::string>& Character::getParameters()
{
	return m_parameters;
}

std::string Character::getParameter(std::string match)
{
	for (int x = 0; x < m_parameters.size(); x++)
	{
		int pos = m_parameters[x].find(match);
		if (pos != std::string::npos)
		{
			return m_parameters[x];
		}
	}

	return "";
}


void Character::setCycle(bool val)
{
	//m_cycle->setValue(val);

	// determine the final position which will be used as an offset
	CharJoint* root = this->getRoot();
	if (!root)
	{
		setVector(m_globalOffset, 0, 0, 0);
		return;
	}

	int channels[6];
	int numChannels = root->getChannels(channels);
	int chanX = -1, chanY = -1, chanZ = -1;
	for (int x = 0; x < numChannels; x++)
	{
		if (channels[x] == CharJoint::XPOSITION)
			chanX = x;
		if (channels[x] == CharJoint::YPOSITION)
			chanY = x;
		if (channels[x] == CharJoint::ZPOSITION)
			chanZ = x;
	}
	int numFrames = root->getNumFrames();
	double frames[6];
	root->getFrames(0, frames);
	Vector initialPos = {0,0,0};
	if (chanX >= 0)
		initialPos[0] = frames[chanX];
	if (chanY >= 0)
		initialPos[1] = frames[chanY];
	if (chanZ >= 0)
		initialPos[2] = frames[chanZ];
	root->getFrames(numFrames - 1, frames);
	Vector finalPos = {0,0,0};
	if (chanX >= 0)
		finalPos[0] = frames[chanX];
	if (chanY >= 0)
		finalPos[1] = frames[chanY];
	if (chanZ >= 0)
		finalPos[2] = frames[chanZ];
	VecSubtract(m_cycleOffset, finalPos, initialPos);
}

bool Character::isCycle()
{
	return m_cycle->getValue();
}

void Character::setGlobalOffset(Vector offset)
{
	VecCopy(m_globalOffset, offset);
}

void Character::getGlobalOffset(Vector offset)
{
	VecCopy(offset, m_globalOffset);
}

void Character::getCycleOffset(Vector offset)
{
	VecCopy(offset, m_cycleOffset);
}

void Character::output(int mode)
{
	//PlugIn::output(mode);
	this->draw(getTime(), m_useInterpolation->getValue());
}

fltk::Widget* Character::getInterface()
{
	if (m_gui == NULL) 
	{
		m_gui = new CharacterWindow(this, 0, 0, 300, 400, this->getName());
	}

	return m_gui;
}

void Character::setTime(double time)
{
	m_time->setValue(time);
}

double Character::getTime()
{
	return m_time->getValue();
}

void Character::setOffsetTime(double offsetTime)
{
	m_offsetTime->setValue(offsetTime);
}

double Character::getOffsetTime()
{
	return m_offsetTime->getValue();
}


void Character::calcWorldTransMatrix()
{
	calculateMatricesRecurse(this->getTime(), this->getRoot());
}

void Character::notify(DSubject* subject)
{
	DAttribute* attribute = dynamic_cast<DAttribute*>(subject);
	if (attribute == this->m_showJoints)
	{
		for (int j = 0; j < this->getNumJoints(); j++)
		{
			CharJoint* joint = this->getJointByIndex(j);
			BoolAttribute* showJointsAttr = dynamic_cast<BoolAttribute*>(joint->getAttribute("showjoint"));
			if (showJointsAttr)
				showJointsAttr->setValue(m_showJoints->getValue());
		}
		dance::Refresh();
	}
	else if (attribute == this->m_showBones)
	{
		dance::Refresh();
	}
	else if (attribute == this->m_showJoints)
	{
		for (int j = 0; j < m_allJoints.size(); j++)
		{
			CharJoint* joint = m_allJoints[j];
			BoolAttribute* drawJointAttr = dynamic_cast<BoolAttribute*>(joint->getAttribute("showjoint"));
			if (drawJointAttr)
			{
				drawJointAttr->setValue(m_showJoints->getValue());
			}
		}
		dance::Refresh();
	}
	else if (attribute == this->m_showBonesAsLines)
	{
		dance::Refresh();
	}
	else if (attribute == m_boneColor)
	{
		dance::Refresh();
	}
	else if (attribute == m_jointColor)
	{
		for (int j = 0; j < this->getNumJoints(); j++)
		{
			CharJoint* joint = this->getJointByIndex(j);
			Vec3Attribute* jointColorAttr = dynamic_cast<Vec3Attribute*>(joint->getAttribute("jointcolor"));
			if (jointColorAttr)
				jointColorAttr->setValue(m_jointColor->getValue());
		}
		dance::Refresh();
	}
	else if (attribute == m_boneWidth)
	{
		dance::Refresh();
	}
	else if (attribute == m_jointSize)
	{
		for (int j = 0; j < this->getNumJoints(); j++)
		{
			CharJoint* joint = this->getJointByIndex(j);
			DoubleAttribute* jointSizeAttr = dynamic_cast<DoubleAttribute*>(joint->getAttribute("jointsize"));
			if (jointSizeAttr)
				jointSizeAttr->setValue(m_jointSize->getValue());
		}
		dance::Refresh();
	}
	else if (attribute == m_selectedJoint)
	{
		CharJoint* joint = this->getJointByName((char*) m_selectedJoint->getValue().c_str());
	}
	else if (attribute == m_desiredTime)
	{
		this->setTime(m_desiredTime->getValue());
	}
	else if (attribute == m_time)
	{
		this->calculateMatrices(m_time->getValue());
		dance::Refresh();
	}
	else if (attribute == m_offset[0] || attribute == m_offset[1] || attribute == m_offset[2])
	{
		setOffset(m_offset[0]->getValue(), m_offset[1]->getValue(), m_offset[2]->getValue());
		dance::Refresh();
	}
	else if (attribute == m_rotation[0] || attribute == m_rotation[1] || attribute == m_rotation[2])
	{
		setRotation(m_rotation[0]->getValue(), m_rotation[1]->getValue(), m_rotation[2]->getValue());
		dance::Refresh();
	}
	else if (attribute == m_scale)
	{
		setScale(m_scale->getValue());
		dance::Refresh();
	}
	else if (attribute == m_cycle)
	{
		setCycle(m_cycle->getValue());
		dance::Refresh();
	}



}

void Character::onConnect(DConnection* connection)
{
	if (connection->getFrom() == this)
	{
		if (connection->getType() == "rootjoint")
		{
			m_root = dynamic_cast<CharJoint*>(connection->getTo());
			setRoot(m_root);
			this->recalculateJointList();
		}
		else if (connection->getType() == "joint")
		{
			this->recalculateJointList();
		}
	}
}

void Character::onDisconnect(DConnection* connection)
{
	if (connection->getFrom() == this)
	{
		if (connection->getType() == "rootjoint")
		{
			setRoot(NULL);
			this->recalculateJointList();
		}
		else if (connection->getType() == "joint")
		{
			this->recalculateJointList();
		}
	}
}
