/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_ARCBALL_H
#define	_ARCBALL_H

#ifndef	DLLENTRY
#ifdef WIN32
#define	DLLENTRY __declspec(dllexport)
#else
#define	DLLENTRY
#endif
#endif

#include <cstdio>
#include "BallAux.h"

typedef	enum AxisSet{NoAxes, CameraAxes, BodyAxes, OtherAxes, NSets} AxisSet;
typedef	float *ConstraintSet;

class DLLENTRY ArcBall
{
	public:	

		ArcBall();
		~ArcBall();

		void init(float *init_matrix=NULL);
		void place(HVect center, double radius);
		void mouse(HVect vNow);
		void useSet(AxisSet axisSet);
		void setOtherAxes(HMatrix conAxis);
		void showResult();
		void hideResult();
		void update();
		void value(HMatrix mNow);
		void setMatrix(HMatrix mat);
		void setQuat(float qNow[4]);
		Quat* getQuat();
		void beginDrag();
		void beginDragReset();
		void endDrag();
		void draw();
		bool isDrag();

		static HVect mouseOnSphere(HVect mouse, HVect ballCenter, double ballRadius);
		static HVect constrainToAxis(HVect loose, HVect axis);
		static int nearestConstraintAxis(HVect	loose, HVect *axes, int	nAxes);
		static Quat qt_FromBallPoints(HVect from, HVect to);
		static void qt_ToBallPoints(Quat q, HVect *arcFrom, HVect *arcTo);

	private:
		void drawAnyArc(HVect vFrom, HVect vTo);
		void drawHalfArc(HVect n);
		void drawConstraints();
		void drawDragArc();
		void drawResultArc();

		HVect center;
		double radius;
		Quat qNow;
		Quat qDown;
		Quat qDrag;
		HVect vNow;
		HVect vDown;
		HVect vFrom;
		HVect vTo;
		HVect vrFrom;
		HVect vrTo;
		HMatrix mNow;
		HMatrix mDown;
		bool isShowResult;
		bool isDragging;
		ConstraintSet sets[NSets];
		int	setSizes[NSets];
		AxisSet axisSet;
		int	axisIndex;
		HMatrix userAxes;
};

#endif
