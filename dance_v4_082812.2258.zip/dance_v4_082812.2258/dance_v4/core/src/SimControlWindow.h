/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef _SIMCONTROLWINDOW_
#define _SIMCONTROLWINDOW_

#include "defs.h"
#include <fltk/Window.h>
#include <fltk/MenuBar.h>
#include <fltk/Button.h>
#include <fltk/CheckButton.h>
#include <fltk/ValueSlider.h>
#include <fltk/FloatInput.h>
#include <fltk/Choice.h>

class DLLENTRY SimControlWindow : public fltk::Group
{
	public:
		SimControlWindow(int x, int y, int w, int h, const char* name);

		void updateGUI();

		void adjustCurrent();
		void disablePlaybackControls();
		void enablePlaybackControls();
		void disableSimulatorControls();
		void enableSimulatorControls();


		static void sim_step_cb(fltk::Widget*, void*);
		static void disp_step_cb(fltk::Widget*, void*);
		static void playback_step_cb(fltk::Widget* o, void* p);
		static void run_cb(fltk::Widget*, void*);
		static void stop_cb(fltk::Widget*, void*);
		static void reset_cb(fltk::Widget*, void*);
		static void test_cb(fltk::Widget*, void*);
		static void end_time_cb(fltk::Widget*, void*);
		static void current_time_cb(fltk::Widget*, void*);

		static void playbackrun_cb(fltk::Widget* o, void* p);
		static void playbackstepback_cb(fltk::Widget* o, void* p);
		static void playbackrewind_cb(fltk::Widget* o, void* p);
		static void playbackstepforward_cb(fltk::Widget* o, void* p);
		static void playbackfastforward_cb(fltk::Widget* o, void* p);
		static void playbackspeeed_cb(fltk::Widget* o, void* p);
		static void loopplay_cb(fltk::Widget* o, void* p);

		static double valuatorCB(double a, SimControlWindow* com);

		fltk::Button *buttonSimPlay;
		fltk::Button *buttonSimStop;
		fltk::Button *buttonSimReset;

		fltk::Button *buttonPlayback;
		fltk::Button *buttonPlaybackStepBack;
		fltk::Button *buttonPlaybackStepForward;
		fltk::Button *buttonPlaybackRewind;
		fltk::Button *buttonPlaybackFastForward;
		fltk::CheckButton* checkLoopPlay;


		fltk::ValueSlider* slider;
		fltk::FloatInput* timeStep;
		fltk::FloatInput* displayTimeStep;
		fltk::FloatInput* inputEndTime;
		fltk::CheckButton* checkPlaybackMode;
		fltk::Choice* choicePlaybackSpeed;

};
#endif

