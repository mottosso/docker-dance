#ifndef _DNODEMANAGER_H
#define _DNODEMANAGER_H

#include "defs.h"
#include "DNode.h"

class DLLENTRY DNodeManager
{
	public:
		DNodeManager();
		~DNodeManager();

		void setRoot(DNode* node);
		DNode* getRoot();

	private:
		DNode* m_root;
};

#endif