/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _DEFS_H_
#define _DEFS_H_

#define NOMINMAX
#include "mathdefs.h"

#ifdef WIN32
	#include <windows.h>

	#ifdef _EXPORTING_DANCE_CORE
		#define	DLLENTRY __declspec(dllexport)
	#else
		#define	DLLENTRY __declspec(dllimport)
	#endif

	#define	DLLEXPORT __declspec(dllexport)
	#define	DLLIMPORT __declspec(dllimport)

	#ifdef EXP_STL
	#    define DECLSPECIFIER __declspec(dllexport)
	#    define EXPIMP_TEMPLATE
	#else
	#    define DECLSPECIFIER __declspec(dllimport)
	#    define EXPIMP_TEMPLATE extern
	#endif


#else

	#define	DLLENTRY
	#define	DLLEXPORT
	#define	DLLIMPORT

#endif

#ifdef WIN32 
#define INLINE inline
#else
#define INLINE
#endif

#define	LDISPLAY_WIRE	     1
#define	LDISPLAY_MONITOR     2
#define	LDISPLAY_COMPUTE_SHADOW_MAP	     4
#define	LDISPLAY_SOLID       8
#define	LDISPLAY_SELECTION  16
#define	LDISPLAY_USE_SHADOW_MAP	     256
#define	LDISPLAY_SHADOW_MAP_PASS4	  512

// For joints.
#define	JDISPLAY_CENTRES    32
#define JDISPLAY_MANIPS     64
#define JDISPLAY_SELECTION	128

// Shading
#define SHADE_FLAT 600
#define SHADE_SMOOTH 601

#define MAX_LINE 512
#define MAXPATHLENGTH 512

#define DANCE_OK 1
#define DANCE_CONTINUE 0
#define DANCE_ERROR -1

// some commands for a cleaner compilation
#ifdef WIN32
#pragma warning( disable : 4275 4244 4231 4251 4018 4996 ) // 4251 STL doesn't compile cleanly on Visual C++ due to problem with DLL declarations
#endif
// 4018 signed/unsigned mismatch when looping through STL vectors with integer declarations instead of unsigned integer declarations
#endif // _DEFS_H_

