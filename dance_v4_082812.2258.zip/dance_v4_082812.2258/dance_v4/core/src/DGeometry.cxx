/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	NO_GL
#ifdef WIN32
#include <windows.h>
#endif
#include "opengl.h"
//#include <GL/glu.h>
//#include "FL/Fl_Tabs.h"
#endif
#include "defs.h"
#include "DGeometry.h"
#include "PlugIn.h"
#include "GLutilities.h"
#include "danceInterp.h"
#include "dance.h"
#include "ViewManager.h"
#include "arbMatrix.h"
#include "GeometryWindow.h"
#include "vectorObj.h"
#include "matrix3x3.h"
#include "RAPID.h"

using namespace fltk;

void printArrayTcl(double matrix[4][4])
{
	for (int i = 0 ; i < 4 ; i++)
	{
		danceInterp::OutputMessage("%lf %lf %lf %lf", matrix[i][0], matrix[i][1], matrix[i][2], matrix[i][3]);
	}
}


int DGeometry::m_NumGeometry = 0;

DGeometry::DGeometry() : PlugIn()
{
    setBaseType("geometry");

	m_RAPIDmodel = NULL;

	setMaterial(dance::MaterialManager->getDefaultMaterial()) ;

/*    m_Color[0] = (float) .4 ;
    m_Color[1] = (float) .4 ;
    m_Color[2] = (float) .4 ;
    m_Color[3] = (float) 1.0 ;
	this->setColor(m_Color[0], m_Color[1], m_Color[2], m_Color[3]);*/

    
    m_ID = m_NumGeometry++; // We will always have the first valid ID as 1 since ID 0 corresponds to the
    // proxy geometry.
	setIdentMat(&m_transMatrix[0][0], 4);
	m_geometryWindow = NULL;
	
	setUseTransMatrix(true);
	this->showSolid();

	m_tx = this->createDoubleAttribute("translatex", 0, true, "Transformations", 10, false, true);
	m_ty = this->createDoubleAttribute("translatey", 0, true, "Transformations", 20, false, true);
	m_tz = this->createDoubleAttribute("translatez", 0, true, "Transformations", 30, false, true);
	m_rx = this->createDoubleAttribute("rotatex", 0, true, "Transformations", 40, false, true);
	m_ry = this->createDoubleAttribute("rotatey", 0, true, "Transformations", 50, false, true);
	m_rz = this->createDoubleAttribute("rotatez", 0, true, "Transformations", 60, false, true);
	m_scaleu = this->createDoubleAttribute("scaleuniform", 1.0, true, "Transformations", 70, false, true);
	m_sx = this->createDoubleAttribute("scalex", 1.0, true, "Transformations", 80, false, true);
	m_sy = this->createDoubleAttribute("scaley", 1.0, true, "Transformations", 90, false, true);
	m_sz = this->createDoubleAttribute("scalez", 1.0, true, "Transformations", 100, false, true);
	ArbMatrix arbMatrix;
	m_matrix = this->createMatrixAttribute(std::string("transmatrix"), arbMatrix, true, "Transformations", 400, false, true, true);

	m_transparency = this->createDoubleAttribute("transparency", 1.0, true, "Display", 300, false, true);
	m_transparency->setMin(0);
	m_transparency->setMax(1);

}

DGeometry::~DGeometry()
{
	if (m_geometryWindow != NULL)
		delete m_geometryWindow;

}

void DGeometry::output(int mode)
{
	PlugIn::output(mode);
}

void DGeometry::displayBoundingBox(float r, float g, float b, float a)
{
	// Display Oriented-Bounding-Box if present.
	DObject::displayBoundingBox(r, g, b, a);
}

// monitor points functions

//		   getMonitorPoints()
// Accepts a transformation matrix or NULL and fills
// in the pre allocated	matrix pts with	the monitor
// points. THe monitor poins are returned in link
// coordinate system unless matrix m is	supplied
// in which case they are multiplied by	it.
// Matrices *m,
// [ R 0 ]
// [ T 1 ]
void DGeometry::getMonitorPoints(double (*m)[4][4], Vector *pts)
{
    int	i ;

    for( i = 0 ; i < m_MonitorPoints.m_NumPoints ; i++ )
		VecCopy(pts[i],	m_MonitorPoints.m_Point[i])	;

    if(	m != NULL )
		for( i = 0 ; i < m_MonitorPoints.m_NumPoints ; i++ )
			transformPoint_mat(pts[i],*m) ;
}

void DGeometry::getMonitorPointsPrevPosition(double (*m)[4][4], Vector *pts)
{
    int	i ;

    for( i = 0 ; i < m_MonitorPoints.m_NumPoints ; i++ )
		VecCopy(pts[i],	m_MonitorPoints.m_PrevPos[i])	;

    if(	m != NULL )
		for( i = 0 ; i < m_MonitorPoints.m_NumPoints ; i++ )
			transformPoint_mat(pts[i],*m) ;
}


int DGeometry::getMonitorPoints(Vector **pts)
{
    *pts = m_MonitorPoints.m_Point ;
    return  m_MonitorPoints.m_NumPoints ;
}


int DGeometry::getMonitorPointsPrevPos(Vector **pts)
{
    *pts = m_MonitorPoints.m_PrevPos ;
    return  m_MonitorPoints.m_NumPoints ;
}

void DGeometry::DeleteMonitorPoints()
{
    m_MonitorPoints.Deallocate() ;
}

int DGeometry::AllocateMonitorPoints(int n)
{
    return m_MonitorPoints.Allocate(n) ;
}

int DGeometry::assignMonitorPoints(int n, bool random)
{
    if( n < 1 )
    {
		danceInterp::OutputMessage("ERROR: assignMonitorPoints: number of points must be > 0!\n") ;
	return 0 ;
    }
    if( AllocateMonitorPoints(n) == n )
		return createMonitorPoints(n, random) ;
    else
	return 0 ;
}

int DGeometry::assignMonitorPoints(int n, Vector *p)
{
    if( n < 1 )
    {
		danceInterp::OutputMessage("ERROR: assignMonitorPoints: number of points must be > 0!\n") ;
		return 0 ;
    }
    if( AllocateMonitorPoints(n) != n ) return 0 ;
    for( int i = 0 ; i < n ; i++ )
	VecCopy(m_MonitorPoints.m_Point[i], p[i]) ;
    return n ;
}

void DGeometry::displayLocalAxes()
{
	// Draw origin.
	glPushAttrib(GL_LIGHTING_BIT);
	glDisable(GL_LIGHTING);
	double origin[3] = {0.0,0.0,0.0};
	glColor4f(1.0,1.0,0.0,1.0);
	glPointSize(3.0);
	glBegin(GL_POINTS);
	glVertex3dv(origin);
	glEnd();
	glPointSize(1.0);

	// Draw axes.
	double xaxis[3] = { 1.0,0.0,0.0 };
	double yaxis[3] = { 0.0,1.0,0.0 };
	double zaxis[3] = { 0.0,0.0,1.0 };

	double dim[3];
	m_BoundingBox.getDimensions(dim);

	glColor4f(1.0,0.0,0.0,1.0);
	GLdrawVector(origin,xaxis,dim[0]*0.5);
	glColor4f(0.0,1.0,0.0,1.0);
	GLdrawVector(origin,yaxis,dim[1]*0.5);
	glColor4f(0.0,0.0,1.0,1.0);
	GLdrawVector(origin,zaxis,dim[2]*0.5);
	glPopAttrib();	
}

void DGeometry::getBounds(double dim [ 3 ])
{
	calcBoundingBox(NULL);
	m_BoundingBox.getDimensions(dim);
}

void DGeometry::getTransMatrix(double matrix[4][4])
{
	for (int x = 0; x < 4; x++)
		for (int y = 0; y < 4; y++)
			matrix[x][y] = m_transMatrix[x][y];

}

void DGeometry::setTransMatrix(double matrix[4][4])
{
	ArbMatrix m(4,4);
	for (int x = 0; x < 4; x++)
		for (int y = 0; y < 4; y++)
		{
			m_transMatrix[x][y] = matrix[x][y];
			m.elem(x,y) = matrix[x][y];
		}

	m_matrix->setValue(m);
}

void DGeometry::Center(bool changeVertices)
{
	BoundingBox box;
	this->calcBoundingBox(&box);
	Vector mid;
	box.getMidPoint(mid);
	this->Translate(-mid[0], -mid[1], -mid[2], true);

	if (changeVertices)
	{
		this->calcTransMatrix();
		this->applyTransMatrix();
	}
}

void DGeometry::Rotate(const char *axis, double degrees, int center)
{
	switch (*axis)
	{
	case 'x':
		m_rx->setValue(degrees);
		break;
	case 'y':
		m_ry->setValue(degrees);
		break;
	case 'z':
		m_rz->setValue(degrees);
		break;
	default:
		break;
	}

	calcTransMatrix();
}

void DGeometry::Rotate(double x, double y, double z, int center)
{
	m_rx->setValue(x);
	m_ry->setValue(x);
	m_rz->setValue(x);

	calcTransMatrix();
}

void DGeometry::Translate(double x, double y, double z, bool relative)
{
	if (relative)
	{
		m_tx->setValue(m_tx->getValue() + x);
		m_ty->setValue(m_ty->getValue() + y);
		m_tz->setValue(m_tz->getValue() + z);
	}
	else
	{
		m_tx->setValue(x);
		m_ty->setValue(y);
		m_tz->setValue(z);
	}

	calcTransMatrix();
}

void DGeometry::Scale(double sx, double sy, double sz, int center)
{
	m_sx->setValue(sx);
	m_sy->setValue(sy); 
	m_sz->setValue(sz);

	calcTransMatrix();
}

void DGeometry::getCenter(Vector pos)
{
	pos[0] = m_transMatrix[3][0];
	pos[1] = m_transMatrix[3][1];
	pos[2] = m_transMatrix[3][2];
}

void DGeometry::displayAxis(double axis[3],	double length, int arrowtype)
{
	double point[3];
	zeroVector(point);

    GLdrawVector(point,	axis, length);
}

void DGeometry::displayScaleAxis(double axis[3], double length, int arrowtype)
{
	double point[3];
	zeroVector(point);
	glColor3f(0.0, 1.0, 0.0);
	glutSolidSphere(.2 * length, 10, 10);
    GLdrawVector2(point,	axis, length);
}

void DGeometry::displayRotationalAxis(double axis[3], double length, int arrowtype)
{
	glBegin(GL_LINE_LOOP);
	for (int i=0; i < 360; i++)
	{
		float degInRad = i * M_PI / 180.0;
		glVertex2f(cos(degInRad) * length, sin(degInRad) * length);
	}
	glEnd();
}

void DGeometry::displayManipulators()
{
	/*
	glPushAttrib(GL_ENABLE_BIT);

	// Calculate suitable arrow	lengths	for inboard and	outboard vectors.
	// Scale these arrows as a percentage of the View Volume dimensions.
	double arrowLength = 1.0;
	DView *wview = dance::AllViews->getViewFocus();
	if (wview)
	{
		double pos[3] = { m_transMatrix[3][0], m_transMatrix[3][1], m_transMatrix[3][2] };
		double win[3]; wview->getWindowCoords(pos,win);
		double worldwidth = wview->getFrustumWidth(win[2]);
//		arrowLength = 0.05*worldwidth;
		arrowLength = 0.1*worldwidth;
	}

	//const GLfloat sliderColor[] = {0.0f,0.0f,0.9f,1.0f};
	//const GLfloat revoluteColor[] = {0.2f,0.2f,0.9f,1.0f};
    //glColor4fv(revoluteColor);
	//glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, revoluteColor) ;
	

	double x[3] = {1, 0, 0};
	double y[3] = {0, 1, 0};
	double z[3] = {0, 0, 1};

    // Draw any	axes that must be in the inboard frame.
    // Need to add glPushName
    glPushMatrix();
	glMultMatrixd(&m_transMatrix[0][0]);

	glDisable(GL_LIGHTING);

	
	glPushName(0);
	if (this->isManipulatorRotation())
	{
		displayRotationalAxis(z, arrowLength);
	}
	else if (this->isManipulatorTranslation())
	{
		glutSolidCube(.2 * arrowLength);
	}
	else if (this->isManipulatorScale())
	{
		glutSolidSphere(.2 * arrowLength, 10, 10);
	}
	glPopName();

	// X
	glColor3f(1.0, 0.0, 0.0);
	glPushName(1);
	glPushMatrix();
	if (this->isManipulatorRotation())
	{
		glRotatef(90, 0, 1, 0);
		displayRotationalAxis(x, arrowLength);
	}
	else if (this->isManipulatorTranslation())
	{
		displayAxis(x, arrowLength);
	}
	else if (this->isManipulatorScale())
	{
		displayScaleAxis(x, arrowLength, 1);
	}
	glPopMatrix();
	glPopName();

	// Y
	glPushMatrix();
	glColor3f(1.0, 1.0, 0.0);
	glPushName(2);
	if (this->isManipulatorRotation())
	{
		glRotatef(90, 1, 0, 0);
		displayRotationalAxis(y, arrowLength);
	}
	else if (this->isManipulatorTranslation())
	{
		glRotated(1 * 180.0/M_PI, 0, 1, 0);
		displayAxis(y, arrowLength);
	}
	else if (this->isManipulatorScale())
	{
		glRotated(1 * 180.0/M_PI, 0, 1, 0);
		displayScaleAxis(y, arrowLength, 1);
	}
	glPopName();
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.0, 0.0, 1.0);
	glPushName(3);
	if (this->isManipulatorRotation())
	{
		displayRotationalAxis(z, arrowLength);
	}
	else if (this->isManipulatorTranslation())
	{
		glRotated(1 * 180.0/M_PI, 0, 0, 1);
		displayAxis(z, arrowLength);
	}
	else if (this->isManipulatorScale())
	{
		glRotated(1 * 180.0/M_PI, 0, 0, 1);
		displayScaleAxis(z, arrowLength, 1);
	}
	glPopName();
    glPopMatrix();

	glPopAttrib();
	*/
}


int DGeometry::InteractStart(Event* event)
{
	return 0;
}

int DGeometry::Interact(Event* event)
{
	return 0;
}

int DGeometry::InteractEnd(Event* event)
{
	return 0;
}

Widget* DGeometry::getInterface()
{
	if (m_geometryWindow == NULL)
	{
		m_geometryWindow = new GeometryWindow(this, -1, -1, -1, -1, this->getName());
	}

	return m_geometryWindow;
}

void DGeometry::calcTransMatrix()
{
	
	double matrix[4][4];
	setIdentMat(&matrix[0][0], 4);
	TransMatFromScaleRotTrans(matrix, 
								m_sx->getValue(), 
								m_sy->getValue(), 
								m_sz->getValue(),
								m_rx->getValue() * M_PI / 180.0, 
								m_ry->getValue() * M_PI / 180.0, 
								m_rz->getValue() * M_PI / 180.0, 
								m_tx->getValue(), 
								m_ty->getValue(), 
								m_tz->getValue()
								);

	transpArray(m_transMatrix, matrix);
	ArbMatrix m(4,4);
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			m.elem(r,c) = m_transMatrix[r][c];
	m_matrix->setValue(m);
	
	/*
	// scale, rotate then translate
	Matrix3x3 scaleMatrix;
	scaleMatrix.identity();

	// scale
	VectorObj s(m_scaling);
	scaleMatrix.setScale(s);

	// rotation center
	// ... incorporate origin of rotation here

	Matrix3x3 multMatrix;

	// rotate
	Matrix3x3 rotateMatrix;
	VectorObj xaxis(1.0, 0.0, 0.0);
	rotateMatrix.setRotation(xaxis, m_rotation[0] * M_PI / 180.0);
	multMatrix = rotateMatrix * scaleMatrix;

	VectorObj yaxis(0.0, 1.0, 0.0);
	rotateMatrix.setRotation(yaxis, m_rotation[1] * M_PI / 180.0);
	multMatrix = rotateMatrix * multMatrix;

	VectorObj zaxis(0.0, 0.0, 1.0);
	rotateMatrix.setRotation(zaxis, m_rotation[2] * M_PI / 180.0);
	multMatrix = rotateMatrix * multMatrix;

	// multiply by inverse of axis of rotation

	// translation

	danceInterp::OutputMessage("Before transpose & translation:");
	for (int r = 0; r < 3; r++)
		danceInterp::OutputMessage("%lf %lf %lf", multMatrix[r][0], multMatrix[r][1], multMatrix[r][2]);


	multMatrix.transpose();
	for (int r = 0; r < 3; r++)
		for (int c = 0; c < 3; c++)
			m_transMatrix[r][c] = multMatrix[r][c];

	m_transMatrix[3][0] = m_translation[0];
	m_transMatrix[3][1] = m_translation[1];
	m_transMatrix[3][2] = m_translation[2];
	*/
}

void DGeometry::setRotationCenter(Vector center)
{
	VecCopy(m_rotationCenter, center);
}

void DGeometry::getRotationCenter(Vector& center)
{
	VecCopy(center, m_rotationCenter);
}

void DGeometry::getTranslation(Vector trans)
{
	trans[0] = m_tx->getValue();
	trans[1] = m_ty->getValue();
	trans[2] = m_tz->getValue();
}

void DGeometry::getScaling(Vector scale)
{
	scale[0] = m_sx->getValue();
	scale[1] = m_sy->getValue();
	scale[2] = m_sz->getValue();
}

void DGeometry::getRotation(Vector rotations)
{
	rotations[0] = m_rx->getValue();
	rotations[1] = m_ry->getValue();
	rotations[2] = m_rz->getValue();
}

void DGeometry::setUseTransMatrix(bool val)
{
	m_useTransMatrix = val;
}

bool DGeometry::useTransMatrix()
{
	return m_useTransMatrix;
}

void DGeometry::showMesh()
{
	m_renderType = GEOMETRY_MESH;
}

void DGeometry::showSolid()
{
	m_renderType = GEOMETRY_SOLID;
}

void DGeometry::showVertices()
{
	m_renderType = GEOMETRY_VERTICES;
}

bool DGeometry::isShowMesh()
{
	return m_renderType == GEOMETRY_MESH;
}

bool DGeometry::isShowSolid()
{
	return m_renderType == GEOMETRY_SOLID;
}

bool DGeometry::isShowVertices()
{
	return m_renderType == GEOMETRY_VERTICES;
}


int DGeometry::commandPlugIn(int argc, char	**argv)
{
	int ret = PlugIn::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

	if (strcmp(argv[0], "apply_transform") == 0)
	{
		this->applyTransMatrix();
		danceInterp::OutputMessage("Transformation matrix has been applied to '%s' resulting in new vertices.", this->getName());
		return DANCE_OK;
	}
	else if  (strcmp(argv[0], "use_trans_matrix") == 0)
	{
		if (argc < 2)
		{
			// usage
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "true") == 0)
		{
			this->setUseTransMatrix(true);
		}
		else if (strcmp(argv[1], "false") == 0)
		{
			this->setUseTransMatrix(false);
		}
		else
		{
			if (argc < 2)
			{
				// usage
				return DANCE_ERROR;
			}
		}
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if  (strcmp(argv[0], "apply_trans_matrix") == 0)
	{
		this->applyTransMatrix();
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "trans_matrix") == 0)
	{
		if (argc < 17)
		{
			// usage
			danceInterp::OutputMessage("Please set all 16 values for transformation matrix for geometry %s in row order.", this->getName());
			return DANCE_ERROR;
		}
		int count = 0;
		double matrix[4][4];
		for (int r = 0; r < 4; r++)
		{
			for (int c = 0; c < 4; c++)
			{
				matrix[r][c] = atof(argv[count + 1]);
				count++;
			}
		}
		this->setTransMatrix(matrix);
		danceInterp::OutputMessage("Transformation matrix for geometry %s has been set.", this->getName());
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "translate") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: translate <x> <y> <z>\n");
			return DANCE_ERROR;
		}
		double x = atof(argv[1]);
		double y = atof(argv[2]);
		double z = atof(argv[3]);
		if (argc == 5 && strcmp(argv[4], "true") == 0)
			this->Translate(x, y, z, true);
		else
			this->Translate(x, y, z);
		danceInterp::OutputMessage("Geometry %s has been translated by (%f %f %f)...\n", getName(), x, y, z);
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "rotation") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: rotation <xrot> <yrot> <zrot>");
			return DANCE_ERROR;
		}
		Vector rotation;
		rotation[0] = atof(argv[1]);
		rotation[1] = atof(argv[2]);
		rotation[2] = atof(argv[3]);
		this->Rotate(rotation[0], rotation[1], rotation[2]);
		danceInterp::OutputMessage("Geometry %s has been rotated by (%f %f %f)...\n", getName(), rotation[0], rotation[1], rotation[2]);
		dance::AllViews->postRedisplay();
		return DANCE_OK;

	}

	else if (strcmp(argv[0], "rotate") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: rotate <axis> <degrees> <center?yes/no>\n");
			return DANCE_ERROR;
		}
		double degrees = atof(argv[2]);
		int center = 0;
		if (strcmp(argv[3], "yes") == 0)
			center = 1;
		else if (strcmp(argv[3], "no") == 0)
			center = 0;
		else
		{
			danceInterp::OutputMessage("Usage: rotate <axis> <degrees> <center?yes/no>\n");
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "x") != 0 && strcmp(argv[1], "y") != 0 && strcmp(argv[1], "z") != 0 )
		{
			danceInterp::OutputMessage("Usage: rotate <axis> <degrees> <center?yes/no>\n");
			return DANCE_ERROR;
		}
		this->Rotate(argv[1], degrees, center);
		danceInterp::OutputMessage("Geometry %s has been rotated along the %s-axis by %f degrees and %s centered\n", getName(), argv[1], degrees, argv[3]);
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "scale") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: scale <x> <y> <z>\n");
			return DANCE_ERROR;
		}
		double x = atof(argv[1]);
		double y = atof(argv[2]);
		double z = atof(argv[3]);
		this->Scale(x, y, z, 0);
		danceInterp::OutputMessage("Geometry %s has been scaled by (%f %f %f)...\n", getName(), x, y, z);
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "transparency") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: transparency <0..1>\n");
			return DANCE_ERROR;
		}
		else
		{
			double val = atof(argv[1]);
			this->setTransparency((float) val);
			danceInterp::OutputMessage("Transparency is now %f", val);
			dance::Refresh();
			return DANCE_OK;
		}
	}
	else if (strcmp(argv[0], "material") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.geometry(\"%s\", \"material\", \"<material_name>\")");
			return DANCE_ERROR;
		}

		Material* material = dance::MaterialManager->getMaterialbyName(argv[1]);
		if (material == NULL)
		{
			danceInterp::OutputMessage("Material %s does not exist in the material manager.", argv[1]);
			return DANCE_ERROR;
		}
		this->setMaterial(material);
		danceInterp::OutputMessage("Geometry %s now uses material %s.", this->getName(), argv[1]);
		dance::AllViews->postRedisplay();
		return DANCE_OK;
		
	}
	else if (strcmp(argv[0], "solid") == 0)
	{
		this->showSolid();
		danceInterp::OutputMessage("Geometry %s will now be shown as a solid.", this->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "mesh") == 0)
	{
		this->showMesh();
		danceInterp::OutputMessage("Geometry %s will now be shown as a mesh.", this->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "vertices") == 0)
	{
		this->showVertices();
		danceInterp::OutputMessage("Geometry %s will now be shown as a vertices.", this->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "visible") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.geometry(\"%s\", \"visible\", \"<true|false>\")", this->getName());
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "true") == 0)
		{
			this->setVisible(true);
			danceInterp::OutputMessage("Geometry %s will now be visible.", this->getName());
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "false") == 0)
		{
			this->setVisible(false);
			danceInterp::OutputMessage("Geometry %s will now be hidden.", this->getName());
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Usage: dance.geometry(\"%s\", \"visible\", \"<true|false>\")", this->getName());
			return DANCE_ERROR;
		}
	}
	/* REMOVED BY Paco Abad
	If you want to change the color of an object, change its material, or change the material's properties 
	else if (strcmp(argv[0], "color") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: geometry %s color <r> <g> <b>", this->getName());
			return DANCE_ERROR;
		}

		float r = (float) atof(argv[1]);
		float g = (float) atof(argv[2]);
		float b = (float) atof(argv[3]);
		this->setColor(r, g, b, 1.0);
		dance::AllViews->postRedisplay();

		return DANCE_OK;
	}
	*/

	return DANCE_CONTINUE;
}


/*
void DGeometry::setColor(float r, float g, float b, float a)
{
	m_Color[0] = r;
	m_Color[1] = g;
	m_Color[2] = b;
	m_Color[3] = a;

	// copy the color to the diffuse and ambient parameters of the material if present
	if (material != NULL)
	{
		this->getMaterial()->setDiffuseColor(m_Color);;
		this->getMaterial()->setAmbientColor(m_Color);;
	}
}

void DGeometry::getColor(float& r, float& g, float& b, float& a)
{
	r = m_Color[0];
	g = m_Color[1];
	b = m_Color[2];
	a = m_Color[3];
}
*/


void DGeometry::setMaterial(Material* m)
{
	m_material = m;
}

Material* DGeometry::getMaterial()
{
	return m_material;
}

#ifdef _DEBUG

static void write_vector(std::ofstream & file, Vector v) {
	file << v[0] << " " << v[1] << " " << v[2] ;
}


void DGeometry::write_properties(std::ofstream & file) {
/* Write the value of the properties in the object to the file */
	int i,j;

	file << "id: " << m_ID << "\n";

	file << (m_visible->getValue() ? "VISIBLE" : "INVISIBLE") << "\n";

	file << "transMatrix: \n";
	for (i=0; i<4; i++) {
		for (j=0;j<4;j++)
			file << m_transMatrix[i][j] << " ";
		file << "\n";
	}

	file << (m_useTransMatrix?"":"NO ") << "USE transMatrix"  << "\n";

	file << "origX: " << m_origX << "  origY: " << m_origY;

	file << "\nm_translation: ";
	Vector tVec = { m_tx->getValue(), m_ty->getValue(), m_tz->getValue() };
	write_vector(file, tVec);

	file << "\nm_rotation: ";
	Vector rVec = { m_rx->getValue(), m_ry->getValue(), m_rz->getValue() };
	write_vector(file, rVec);

	file << "\nm_rotationCenter: ";
	write_vector(file, m_rotationCenter);


	file << "\nm_scaling: ";
	Vector sVec = { m_sx->getValue(), m_sy->getValue(), m_sz->getValue() };
	write_vector(file, sVec);

}
#endif

int DGeometry::createMonitorPoints(int numPoints, bool random)
{
	return 0;
}

void DGeometry::save(int mode, std::ofstream& file)
{
	PlugIn::save(mode, file);

	if (mode == 1)
	{
		char buff[512];
	
		// transformation matrix
		double matrix[4][4];
		this->getTransMatrix(matrix);
		sprintf(buff, "\"trans_matrix\", %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f", 
				matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3], 
				matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3], 
				matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3], 
				matrix[3][0], matrix[3][1], matrix[3][2], matrix[3][3]);
		pythonSave(file, buff);
		
		// use transformation matrix?
		if (this->useTransMatrix())
		{
			sprintf(buff, "\"use_trans_matrix\", \"true\"");
			pythonSave(file, buff);		
		}
		else
		{
			sprintf(buff, "\"use_trans_matrix\", \"false\"");
			pythonSave(file, buff);		
			sprintf(buff, "\"apply_trans_matrix\"");
			pythonSave(file, buff);		
		}

		// monitor points
		// ...

		// material
		Material* m = this->getMaterial();
		if (m != NULL)
		{
			sprintf(buff, "\"material\", \"%s\"", this->getMaterial()->getMaterialName());
			pythonSave(file, buff);
		}

		// solid, vertices or mesh
		if (this->isShowSolid())
		{
			sprintf(buff, "\"solid\"");
			pythonSave(file, buff);
		}
		else if (this->isShowMesh())
		{
			sprintf(buff, "\"mesh\"");
			pythonSave(file, buff);
		}
		else if (this->isShowVertices())
		{
			sprintf(buff, "\"vertices\"");
			pythonSave(file, buff);
		}
	}
}

void DGeometry::decomposeTransformationMatrix()
{ 
	// decomposes the transformation matrix into the scaling, translation and rotation parameters

	// translation
	m_tx->setValue(m_transMatrix[3][0]);
	m_tx->setValue(m_transMatrix[3][1]);
	m_tz->setValue(m_transMatrix[3][2]);

	// rotation
	Matrix3x3 rotMatrix(m_transMatrix);
	// remove scaling, assume that the scaling is explicitly identified and undo that value
	rotMatrix[0][0] *= 1.0 / m_sx->getValue();
	rotMatrix[1][1] *= 1.0 / m_sy->getValue();
	rotMatrix[2][2] *= 1.0 / m_sz->getValue();
	
	Matrix3x3 transpMatrix;
	transpMatrix = rotMatrix.transpose();

	VectorObj angles;
	transpMatrix.matToEuler(Matrix3x3::XYZ, angles, false);

	m_rx->setValue(angles[0] * 180.0 / M_PI);
	m_rx->setValue(angles[1] * 180.0 / M_PI);
	m_rz->setValue(angles[2] * 180.0 / M_PI);
}

void DGeometry::setUpShadowMapPass1(void)
{
	return; 
}
void DGeometry::cleanUpAfterShadowMapPass1(void) 
{

	return ;

}

void DGeometry::setUpShadowMapPass3(void)
{
	//glCullFace(GL_BACK) ;
	//glEnable(GL_CULL_FACE) ;
//	glDisable(GL_LIGHTING) ;
	//glEnable(GL_TEXTURE_2D) ;
//	glEnable(GL_DEPTH_TEST);
//	glDisable(GL_BLEND) ;
//	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	//glHint(GL_LINE_SMOOTH_HINT, GL_DONT_CARE);
	//glColor4f(0.0,0.0,0.0,1) ;

	return ;

}

void DGeometry::setUpShadowMapPass4(void)
{
	
	//glCullFace(GL_BACK) ;
	//glEnable(GL_CULL_FACE) ;
	//glEnable(GL_LIGHTING) ;
	//glDisable(GL_TEXTURE_2D) ;
	//glEnable(GL_DEPTH_TEST);
	//glEnable(GL_BLEND) ;
	//glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	return ;
}

void DGeometry::notify(DSubject* subject)
{
	PlugIn::notify(subject);
	if (subject == m_tx || subject == m_ty || subject == m_tz)
	{
		calcTransMatrix();
		dance::AllViews->postRedisplay();
	}
	else if (subject == m_rx || subject == m_ry || subject == m_rz)
	{
		calcTransMatrix();
		dance::AllViews->postRedisplay();
	}
	else if (subject == m_sx || subject == m_sy || subject == m_sz)
	{
		calcTransMatrix();
		dance::AllViews->postRedisplay();
	}
	else if (subject == m_scaleu)
	{
		m_sx->setValue(m_scaleu->getValue());
		m_sy->setValue(m_scaleu->getValue());
		m_sz->setValue(m_scaleu->getValue());
		calcTransMatrix();
		dance::AllViews->postRedisplay();
	}
}

void DGeometry::getLocalCoord(double local[3], double world[3])
{
	double invMatrix[4][4];
	invert_matrix(m_transMatrix, invMatrix);
	VecCopy(local, world);
	transformPoint_mat(local, m_transMatrix);
}

void DGeometry::getWorldCoord(double world[3], double local[3])
{
	VecCopy(world, local);
	transformPoint_mat(world, m_transMatrix);
}
