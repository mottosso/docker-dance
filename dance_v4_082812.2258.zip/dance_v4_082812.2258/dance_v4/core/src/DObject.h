/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	DObject_h
#define	DObject_h

#include "defs.h"
#include "Event.h"
#include <fltk/Widget.h>
#include "BoundingBox.h"
#include "DAttribute.h"
#include "DCommand.h"

#include "DObserver.h"
#include <fstream>
#include <map>

class DObjectRefList;
class DConnection;
class DGeometry;
class DAttributeManager;

class DLLENTRY DObject : public DObserver {
public:
  DObject();
  virtual ~DObject();

  INLINE const char *getBaseType() { return BaseType.c_str(); } ;
  INLINE const char *getName() {	return Name.c_str();} ;
  INLINE const char *getFileName() {return Filename.c_str();} ;
  INLINE const char *getType() {	return Type.c_str()	;} ;

  INLINE void setBaseType(const char *type) { BaseType = type; };
  INLINE void setFileName(const char *filename) { Filename = filename; };
  INLINE void setName(const char *name) { Name = name; };
  INLINE void setType(const char *type) { Type = type; };

  virtual void output(int mode = 1);
  virtual void render(int argc, char** argv, std::ofstream& file) { return;};

  virtual void Highlight(float r, float g, float b, float a) { return; };
  virtual void GetWorldFrame(double frame[3][3], double local[3]) {return;};

  virtual int commandPlugIn(int argc, char **argv) ;
  
  virtual int interact(Event* event) {	return 0; };
  virtual int interactStart(Event* event) { return 0 ; };
  virtual int interactEnd(Event* event) {return 0 ;};

  INLINE void setSelected(bool val);
  INLINE bool isSelected();

  virtual void getLocalCoord(double local[3], double world[3]) { return; };
  virtual void getWorldCoord(double world[3], double local[3]) { return; };
  virtual void getWorldVelocity(double worldvel[3], double local[3]) { return; };
  virtual void GetWorldVector(double worldve[3], double local[3]) { return; };

	virtual double getState(int index) { return  MINFLOAT ;} ;
	virtual void getState(double *state) { return ;} ;
	virtual int getStateSize() { return 0 ;} ;
	virtual void setState(int index, double val) { return;} ;
	virtual void setState(double *state) { return ;} ;
	virtual void setState(double time) { return ;} ;

//  virtual void GetVelocities(double *dstate) { return ;}
//  virtual int GetVelocitiesSize() { return GetStateSize(); } ;
//  virtual void UpdateState(double *state) { return ;} ;
//  virtual void SetLastState() { return; };

  INLINE void Synchronize(double currentTime) { m_LocalTime = currentTime; };


/*  virtual int IdleCB() { return 0 ;} ;	// This routine is to be called in the
				        // dance::idleCB so that an object
					// can do something on each own  every time.
                                        // a value of 0 indicates that the object
                                        // hasn't done anything, so no need to redisplay
  virtual void AfterAllSimStep(double time, double dt) { return;} ;	// called in idleCB after all objects 
                                                        // take a step   
  virtual void BeforeAllSimStep(double time, double dt) { return ;} ;	// called in dance::idleCB before all obj`ects take
                                                        // a simulation step
*/
  virtual BoundingBox *calcBoundingBox(BoundingBox *box = NULL) { return  NULL;} ;
  void displayBoundingBox(float	r, float g, float b, float a);

  INLINE void setVisible(bool val) { m_visible->setValue(val); }
  INLINE bool isVisible() { return m_visible->getValue(); }

  void addDependency(DObject* object);
  void removeDependency(DObject* object);
  void addDependencyOnly(DObject* object);
  void removeDependencyOnly(DObject* object);
  DObjectRefList* getDependencies();
  void addDependencyReverse(DObject* object);
  void removeDependencyReverse(DObject* object);
  DObjectRefList* getDependenciesReverse();
  void clearDependencies();
  void clearReverseDependencies();

  virtual void onDependencyRemoval(DObject* object);

  virtual  fltk::Widget* getInterface();

  unsigned int getID(); // unique id
  static unsigned int GetNextID();

  virtual void save(int mode, std::ofstream& file);

  std::map<std::string, DCommand*>& getCommands();

  void addAttribute(DAttribute* attr);
  DAttribute* getAttribute(std::string name);
  BoolAttribute* createBoolAttribute(std::string name, bool value, bool notifySelf, std::string groupName, int priority, bool isReadOnly = false, bool isLocked = false, bool isHidden = false);
  IntAttribute* createIntAttribute(std::string name, int value, bool notifySelf, std::string groupName, int priority, bool isReadOnly = false, bool isLocked = false, bool isHidden = false);
  DoubleAttribute* createDoubleAttribute(std::string name, double value, bool notifySelf, std::string groupName, int priority, bool isReadOnly = false, bool isLocked = false, bool isHidden = false);
  StringAttribute* createStringAttribute(std::string name, std::string value, bool notifySelf, std::string groupName, int priority, bool isReadOnly = false, bool isLocked = false, bool isHidden = false);
  Vec3Attribute* createVec3Attribute(std::string name, double val, double val2, double val3, bool notifySelf, std::string groupName, int priority, bool isReadOnly = false, bool isLocked = false, bool isHidden = false);
  MatrixAttribute* createMatrixAttribute(std::string name, ArbMatrix& val, bool notifySelf, std::string groupName, int priority, bool isReadOnly = false, bool isLocked = false, bool isHidden = false);
  
  bool removeAttribute(std::string name);
  std::map<std::string, DAttribute*>& getAttributeList();
  DAttributeManager* getAttributeManager();
  virtual void notify(DSubject* subject);

  virtual void onConnect(DConnection* connection);
  virtual void onDisconnect(DConnection* connection);

protected:
  double m_LocalTime;
  BoundingBox m_BoundingBox;

  void pythonSave(std::ofstream& file, char* str);

  DAttributeManager* m_attributeManager;

  BoolAttribute* m_visible;

private:
  std::string Filename;
  std::string Name;
  std::string Type;
  std::string BaseType;
  bool m_selected;
  unsigned int m_uniqueID;

  static unsigned int nextID;

  fltk::Widget* m_win;
  DObjectRefList* m_dependencies;
  DObjectRefList* m_dependenciesReverse;

  std::map<std::string, DAttribute*> m_attributeList;

  std::map<std::string, DCommand*> m_commands;
} ;

#endif

