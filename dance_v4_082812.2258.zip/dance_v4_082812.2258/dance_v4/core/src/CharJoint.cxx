/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "CharJoint.h"
#include "CharJointWindow.h"
#include "myMath.h"
#include "dance.h"
#include "danceInterp.h"
#include "matrix3x3.h"
#include "arbMatrix.h"
#include "Character.h"
#include "Quaternion.h"
#include <cstdlib>
#include "vectorObj.h"
#include "DConnectionManager.h"
#include "DConnection.h"

#define PI 3.14159
#define DEGREESTORADIANS (PI / 180.0)

Quaternion CharJoint::m_defaultQuaternion;

int CharJoint::curUniqueID = 0;

CharJoint::CharJoint(const char* name) : PlugIn()
{
	setName(name);
	curUniqueID++;
	uniqueID = curUniqueID;


	this->setDirection(0.0, 0.0, 0.0);

	m_parent = NULL;
	m_isEndEffector = false;
	for (int x = 0; x < 6; x++)
		m_channels[x] = 0;
	m_numChannels = 0;


	setIdentMat(&m_transMatrix[0][0], 4);
	setFrameTime(.033);

	setCharacter(NULL);

	m_useAxis = false;

	m_length = 0.0;

	setInterpolatedJoint(NULL);

	setIgnoreChannels(false);
	m_characterIndex = -1;

	for (int x = 0; x < 6; x++)
		setLimits(x, 0.0, 0.0);

//	m_firstTranslationChannel = -1;
//	m_lastTranslationChannel = -1;

	m_gui = NULL;
	m_worldMatrixDirty = true;

	
	m_offset[0] = this->createDoubleAttribute("offsetx", 0.0, true, "Parameters", 50);
	m_offset[1] = this->createDoubleAttribute("offsety", 0.0, true, "Parameters", 60);
	m_offset[2] = this->createDoubleAttribute("offsetz", 0.0, true, "Parameters", 70);

	m_endEffectorOffset[0] = this->createDoubleAttribute("endeffectoroffsetx", 0.0, true, "Parameters", 80);
	m_endEffectorOffset[1] = this->createDoubleAttribute("endeffectoroffsety", 0.0, true, "Parameters", 90);
	m_endEffectorOffset[2] = this->createDoubleAttribute("endeffectoroffsetz", 0.0, true, "Parameters", 100);

	this->setOffset(0.0, 0.0, 0.0);
	this->setEndEffectorOffset(0.0, 0.0, 0.0);

	m_showJoint = this->createBoolAttribute("showjoint", true, true, "Display", 110);
	m_showTrajectories = this->createBoolAttribute("showtrajectories", false, true, "Display", 120);
	m_showGesturePhases = this->createBoolAttribute("showgestures",  false, true, "Display", 130);
}

CharJoint::~CharJoint()
{
	clearFrames();
	if (m_gui)
		delete m_gui;
}

void CharJoint::output(int mode)
{
	//PlugIn::output(mode);

	glPushAttrib(GL_LIGHTING_BIT);
	glDisable(GL_LIGHTING);

	if (m_showJoint->getValue())
	{
		// draw a sphere to indicate the joint
		double matrix[4][4];
		if (this->m_numChannels == 0)
			this->m_worldMatrixDirty = true; // is this necessary?
		getWorldTransMatrix(matrix);
		glPushMatrix();
		glMultMatrixd(&matrix[0][0]);

		Vector color = {1, 1, 1};
		double height = .1;
		if (this->getCharacter())
			this->getCharacter()->getJointColor(color);

		if (this->isSelected())
			glColor3d(1.0, 1.0, 0.0);
		else
			glColor3dv(color);
		if (this->getCharacter())
			height = this->getCharacter()->getHeight() * this->getCharacter()->getJointSize();
		glutWireSphere(height, 6, 6);
		glPopMatrix();
	}

	// draw the path if indicated
	if (m_showTrajectories->getValue())
	{
		glDisable(GL_LIGHTING);
		// show the path
		glColor3f(1.0, 1.0, 0.0);
		glBegin(GL_LINE_STRIP);
		for (int f = 0; f < m_path.size(); f++)
		{
			glVertex3d(m_path[f][0], m_path[f][1], m_path[f][2]);
		}
		glEnd();


		if (m_path.size() > 0)
		{
			// show the start and end points
			glPushAttrib(GL_POINT_BIT | GL_LIGHTING_BIT);

			glPointSize(3.0);
			glColor3f(0.0, 1.0, 0.0);
			glBegin(GL_POINTS);
			glVertex3d(m_path[0][0], m_path[0][1], m_path[0][2]);

			int pathSize = m_path.size();
			glColor3f(1.0, 0.0, 0.0);
			glVertex3d(m_path[pathSize - 1][0], m_path[pathSize - 1][1], m_path[pathSize - 1][2]);
			glEnd();

			glPopAttrib();
		}
		
	}


	// if this is an skm file, draw the gesture phases
	if (m_showGesturePhases->getValue())
	{
		glPushAttrib(GL_POINT_BIT | GL_LIGHTING_BIT);
		glDisable(GL_LIGHTING);

		std::string str;
		int pos;
		double readyTime = 0.0;
		std::string readyTimeParam = this->getCharacter()->getParameter("ready time:");
		if (readyTimeParam != "")
		{
			pos = readyTimeParam.find(":");
			if (pos != std::string::npos)
				readyTimeParam = readyTimeParam.substr(pos + 1, readyTimeParam.size() - 4);
				readyTime = atof(readyTimeParam.c_str());
		}
		int readyFrame = int(readyTime / this->getFrameTime());

		double strokeStartTime = 0.0;
		std::string strokeStartTimeParam = this->getCharacter()->getParameter("strokeStart time:");
		if (strokeStartTimeParam != "")
		{
			pos = strokeStartTimeParam.find(":");
			if (pos != std::string::npos)
				strokeStartTimeParam = strokeStartTimeParam.substr(pos + 1, strokeStartTimeParam.size() - 4);
				strokeStartTime = atof(strokeStartTimeParam.c_str());
		}
		int strokeStartFrame = int(strokeStartTime / this->getFrameTime());

		double emphasisTime = 0.0;
		std::string emphasisTimeParam = this->getCharacter()->getParameter("emphasis time:");
		if (emphasisTimeParam != "")
		{
			pos = emphasisTimeParam.find(":");
			if (pos != std::string::npos)
				emphasisTimeParam = emphasisTimeParam.substr(pos + 1, emphasisTimeParam.size() - 4);
				emphasisTime = atof(emphasisTimeParam.c_str());
		}
		int emphasisFrame = int(emphasisTime / this->getFrameTime());

		double strokeTime = 0.0;
		std::string strokeTimeParam = this->getCharacter()->getParameter("stroke time:");
		if (strokeTimeParam != "")
		{
			pos = strokeTimeParam.find(":");
			if (pos != std::string::npos)
				strokeTimeParam = strokeTimeParam.substr(pos + 1, strokeTimeParam.size() - 4);
				strokeTime = atof(strokeTimeParam.c_str());
		}
		int strokeFrame = int(strokeTime / this->getFrameTime());
		
		double relaxTime = 0.0;
		std::string relaxTimeParam = this->getCharacter()->getParameter("relax time:");
		if (relaxTimeParam != "")
		{
			pos = relaxTimeParam.find(":");
			if (pos != std::string::npos)
				relaxTimeParam = relaxTimeParam.substr(pos + 1, relaxTimeParam.size() - 4);
				relaxTime = atof(relaxTimeParam.c_str());
		}
		int relaxFrame = int(relaxTime / this->getFrameTime());
		
		int curFrame = 0;
		// initial phase
		glColor3f(.5, .5, .5);
		glBegin(GL_LINE_STRIP);
		for ( ; curFrame < readyFrame && curFrame < m_path.size(); curFrame++)
		{
			glVertex3d(m_path[curFrame][0], m_path[curFrame][1], m_path[curFrame][2]);
		}
		glEnd();

		// ready phase
		glPointSize(1.0);
		glColor3f(0.0, 1.0, 0.0);
		glBegin(GL_LINE_STRIP);
		if (curFrame > 0)
			curFrame--;
		for ( ; curFrame < strokeStartFrame && curFrame < m_path.size(); curFrame++)
		{
			glVertex3d(m_path[curFrame][0], m_path[curFrame][1], m_path[curFrame][2]);
		}
		glEnd();

		// stroke start phase
		glPointSize(3.0);
		glColor3f(1.0, 1.0, 0.0);
		glBegin(GL_LINE_STRIP);
		if (curFrame > 0)
			curFrame--;
		for ( ;curFrame < emphasisFrame && curFrame < m_path.size(); curFrame++)
		{
			glVertex3d(m_path[curFrame][0], m_path[curFrame][1], m_path[curFrame][2]);
		}
		glEnd();

		// emphasis phase
		glPointSize(5.0);
		glColor3f(1.0, 0.0, 0.0);
		glBegin(GL_LINE_STRIP);
		if (curFrame > 0)
			curFrame--;
		for ( ; curFrame < strokeFrame && curFrame < m_path.size(); curFrame++)
		{
			glVertex3d(m_path[curFrame][0], m_path[curFrame][1], m_path[curFrame][2]);
		}
		glEnd();

		// relax time
		glPointSize(3.0);
		glPointSize(1+6.0);
		glColor3f(1.0, 0.0, 0.0);
		glBegin(GL_LINE_STRIP);
		if (curFrame > 0)
			curFrame--;
		for ( ; curFrame < relaxFrame && curFrame < m_path.size(); curFrame++)
		{
			glVertex3d(m_path[curFrame][0], m_path[curFrame][1], m_path[curFrame][2]);
		}
		glEnd();

		// remainder of motion
		glPointSize(1.0);
		glColor3f(.5, .5, .5);
		glBegin(GL_LINE_STRIP);
		if (curFrame > 0)
			curFrame--;
		for ( ; curFrame < m_path.size(); curFrame++)
		{
			glVertex3d(m_path[curFrame][0], m_path[curFrame][1], m_path[curFrame][2]);
		}
		glEnd();

		glPopAttrib();
	}
	
	glPopAttrib();	
}

double CharJoint::convertToLocalTime(double time)
{
	Character* character = this->getCharacter();
	if (!character)
		return time;
	double offsetTime = 0.0;
	offsetTime = character->getOffsetTime();
	return time - offsetTime;
}

void CharJoint::setOffset(double x, double y, double z)
{
	m_offset[0]->setValue(x);
	m_offset[1]->setValue(y);
	m_offset[2]->setValue(z);
}

void CharJoint::setEndEffectorOffset(double x, double y, double z)
{
	m_endEffectorOffset[0]->setValue(x);
	m_endEffectorOffset[1]->setValue(y);
	m_endEffectorOffset[2]->setValue(z);
}

void CharJoint::getEndEffectorOffset(Vector &offset)
{
	double scale = this->getCharacter()->getScale();
	offset[0] = m_endEffectorOffset[0]->getValue() * scale;
	offset[1] = m_endEffectorOffset[1]->getValue() * scale;
	offset[2] = m_endEffectorOffset[2]->getValue() * scale;
}

void CharJoint::addChild(CharJoint* child)
{
	m_children.push_back(child);
}

void CharJoint::removeChild(CharJoint* child)
{
	for (std::vector<CharJoint*>::iterator iter = m_children.begin(); iter != m_children.end(); iter++)
	{
		if (*iter == child)
		{
			m_children.erase(iter);
			break;
		}
	}
}


void CharJoint::setEndEffector(bool val)
{
	m_isEndEffector = val;
}

bool CharJoint::isEndEffector()
{
	return m_isEndEffector;
}

void CharJoint::getOffset(Vector &offset)
{
	double scale = this->getCharacter()->getScale();
	offset[0] = m_offset[0]->getValue() * scale;
	offset[1] = m_offset[1]->getValue() * scale;
	offset[2] = m_offset[2]->getValue() * scale;
}

//std::vector<CharJoint*> CharJoint::getChildren()
//{
//	return m_children;
//}

void CharJoint::setParent(CharJoint* parent)
{
	m_parent = parent;
	if (m_parent != NULL)
		setCharacter(m_parent->getCharacter());
}

CharJoint* CharJoint::getParent()
{
	return m_parent;
}

void CharJoint::setCharacter(Character* ch)
{
	m_character = ch;
}

Character* CharJoint::getCharacter()
{
	return m_character;
}

void CharJoint::getOffsetFromRoot(Vector &offset)
{
	if (m_parent == NULL)
	{
		getOffset(offset);
	}
	else
	{
		m_parent->getOffsetFromRoot(offset);
		Vector off;
		this->getOffset(off);
		offset[0] += off[0];
		offset[1] += off[1];
		offset[2] += off[2];
	}
}

void CharJoint::setChannels(int numOfChannels, int* channels)
{
	m_firstTranslationChannel = -1;
	m_lastTranslationChannel = - 1;
	m_numChannels = numOfChannels;
	for (int x = 0; x < m_numChannels; x++)
	{
		m_channels[x] = channels[x];
		if (channels[x] == CharJoint::XPOSITION || 
			channels[x] == CharJoint::YPOSITION || 
			channels[x] == CharJoint::ZPOSITION)
		{
			if (m_firstTranslationChannel == -1)
				m_firstTranslationChannel = x;
			else
				m_lastTranslationChannel = x;
		}
	}
}

int CharJoint::getChannels(int* channels)
{
	for (int x = 0; x < m_numChannels; x++)
		channels[x] = m_channels[x];

	return m_numChannels;
}

int CharJoint::getNumChannels()
{
	return m_numChannels;
}

void CharJoint::addFrame(double* vals)
{
	if (m_numChannels == 0)
		return;

	double* newframe = new double[6];
	int numChannels = this->getNumChannels();
	

	for (int x = 0; x < numChannels; x++)
	{
		newframe[x] = vals[x];
	}
	for (int i = numChannels; i < 6; i++)
	{
		newframe[i] = 0.0;
	}

	m_frames.push_back(newframe);
 	m_quaternions.push_back(convertToQuaternion(newframe));
	// make space on the points list for x, y, z
	m_points.push_back(0.0); 
	m_points.push_back(0.0);
	m_points.push_back(0.0);
	if (this->isEndEffector())
	{
		m_endEffectorPoints.push_back(0.0); 
		m_endEffectorPoints.push_back(0.0);
		m_endEffectorPoints.push_back(0.0);
	}
	// make space for offset adjustments
	m_offsetAdjustments.push_back(1.0);
}

void CharJoint::addFrame(Quaternion* quat)
{
	if (m_numChannels == 0)
		return;

	// add the quaternion representation
 	m_quaternions.push_back(quat);

	// add the Euler angle representation of the quaternion
	Matrix3x3 danceMat;
	quat->toMatrix(danceMat);

	int order = CharJoint::determineRotationOrder(m_channels, getNumChannels(), this);
	VectorObj angles;
	danceMat.matToEuler(order, angles);

	double *newframe = new double[6];
	int numChannels = this->getNumChannels();
	for (int i = 0; i < numChannels; i++)
	{
		if (m_channels[i] == CharJoint::XPOSITION || 
			m_channels[i] == CharJoint::YPOSITION || 
			m_channels[i] == CharJoint::ZPOSITION)
		{
			newframe[i] = 0.0;
		}
		else if (m_channels[i] == CharJoint::XROTATION)
		{
			newframe[i] = angles.x() * 180.0 / M_PI;
		}
		else if (m_channels[i] == CharJoint::YROTATION)
		{
			newframe[i] = angles.y() * 180.0 / M_PI;
		}
		else if (m_channels[i] == CharJoint::ZROTATION)
		{
			newframe[i] = angles.z() * 180.0 / M_PI;
		}
	}
	for (int i = numChannels; i < 6; i++)
	{
		newframe[i] = 0.0;
	}

	m_frames.push_back(newframe);

	// make space on the points list for x, y, z
	m_points.push_back(0.0); 
	m_points.push_back(0.0);
	m_points.push_back(0.0);
	if (this->isEndEffector())
	{
		m_endEffectorPoints.push_back(0.0); 
		m_endEffectorPoints.push_back(0.0);
		m_endEffectorPoints.push_back(0.0);
	}
	m_offsetAdjustments.push_back(1.0);
}

void CharJoint::addFrame(double x, double y, double z)
{
	if (m_numChannels == 0)
		return;

	// add the point representation
	m_points.push_back(x);
	m_points.push_back(y);
	m_points.push_back(z);

	// add dummy end effector points
	// for now, make them the same at their parent joint
	if (this->isEndEffector())
	{
		m_endEffectorPoints.push_back(x);
		m_endEffectorPoints.push_back(y);
		m_endEffectorPoints.push_back(z);
	}

	/// add a dummy frame representation
	double *newframe = new double[6];
	for (int x = 0; x < 6; x++)
		newframe[x] = 0.0;
	m_frames.push_back(newframe);

	// add a dummy quaternion representation
	Quaternion* mg = new Quaternion();
 	m_quaternions.push_back(mg);
	// make space for offset adjustments
	m_offsetAdjustments.push_back(1.0);
}

void CharJoint::clearFrames()
{
	for (int x = 0; x < (int) m_frames.size(); x++)
	{
		delete [] m_frames[x];
		if (m_quaternions[x] != NULL)
			delete m_quaternions[x];
		else
			danceInterp::OutputMessage("PROBLEM! Quaternion at index %d is NULL!", x);

	}

	m_frames.clear();
	m_quaternions.clear();
	m_points.clear();
	m_endEffectorPoints.clear();

	m_offsetAdjustments.clear();
}

int CharJoint::getNumFrames()
{
	return m_frames.size();
}

void CharJoint::setNumFrames(int num)
{
	if (num < m_frames.size())
	{
		for (int f = num; f < m_frames.size(); f++)
		{
			delete [] m_frames[f];
		}
		m_frames.resize(num);
	}
}

void CharJoint::getTransMatrix(double matrix[4][4])
{
	for (int i = 0; i < 4; i++)
		for (int j = 0; j < 4; j++)
			matrix[i][j] = m_transMatrix[i][j];
}

void CharJoint::calcTransMatrix(double time, bool useInterpolation)
{
	if (m_useAxis)
		calcTransMatrixASFAMC(time, useInterpolation);
	else
		calcTransMatrixBVH(time, useInterpolation);
	
	m_lastTime = time;
	if (m_lastTime < 0.0)
		m_lastTime = 0.0;
}

void CharJoint::addOffset(Vector offset)
{
	for (int x = 0; x < 3; x++)
		m_transMatrix[3][x] += offset[x];
}

void CharJoint::calcTransMatrixBVH(double time, bool useInterpolation)
{
	Vector off;
	this->getOffset(off);

	int translationChannelStart = this->getFirstTranslationChannel();

	double localTime = convertToLocalTime(time);
	if (localTime < 0.0) // get the zero position for frame times < 0
	{
		if (this->getCharacter()->isAdjustBoneLengths())
			VecNumMul(off, off, this->getOffsetAdjustment(0));

		setIdentMat(&m_transMatrix[0][0], 4);
		m_transMatrix[3][0] = off[0];
		m_transMatrix[3][1] = off[1];
		m_transMatrix[3][2] = off[2];

		if (this->getParent() == NULL)
		{
			// add in the offset
			Vector globalOffset;
			this->getCharacter()->getOffset(globalOffset);
			m_transMatrix[3][0] += globalOffset[0];
			m_transMatrix[3][1] += globalOffset[1];
			m_transMatrix[3][2] += globalOffset[2];
		}
		return;
	}

    // determine the appropriate frame
	
    double frame = localTime / m_frameTime;
    int frameNum = (int) frame;
	if (frameNum >= this->getNumFrames())
		frameNum = frameNum - 1;
    double diff = frame - (double) frameNum; 

	if (this->getCharacter()->isAdjustBoneLengths())
		VecNumMul(off, off, this->getOffsetAdjustment(frameNum));

	double tempMatrix[4][4];

	int numFrames = getNumFrames();
	if (numFrames == 0)
	{
		setIdentMat(&m_transMatrix[0][0], 4);
		if (!this->m_useAxis)
		{
			Vector off;
			this->getOffset(off);
			m_transMatrix[3][0] = off[0];
			m_transMatrix[3][1] = off[1];
			m_transMatrix[3][2] = off[2];
		}
		return;
	}
	if (frameNum >= numFrames)
		frameNum = numFrames - 1;

	// get the starting quaternion
	Quaternion* qStart = getQuaternion(frameNum);
	
	Quaternion* qEnd;
	Quaternion qSlerp;

	// get the ending quaternion
	if (frameNum + 1 >= numFrames)
	{
		qEnd = getQuaternion(numFrames - 1);
	}
	else
	{
		qEnd = getQuaternion(frameNum + 1);
	}

	// quaternion slerping
	if (useInterpolation)
		qStart->Slerp(qEnd, diff, &qSlerp);
	else
		qSlerp.copy(qStart);

	setIdentMat(&tempMatrix[0][0], 4);

	// add the offset
	if (!this->m_useAxis)
	{
		Vector off;
		this->getOffset(off);
		tempMatrix[3][0] = off[0];
		tempMatrix[3][1] = off[1];
		tempMatrix[3][2] = off[2];
	}

	if (translationChannelStart != -1) // this joint has translation channels
	{
		double startFrame[6];
		double endFrame[6];
		getFrames(frameNum, startFrame);
		if (frameNum + 1 >= numFrames)
			getFrames(frameNum, endFrame);
		else
			getFrames(frameNum + 1, endFrame);

		for (int x = getFirstTranslationChannel(); x <= getLastTranslationChannel(); x++)
		{
			switch (m_channels[x])
			{
			case CharJoint::XPOSITION:
				if (useInterpolation)
					tempMatrix[3][0] += (startFrame[x] * ((1.0 - diff)) + (endFrame[x] * diff));
				else
					tempMatrix[3][0] += startFrame[x];
				break;
			case CharJoint::YPOSITION:
				if (useInterpolation)
					tempMatrix[3][1] += (startFrame[x] * (1.0 - diff)) + (endFrame[x] * diff);
				else
					tempMatrix[3][1] += startFrame[x];
				break;
			case CharJoint::ZPOSITION:
				if (useInterpolation)
					tempMatrix[3][2] += ((startFrame[x] * (1.0 - diff)) + (endFrame[x] * diff));
				else
					tempMatrix[3][2] += startFrame[x] ;
				break;
			}
		}

	}

	
	Matrix3x3 quatMatrix;
	qSlerp.toMatrix(quatMatrix);

	// copy back to m_transMatrix
	// matrix must be transposed to match OpenGL
	for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++)
					m_transMatrix[i][j] = quatMatrix[j][i];

	// write the translation
	if (!this->m_useAxis)
	{
		m_transMatrix[3][0] = tempMatrix[3][0];
		m_transMatrix[3][1] = tempMatrix[3][1];
		m_transMatrix[3][2] = tempMatrix[3][2];
	}
}

void CharJoint::calcTransMatrixASFAMC(double time, bool useInterpolation)
{
	Vector offset;
	this->getOffset(offset);

	double localTime = convertToLocalTime(time);
	if (localTime < 0.0) // get the zero position for frame times < 0
	{
		if (this->getCharacter()->isAdjustBoneLengths())
			VecNumMul(offset, offset, this->getOffsetAdjustment(0));

		setIdentMat(&m_transMatrix[0][0], 4);
		// add the offset
		m_transMatrix[3][0] = offset[0];
		m_transMatrix[3][1] = offset[1];
		m_transMatrix[3][2] = offset[2];
		return;
	}

    // determine the appropriate frame
    double frame = localTime / m_frameTime;
    int frameNum = (int) frame;

    double diff = frame - (double) frameNum;    

	if (this->getCharacter()->isAdjustBoneLengths())
		VecNumMul(offset, offset, this->getOffsetAdjustment(frameNum));


	double startFrame[6];
	double endFrame[6];

	getFrames(frameNum, startFrame);
	if (frameNum + 1 >= this->getNumFrames())
	{
		getFrames(frameNum, endFrame);
	}
	else
	{
		getFrames(frameNum + 1, endFrame);
	}

	Vector globalTrans;
	zeroVector(globalTrans);
//		int i, j;

// start frame
	Matrix3x3 startMatrix;
	startMatrix.identity();

	// add any positional changes 
	for (int c = 0; c < m_numChannels; c++)
	{
		if (m_channels[c] == CharJoint::XPOSITION)
		{
			if (useInterpolation)
				globalTrans[0] = (startFrame[c] * (1.0 - diff)) + (endFrame[c] * diff);
			else
				globalTrans[0] = startFrame[c];
		}
		else if (m_channels[c] == CharJoint::YPOSITION)
		{
			if (useInterpolation)
				globalTrans[1] = (startFrame[c] * (1.0 - diff)) + (endFrame[c] * diff);
			else
				globalTrans[1] = startFrame[c];
		}
		else if (m_channels[c] == CharJoint::ZPOSITION)
		{
			if (useInterpolation)
				globalTrans[2] = (startFrame[c] * (1.0 - diff)) + (endFrame[c] * diff);
			else
				globalTrans[2] = startFrame[c];
		}
		else if (m_channels[c] == CharJoint::XROTATION)
		{
				// apply the x-rotation
				Matrix3x3 rot;
				rot.setRotateMatrix(Matrix3x3::X, DEGREESTORADIANS * startFrame[c]);
				startMatrix = rot * startMatrix;
		}
		else if (m_channels[c] == CharJoint::YROTATION)
		{
				// apply the y-rotation
				Matrix3x3 rot;
				rot.setRotateMatrix(Matrix3x3::Y, DEGREESTORADIANS * startFrame[c]);
				startMatrix = rot * startMatrix;
		}
		else if (m_channels[c] == CharJoint::ZROTATION)
		{
				// apply the z-rotation
				Matrix3x3 rot;
				rot.setRotateMatrix(Matrix3x3::Z, DEGREESTORADIANS * startFrame[c]);
				startMatrix = rot * startMatrix;
		}
	}
	Quaternion qStart;
	qStart.fromMatrix(startMatrix);

	// how does this quaternion compare with the quaternion saved?
	Quaternion qSlerp;

	if (useInterpolation)
	{
		Matrix3x3 endMatrix;
		endMatrix.identity();

		for (int c = 0; c < m_numChannels; c++)
		{
			if (m_channels[c] == CharJoint::XROTATION)
			{
					// apply the x-rotation
					Matrix3x3 rot;
					rot.setRotateMatrix(Matrix3x3::X, DEGREESTORADIANS * endFrame[c]);
					endMatrix = rot * endMatrix;
			}
			else if (m_channels[c] == CharJoint::YROTATION)
			{
					// apply the y-rotation
					Matrix3x3 rot;
					rot.setRotateMatrix(Matrix3x3::Y, DEGREESTORADIANS * endFrame[c]);
					endMatrix = rot * endMatrix;
			}
			else if (m_channels[c] == CharJoint::ZROTATION)
			{
					// apply the z-rotation
					Matrix3x3 rot;
					rot.setRotateMatrix(Matrix3x3::Z, DEGREESTORADIANS * endFrame[c]);
					endMatrix = rot * endMatrix;
			}
		}
		Quaternion qEnd;
		qEnd.fromMatrix(endMatrix);
	
		qStart.Slerp(&qEnd, diff, &qSlerp);
	}
	else
	{
		qSlerp.copy(&qStart);
	}



	Matrix3x3 quatMatrix;
	qSlerp.toMatrix(quatMatrix);

	double tempMatrix[4][4];
	setIdentMat(&tempMatrix[0][0], 4);
	// copy back to m_transMatrix
	// transpose matrix to match OpenGL
	for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++)
					tempMatrix[i][j] = quatMatrix[j][i];

	double offsetMatrix[4][4];
	setIdentMat(&offsetMatrix[0][0], 4);
	offsetMatrix[0][3] = offset[0];
	offsetMatrix[1][3] = offset[1];
	offsetMatrix[2][3] = offset[2];

	double axisMatrix[4][4];
	for (int i = 0; i < 4; i++)
			for (int j = 0; j < 4; j++)
					axisMatrix[i][j] = m_axisRotMatrix[j][i];

	double axisMatrixInv[4][4];
	for (int i = 0; i < 4; i++)
			for (int j = 0; j < 4; j++)
					axisMatrixInv[i][j] = m_axisRotMatrixInv[j][i];

	double transMatrix[4][4];
	for (int i = 0; i < 4; i++)
			for (int j = 0; j < 4; j++)
					transMatrix[i][j] = tempMatrix[j][i];

	double temp[4][4];
//	multArray(&temp[0][0], &offsetMatrix[0][0], &axisMatrix[0][0], 4, 4, 4);
	multArray4x4(temp, offsetMatrix, axisMatrix);
	double temp2[4][4];
//	multArray(&temp2[0][0], &temp[0][0], &transMatrix[0][0], 4, 4, 4);
	multArray4x4(temp2, temp, transMatrix);
//	multArray(&temp[0][0], &temp2[0][0], &axisMatrixInv[0][0], 4, 4, 4);
	multArray4x4(temp, temp2, axisMatrixInv);

	for (int i = 0; i < 4; i++)
			for (int j = 0; j < 4; j++)
					m_transMatrix[j][i] = temp[i][j];

	// add the global translation, if any
	m_transMatrix[3][0] += globalTrans[0];
	m_transMatrix[3][1] += globalTrans[1];
	m_transMatrix[3][2] += globalTrans[2];
}


void CharJoint::setFrame(int frameNum, double val, int channel)
{
	if (frameNum >= (int) m_frames.size())
	{ 
		danceInterp::OutputMessage("Cannot set values at frame #%d, only %d frames...\n", frameNum, m_frames.size());
		return;
	}

	m_frames[frameNum][channel] = val;
	Quaternion* cur = m_quaternions[frameNum];
	Quaternion* temp = convertToQuaternion(m_frames[frameNum]);

	cur->copy(temp);

	delete temp;
}

void CharJoint::setFrame(int frameNum, double* vals)
{
	if (frameNum >= (int) m_frames.size())
	{
		danceInterp::OutputMessage("Cannot set values at frame #%d, only %d frames...\n", frameNum, m_frames.size());
		return;
	}

	int numChannels = this->getNumChannels();
	for (int x = 0; x < numChannels; x++)
		m_frames[frameNum][x] = vals[x];
	for (int i = numChannels; i < 6; i++)
		m_frames[frameNum][i] = 0.0;

	Quaternion* cur = m_quaternions[frameNum];
	Quaternion* temp = convertToQuaternion(m_frames[frameNum]);

	cur->copy(temp);

	delete temp;

/*	Quaternion* temp = m_quaternions[frameNum];
	delete temp;

	m_quaternions[frameNum] = convertToQuaternion(m_frames[frameNum]);
*/
}

void CharJoint::setFrame(int frameNum, Quaternion* quat)
{
	if (frameNum >= (int) m_frames.size())
	{
		danceInterp::OutputMessage("Cannot set values at frame #%d, only %d frames...\n", frameNum, m_frames.size());
		return;
	}

	Quaternion* cur = m_quaternions[frameNum];

	cur->copy(quat);

	this->convertToFrame(quat, m_frames[frameNum]);
}

void CharJoint::setPoint(int frameNum, double x, double y, double z)
{
	if (frameNum >= (int) m_frames.size())
	{
		danceInterp::OutputMessage("Cannot set point at frame #%d, only %d frames...\n", frameNum, m_frames.size());
		return;
	}

	// add XYZ location for joint
	m_points[3 * frameNum] = x;
	m_points[3 * frameNum + 1] = y;
	m_points[3 * frameNum + 2] = z;
}

void CharJoint::setEndEffectorPoint(int frameNum, double x, double y, double z)
{
	if (frameNum >= (int) m_frames.size())
	{
		danceInterp::OutputMessage("Cannot set end effector point at frame #%d, only %d frames...\n", frameNum, m_frames.size());
		return;
	}

	// add XYZ location for joint
	m_endEffectorPoints[3 * frameNum] = x;
	m_endEffectorPoints[3 * frameNum + 1] = y;
	m_endEffectorPoints[3 * frameNum + 2] = z;
}

void CharJoint::getFrames(int frameNum, double* frames)
{
	if (frameNum >= (int) m_frames.size())
	{
//		danceInterp::OutputMessage("Cannot get frame at index #%d, only %d frames...\n", frameNum, m_frames.size());
		// return the maximum frame
		frameNum = this->getNumFrames() - 1;
	}


	double scale = 1.0;
	Vector offset = {0.0, 0.0, 0.0};
	CharJoint* parent = getParent();
	if (parent == NULL)
	{
		scale = this->getCharacter()->getScale();
		this->getCharacter()->getOffset(offset);
	}

	for (int x = 0; x < m_numChannels; x++)
	{
		if (frameNum < 0) // apply the zero-position for any frame < 0
		{
			frames[x] = 0.0;
		}
		else
		{
			if (this->numTranslationChannels())
			{
				if (this->getFirstTranslationChannel() <= x &&
					this->getLastTranslationChannel() >= x)
				{
					frames[x] = m_frames[frameNum][x] * scale + offset[x];
				}
				else
				{
					frames[x] = m_frames[frameNum][x];
				}
			}
			else
			{
				frames[x] = m_frames[frameNum][x];
			}		
		}
	}
}

double* CharJoint::getFrames(int frameNum)
{
	if (frameNum >= (int) m_frames.size())
	{
		return NULL;
	}

	return m_frames[frameNum];
}

void CharJoint::getFramesByTime(double time, double* frames)
{
	double localTime = convertToLocalTime(time);
	// NOTE: This method gives a linear interpolation of 
	// the Euler values and is subject to Gimbal lock
	int numFrames = this->getNumFrames();
	double frameTime = this->getFrameTime();
	double maxTime = (double) numFrames * frameTime;
	if (localTime >=  maxTime)
	{
		//danceInterp::OutputMessage("Cannot get frame at index #%d, only %d frames...\n", frameNum, m_frames.size());
		// return the maximum frame
		localTime = maxTime;
	}

	double tempFrame = localTime * frameTime;
	int startFrame = (int) tempFrame;
	int endFrame = startFrame + 1;
	if (endFrame >= numFrames)
		endFrame = startFrame;

	double startFrames[6];
	double endFrames[6];

	double scale = 1.0;
	Vector offset = {0.0, 0.0, 0.0};
	CharJoint* parent = getParent();
	if (parent == NULL)
	{
		scale = this->getCharacter()->getScale();
		this->getCharacter()->getOffset(offset);

	}
	for (int x = 0; x < m_numChannels; x++)
	{
		if (startFrame < 0) // apply the zero-position for any frame < 0
		{
			startFrames[x] = 0.0;
			endFrames[x] = 0.0;
		}
		else
		{
			if (this->numTranslationChannels() > 0)
			{
				if (getFirstTranslationChannel() >= x &&
					getFirstTranslationChannel() <= x)
				{
					startFrames[x] = m_frames[startFrame][x] * scale + offset[x];
					endFrames[x] = m_frames[endFrame][x] * scale + offset[x];
				}
				else
				{
					startFrames[x] = m_frames[startFrame][x];
					endFrames[x] = m_frames[endFrame][x];
				}
			}
			else
			{
				startFrames[x] = m_frames[startFrame][x];
				endFrames[x] = m_frames[endFrame][x];
			}		
		}
	}

	// interpolate
	double interpVal = tempFrame - (double) startFrame;
	for (int x = 0; x < m_numChannels; x++)
	{
		frames[x] = (startFrames[x] * (1.0 - interpVal) + endFrames[x] * interpVal) / 2.0;
	}
}



void CharJoint::getPoint(double time, Vector pos)
{
	double localTime = convertToLocalTime(time);
    // determine the appropriate frame
    double frame = localTime / m_frameTime;
    int frameNum = (int) frame;
    double diff = frame - (double) frameNum; 

	if (frameNum >= this->getNumFrames())
		frameNum = this->getNumFrames() - 1;
	int nextFrame = frameNum + 1;
	if (nextFrame >= this->getNumFrames())
		nextFrame = this->getNumFrames() - 1;

	if (frameNum < 0 || nextFrame < 0)
	{
		Vector coord;
		this->getWorldCoord(-1.0, coord);
		VecCopy(pos, coord);
		return;
	}

	// interpolate between the two frames
	Vector start;
	start[0] = m_points[3 * frameNum];
	start[1] = m_points[3 * frameNum + 1];
	start[2] = m_points[3 * frameNum + 2];
	Vector end;
	end[0] = m_points[3 * nextFrame];
	end[1] = m_points[3 * nextFrame + 1];
	end[2] = m_points[3 * nextFrame + 2];

	for (int i = 0; i < 3; i++)
		pos[i] = start[i] * (1.0 - diff) + end[i] * diff;

	// factor in the scale and offset
	double scale = 1.0;
	Vector offset = {0.0, 0.0, 0.0};
	scale = this->getCharacter()->getScale();
	this->getCharacter()->getOffset(offset);
	for (int i = 0; i < 3; i++)
		pos[i] = (pos[i] * scale) + offset[i];

}

void CharJoint::getPoint(int frameNum, double& x, double& y, double& z)
{
	if (frameNum >= (int) m_frames.size())
	{
		danceInterp::OutputMessage("Cannot get point at frame #%d, only %d frames...\n", frameNum, m_frames.size());
		x = 0.0; y = 0.0; z = 0.0;
		return;
	}

	x = m_points[3 * frameNum];
	y = m_points[3 * frameNum + 1];
	z = m_points[3 * frameNum + 2];
}

void CharJoint::getEndEffectorPoint(int frameNum, double& x, double& y, double& z)
{
	if (frameNum >= (int) m_frames.size())
	{
		danceInterp::OutputMessage("Cannot get end effector point at frame #%d, only %d frames...\n", frameNum, m_frames.size());
		x = 0.0; y = 0.0; z = 0.0;
		return;
	}

	x = m_endEffectorPoints[3 * frameNum];
	y = m_endEffectorPoints[3 * frameNum + 1];
	z = m_endEffectorPoints[3 * frameNum + 2];
}

void CharJoint::getEndEffectorPoint(double time, Vector pos)
{
	double localTime = convertToLocalTime(time);
	 // determine the appropriate frame
    double frame = localTime / m_frameTime;
    int frameNum = (int) frame;
    double diff = frame - (double) frameNum; 

	if (frameNum >= this->getNumFrames())
		frameNum = this->getNumFrames() - 1;
	int nextFrame = frameNum + 1;
	if (nextFrame >= this->getNumFrames())
		nextFrame = this->getNumFrames() - 1;

	if (frameNum < 0 || nextFrame < 0)
	{
		Vector coord;
		this->getWorldCoord(-1.0, coord);
		VecCopy(pos, coord);
		Vector eeOffset = { m_endEffectorOffset[0]->getValue(), m_endEffectorOffset[1]->getValue(), m_endEffectorOffset[2]->getValue() };
		VecAdd(pos, pos, eeOffset);
		return;
	}

	// interpolate between the two frames
	Vector start;
	start[0] = m_endEffectorPoints[3 * frameNum];
	start[1] = m_endEffectorPoints[3 * frameNum + 1];
	start[2] = m_endEffectorPoints[3 * frameNum + 2];
	Vector end;
	end[0] = m_endEffectorPoints[3 * nextFrame];
	end[1] = m_endEffectorPoints[3 * nextFrame + 1];
	end[2] = m_endEffectorPoints[3 * nextFrame + 2];

	for (int i = 0; i < 3; i++)
		pos[i] = start[i] * (1.0 - diff) + end[i] * diff;

	// factor in the scale and offset
	double scale = 1.0;
	Vector offset = {0.0, 0.0, 0.0};
	scale = this->getCharacter()->getScale();
	this->getCharacter()->getOffset(offset);
	for (int i = 0; i < 3; i++)
		pos[i] = (pos[i] * scale) + offset[i];
}

Quaternion* CharJoint::getQuaternion(int frameNum)
{
	if (frameNum >= (int) m_frames.size())
	{
		if (m_frames.size() == 0)
		{
			Quaternion* defaultquat = new Quaternion(&CharJoint::m_defaultQuaternion);
			return defaultquat;
		}
		else
		{
			danceInterp::OutputMessage("Cannot get quaternion at frame #%d, only %d frames...\n", frameNum, m_frames.size());
			return m_quaternions[m_frames.size() - 1];
		}
	}

	return m_quaternions[frameNum];
}

Quaternion* CharJoint::getQuaternion(double time)
{
	double localTime = convertToLocalTime(time);

	double frameTime = this->getFrameTime();
	int startFrame = (int) (localTime / frameTime);
	int endFrame = startFrame + 1;
	//if (fabs(localTime * frameTime) - fabs(float(startFrame)) < .0001)
	//	endFrame = startFrame;
	if (endFrame >= this->getNumFrames())
		endFrame = this->getNumFrames() - 1;

	if (endFrame < startFrame)
		endFrame = startFrame;

	Quaternion* qStart = this->getQuaternion(startFrame);
	Quaternion* qEnd = this->getQuaternion(endFrame);

	double val = ((double) endFrame) - (localTime / frameTime);
	Quaternion* temp = new Quaternion();
	qStart->Slerp(qEnd, val, temp);

	return temp;
}

double CharJoint::getFrameTime()
{
	CharJoint* root = this->getCharacter()->getRoot();
	if (root != NULL && root != this)
		return root->getFrameTime();
	
	if (m_frames.size() > 0)
		return m_frameTime;
	else
		return 1.0;
}

void CharJoint::setFrameTime(double time)
{
	m_frameTime = time;
}

Quaternion* CharJoint::getGlobalQuaternion(int frameNum)
{
	if (frameNum >= (int) m_frames.size())
	{
		danceInterp::OutputMessage("Cannot get global orientation at frame #%d, only %d frames...\n", frameNum, m_frames.size());
		frameNum = m_frames.size() - 1;
	}

	double t = frameNum * this->getFrameTime();
	double matrix[4][4];
	Matrix3x3 mat;
	this->getWorldTransMatrix(t, matrix);
	for (int i = 0; i < 4; i++)
			for (int j = 0; j < 4; j++)
					mat[i][j] = matrix[j][i];

	Quaternion mg;
	mg.fromMatrix(mat);
	m_globalQuaternion.copy(&mg);

	return &m_globalQuaternion;
}

void CharJoint::setOffsetAdjustment(int frameNum, double ratio)
{
	if (frameNum >= (int) m_frames.size())
	{
		danceInterp::OutputMessage("Cannot set offset adjustment at frame #%d, only %d frames...\n", frameNum, m_frames.size());
		return;
	}

	m_offsetAdjustments[frameNum] = ratio;
}

double CharJoint::getOffsetAdjustment(int frameNum)
{
	if (frameNum >= (int) m_frames.size())
	{
//		danceInterp::OutputMessage("Cannot get offset adjustment at frame #%d, only %d frames...\n", frameNum, m_frames.size());
		return 1.0;
	}

	return m_offsetAdjustments[frameNum];
}

CharJoint* CharJoint::copy(Character* c, CharJoint* parent, int startFrame, int endFrame)
{
	CharJoint* joint = new CharJoint(getName());
	dance::AllGenericPlugins->add(joint);
	joint->setCharacter(c);
	joint->setParent(parent);
	joint->setEndEffector(isEndEffector());
	Vector endEffectorOffset;
	getEndEffectorOffset(endEffectorOffset);
	joint->setEndEffectorOffset(endEffectorOffset[0], endEffectorOffset[1], endEffectorOffset[2]);
	Vector offset;
	getOffset(offset);
	joint->setOffset(offset[0], offset[1], offset[2]);
	int channels[6];
	getChannels(channels);
	joint->setChannels(getNumChannels(), channels);

	if (this->useAxis())
	{
		double jaxis[3];
		this->getAxis(jaxis);
		joint->setAxis(jaxis);
	}

	int start = 0;
	if (startFrame > start)
		start = startFrame;

	int numFrames = getNumFrames();
	int end = numFrames - 1;
	if (endFrame < end)
		end = endFrame;

	double frames[6];
	for (int f = start; f <= end; f++)
	{
		getFrames(f, frames);
		joint->addFrame(frames);
		// add the quaternion
//		Quaternion* quat = getQuaternion(f);
//		joint->setFrame(f - startFrame, quat);
		// add the points
		Vector point;
		this->getPoint(f, point[0], point[1], point[2]);
		joint->setPoint(f - startFrame, point[0], point[1], point[2]);
		if (this->isEndEffector())
		{
			Vector endEffectorPoint;
			this->getEndEffectorPoint(f, endEffectorPoint[0], endEffectorPoint[1], endEffectorPoint[2]);
			joint->setEndEffectorPoint(f - startFrame, endEffectorPoint[0], endEffectorPoint[1], endEffectorPoint[2]);
		}
/*
		if (numMismatches > 10)
			continue;

		// compare the old quaternion to the new quaternion
		Quaternion* o = this->getQuaternion(f);
		Quaternion* n = joint->getQuaternion(f);
		if (o->q_coords[0] != n->q_coords[0] ||
			o->q_coords[1] != n->q_coords[1] ||
			o->q_coords[2] != n->q_coords[2] ||
			o->q_coords[3] != n->q_coords[3])
		{
			danceInterp::OutputMessage("Joint %s frame %d: Orig q is %f %f %f %f, compare Q is %f %f %f %f", this->getName(), f, o->q_coords[0], o->q_coords[1], o->q_coords[2], o->q_coords[3], n->q_coords[0], n->q_coords[1], n->q_coords[2], n->q_coords[3]);
			numMismatches++;
		}
*/
	}
	joint->setFrameTime(getFrameTime());

	return joint;
}

void CharJoint::setEndSiteName(char* name)
{
	m_endSiteName = name;
}

char* CharJoint::getEndSiteName()
{
	return (char*) m_endSiteName.c_str();
}

void CharJoint::getWorldTransMatrix(double time, double matrix[4][4])
{
	setIdentMat(&matrix[0][0], 4);
	getWorldCoordRecurse(time, matrix, this);
}

void CharJoint::getWorldCoord(double time, Vector &pos)
{
	double matrix[4][4];
	setIdentMat(&matrix[0][0], 4);
	getWorldCoordRecurse(time, matrix, this);

	pos[0] = matrix[3][0];
	pos[1] = matrix[3][1];
	pos[2] = matrix[3][2];
}

			
void CharJoint::getWorldCoordRecurse(double time, double matrix[4][4], CharJoint* node)
{
	// find the parent
	if (node->getParent() != NULL)
	{
		getWorldCoordRecurse(time, matrix, node->getParent());
	}

	// get the transformation matrix of this joint
	if (!this->getCharacter()->isMatrixCalculated())
		node->calcTransMatrix(time);

	double jointMatrix[4][4];
	node->getTransMatrix(jointMatrix);

	// multiply the current matrix by the 
	ArbMatrix m1(4, 4);
	for (int x  = 0; x < 4; x++)
		for (int y = 0; y < 4; y++)
			m1.elem(x, y) = matrix[y][x];

	ArbMatrix m2(4, 4);
	for (int x  = 0; x < 4; x++)
		for (int y = 0; y < 4; y++)
			m2.elem(x, y) = jointMatrix[y][x];

	ArbMatrix m3(4, 4);
	m1.mult(m3, m2);

	for (int x  = 0; x < 4; x++)
		for (int y = 0; y < 4; y++)
			matrix[y][x] = m3.elem(x, y);
}

void CharJoint::getLocalCoordToJoint(double time, Vector &pos, CharJoint* joint)
{
	getLocalCoordToJointRecurse(time, pos, this, joint);
}

			
void CharJoint::getLocalCoordToJointRecurse(double time, Vector &curPos, CharJoint* node, CharJoint* topNode)
{
	if (this->getParent() != NULL && node->getParent() == topNode)
	{
		curPos[0] = 0.0; 
		curPos[1] = 0.0; 
		curPos[2] = 0.0; 
	}
	else if (node->getParent() == NULL)
	{
//		danceInterp::OutputMessage("No matching joint found, using world coordinates...");
		node->getOffset(curPos);
	}
	else
	{
		getLocalCoordToJointRecurse(time, curPos, node->getParent(), topNode);
	}

	// multiply by the transformation matrix
	if (!this->getCharacter()->isMatrixCalculated())
		node->calcTransMatrix(time);
	double n[4][4];
	node->getTransMatrix(n);
	transformPoint_mat(curPos, n);
}

int CharJoint::determineRotationOrder(int* channels, int numChannels, CharJoint* joint)
{
	int index = 0;
	if (numChannels > 3)
		index = 3;

	int order = -1;

	if (channels[index] == CharJoint::XROTATION)
	{
		if (numChannels > index + 1)
		{
			if (channels[index + 1] == CharJoint::YROTATION)
			{
				order = Matrix3x3::XYZ;
			}
			else
			{
				order = Matrix3x3::XZY;
			}
		}
		else
		{
			order = Matrix3x3::XYZ;
		}
	}
	else if (channels[index] == CharJoint::YROTATION)
	{
		if (numChannels > index + 1)
		{
			if (channels[index + 1] == CharJoint::XROTATION)
			{
				order = Matrix3x3::YXZ;
			}
			else
			{
				order = Matrix3x3::YZX;
			}
		}
		else
		{
			order = Matrix3x3::YXZ;
		}
	}
	else if (channels[index] == CharJoint::ZROTATION)
	{
		if (numChannels > index + 1)
		{
			if (channels[index + 1] == CharJoint::XROTATION)
			{
				order = Matrix3x3::ZXY;
			}
			else
			{
				order = Matrix3x3::ZYX;
			}
		}
		else
		{
			order = Matrix3x3::ZXY;
		}
	}

	if (order == -1)
	{
		if (numChannels == 0)
			order = Matrix3x3::XYZ;
		else
		{
			//danceInterp::OutputMessage("No proper ordering found for joint %s, setting to XYZ...", joint->getName());
			for (int f = 0; f < numChannels; f++)
			{
				char buff[40];
				if (channels[f] == CharJoint::XROTATION)
					strcpy(buff, "XROTATION");
				else if (channels[f] == CharJoint::YROTATION)
					strcpy(buff, "YROTATION");
				else if (channels[f] == CharJoint::ZROTATION)
					strcpy(buff, "ZROTATION");
				else if (channels[f] == CharJoint::XPOSITION)
					strcpy(buff, "XPOSITION");
				else if (channels[f] == CharJoint::YPOSITION)
					strcpy(buff, "YPOSITION");
				else if (channels[f] == CharJoint::ZPOSITION)
					strcpy(buff, "ZPOSITION");
				else
				{
#ifdef WIN32
				  	itoa(f, buff, 10);
					strcat(buff, "UNKNOWN");
#endif
				}
				//danceInterp::OutputMessage("Channel #%d is %s...", f, buff);
			}
			order = Matrix3x3::XYZ;
		}
	}

	return order;
}

void CharJoint::convertToFrame(Quaternion* quat, double frames[6])
{
	Matrix3x3 danceMat;
	quat->toMatrix(danceMat);

	int order = CharJoint::determineRotationOrder(m_channels, getNumChannels(), this);
	VectorObj angles;
	danceMat.matToEuler(order, angles, false);
	int numChannels = this->getNumChannels();
	for (int i = 0; i < numChannels; i++)
	{
		if (m_channels[i] == CharJoint::XPOSITION || 
			m_channels[i] == CharJoint::YPOSITION || 
			m_channels[i] == CharJoint::ZPOSITION)
		{
			// keep the existing data
			//frames[i] = 0.0;
		}
		else if (m_channels[i] == CharJoint::XROTATION)
		{
			frames[i] = angles.x() * 180.0 / M_PI;
		}
		else if (m_channels[i] == CharJoint::YROTATION)
		{
			frames[i] = angles.y() * 180.0 / M_PI;
		}
		else if (m_channels[i] == CharJoint::ZROTATION)
		{
			frames[i] = angles.z() * 180.0 / M_PI;
		}
	}
	for (int i = numChannels; i < 6; i++)
	{
		frames[i] = 0.0;
	}
}

Quaternion* CharJoint::convertToQuaternion(double frames[6])
{
	bool isBVH = this->getCharacter()->isBVH();

	int order = CharJoint::determineRotationOrder(m_channels, m_numChannels, this);
	// convert the frames to radians
	int cIndex = 0;
	double startFrame[6];

	// find the index of the first rotational parameter
	// note that this means that the translation and rotation parameters
	// are assumed to be grouped together (in other words, there is no
	// alternations between rotational and positional parameters).
	// The code should be made more robust to handle any case.
	for (int c = 0; c < m_numChannels; c++)
	{
		if (m_channels[c] == CharJoint::XROTATION ||
			m_channels[c] == CharJoint::YROTATION ||
			m_channels[c] == CharJoint::ZROTATION)
		{
			cIndex = c;
			break;
		}

	}

	Quaternion* mg = NULL;

	switch (order)
	{
	case Matrix3x3::XYZ:
		startFrame[0] = frames[cIndex] * DEGREESTORADIANS; startFrame[1] = frames[cIndex + 1] * DEGREESTORADIANS; startFrame[2] = frames[cIndex + 2] * DEGREESTORADIANS;
		if (isBVH)
		{
			Matrix3x3 m;
			m.identity();
			Matrix3x3 rotX;
			rotX.setRotateMatrix(Matrix3x3::X, startFrame[0]);
			Matrix3x3 rotY;
			rotY.setRotateMatrix(Matrix3x3::Y, startFrame[1]);
			Matrix3x3 rotZ;
			rotZ.setRotateMatrix(Matrix3x3::Z, startFrame[2]);
			m = rotX * rotY * rotZ;
			mg = new Quaternion();
			mg->fromMatrix(m);
		}
		else
		{
			Matrix3x3 m;
			m.identity();
			Matrix3x3 rotX;
			rotX.setRotateMatrix(Matrix3x3::X, startFrame[0]);
			Matrix3x3 rotY;
			rotY.setRotateMatrix(Matrix3x3::Y, startFrame[1]);
			Matrix3x3 rotZ;
			rotZ.setRotateMatrix(Matrix3x3::Z, startFrame[2]);
			m = rotZ * rotY * rotX;
			mg = new Quaternion();
			mg->fromMatrix(m);
		}
		break;
	case Matrix3x3::XZY:
		startFrame[0] = frames[cIndex] * DEGREESTORADIANS; startFrame[1] = frames[cIndex + 2] * DEGREESTORADIANS; startFrame[2] = frames[cIndex + 1] * DEGREESTORADIANS;
		if (isBVH)
		{
			Matrix3x3 m;
			m.identity();
			Matrix3x3 rotX;
			rotX.setRotateMatrix(Matrix3x3::X, startFrame[0]);
			Matrix3x3 rotZ;
			rotZ.setRotateMatrix(Matrix3x3::Z, startFrame[2]);
			Matrix3x3 rotY;
			rotY.setRotateMatrix(Matrix3x3::Y, startFrame[1]);
			m = rotX * rotZ * rotY;
			mg = new Quaternion();
			mg->fromMatrix(m);
		}
		else
		{
			Matrix3x3 m;
			m.identity();
			Matrix3x3 rotX;
			rotX.setRotateMatrix(Matrix3x3::X, startFrame[0]);
			Matrix3x3 rotZ;
			rotZ.setRotateMatrix(Matrix3x3::Z, startFrame[2]);
			Matrix3x3 rotY;
			rotY.setRotateMatrix(Matrix3x3::Y, startFrame[1]);
			m = rotY * rotZ * rotX;
			mg = new Quaternion();
			mg->fromMatrix(m);
		}
		break;
	case Matrix3x3::YXZ:
		startFrame[0] = frames[cIndex + 1] * DEGREESTORADIANS; startFrame[1] = frames[cIndex] * DEGREESTORADIANS; startFrame[2] = frames[cIndex + 2] * DEGREESTORADIANS;
		if (isBVH)
		{
			Matrix3x3 m;
			m.identity();
			Matrix3x3 rotY;
			rotY.setRotateMatrix(Matrix3x3::Y, startFrame[1]);
			Matrix3x3 rotX;
			rotX.setRotateMatrix(Matrix3x3::X, startFrame[0]);
			Matrix3x3 rotZ;
			rotZ.setRotateMatrix(Matrix3x3::Z, startFrame[2]);
			m = rotY * rotX * rotZ;
			mg = new Quaternion();
			mg->fromMatrix(m);
		}
		else
		{
			Matrix3x3 m;
			m.identity();
			Matrix3x3 rotY;
			rotY.setRotateMatrix(Matrix3x3::Y, startFrame[1]);
			Matrix3x3 rotX;
			rotX.setRotateMatrix(Matrix3x3::X, startFrame[0]);
			Matrix3x3 rotZ;
			rotZ.setRotateMatrix(Matrix3x3::Z, startFrame[2]);
			m = rotZ * rotX * rotY;
			mg = new Quaternion();
			mg->fromMatrix(m);
		}
		break;
	case Matrix3x3::YZX:
		startFrame[0] = frames[cIndex + 2] * DEGREESTORADIANS; startFrame[1] = frames[cIndex] * DEGREESTORADIANS; startFrame[2] = frames[cIndex + 1] * DEGREESTORADIANS;
		if (isBVH)
		{
			Matrix3x3 m;
			m.identity();
			Matrix3x3 rotY;
			rotY.setRotateMatrix(Matrix3x3::Y, startFrame[1]);
			Matrix3x3 rotZ;
			rotZ.setRotateMatrix(Matrix3x3::Z, startFrame[2]);
			Matrix3x3 rotX;
			rotX.setRotateMatrix(Matrix3x3::X, startFrame[0]);
			m = rotY * rotZ * rotX;
			mg = new Quaternion();
			mg->fromMatrix(m);
		}
		else
		{
			Matrix3x3 m;
			m.identity();
			Matrix3x3 rotY;
			rotY.setRotateMatrix(Matrix3x3::Y, startFrame[1]);
			Matrix3x3 rotZ;
			rotZ.setRotateMatrix(Matrix3x3::Z, startFrame[2]);
			Matrix3x3 rotX;
			rotX.setRotateMatrix(Matrix3x3::X, startFrame[0]);
			m = rotX * rotZ * rotY;
			mg = new Quaternion();
			mg->fromMatrix(m);
		}
		break;
	case Matrix3x3::ZXY:
		startFrame[0] = frames[cIndex + 1] * DEGREESTORADIANS; startFrame[1] = frames[cIndex + 2] * DEGREESTORADIANS; startFrame[2] = frames[cIndex] * DEGREESTORADIANS;
		if (isBVH)
		{
			Matrix3x3 m;
			m.identity();
			Matrix3x3 rotZ;
			rotZ.setRotateMatrix(Matrix3x3::Z, startFrame[2]);
			Matrix3x3 rotX;
			rotX.setRotateMatrix(Matrix3x3::X, startFrame[0]);
			Matrix3x3 rotY;
			rotY.setRotateMatrix(Matrix3x3::Y, startFrame[1]);
			m = rotZ * rotX * rotY;
			mg = new Quaternion();
			mg->fromMatrix(m);
		}
		else
		{
			Matrix3x3 m;
			m.identity();
			Matrix3x3 rotZ;
			rotZ.setRotateMatrix(Matrix3x3::Z, startFrame[2]);
			Matrix3x3 rotX;
			rotX.setRotateMatrix(Matrix3x3::X, startFrame[0]);
			Matrix3x3 rotY;
			rotY.setRotateMatrix(Matrix3x3::Y, startFrame[1]);
			m = rotY * rotX * rotZ;
			mg = new Quaternion();
			mg->fromMatrix(m);
		}
		break;
	case Matrix3x3::ZYX:
		startFrame[0] = frames[cIndex + 2] * DEGREESTORADIANS; startFrame[1] = frames[cIndex + 1] * DEGREESTORADIANS; startFrame[2] = frames[cIndex] * DEGREESTORADIANS;
		if (isBVH)
		{
			Matrix3x3 m;
			m.identity();
			Matrix3x3 rotZ;
			rotZ.setRotateMatrix(Matrix3x3::Z, startFrame[2]);
			Matrix3x3 rotY;
			rotY.setRotateMatrix(Matrix3x3::Y, startFrame[1]);
			Matrix3x3 rotX;
			rotX.setRotateMatrix(Matrix3x3::X, startFrame[0]);
			m = rotZ * rotY * rotX;
			mg = new Quaternion();
			mg->fromMatrix(m);
		}
		else
		{
			Matrix3x3 m;
			m.identity();
			Matrix3x3 rotZ;
			rotZ.setRotateMatrix(Matrix3x3::Z, startFrame[2]);
			Matrix3x3 rotY;
			rotY.setRotateMatrix(Matrix3x3::Y, startFrame[1]);
			Matrix3x3 rotX;
			rotX.setRotateMatrix(Matrix3x3::X, startFrame[0]);
			m = rotX * rotY * rotZ;
			mg = new Quaternion();
			mg->fromMatrix(m);
		}
		break;
	}

	if (mg == NULL)
		danceInterp::OutputMessage("PROBLEM! Quaternion is NULL!");

	return mg;
}

void CharJoint::setAxis(double* axis)
{
	// we are assuming an axis order of 'XYZ'
	for (int a = 0; a < 3; a++)
		m_axis[a] = axis[a];

	setIdentMat(&m_axisRotMatrix[0][0], 4);
	setIdentMat(&m_axisRotMatrixInv[0][0], 4);

	m_useAxis = true;

	Matrix3x3 sMatrix;
	sMatrix.identity();
	Matrix3x3 rotX;
	rotX.setRotateMatrix(Matrix3x3::X, m_axis[0]);
	Matrix3x3 rotY;
	rotY.setRotateMatrix(Matrix3x3::Y, m_axis[1]);
	Matrix3x3 rotZ;
	rotZ.setRotateMatrix(Matrix3x3::Z, m_axis[2]);
	sMatrix = rotZ * rotY * rotX;

	// copy back to m_axisRotMatrix
    for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
	            m_axisRotMatrix[i][j] = sMatrix[j][i];

	// form the inverse matrix
	Matrix3x3 iMatrix;
	iMatrix = sMatrix;
	iMatrix.invert();

	// copy back to m_axisRotMatrixInv
    for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
				m_axisRotMatrixInv[i][j] = iMatrix[j][i];
}

void CharJoint::getAxis(double* axis)
{
	if (!m_useAxis)
	{
		for (int x = 0; x < 3; x++)
			axis[x] = 0.0;
	}
	else
	{
		for (int x = 0; x < 3; x++)
			axis[x] = m_axis[x];
	}
}

bool CharJoint::useAxis()
{
	return m_useAxis;
}

void CharJoint::getAxisMatrix(double axisMatrix[4][4])
{
	for (int i = 0; i < 4; i++)
		for (int j = 0; j < 4; j++)
			axisMatrix[i][j] = m_axisRotMatrix[i][j];
}

void CharJoint::getAxisMatrixInverse(double axisMatrixInv[4][4])
{
	for (int i = 0; i < 4; i++)
		for (int j = 0; j < 4; j++)
			axisMatrixInv[i][j] = m_axisRotMatrixInv[i][j];
}

void CharJoint::setLength(double length)
{
	m_length = length;
}

double CharJoint::getLength()
{
	return m_length;
}

void CharJoint::setDirection(double x, double y, double z)
{
	m_direction[0] = x;
	m_direction[1] = y;
	m_direction[2] = z;
}

void CharJoint::getDirection(Vector direction)
{
	direction[0] = m_direction[0];
	direction[1] = m_direction[1];
	direction[2] = m_direction[2];
}

int CharJoint::getNumChildren()
{
	return m_children.size();
}

CharJoint* CharJoint::getChild(int childNum)
{
	if (childNum < (int) m_children.size())
		return m_children[childNum];
	else
		return NULL;
}

void CharJoint::setInterpolatedJoint(CharJoint* j)
{
	m_interpolatedJoint = j;
}

CharJoint* CharJoint::getInterpolatedJoint()
{
	return m_interpolatedJoint;
}

bool CharJoint::isIgnoreChannels()
{
	return m_ignoreChannels;
}

void CharJoint::setIgnoreChannels(bool val)
{
	m_ignoreChannels = val;
}

double CharJoint::getLastTime()
{
	return m_lastTime;
}


void CharJoint::getLimitsFromData(int channelNum, double& low, double& high)
{
	if (channelNum >= this->getNumChannels())
		return;

	low = 180.0; 
	high = -180.0; 

	for (int x = 0; x < this->getNumFrames(); x++)
	{
		double data[6];
		this->getFrames(x, data);
		if (data[channelNum] < low)
			low = data[channelNum];
		if (data[channelNum] > high)
			high = data[channelNum];
	}

	if (low > high)
	{
		low = -180.0;
		high = 180.0;
	}
}

int CharJoint::numTranslationChannels()
{
	if (getFirstTranslationChannel() == -1)
		return 0;

	return getLastTranslationChannel() - getFirstTranslationChannel() + 1;
}

int CharJoint::getFirstTranslationChannel()
{
	return m_firstTranslationChannel;
}

int CharJoint::getLastTranslationChannel()
{
	return m_lastTranslationChannel;
}

int CharJoint::getCharacterIndex()
{
	return m_characterIndex;
}

void CharJoint::setCharacterIndex(int index)
{
	m_characterIndex = index;
}

void CharJoint::setLimits(int channelNum, double low, double high)
{
	m_limitsLow[channelNum] = low;
	m_limitsHigh[channelNum] = high;
}

void CharJoint::getLimits(int channelNum, double& low, double& high)
{
	low = m_limitsLow[channelNum];
	high = m_limitsHigh[channelNum];
}

std::vector<std::string>& CharJoint::getParameters()
{
	return m_parameters;
}

std::string CharJoint::getParameter(std::string match)
{
	for (int x = 0; x < m_parameters.size(); x++)
	{
		int pos = m_parameters[x].find(match);
		if (pos != std::string::npos)
		{
			return m_parameters[x];
		}
	}

	return "";
}

std::vector<double*>& CharJoint::getRawFrameData()
{
	return m_frames;
}

fltk::Widget* CharJoint::getInterface()
{
	if (m_gui == NULL) 
	{
		m_gui = new CharJointWindow(this, -1, -1, -1, -1, this->getName());
	}

	return m_gui;
}

void CharJoint::onConnect(DConnection* connection)
{
	if (connection->getTo() == this)
	{
		if (connection->getType() == "joint")
		{
			Character* character = dynamic_cast<Character*>(connection->getFrom());
			if (character)
			{
				this->setCharacter(character);
				// be notified when the time or offsettime changes
				DoubleAttribute* timeAttr = dynamic_cast<DoubleAttribute*>(character->getAttribute("time"));
				if (timeAttr)
					timeAttr->registerObserver(this);
				DoubleAttribute* offsetTimeAttr = dynamic_cast<DoubleAttribute*>(character->getAttribute("offsettime"));
				if (offsetTimeAttr)
					offsetTimeAttr->registerObserver(this);
			}
		}
		else if (connection->getType() == "jointchild")
		{
			CharJoint* parentJoint = dynamic_cast<CharJoint*>(connection->getFrom());
			this->setParent(parentJoint);
			// if the joint is connection to a character, do the same for this joint
			std::vector<DConnection*> list;
			dance::connectionManager->getToConnections("joint", parentJoint, list);
			if (list.size() > 0)
			{
				Character* character = dynamic_cast<Character*>(list[0]->getFrom());
				if (character)
				{
					dance::connectionManager->makeConnection(character, "joint", this);
				}
			}
		}
		else if (connection->getType() == "rootjoint")
		{
			Character* character = dynamic_cast<Character*>(connection->getFrom());
			if (character)
			{
				dance::connectionManager->makeConnection(character, "joint", this);
			}
		}
	}
	else
	{
		if (connection->getType() == "jointchild")
		{
			this->addChild(dynamic_cast<CharJoint*>(connection->getTo()));
		}
	}
}

void CharJoint::onDisconnect(DConnection* connection)
{
	if (connection->getTo() == this)
	{
		if (connection->getType() == "joint")
		{
			Character* character = dynamic_cast<Character*>(connection->getFrom());
			if (character)
			{
				// unregister when the time changes
				DoubleAttribute* timeAttr = dynamic_cast<DoubleAttribute*>(character->getAttribute("time"));
				if (timeAttr)
					timeAttr->unregisterObserver(this);
				this->setCharacter(NULL);
			}
		}
		else if (connection->getType() == "jointchild")
		{
			this->setParent(NULL);
		}
		else if (connection->getType() == "rootjoint")
		{
			Character* character = dynamic_cast<Character*>(connection->getFrom());
			if (character)
			{
				dance::connectionManager->removeConnection(character, "joint", this);
			}
		}
	}
	else
	{
		if (connection->getType() == "jointchild")
		{
			this->removeChild(dynamic_cast<CharJoint*>(connection->getTo()));
		}
	}
}

void CharJoint::notify(DSubject* subject)
{
	if (subject == m_offset[0] || subject == m_offset[1] || subject == m_offset[2] ||
		subject == m_endEffectorOffset[0] || subject == m_endEffectorOffset[1] || subject == m_endEffectorOffset[2])
	{
		m_worldMatrixDirty = true;
		dance::Refresh();
	}
	else if (subject == m_showTrajectories)
	{
	
		if (m_showTrajectories->getValue())
		{
			this->calculatePath(0, this->getCharacter()? this->getCharacter()->getRoot()->getNumFrames() : 0);
		}
		dance::Refresh();
	}
	else if (subject == m_showGesturePhases)
	{
		if (m_showGesturePhases->getValue())
			this->calculatePath(0, this->getCharacter()? this->getCharacter()->getRoot()->getNumFrames() : 0);
		dance::Refresh();
	}
	else 
	{
		Character* character = this->getCharacter();
		if (!character)
			return;
		DoubleAttribute* timeAttr = dynamic_cast<DoubleAttribute*>(this->getCharacter()->getAttribute("time"));
		if (timeAttr == subject)
		{
			m_worldMatrixDirty = true;
		}
		else 
		{
			DoubleAttribute* offsetTimeAttr = dynamic_cast<DoubleAttribute*>(this->getCharacter()->getAttribute("offsettime"));
			if (offsetTimeAttr == subject)
			{
				m_worldMatrixDirty = true;
			}
		}
	}
}

BoundingBox* CharJoint::calcBoundingBox(BoundingBox *box)
{
	Character* character = this->getCharacter();
	Vector point;
	double radius = .1;
	if (!character)
	{
		double matrix[4][4];
		this->getTransMatrix(matrix);
		setVector(point, matrix[3][0], matrix[3][1], matrix[3][2]);
	}
	else
	{
		
		this->getWorldCoord(this->getCharacter()->getTime(), point);
		radius = this->getCharacter()->getHeight() * this->getCharacter()->getJointSize();
	}

	m_BoundingBox.xMin = point[0] - radius;
	m_BoundingBox.xMax = point[0] + radius;
	m_BoundingBox.yMin = point[1] - radius;
	m_BoundingBox.yMax = point[1] + radius;
	m_BoundingBox.zMin = point[2] - radius;
	m_BoundingBox.zMax = point[2] + radius;

	if (box)
		box->merge(m_BoundingBox);

	return &m_BoundingBox;

}

void CharJoint::getWorldTransMatrix(double matrix[4][4])
{
	if (m_worldMatrixDirty)
	{
		Character* c = this->getCharacter();
		if (c)
			this->getCharacter()->calcWorldTransMatrix();
	}
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			matrix[r][c] = m_worldTransMatrix[r][c];
}

void CharJoint::setWorldTransMatrix(double matrix[4][4])
{
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			m_worldTransMatrix[r][c] = matrix[r][c];

	m_worldMatrixDirty = false;
}

void CharJoint::calculatePath(int startFrame, int endFrame)
{

	m_path.clear();

	double oldTime = getLastTime();

	Character* character = this->getCharacter();
	Vector rotation;
	character->getRotation(rotation);
	Matrix3x3 xrot;
	xrot.setRotateMatrix(Matrix3x3::X, -rotation[0] * M_PI / 180.0);
	Matrix3x3 yrot;
	yrot.setRotateMatrix(Matrix3x3::Y, -rotation[1] * M_PI / 180.0);
	Matrix3x3 zrot;
	zrot.setRotateMatrix(Matrix3x3::Z, -rotation[2] * M_PI / 180.0);

	Matrix3x3 finalRot = zrot * yrot * xrot;

	double rotmatrix[4][4];
	setIdentMat(&rotmatrix[0][0], 4);
	finalRot.to4x4(rotmatrix);

	int numFrames = endFrame - startFrame + 1;

	for (int f = 0; f < numFrames; f++)
	{
		double curTime = getFrameTime() * (startFrame + f);
		Vector pos;
		getWorldCoord(curTime, pos);
		m_path.push_back(VectorObj(pos[0], pos[1], pos[2]));
	}
	character->setMatrixCalculated(false);

	calcTransMatrix(oldTime);

}

std::vector<VectorObj>& CharJoint::getPath()
{
	return m_path;
}