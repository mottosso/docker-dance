/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _COLLISIONHIERARCHY_
#define _COLLISIONHIERARCHY_

#include "DCollision.h"

class DLLENTRY DCollisionHierarchy
{
	public:
		DCollisionHierarchy();
		~DCollisionHierarchy();

		INLINE void setID(int i);
		INLINE int getID();

		INLINE void setSize(double s);
		INLINE double getSize();

		INLINE double* getCurLocation();
		INLINE void setCurLocation(double* loc);

		INLINE double* getLocation();
		INLINE void setLocation(double* loc);

		INLINE int getNumChildren();
		INLINE void setNumChildren(int c);
		INLINE void setChildren(DCollisionHierarchy** c);
		INLINE DCollisionHierarchy** getChildren();

		INLINE int getNumCollisions();
		INLINE void setNumCollisions(int c);
		INLINE void setCollisions(DCollision** c);
		INLINE DCollision** getCollisions();

	private:
		int id;
		Vector point;
		double size;
		Vector curLocation;

		DCollisionHierarchy** children;
		int numChildren;

		DCollision** collision;
		int numCollisions;
};
#endif

