#ifndef DOBSERVER_H
#define DOBSERVER_H

#include "defs.h"

class DLLENTRY DSubject;

class DLLENTRY DObserver
{
	public:
		DObserver();
		~DObserver();

		virtual void notify(DSubject* subject) = 0;
};

#endif

