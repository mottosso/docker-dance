/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "GroupAppliedSystems.h"
#include "dance.h"

using namespace fltk;

GroupAppliedSystems::GroupAppliedSystems(DActuator* a, int x, int y, int w, int h, const char* name) : Group(x, y, w, h, name)
{
	actuator = a;
	this->box(fltk::BORDER_BOX);
	this->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);

	this->begin();

	checkApplyAll = new CheckButton(10, 20, 80, 20, "Apply All");
	checkApplyAll->callback(ApplyAllCB, this);

	choiceSystems = new Choice(10, 20, w - 20, 20);

	int browserHeight = h - 90;
	if (browserHeight < 10)
		browserHeight = 10;
	browserSystems = new MultiBrowser(10, 45, w - 20, browserHeight);

	buttonUpdateSystems = new Button(10, h - 25, 60, 20, "Refresh");
	buttonUpdateSystems->callback(UpdateSystemsListCB, this);
	
	this->end();

	this->setApplyOneOnly(false);
}

void GroupAppliedSystems::setApplyOneOnly(bool val)
{
	applyOneOnly = val;
	if (applyOneOnly)
	{
		browserSystems->hide();
		checkApplyAll->hide();
		choiceSystems->show();
	}
	else
	{
		browserSystems->show();
		checkApplyAll->show();
		choiceSystems->hide();
	}
}

bool GroupAppliedSystems::isApplyOneOnly()
{
	return applyOneOnly;
}

void GroupAppliedSystems::updateGUI()
{
	if (this->active())
	{
		if (!isApplyOneOnly())
		{
			browserSystems->activate();
			checkApplyAll->activate();

			if (actuator->isAppliedAllObjects())
				checkApplyAll->value(true);
			else
				checkApplyAll->value(false);


			// add all systems
			browserSystems->clear();
			for (int x = 0; x < dance::AllSystems->size(); x++)
			{
				DSystem* sys = dynamic_cast<DSystem*>(dance::AllSystems->get(x));
				if (sys != NULL)
				{
					CheckButton* check = new CheckButton(0, 0, browserSystems->w() - 20, 20, sys->getName());
					check->callback(ApplyChangeCB, this);

					// is this articulated object already applied?
					if (actuator->isInApplyList(sys))
					{
						check->value(1);
					}
					else
					{
						check->value(0);
					}
					browserSystems->add(check);
				}
			}

			browserSystems->activate();
		}
		else
		{
			choiceSystems->activate();
			// add all systems
			choiceSystems->clear();
			choiceSystems->add("Choose a system", 0, ApplyChangeSingleCB, this, 0);
			bool found = false;
			for (int x = 0; x < dance::AllSystems->size(); x++)
			{
				DSystem* sys = dynamic_cast<DSystem*>(dance::AllSystems->get(x));
				if (sys != NULL)
				{
					choiceSystems->add(sys->getName(), 0, ApplyChangeSingleCB, this, 0);
					// is this articulated object already applied?
					if (actuator->isInApplyList(sys))
					{
						choiceSystems->value(x + 1);
						found = true;
					}
				}
			}
			if (!found)
				choiceSystems->value(0);
		}
		buttonUpdateSystems->activate();
	}
	else
	{
		if (!isApplyOneOnly())
		{
			browserSystems->clear();
			browserSystems->deactivate();
			checkApplyAll->deactivate();
		}
		buttonUpdateSystems->deactivate();
	}
}

void GroupAppliedSystems::UpdateSystemsListCB(fltk::Widget *w, void *data)
{
	GroupAppliedSystems* win = (GroupAppliedSystems*) data;

	win->updateGUI();
}

void GroupAppliedSystems::ApplyAllCB(Widget *w, void *data)
{
	GroupAppliedSystems* win = (GroupAppliedSystems*) data;
	
	win->actuator->setAppliedAllObjects(win->checkApplyAll->value());

	win->updateGUI();
}

void GroupAppliedSystems::ApplyChangeCB(fltk::Widget *w, void *data)
{
	GroupAppliedSystems* win = (GroupAppliedSystems*) data;
	CheckButton* check = (CheckButton*) w;

	DSystem* sys = (DSystem*) dance::AllSystems->get((char*) w->label());

	if (sys == NULL)
	{
		danceInterp::OutputMessage("Cannot find system with name %s.", w->label());
		return;
	}

	if (check->value())
	{
		win->actuator->setAppliedObject(sys);
	}
	else
	{
		win->actuator->removeAppliedObject(sys);
	}

	win->updateGUI();
}

void GroupAppliedSystems::ApplyChangeSingleCB(fltk::Widget *w, void *data)
{
	GroupAppliedSystems* win = (GroupAppliedSystems*) data;

	DSystem* sys = (DSystem*) dance::AllSystems->get((char*) w->label());

	if (sys == NULL)
	{
		danceInterp::OutputMessage("Cannot find system with name %s.", w->label());
		int numAppliedObjects = win->actuator->getNumAppliedObjects();
		for (int x = numAppliedObjects; x >= 0; x--)
		{
			DSystem* oldsys = win->actuator->getAppliedObject(x);
			win->actuator->removeAppliedObject(oldsys);
		}
	}
	else
	{
		int numAppliedObjects = win->actuator->getNumAppliedObjects();
		for (int x = numAppliedObjects; x > 0; x--)
		{
			DSystem* oldsys = win->actuator->getAppliedObject(x);
			win->actuator->removeAppliedObject(oldsys);
		}
		win->actuator->setAppliedObject(sys);
	}

	win->updateGUI();
}

