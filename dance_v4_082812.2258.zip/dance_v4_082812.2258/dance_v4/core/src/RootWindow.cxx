/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "RootWindow.h"

#include "ViewManager.h"
#include "DSimulatorManager.h"
#include "dance.h"
#include "danceInterp.h"
#include "DRenderer.h"
#include <fltk/PackedGroup.h>
#include <fltk/AlignGroup.h>
#include <fltk/BarGroup.h>
#include <fltk/ask.h>
#include <fltk/file_chooser.h>
#include "Preference.h"
#include "stuff.h"
#include <sstream>
#include <fltk/filename.h>

#include "DMaterialManager.h"

using namespace fltk;

RootWindow::RootWindow(int x, int y, int w, int h, const char* name) : Window(x, y, w, h, name)
{
	this->begin();

	menubar = new MenuBar(0, 0, w, 30); 
	menubar->add("&File/&New session",	NULL, RootWindow::resetAll_cb, 0);
	menubar->add("&File/&Load session",	NULL, RootWindow::loadSession_cb, 0);
	menubar->add("&File/&Save session",	NULL, RootWindow::saveSession_cb, 0);
	menubar->add("&File/&Quit", NULL, RootWindow::quit_cb, 0, MENU_DIVIDER);
//	menubar->add("&Views/&Toggle Multiview", 0, RootWindow::multiviewToggle_cb, 0, MENU_DIVIDER);
	menubar->add("&Window/&Show-Hide Command Console", 0, RootWindow::consoleToggle_cb,0, NULL);
	menubar->add("&Window/Change &directory",	NULL, RootWindow::changeDir_cb, 0);
	menubar->add("&Plugins/Se&lect", NULL, RootWindow::pluginsSelect_cb, 0, 0);
	menubar->add("&Plugins/Crea&te", NULL, RootWindow::pluginsCreate_cb, 0, 0);
	menubar->add("&Plugins/&Interaction", NULL, RootWindow::pluginsInteraction_cb,0, 0);
	menubar->add("&Materials/&Editor", NULL, RootWindow::materialManager_cb,0, NULL);
	menubar->add("&Render/Render current view", NULL, RootWindow::rendercurrent_cb, 0, NULL);
	menubar->add("&Render/Render continuously     ", NULL, RootWindow::rendercontinuous_cb,0, NULL);
	menubar->add("&Render/&Render...", NULL, RootWindow::rendernow_cb,0, NULL);
	menubar->add("&Help/About", 0, RootWindow::helpabout_cb, this, NULL);
	menubar->add("&Help/Give feedback or report a bug", 0, RootWindow::feedback_cb, 0, NULL);
	menubar->add("&Help/Check for updates", 0, RootWindow::updateversion_cb, 0, NULL);

	danceWindow = new DanceWindow(10, 30, 640, h - 40 -  140, NULL);
	danceWindow->box(fltk::UP_BOX);

	simControlWindow = new SimControlWindow(10, h - 160, 640, 140, "Simulator"); 
	simControlWindow->box(fltk::UP_BOX);

	parameterWindow = new ParameterWindow(650, 30, 340, h - 30, "Plugins");

	this->end();

	this->resizable(danceWindow);

	commandWindow = new CommandWindow(10, 400, 640, 400, "Command Shell");
//	commandWindow->child_of(this);
	commandWindow->hide();

	instanceWindow = new InstanceWindow(50, 50, 400, 400, "Create a Plugin Object");
	instanceWindow->child_of(this);
	instanceWindow->hide();

	materialWindow = new DMaterialManagerWindow(50, 50, 400, 400, "Material Manager");
	materialWindow->child_of(this);
	materialWindow->hide();

	materialEditorWindow = new MaterialEditorWindow(100, 100, 300, 300, "Material Editor");
	materialEditorWindow->child_of(this);
	materialEditorWindow->hide();

	renderWindow = new RenderWindow(300, 300, "Render");
	renderWindow->hide();

	// start the selecion window
	selectionWindow = new SelectionWindow(20, 20, 600, 450, "Select Plug-Ins");
	selectionWindow->redraw();

	interactionWindow = new InteractionWindow(50, 50, 420, 270, "Plugin Interaction");
	interactionWindow->hide();

//	feedbackWindow = new FeedbackWindow(400, 400, "Feedback");
//	feedbackWindow->child_of(this);
//	feedbackWindow->hide();

	this->callback(destroywindow_cb);

	const char* danceDir = dance::getDanceDir();
	if (danceDir)
	{
		std::stringstream strstr;
		strstr << danceDir << "/data/splash.jpg";
		int imageWidth = 640;
		int imageHeight = 480;
		splashWindow = new SplashWindow(strstr.str().c_str(), 
						x + (w - imageWidth) / 2, y + (h - imageHeight) / 2, 
						imageWidth, imageHeight, "DANCE");
		splashWindow->set_modal();
		splashWindow->setAutoHideTime(1);
		fltk::add_timeout(0, showSplash, this);
		splashWindow->hide();
	}
}

RootWindow::~RootWindow() {
	delete commandWindow;
	delete instanceWindow;
	delete materialWindow;
	delete materialEditorWindow;
	delete renderWindow;
	delete selectionWindow;
	delete interactionWindow;
	delete splashWindow;
}

void RootWindow::showSplash(void* data)
{
	RootWindow* rootWindow = (RootWindow*) data;
	std::vector<std::string> info;
	RootWindow::getaboutinfo(info);
	rootWindow->splashWindow->setInfo(info);
	rootWindow->splashWindow->show();
	if (rootWindow->splashWindow->isAutoHide())
		fltk::add_timeout(rootWindow->splashWindow->getAutoHideTime(), hideSplash, rootWindow);
}

void RootWindow::hideSplash(void* data)
{
	RootWindow* rootWindow = (RootWindow*) data;
	rootWindow->splashWindow->hide();
}

void RootWindow::updateViewMenu(ViewManager* manager)
{
	// erase the old menu
	for (int x = menubar->children() - 1; x >= 0; x--)
	{
		Widget* widget = menubar->child(x);
		if (strcmp(widget->label(), "&Views") == 0)
		{
			Group* group = (Group*) widget;
			for (int x = group->children() - 1; x >= 0; x--)
				group->remove(x);
		}
	//	menubar->add("&Views/&Toggle Multiview", 0, RootWindow::multiviewToggle_cb, 0, MENU_DIVIDER);
	}


	menubar->add("&Views/Duplicate view", 0, RootWindow::saveview_cb, 0, 0);
	menubar->add("&Views/Fit objects in view", 0, RootWindow::fitview_cb, 0, MENU_DIVIDER);	
	menubar->add("&Views/Target Selected Objects", 0, RootWindow::targetselected_cb, 0, MENU_DIVIDER);	
	menubar->add("&Views/Select Camera", 0, RootWindow::selectcamera_cb, 0, MENU_DIVIDER);	

	// create the new menu
	for (int x = 0; x < manager->getNumViews(); x++)
	{
		DView* view = (DView*) manager->get(x);
		std::stringstream strstr;
		strstr << "&Views/&" << view->getName();
		menubar->add(strstr.str().c_str(), 0, RootWindow::switchview_cb, 0, 0);
	}

}

void RootWindow::consoleToggle_cb(Widget* o, void* p)
{
	if (dance::rootWindow->commandWindow != NULL)
	{
		if (dance::rootWindow->commandWindow->visible())
		{
			Preference::setWindowPreference("dance.commandwindow", dance::rootWindow->commandWindow);
			dance::writePreferences();
			dance::rootWindow->commandWindow->hide();
		}
		else
		{
			Preference::getWindowPreference("dance.commandwindow", dance::rootWindow->commandWindow);
			dance::rootWindow->commandWindow ->show();
		}
	}
}

void RootWindow::multiviewToggle_cb(Widget* o, void* p)
{
	if (dance::AllViews->isQuadView())
		dance::AllViews->setQuadView(false);
	else
		dance::AllViews->setQuadView(true);
}

void RootWindow::select_cb(Widget* o, void* p)
{
	Preference::getWindowPreference("dance.selectionwindow", dance::rootWindow->selectionWindow);
	dance::rootWindow->selectionWindow->show();
}

void RootWindow::quit_cb(Widget*, void*)
{
	dance::quit();
}

void RootWindow::getaboutinfo(std::vector<std::string>& info)
{
	// obtain the OpenGL version information
	const GLubyte* openGLversion = glGetString(GL_VERSION);
	const GLubyte* openGLvendor = glGetString(GL_VENDOR);
	//const GLubyte* renderer = glGetString(GL_RENDERER);
	GLint texSize;
	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &texSize);

	info.push_back("DANCE v4");
	info.push_back("");
	info.push_back("Created by: Ari Shapiro");
	info.push_back("shapiroari@yahoo.com");
	info.push_back("http://www.arishapiro.com");
	info.push_back("Web page: http://www.arishapiro.com/dance/");
	info.push_back("");
	std::string danceVersion = "DANCE Version ";
	danceVersion.append(dance::getVersion());
	info.push_back(danceVersion);
	info.push_back("");
	if (openGLversion)
	{
		std::stringstream strstr;
		strstr << "Using OpenGL version " << openGLversion;
		info.push_back(strstr.str());
		strstr.clear();
	}
	if (openGLvendor)
	{
		std::stringstream strstr;
		strstr <<  "Using OpenGL vendor " << openGLvendor;
		info.push_back(strstr.str());

		std::stringstream strstr2;
		strstr2 << "Max. Texture Size  " << texSize;
		info.push_back(strstr2.str());
	}
}

void RootWindow::helpabout_cb(Widget*, void* data)
{
	RootWindow* rootWindow = (RootWindow*) data;
	rootWindow->splashWindow->setAutoHide(false);
	
	RootWindow::showSplash(rootWindow);
}


void RootWindow::feedback_cb(Widget*, void*)
{
	const char* dancedir = dance::getDanceDir();
	std::stringstream feedbackScript;
	feedbackScript << dancedir << "/feedback.py";
	danceInterp::load((char*) feedbackScript.str().c_str());
}

void RootWindow::updateversion_cb(Widget*, void*)
{
	const char* dancedir = dance::getDanceDir();
	std::stringstream updateVersionScript;
	updateVersionScript << dancedir << "/updateversion.py";
	danceInterp::load((char*) updateVersionScript.str().c_str());
}

void RootWindow::runScript_cb(Widget*, void*)
{
	const char* filename = fltk::file_chooser("Choose a python script:", "*.py", NULL, true);
	fltk::redraw();
	if (filename != NULL)
	{
		printf("This is the file name I got %s\n", filename) ;
		char str[1024];
		convertbackslashes((char*) filename, str);
		danceInterp::load((char*) str);
		danceInterp::flush();
	}
}

void RootWindow::loadSession_cb(Widget* w, void* data)
{
	int ok = fltk::ask("Are you sure you want to load a new session?\nYour current session will be lost.");
	if (!ok)
		return;

    const char* last = Preference::getPreferenceValue("dance.lastloadedsession");
 
    const char* filename = fltk::file_chooser("Choose a python script:", "*.dpy", (const char*) last, true);
	fltk::redraw();
	char str[1024];
	if (filename != NULL)
	{        
        char absFileName[1024];
        // make sure that we are using the absolute path
#ifdef WIN32
//		filename_normalize(absFileName, 1024, filename, NULL);
		const char* f = fltk_filename_normalize(absFileName, 1024, filename, NULL);
		if (strcmp(f, filename) == 0)
			strcpy(absFileName, filename);
#else
        filename_absolute(absFileName, 1024, filename, NULL);
#endif
          
        convertbackslashes((char*) absFileName, str);
        // remove references to DANCE_DIR://
        std::string fullPath = dance::convertPathToAbsolutePath(str);
        // make sure that the path is absolute
        int pos = fullPath.find_first_of("/");
        if (pos != 0)
        {   
			int colonPos = fullPath.find_first_of(":");
			if (colonPos != 1)
			{
				std::string temp = dance::getDanceDir();
				temp.append("/");
				temp.append(fullPath);
				fullPath = temp;
			}
        }
          
		dance::resetAll();	
        danceInterp::load((char*) fullPath.c_str());
		danceInterp::flush();
  
        Preference::replacePreference("dance.lastloadedsession", (char*) fullPath.c_str());
        dance::writePreferences();
	}
	Preference::updateRecentPreferences("dance.session.", 5, str);
	dance::writePreferences();
	dance::rootWindow->updateFileMenu();
}

void RootWindow::loadRecentSession_cb(fltk::Widget* w, void* data)
{
	int ok = fltk::ask("Are you sure you want to load a new session?\nYour current session will be lost.");
	if (!ok)
		return;
	dance::resetAll();	
    const char* recentFile = w->label();
    char str[1024]; 
    if (recentFile != NULL)
    {        
        convertbackslashes((char*) recentFile, str);
        // remove references to DANCE_DIR://
        std::string fullPath = dance::convertPathToAbsolutePath(str);
        // make sure that the path is absolute
        int pos = fullPath.find_first_of("/");
        if (pos != 0)
        {            
			int colonPos = fullPath.find_first_of(":");
			if (colonPos != 1)
			{
				std::string temp = dance::getDanceDir();
				temp.append("/");
				temp.append(fullPath);
				fullPath = temp;
			}
        }
          
        dance::resetAll();  
        danceInterp::load((char*) fullPath.c_str());
        danceInterp::flush();
    }
}

		

void RootWindow::resetAll_cb(Widget*, void*)
{
	int ok = fltk::ask("Are you sure you want to reset this session?\nYour current session will be lost.");
	if (!ok)
		return;
	dance::resetAll();	
	dance::loadProfile();
}

void RootWindow::fitview_cb(fltk::Widget*, void*)
{
	dance::AllViews->FitView();
	dance::Refresh();
}

void RootWindow::targetselected_cb(fltk::Widget*, void*)
{
	// set the camera target to be the selected object(s)
	VectorObj location(0,0,0);
	std::map<std::string, DObject*>& selectedObjects = dance::selectionManager->getSelectedObjects();
	for (std::map<std::string, DObject*>::iterator iter = selectedObjects.begin();
		iter != selectedObjects.end();
		iter++)
	{
		DObject* object = (*iter).second;
		VectorObj zero(0, 0, 0);
		Vector center = {0,0,0};
		object->getWorldCoord(center, zero.data());
		location += center;
	}
	if (selectedObjects.size() > 0)
		location /= double(selectedObjects.size());

	DView* view = dance::AllViews->getViewFocus();
	if (view)
		view->setTarget(location.data());
	dance::Refresh();
}

void RootWindow::selectcamera_cb(fltk::Widget*, void*)
{
	DView* view = dance::AllViews->getViewFocus();
	if (view)
		view->setSelected(true);
}

void RootWindow::saveview_cb(fltk::Widget*, void* data)
{
	// copy the view
	DView* currentView = dance::AllViews->getViewFocus();
	bool goodName = false;

	std::string vname;
	while (!goodName)
	{
		goodName = true;
		const char* viewname = fltk::input("Please name the view:");
		if (!viewname)
			break;
		// make sure that the name isn't already taken
		for (int i = 0; i < dance::AllViews->getNumViews(); i++)
		{
			DView* view = (DView*) dance::AllViews->get(i);
			if (strcmp(view->getName(), viewname) == 0)
			{
				goodName = false;
			}
		}
		if (goodName)
			vname.append(viewname);
	}
	if (goodName)
	{
		// duplicate the current view
		DView* newview = dance::AllViews->copyView(currentView, (char*) vname.c_str());
		dance::AllViews->add(newview);
	}
}



void RootWindow::pluginsCreate_cb(fltk::Widget*, void*)
{
	Preference::getWindowPreference("dance.instancewindow", dance::rootWindow->instanceWindow);
	dance::rootWindow->instanceWindow->show();
}

void RootWindow::pluginsSelect_cb(fltk::Widget*, void*)
{
	Preference::getWindowPreference("dance.selectionwindow", dance::rootWindow->selectionWindow);
	dance::rootWindow->selectionWindow->show();
}

void RootWindow::pluginsInteraction_cb(fltk::Widget*, void*)
{
	Preference::getWindowPreference("dance.interactionwindow", dance::rootWindow->interactionWindow);
	dance::rootWindow->interactionWindow->show();
}


void RootWindow::materialManager_cb(fltk::Widget*, void*)
{
	Preference::getWindowPreference("dance.materialeditorwindow", dance::rootWindow->materialWindow);
	dance::rootWindow->materialWindow->setSelectMode(false);
	dance::rootWindow->materialWindow->show();
	dance::rootWindow->materialWindow->redraw();
	fltk::flush();

}

void RootWindow::rendernow_cb(fltk::Widget*, void*)
{
	Preference::getWindowPreference("dance.renderwindow", dance::rootWindow->renderWindow);
	dance::rootWindow->renderWindow->show();
}

void RootWindow::rendercurrent_cb(fltk::Widget*, void*)
{
	DRenderer* renderer = dance::AllViews->getRenderer();
	if (renderer != NULL)
	{
		DView* currentView = dance::AllViews->getViewFocus();
		currentView->SaveFrame();
		fltk::alert("View has been rendered to %s", renderer->getLastRenderedFileName().c_str());
	}
	else
	{
		fltk::alert("No renderer has been selected.\nPlease choose a renderer with the Render... option.");
	}
}


void RootWindow::switchview_cb(fltk::Widget* w, void* data)
{
	// get the name of the view selected
	const char* viewName = w->label();

	for (int x = 0; x < dance::AllViews->getNumViews(); x++)
	{
		DView* view = (DView*) dance::AllViews->get(x);
		std::string temp;
		temp.append("&");
		temp.append(view->getName());
		if (temp == viewName)
		{
			// switch to that view
			dance::AllViews->setViewFocus(view);
			view->resetLights();
			dance::AllViews->postRedisplay();
			break;
		}
	}
}

void RootWindow::destroywindow_cb(fltk::Widget* widget, void* data)
{
	dance::quit();
}

void RootWindow::saveSession_cb(fltk::Widget*, void*)
{
    const char* last = Preference::getPreferenceValue("dance.lastsavedsession");

    const char* name = fltk::file_chooser("Please select a filename:", "{*.dpy}", (const char*) last);
	if (name != NULL)
	{
        char absFileName[1024];
            // make sure that we are using the absolute path
#ifdef WIN32
		const char* f = fltk_filename_normalize(absFileName, 1024, name, NULL);
		if (strcmp(f, name) == 0)
			strcpy(absFileName, name);
#else
        filename_absolute(absFileName, 1024, name, NULL);
#endif

        bool ok = dance::save((char*) absFileName);

		if (ok)
		{
            fltk::alert("Session has been saved to: %s", absFileName);
			char safeName[1024];
            convertbackslashes((char*) absFileName, safeName);
      
            Preference::replacePreference("dance.lastsavedsession", safeName);
            dance::writePreferences();

			Preference::updateRecentPreferences("dance.session.", 5, safeName);
			dance::writePreferences();
		}
                else
                {
                        fltk::alert("Problem! Session has not been saved!  Please examine the command window for more details.");
                }
	}
}

void RootWindow::changeDir_cb(fltk::Widget*, void*)
{
	std::string buff;
	buff.append(dance::rootWindow->commandWindow->getCurrentDirectory());
	const char* dir = fltk::input("Please set the current directory:", buff.c_str());
	if (dir != NULL)
	{
		dance::rootWindow->commandWindow->setCurrentDirectory(dir);
	}
}

void RootWindow::reloadscripts_cb(fltk::Widget* w, void* data)
{
	std::string buff;
	buff.append(dance::getDanceDir());
	buff.append("/scripts/");
	dance::reloadScripts(buff.c_str());
}

void RootWindow::runUserScript_cb(fltk::Widget* w, void* data)
{
	// determine which script was selected

	Widget* widget = w;

	std::string path = "";
	Widget* curWidget = widget;
	while (curWidget->parent() != dance::rootWindow->menubar)
	{
		path.insert(0, curWidget->label());
		path.insert(0, "/");
		curWidget = curWidget->parent();
	}
	std::string filename;
	filename.append(dance::getDanceDir());
	filename.append("/scripts");
	filename.append(path);
	filename.append(".py");
	danceInterp::load((char*) filename.c_str());
	dance::rootWindow->danceWindow->resetAllLights();
	danceInterp::flush();
}

void RootWindow::rendercontinuous_cb(fltk::Widget* w, void* data)
{
	DView* currentView = dance::AllViews->getViewFocus();

	if (currentView != NULL)
	{
		if (currentView->isDumped())
		{
			currentView->setDumped(false);
			w->label("Render continuously");
		}
		else
		{
			currentView->setDumped(true);
			w->label("Stop rendering continuously");
		}
	}
}

void RootWindow::updateFileMenu()
{
	// erase the old file menu
	for (int x = this->menubar->children() - 1; x >= 0; x--)
	{
		Widget* widget = dance::rootWindow->menubar->child(x);
		if (strcmp(widget->label(), "&File") == 0)
		{
			Group* group = (Group*) widget;
			for (int x = group->children() - 1; x > 4; x--)
				group->remove(x);
			break;
		}
	}

	// find NUMSESSIONPREFS preferences
	for (int x = 1; x <= NUMSESSIONPREFS; x++)
	{
		std::stringstream prefname;
		prefname << "dance.session.";
		prefname << x;
		Preference* pref = Preference::getPreference((char*) prefname.str().c_str());
		if (pref != NULL)
		{
			const char* pvalue = pref->getValue();
			// make sure that slashes are used properly
			int length = strlen(pvalue);
			std::string prefvalue;
			prefvalue.append("&File/Recent sessions/");
			for (int c = 0; c < length; c++)
			{
				if (pvalue[c] == '/')
				{
					prefvalue.append("\\/");
				}
				else if (pvalue[c] == '\\') 
				{
					prefvalue += "\\/";
				}
				else
				{
					prefvalue += pvalue[c];
				}
			}
			this->menubar->add(prefvalue.c_str(),	0, RootWindow::loadRecentSession_cb, 0);
		}
	}
}
