/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_VIEWMANAGER_H_
#define	_VIEWMANAGER_H_	1

#include "DObjectList.h"
#include <vector>
#include "DRenderer.h"
#include "DView.h"

#define MAXNUMVIEWS 100

class BoundingBox;

class DLLENTRY ViewManager : public DObjectList
{
public:
	ViewManager();
	ViewManager(int	argc, char **argv);
	~ViewManager();

	int commandPlugIn(int argc, char **argv);

	DView* createView( char* name, int argc, char **argv);

	INLINE DView *getViewFocus();
	INLINE void setViewFocus(DView* view);

	void AttachCameras(BoundingBox *box);
	void attachMenu(int menu);
	void detachMenu(int menu);
    void FitView();
	void move();
	void postRedisplay();
	void postRedisplayActive();

	bool add(DObject *obj);

	bool remove(int index);
	bool remove(char* name);
	bool remove(DObject* obj);

	bool isQuadView();
	void setQuadView(bool val);

	const static int TOP_LEFT = 0;
	const static int TOP_RIGHT = 1;
	const static int BOTTOM_LEFT = 2;
	const static int BOTTOM_RIGHT = 3;

	INLINE DView* getWindowAtLocation(int location);
	INLINE int getViewLocation(DView* view);
	INLINE void setWindowAtLocation(int location, DView* view);
	int getNumViews();
	DView* getView(int num);

	int getActiveLocation();
	void setActiveLocation(int v);

	DView* copyView(DView* copyView, char* name);

	DView* currentView;

	void setRenderer(DRenderer* renderer);
	DRenderer* getRenderer();

	void save(int mode, std::ofstream& file);


private:
	void resetActiveLocations();

	bool m_isQuadView;
	DView* m_focus;
	DView* m_viewAtlocation[MAXNUMVIEWS];
	int m_activeLocation;
	DRenderer* m_curRenderer;
	std::vector<DRenderer*> m_renderers;
	char m_renderDir[1024];
} ;

#endif
