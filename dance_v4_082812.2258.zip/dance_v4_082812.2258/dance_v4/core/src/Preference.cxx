/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "Preference.h"
#include "danceInterp.h"

#include <sstream>
#include <stdlib.h>

std::vector<Preference*> Preference::allpreferences;

Preference::Preference()
{
	name[0] = '\0';
	value[0] = '\0';
}


Preference::Preference(const char* n, const char* v)
{
	name = n;
	value = v;
}

void Preference::setName(const char* n)
{
	name = n;
}

const char* Preference::getName()
{
	return name.c_str();
}

void Preference::setValue(const char* n)
{
	value = n;
}

const char* Preference::getValue()
{
	return value.c_str();
}

void Preference::loadPreferences(std::ifstream& file)
{
	while (!file.eof())
	{
		char buffer[1024];
		file.getline(buffer, 1024);
                if (buffer[strlen(buffer) - 1] == '\r')
                        buffer[strlen(buffer) - 1] = '\0';

		if (strlen(buffer) == 0)
			continue;
		if (buffer[0] == '#') // ignore comments
			continue;
		// tokenize the line
		char* tok;
		tok = strtok(buffer, "=");
		if (tok != NULL)
		{
			// preference name
			std::string name = tok;
			tok = strtok(NULL, "");
			if (tok == NULL)
				continue;
			std::string value = tok;
			Preference* pref = new Preference();
			pref->setName((char*) name.c_str());
			pref->setValue((char*) value.c_str());

			Preference::addPreference(pref);
		}
	}
	file.close();
}


void Preference::writePreferences(std::ofstream& file)
{
	for (unsigned int i = 0; i < allpreferences.size(); i++)
	{
		Preference* pref = allpreferences[i];
		file << pref->getName() << "=" << pref->getValue() << std::endl;
	}
}

void Preference::removeAllPreferences()
{
	for (unsigned int x = 0; x < allpreferences.size(); x++)
		delete allpreferences[x];

	allpreferences.clear();
}

Preference* Preference::getPreference(const char* name)
{
	for (unsigned int x = 0; x < allpreferences.size(); x++)
	{
		if (strcmp(allpreferences[x]->getName(), name) == 0)
		{
			return allpreferences[x];
		}
	}

	return NULL;
}


const char* Preference::getPreferenceValue(const char* name)
{
	Preference* p = Preference::getPreference(name);
	if (p == NULL)
		return NULL;
	else
		return p->getValue();
}

void Preference::addPreference(Preference* pref)
{
	for (unsigned int x = 0; x < allpreferences.size(); x++)
	{
		if (allpreferences[x] == pref)
		{
			danceInterp::OutputMessage("Preference %s already present.", pref->getName());
			return;
		}
	}

	allpreferences.push_back(pref);
}

void Preference::removePreference(const char* name)
{
	for (std::vector<Preference*>::iterator iter = allpreferences.begin(); iter != allpreferences.end(); iter++)
	{
		if (strcmp((*iter)->getName(), name) == 0)
		{
			danceInterp::OutputMessage("Preference %s removed.", (*iter)->getName());
			delete (*iter);
			allpreferences.erase(iter);
			return;
		}
	}

	danceInterp::OutputMessage("No preference named %s found.", name);
}

void Preference::removePreference(Preference* pref)
{
	for (std::vector<Preference*>::iterator iter = allpreferences.begin(); iter != allpreferences.end(); iter++)
	{
		if (strcmp((*iter)->getName(), pref->getName()) == 0)
		{
			danceInterp::OutputMessage("Preference %s removed.", (*iter)->getName());
			delete (*iter);
			allpreferences.erase(iter);
			return;
		}
	}

	danceInterp::OutputMessage("No preference named %s found.", pref->getName());
}

void Preference::replacePreference(const char* n, const char* v)
{
	Preference* pref = Preference::getPreference(n);
	if (pref == NULL)
	{
		Preference* pref = new Preference(n, v);
		Preference::addPreference(pref);
	}
	else
	{
		pref->setValue(v);
		danceInterp::OutputMessage("Updated preference %s to value %s.", pref->getName(), pref->getValue());
	}

}

void Preference::getWindowPreference(const char* name, fltk::Widget* widget)
{
	char name1[1024];
	char name2[1024];

	sprintf(name1, "%s.x", name);
	sprintf(name2, "%s.y", name);

	Preference* p1 = Preference::getPreference(name1);
	Preference* p2 = Preference::getPreference(name2);

	if (p1 != NULL && p2 != NULL)
	{
		int xpos = atoi(p1->getValue());
		int ypos = atoi(p2->getValue());
		widget->x(xpos);
		widget->y(ypos);
	}
}

void Preference::setWindowPreference(const char* name, fltk::Widget* widget)
{
	char name1[1024];
	char name2[1024];

	sprintf(name1, "%s.x", name);
	sprintf(name2, "%s.y", name);
	
	int xval = widget->x();
	int yval = widget->y();

	if (xval < 0 || yval < 0)
		return;

	char xstr[40];
	char ystr[40];
	sprintf(xstr, "%d", widget->x());
	sprintf(ystr, "%d", widget->y());
	Preference::replacePreference(name1, xstr);
	Preference::replacePreference(name2, ystr);
}

void Preference::updateRecentPreferences(const char* prefix, int number, const char* recent)
{
	// is this recent value already in the list?
	int found = 0;
	Preference** p = new Preference*[number];
	for (int x = 1; x <= number; x++)
	{
		std::stringstream strstr;
		strstr << prefix << x;
		p[x - 1] = Preference::getPreference(strstr.str().c_str());
		if (p[x - 1] != NULL)
		{
			if (strcmp(p[x - 1]->getValue(), recent) == 0)
			{
				found = x;
			}
		}
		else
		{ // create the preference if it does not exist
			p[x - 1] = new Preference(strstr.str().c_str(), "");
			Preference::addPreference(p[x - 1]);
		}
	}
	// add this point, all preferences exist, found indicates position of new preference

	std::string old;
	// move all preferences down one step
	std::string old2;
	for (int x = 1; x <= 5; x++)
	{
		old2 = p[x - 1]->getValue();
		if (x == 1)
		{
			p[x - 1]->setValue(recent);
		}
		else
		{
			p[x - 1]->setValue(old.c_str());
		}
		old = old2;
		if (found == x)
			old = "";
	}

	delete [] p;
}




