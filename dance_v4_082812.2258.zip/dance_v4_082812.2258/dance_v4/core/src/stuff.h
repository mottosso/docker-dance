/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef _STUFF_H
#define _STUFF_H

#include <string>
#include <fstream>
#include "defs.h"
#include <fltk/gl.h>

#ifndef MAX
#define MAX(a,b) ( (a) > (b) ? (a) : (b) )
#define MIN(a,b) ( (a) < (b) ? (a) : (b) )
#endif

#ifndef RAD2DEG
#define RAD2DEG(r) ((r)*180/PI)
#define DEG2RAD(d) ((d)*PI/180)
#endif


#define VPOVRAY 1
#define VSPACES 2

#define FREE_CLEAR(p) { free(p); p=NULL; }


/* Misc funcs */

/* Tokenizes the file. The spaces (tabs, etc) are always separators (you do not need to include them in the seps). 
Returns the characters in seps as tokens. Call the first time with my_C_tokenizer(file, NULL), to init state 
Ignores C comments / *  and * /   */
DLLENTRY std::string my_C_tokenizer(std::ifstream &file, char *seps);

/* Tokenizes the file. The spaces (tabs, etc) are always separators (you do not need to include them in the seps). 
Returns the characters in seps as tokens. Call the first time with my_VRML_tokenizer(file, NULL), to init state 
Ignores VRML comment, from # until the end of the line   */

DLLENTRY std::string my_VRML_tokenizer(std::ifstream &file, char *seps);


/* Reads a povray color from the file. See Material::read_povray. Although it accept rgbft, only reads rgbt */
DLLENTRY int read_povray_color(std::ifstream &file, float *color);

// Writes --n-- components of --vector-- in the file. Depending on --mode--:
// mode=VPOVRAY   ->   <v0, v1, v2...vn>
// mode=VSPACES   ->   v0 v1 v2 ... vn
DLLENTRY void write_vector(std::ofstream &file, float *vector, int n, int mode);
DLLENTRY void write_vector(std::ofstream &file, double *vector, int n, int mode);


DLLENTRY void bwtorgba(unsigned char *b,unsigned char *l,int n);
DLLENTRY void latorgba(unsigned char *b, unsigned char *a,unsigned char *l,int n);
DLLENTRY void rgbtorgba(unsigned char *r,unsigned char *g,unsigned char *b,unsigned char *l,int n);
DLLENTRY void rgbatorgba(unsigned char *r,unsigned char *g,unsigned char *b,unsigned char *a,unsigned char *l,int n);
DLLENTRY void ConvertShort(unsigned short *array, long length) ;
DLLENTRY void ConvertLong(unsigned *array, long length);


// Reads from the file a line and writes it in --*dest--, removing spaces leading and trailing spaces
// 0: OK, -1: EOF
DLLENTRY int readTrimmedLine(std::ifstream & file, char *dest, int sizedest);

// Removes the file name from the path
DLLENTRY void removeFilename(char *path);

// Extracts the file name from a path
DLLENTRY void getFilename(char *pathname, bool remove_extension, char *filename);


// Checks if a file is readable
DLLENTRY int fileReadable(char *path);

// Builds an absolute file name from the path and the file name (--dest-- can be --path--)
DLLENTRY void buildPathName(char *dest, char *path, char *file);

// retrieves path name
DLLENTRY void getPathName(char *path, char *file);

// Returns the smaller power of two that is non smaller that n
DLLENTRY unsigned int ceilPower2(unsigned int n);

DLLENTRY void convertbackslashes(const char* in, char* out);
DLLENTRY void convertbackslashesinplace(const char* out);

DLLENTRY void trim(const char* in, char* out);
DLLENTRY void eliminatespaces(const char* in, char* out);
DLLENTRY void changechar(const char* in, char* out, char lookfor, char changeto);
DLLENTRY const char* fltk_filename_normalize(char* output, int length, const char* input, const char* directory=0);


#endif
