/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "dancePython.h"
#include <string>
#include "dance.h"
#include "danceInterp.h"
#include "DObjectList.h"
/**
#include "DObjectList.h"
#include "PlugInManager.h"
#include "DSimulatorManager.h"
#include "DSystem.h"
#include "ViewManager.h"
#include "DanceWindow.h"
#include "SelectionWindow.h"
**/

#include <iostream>
#include <cstdlib>
#include <cassert>
#include <sstream>

#ifndef WIN32
#include <unistd.h>
#endif


using namespace fltk;
using namespace std;


const int MAX_SIZE_OUT_BUFFER = 8192 ;

char OutBuffer[MAX_SIZE_OUT_BUFFER] = "" ;
char ResultBuffer[MAX_SIZE_OUT_BUFFER] = "";
 
PyObject *dancePython::pMainDictionary ;
PyObject *dancePython::pMainModule ;

//------------------------------------------------------------------------------
// Make Python aware of our special C++ functions above.
//------------------------------------------------------------------------------

PyMethodDef g_PythonInterpreterFunctions[] =
{   
	{ "actuator",dancePython::actuator, METH_VARARGS,
		"send commands to an actuator"},
	{ "geometry", dancePython::geometry, METH_VARARGS,
					  "send commands to a geometry"	},
	{ "system", dancePython::system, METH_VARARGS,
					  "send commands to a system"	},
	{ "light", dancePython::light, METH_VARARGS,
					  "send commands to a light "	},
	{ "view", dancePython::view, METH_VARARGS,
					  "send commands to a view "	},
	{ "simulator", dancePython::simulator, METH_VARARGS,
					  "send commands to a simulator"	},
	{ "modifier", dancePython::modifier, METH_VARARGS,
					  "send commands to a modifier"	},
	{ "renderer", dancePython::renderer, METH_VARARGS,
					  "send commands to a renderer "	},
	{ "generic", dancePython::generic, METH_VARARGS,
					  "send commands to an generic plug-in"	},
	{ "all", dancePython::all, METH_VARARGS,
					  "TBA"	},
	{ "active", dancePython::active, METH_VARARGS,
					  "TBA"	},
	{ "instance", dancePython::instance, METH_VARARGS,
					  "create an instance of a plugin"	},
	{ "plugin", dancePython::Plugin, METH_VARARGS,
					  "load a plugin into DANCE"	},
	{ "remove", dancePython::remove, METH_VARARGS,
					  "remove an object instance"	},
	{ "show", dancePython::show, METH_VARARGS,
					  "shows all plugins in the system, or use show |actuator|geometry|system|modifier|generic|simulator|view|light to see plugins of that type."	},
	{ "exists", dancePython::exists, METH_VARARGS,
					  "checks to see if a plugin of a given name exists."	},
	{ "<", dancePython::load, METH_VARARGS,
					  "load a file containing python DANCE commands"	},
	{ "load", dancePython::load, METH_VARARGS,
					  "load a file containing python DANCE commands"	},
	{ "simul", dancePython::simul, METH_VARARGS,
					  "send commands to the simulation manager"	},
	{ "viewmanager", dancePython::viewmanager, METH_VARARGS,
					  "send commands to the view manager"	},
	{ "materialmanager", dancePython::materialmanager, METH_VARARGS,
					  "send commands to the material manager"	},
	{ "quit", dancePython::quit, METH_VARARGS,
					  "exit DANCE"	},
	{ "queryOS",dancePython::queryOS, METH_VARARGS, 
					  "show the current operating system type" },
					  
	{ "showinterface",dancePython::showinterface, METH_VARARGS, 
					  "show the GUI inteferface for a DANCE object" },
	{ "hideinterface",dancePython::hideinterface, METH_VARARGS, 
					  "hide the GUI inteferface for a DANCE object" },
	{ "addinteraction",dancePython::addinteraction, METH_VARARGS, 
					  "allow the DANCE object to handle keyboard and mouse commands" },
	{ "removeinteraction",dancePython::removeinteraction, METH_VARARGS, 
					  "remove keyboard and mouse command control from a DANCE object" },
	{ "hideinterface",dancePython::hideinterface, METH_VARARGS, 
					  "show the GUI interface for a DANCE object" },
	{ "dependency",dancePython::dependency, METH_VARARGS, 
					  "create a dependency between two objects" },
	{ "setNoOutput",dancePython::setNoOutput, METH_VARARGS, 
					  "turns on or off the printing of messages in the console window" },
	{ "reset",dancePython::reset, METH_VARARGS, 
					  "reset to the default session" },
	{ "save", dancePython::save, METH_VARARGS, 
					  "save a DANCE session" },
	{ "rename", dancePython::rename, METH_VARARGS, 
					  "rename a DANCE object" },
	{ "chdir", dancePython::chdir, METH_VARARGS, 
					  "change the DANCE working directory" },
	{ "version", dancePython::version, METH_VARARGS, 
					  "change the current DANCE version" },
	{ "dancedir", dancePython::danceDir, METH_VARARGS, 
					  "gets the DANCE_DIR value" },
	{ "checkui", dancePython::checkUI, METH_VARARGS, 
					  "checks the UI components" },
					  
	{NULL, NULL}

};


// Commands that belong to danceInterp and wrap equivalent functions of a specific interpreter
// implementation. If the classes were not static, these functios would be virtual and
// the would be subclassed by a specific implementation.

static const char *ProfilePython = "profile.py" ;

const char *danceInterp::getProfileFile() { return ProfilePython;} 

void danceInterp::flush() { } 

int danceInterp::Init(int argc, char **argv) { return dancePython::InitPython(argc, argv); } 

// OutputListElement:
//	Adds an item to the result list.
void danceInterp::OutputListElement(const char * format, ...)
{
	va_list vl;

	//  format is the last argument specified; all
    //  others must be accessed using the variable-argument macros.
    va_start( vl, format);   
	static char message[MAX_SIZE_OUT_BUFFER];
	vsprintf(message,format,vl);
	va_end( vl );

	int len = (int) strlen(message);
	assert( len < MAX_SIZE_OUT_BUFFER); // Exceeded internal print buffer.

	//danceInterp::OutputMessage("%s",message) ;

	int size = strlen(ResultBuffer); 
	if( size > 0 ) strcat(ResultBuffer," ") ;
	strcat(ResultBuffer,message) ;
}

void danceInterp::OutputMessage(const char *format, ...)
{

	if (dance::NoOutput == true ) return ;

    va_list vl;   

    //  format is the last argument specified; all
    //  others must be accessed using the variable-argument macros.
    va_start( vl, format);   
    char message[MAX_SIZE_OUT_BUFFER];

    vsprintf(message,format,vl);
    va_end( vl );
	dancePython::getStandardOutputError() ;
	strncat(OutBuffer, message, MAX_SIZE_OUT_BUFFER - 2 ) ;
	strcat(OutBuffer, "\n\0") ;
	dancePython::DisplayOutput();
}

void danceInterp::OutputResult(const char *format, ...)
{
	va_list vl;

	//  format is the last argument specified; all
    //  others must be accessed using the variable-argument macros.
	va_start( vl, format);   
	static char message[MAX_SIZE_OUT_BUFFER];
	
	vsprintf(message,format,vl);
	va_end( vl );

	int len = (int) strlen(message);
	assert( len < MAX_SIZE_OUT_BUFFER); // Exceeded internal print buffer.
	sprintf(ResultBuffer,"%s",message) ;	
}


int danceInterp::load(const char *filename)
{
	string *res = dancePython::loadPythonScript(filename) ;
	if( res ) 
	{
		PyObject *p = PyRun_String(res->c_str(),Py_file_input, dancePython::pMainDictionary, dancePython::pMainDictionary) ;

		if (p != NULL)
		{
			//dance::Refresh();
			delete res ;
			Py_XDECREF(p) ;
			dancePython::DisplayOutput() ;
			return DANCE_OK ;
		}
		else
		{
			delete res ;
			PyErr_Print();

			//PyObject* p2 = PyRun_String("sys.stderr.flush()\n",Py_file_input, dancePython::pMainDictionary, dancePython::pMainDictionary) ;
			PyObject *exception, *err, *tb;
			PyErr_Fetch( &exception, &err, &tb );
			if (err)
				Py_INCREF(err);
			if (exception)
				Py_INCREF(exception);
			if (tb)
				Py_INCREF(exception);
			danceInterp::OutputMessage("Error when loading file %s", filename);
			PyObject *stderrorObj = PySys_GetObject("_stderrCatcher");
			PyObject *f = PySys_GetObject((char*)"stderr");
			int errorNum = PyTraceBack_Print(tb, f);
			if (err)
			{
				danceInterp::OutputMessage("Python error number %d\n", errorNum);
				Py_DECREF(err);
			}
			if (exception)
			{
				Py_DECREF(exception);
			}
			if (tb)
			{
				Py_DECREF(exception);
			}
			Py_XDECREF(p) ;
			PyErr_Clear();
			dancePython::DisplayOutput() ;
			return DANCE_ERROR;
		}
	} else return DANCE_ERROR ;
}


// dir has to be preallocated
void danceInterp::getCurrentDirectory(char *dir) {

	PyObject *pModule = PyImport_ImportModule( "os" );
    PyObject *pAttrGetcwd = PyObject_GetAttrString( pModule, "getcwd" );
	PyObject *pResult = PyEval_CallObject( pAttrGetcwd, NULL );
	char *cStr;
	PyArg_Parse( pResult, "s", &cStr );
	strcpy(dir,&cStr[0]) ;	
#ifdef WIN32
	for( int i = 0 ; i < strlen(cStr) ; i++ )
	{
		if( dir[i] == '\\' ) dir[i] = '/' ;
	}
#endif
	Py_XDECREF( pResult );
	Py_XDECREF( pAttrGetcwd );
    Py_XDECREF( pModule );
} 

int danceInterp::ExecuteCommand(const char *command) 
{
	int res = dancePython::ExecuteCommand(command) ;
	if( res == DANCE_ERROR) 
	{
		danceInterp::OutputMessage("==> [%s] Error...", command) ;
	}
	dance::rootWindow->commandWindow->addHistoryItem(command);
	dancePython::DisplayOutput() ;
	return DANCE_OK ;
}

int danceInterp::ExecuteCommandNoRecord(const char *command) 
{
	dancePython::ExecuteCommand(command) ;
	return DANCE_OK ;
}

int danceInterp::getDirectoryListing(char *dl, int maxsize, char *directory)  // dl has to be preallocated
{
	char dir[512] ;
	if( directory == NULL ) strcpy(dir,"\0") ;
	else strcpy(dir, directory) ;


	PyObject *pModule = PyImport_ImportModule( "os" );
    PyObject *pAttrGetcwd = PyObject_GetAttrString( pModule, "listdir" );

	PyObject *pArguments = Py_BuildValue( "(s)", dir );
    PyObject *pResult = PyEval_CallObject( pAttrGetcwd, pArguments );
	
	int Max = maxsize;

	char *cStr;
	int n = 0 ;
	if( pResult != NULL )
	{
		PyObject * pString = PyObject_Str(pResult) ;
		cStr = PyString_AS_STRING(pString) ; 	
		for( int i = 0 ; (i < (int) strlen(cStr)) && (i < Max) ; i++ )
		{
			if( (cStr[i] != '[') && (cStr[i] != '\'') && (cStr[i] != ']') && (cStr[i] != ']') && (cStr[i] != ' '))
			{
				if( cStr[i] == ',' ) dl[n] = ' ' ;
				else dl[n] = cStr[i] ;
				n++ ;
			}
		}
		Py_XDECREF(pString) ;
	}
	dl[n] = '\0' ;
	Py_XDECREF( pResult );
	Py_XDECREF( pAttrGetcwd );
	Py_XDECREF( pArguments) ;
    Py_XDECREF( pModule );

	return DANCE_OK ;
}


void danceInterp::getHistoryEvent(int n, char *cmd) 
{
	dancePython::getHistoryEvent(n, cmd) ;

}

void dancePython::getHistoryEvent(int n, char *cmd)
{

}


char *dancePython::getStandardOutputError()
{
	// get stdout
	PyRun_String("__res__ = sys.stdout.data\n", Py_file_input,pMainDictionary,pMainDictionary) ;
    PyObject *pResult = PyDict_GetItemString( pMainDictionary, "__res__" );
	char *boutTemp = NULL ;
    PyArg_Parse( pResult, "s", &boutTemp );

	int sizeOut = strlen(OutBuffer) ;
	if( boutTemp != NULL )
	{
		int sizeInc = strlen(boutTemp) ;
		if( sizeInc+sizeOut < MAX_SIZE_OUT_BUFFER )
		{
			sizeOut += (int) strlen(boutTemp) ;
			strcat(OutBuffer,boutTemp) ;
		
		}
		else
		{
			strncat(OutBuffer,boutTemp, MAX_SIZE_OUT_BUFFER) ;
			sizeOut = MAX_SIZE_OUT_BUFFER-1 ;
		}
		OutBuffer[sizeOut] = '\0' ;

		// clear the python buffer
		PyRun_String("sys.stdout.data = \"\"\n",Py_file_input,pMainDictionary,pMainDictionary) ;
		//Py_XDECREF( pResult );
	}

	// get stderr
//	PyRun_String("__res_err__ = sys.stderr.data\n", Py_file_input,pMainDictionary,pMainDictionary) ;
	PyRun_String("__res_err__ = _stderrCatcher.data\n", Py_file_input,pMainDictionary,pMainDictionary) ;
	pResult = PyDict_GetItemString( pMainDictionary, "__res_err__" );
	char *berrTemp = NULL ;
    PyArg_Parse( pResult, "s", &berrTemp );	
	
	if( berrTemp != NULL && strlen(berrTemp) != 0 )
	{
		sizeOut += (int) std::min<int>( MAX_SIZE_OUT_BUFFER-1, strlen(berrTemp) );
		//OutBuffer = new char[size+1] ;
		int remaining = MAX_SIZE_OUT_BUFFER - strlen(OutBuffer) - 1;
		strncat(OutBuffer,berrTemp,remaining) ;
		OutBuffer[sizeOut] = '\0' ;

		// clear the python buffer
		PyRun_String("sys.stderr.data = \"\"\n",Py_file_input,pMainDictionary,pMainDictionary) ;
		//Py_XDECREF( pResult );
	}


	return OutBuffer ;  
}

//-----------------------------------------------------------------------------
// Function: 
//      loadPythonScript().
// Does: 
//		reads a python script into string.
// Side effects:
//		allocates the string.
//-----------------------------------------------------------------------------
string *dancePython::loadPythonScript(const char *fileName )
{
    ifstream pythonFile;

    pythonFile.open( fileName );

    if ( !pythonFile.is_open() ) 
    {
		danceInterp::OutputMessage("Cannot open python script file %s", fileName) ;
        pythonFile.clear();
        return NULL;
    }
    else
    {
		danceInterp::OutputMessage("Reading python script file %s", fileName) ;
	string* scriptString = new string();
	char buff[2048];
	while (pythonFile.good())
	{
		pythonFile.getline(buff, 2048);
		scriptString->append(buff);
		scriptString->append("\n");
	}

        pythonFile.close();

	    return scriptString;
    }
}

PyObject *dancePython::queryOS(PyObject* self, PyObject* args)
{

	//PyRun_String("sys.platform()",Py_file_input,pMainDictionary,pMainDictionary);
	PyRun_String("print sys.platform\n",Py_single_input,pMainDictionary,pMainDictionary);
	
    return Py_BuildValue("");
}

int dancePython::ExecuteCommand(const char *buffer)
{
	int res = Run(buffer) ;
	DisplayOutput() ;
	return res ;
}

void dancePython::DisplayOutput()
{
	char* buff = getStandardOutputError() ;
	dance::rootWindow->commandWindow->UpdateOutput(&OutBuffer[0]) ;
	dance::rootWindow->commandWindow->redraw();
	// clear the OutputBuffer
	OutBuffer[0] = '\0' ;
}


int dancePython::InitPython(int argc, char **argv)
{
	Py_Initialize();

    //
    // Define our custom module called "dance"...
	//

    PyImport_AddModule( "dance" );
    Py_InitModule( "dance", g_PythonInterpreterFunctions );

	//
	// Access the "__main__" module and its name-space dictionary.
	//

	pMainModule     = PyImport_AddModule( "__main__" );
	pMainDictionary = PyModule_GetDict( pMainModule );

	PyRun_String("import sys\n"
			"import os\n",Py_file_input,pMainDictionary,pMainDictionary) ;


	// redirect the output of any python command into the variable sys.stout.data
	PyRun_String("import sys\n"
			"class StdoutCatcher:\n"
			"    def __init__(self):\n"
			"        self.data = ''\n"
			"    def write(self, stuff):\n"
			"        self.data = self.data + stuff\n"
			"_stdoutCatcher = StdoutCatcher()\n"
			"sys.stdout = _stdoutCatcher\n",Py_file_input,pMainDictionary,pMainDictionary) ;
			//"sys.stdout = StdoutCatcher()\n",Py_file_input,pMainDictionary,pMainDictionary) ;

	PyRun_String(
			"class StderrCatcher:\n"
			"    def __init__(self):\n"
			"        self.data = ''\n"
			"    def write(self, stuff):\n"
			"        self.data = self.data + stuff\n"
			"_stderrCatcher = StderrCatcher()\n"
			"sys.stderr = _stderrCatcher\n",Py_file_input,pMainDictionary,pMainDictionary) ;
			//"sys.stderr = StderrCatcher()\n",Py_file_input,pMainDictionary,pMainDictionary) ;
	/**
	PyObject *p = PyRun_String(
		"import sys\n"
		"def mye(t,v,tr):\n"
		"    print t,v,tr\n"
		"sys.excepthook = mye\n",Py_file_input,pMainDictionary,pMainDictionary) ;
	**/	

	PyObject *p1 = PyRun_String(
		"import dance\nimport sys\nimport math\n"
		"dir(dance)\n",Py_file_input,pMainDictionary,pMainDictionary) ;			
	if (!p1) 
	{
	std::cout << "Problem importing dance, sys and math libraries. Python will not work correctly." << std::endl;
	}

	return DANCE_OK ;
}

void dancePython::CleanUp()
{
	Py_DECREF( pMainDictionary );
	Py_DECREF( pMainModule );
	Py_Finalize();
}

int dancePython::Run(const char *command)
{
	// if command spans multiple lines, process entire block at once
	// otherwise, process command interactively (shows output)
	PyObject *pResult;
	if (strstr(command, "\n") == NULL)
	{	
		pResult	= PyRun_String(command,		
			Py_single_input,pMainDictionary,pMainDictionary) ;
	}
	else
	{
		pResult = PyRun_String(command,		
			Py_file_input,pMainDictionary,pMainDictionary) ;
	}
	int res ;
	if( pResult == NULL )
	{
		if( PyErr_Occurred() ) 
		{
			PyObject *exception, *err, *tb;
			PyErr_Fetch( &exception, &err, &tb );
			if (err)
				Py_INCREF(err);
			if (exception)
				Py_INCREF(exception);
			if (tb)
				Py_INCREF(exception);
			danceInterp::OutputMessage("==> [%s]", command);
			PyErr_Print();


			//PyObject *f = PySys_GetObject("stderr");
			//int errorNum = PyTraceBack_Print(tb, f);
			if (err)
			{
				Py_DECREF(err);
			}
			if (exception)
			{
				Py_DECREF(exception);
			}
			if (tb)
			{
				Py_DECREF(exception);
			}

			PyErr_Clear();
			//PyErr_Print() ;
		}
		res =  DANCE_ERROR ;
	}
	else res = DANCE_OK ;
	Py_XDECREF(pResult) ;

	return res ; 

}

// Function: GetArguments()
//
// Does: 
//		Transforms args into an array of pointers to strings.
// Returns: 
//		The number of arguments.
// Side effects: 
//		Allocates the arrage argv[0,...,argc-1].
int dancePython::GetArguments(PyObject *args, char **&argv)
{
	//char *temp ;
	int argc = PyTuple_Size(args) ;
	argv = new char *[argc+1] ;
	argv[argc] = 0 ;
	for( int i = 0 ; i < argc ; i++ )
	{
		PyObject *a = PyTuple_GET_ITEM(args,i) ;
		PyObject *sa = PyObject_Str(a) ;
		argv[i] = PyString_AS_STRING(sa) ;
//		Py_XDECREF(sa) ;
	}
	return argc ;
}


PyObject *dancePython::all(PyObject* self, PyObject* args)
{
	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	danceInterp::all(argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::active(PyObject* self, PyObject* args)
{

	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	danceInterp::active( argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::instance(PyObject* self, PyObject* args)
{

	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	danceInterp::instance( argc,argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::quit(PyObject *self, PyObject *args)
{
	dance::DeleteAll();

	dance::quit();

    return Py_BuildValue("");
}



PyObject *dancePython::save(PyObject* self, PyObject* args)
{

	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	danceInterp::save( argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::Plugin(PyObject* self, PyObject* args)
{

	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	danceInterp::Plugin( argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::simul(PyObject* self, PyObject* args)
{
	char **argv = NULL  ;
	int argc = GetArguments(args,argv) ;
	danceInterp::simul( argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}


PyObject *dancePython::viewmanager(PyObject* self, PyObject* args)
{

	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;

	danceInterp::viewmanager( argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::materialmanager(PyObject* self, PyObject* args)
{

	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;

	int ret = danceInterp::materialmanager( argc, argv) ;

	if (ret == DANCE_OK)
	{
		PyObject *s = PyString_FromStringAndSize(ResultBuffer,strlen(ResultBuffer)) ;
		ResultBuffer[0] = '\0' ; //reset buffer
		return s ;
	}
	else
	{
		return NULL ;
	}
}

PyObject *dancePython::remove(PyObject* self, PyObject* args)
{

	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;

	danceInterp::remove( argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}


PyObject *dancePython::show(PyObject* self, PyObject* args)
{

	char **argv= NULL ;
	int argc = GetArguments(args,argv) ;

	int ret = danceInterp::show( argc, argv) ;
	if( argv) delete [] argv ;
	
	if (ret == DANCE_OK)
	{
		PyObject *s = PyString_FromStringAndSize(ResultBuffer,strlen(ResultBuffer)) ;
		ResultBuffer[0] = '\0' ; //reset buffer
		return s ;
	}
	else
	{
		return NULL ;
	}
}


PyObject *dancePython::exists(PyObject* self, PyObject* args)
{

	char **argv= NULL ;
	int argc = GetArguments(args,argv) ;

	int ret = danceInterp::exists( argc, argv) ;
	if( argv) delete [] argv ;
	
	if (ret == DANCE_OK)
	{
		PyObject *s = PyString_FromStringAndSize(ResultBuffer,strlen(ResultBuffer)) ;
		ResultBuffer[0] = '\0' ; //reset buffer
		return s ;
	}
	else
	{
		return NULL ;
	}
}


PyObject *dancePython::rename(PyObject* self, PyObject* args)
{

	char **argv = NULL;
	int argc = GetArguments(args,argv) ;
	danceInterp::rename(argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::chdir(PyObject* self, PyObject* args)
{

	char **argv = NULL;
	int argc = GetArguments(args,argv) ;
	danceInterp::chdir(argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::version(PyObject* self, PyObject* args)
{
	char **argv= NULL ;
	int argc = GetArguments(args,argv) ;

	danceInterp::version( argc, argv) ;
	
	PyObject *s = PyString_FromStringAndSize(ResultBuffer,strlen(ResultBuffer)) ;
	ResultBuffer[0] = '\0' ; //reset buffer
	return s ;

}

PyObject *dancePython::danceDir(PyObject* self, PyObject* args)
{
	char **argv= NULL ;
	GetArguments(args,argv) ;

	const char* danceDir = dance::getDanceDir();
	
	PyObject *s = PyString_FromStringAndSize(danceDir,strlen(danceDir)) ;
	ResultBuffer[0] = '\0' ; //reset buffer
	return s ;

}


PyObject *dancePython::checkUI(PyObject* self, PyObject* args)
{
	char **argv= NULL ;
	GetArguments(args,argv) ;
	int argc = GetArguments(args,argv) ;
	danceInterp::checkUI(argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::showinterface(PyObject* self, PyObject* args)
{

	char **argv = NULL;
	int argc = GetArguments(args,argv) ;
	danceInterp::showinterface(argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::hideinterface(PyObject* self, PyObject* args)
{
	char **argv = NULL;
	int argc = GetArguments(args,argv) ;
	danceInterp::hideinterface(argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::addinteraction(PyObject* self, PyObject* args)
{

	char **argv = NULL;
	int argc = GetArguments(args,argv) ;
	danceInterp::addinteraction(argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::removeinteraction(PyObject* self, PyObject* args)
{
	char **argv = NULL;
	int argc = GetArguments(args,argv) ;
	danceInterp::removeinteraction(argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::dependency(PyObject* self, PyObject* args)
{
	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	danceInterp::dependency(argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::setNoOutput(PyObject* self, PyObject* args)
{
	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	danceInterp::setNoOutput(argc, argv) ;
	if( argv) delete [] argv ;
    return Py_BuildValue("");
}

PyObject *dancePython::load(PyObject* self, PyObject* args)
{
	char **argv = NULL ;
	int res = DANCE_ERROR ;

	int argc = GetArguments(args,argv) ;
	if( argc ==1 )
	{
		res = danceInterp::load(argv[0]) ;
	}

	if( argv) delete [] argv ;
	return result(res) ;
}

PyObject * dancePython::actuator(PyObject * self, PyObject* args)
{
	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	PyObject* res =  result(danceInterp::actuator(argc, &argv[0])) ;
	if( argv) delete [] argv ;
	return res ;
}

PyObject * dancePython::system(PyObject * self, PyObject* args)
{
	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	PyObject* res =  result(danceInterp::system(argc, &argv[0])) ;
	if( argv) delete [] argv ;
	return res ;
}

PyObject * dancePython::modifier(PyObject * self, PyObject* args)
{
	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	PyObject *res = result(danceInterp::modifier(argc, &argv[0])) ;
	if( argv) delete [] argv ;
	return res ;
}

PyObject * dancePython::geometry(PyObject * self, PyObject* args)
{
	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	PyObject *res = result(danceInterp::geometry(argc, &argv[0])) ;
	if( argv) delete [] argv ;
	return res ;
}

PyObject * dancePython::simulator(PyObject * self, PyObject* args)
{
	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	PyObject *res = result(danceInterp::simulator(argc, &argv[0])) ;
	if( argv) delete [] argv ;
	return res ;
}

PyObject * dancePython::view(PyObject * self, PyObject* args)
{
	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	PyObject *res = result(danceInterp::view(argc, &argv[0])) ;
	if( argv) delete [] argv ;
	return res ;
}

PyObject * dancePython::renderer(PyObject * self, PyObject* args)
{
	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	PyObject *res = result(danceInterp::renderer(argc, &argv[0])) ;
	if( argv) delete [] argv ;
	return res ;
}

PyObject * dancePython::generic(PyObject * self, PyObject* args)
{
	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	PyObject *res = result(danceInterp::generic(argc, &argv[0])) ;
	if( argv) delete [] argv ;
	return res ;
}

PyObject * dancePython::light(PyObject * self, PyObject* args)
{
	char **argv = NULL ;
	int argc = GetArguments(args,argv) ;
	PyObject *res = result(danceInterp::light(argc, &argv[0])) ;
	if( argv) delete [] argv ;

	return res;
}

PyObject * dancePython::reset(PyObject * self, PyObject* args)
{
	dance::resetAll();
	dance::loadProfile();

    return Py_BuildValue("");
}

PyObject * dancePython::result(int code)
 { 
	 if (code == DANCE_ERROR)
	 {
		ResultBuffer[0] = '\0';
		return NULL;
	 }
	 else
	 {
		if( ResultBuffer[0] != '\0' )
		{
			PyObject *s = PyString_FromStringAndSize(ResultBuffer,strlen(ResultBuffer)) ;
			ResultBuffer[0] = '\0' ; //reset buffer
			//Py_XDECREF(s) ; // ???
			return s ;
		}
		else
		{
		    return Py_BuildValue("");
		}
	 }
 }


