/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "ParserSKM.h"
#include <iostream>
#include <stack>
#include <sstream>
#include <stdlib.h>
#include "danceInterp.h"
#include "dance.h"
#include "stuff.h"
#include "DConnectionManager.h"

using namespace std;

Character* ParserSKM::parse(std::string name, std::ifstream &metaFile, std::ifstream &dataFile, int N1, int N2)
{
	// check to make sure we have properly opened the file
	if (!metaFile.good())
	{	
		danceInterp::OutputMessage("Could not open .sk file.\n");
		if (dataFile.good())
			dataFile.close();
		return NULL;
	}

	if (!dataFile.good())
	{
		danceInterp::OutputMessage("Could not open .skm file.\n");
		metaFile.close();
		return NULL;
	}

	char line[8192];
	Character* c = new Character();
	c->setName(name.c_str());
	c->setIsBVH(true);
	int state = 0;
	char* str = NULL;
	stack<CharJoint*> stack;
	CharJoint* cur = NULL;
	int numFrames = 0;
	int curFrame = -1;
	double frameTime = 0;
	double lastFrameTime = 0;
	int numSkmChannels = 0;
	int foundRoot = 0; // 0 = root not found, 1 = root found, 2 = next joint found
	std::vector<int> channelMap;
	std::string origLine;
	int numRootFrames = 0;
	bool parsedFrame = false;

	while(!metaFile.eof() && metaFile.good())
	{
		metaFile.getline(line, 8192, '\n');
                // remove any trailing \r
                if (line[strlen(line) - 1] == '\r')
                        line[strlen(line) - 1] = '\0';
		if (strlen(line) == 0) // ignore blank lines
			continue;
		
		
		switch (state)
		{
			case 0:	// looking for 'skeleton'
				str = strtok(line, " \t");	
				if (str && str[0] == '#') // ignore comment lines
					break;

				// ignore the set_name 
				if (str && 
						(strncmp(str, "set_name", strlen("set_name")) == 0 || 
						 strncmp(str, "SET_NAME", strlen("SET_NAME") == 0)))
					break;

				if (strncmp(str, "skeleton", strlen("skeleton")) == 0 || strncmp(str, "SKELETON", strlen("SKELETON")) == 0)
					state = 1;
				else
				{
					danceInterp::OutputMessage("skeleton not found...\n");
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 1:	// looking for 'ROOT'
				str = strtok(line, " \t");	
				if (str != NULL && (strncmp(str, "ROOT", strlen("ROOT")) == 0 || strncmp(str, "root", strlen("root")) == 0))
				{
					str = strtok(NULL, " \t");
					if (str != NULL)
					{
						char trimmedname[512];
						trim(str, trimmedname);
						std::stringstream strstr;
						strstr << c->getName() << "_" << trimmedname;
						CharJoint* root = new CharJoint(strstr.str().c_str());
						dance::AllGenericPlugins->add(root);
						dance::connectionManager->makeConnection(c, "rootjoint", root);
						cur = root;
						state = 2;
					}
					else
					{
						danceInterp::OutputMessage("ROOT name not found...\n");
						metaFile.close();
						dataFile.close();
						return c;
					}
				}
				else
				{
					danceInterp::OutputMessage("ROOT not found...\n");
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 2: // looking for '{'
				str = strtok(line, " \t");
				if (str != NULL && strncmp(str, "{", 1) == 0)
				{
					stack.push(cur);

					str = strtok(NULL, " \t");

					if (str != NULL && (strncmp(str, "OFFSET", strlen("OFFSET")) == 0 ||  strncmp(str, "offset", strlen("offset")) == 0))
					{
						if (foundRoot == 0)
							foundRoot = 1;
						else if (foundRoot == 1)
							foundRoot = 2;
						double x = 0; double y = 0; double z = 0;
						str = strtok(NULL, " \t");
						x = atof(str);
						str = strtok(NULL, " \t");
						y = atof(str);
						str = strtok(NULL, " \t");
						z = atof(str);
						cur->setOffset(x, y, z);
						//cout << "Found offset of " << x << " " << y << " " << z << " " << endl;
					}
					state = 3;
				}
				else
				{
					danceInterp::OutputMessage("{ not found...\n");
					metaFile.close();
					dataFile.close();
					return c;
				}
				break;
			case 3: // looking for 'OFFSET'
				str = strtok(line, " \t");
				// for now, ignore visgeo and colgeo
				if (str != NULL && (strncmp(str, "VISGEO", strlen("VISGEO")) == 0 || strncmp(str, "visgeo", strlen("visgeo")) == 0))
				{
					std::vector<std::string>& parameters = cur->getParameters();
					char buff[512];
					char* str2 = strtok(NULL, " \t");
					if (str2)
						sprintf(buff, "%s %s", str, str2);
					parameters.push_back(buff);
					break;
				}
				if (str != NULL && (strncmp(str, "COLGEO", strlen("COLGEO")) == 0|| strncmp(str, "colgeo", strlen("colgeo")) == 0))
				{
					std::vector<std::string>& parameters = cur->getParameters();
					char buff[512];
					char* str2 = strtok(NULL, " \t");
					if (str2)
						sprintf(buff, "%s %s", str, str2);
					parameters.push_back(buff);
					break;
				}
			
				if (str != NULL && (strncmp(str, "CHANNEL", strlen("CHANNEL")) == 0 || strncmp(str, "channel", strlen("channel")) == 0))
				{
					str = strtok(NULL, " \t");
					int channels[6];
					int numChannels = cur->getChannels(channels);
					int curChannel = numChannels;
					bool isTranslation = false;
					if (strncmp(str, "Quat", strlen("Quat")) == 0) 
					{
						channels[curChannel] = CharJoint::XROTATION;
						channels[curChannel + 1] = CharJoint::YROTATION;
						channels[curChannel + 2] = CharJoint::ZROTATION;
						cur->setChannels(numChannels + 3, channels);
					}
					else if (strncmp(str, "XPos", strlen("XPos")) == 0) 
					{
						channels[curChannel] = CharJoint::XPOSITION;
						cur->setChannels(numChannels + 1, channels);
						isTranslation = true;
					}
					else if (strncmp(str, "YPos", strlen("YPos")) == 0) 
					{
						channels[curChannel] = CharJoint::YPOSITION;
						cur->setChannels(numChannels + 1, channels);
						isTranslation = true;
					}
					else if (strncmp(str, "ZPos", strlen("ZPos")) == 0) 
					{
						channels[curChannel] = CharJoint::ZPOSITION;
						cur->setChannels(numChannels + 1, channels);
						isTranslation = true;
					}
					else
					{
						danceInterp::OutputMessage("Unknown channel: %s...\n", str);;
						metaFile.close();
					}

					if (isTranslation)
					{
						str = strtok(NULL, " \t");
						if (str)
							double value = atof(str); // value of joint, ignore for now
						str = strtok(NULL, " \t");	
						if (str && strncmp(str, "lim", strlen("lim")) == 0)
						{
							str = strtok(NULL, " \t");	
							double low = 0;
							double high = 0;
							if (str)
								low = atof(str); // low limit of joint
							str = strtok(NULL, " \t");	
							if (str)
								high = atof(str); // high limit of joint

							if (strncmp(str, "XPos", strlen("XPos")) == 0)
								cur->setLimits(0, low, high);
							else if (strncmp(str, "YPos", strlen("YPos")) == 0)
								cur->setLimits(1, low, high);
							else if (strncmp(str, "ZPos", strlen("ZPos")) == 0)
								cur->setLimits(2, low, high);
						}					
					}
				
					
					state = 3;
				}
				if (str && (strncmp(str, "JOINT", strlen("JOINT")) == 0 || strncmp(str, "joint", strlen("joint")) == 0))
				{
					str = strtok(NULL, "");
					if (str != NULL)
					{
						char trimmedname[512];
						trim(str, trimmedname);
						// prepend the charactername
						std::stringstream strstr;
						strstr << c->getName() << "_" << trimmedname;
						CharJoint* joint = new CharJoint(strstr.str().c_str());
						dance::AllGenericPlugins->add(joint);
						CharJoint* top = stack.top();
						dance::connectionManager->makeConnection(top, "jointchild", joint);
						cur = joint;
						//cout << "Found joint " << str << endl;
						state = 2;
					}
				}
				if (str != NULL && (strncmp(str, "}", strlen("}"))) == 0)
				{					
					stack.pop();
					state = 3;
				}
				if (str && (strncmp(str, "END", strlen("END")) == 0 || strncmp(str, "end", strlen("end")) == 0))
				{
					state = 10;
					danceInterp::OutputMessage("Finished parsing skeleton.");
					metaFile.close();
					c->recalculateJointList();
					c->calculateMatrices(0);	
				}	
				break;
			
			case 9: // found 'MOTION', looking for 'Frames'
				danceInterp::OutputMessage("Finished parsing skeleton.");
				metaFile.close();
				c->recalculateJointList();
				c->calculateMatrices(0);	
				state = 10;
			default:
				break;
		}
	}	

	metaFile.close();

	while(!dataFile.eof() && dataFile.good())
	{
		dataFile.getline(line, 8192, '\n');
                // remove any trailing \r
                if (line[strlen(line) - 1] == '\r')
                        line[strlen(line) - 1] = '\0';
		if (strlen(line) == 0) // ignore blank lines
			continue;

		switch (state)
		{
			case 10:
				if (line && line[0] == '#') // ignore comment lines
					break;
				if (line != NULL && (strncmp(line, "SkMotion", strlen("SkMotion")) == 0 || strncmp(line, "SKMOTION", strlen("SKMOTION")) == 0))
				{
					state = 11;
				}
				else
				{
					danceInterp::OutputMessage("SkMotion not found...\n");
					dataFile.close();
					return c;
				}
				break;
			case 11:
				str = strtok(line, " \t");	
				if (str != NULL && (strncmp(str, "name", strlen("name")) == 0 || strncmp(str, "NAME", strlen("NAME")) == 0))
				{
					std::string characterName = c->getName();
					str = strtok(NULL, " \t");
					if (str)
					{
						danceInterp::OutputMessage("Character name from .skm file is %s.", str);
						StringAttribute* nameAttr = dynamic_cast<StringAttribute*>(c->getAttribute("namefromfile"));
						if (nameAttr)
							nameAttr->setValue(str);
					}
					else
					{
						danceInterp::OutputMessage("Character name from no name found in .skm file.", characterName.c_str(), str);
					}
					state = 12;
				}
				else
				{
					danceInterp::OutputMessage("No character name found...\n");
					dataFile.close();
					return c;
				}
				break;
			case 12:
				str = strtok(line, " \t");	
				if (str != NULL && (strncmp(str, "channels", strlen("channels")) == 0 || strncmp(str, "CHANNELS", strlen("CHANNELS")) == 0))
				{
					str = strtok(NULL, " \t");
					if (str)
					{
						numSkmChannels = atoi(str);						
					}
					else
					{
						danceInterp::OutputMessage("No number of channels found...\n");
						dataFile.close();
						return c;
					}
					state = 13;
				}
				break;
			case 13:
				str = strtok(line, " \t");	
				if (str != NULL && (strncmp(str, "frames", strlen("frames")) == 0 || strncmp(str, "FRAMES", strlen("FRAMES")) == 0))
				{
					str = strtok(NULL, " \t");
					numFrames = atoi(str);
					danceInterp::OutputMessage("Found %d frames of animation...\n", numFrames);
					state = 14;
					break;
				}
				else
				{
					// set up a map between the channels in this .skm file and the channels on the skeleton
					// since an skm file might not apply to all channels	
					std::stringstream strstr;
					strstr << c->getName() << "_" << str;
					CharJoint* joint = c->getJointByName((char*) strstr.str().c_str());
					std::string jointName = str;
					if (!joint)
					{
						danceInterp::OutputMessage("Joint named %s was not found. Will ignore these channels.", str);
					}
					// get the joint's channels
					int channels[6];
					int numChannels = 0;
					if (joint)
						numChannels = joint->getChannels(channels);

					str = strtok(NULL, " \t"); // channel descriptor
					if (!str)
					{
						danceInterp::OutputMessage("Joint %s missing channel descriptor, ignoring...", jointName.c_str());						
						break;
					}

					int channelIndex = -1;
					if (!joint) // joint is not present, indicate which channels to skip
					{
						if (str != NULL && 
						(strncmp(str, "XPos", strlen("XPos")) == 0 || strncmp(str, "XPOS", strlen("XPOS")) == 0))
						{
							channelMap.push_back(-1);
						}
						else if (str != NULL && 
						(strncmp(str, "YPos", strlen("YPos")) == 0 || strncmp(str, "YPOS", strlen("YPOS")) == 0))
						{
							channelMap.push_back(-1);
						}
						else if (str != NULL && 
						(strncmp(str, "ZPos", strlen("ZPos")) == 0 || strncmp(str, "ZPOS", strlen("ZPOS")) == 0))
						{
							channelMap.push_back(-1);
						}
						else if (str != NULL && (strncmp(str, "Quat", strlen("Quat")) == 0 || strncmp(str, "QUAT", strlen("QUAT")) == 0))
						{
							channelMap.push_back(-1);
							channelMap.push_back(-1);
							channelMap.push_back(-1);
						}
						break;
					}


					bool isQuat = false;
					if (str != NULL && 
						(strncmp(str, "XPos", strlen("XPos")) == 0 || strncmp(str, "XPOS", strlen("XPOS")) == 0))
					{
						for (int c = 0; c < numChannels; c++)
							if (channels[c] == CharJoint::XPOSITION)
							{
								channelIndex = c;
								break;
							}
					}
					else if (str != NULL && 
						(strncmp(str, "YPos", strlen("YPos")) == 0 || strncmp(str, "YPOS", strlen("YPOS")) == 0))
					{
						for (int c = 0; c < numChannels; c++)
							if (channels[c] == CharJoint::YPOSITION)
							{
								channelIndex = c;
								break;
							}
					}
					else if (str != NULL && 
						(strncmp(str, "ZPos", strlen("ZPos")) == 0 || strncmp(str, "ZPOS", strlen("ZPOS")) == 0))
					{
						for (int c = 0; c < numChannels; c++)
							if (channels[c] == CharJoint::ZPOSITION)
							{
								channelIndex = c;
								break;
							}

					}
					else if (str != NULL && (strncmp(str, "Quat", strlen("Quat")) == 0 || strncmp(str, "QUAT", strlen("QUAT")) == 0))
					{
						isQuat = true;
						bool foundX = false;
						bool foundY = false;
						bool foundZ = false;
						int firstRotChannel = 0;
						for (int c = 0; c < numChannels; c++)
						{
							if (channels[c] == CharJoint::XROTATION)
							{
								foundX = true;
								firstRotChannel = c;
							}
							else if (channels[c] == CharJoint::YROTATION)
							{
								foundY = true;
							}
							else if (channels[c] == CharJoint::ZROTATION)
							{
								foundZ = true;
							}
						}
						if (foundX && foundY && foundZ)
						{
							channelIndex = firstRotChannel;
							
						}
					}
					if (channelIndex == -1)
					{
						if (str != NULL)
						{
							danceInterp::OutputMessage("Warning: skeleton %s at joint %s does not have the channels %s. Possible mismatch between the .sk and .skm file.", c->getName(), jointName.c_str(), str);
						}
						else
						{
							danceInterp::OutputMessage("Warning: skeleton %s at joint %s does not have the proper channels. Possible mismatch between the .sk and .skm file.", c->getName(), jointName.c_str());
						}
						state = 50;
						break;
					}

					// now we know the joint and the dof, so create a mapping between the channel number and that index
					int map = c->getIndex(joint, channelIndex);
					channelMap.push_back(map);
					if (isQuat) 
					{
						channelMap.push_back(map + 1);
						channelMap.push_back(map + 2);
 					}

				}
				state = 13;
				break;
		
			case 14: // parsing 
				origLine = line;
				str = strtok(line, " \t");	
				numRootFrames = c->getRoot()->getNumFrames();
				parsedFrame = false;
				if (str != NULL && (strncmp(str, "kt", strlen("kt")) == 0))
				{
					str = strtok(NULL, " \t");
					if (!str)
					{
						danceInterp::OutputMessage("Frame %d missing data, ignoring...", curFrame);
						break;
					}
					if (curFrame == 1)
						lastFrameTime = frameTime;
					frameTime = atof(str);
					curFrame++;
					if (curFrame == 1)
					{
						float frameDiff = frameTime - lastFrameTime;
						if (c->getRoot())
						{
							c->getRoot()->setFrameTime(frameDiff);
						}
					}

					parsedFrame = true;
					
					str = strtok(NULL, " \t");

					if (!str || (strncmp(str, "fr", strlen("fr")) != 0))
					{
						danceInterp::OutputMessage("Frame %d missing frame indicator 'fr', ignoring...", curFrame);
						break;
					}

					// parse the channel data
					if( (curFrame <= N2) && (curFrame >= N1))
					{
						if (curFrame >= numFrames)
						{
							danceInterp::OutputMessage("Exceeding number of frames indicated (%d)", numFrames);
							break;
						}
						
						int jointIndex = 0;
						CharJoint* curJoint = NULL;
						CharJoint* lastJoint = NULL;
						double frames[6] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
						int channels[6];
						int dataIndex = 0;

						str = strtok(NULL, " \t");
						
						int curIndex = 0;
						// clean up any line feeds or carriage returns
						while (str != NULL && str[0] != 13)
						{
							if (curIndex >= channelMap.size())
							{
								// more data on line than indicated via channel list
								int numExcessData = 0;
								do 
								{
									numExcessData++;
									str = strtok(NULL, " \t");
								}
								while (str != NULL && str[0] != 13);
									
								danceInterp::OutputMessage("Excessive channel data from indices %d to %d", curIndex, curIndex + numExcessData);
								break;
							}
							// where does this data go?
							int characterIndex = channelMap[curIndex];
							if (characterIndex == -1) // we ignore those channels that were not found in the .sk definition
							{
								curIndex++;
								str = strtok(NULL, " \t");
								continue;
							}
							int dof = -1;
							curJoint = c->getCharJoint(characterIndex, dof);
							if (curJoint == NULL)
							{
								danceInterp::OutputMessage("Can't find joint at index %d. Skipping...");
								break;
							}
							curJoint->getChannels(channels);
							// at this point, we are assigning the next set of data
							// into curJoint at channel number 'dof'
							// flush the data to the curJoint
							if (lastJoint && (curJoint != lastJoint))
							{
								lastJoint->addFrame(frames);

								for (int f = 0; f < 6; f++)
									frames[f] = 0.0;
								lastJoint = curJoint;
							}
													
							double val = atof(str);

							if (channels[dof] == CharJoint::XPOSITION ||
								channels[dof] == CharJoint::YPOSITION ||
								channels[dof] == CharJoint::ZPOSITION)
							{
								frames[dof] = val;
								curIndex++;
							}
							// if the current dof is an xyz rotation, then we are
							// gathering data in order to complete a quaternion
							else if (channels[dof] == CharJoint::XROTATION &&
								channels[dof + 1] == CharJoint::YROTATION &&
								channels[dof + 2] == CharJoint::ZROTATION) 
							{
								Vector axis;
								axis[0] = val;
								str = strtok(NULL, " \t");
								if (str) 
									axis[1] = atof(str);
								str = strtok(NULL, " \t");
								if (str)
									axis[2] = atof(str);
								
								double angle = VecLength(axis);
								VecNormalize(axis);

								Quaternion q;
								q.setAxisAngle(axis, angle);
								// convert to XYZ euler angles
								Matrix3x3 mat;

								q.normalize();
								q.toMatrix(mat);
								VectorObj angles;
								mat.matToEuler(Matrix3x3::XYZ, angles, false);
								frames[dof] = angles.x() * 180.0 / M_PI;
								frames[dof + 1] = angles.y() * 180.0 / M_PI;
								frames[dof + 2] = angles.z() * 180.0 / M_PI;
								curIndex += 3;

							} 
						
							str = strtok(NULL, " \t");
							lastJoint = curJoint;
							
						} // end while loop for parsing motion values

						// flush the data to the curJoint
						if (curJoint)
							curJoint->addFrame(frames);

						state = 14;
		
					}

					// make sure that the root gets some frame
					if (parsedFrame)
					{
						int numRootFramesAfterParse = c->getRoot()->getNumFrames();
						if (numRootFramesAfterParse == numRootFrames)
						{
							// add a dummy frame to the root
							double dummyFrame[6] = {0, 0, 0, 0, 0, 0};
							c->getRoot()->addFrame(dummyFrame);
						}
					}

					state = 14;
					break;
				}

				if (line != NULL && (strncmp(line, "ready", strlen("ready")) == 0 || strncmp(line, "READY", strlen("READY")) == 0))
				{
					std::vector<std::string>& parameters = c->getParameters();
					parameters.push_back(origLine);
					state = 14;
					break;
				}
				if (line != NULL && (strncmp(line, "strokeStart", strlen("strokeStart")) == 0 || strncmp(line, "STROKESTART", strlen("STROKESTART")) == 0))
				{
					std::vector<std::string>& parameters = c->getParameters();
					parameters.push_back(origLine);
					state = 14;
					break;
				}
				if (line != NULL && (strncmp(line, "emphasis", strlen("emphasis")) == 0 || strncmp(line, "EMPHASIS", strlen("EMPHASIS")) == 0))
				{
					std::vector<std::string>& parameters = c->getParameters();
					parameters.push_back(origLine);
					state = 14;
					break;
				}
				if (line != NULL && (strncmp(line, "stroke", strlen("stroke")) == 0 || strncmp(line, "STROKE", strlen("STROKE")) == 0))
				{
					std::vector<std::string>& parameters = c->getParameters();
					parameters.push_back(origLine);
					state = 14;
					break;
				}
				if (str != NULL && (strncmp(str, "relax", strlen("relax")) == 0 || strncmp(str, "RELAX", strlen("RELAX")) == 0))
				{
					std::vector<std::string>& parameters = c->getParameters();
					parameters.push_back(origLine);
					state = 14;
					break;
				}

				curFrame++;
				

				break;

			
			case 50:
				danceInterp::OutputMessage("Finished parsing motion with %d frames...", numFrames);
				metaFile.close();
				c->recalculateJointList();
				c->calculateMatrices(0);	

				return c;
			default:
				cerr << "State " << state << " not expected..." << endl;
				metaFile.close();
				return c;
		}
	}
	return c;
}
