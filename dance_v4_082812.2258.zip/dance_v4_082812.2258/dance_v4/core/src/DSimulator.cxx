/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "defs.h"
#include "dance.h"
#include "danceInterp.h"
#include "DSimulator.h"
#include "DActuator.h"
#include "MonitorPoints.h"
#include "DSimulatorManager.h"
#include "float.h"
#include "PlugIn.h"

#include <cassert>

using namespace std;

void DSimulatorEvent::Execute(double time) 
{ 
	if( time >= this->GetTime() )
	{
		char *s= GetScript() ;
		//danceInterp::OutputMessage("Executing event at time %lf \"%s\"", time, s) ;
		danceInterp::ExecuteCommand(s); 
	}
}

void DSimulator::NotImpl(const char *func) 
{
    danceInterp::OutputMessage("Function %s not implemented for %s.", func, getName()) ;
    return ;
}

DSimulator::DSimulator() : PlugIn()
{
    setBaseType("simulator") ;
    m_ignoreBaseFlag = FALSE ;
    m_initActuatorsFlag = TRUE ;
    m_initSystemsFlag = TRUE ;
	setKinematicControl(false);
	setActive(true);

	dance::AllSimulators->addSimStepCB(this, -1, this->simstep);
	dance::AllSimulators->addSimStartCB(this, -1, this->simstart);
	dance::AllSimulators->addSimStopCB(this, -1, this->simstop);
	dance::AllSimulators->addRecordStateCB(this, -1, recordstate);
	danceInterp::OutputMessage("Created a base simulator...");
	setName("tempName") ;

	this->setUseMainTimeStep(true);
	this->setTimeStep(dance::AllSimulators->getSimulationTimeStep());
}

DSimulator::~DSimulator()
{
	m_simEvents.clear() ;
}

void DSimulator::saveSystemState(double time)
{
}


void DSimulator::addSystem(DSystem *sys)
{
	if (!sys)
	{
		danceInterp::OutputMessage("Cannot add NULL system.") ;
		return ;
	}

	// make sure this system is not already present in the list
	for (int x = 0; x < m_systems.size(); x++)
	{
		DSystem* system = (DSystem*) m_systems.get(x);
		if (system == sys)
		{
			danceInterp::OutputMessage("System %s was already found in system list.", sys->getName());
			return;
		}
	}

	m_systems.add(sys);
	sys->addSimulator(this);
	this->addDependency(sys);
	danceInterp::OutputMessage("System %s was added to simulator %s's list.", sys->getName(), this->getName());

	return;
}

void DSimulator::removeSystem(DSystem *sys)
{
	if (!sys)
	{
		danceInterp::OutputMessage("Cannot remove NULL system.") ;
		return ;
	}

	// make sure this system is not already present in the list
	for (int x = 0; x < m_systems.size(); x++)
	{
		DSystem* system = (DSystem*) m_systems.get(x);
		if (system == sys)
		{
			m_systems.remove(x);
			danceInterp::OutputMessage("System %s was erased from simulator %s's list.", sys->getName(), this->getName());
			return;
		}
	}

	danceInterp::OutputMessage("Could not find %s in simulator %s's list.", sys->getName(), this->getName());
}

int DSimulator::getNumSystems()
{
	return m_systems.size();
}

DSystem* DSimulator::getSystem(int index)
{
	return (DSystem*) m_systems.get(index);
}

int DSimulator::commandPlugIn(int argc, char **argv)
{

	int ret = PlugIn::commandPlugIn(argc, argv);
    if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

    DSystem *sys;
    // check simulator base class commands
    if (strcmp(argv[0],"system") == 0 || strcmp(argv[0],"apply") == 0)
	{
		if (argc != 2)
		{
			danceInterp::OutputMessage("USAGE: apply <system name>") ;
			return DANCE_ERROR;
	    }
		sys = (DSystem *) dance::AllSystems->get(argv[1]);
		if (sys)
		{
			this->addSystem(sys);
			sys->addSimulator(this);
			danceInterp::OutputMessage("Simulator %s now simulates system %s.", this->getName(), sys->getName());
		}
		else
		{
			danceInterp::OutputMessage("Error: System %s not found\n", argv[1]);
		}
		return DANCE_OK ;
	}
    else if( strcmp(argv[0], "remove") == 0	)
    {
		if( argc != 2 )
		{
			danceInterp::OutputMessage("Expected: remove <system name>") ;
			return DANCE_ERROR;
		}
		sys = (DSystem *) dance::AllSystems->get(argv[1]);
		this->removeSystem(sys);
		return DANCE_OK ;
    }
	else if( strcmp(argv[0], "addEvent") == 0 )
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Usage: dance.simulator(\"%s\", addEvent(time, string)", this->getName());
			return DANCE_ERROR;
		}
		double t = atof(argv[1]) ;
		this->AddEvent(t, argv[2]) ;
		return DANCE_OK ;
	}
	else if (strcmp(argv[0], "removeEvent") == 0 )
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.simulator(\"%s\", removeEvent(time, string)", this->getName());
			return DANCE_ERROR;
		}
		this->RemoveEvent(argv[1]) ;
		return DANCE_OK ;
	}
	else if (strcmp(argv[0], "systems") == 0)
	{
		for (int x = 0; x < m_systems.size(); x++)
		{
			DSystem* system = (DSystem*) m_systems.get(x);
			danceInterp::OutputMessage("%s", system->getName());
		}
	}
	else if (strcmp(argv[0], "timestep") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: simulator %s timestep <step>", this->getName());
			return DANCE_ERROR;
		}
		double step = atof(argv[1]);
		this->setTimeStep(step);
		this->setUseMainTimeStep(false);
		danceInterp::OutputMessage("Timestep for simulator %s is now %f. Will be used instead of main simulator's timestep.", this->getName(), step);
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "usetimestep") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: simulator %s usetimestep <true|false>", this->getName());
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "true") == 0)
		{
			this->setUseMainTimeStep(true);
			danceInterp::OutputMessage("Simulator %s will now use timestep from main simulator (currently %f).", this->getName(), dance::AllSimulators->getSimulationTimeStep());
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "false") == 0)
		{
			this->setUseMainTimeStep(false);
			danceInterp::OutputMessage("Simulator %s will now use its own timestep (currently %f).", this->getName(), this->getTimeStep());
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Usage: simulator %s usetimestep <step>", this->getName());
			return DANCE_ERROR;
		}
	}
    return DANCE_CONTINUE;
}

void DSimulator::ApplyActuatorForces(DSystem *sys, double time, double dt, double *state, double *dstate)
{
    for	(int i=0; i < dance::AllActuators->size(); i++)
	{
		DActuator *wact = (DActuator *)dance::AllActuators->get(i);
		wact->ExertLoad(sys, this, time,dt,state,dstate);
    }
}


void DSimulator::setKinematicControl(bool val)
{
	isKinematic = val;
}

bool DSimulator::isKinematicControl()
{
	return isKinematic;
}

void DSimulator::setActive(bool val)
{
	active = val;
}

bool DSimulator::isActive()
{
	return active;
}

void DSimulator::simstep(DObject* data, double time)
{
	DSimulator* sim = (DSimulator*) data;
	sim->ExecuteEvents(time) ;
	sim->Step(NULL, time);
}

void DSimulator::simstart(DObject* data, double time)
{
	DSimulator* sim = (DSimulator*) data;

	// load the state from all the systems
	sim->getStateFromSystem();
	
	// start the simulator
	sim->Start(time);
	
}

void DSimulator::simstop(DObject* data, double time)
{
	DSimulator* sim = (DSimulator*) data;

	// stop the simulator
	sim->Stop();
}

void DSimulator::recordstate(DObject* data, double time)
{
	DSimulator* sim = (DSimulator*) data;

	sim->saveSystemState(time);

}

void DSimulator::getStateFromSystem()
{
}
	
void DSimulator::SetTime(double t)
{
	currentTime = t;
}

double DSimulator::GetTime()
{
	return currentTime;
}

int DSimulator::Step(DSystem *sys, double destinationTime)
{
	return 0;
}

int DSimulator::Start(double time)
{
	return 0;
}

int DSimulator::Stop()
{
	return 0;
}

void DSimulator::checkAttachments()
{
	return;
}

void DSimulator::resetPhysicalProperties(DSystem* system)
{
}

void DSimulator::setTimeStep(double val)
{
	m_timeStep = val;
}

double DSimulator::getTimeStep()
{
	if (this->isUseMainTimeStep())
		return dance::AllSimulators->getSimulationTimeStep();
	else
		return m_timeStep;
}

void DSimulator::setUseMainTimeStep(bool val)
{
	m_useMainTimeStep = val;
}

bool DSimulator::isUseMainTimeStep()
{
	return m_useMainTimeStep;
}

void DSimulator::onDependencyRemoval(DObject* obj)
{
	for (int x = m_systems.size(); x >= 0; x--)
	{
		DSystem* sys = (DSystem*) m_systems.get(x);
		if (sys == obj)
		{
			m_systems.remove(x);
		}
	}
}

void DSimulator::save(int mode, std::ofstream& file)
{
	PlugIn::save(mode, file);

	char buff[512];

	if (mode == 1)
	{
		double timeStep = this->getTimeStep();
		sprintf(buff, "\"timestep\", %f", timeStep);
		pythonSave(file, buff);
		
		if (this->isUseMainTimeStep())
		{
			sprintf(buff, "\"usetimestep\", \"true\"");
			pythonSave(file, buff);
		}
		else
		{
			sprintf(buff, "\"usetimestep\", \"false\"");
			pythonSave(file, buff);
		}
	}
	else if (mode == 2)
	{
		// add any systems
		for (int x = 0; x < this->getNumSystems(); x++)
		{
			DSystem* sys = this->getSystem(x);
			sprintf(buff, "\"system\", \"%s\"", sys->getName());
			pythonSave(file, buff);
		}
	}

}


void DSimulator::getEulerDerivativesFromAngularVelocity(int order, double* omega, double* eulerAngles, double* eulerDerivs)
{ 
	// 3 DOF
	if (order == Matrix3x3::XYZ || order == Matrix3x3::X)
	{
		 eulerDerivs[0] = -(-omega[0]*cos(eulerAngles[1])-sin(eulerAngles[1])*sin(eulerAngles[0])*omega[1]+sin(eulerAngles[1])*cos(eulerAngles[0])*omega[2])/cos(eulerAngles[1]);
		//eulerDerivs[0] = (omega[0]*cos(eulerAngles[1])+sin(eulerAngles[1])*sin(eulerAngles[0])*omega[1]-sin(eulerAngles[1])*cos(eulerAngles[0])*omega[2])/cos(eulerAngles[1]);
		eulerDerivs[1] = cos(eulerAngles[0])*omega[1]+sin(eulerAngles[0])*omega[2];
		eulerDerivs[2] = -(sin(eulerAngles[0])*omega[1]-cos(eulerAngles[0])*omega[2])/cos(eulerAngles[1]);
	}
	else if (order == Matrix3x3::XZY)
	{
		eulerDerivs[0] = (omega[0]*cos(eulerAngles[2])+cos(eulerAngles[0])*sin(eulerAngles[2])*omega[1]+sin(eulerAngles[0])*sin(eulerAngles[2])*omega[2])/cos(eulerAngles[2]);
		eulerDerivs[1] = (cos(eulerAngles[0])*omega[1]+sin(eulerAngles[0])*omega[2])/cos(eulerAngles[2]);
		eulerDerivs[2] = -sin(eulerAngles[0])*omega[1]+cos(eulerAngles[0])*omega[2];
	}
	else if (order == Matrix3x3::YXZ || order == Matrix3x3::Y)
	{
		eulerDerivs[0] = cos(eulerAngles[1])*omega[0]-sin(eulerAngles[1])*omega[2];
		eulerDerivs[1] = (sin(eulerAngles[1])*sin(eulerAngles[0])*omega[0]+cos(eulerAngles[0])*omega[1]+cos(eulerAngles[1])*sin(eulerAngles[0])*omega[2])/cos(eulerAngles[0]);
		eulerDerivs[2] = (sin(eulerAngles[1])*omega[0]+cos(eulerAngles[1])*omega[2])/cos(eulerAngles[0]);
	}
	else if (order == Matrix3x3::YZX)
	{
 
		eulerDerivs[0] =  -(-cos(eulerAngles[1])*omega[0]+sin(eulerAngles[1])*omega[2])/cos(eulerAngles[2]);
		eulerDerivs[1] = (-cos(eulerAngles[1])*sin(eulerAngles[2])*omega[0]+omega[1]*cos(eulerAngles[2])+sin(eulerAngles[1])*sin(eulerAngles[2])*omega[2])/cos(eulerAngles[2]);
		eulerDerivs[2] = sin(eulerAngles[1])*omega[0]+cos(eulerAngles[1])*omega[2];
	}
	else if (order == Matrix3x3::ZXY || order == Matrix3x3::Z)
	{
		eulerDerivs[0] = omega[0]*cos(eulerAngles[2])+sin(eulerAngles[2])*omega[1];
		eulerDerivs[1] = (-sin(eulerAngles[2])*omega[0]+cos(eulerAngles[2])*omega[1])/cos(eulerAngles[0]);
		eulerDerivs[2] = -(-sin(eulerAngles[0])*sin(eulerAngles[2])*omega[0]+sin(eulerAngles[0])*cos(eulerAngles[2])*omega[1]-omega[2]*cos(eulerAngles[0]))/cos(eulerAngles[0]);
	}
	else if (order == Matrix3x3::ZYX)
	{
		eulerDerivs[0] = (omega[0]*cos(eulerAngles[2])+sin(eulerAngles[2])*omega[1])/cos(eulerAngles[1]);
		eulerDerivs[1] = -sin(eulerAngles[2])*omega[0]+cos(eulerAngles[2])*omega[1];
		eulerDerivs[2] = (sin(eulerAngles[1])*cos(eulerAngles[2])*omega[0]+sin(eulerAngles[1])*sin(eulerAngles[2])*omega[1]+omega[2]*cos(eulerAngles[1]))/cos(eulerAngles[1]);
	}
	else if (order == Matrix3x3::XY)
	{
		eulerDerivs[0] = omega[0];
		double cosx = cos(eulerAngles[0]);
 		if (fabs(cosx) > 10e-6)
			eulerDerivs[1] = omega[1] / cosx;
		else
			eulerDerivs[1] = omega[2] / sin(eulerAngles[0]);
	}
	else if (order == Matrix3x3::XZ)
	{
		eulerDerivs[0] = omega[0];
		double cosx = cos(eulerAngles[0]);
 		if (fabs(cosx) > 10e-6)
			eulerDerivs[2] = omega[1] / cosx;
		else
			eulerDerivs[2] = omega[2] / -sin(eulerAngles[0]);
	}
	else if (order == Matrix3x3::YX)
	{
		double cosy = cos(eulerAngles[1]);
 		if (fabs(cosy) > 10e-6)
			eulerDerivs[0] = omega[0] / cosy;
		else
			eulerDerivs[0] = omega[2] / -sin(eulerAngles[1]);
		eulerDerivs[1] = omega[1];
	}
	else if (order == Matrix3x3::YZ)
	{
		eulerDerivs[1] = omega[1];
		double cosy = cos(eulerAngles[1]);
 		if (fabs(cosy) > 10e-6)
			eulerDerivs[2] = omega[2] / cosy;
		else
			eulerDerivs[2] = omega[0] / sin(eulerAngles[1]);
	}
	else if (order == Matrix3x3::ZX)
	{
		double cosz = cos(eulerAngles[2]);
 		if (fabs(cosz) > 10e-6)
			eulerDerivs[0] = omega[0] / cosz;
		else
			eulerDerivs[0] = omega[1] / sin(eulerAngles[2]);
		eulerDerivs[2] = omega[2];
	}
	else if (order == Matrix3x3::ZY)
	{
		double cosz = cos(eulerAngles[2]);
 		if (fabs(cosz) > 10e-6)
			eulerDerivs[1] = omega[1] / cosz;
		else
			eulerDerivs[1] = omega[0] / -sin(eulerAngles[2]);
		eulerDerivs[2] = omega[2];
	}

	// check:
	//Vector check;
	//getAngularVelocityFromEulerDerivatives(order, eulerDerivs, eulerAngles, check);
	//double dist = VecDist(omega, check);
	//if (fabs(dist) > .01)
	//{
	//	danceInterp::OutputMessage("Problem! inconsistent results with order %d (%8.4f, %8.4f, %8.4f) vs. (%8.4f, %8.4f, %8.4f)", order, omega[0], omega[1], omega[2], check[0], check[1], check[2]);
	//}

}

void DSimulator::getAngularVelocityFromEulerDerivatives(int order, double* eulerDerivs, double* eulerAngles, double* omega)
{ 
	if (order == Matrix3x3::XYZ || order == Matrix3x3::X)
	{
		omega[0] = eulerDerivs[0] + sin(eulerAngles[1]) * eulerDerivs[2];
		omega[1] = cos(eulerAngles[0]) * eulerDerivs[1] - sin(eulerAngles[0]) * cos(eulerAngles[1]) * eulerDerivs[2];
		omega[2] = sin(eulerAngles[0]) * eulerDerivs[1] + cos(eulerAngles[0]) * cos(eulerAngles[1]) * eulerDerivs[2];
	}
	else if (order == Matrix3x3::XZY)
	{
		omega[0] = eulerDerivs[0]-sin(eulerAngles[2])*eulerDerivs[1];
		omega[1] = -sin(eulerAngles[0])*eulerDerivs[2]+cos(eulerAngles[0])*cos(eulerAngles[2])*eulerDerivs[1];
		omega[2] = cos(eulerAngles[0])*eulerDerivs[2]+sin(eulerAngles[0])*cos(eulerAngles[2])*eulerDerivs[1];
	}
	else if (order == Matrix3x3::YXZ || order == Matrix3x3::Y)
	{
		omega[0] = cos(eulerAngles[1])*eulerDerivs[0]+sin(eulerAngles[1])*cos(eulerAngles[0])*eulerDerivs[2];
		omega[1] = eulerDerivs[1]-sin(eulerAngles[0])*eulerDerivs[2];
		omega[2] = -sin(eulerAngles[1])*eulerDerivs[0]+cos(eulerAngles[1])*cos(eulerAngles[0])*eulerDerivs[2];
	}
	else if (order == Matrix3x3::YZX)
	{
		omega[0] = sin(eulerAngles[1])*eulerDerivs[2]+cos(eulerAngles[1])*cos(eulerAngles[2])*eulerDerivs[0];
		omega[1] = eulerDerivs[1]+sin(eulerAngles[2])*eulerDerivs[0];
		omega[2] = cos(eulerAngles[1])*eulerDerivs[2]-sin(eulerAngles[1])*cos(eulerAngles[2])*eulerDerivs[0];
	}
	else if (order == Matrix3x3::ZXY || order == Matrix3x3::Z)
	{
		omega[0] = cos(eulerAngles[2])*eulerDerivs[0]-cos(eulerAngles[0])*sin(eulerAngles[2])*eulerDerivs[1];
		omega[1] = sin(eulerAngles[2])*eulerDerivs[0]+cos(eulerAngles[0])*cos(eulerAngles[2])*eulerDerivs[1];
		omega[1] = eulerDerivs[2]+sin(eulerAngles[0])*eulerDerivs[1];
	}
	else if (order == Matrix3x3::ZYX)
	{
		omega[0] = -sin(eulerAngles[2])*eulerDerivs[1]+cos(eulerAngles[1])*cos(eulerAngles[2])*eulerDerivs[0];
		omega[1] = cos(eulerAngles[2])*eulerDerivs[1]+cos(eulerAngles[1])*sin(eulerAngles[2])*eulerDerivs[0];
		omega[2] = eulerDerivs[2]-sin(eulerAngles[1])*eulerDerivs[0];
	}
	else if (order == Matrix3x3::XY)
	{
		omega[0] = eulerDerivs[0];
		omega[1] = cos(eulerAngles[0]) * eulerDerivs[1];
		omega[2] = sin(eulerAngles[0]) * eulerDerivs[1];
	}
	else if (order == Matrix3x3::XZ)
	{
		omega[0] = eulerDerivs[0];
		omega[1] = -sin(eulerAngles[0]) * eulerDerivs[2];
		omega[2] = cos(eulerAngles[0]) * eulerDerivs[2];
	}
	else if (order == Matrix3x3::YX)
	{
		omega[0] = cos(eulerAngles[1]) * eulerDerivs[0];
		omega[1] = eulerDerivs[1];
		omega[2] = -sin(eulerAngles[1]) * eulerDerivs[0];
	}
	else if (order == Matrix3x3::YZ)
	{
		omega[0] = sin(eulerAngles[1]) * eulerDerivs[2];
		omega[1] = eulerDerivs[1];
		omega[2] = cos(eulerAngles[1]) * eulerDerivs[2];
	}
	else if (order == Matrix3x3::ZX)
	{
		omega[0] = cos(eulerAngles[2]) * eulerDerivs[0];
		omega[1] = cos(eulerAngles[1]) * eulerDerivs[2];
		omega[2] = eulerDerivs[1];
	}
	else if (order == Matrix3x3::ZY)
	{
		omega[0] = -sin(eulerAngles[2]) * eulerDerivs[1];
		omega[1] = cos(eulerAngles[2]) * eulerDerivs[1];
		omega[2] = eulerDerivs[2];
	}
}

void DSimulator::accumulateTorques( void )
{
	// To be implemented by subclasses
	assert( false );
}

void DSimulator::acquireTorque( Vector outTorque, int argGroupId /*Joint*/ )
{
	// To be implemented by subclasses
	assert( false );
}

void DSimulator::acquireTorques( std::vector<double>& outTorques /* treated as state space */ )
{
	// To be implemented by subclasses
	assert( false );
}

void DSimulator::zeroTorques( void )
{
	// To be implemented by subclasses
	assert( false );
}

void DSimulator::AddEvent(double t, char *s)
{
	danceInterp::OutputMessage("Event being scheduled at time %lf", t) ;
	DSimulatorEvent* e = new DSimulatorEvent(t,s) ;
	this->m_simEvents.push_back(e) ;
}

/// Loop through all the events and call their execute function
/// Events will be executed continuously unless removed
void DSimulator::ExecuteEvents(double t)
{
	std::vector<DSimulatorEvent *>::iterator iter ;
	for(  iter = m_simEvents.begin(); iter != m_simEvents.end(); ++iter)
	{
		(*iter)->Execute(t) ;
	}
}
void DSimulator::RemoveEvent(char *s)
{
	vector<DSimulatorEvent *>::iterator iter ;
	for(  iter = m_simEvents.begin(); iter != m_simEvents.end(); ++iter)
	{
		if( strcmp(s, (*iter)->GetScript()) == 0 )
		{
			DSimulatorEvent *e = *iter ;
			m_simEvents.erase(iter) ;
			delete e ;
			break ;
		}
	}
	
}
