#ifndef DCONNECTION_INFO_H
#define DCONNECTION_INFO_H

class DLLENRY DConnectionInfo
{
	DConnectionInfo();
	~DConnectionInfo();

};
#endif