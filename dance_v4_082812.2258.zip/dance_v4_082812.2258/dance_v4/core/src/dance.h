/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_DANCE_H_
#define	_DANCE_H_ 

#ifdef _DEBUG
#define _CRTDBG_MAP_ALLOC
#include <cstdlib>
#include <crtdbg.h>
#endif

#include "defs.h"
#include "opengl.h"
#include "DanceWindow.h"
#include "SelectionWindow.h"
#include "ParameterWindow.h"
#include "RootWindow.h"
#include "SimControlWindow.h"
#include "CommandWindow.h"
#include "DMaterialManager.h"
#include "DRendererManager.h"
#include "EventManager.h"
#include "DAttributeManager.h"
#include "DSelectionManager.h"

#include <cstdio>
#include <vector>
#include <map>
#include <string>
class DObject;
class DObjectList;
class PlugInManager;
class DSimulatorManager;
class DConnectionManager;
class DView ;
class ViewManager ;
class BoundingBox;

class DLLENTRY DObject;
#ifdef WIN32
template class DLLENTRY std::allocator<DObject*>;
template class DLLENTRY std::vector<DObject*>;
#endif


class DLLENTRY dance
{
	public:

		// DANCE Object access methods
		static DObjectList **DanceLists;
		static int numDanceLists;
	    static void	getLists(int *number, DObjectList ***list);
	    static DObjectList *getList(const char *listname);
		static DObject* getObject(char* name);

		static DObjectList* AllGenericPlugins;
		static DObjectList* AllActuators;
		static DObjectList* AllLights;
		static DObjectList* AllSystems;
		static DObjectList* AllGeometry;
		static DObjectList* AllModifiers;
		static DRendererManager* AllRenderers;
		static ViewManager* AllViews;
		static DSimulatorManager* AllSimulators;
		static DMaterialManager* MaterialManager;
		static PlugInManager* AllPlugIns;
		static EventManager* eventManager;
		static DConnectionManager* connectionManager;
		static DSelectionManager* selectionManager;

		// instance creation, deletion and renaming
	    static DObject* getInstance(char* type, char* name, int argc, char** argv);
		static bool removeObject(DObject* obj);
		static bool rename(DObject* obj, char* name);
		static void DeleteAll();

		// Mouse and keyboard interaction methods
		static void addInteraction(DObject* obj);
		static void removeInteraction(DObject* obj);
		static DObject* getInteraction(int num);
		static int getNumInteractions();
		static bool isInInteractStack(DObject* obj);

		// DANCE environment control
		static void Refresh() ;
		static void resetAll();
		static void loadProfile();
		static void clear();
		static bool save(char* filename);
		static void quit();
		static void reloadScripts(const char *scriptsDir);

		static double CursorPosn[3];
	    static int FitviewAlways;
	    static BoundingBox *GetSceneBox(bool selected = false);

		static void CheckError(const char *mes);
	    static void	initialize(int argc, char **argv);
		static RootWindow* rootWindow;
		
		static void	IdleCB();

		static char* getCurrentSaveDirectory();
		static char* getTemporaryWorkDirectory();

		static void loadPreferences();
		static void writePreferences();

		static float shadowAlpha ;
		static bool NoOutput ;
		static std::string getVersion();
		static std::string getMajorVersion();
		static std::string getMinorVersion();

		static std::string convertPathToAbsolutePath(std::string path);
		static std::string convertPathToRelativePath(std::string path);
		
		static const char* getDanceDir();
		static void setDanceDir(const char* directory);

	private:
		static void mainLoop();
		static void reloadScriptsByDir(const char *scriptsDir, const char* parentStr);

		static char initScript[1024];
		static std::vector<DObject*> interactStack;
		static std::string saveDir;
		static std::string tempDir;
		static std::string danceDir;

};




#endif



