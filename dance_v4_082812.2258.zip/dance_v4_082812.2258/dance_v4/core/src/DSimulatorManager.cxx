/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include <cstdlib>
#include "dance.h"
#include "danceInterp.h"
#include "DSimulatorManager.h"
#include "DSimulator.h"
#include "DSystem.h"
#include "ViewManager.h"
#include "danceInterp.h"
#include "PlugInManager.h"
#include <fltk/glut.h>

using namespace std;


DSimulator* DSimulatorManager::CurrentSimulator = NULL;

DSimulatorManager::DSimulatorManager()
{
	m_stopRequested = FALSE ;
	this->m_CurrentTime = 0.0;
	this->m_SimulationTimeStep = .001;
	this->m_DisplayTimeStep = .01;
	this->m_state = STATE_NOT_RUNNING;
	this->m_mode = MODE_SIMULATION;
	this->m_playbackSpeed = 30;
	this->m_playbackTime = 0.0;
	this->m_playbackEndTime = 0.0;
	m_SimulationTimeStepUsed = 0.01;
	m_EndTime = 1000.0 ;
	m_autoMake = TRUE ;
	m_useBisection = false;
	m_maxDistanceFromTolerance = 0.0;
	m_hasPenetration = false;
	m_savedOnce = false;
	m_checkpointTime = 0.0;
	m_loopPlay = false;

}

// FIXME: This code is redundant - superclass destructor already deletes all dance objects
DSimulatorManager::~DSimulatorManager()
{
		for (int i=0; i	< numDObjects; i++)
			if (DObjects[i]) {
				delete DObjects[i];
				DObjects[i] = NULL;
			}
		numDObjects = 0;
}


/** command parser */
int DSimulatorManager::Command(int argc, char **argv) 
{
   
	return Simul(argc, argv) ;
}

int DSimulatorManager::Simul(int argc, char **argv)
{

    if (argc <= 0) 
    {
	danceInterp::OutputMessage("usage: simul [-setDisplayTimeStep] "
				"[-setCurrentTime] "
				"[-setSimulationTimeStep]"
				"[-setEndTime] "
				"[-setAutoMake] "
				"[-block on|off] "
        "[-bisection on|off] start|stop|pause|cont") ;
	return DANCE_OK ;
    }
    int count = 0 ;
    while( (count < argc) )
    {
	if (strcmp(argv[count],"-setDisplayTimeStep") == 0 ||
        strcmp(argv[count],"setDisplayTimeStep") == 0)
	{
	    count++;
	    if( count < argc )
	    {
			this->setDisplayTimeStep(atof(argv[count]));		
			if (dance::rootWindow->simControlWindow != NULL)
				dance::rootWindow->simControlWindow->updateGUI();
	    }
	    else
	    {
			danceInterp::OutputMessage("error: expected number") ;
			return DANCE_ERROR ;
	    }
		count++ ;
	}
	else if (strcmp(argv[count],"-setEndTime") == 0 ||
             strcmp(argv[count],"setEndTime") == 0)
	{
	    count++ ;
	    if( count < argc )
	    {
			this->setEndTime(atof(argv[count]));
			if (dance::rootWindow->simControlWindow != NULL)
				dance::rootWindow->simControlWindow->updateGUI();
	    }
	    else
	    {
			danceInterp::OutputMessage("error: expected number") ;
			return DANCE_ERROR ;
	    }   
	    count++ ;
	}
	else if (strcmp(argv[count],"-setSimulationTimeStep") == 0 ||
             strcmp(argv[count],"setSimulationTimeStep") == 0)
	{
	    count++ ;
	    if( count < argc )
	    {
			this->setSimulationTimeStep(atof(argv[count]));
			if (dance::rootWindow->simControlWindow != NULL)
				dance::rootWindow->simControlWindow->updateGUI();
	    }
	    else
	    {
			danceInterp::OutputMessage("error: expected number") ;
			return DANCE_ERROR ;
	    }   
	    count++ ;
	}
	else if (strcmp(argv[count],"-setCurrentTime") == 0 ||
             strcmp(argv[count],"setCurrentTime") == 0)
	{
	    
	    count++;
	    if( count < argc )
	    {
			this->setCurrentTime(atof(argv[count]));
			if (dance::rootWindow->simControlWindow != NULL)
				dance::rootWindow->simControlWindow->updateGUI();
		}
	    else
	    {
			danceInterp::OutputMessage("error: expected number") ;
			return DANCE_ERROR ;
	    }   
		count++ ;
	}
	else if (strcmp(argv[count],"-bisection") == 0)
	{
    count++;
    if( count < argc )
    {
      if( strcmp(argv[count], "on") == 0 )
	      m_useBisection = true;
      else if( strcmp(argv[count], "off") == 0 )
	      m_useBisection = false;
      else
      {
        danceInterp::OutputMessage("error: expected on|off") ;
        return DANCE_ERROR ;
      }
    }
    else
    {
      danceInterp::OutputMessage("error: expected on|off") ;
      return DANCE_ERROR ;
    }
    count++ ;
	}
	else if (strcmp(argv[count],"-setAutoMake") == 0)
	{
	    count++;
	    if( count < argc )
	    {
		if( strcmp(argv[count], "on") == 0 )
		    m_autoMake = TRUE;
		else if( strcmp(argv[count], "off") == 0 )
		    m_autoMake = FALSE ;
		else
		{
			danceInterp::OutputMessage("error: expected on|off") ;
			return DANCE_ERROR ;
		}
	    }
	    else
	    {
		danceInterp::OutputMessage("error: expected on|off") ;
		return DANCE_ERROR ;
	    }
		count++ ;
	}
	else
	{
	    danceInterp::OutputMessage("Unknown argument %s", argv[count]) ;
	    return DANCE_ERROR ;
	}

    }
    

    if( count < argc )
    {
	if( strcmp(argv[count], "start") == 0 )
	{
	    if( m_autoMake == 1 )
	    {
			BuildSimulators() ;
	    }
	    dance::AllSimulators->Start() ;
	}
	else if( strcmp(argv[count], "stop") == 0 )
	    dance::AllSimulators->Stop() ;
	else if( strcmp(argv[count], "pause") == 0 )
	    dance::AllSimulators->Pause() ;
	else if( strcmp(argv[count], "cont") == 0 )
	    dance::AllSimulators->Continue() ;
	else
	    danceInterp::OutputMessage("usage: simul [-setDisplayTimeStep] "
				    "[-setCurrentTime] "
				    "[-setSimulationTimeStep]"
				    "[-setEndTime] "
				    "[-block on|off] start|stop|pause|cont") ;
	
    }
    return DANCE_OK ;
}

void DSimulatorManager::SetTime(double currTime, double displayTimeStep)
{
	setCurrentTime(currTime);
	setDisplayTimeStep(displayTimeStep);

	// Set the time for all Simulators
	for (int i = 0; i < numDObjects; i++)
	{
		DSimulator *sim = (DSimulator *)DObjects[i];
		sim->SetTime(currTime);
	}
}

int DSimulatorManager::Step()
{
	int redisplay = 0;

	double currentTime = this->getCurrentTime();
	double endTime = this->getEndTime();
	// stop if we have reached the end time
	if( (currentTime > endTime) )
	{
		this->setCurrentTime(endTime) ;
		danceInterp::OutputMessage("End of simulation at time %lf.", getCurrentTime()) ;
		this->Stop() ;
		return redisplay;
	}

	if (this->m_firstTime)
	{
		this->recordAllStates();
		this->m_firstTime = false;
	}

	// perform callbacks 
	// Before Step
	for (vector<SimCallback*>::iterator iter = cbBeforeSteps.begin(); iter != cbBeforeSteps.end(); iter++)
	{ 
		(*iter)->cb((*iter)->data, currentTime);
	}

	// Step
	for (vector<SimCallback*>::iterator iter = cbSteps.begin(); iter != cbSteps.end(); iter++)
	{ 
		(*iter)->cb((*iter)->data, currentTime);
	}

	// After Step
	for (vector<SimCallback*>::iterator iter = cbAfterSteps.begin(); iter != cbAfterSteps.end(); iter++)
	{ 
		(*iter)->cb((*iter)->data, currentTime);
	}

	// record the system state
	this->recordAllStates();

	// check to see if we should automatically redisplay based on the display time step
	if( (currentTime - this->getLastDisplayTime()) >= this->getDisplayTimeStep())
	{
		this->setLastDisplayTime(currentTime);
		dance::AllViews->postRedisplay();
		redisplay = 1 ;
	}

	// update the time
	this->setCurrentTime(currentTime + this->getSimulationTimeStep());

	// stop if we have reached the end time
	if( (currentTime > endTime) )
	{
		this->setCurrentTime(endTime) ;
		danceInterp::OutputMessage("End of simulation at time %lf.", getCurrentTime()) ;
		this->Stop() ;
		return 0;
	}

	return redisplay;
}

void DSimulatorManager::recordAllStates()
{
	// Record State Callbacks
	for (vector<SimCallback*>::iterator iter = cbRecordStates.begin(); iter != cbRecordStates.end(); iter++)
	{ 
		(*iter)->cb((*iter)->data, this->getCurrentTime());
	}
}

void DSimulatorManager::Start()
{
	if (dance::AllViews->getViewFocus())
		dance::AllViews->getViewFocus()->startFPS();

	// make sure the two time step parameters make sense
	if (this->getDisplayTimeStep() < this->getSimulationTimeStep())
	{
		danceInterp::OutputMessage("Warning: Display time step (%f) less than simulation time step (%f). The simulation time step will be used.", this->getDisplayTimeStep(), this->getSimulationTimeStep()) ;
	}

	if (this->getSimulationTimeStep()  < 1e-16)
	{
		this->setSimulationTimeStep(0.00001);
		danceInterp::OutputMessage("Warning time step too small. Using %f", this->getSimulationTimeStep());
	}

	this->setLastDisplayTime(MINFLOAT);

	this->setSimulationState(STATE_RUNNING);
	danceInterp::OutputMessage("Starting simulation at %f.", dance::AllSimulators->getCurrentTime()) ;

	// Start callback
	for (vector<SimCallback*>::iterator iter = cbSimStarts.begin(); iter != cbSimStarts.end(); iter++)
	{ 
		(*iter)->cb((*iter)->data, this->getCurrentTime());
	}


	this->m_firstTime = true;
	fltk::add_idle((void(*)(void*))dance::IdleCB, (void*) 0);
 }

void DSimulatorManager::Stop()
{
	fltk::remove_idle((void(*)(void*))dance::IdleCB, (void*) 0);
	danceInterp::OutputMessage("Stopping simulation at %f.", dance::AllSimulators->getCurrentTime()) ;
	this->setSimulationState(STATE_NOT_RUNNING);

	dance::AllSimulators->calculatePlaybackEndTime();
	dance::AllSimulators->setPlaybackTime(dance::AllSimulators->getCurrentTime());

	// Stop callback
	for (vector<SimCallback*>::iterator iter = cbSimStops.begin(); iter != cbSimStops.end(); iter++)
	{ 
		(*iter)->cb((*iter)->data, this->getCurrentTime());
	}
	dance::AllSimulators->setSimulationMode(dance::AllSimulators->MODE_PLAYBACK);
}

void DSimulatorManager::end()
{
    danceInterp::OutputMessage("Ending simulation at %f.", dance::AllSimulators->getCurrentTime()) ;
	this->setSimulationState(STATE_NOT_RUNNING);

	// End callback
	for (vector<SimCallback*>::iterator iter = cbSimEnds.begin(); iter != cbSimEnds.end(); iter++)
	{ 
		(*iter)->cb((*iter)->data, this->getCurrentTime());
	}
}



/**
 * <brief description>
 *
 * <full description>
 * @return void 
 */
void DSimulatorManager::Pause()
{
	if( m_state == STATE_RUNNING )
    {
		m_state = STATE_PAUSED ;
		danceInterp::OutputMessage("Simulation paused at %f.", dance::AllSimulators->getCurrentTime()) ;
		fltk::remove_idle((void(*)(void*))dance::IdleCB, (void*) 0);
    }
    else
		danceInterp::OutputMessage("No simulation running. Command ignored.") ;
}

int DSimulatorManager::getSimulationState()
{
	return m_state;
}

void DSimulatorManager::setSimulationState(int val)
{
	m_state = val;
}

int DSimulatorManager::getSimulationMode()
{
	return m_mode;
}

void DSimulatorManager::setSimulationMode(int val)
{
	m_mode = val;
}



/**
 * <brief description>
 *
 * <full description>
 * @param void
 * @return void 
 */
void DSimulatorManager::Continue() 
{
	if (this->getSimulationState() ==  STATE_PAUSED ) 
	{
		this->setSimulationState(STATE_RUNNING);
		danceInterp::OutputMessage("Resuming simulation.") ;
		fltk::add_idle((void(*)(void*))dance::IdleCB, (void*) 0);
	}
    else if (m_state == STATE_NOT_RUNNING)
    {
		danceInterp::OutputMessage("Restarting simulation.") ;
		Start();
    }



}

/**
 * Loops through systems and calls their BuildAndLinkSimulator function
 *
 * Systems may implement the DSystem::BuildAndLinkSimulator function
 * that automatically instatiates the default simulator.
 * @param void
 * @return void
 */
void DSimulatorManager::BuildSimulators()
{
    DObjectList *allSystems = dance::getList("system") ;
    for( int i = 0 ; i < allSystems->size() ; i++ )
	((DSystem *)allSystems->get(i))->BuildAndLinkSimulator() ;
}


void DSimulatorManager::RequestStop()
{ 
	m_stopRequested = TRUE ;
} 

double DSimulatorManager::getCurrentTime()
{
	return m_CurrentTime;
}

void DSimulatorManager::setCurrentTime(double m)
{
	m_CurrentTime = m;

	if (dance::rootWindow->commandWindow != NULL)
	{
		dance::rootWindow->simControlWindow->adjustCurrent();
		if (m_CurrentTime == m_EndTime)
			dance::rootWindow->simControlWindow->buttonPlayback->label("@>");
	}
}

double DSimulatorManager::getDisplayTimeStep()
{
	return m_DisplayTimeStep;
}

void DSimulatorManager::setDisplayTimeStep(double step)
{
	m_DisplayTimeStep = step;
	if (dance::rootWindow->simControlWindow != NULL)
		dance::rootWindow->simControlWindow->updateGUI();
}

void DSimulatorManager::setSimulationTimeStep(double step)
{
	if( step > 0 )
	{
		m_SimulationTimeStep = step;
		if (dance::rootWindow->simControlWindow != NULL)
			dance::rootWindow->simControlWindow->updateGUI();
	}
}

double DSimulatorManager::getSimulationTimeStep()
{
	return m_SimulationTimeStep;
}

void DSimulatorManager::setEndTime(double time)
{
	m_EndTime = time;
	if (dance::rootWindow->simControlWindow != NULL)
		dance::rootWindow->simControlWindow->updateGUI();
}

double DSimulatorManager::getEndTime()
{
	return m_EndTime;
}

double DSimulatorManager::getLastDisplayTime()
{
	return m_lastDisplayTime;
}

void DSimulatorManager::setLastDisplayTime(double t)
{
	m_lastDisplayTime = t;
}

void DSimulatorManager::addSimStepCB(DObject* data, int priority, void (*stepcb)(DObject* data, double time))
{
	SimCallback* c = new SimCallback();
	c->data = data;
	c->priority = priority;
	c->cb = stepcb;

	// insert the callback based on priority
	for (vector<SimCallback*>::iterator iter = this->cbSteps.begin(); iter != this->cbSteps.end(); iter++)
	{
		if ((*iter)->priority > c->priority)
		{
			this->cbSteps.insert(iter, c);
			return;
		}
	}

	// priority is greater than all other priorities currently in callback list
	cbSteps.push_back(c);
}

void DSimulatorManager::addBeforeSimStepCB(DObject* data, int priority, void (*beforestepcb)(DObject* data, double time))
{
	SimCallback* c = new SimCallback();
	c->data = data;
	c->priority = priority;
	c->cb = beforestepcb;

	// insert the callback based on priority
	for (vector<SimCallback*>::iterator iter = this->cbBeforeSteps.begin(); iter != this->cbBeforeSteps.end(); iter++)
	{
		if ((*iter)->priority > c->priority)
		{
			this->cbBeforeSteps.insert(iter, c);
			return;
		}
	}

	// priority is greater than all other priorities currently in callback list
	cbBeforeSteps.push_back(c);
}

void DSimulatorManager::addAfterSimStepCB(DObject* data, int priority, void (*afterstepcb)(DObject* data, double time))
{
	SimCallback* c = new SimCallback();
	c->data = data;
	c->priority = priority;
	c->cb = afterstepcb;

	// insert the callback based on priority
	for (vector<SimCallback*>::iterator iter = this->cbAfterSteps.begin(); iter != this->cbAfterSteps.end(); iter++)
	{
		if ((*iter)->priority > c->priority)
		{
			this->cbAfterSteps.insert(iter, c);
			return;
		}
	}

	// priority is greater than all other priorities currently in callback list
	cbAfterSteps.push_back(c);
}

void DSimulatorManager::addSimStartCB(DObject* data, int priority, void (*simstartcb)(DObject* data, double time))
{
	SimCallback* c = new SimCallback();
	c->data = data;
	c->priority = priority;
	c->cb = simstartcb;

	// insert the callback based on priority
	for (vector<SimCallback*>::iterator iter = this->cbSimStarts.begin(); iter != this->cbSimStarts.end(); iter++)
	{
		if ((*iter)->priority > c->priority)
		{
			this->cbSimStarts.insert(iter, c);
			return;
		}
	}

	// priority is greater than all other priorities currently in callback list
	cbSimStarts.push_back(c);
}

void DSimulatorManager::addSimStopCB(DObject* data, int priority, void (*simstopcb)(DObject* data, double time))
{
	SimCallback* c = new SimCallback();
	c->data = data;
	c->priority = priority;
	c->cb = simstopcb;

	// insert the callback based on priority
	for (vector<SimCallback*>::iterator iter = this->cbSimStops.begin(); iter != this->cbSimStops.end(); iter++)
	{
		if ((*iter)->priority > c->priority)
		{
			this->cbSimStops.insert(iter, c);
			return;
		}
	}

	// priority is greater than all other priorities currently in callback list
	cbSimStops.push_back(c);
}

void DSimulatorManager::addSimEndCB(DObject* data, int priority, void (*simendcb)(DObject* data, double time))
{
	SimCallback* c = new SimCallback();
	c->data = data;
	c->priority = priority;
	c->cb = simendcb;

	// insert the callback based on priority
	for (vector<SimCallback*>::iterator iter = this->cbSimEnds.begin(); iter != this->cbSimEnds.end(); iter++)
	{
		if ((*iter)->priority > c->priority)
		{
			this->cbSimEnds.insert(iter, c);
			return;
		}
	}

	// priority is greater than all other priorities currently in callback list
	cbSimEnds.push_back(c);
}

void DSimulatorManager::addRecordStateCB(DObject* data, int priority, void (*recordstatecb)(DObject* data, double time))
{
	SimCallback* c = new SimCallback();
	c->data = data;
	c->priority = priority;
	c->cb = recordstatecb;

	// insert the callback based on priority
	for (vector<SimCallback*>::iterator iter = this->cbRecordStates.begin(); iter != this->cbRecordStates.end(); iter++)
	{
		if ((*iter)->priority > c->priority)
		{
			this->cbRecordStates.insert(iter, c);
			return;
		}
	}

	// priority is greater than all other priorities currently in callback list
	cbRecordStates.push_back(c);
}


void DSimulatorManager::removeAllCallbacks()
{
	for (unsigned int x = 0; x < cbSteps.size(); x++)
	{
		SimCallback* c = cbSteps[x];
		delete c;
	}
	cbSteps.clear();

	for (unsigned int x = 0; x < cbBeforeSteps.size(); x++)
	{
		SimCallback* c = cbBeforeSteps[x];
		delete c;
	}
	cbBeforeSteps.clear();

	for (unsigned int x = 0; x < cbAfterSteps.size(); x++)
	{
		SimCallback* c = cbAfterSteps[x];
		delete c;
	}
	cbAfterSteps.clear();

	for (unsigned int x = 0; x < cbSimStarts.size(); x++)
	{
		SimCallback* c = cbSimStarts[x];
		delete c;
	}
	cbSimStarts.clear();

	for (unsigned int x = 0; x < cbSimStops.size(); x++)
	{
		SimCallback* c = cbSimStops[x];
		delete c;
	}
	cbSimStops.clear();

	for (unsigned int x = 0; x < cbSimEnds.size(); x++)
	{
		SimCallback* c = cbSimEnds[x];
		delete c;
	}
	cbSimEnds.clear();

	for (unsigned int x = 0; x < cbRecordStates.size(); x++)
	{
		SimCallback* c = cbRecordStates[x];
		delete c;
	}
	cbRecordStates.clear();
}

void DSimulatorManager::removeAllCallbacks(DObject* object)
{
	bool found = true;
	while (found)
	{
		found = false;
		for (vector<SimCallback*>::iterator iter = cbSteps.begin(); iter != cbSteps.end(); iter++)
		{
			if (object == (*iter)->data)
			{
				SimCallback* c = *iter;
				delete c;
				cbSteps.erase(iter);
				found = true;
				break;
			}
		}
	}

	found = true;
	while (found)
	{
		found = false;
		for (vector<SimCallback*>::iterator iter = cbBeforeSteps.begin(); iter != cbBeforeSteps.end(); iter++)
		{
			if (object == (*iter)->data)
			{
				SimCallback* c = *iter;
				delete c;
				cbBeforeSteps.erase(iter);
				found = true;
				break;;
			}
		}
	}

	found = true;
	while (found)
	{
		found = false;	
		for (vector<SimCallback*>::iterator iter = cbAfterSteps.begin(); iter != cbAfterSteps.end(); iter++)
		{
			if (object == (*iter)->data)
			{
				SimCallback* c = *iter;
				delete c;
				cbAfterSteps.erase(iter);
				found = true;
				break;;
			}
		}
	}

	found = true;
	while (found)
	{
		found = false;
		for (vector<SimCallback*>::iterator iter = cbSimStarts.begin(); iter != cbSimStarts.end(); iter++)
		{
			if (object == (*iter)->data)
			{
				SimCallback* c = *iter;
				delete c;
				cbSimStarts.erase(iter);
				found = true;
				break;;
			}
		}
	}

	found = true;
	while (found)
	{
		found = false;
		for (vector<SimCallback*>::iterator iter = cbSimStops.begin(); iter != cbSimStops.end(); iter++)
		{
			if (object == (*iter)->data)
			{
				SimCallback* c = *iter;
				delete c;
				cbSimStops.erase(iter);
				found = true;
				break;;
			}
		}
	}

	found = true;
	while (found)
	{
		found = false;
		for (vector<SimCallback*>::iterator iter = cbSimEnds.begin(); iter != cbSimEnds.end(); iter++)
		{
			if (object == (*iter)->data)
			{
				SimCallback* c = *iter;
				delete c;
				cbSimEnds.erase(iter);
				found = true;
				break;;
			}
		}
	}

	found = true;
	while (found)
	{
		found = false;
		for (vector<SimCallback*>::iterator iter = cbRecordStates.begin(); iter != cbRecordStates.end(); iter++)
		{
			if (object == (*iter)->data)
			{
				SimCallback* c = *iter;
				delete c;
				cbRecordStates.erase(iter);
				found = true;
				break;;
			}
		}
	}
}


void DSimulatorManager::playbackStart()
{
	if (dance::AllViews->getViewFocus())
		dance::AllViews->getViewFocus()->startFPS();

	this->setSimulationMode(MODE_PLAYBACK);

	int numPlaybackSystems = calculatePlaybackEndTime();

	if (numPlaybackSystems == 0)
	{
		danceInterp::OutputMessage("No systems are in playback mode.");
		this->setSimulationMode(MODE_SIMULATION);
		return;
	}

	this->setLastDisplayTime(-this->getDisplayTimeStep());
	this->setSimulationState(STATE_RUNNING);
	dance::rootWindow->simControlWindow->buttonPlayback->label("@||");
	dance::rootWindow->simControlWindow->buttonPlayback->redraw();

	m_timer.reset();
	m_playbackStartCounter = this->m_playbackTime;
	dance::rootWindow->simControlWindow->updateGUI();
	fltk::add_idle((void(*)(void*))dance::IdleCB, (void*) 0);
}

void DSimulatorManager::playbackPause()
{
	fltk::remove_idle((void(*)(void*))dance::IdleCB, (void*) 0);
	this->setSimulationState(STATE_PAUSED);
	dance::rootWindow->simControlWindow->buttonPlayback->label("@>");
	dance::rootWindow->simControlWindow->buttonPlayback->redraw();

}

void DSimulatorManager::playbackContinue()
{
	this->setSimulationState(STATE_RUNNING);
	
	m_timer.reset();
	m_playbackStartCounter = this->m_playbackTime;
	fltk::add_idle((void(*)(void*))dance::IdleCB, (void*) 0);
	dance::rootWindow->simControlWindow->buttonPlayback->label("@||");
	dance::rootWindow->simControlWindow->buttonPlayback->redraw();

}


void DSimulatorManager::playbackStep()
{
	// determine the current playback time
	float elapsedTime = m_timer.getElapsedTime();

	double curPlayTime = elapsedTime * this->m_playbackSpeed / 30.0 + m_playbackStartCounter;

	// advance time by the playback step
	this->setPlaybackTime(curPlayTime);
	if (this->getPlaybackTime() > this->getPlaybackEndTime())
	{
		this->playbackStop();
		if (this->isLoopPlay())
		{
			this->setCurrentTime(0.0);
			this->m_playbackTime = 0.0;
			this->playbackStart();
			return;
		}
	}

	// playback all systems that are interested
	for (int x = 0; x < dance::AllSystems->size(); x++)
	{
		DSystem* system = (DSystem*) dance::AllSystems->get(x);
		if (system->isPlayback())
			system->setState(curPlayTime);
	}
	for (int x = 0; x < dance::AllPlugIns->size(); x++)
	{
		DObject* object = dance::AllPlugIns->get(x);
		DSystem* system = dynamic_cast<DSystem*>(object);
		if (system)
		{
			if (system->isPlayback())
				system->setState(curPlayTime);
		}
		else
		{
			object->setState(curPlayTime);
		}
	}

	// check to see if we should automatically redisplay based on the display time step
	if( (curPlayTime - this->getLastDisplayTime()) >= this->getDisplayTimeStep())
	{
		this->setLastDisplayTime(this->getPlaybackTime());
		dance::Refresh();
	}
	else if (curPlayTime - this->getLastDisplayTime() > .033)
	{ 
		// play at 30 fps regardless
		dance::Refresh();
	}
}


void DSimulatorManager::playbackStop()
{
	fltk::remove_idle((void(*)(void*))dance::IdleCB, (void*) 0);
	this->setSimulationState(STATE_NOT_RUNNING);
	dance::rootWindow->simControlWindow->buttonPlayback->label("@>");
	dance::rootWindow->simControlWindow->buttonPlayback->redraw();
	dance::rootWindow->simControlWindow->updateGUI();
}


double DSimulatorManager::getPlaybackTime()
{
	return m_playbackTime;
}

void DSimulatorManager::setPlaybackTime(double time)
{
 	m_playbackTime = time;
	if (dance::rootWindow->commandWindow != NULL)
	{
		dance::rootWindow->simControlWindow->adjustCurrent();
		if (this->getPlaybackTime() >= this->getPlaybackEndTime())
		{
				dance::rootWindow->simControlWindow->buttonPlayback->label("@>");
				dance::rootWindow->simControlWindow->buttonPlayback->redraw();
		}

	}

	// playback all systems that are interested
	for (int x = 0; x < dance::AllSystems->size(); x++)
	{
		DSystem* system = (DSystem*) dance::AllSystems->get(x);

		if (system->isPlayback())
			system->setState(this->getPlaybackTime());
	}

}

void DSimulatorManager::setNeedSimInit(bool val)
{
	m_needsSimInit = val;
}

bool DSimulatorManager::isNeedsSimInit()
{
	return m_needsSimInit;
}

void DSimulatorManager::setPlaybackSpeed(double step)
{
	m_playbackSpeed = step;
	m_timer.reset();
	m_playbackStartCounter = this->m_playbackTime;

}

double DSimulatorManager::getPlaybackSpeed()
{
	return m_playbackSpeed;
}

double DSimulatorManager::getPlaybackEndTime()
{
	return m_playbackEndTime;
}

void DSimulatorManager::setPlaybackEndTime(double time)
{
	m_playbackEndTime = time;
}

int DSimulatorManager::calculatePlaybackEndTime()
{
	// determine the end time of all systems that are interested
	double endTime = 0.0;
	int numPlaybackSystems = 0;
	for (int x = 0; x < dance::AllSystems->size(); x++)
	{
		DSystem* system = (DSystem*) dance::AllSystems->get(x);
		if (system->isPlayback())
		{
			numPlaybackSystems++;
			if (system->getLastRecordTime() > endTime)
				endTime = system->getLastRecordTime();
		}

	}

	this->setPlaybackEndTime(endTime);

	return numPlaybackSystems;
}

void DSimulatorManager::setLoopPlay(bool val)
{
	this->m_loopPlay = val;

	dance::rootWindow->simControlWindow->updateGUI();
}

bool DSimulatorManager::isLoopPlay()
{
	return this->m_loopPlay;
}

void DSimulatorManager::reset()
{
	this->Stop();
	// erase all stored system info for dynamic systems
	// all systems that are using kinematic control
	// should retain their playback
	for (int x = 0; x < dance::AllSystems->size(); x++)
	{
		DSystem* sys = (DSystem*) dance::AllSystems->get(x);
		if (sys->isRecording())
		{
			// find the associated simulator
			DSimulator* sim = this->findSimulatorForSystem(sys);
			if (sim)
			{
				if (!sim->isKinematicControl()) // kinematic systems should retain their state
				{
					sys->setState(0.0);
					sys->erasePlayback();
					sys->setLastRecordTime(MINFLOAT);
				}
			}
		}
	}
	this->setCurrentTime(0.0);
	this->setSimulationMode(dance::AllSimulators->MODE_PLAYBACK);

	this->calculatePlaybackEndTime();
	this->setPlaybackTime(0.0);
	dance::rootWindow->simControlWindow->adjustCurrent();
	dance::rootWindow->simControlWindow->updateGUI();
}

void DSimulatorManager::removeSimStepCB(DObject* obj)
{
	for (vector<SimCallback*>::iterator iter = this->cbSteps.begin(); iter != this->cbSteps.end(); iter++)
	{
		if ((*iter)->data == obj)
		{
			SimCallback* cb = (*iter);
			this->cbSteps.erase(iter);
			delete cb;

			return;
		}
	}
}


void DSimulatorManager::removeSimStartCB(DObject* object)
{
	for (vector<SimCallback*>::iterator iter = this->cbSimStarts.begin(); iter != this->cbSimStarts.end(); iter++)
	{
		if ((*iter)->data == object)
		{
			SimCallback* cb = (*iter);
			this->cbSimStarts.erase(iter);
			delete cb;

			return;
		}
	}
}

void DSimulatorManager::removeSimStopCB(DObject* object)
{
	for (vector<SimCallback*>::iterator iter = this->cbSimStops.begin(); iter != this->cbSimStops.end(); iter++)
	{
		if ((*iter)->data == object)
		{
			SimCallback* cb = (*iter);
			this->cbSimStops.erase(iter);
			delete cb;

			return;
		}
	}
}

void DSimulatorManager::removeBeforeSimStepCB(DObject* object)
{
	for (vector<SimCallback*>::iterator iter = this->cbBeforeSteps.begin(); iter != this->cbBeforeSteps.end(); iter++)
	{
		if ((*iter)->data == object)
		{
			SimCallback* cb = (*iter);
			this->cbBeforeSteps.erase(iter);
			delete cb;

			return;
		}
	}
}

void DSimulatorManager::removeAfterSimStepCB(DObject* object)
{
	for (vector<SimCallback*>::iterator iter = this->cbAfterSteps.begin(); iter != this->cbAfterSteps.end(); iter++)
	{
		if ((*iter)->data == object)
		{
			SimCallback* cb = (*iter);
			this->cbAfterSteps.erase(iter);
			delete cb;

			return;
		}
	}
}

void DSimulatorManager::removeSimEndCB(DObject* object)
{
	for (vector<SimCallback*>::iterator iter = this->cbSimEnds.begin(); iter != this->cbSimEnds.end(); iter++)
	{
		if ((*iter)->data == object)
		{
			SimCallback* cb = (*iter);
			this->cbSimEnds.erase(iter);
			delete cb;

			return;
		}
	}
}

void DSimulatorManager::removeRecordStateCB(DObject* object)
{
	for (vector<SimCallback*>::iterator iter = this->cbRecordStates.begin(); iter != this->cbRecordStates.end(); iter++)
	{
		if ((*iter)->data == object)
		{
			SimCallback* cb = (*iter);
			this->cbRecordStates.erase(iter);
			delete cb;

			return;
		}
	}
}

DSimulator*	DSimulatorManager::findSimulatorForSystem(DSystem* system)
{
	for (int s = 0; s < this->size(); s++)
	{
		DSimulator* sim = (DSimulator*) this->get(s);
		for (int i = 0; i < sim->getNumSystems(); i++)
		{
			DSystem* sys = sim->getSystem(i);
			if (sys == system)
				return sim;
		}
	}

	// no simulator found
	return NULL;
}
