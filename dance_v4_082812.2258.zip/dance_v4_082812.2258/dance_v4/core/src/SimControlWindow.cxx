/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "SimControlWindow.h"
#include "dance.h"
#include "DSimulatorManager.h"
#include "ViewManager.h"
#include <fltk/AlignGroup.h>
#include <fltk/PackedGroup.h>
#include <fltk/BarGroup.h>
#include <fltk/TiledGroup.h>
#include <fltk/InvisibleBox.h>
#include <fltk/ask.h>

using namespace fltk;

#define SIMULATE_PLAY_COLOR		fltk::GRAY50
#define SIMULATE_PAUSE_COLOR	fltk::GRAY50
#define SIMULATE_STOP_COLOR		fltk::WHITE
#define PLAYBACK_PLAY_COLOR		fltk::WHITE
#define PLAYBACK_PAUSE_COLOR	fltk::WHITE
#define PLAYBACK_STOP_COLOR		fltk::WHITE

SimControlWindow::SimControlWindow(int x, int y, int w, int h, const char* name) : Group(x, y, w, h, name)
{
	this->box(fltk::UP_BOX);
	this->begin();

	int curX = 5;
	int curY = 10;

	slider = new ValueSlider(curX, curY, w - 20, 25); 
	slider->box(fltk::UP_BOX);
	slider->type(Slider::TICK_ABOVE);
	slider->callback(current_time_cb,this);
	slider->value(0.0);
	slider->step(.001);
	slider->range(0.0, 100.0);
	slider->align(fltk::ALIGN_BOTTOM);
	slider->deactivate();


	fltk::Widget* label1 = new Widget(30, curY + 25, 60, 20, "Simulator");
	label1->color(fltk::GRAY75);
	label1->box(fltk::NO_BOX);

	fltk::Widget* label2 = new Widget(190, curY + 25, 60, 20, "Playback");
	label2->color(fltk::GRAY75);
	label2->box(fltk::NO_BOX);

	curY += 45;

	buttonSimPlay = new Button(curX, curY, 30, 30, "@>");
	buttonSimPlay->set_vertical();
	buttonSimPlay->callback(run_cb,this);

	curX += 35;
	buttonSimStop = new Button(curX, curY, 30, 30, "@square");
	buttonSimStop->callback(stop_cb,this);
	buttonSimStop->set_vertical();

	curX += 35;
	buttonSimReset = new Button(curX, curY, 30, 30,"Reset");
	buttonSimReset->callback(reset_cb,this);
	buttonSimReset->set_vertical();

	curX += 60;
	buttonPlaybackRewind = new Button(curX, curY, 30, 30, "@<<");
	buttonPlaybackRewind->callback(playbackrewind_cb, this);
	buttonPlaybackRewind->set_vertical();

	curX += 35;
	buttonPlaybackStepBack = new Button(curX, curY, 30, 30, "@|<");
	buttonPlaybackStepBack->callback(playbackstepback_cb, this);
	buttonPlaybackStepBack->set_vertical();

	curX += 35;
	buttonPlayback = new Button(curX, curY, 30, 30, "@>");
	buttonPlayback->callback(playbackrun_cb, this);
	buttonPlayback->set_vertical();

	curX += 35;
	buttonPlaybackStepForward = new Button(curX, curY, 30, 30, "@>|");
	buttonPlaybackStepForward->callback(playbackstepforward_cb, this);
	buttonPlaybackStepForward->set_vertical();
	
	curX += 35;
	buttonPlaybackFastForward = new Button(curX, curY, 30, 30, "@>>");
	buttonPlaybackFastForward->callback(playbackfastforward_cb, this);
	buttonPlaybackFastForward->set_vertical();

	curX += 130;
	choicePlaybackSpeed = new Choice(curX, curY, 60, 30, "Playback speed");
	choicePlaybackSpeed->callback(playbackspeeed_cb, this);
	choicePlaybackSpeed->add("1");
	choicePlaybackSpeed->add("2");
	choicePlaybackSpeed->add("3");
	choicePlaybackSpeed->add("7.5");
	choicePlaybackSpeed->add("15");
	choicePlaybackSpeed->add("30");
	choicePlaybackSpeed->add("60");
	choicePlaybackSpeed->add("120");
	choicePlaybackSpeed->add("240");

	curX += 65;
	checkLoopPlay = new CheckButton(curX, curY, 60, 30, "Loop");
	checkLoopPlay->callback(loopplay_cb, this);


	curX = 110;
	curY += 35;
	timeStep = new FloatInput(curX, curY, 50, 25, "Simulation Time Step");
	timeStep->value(.001);
	timeStep->callback(sim_step_cb, this);

	curX += 160;
	displayTimeStep = new FloatInput(curX, curY,  50, 25, "Display Time Step");
	displayTimeStep->value(.01);
	displayTimeStep->callback(disp_step_cb, this);
	
	curX += 120;
	inputEndTime = new FloatInput(curX, curY, 50, 25, "End Time"); 
	inputEndTime->value(100.0);
	inputEndTime->callback(end_time_cb, this);

	this->end();

}

void SimControlWindow::updateGUI()
{
	// set the simulation time step
	double simstep = dance::AllSimulators->getSimulationTimeStep();
	timeStep->value(simstep);

	// set the display time step
	double dispstep = dance::AllSimulators->getDisplayTimeStep();
	displayTimeStep->value(dispstep);

	// set the time
	if (dance::AllSimulators->getSimulationMode() == dance::AllSimulators->MODE_PLAYBACK)
		slider->value(dance::AllSimulators->getPlaybackTime());
	else
		slider->value(dance::AllSimulators->getCurrentTime());

	// set the end time

	double endTime = dance::AllSimulators->getEndTime();
	inputEndTime->value(endTime);

	// set the playback time step
	double playspeed = dance::AllSimulators->getPlaybackSpeed();
	if (playspeed == 1.0)
		choicePlaybackSpeed->value(1);
	else if (playspeed == 2.0)
		choicePlaybackSpeed->value(2);
	else if (playspeed == 3.0)
		choicePlaybackSpeed->value(3);
	else if (playspeed == 7.5)
		choicePlaybackSpeed->value(4);
	else if (playspeed == 30)
		choicePlaybackSpeed->value(5);
	else if (playspeed == 60.0)
		choicePlaybackSpeed->value(6);
	else if (playspeed == 120.0)
		choicePlaybackSpeed->value(7);
	else if (playspeed == 240.0)
		choicePlaybackSpeed->value(8);
	else
		danceInterp::OutputMessage("No selection available for playback speed %f", playspeed);

	// check for the simulation state
	if (dance::AllSimulators->getSimulationMode() == dance::AllSimulators->MODE_SIMULATION)
	{
		slider->input.color(SIMULATE_PLAY_COLOR);
		this->enableSimulatorControls();
		if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_RUNNING)
		{
			this->disablePlaybackControls();
			this->buttonSimPlay->label("@||");
			
		}
		else if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_PAUSED)
		{
			slider->input.color(SIMULATE_PAUSE_COLOR);
			this->enablePlaybackControls();
			this->buttonSimPlay->label("@>");
		}
		else if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_NOT_RUNNING)
		{
			slider->input.color(SIMULATE_STOP_COLOR);
			this->enablePlaybackControls();
			this->buttonSimPlay->label("@>");
		}
	}
	else // MODE_PLAYBACK
	{
		this->enablePlaybackControls();
		if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_RUNNING)
		{
			slider->input.color(PLAYBACK_PLAY_COLOR);
			this->disableSimulatorControls();
			this->buttonPlayback->label("@square");
		}
		else if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_PAUSED)
		{
			slider->input.color(PLAYBACK_PAUSE_COLOR);
			this->enableSimulatorControls();
			this->buttonPlayback->label("@>");
			this->slider->activate();
		}
		else if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_NOT_RUNNING)
		{
			slider->input.color(PLAYBACK_STOP_COLOR);
			this->enableSimulatorControls();
			this->buttonPlayback->label("@>");
			this->slider->activate();
		}
	}

	// loop play
	if (dance::AllSimulators->isLoopPlay())
		checkLoopPlay->value(1);
	else
		checkLoopPlay->value(0);
	
}

double SimControlWindow::valuatorCB(double a, SimControlWindow* com)
{
	double v = (double)powf(float(10.0), float(a));
	
	return v;
}


void SimControlWindow::disp_step_cb(Widget* o, void* p)
{
	FloatInput *input = (FloatInput*) o;
	dance::AllSimulators->setDisplayTimeStep(input->fvalue());
}

void SimControlWindow::sim_step_cb(Widget* o, void* p)
{
	FloatInput* input = (FloatInput*) o;
	dance::AllSimulators->setSimulationTimeStep(input->fvalue());
}

void SimControlWindow::playbackspeeed_cb(fltk::Widget* o, void* p)
{
	Choice* choice = (Choice*) o;
	double val = atof(choice->get_item()->label());

	dance::AllSimulators->setPlaybackSpeed(val);
}

void SimControlWindow::run_cb(Widget* o, void* p)
{
	Button* button = (Button*) o;
	SimControlWindow* cWin = (SimControlWindow*) p;

	if (dance::AllSimulators->getSimulationMode() == dance::AllSimulators->MODE_PLAYBACK)
	{
		dance::AllSimulators->setSimulationMode(dance::AllSimulators->MODE_SIMULATION);
		// set the current time to the playback time
		dance::AllSimulators->setCurrentTime(dance::AllSimulators->getPlaybackTime());
	}

	if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_NOT_RUNNING)
	{
		dance::AllSimulators->Start();
		button->label("@||");
		// disable the playback controls
		cWin->disablePlaybackControls();
		cWin->slider->input.color(SIMULATE_PLAY_COLOR);
	}
	else if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_PAUSED)
	{
		dance::AllSimulators->Continue();
		button->label("@||");
		// enable the playback controls
		cWin->enablePlaybackControls();
		cWin->slider->input.color(SIMULATE_PAUSE_COLOR);
	}
	else
	{
		if(dance::AllSimulators->getSimulationState()== dance::AllSimulators->STATE_RUNNING)
		{
			dance::AllSimulators->Pause();
			button->label("@>");
			// enable the playback controls
			cWin->enablePlaybackControls();
			cWin->slider->input.color(SIMULATE_STOP_COLOR);
		}
		else
		{
			dance::AllSimulators->Continue();
			button->label("@||");
			// disable the playback controls
			cWin->disablePlaybackControls();
			cWin->slider->input.color(SIMULATE_PLAY_COLOR);
		}
	}
}

void SimControlWindow::stop_cb(Widget* o, void* p)
{
	SimControlWindow* cWin = (SimControlWindow*) p;
	dance::AllSimulators->Stop();
	dance::AllSimulators->setSimulationMode(dance::AllSimulators->MODE_PLAYBACK);
	dance::AllSimulators->calculatePlaybackEndTime();
	dance::AllSimulators->setPlaybackTime(dance::AllSimulators->getCurrentTime());
	cWin->adjustCurrent();
	cWin->buttonSimPlay->label("@>");
	// enable the playback controls
	cWin->enablePlaybackControls();
	cWin->slider->input.color(SIMULATE_STOP_COLOR);
	dance::AllSimulators->recordAllStates();
	for (int s = 0; s < dance::AllSimulators->size(); s++)
	{
		DSimulator* sim = (DSimulator*) dance::AllSimulators->get(s);
		for (int sys = 0; sys < sim->getNumSystems(); sys++)
		{
			DSystem* system = (DSystem*) sim->getSystem(sys);
			system->setStateModifiedOutsideSimulation(false);
		}
	}
}

void SimControlWindow::reset_cb(Widget* o, void* p)
{
	//SimControlWindow* cWin = (SimControlWindow*) p;
	if (fltk::ask("Are you sure you want to erase all the recorded motion\nand restart the simulation from the current states?"))
		dance::AllSimulators->reset();
	
	dance::AllViews->postRedisplay();
}

void SimControlWindow::end_time_cb(Widget* o, void* p)
{
	FloatInput* inp = dynamic_cast<FloatInput*>(o);
	SimControlWindow* cWin = (SimControlWindow*) p;
	dance::AllSimulators->setEndTime(inp->fvalue());	
	cWin->slider->range(0.0,inp->fvalue());
	danceInterp::OutputMessage("End time value is now %f", inp->fvalue());	
}
void SimControlWindow::current_time_cb(Widget* o, void* p)
{
	ValueSlider *value_slider = (ValueSlider*) o;

	if (dance::AllSimulators->getSimulationMode() == dance::AllSimulators->MODE_SIMULATION)
	{
		dance::AllSimulators->setSimulationMode(dance::AllSimulators->MODE_PLAYBACK);
		dance::AllSimulators->calculatePlaybackEndTime();
	}
	dance::AllSimulators->setPlaybackTime(value_slider->value());

	dance::AllViews->postRedisplay();

	//	danceInterp::OutputMessage("value of m_CurrentTime is %f and value slider is %f",cWin->simul->get_m_CurrentTime(), value_slider->value());
}

void SimControlWindow::adjustCurrent()
{
	if (dance::AllSimulators->getSimulationMode() == dance::AllSimulators->MODE_PLAYBACK)
	{
		slider->value(dance::AllSimulators->getPlaybackTime());
		if (slider->maximum() > dance::AllSimulators->getPlaybackEndTime())
			slider->range(0.0, dance::AllSimulators->getPlaybackEndTime());
	}
	else
	{
		slider->input.value(dance::AllSimulators->getCurrentTime());
		if (slider->maximum() < dance::AllSimulators->getEndTime())
			slider->range(0.0, dance::AllSimulators->getEndTime());
	}
}

void SimControlWindow::playbackrun_cb(Widget* o, void* p)
{
	SimControlWindow* cWin = (SimControlWindow*) p;


	dance::AllSimulators->setSimulationMode(dance::AllSimulators->MODE_PLAYBACK);
	// are we at the end of of the playback period?
	if (dance::AllSimulators->getPlaybackTime() >= dance::AllSimulators->getPlaybackEndTime())
	{
		// stop the playback
		dance::AllSimulators->playbackStop();
		cWin->buttonPlayback->label("@>");
		cWin->slider->input.color(PLAYBACK_STOP_COLOR);
	}
	else
	{
		if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_PAUSED)
		{
			dance::AllSimulators->playbackContinue();
			cWin->buttonPlayback->label("@||");
			cWin->slider->input.color(PLAYBACK_PLAY_COLOR);
		}
		else if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_NOT_RUNNING)
		{
			dance::AllSimulators->playbackStart();
			cWin->buttonPlayback->label("@||");
			cWin->slider->input.color(PLAYBACK_PLAY_COLOR);
		}
		else if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_RUNNING)
		{
			dance::AllSimulators->playbackStop();
			cWin->buttonPlayback->label("@>");
			cWin->slider->input.color(PLAYBACK_STOP_COLOR);
		}
	}
	cWin->updateGUI();
	cWin->adjustCurrent();

}

void SimControlWindow::playbackstepback_cb(Widget* o, void* p)
{
	SimControlWindow* cWin = (SimControlWindow*) p;

	dance::AllSimulators->setSimulationMode(dance::AllSimulators->MODE_PLAYBACK);

	// rewind time by the playback step
	double newtime = dance::AllSimulators->getPlaybackTime() - (1.0 / dance::AllSimulators->getPlaybackSpeed());
	if (newtime < 0.0)
		newtime = 0.0;
	if (newtime > dance::AllSimulators->getPlaybackEndTime())
		newtime = dance::AllSimulators->getPlaybackEndTime();
	dance::AllSimulators->setPlaybackTime(newtime);
	cWin->updateGUI();
	cWin->adjustCurrent();
	dance::AllViews->postRedisplay();
}

void SimControlWindow::playbackrewind_cb(Widget* o, void* p)
{
	SimControlWindow* cWin = (SimControlWindow*) p;

	dance::AllSimulators->setSimulationMode(dance::AllSimulators->MODE_PLAYBACK);

	// rewind time all the way
	dance::AllSimulators->calculatePlaybackEndTime();
	dance::AllSimulators->setPlaybackTime(0.0);
	dance::rootWindow->simControlWindow->buttonPlayback->label("@>");
	cWin->updateGUI();
	cWin->adjustCurrent();
	dance::AllViews->postRedisplay();
}

void SimControlWindow::playbackstepforward_cb(Widget* o, void* p)
{
	SimControlWindow* cWin = (SimControlWindow*) p;

	dance::AllSimulators->setSimulationMode(dance::AllSimulators->MODE_PLAYBACK);

	// forward time by the playback step
	double newtime = dance::AllSimulators->getPlaybackTime() + (1.0 / dance::AllSimulators->getPlaybackSpeed());
	if (newtime < 0.0)
		newtime = 0.0;
	if (newtime > dance::AllSimulators->getPlaybackEndTime())
		newtime = dance::AllSimulators->getPlaybackEndTime();
	dance::AllSimulators->setPlaybackTime(newtime);
	cWin->updateGUI();
	cWin->adjustCurrent();
	dance::AllViews->postRedisplay();
}

void SimControlWindow::playbackfastforward_cb(Widget* o, void* p)
{
	SimControlWindow* cWin = (SimControlWindow*) p;

	dance::AllSimulators->setSimulationState(dance::AllSimulators->MODE_PLAYBACK);
	dance::AllSimulators->playbackStop();

	// fast forward time all the way
	dance::AllSimulators->calculatePlaybackEndTime();
	dance::AllSimulators->setPlaybackTime(dance::AllSimulators->getPlaybackEndTime());
	cWin->updateGUI();
	cWin->adjustCurrent();
	dance::AllViews->postRedisplay();
}

void SimControlWindow::enablePlaybackControls()
{
	this->buttonPlayback->activate();
	this->buttonPlaybackFastForward->activate();
	this->buttonPlaybackRewind->activate();
	this->buttonPlaybackStepForward->activate();
	this->buttonPlaybackStepBack->activate();
	this->choicePlaybackSpeed->activate();
	this->slider->color(fltk::GRAY75);
	this->slider->activate();
}


void SimControlWindow::disablePlaybackControls()
{
	this->buttonPlayback->deactivate();
	this->buttonPlaybackFastForward->deactivate();
	this->buttonPlaybackRewind->deactivate();
	this->buttonPlaybackStepForward->deactivate();
	this->buttonPlaybackStepBack->deactivate();
	this->choicePlaybackSpeed->deactivate();
	this->slider->deactivate();
}

void SimControlWindow::enableSimulatorControls()
{
	this->buttonSimPlay->activate();
	this->buttonSimStop->activate();
	this->buttonSimReset->activate();
	this->slider->deactivate();
}


void SimControlWindow::disableSimulatorControls()
{
	this->buttonSimPlay->deactivate();
	this->buttonSimStop->deactivate();
	this->buttonSimReset->deactivate();
	this->slider->activate();
}

void SimControlWindow::loopplay_cb(fltk::Widget* o, void* p)
{
	//SimControlWindow* cWin = (SimControlWindow*) p;
	CheckButton* check = (CheckButton*) o;

	if (check->value())
		dance::AllSimulators->setLoopPlay(true);
	else
		dance::AllSimulators->setLoopPlay(false);

}



