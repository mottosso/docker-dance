/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _MATERIALMANAGER_H
#define _MATERIALMANAGER_H

#include "defs.h"
#include <vector>

#include "Material.h"
#include "DObjectList.h"
#include "imageManager.h"


#define STOCK_FILENAME "/data/materials/stock.txt"

// The material is defined by the system
#define STOCK_MATERIAL 1
// This is a temporal flag!!! It is usually NOT updated. Call 'update_in_use_flag' function to update it
#define IN_USE 2

// This is the flag status for a new material
#define DEFAULT_FLAG_SET 0


// Recognized file formats 
// This is the 'native' way to store materials in DANCE
#define PSEUDO_POVRAY 1
// Wavefront MTL format
#define WAVEFRONT_MTL 2


typedef struct {
	Material mat;
	int flags;    // Use the flags codes defined above
} MaterialCapsule;


class DLLENTRY DMaterialManager
{
public:
	DMaterialManager();
	~DMaterialManager();
	

	// Adds a material to the database. It returns the pointer that should be stored/used by the renderer
	// It returns NULL if the name of the material exists
	Material * addMaterial(Material *p);

	// Retrieves from the database the material which name is -name-
	Material * getMaterialbyName(const char *name);

	// Saves the materials in several formats
	// If saveOnlyInUse==TRUE, then it saves only the materials with its IN_USE flag active
	int save(const char *filename, int format=PSEUDO_POVRAY, bool saveOnlyInUse=false);

	// Loads from a file the state of the manager in several formats
	/* This function returns:
		-2: File not found
		-1: Syntax error in the file
		0: OK

		Those materials that are duplicated are not loaded. If duplicates!=NULL, it returns the names of the
		materials that were skipped.
		Later you can query for the number of actually loaded materials (even when there is an error)
	*/
	int load(char *filename, int format=PSEUDO_POVRAY, std::string *duplicates=NULL);
	
	// Cleans up the database, erasing those materials that are not referenced by the geometry list AND do not belong to the stock. 
	// Returns the number of deleted records
	int cleanup(DObjectList *geometry);
    
	// Removes all the materials from the data structure. Returns the number of objects deleted
	int remove_materials();
	
	// Retrieves the ind-nth material. The index is zero-based
	Material * const getMaterialbyIndex(int ind);

	// Returns the number of materials
	int getNumMaterials();

	// Returns the index of the material which name is --name--, or -1 if the material does not exist
	int getMaterialIndexbyName(char * name);
	// Load the materials from the stock file. This function is equal to --load--, but it sets the materials' STOCK flag 
	int loadStock(char * filename, std::string *duplicates=NULL);

	// Returns the default material
	Material * getDefaultMaterial();

	// Returns a random material
	Material * getRandomMaterial();

	// command interface
	int commandPlugIn(int argc, char** argv);

	ImageManager im;

#ifdef _DEBUG
	void test(fltk::Widget*, void*);
#endif

private:

	std::vector <MaterialCapsule *> pool;

	// Returns the capsule that contains the material m, or NULL if it does not exists
	MaterialCapsule *findCapsule(Material *m);

	// Given a set of geometries, updates the status of the IN_USE flag of the material database
	void update_in_use_flag(DObjectList *geometry);
};

#endif

