/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "dance.h"
#include "danceInterp.h"
#include "ViewManager.h"
#include "ViewWindow.h"
#include "AttributeWindow.h"

using namespace fltk;

ViewWindow::ViewWindow(DView* v, int x, int y, int w, int h, const char *s) : Group(x, y, w, h, s)
{
	view = v;

	this->begin();

	choiceViewType = new Choice(80, 20, 100, 20, "View Type");
	choiceViewType->add("Perspective", 0, ViewTypeCB, this, 0);
	choiceViewType->add("Front", 0, ViewTypeCB, this, 0);
	choiceViewType->add("Right", 0, ViewTypeCB, this, 0);
	choiceViewType->add("Top", 0, ViewTypeCB, this, 0);

	checkShadows = new CheckButton(80, 45, 100, 20, "Shadows");
	checkShadows->callback(ShadowsCB, this);

	checkSolids = new CheckButton(80, 70, 100, 20, "Solids");
	checkSolids->callback(SolidsCB, this);

	checkLights = new CheckButton(80, 95, 100, 20, "Lights");
	checkLights->callback(LightsCB, this);

	buttonDumpScreen = new Button(80, 120, 100, 20, "Dump Screen");
	buttonDumpScreen->callback(DumpScreenCB, this);

	checkDumpContinuous = new CheckButton(200, 145, 100, 20, "Dump continuously");
	checkDumpContinuous->callback(DumpScreenContinuousCB, this);

	colorBackground = new ColorChooser(80, 200, 200, 95, "Background Color");
	colorBackground->callback(BackgroundColorCB, this);

	for (int x = 0; x < 3; x++)
	{
		inputTarget[x] = new FloatInput(80 + 60 * x, 310, 50, 20);
		inputTarget[x]->callback(TargetCB, this);
	}
	inputTarget[0]->label("Target");

	for (int x = 0; x < 3; x++)
	{
		inputCamera[x] = new FloatInput(80 + 60 * x, 340, 50, 20);
		inputCamera[x]->callback(CameraCB, this);
	}
	inputCamera[0]->label("Camera");

	inputDistance = new FloatInput(80, 370, 50, 20, "Distance");
	inputDistance->callback(DistanceCB, this);

	checkStats = new CheckButton(10, 400, 80, 20, "Show camera stats");
	checkStats->callback(CameraStatsCB, this);

	inputNear = new FloatInput(80, 430, 80, 20, "Near");
	inputNear->callback(NearCB, this);
	inputFar = new FloatInput(80, 455, 80, 20, "Far");
	inputFar->callback(FarCB, this);

	// add the attribute list
	AttributeWindow* attr = new AttributeWindow(this->view, 0, 0, 0, 0, "Attributes");
	attr->resize(10, 480, 300, 400);
	attr->show();

	this->end();

	this->updateGUI();
}

void ViewWindow::updateGUI()
{
	// view type
	int viewType = this->view->getProjectionType();
	switch (viewType)
	{
	case DView::VIEW_PERSP:
		this->choiceViewType->value(0);
		break;
	case DView::VIEW_FRONT:
		this->choiceViewType->value(1);
		break;
	case DView::VIEW_RIGHT:
		this->choiceViewType->value(2);
		break;
	case DView::VIEW_TOP:
		this->choiceViewType->value(3);
		break;
	default:
		danceInterp::OutputMessage("Unknown selection: %d", viewType);
	}
	// shadows
	if (view->isShadows())
		checkShadows->value(1);
	else
		checkShadows->value(0);

	// solids
	if (view->isSolids())
		checkSolids->value(1);
	else
		checkSolids->value(0);

	// lights
	if (view->isLights())
		checkLights->value(1);
	else
		checkLights->value(0);

	// dumped?
	if (view->isDumped())
		this->checkDumpContinuous->value(1);
	else
		this->checkDumpContinuous->value(0);

	// background colors
	float color[4];
	view->getBackgroundColor(color);

	// update the target
	double* target = view->getTarget();
	for (int x = 0; x < 3; x++)
		this->inputTarget[x]->value(target[x]);

	// update the camera
	double* camera = view->getCamera();
	for (int x = 0; x < 3; x++)
		this->inputCamera[x]->value(camera[x]);

	if (this->view->isShowStats())
		this->checkStats->value(true);
	else
		this->checkStats->value(false);

	this->inputDistance->value(this->view->getDistance());

	colorBackground->rgb(color[0], color[1], color[2]);

	// near & far
	inputNear->value(this->view->getNear());
	inputFar->value(this->view->getFar());

	dance::AllViews->postRedisplay();
}

void ViewWindow::ShadowsCB(Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;

	if (win->checkShadows->value() == 1)
		win->view->setShadows(true);
	else
		win->view->setShadows(false);

	win->updateGUI();
}

void ViewWindow::SolidsCB(Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;

	if (win->checkSolids->value() == 1)
		win->view->setSolids(true);
	else
		win->view->setSolids(false);

	win->updateGUI();
}


void ViewWindow::LightsCB(Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;

	if (win->checkLights->value() == 1)
		win->view->setLights(true);
	else
		win->view->setLights(false);

	win->updateGUI();
}


void ViewWindow::DumpScreenCB(Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;
	
	win->view->SaveFrame();

	win->updateGUI();
}

void ViewWindow::BackgroundColorCB(Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;
	
	win->view->setBackgroundColor((float) win->colorBackground->r(), (float) win->colorBackground->g(), (float) win->colorBackground->b(), 1.0);

	win->updateGUI();
}

void ViewWindow::DumpScreenContinuousCB(Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;
	CheckButton* check = (CheckButton*) widget;
	
	if (check->value() == 1)
		win->view->setDumped(true);
	else
		win->view->setDumped(false);

	win->updateGUI();
}

void ViewWindow::TargetCB(fltk::Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;

	// set the target
	Vector target;
	for (int x = 0; x < 3; x++)
	{
		target[x] = win->inputTarget[x]->fvalue();
	}

	win->view->setTarget(target);

	win->updateGUI();
}

void ViewWindow::CameraCB(fltk::Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;

	// set the camera
	Vector camera;
	for (int x = 0; x < 3; x++)
	{
		camera[x] = win->inputCamera[x]->fvalue();
	}

	win->view->setCamera(camera);

	win->updateGUI();
}

void ViewWindow::CameraStatsCB(fltk::Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;

	win->view->setShowStats(win->checkStats->value());
	win->view->startFPS();

	win->updateGUI();
}

void ViewWindow::DistanceCB(fltk::Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;

	win->view->setDistance(win->inputDistance->fvalue());

	win->updateGUI();
}

void ViewWindow::ViewTypeCB(fltk::Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;

	int type = win->choiceViewType->value();
	switch (type)
	{
	case 0:
		win->view->setProjectionType(DView::VIEW_PERSP);
		break;
	case 1:
		win->view->setProjectionType(DView::VIEW_FRONT);
		break;
	case 2:
		win->view->setProjectionType(DView::VIEW_RIGHT);
		break;
	case 3:
		win->view->setProjectionType(DView::VIEW_TOP);
		break;
	default:
		danceInterp::OutputMessage("Unknown selection: %d", type);
	}

	win->view->resetCamera();
	win->view->PositionCamera();
	win->view->resetLights();
	dance::AllViews->FitView();
	dance::Refresh();
	
	win->updateGUI();
}

void ViewWindow::NearCB(fltk::Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;

	win->view->setNear(win->inputNear->fvalue());

	win->updateGUI();
}

void ViewWindow::FarCB(fltk::Widget* widget, void* data)
{
	ViewWindow* win = (ViewWindow*) data;

	win->view->setFar(win->inputFar->fvalue());

	win->updateGUI();
}


