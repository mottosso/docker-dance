/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef	_DGEOMETRY_
#define	_DGEOMETRY_

#define	MAX_VER	40
#define	MAX_POINTS_IN_PL   1000	/* maximum number of points in a polygon list */
#define	MAX_ADJ_POL	     50	/* maximum number of polygons shared by	a single vertex	*/
#define	NOT_VALID	    -1

#define GEOMETRY_MESH 1
#define GEOMETRY_SOLID 2
#define GEOMETRY_VERTICES 3

// These should	be moved to their respective subclasses	to hide	information

#include <cstring>
#include <cstdlib>
#include "defs.h"
#include "vector.h"
#include "Ball.h"
#include "CoordSystem.h"
#include "BoundingBox.h"
#include "PlugIn.h"
#include "MonitorPoints.h"
#include "Material.h"

class RAPID_model; // RAPID model for collision detection.
class CompositeGeometry;
class GeometryWindow;

class DLLENTRY DGeometry: public PlugIn {

public:

	DGeometry(); 
	~DGeometry(); 

	RAPID_model *m_RAPIDmodel;

	virtual void getTransMatrix(double matrix[4][4]);
	virtual void setTransMatrix(double matrix[4][4]);

	void setUseTransMatrix(bool val);
	bool useTransMatrix();

	virtual void output(int mode);

	// returns a triangle that corresponds to rapid id
	virtual int GetRapidTriangle(int id, Vector v1, Vector v2, Vector v3) { return -1 ;};

	void getBounds(double dim[3]);
	virtual void displayNormals() { return; };
	void displayLocalAxes();
	INLINE void setTransparency(float transparency) {m_transparency->setValue(transparency);};
	INLINE float getTransparency() { return m_transparency->getValue();};

	virtual void display(int style=0) {} ;
	void displayBoundingBox(float r = 0.0, float g = 1.0, float b = 0.0, float a = 1.0);
	virtual void getEndEffector(Vector p) { fprintf(stderr,"getEndEffector: Not	implemented for	this geometry type\n") ;};

	virtual void setMaterial(Material* m);
	virtual Material* getMaterial();

/*	INLINE void setColor(float r, float g, float b, float a);
	INLINE void getColor(float& r, float& g, float& b, float& a);
*/
	int commandPlugIn(int argc, char **argv);

	virtual void Center(bool changeVertices = false);
	virtual void Rotate(const char *axis, double degrees, int center = 0);
	virtual void Rotate(double x, double y, double z,  int center = 0);
	virtual void Translate(double x, double y, double z, bool relative = false);
	virtual void Scale(double sx, double sy, double sz, int center = 0);
	virtual void getTranslation(Vector trans);
	virtual void getScaling(Vector trans);
	virtual void getRotation(Vector rotations);
	virtual void SetOrigin(Vector orig) { printf("Not implemented for this geometry.\n") ;} ;
	virtual int PrepareCollision() { return DANCE_ERROR ;} ;
	virtual void getCenter(Vector pos);
	virtual void setRotationCenter(Vector axis);
	virtual void getRotationCenter(Vector& axis);

	virtual void getLocalCoord(double local[3], double world[3]);
	virtual void getWorldCoord(double world[3], double local[3]);

	void showMesh();
	void showSolid();
	void showVertices();
	bool isShowMesh();
	bool isShowSolid();
	bool isShowVertices();


	// monitor points routines
	virtual int assignMonitorPoints(int npoints, bool random) ;
	virtual int assignMonitorPoints(int n, Vector	*p) ;
	virtual void getMonitorPoints(double (*m)[4][4], Vector *pts)	;
	virtual int getMonitorPoints(Vector **pts) ;
	virtual int getMonitorPointsPrevPos(Vector **pts) ;
	virtual int getNumMonitorPoints()	{  return m_MonitorPoints.m_NumPoints ; } ;
	virtual void getMonitorPointsPrevPosition(double (*m)[4][4], Vector *pts) ;
   
	MonitorPoints * getMonitorStruct() { return &m_MonitorPoints ;} ;

	int Interact(Event* event);
	int InteractStart(Event* event);
	int InteractEnd(Event* event);

	void displayManipulators();
	void displayAxis(double axis[3], double length, int arrowtype = 0);
	void displayScaleAxis(double axis[3],	double length, int arrowtype);
	void displayRotationalAxis(double axis[3], double length, int arrowtype = 0);


	fltk::Widget* getInterface();
	void save(int mode, std::ofstream& file);

	virtual void applyTransMatrix() {};
	
	void decomposeTransformationMatrix();
	virtual int createMonitorPoints(int numPoints, bool random = false);

	friend class CompositeGeometry;

	void notify(DSubject* subject);

#ifdef _DEBUG
	void write_properties(std::ofstream & file);
#endif

protected:
	static int m_NumGeometry;
	int m_ID;

//	float m_Color[4];
	Material* m_material;
	int	displayStyle;		// Style to draw in.

	MonitorPoints m_MonitorPoints	;
	void DeleteMonitorPoints() ;
	int AllocateMonitorPoints(int n) ;

	double m_transMatrix[4][4];
	Vector m_rotationCenter;
	void calcTransMatrix();

	void setUpShadowMapPass1(void) ;
	void cleanUpAfterShadowMapPass1(void) ;
	void setUpShadowMapPass2(void) { return ;} ;
	void setUpShadowMapPass3(void) ;
	void setUpShadowMapPass4(void) ;

	int m_origX;
	int m_origY;

	bool m_useTransMatrix;
	int m_renderType;

	DoubleAttribute* m_tx;
	DoubleAttribute* m_ty;
	DoubleAttribute* m_tz;
	DoubleAttribute* m_rx;
	DoubleAttribute* m_ry;
	DoubleAttribute* m_rz;
	DoubleAttribute* m_scaleu;
	DoubleAttribute* m_sx;
	DoubleAttribute* m_sy;
	DoubleAttribute* m_sz;
	DoubleAttribute* m_transparency;
	MatrixAttribute* m_matrix;
	

private:
	GeometryWindow* m_geometryWindow;

};

#endif

