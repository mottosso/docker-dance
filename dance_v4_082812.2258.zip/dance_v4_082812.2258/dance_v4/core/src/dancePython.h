/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_DANCEPYTHON_H_
#define	_DANCEPYTHON_H_ 1

#ifdef _DEBUG
 #undef _DEBUG
 #include <python.h>
 #define _DEBUG
 #undef _CRT_MANIFEST_RETAIL
#else
#ifdef __APPLE__
#include <Python/Python.h>
#else
 #include "Python.h"
#endif
#endif


#include "DObjectList.h"
#include <stdarg.h>
#include "CommandWindow.h"
#include <cstring>


class DLLENTRY dancePython {

public:

	// Initialization and clean upr routines
	static int InitPython(int argc, char **argv) ;
	static void CleanUp() ;

	// Utility routines
	static int ExecuteCommand(const char *command) ; // runs and records the command in history and flushes the channels
	static void ExecuteCommandNoRecord(const char *command) ; // runs the command without any recording etc.
	static void OutputMessage(const char *format, ...);
	static void OutputResult(const char *format, ...);
	static void OutputListElement(const char *format, ...);
	static void getHistoryEvent(int n, char *cmd) ;
	static std::string *loadPythonScript(const char *fileName ) ;
	static int load(const char *fname);
	static int  Run(const char *com) ;
	
	static char * getStandardOutputError() ;
	static void DisplayOutput() ;

	static PyObject *  active(PyObject* self, PyObject* args);
	static PyObject *  all(PyObject* self, PyObject* args);
	static PyObject *  instance(PyObject* self, PyObject* args);
	static PyObject *  show(PyObject* self, PyObject* args);
	static PyObject *  exists(PyObject* self, PyObject* args);
	static PyObject *  load(PyObject* self, PyObject* args);
	static PyObject *  Plugin(PyObject* self, PyObject* args);
	static PyObject *  proximity(PyObject* self, PyObject* args);
	static PyObject *  quit(PyObject* self, PyObject* args);
	static PyObject *  remove(PyObject* self, PyObject* args);
	static PyObject *  save(PyObject* self, PyObject* args);
	static PyObject *  simul(PyObject* self, PyObject* args);
	static PyObject *  viewmanager(PyObject* self, PyObject* args);
	static PyObject *  materialmanager(PyObject* self, PyObject* args);
	static PyObject *  queryOS(PyObject* self, PyObject* args);
	static PyObject *  rename(PyObject* self, PyObject* args);
	static PyObject *  chdir(PyObject* self, PyObject* args);

	static PyObject *  echo(PyObject* self, PyObject* args);
	static PyObject *  ls(PyObject* self, PyObject* args);
	static PyObject *  showinterface(PyObject* self, PyObject* args);
	static PyObject *  hideinterface(PyObject* self, PyObject* args);
	static PyObject *  addinteraction(PyObject* self, PyObject* args);
	static PyObject *  removeinteraction(PyObject* self, PyObject* args);
	static PyObject *  dependency(PyObject* self, PyObject* args);
	static PyObject *  setNoOutput(PyObject* self, PyObject* args);
	static PyObject *  reset(PyObject* self, PyObject* args);
	static PyObject *  version(PyObject* self, PyObject* args);
	static PyObject *  danceDir(PyObject * self, PyObject* args) ;
	static PyObject *  checkUI(PyObject * self, PyObject* args) ;


	static PyObject *  system(PyObject * self, PyObject* args) ;
	static PyObject *  actuator(PyObject * self, PyObject* args) ;
	static PyObject *  modifier(PyObject * self, PyObject* args) ;
	static PyObject *  geometry(PyObject * self, PyObject* args) ;
	static PyObject *  simulator(PyObject * self, PyObject* args) ;
	static PyObject *  view(PyObject * self, PyObject* args) ;
	static PyObject *  renderer(PyObject * self, PyObject* args) ;
	static PyObject *  generic(PyObject * self, PyObject* args) ;
	static PyObject *  light(PyObject * self, PyObject* args) ;
	

	static void flush();


	static PyObject *pMainModule ;
	static PyObject *pMainDictionary ;

private:

	static PyObject *result(int code);
	static int GetArguments(PyObject *args, char **&argv) ;

} ;

#endif
