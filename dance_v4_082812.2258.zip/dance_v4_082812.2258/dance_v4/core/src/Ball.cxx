/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/


/***** Ball.c *****/
/* Ken Shoemake, 1993 */
/* Modified by Victor Ng, Jan. 1996 for	OpenGL */
/* Modified by Ari Shapiro, Jul. 2005, encapsulated as C++ class */
#include <math.h>
#ifdef WIN32
#include <windows.h>
#endif
#include <fltk/gl.h>
//#include <GL/glu.h>
#include <cstdio>
#include "Ball.h"

#ifndef	M_PI
#define	M_PI		3.14159265358979323846
#endif

#ifndef	WIN32
#ifndef	sinf
#define	sinf sin
#define	cosf cos
#endif
#endif

#define	LG_NSEGS 4
#define	NSEGS (1<<LG_NSEGS)
#define	RIMCOLOR()    glColor3f(0.0f, 1.0f, 1.0f);
#define	FARCOLOR()    glColor3f(0.8f, 0.5f, 0.0f);
#define	NEARCOLOR()   glColor3f(1.0f, 0.8f, 0.0f);
#define	DRAGCOLOR()   glColor3f(0.0f, 1.0f, 1.0f);
#define	RESCOLOR()    glColor3f(0.8f, 0.0f, 0.0f);

HMatrix	mId = {{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};
float otherAxis[][4] = {{(float)-0.48, (float)0.80, (float)0.36, (float)1.0}};

ArcBall::ArcBall()
{
	this->init();
}

ArcBall::~ArcBall()
{
}

Quat* ArcBall::getQuat()
{
	return &this->qNow;
}


/* Establish reasonable	initial	values for controller. */
void ArcBall::init(float *init_matrix)
{
    int	i;
    this->center = qOne;
    this->radius = 1.0;
    this->vDown	= this->vNow = qOne;
    this->qDown	= this->qNow = qOne;
    for	(i=15; i>=0; i--) {
		if (init_matrix	== NULL) 
			((float *)this->mNow)[i] = ((float *)this->mDown)[i]	= ((float *)mId)[i];
		else 
			((float *)this->mNow)[i] = ((float *)this->mDown)[i]	= init_matrix[i];
		
	}

	// We must also set the qNow quaternion to correspond with the 
	// given initial rotation matrix.
	if (init_matrix) {
		Qt_ToQuat(this->mNow,&(this->qNow));
		this->qDown = this->qNow;
	}

	this->isShowResult = this->isDragging =	false;
    this->axisSet = NoAxes;
    this->sets[CameraAxes] = mId[X]; this->setSizes[CameraAxes]	= 3;
    this->sets[BodyAxes] = this->mDown[X]; this->setSizes[BodyAxes] = 3;
    this->sets[OtherAxes] = otherAxis[X]; this->setSizes[OtherAxes] = 1;
}

/* Set the center and size of the controller. */
void ArcBall::place(HVect center, double radius)
{
    this->center = center;
    this->radius = radius;
}

/* Incorporate new mouse position. */
void ArcBall::mouse(HVect vNow)
{
    this->vNow = vNow;
}

/* Choose a constraint set, or none. */
void ArcBall::useSet(AxisSet axisSet)
{
    if (!this->isDragging)
		this->axisSet = axisSet;
}

/* Set the OtherAxes for constraints. */
void ArcBall::setOtherAxes(HMatrix conAxis)
{
     for (int i=0; i < 4; i++)
	 for (int j=0; j < 4; j++)
		this->userAxes[i][j] = conAxis[i][j];
     this->sets[OtherAxes] = this->userAxes[X];
     this->setSizes[OtherAxes] = 3;
}

/* Begin drawing arc for all drags combined. */
void ArcBall::showResult()
{
    this->isShowResult = true;
}

/* Stop	drawing	arc for	all drags combined. */
void ArcBall::hideResult()
{
    this->isShowResult = false;
}

/* Using vDown,	vNow, dragging,	and axisSet, compute rotation etc. */
void ArcBall::update()
{
    int	setSize	= this->setSizes[this->axisSet];
    HVect *set = (HVect	*)(this->sets[this->axisSet]);
    this->vFrom	= mouseOnSphere(this->vDown, this->center, this->radius);
    this->vTo =	mouseOnSphere(this->vNow, this->center,	this->radius);
    if (this->isDragging)
	{
		if (this->axisSet!=NoAxes)
		{
			this->vFrom	= constrainToAxis(this->vFrom, set[this->axisIndex]);
			this->vTo =	constrainToAxis(this->vTo, set[this->axisIndex]);
		}
		this->qDrag = qt_FromBallPoints(this->vFrom, this->vTo);
		this->qNow = Qt_Mul(this->qDrag, this->qDown);
		}
		else
		{
			if (this->axisSet!=NoAxes)
			{
			this->axisIndex = nearestConstraintAxis(this->vTo, set, setSize);
			}
		}
		qt_ToBallPoints(this->qDown, &this->vrFrom,	&this->vrTo);
		Qt_ToMatrix(Qt_Conj(this->qNow), this->mNow); /* Gives transpose for GL. */
}

/* Return rotation matrix defined by controller	use. */
void ArcBall::value(HMatrix mNow)
{
    int	i;
    for	(i=15; i>=0; i--) ((float *)mNow)[i] = ((float *)this->mNow)[i];
}

void ArcBall::setMatrix(HMatrix mat)
{
    for	(int i = 15; i >= 0; i--) 
		((float *)this->mNow)[i] = ((float *)mat)[i];
}

/* Return quaternion defined by controller use. */
void ArcBall::setQuat(float qNow[4])
{
	qNow[0] = this->qNow.x;
	qNow[1] = this->qNow.y;
	qNow[2] = this->qNow.z;
	qNow[3] = this->qNow.w;
}

/* Begin drag sequence.	*/
void ArcBall::beginDrag()
{
    this->isDragging = true;
    this->vDown	= this->vNow;
}

bool ArcBall::isDrag()
{
	return this->isDragging;
}


/* Begin drag sequence.	*/
void ArcBall::beginDragReset()
{
    int	i;

    this->isDragging = true;
    this->vDown	= this->vNow;

    // Set to Identity
    this->qDown	= this->qNow = qOne;
    for	(i=15; i>=0; i--)
       ((float *)this->mNow)[i]	= ((float *)this->mDown)[i] = ((float *)mId)[i];
}

/* Stop	drag sequence. */
void ArcBall::endDrag()
{
    int	i;
    this->isDragging = false;
    this->qDown	= this->qNow;
    for	(i=15; i>=0; i--)
	((float	*)this->mDown)[i] = ((float *)this->mNow)[i];
}

/* Draw	the controller with all	its arcs. */
void ArcBall::draw()
{
    float r = (float)this->radius;
    float x = this->center.x;
    float y = this->center.y;

	glPushAttrib(GL_LIGHTING_BIT | GL_ENABLE_BIT | GL_CURRENT_BIT);
	glDisable(GL_LIGHTING);

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();

    // Must use	near and far clip planes at -1.0 and 1.0 or
    // risk clipping out the circle and	arcs drawn.
    glOrtho(-1.0,1.0,-1.0,1.0,-1.0,100.0);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glScalef(r,r,r);
    glTranslatef(x/r,y/r,0.0); // Scale	for radius adjustment

    // Allows arcball constraints to be	shown properly over arcball
    glDisable(GL_DEPTH_TEST);

    RIMCOLOR();
    glBegin(GL_LINE_LOOP);
    for	(int i=0; i < 36; i++)
       glVertex3f(cosf((float)i*(float)(2.0*M_PI/36.0)),
		  sinf((float)i*(float)(2.0*M_PI/36.0)),0.0);
    glEnd();

    drawResultArc();
    drawConstraints();
    drawDragArc();

    glEnable(GL_DEPTH_TEST);

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
	glPopAttrib();
    glMatrixMode(GL_MODELVIEW);
}

/* Draw	an arc defined by its ends. */
void ArcBall::drawAnyArc(HVect vFrom, HVect vTo)
{
    int	i;
    HVect pts[NSEGS+1];
    double dot;
    pts[0] = vFrom;
    pts[1] = pts[NSEGS]	= vTo;
    for	(i=0; i<LG_NSEGS; i++) pts[1] =	V3_Bisect(pts[0], pts[1]);
    dot	= 2.0*V3_Dot(pts[0], pts[1]);
    for	(i=2; i<NSEGS; i++) {
	pts[i] = V3_Sub(V3_Scale(pts[i-1], (float)dot),	pts[i-2]);
    }
    glBegin(GL_LINE_STRIP);
    for	(i=0; i<=NSEGS;	i++) {
	   glColor3f((float)i/NSEGS,(float)i/NSEGS,(float)i/NSEGS);
	   glVertex3fv((float *)&pts[i]);
	}
    glEnd();
}

/* Draw	the arc	of a semi-circle defined by its	axis. */
void ArcBall::drawHalfArc(HVect n)
{
    HVect p, m;
    p.z	= 0;
    if (n.z != 1.0) {
	p.x = n.y; p.y = -n.x;
	p = V3_Unit(p);
    } else {
	p.x = 0; p.y = 1;
    }
    m =	V3_Cross(p, n);
    drawAnyArc(p, m);
    drawAnyArc(m, V3_Negate(p));
}

/* Draw	all constraint arcs. */
void ArcBall::drawConstraints()
{
    ConstraintSet set;
    HVect axis;
    int	i, axisI, setSize = this->setSizes[this->axisSet];
    if (this->axisSet==NoAxes) return;
    set	= this->sets[this->axisSet];
    for	(axisI=0; axisI<setSize; axisI++) {
	if (this->axisIndex!=axisI) {
	    if (this->isDragging)	continue;
	    FARCOLOR();
	} else NEARCOLOR();
	axis = *(HVect *)&set[4*axisI];
	if (axis.z==1.0) {
	   glBegin(GL_LINE_LOOP);
	   for (i=0; i < 36; i++)
	      glVertex3f(cosf((float)i*float(2.0*M_PI/36.0)),sinf((float)i*(float)(2.0*M_PI/36.0)),0.0);
	   glEnd();
	} else {
	    drawHalfArc(axis);
	}
    }
}

/* Draw	"rubber	band" arc during dragging. */
void ArcBall::drawDragArc()
{
    DRAGCOLOR();
    if (this->isDragging)	drawAnyArc(this->vFrom,	this->vTo);
}

/* Draw	arc for	result of all drags. */
void ArcBall::drawResultArc()
{
    RESCOLOR();
    if (this->isShowResult)
		drawAnyArc(this->vrFrom, this->vrTo);
}

/* Convert window coordinates to sphere	coordinates. */
HVect ArcBall::mouseOnSphere(HVect mouse, HVect ballCenter, double ballRadius)
{
    HVect ballMouse;
    register double mag;
    ballMouse.x	= (mouse.x - ballCenter.x) / (float)ballRadius;
    ballMouse.y	= (mouse.y - ballCenter.y) / (float)ballRadius;
    mag	= ballMouse.x*ballMouse.x + ballMouse.y*ballMouse.y;
    if (mag > 1.0) {
	register double	scale =	1.0/sqrt(mag);
	ballMouse.x *= (float)scale; ballMouse.y *= (float)scale;
	ballMouse.z = 0.0;
    } else {
	ballMouse.z = (float)sqrt(1 - mag);
    }
    ballMouse.w	= 0.0;
    return (ballMouse);
}

/* Construct a unit quaternion from two	points on unit sphere */
Quat ArcBall::qt_FromBallPoints(HVect from, HVect to)
{
    Quat qu;
    qu.x = from.y*to.z - from.z*to.y;
    qu.y = from.z*to.x - from.x*to.z;
    qu.z = from.x*to.y - from.y*to.x;
    qu.w = from.x*to.x + from.y*to.y + from.z*to.z;
    return (qu);
}

/* Convert a unit quaternion to	two points on unit sphere */
void ArcBall::qt_ToBallPoints(Quat q, HVect *arcFrom, HVect *arcTo)
{
    double s;
    s =	sqrt(q.x*q.x + q.y*q.y);
    if (s == 0.0) {
	*arcFrom = V3_(0.0, 1.0, 0.0);
    } else {
	*arcFrom = V3_((float)(-q.y/s),	(float)(q.x/s),	(float)0.0);
    }
    arcTo->x = q.w*arcFrom->x -	q.z*arcFrom->y;
    arcTo->y = q.w*arcFrom->y +	q.z*arcFrom->x;
    arcTo->z = q.x*arcFrom->y -	q.y*arcFrom->x;
    if (q.w < 0.0) *arcFrom = V3_(-arcFrom->x, -arcFrom->y, 0.0);
}

/* Force sphere	point to be perpendicular to axis. */
HVect ArcBall::constrainToAxis(HVect loose, HVect axis)
{
    HVect onPlane;
    register float norm;
    onPlane = V3_Sub(loose, V3_Scale(axis, V3_Dot(axis,	loose)));
    norm = V3_Norm(onPlane);
    if (norm > 0.0) {
	if (onPlane.z <	0.0) onPlane = V3_Negate(onPlane);
	return ( V3_Scale(onPlane, 1/(float)sqrt(norm))	);
    } /* else drop through */
    if (axis.z == 1) {
	onPlane	= V3_(1.0, 0.0,	0.0);
    } else {
	onPlane	= V3_Unit(V3_(-axis.y, axis.x, 0.0));
    }
    return (onPlane);
}

/* Find	the index of nearest arc of axis set. */
int ArcBall::nearestConstraintAxis(HVect	loose, HVect *axes, int	nAxes)
{
    HVect onPlane;
    register float max,	dot;
    register int i, nearest;
    max	= -1; nearest =	0;
    for	(i=0; i<nAxes; i++) {
	onPlane	= constrainToAxis(loose, axes[i]);
	dot = V3_Dot(onPlane, loose);
	if (dot>max) {
	    max	= dot; nearest = i;
	}
    }
    return (nearest);
}

