/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "defs.h"
#include "danceInterp.h"
#include "PlugIn.h"
#include "DSystem.h"
#include "DObject.h"
#include "DSimulator.h"
#include "DSimulatorManager.h"
#include "dance.h"

using namespace fltk;

DSystem::DSystem() : PlugIn()
{
    setBaseType("system") ;
	setRecording(true);
	setPlayback(true);
	setRecordStep(.033);
	setLastRecordTime(-9999999);
	setStateModifiedOutsideSimulation(true);

	// add a callback to record the state
	// we want to record the state of the system after the simulators
	// have updated the state, so the priority should be > -1
	dance::AllSimulators->addRecordStateCB(this, 100, recordstate);
	dance::AllSimulators->addSimStartCB(this, -1, startsim);
	dance::AllSimulators->addSimEndCB(this, -1, endsim);
}

DSystem::~DSystem()
{
}

int DSystem::commandPlugIn(int argc, char **argv)
{
	int ret = PlugIn::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;
	
	if (strcmp(argv[0], "simulators") == 0)
	{
		for (int x = 0; x < m_simulators.size(); x++)
		{
			DSimulator* simulator = (DSimulator*) m_simulators.get(x);
			danceInterp::OutputMessage("%s", simulator->getName());
		}
	}
	else if (strcmp(argv[0], "simulator") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: system %s simulator <simulator>", this->getName());
			return DANCE_ERROR;
		}
		DSimulator* sim = (DSimulator*) dance::AllSimulators->get(argv[1]);
		if (sim == NULL)
		{
			danceInterp::OutputMessage("No simulator named %s was found.", argv[1]);
			return DANCE_ERROR;
		}

		this->addSimulator(sim);
		danceInterp::OutputMessage("System %s is now using simulator %s.", this->getName(), sim->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "remove_simulator") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: system %s remove_simulator <simulator>", this->getName());
			return DANCE_ERROR;
		}
		DSimulator* sim = (DSimulator*) dance::AllSimulators->get(argv[1]);
		if (sim == NULL)
		{
			danceInterp::OutputMessage("No simulator named %s was found.", argv[1]);
			return DANCE_ERROR;
		}

		this->removeSimulator(sim);
		danceInterp::OutputMessage("System %s is no longer using simulator %s.", this->getName(), sim->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "record") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: system %s record <on|off>", this->getName());
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "on") == 0)
		{
			this->setRecording(true);
			danceInterp::OutputMessage("System %s is now recording state.", this->getName());
		
		}
		else if (strcmp(argv[1], "off") == 0)
		{
			this->setRecording(false);
			danceInterp::OutputMessage("System %s is not recording state.", this->getName());
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "recordstep") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: system %s recordstep <val>", this->getName());
			return DANCE_ERROR;
		}
		double step = atof(argv[1]);
		this->setRecordStep(step);
		danceInterp::OutputMessage("Record step for system %s is now %f", this->getName(), step);
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "playback") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: system %s playback <on|off>", this->getName());
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "on") == 0)
		{
			this->setPlayback(true);
			danceInterp::OutputMessage("System %s is now playing back state.", this->getName());
		
		}
		else if (strcmp(argv[1], "off") == 0)
		{
			this->setPlayback(false);
			danceInterp::OutputMessage("System %s is not playing back state.", this->getName());
		}
		return DANCE_OK;
	}

    
    return DANCE_CONTINUE;
}

void DSystem::addSimulator(DSimulator* sim)
{
	if (!sim)
	{
		danceInterp::OutputMessage("Cannot add NULL simulator.") ;
		return ;
	}

	// make sure this system is not already present in the list
	for (int x = 0; x < m_simulators.size(); x++)
	{
		DSimulator* simulator = (DSimulator*) m_simulators.get(x);
		if (simulator == sim)
		{
			danceInterp::OutputMessage("Simulator %s was already found in system list.", sim->getName());
			return;
		}
	}

	m_simulators.add(sim);

	this->addDependency(sim);

	return;
}

void DSystem::removeSimulator(DSimulator *sim)
{
	if (!sim)
	{
		danceInterp::OutputMessage("Cannot remove NULL simulator.") ;
		return;
	}

	// make sure this system is not already present in the list
	for (int x = 0; x < m_simulators.size(); x++)
	{
		DSimulator* simulator = (DSimulator*) m_simulators.get(x);
		if (simulator == sim)
		{
			m_simulators.remove(x);
			danceInterp::OutputMessage("Simulator %s was erased from system %s's list.", sim->getName(), this->getName());
			return;
		}
	}

	danceInterp::OutputMessage("Could not find %s in system %s's list.", sim->getName(), this->getName());
}

void DSystem::setRecording(bool val)
{
	this->m_isRecording = val;
}

bool DSystem::isRecording()
{
	return this->m_isRecording;
}

void DSystem::setPlayback(bool val)
{
	this->m_isPlayback = val;
}

bool DSystem::isPlayback()
{
	return this->m_isPlayback;
}

int DSystem::getNumSimulators()
{
	return m_simulators.size();
}

DSimulator* DSystem::getSimulator(int index)
{
	return (DSimulator*) m_simulators.get(index);
}

void DSystem::recordState(double time)
{
}

void DSystem::setRecordStep(double step)
{
	m_recordStep = step;
}

double DSystem::getRecordStep()
{
	return m_recordStep;
}

void DSystem::setLastRecordTime(double time)
{
	m_lastRecordTime = time;
}

double DSystem::getLastRecordTime()
{
	return m_lastRecordTime;
}

void DSystem::erasePlayback()
{
	this->setLastRecordTime(-99999);
}

void DSystem::recordstate(DObject* data, double time)
{
	DSystem* sys = (DSystem*) data;

	if (sys->isRecording())
	{
		if (time - sys->getLastRecordTime() >= sys->getRecordStep())
		{
			sys->recordState(time);
			sys->setLastRecordTime(time);
		}
	}
}

void DSystem::startsim(DObject* data, double time)
{
	DSystem* sys = (DSystem*) data;

	sys->startSimulation();
}

void DSystem::endsim(DObject* data, double time)
{
	DSystem* sys = (DSystem*) data;

	sys->endSimulation();
}

Widget* DSystem::getInterface()
{
	return NULL;
}

DCollision** DSystem::getPointCollisionData()
{
	return NULL;
}

int DSystem::getNumPointCollisionData()
{
	return 0;
}

DSphereCollision** DSystem::getSphereCollisionData()
{
	return NULL;
}

int DSystem::getNumSphereCollisionData()
{
	return 0;
}


void DSystem::startSimulation()
{
	// By default, record every simulated frame.
	// Subclasses may want to change to 0.033 for
	// normal video rates.
	this->setRecordStep(dance::AllSimulators->getSimulationTimeStep());
}

void DSystem::endSimulation()
{
}

bool DSystem::isStateModifiedOutsideSimulation()
{
	return m_stateModified;
}

void DSystem::setStateModifiedOutsideSimulation(bool val)
{
	m_stateModified = val;
}


DCollisionHierarchy* DSystem::getPointCollisionHierarchy()
{
	return NULL;
}

DCollisionHierarchy* DSystem::getSphereCollisionHierarchy()
{
	return NULL;
}

void DSystem::save(int mode, std::ofstream& file)
{
	PlugIn::save(mode, file);

	char buff[512];

	if (mode == 0)
	{
	}
	else if (mode == 1)
	{
		// record 
		if (this->isRecording())
		{
			sprintf(buff, "\"record\", \"on\"");
		}
		else
		{
			sprintf(buff, "\"record\", \"off\"");
		}
		pythonSave(file, buff);

		// record step
		sprintf(buff, "\"recordstep\", \"%f\"", this->getRecordStep());
		pythonSave(file, buff);

		// playback 
		if (this->isPlayback())
		{
			sprintf(buff, "\"playback\", \"on\"");
		}
		else
		{
			sprintf(buff, "\"playback\", \"off\"");
		}
		pythonSave(file, buff);

		// simulators
		int numSimulators = this->getNumSimulators();
		for (int x = 0; x < numSimulators; x++)
		{
			DSimulator* sim = this->getSimulator(x);
			sprintf(buff, "\"simulator\", \"%s\"", sim->getName());
			pythonSave(file, buff);
		}

	}

}

void DSystem::onDependencyRemoval(DObject* object)
{
	PlugIn::onDependencyRemoval(object);

	for (int x = 0; x < this->getNumSimulators(); x++)
	{
		if (this->getSimulator(x) == object)
		{
			this->removeSimulator((DSimulator*) object);
			break;
		}
	}
	
}
