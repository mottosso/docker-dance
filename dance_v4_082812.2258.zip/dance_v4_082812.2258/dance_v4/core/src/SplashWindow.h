
#ifndef _SPLASHWINDOW_H
#define _SPLASHWINDOW_H

#include <fltk/Window.h>
#include <fltk/Group.h>
#include <fltk/SharedImage.h>
#include <fltk/Button.h>
#include <vector>
#include <string>

class SplashWindow : public fltk::Window
{
	public:
		SplashWindow(const char* splashImage, int x, int y, int w, int h, const char* name);
		~SplashWindow();
		void draw();

		void setInfo(std::vector<std::string> infoToWrite);
		void setAutoHide(bool val);
		bool isAutoHide();
		void setAutoHideTime(float seconds);
		float getAutoHideTime();
		static void hidesplash(fltk::Widget* widget, void* data);

	private:
		fltk::SharedImage* image;
		fltk::Button* okButton;
		std::vector<std::string> info;
		bool autoHide;
		float autoHideTime;

};

#endif
