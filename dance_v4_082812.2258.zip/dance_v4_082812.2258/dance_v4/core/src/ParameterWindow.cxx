/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "ParameterWindow.h"

#include <fltk/Button.h>
#include <fltk/Input.h>
#include "dance.h"

using namespace fltk;

ParameterWindow::ParameterWindow(int x, int y, int w, int h, const char* name) : Group(x, y, w, h, name)
{
	this->begin();

	buttonFloat = new Button(this->w() - 60, 5, 30, 15, "Float");
	buttonFloat->callback(floatwidget_cb, this);

	buttonRemove = new Button(this->w() - 80, 5, 20, 15, "X");
	buttonRemove->callback(removewidget_cb, this);

	buttonSelect = new Button(this->w() - 130, 5, 50, 15, "Select");
	buttonSelect->callback(selectwidget_cb, this);

	tabGroup = new TabGroup(10, 30, w - 20, h - 60);

	buttonFloat->deactivate();
	buttonRemove->deactivate();

	this->end();
}


void ParameterWindow::addInterface(fltk::Widget* panel, const char* name)
{
	for (int x = 0; x < tabGroup->children(); x++)
	{
		if (panel == tabGroup->child(x))
		{
			tabGroup->selected_child(panel);
			panel->show();
			return;
		}
	}
	panel->x(0);
	panel->y(30);
	panel->w(tabGroup->w());
	panel->h(tabGroup->h()- 40);
	panel->show();
	tabGroup->add(panel);
	tabGroup->layout();
	tabGroup->selected_child(panel);
	tabGroup->redraw();
	panel->show();

	buttonFloat->activate();
	buttonRemove->activate();
}

void ParameterWindow::removeInterface(fltk::Widget* panel)
{
	// remove the interface from the docked area
	for (int x = 0; x < tabGroup->children(); x++)
	{
		if (panel == tabGroup->child(x))
		{
			panel->hide();
			tabGroup->remove(x);
			tabGroup->redraw();	
			if (tabGroup->children() == 0)
			{
				buttonFloat->deactivate();
				buttonRemove->deactivate();
			}
			return;
		}
	}
	// remove the interface from the floating area
	for (std::vector<FloatingParameterWindow*>::iterator iter = floatingWindows.begin(); iter != floatingWindows.end(); iter++)
	{
		if ((*iter)->getWidget() == panel)
		{
			FloatingParameterWindow* floatWindow = (*iter);
			(*iter)->hide();
			floatWindow->removeWidget(panel);
			floatingWindows.erase(iter);
			delete floatWindow;
			break;
		}
	}
}

void ParameterWindow::floatInterface(fltk::Widget* panel)
{
	this->removeInterface(panel);

	// create a new FloatingParameterWindow and place the widgets on it
	FloatingParameterWindow* floatWindow = new FloatingParameterWindow(this, panel->w() + 20, panel->h() + 40, (char*) panel->label());
	floatWindow->setWidget(panel);
	panel->show();
	floatWindow->show();

	floatingWindows.push_back(floatWindow);
}

void ParameterWindow::dockInterface(fltk::Widget* panel)
{
	bool found = false;
	for (std::vector<FloatingParameterWindow*>::iterator iter = floatingWindows.begin(); iter != floatingWindows.end(); iter++)
	{
		if ((*iter)->getWidget() == panel)
		{
			FloatingParameterWindow* floatWindow = (*iter);
			(*iter)->hide();
			floatWindow->removeWidget(panel);
			floatingWindows.erase(iter);
			delete floatWindow;
			found = true;
			break;
		}
	}

	if (found)
		this->addInterface(panel, (char*) panel->label());
}

void ParameterWindow::floatwidget_cb(fltk::Widget* w, void* data)
{
	ParameterWindow* window = (ParameterWindow*) data;

	// get the interface
	Widget* panel = window->tabGroup->selected_child();
	if (panel == NULL)
		return;

	window->floatInterface(panel);
}

void ParameterWindow::removewidget_cb(fltk::Widget* w, void* data)
{
	ParameterWindow* window = (ParameterWindow*) data;

	// get the interface
	Widget* panel = window->tabGroup->selected_child();
	if (panel == NULL)
		return;

	window->removeInterface(panel);
}

void ParameterWindow::selectwidget_cb(fltk::Widget* w, void* data)
{
	dance::rootWindow->selectionWindow->show();
}

int ParameterWindow::getNumTabInterfaces()
{
	return this->tabGroup->children();
}

Widget* ParameterWindow::getTabInterface(int num)
{
	return this->tabGroup->child(num);
}

int ParameterWindow::getNumFloatingInterfaces()
{
	return this->floatingWindows.size();
}

Widget* ParameterWindow::getFloatingInterface(int num)
{
	return this->floatingWindows[num];
}

