/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef CHARACTER_H
#define CHARACTER_H

#include "defs.h"
#include "CharJoint.h"
#include "matrix3x3.h"
#include "PlugIn.h"
#include "DAttribute.h"

//#include "ArticulatedObject.h"
#include <vector>
#include <fstream>
#include <vector>

class CharacterWindow;

class DLLEXPORT Character : public PlugIn
{
	public:
		Character();
		~Character();

		virtual void output(int mode);
		virtual BoundingBox *calcBoundingBox(BoundingBox *box = NULL);
		virtual  fltk::Widget* getInterface();

		void setTime(double time);
		double getTime();

		void setOffsetTime(double offsetTime);
		double getOffsetTime();

		void setRoot(CharJoint* root);
		CharJoint* getRoot();
		void setDrawingType(int type);
		int getDrawingType();
		void draw(double time, bool useInterpolation);
		void drawJoint(double time, CharJoint* joint, bool useInterpolation);
		void drawJoint_bad(double time, CharJoint* joint, bool useInterpolation);

		int getNumDOF();
		int getNumFrames();
		CharJoint* getCharJoint(int index, int &dof);
		int getNumJoints();
		CharJoint* getJointByIndex(int jointNum);
		CharJoint* getJointByName(char* name);
		int getIndex(CharJoint* joint, int dof);
		void setOffset(double x, double y, double z);
		void getOffset(Vector vec);
		void setRotation(double xrot, double yrot, double zrot);
		void getRotation(Vector vec);
		void getRotationMatrix(double matrix[4][4]);
		void setScale(double val);
		double getScale();
		void center();
		Character* copy(char* name);
		Character* copy(char* name, int startFrame, int endFrame);
		void copyFrames(Character* to, int frameNum);
		//void AlignWithPath(int axis, CRSpline3D *p) ;
		void saveBVH(char* filename);
		void saveBVH(std::ofstream& file);
		void saveSKSKM(char* filename, char* filename2, float fps);
		void saveSKSKM(std::ofstream& file, std::ofstream& file2, float fps);
		void saveASFAMC(char* filename, char* filename2);
		void saveASFAMC(std::ofstream& file, std::ofstream& file2);
//		void saveANI(char* filename, ArticulatedObject* skeleton);
		void saveTxt(char* filename, int representation, bool useTranslation, bool useRotation);
		void savePOVRay(char* filename, int start, int finish, int skipframes);

		void getBoundingBox(double time, Vector min, Vector max);
		double getHeight();
		double getWidth();

		bool verify(); // verfies that the character has been created properly

		static const int POINTS = 0;
		static const int ELLIPSES = 1;
		static const int LINES = 2;

		bool isBVH();
		void setIsBVH(bool val);
		bool isPoints();
		void setIsPoints(bool val);

		void compare(Character* c);

		bool isPointsCalculated();
		void setPointsCalculated(bool val);
		void calculatePoints(int frameNum);

		bool isMatrixCalculated();
		void setMatrixCalculated(bool val);
		void calculateMatrices(double time);

		int getCombinedFrame(); // returns the frame at which the motion data was combined with other motion data
		void setCombinedFrame(int frame); 

		void addMotion(Character* c);
		void clearMotion();

		void setBoneWidth(double size);
		double getBoneWidth();
		void setJointSize(double size);
		double getJointSize();
		void setBoneColor(Vector color);
		void getBoneColor(Vector color);
		void setJointColor(Vector color);
		void getJointColor(Vector color);
		void setShowBones(bool val);
		bool isShowBones();
		void setShowJoints(bool val);
		bool isShowJoints();
		void setShowPoints(bool val);
		bool isShowPoints();

		void setAdjustBoneLengths(bool val);
		bool isAdjustBoneLengths();

		void fixBoneLengths(Character* c);

		void recalculateJointList();

		std::vector<std::string>& getParameters();
		std::string getParameter(std::string match);

		void calcWorldTransMatrix();

		void setCycle(bool val);
		bool isCycle();
		void setGlobalOffset(Vector offset);
		void getGlobalOffset(Vector offset);
		void getCycleOffset(Vector offset);

		virtual void notify(DSubject* subject);

		void onConnect(DConnection* connection);
		void onDisconnect(DConnection* connection);

	private:
		void recalculateJointListRecurse(CharJoint* joint);

		void fixBoneLengthsRecurse(std::vector<CharJoint*>* joints, int jointIndex, Vector offset, int frame);
		void calculatePointsRecurse(int frameNum, CharJoint* joint, const double parentMatrix[4][4]);
		void calculateMatricesRecurse(double time, CharJoint* joint);
		CharJoint* getDOFIndexRecurse(CharJoint* joint, int desiredIndex, int &startIndex, int &cur);
		int getNumDOFRecurse(CharJoint* joint);
		void getWorldCoordRecurse(double time, Vector &curPos, CharJoint* node);
		void scaleRecurse(CharJoint* joint, double val);
		void copyRecurse(CharJoint* parent, CharJoint* parentCopy, int startFrame, int endFrame);
		void skMetaRecurse(CharJoint* joint, int level, std::ofstream &file);
		void bvhMetaRecurse(CharJoint* joint, int level, std::ofstream &file);
		void bvhAnimRecurse(CharJoint* joint, std::ofstream &file, int frameNum);
		void indent(int amount, std::ostream& o, int spaces = 0);

		CharJoint* m_root;
		int m_drawType;
		double m_height;
		double m_width;
		bool m_isBVH;
		bool m_isPoints;
		bool m_pointsCalculated;
		bool m_matrixIsCalculated;
		int m_combinedFrame;

	protected:
		BoolAttribute* m_showBones;
		BoolAttribute* m_showJoints;
		BoolAttribute* m_showBonesAsLines;
		Vec3Attribute* m_boneColor;
		Vec3Attribute* m_jointColor;

		DoubleAttribute* m_boneWidth;
		DoubleAttribute* m_jointSize;
		StringAttribute* m_selectedJoint;

		StringAttribute* m_nameFromFile;
		StringAttribute* m_file;
		StringAttribute* m_file2;

		DoubleAttribute* m_desiredTime;
		DoubleAttribute* m_time;

		DoubleAttribute* m_offset[3];
		DoubleAttribute* m_rotation[3];
		DoubleAttribute* m_scale;

		BoolAttribute* m_cycle;
		BoolAttribute* m_useInterpolation;
		DoubleAttribute* m_offsetTime;

		double m_matrixRotation[4][4];

		int whichDataIsWarped;

		bool m_showPoints;
		std::vector<CharJoint*> m_allJoints;
		bool m_adjustBoneLengths;
		std::vector<std::string> m_parameters;
		Vector m_globalOffset;
		Vector m_cycleOffset;
		
		CharacterWindow* m_gui;
};


#endif
