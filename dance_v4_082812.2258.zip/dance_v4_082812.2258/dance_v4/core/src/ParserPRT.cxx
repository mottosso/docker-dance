/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "ParserPRT.h"
#include <iostream>
#include <stack>
#include <stdlib.h>
#include "danceInterp.h"

using namespace std;

Character* ParserPRT::parse(std::string name, std::ifstream &file)
{
	// check to make sure we have properly opened the file
	if (!file.good())
	{
		danceInterp::OutputMessage("Could not open file\n");
		return NULL;
	}
	char line[4096];
	Character* c = new Character();
	c->setName(name.c_str());
	c->setIsBVH(false);
	int state = 0;
	char* str;
	CharJoint* cur = NULL;
	int numFrames = 0;
	int curFrame = -1;
	int numParticles = 0;
	int curParticle = -1;
	CharJoint* root = NULL;
	int channels[6];

	while(!file.eof() && file.good())
	{
		file.getline(line, 4096, '\n');
                if (line[strlen(line) - 1] == '\r')
                        line[strlen(line) - 1] = '\0';

		if (strlen(line) == 0) // ignore blank lines
			continue;
		switch (state)
		{
			case 0:	// looking for number of particles
				str = strtok(line, " \t");	
				numParticles = atoi(str);
				root = new CharJoint("root");
				c->setRoot(root);
				c->setIsPoints(true);
				channels[0] = CharJoint::XPOSITION;
				channels[1] = CharJoint::YPOSITION;
				channels[2] = CharJoint::ZPOSITION;
				channels[3] = CharJoint::XROTATION;
				channels[4] = CharJoint::YROTATION;
				channels[5] = CharJoint::ZROTATION;
				root->setChannels(6, channels);
				c->setShowBones(false);
				c->setShowJoints(false);
				c->setShowPoints(true);
				state = 1;
				break;
			case 1:	// process each particle
				str = strtok(line, " \t");	
				curParticle++;
				char buff[80];
				sprintf(buff, "particle%d", curParticle);
				cur = new CharJoint(buff);
				root->addChild(cur);
				cur->setParent(root);
				channels[0] = CharJoint::XROTATION;
				channels[1] = CharJoint::YROTATION;
				channels[2] = CharJoint::ZROTATION;
				cur->setChannels(3, channels);
				curFrame = -1;
				while (str != NULL)
				{
					double x = atof(str);
					str = strtok(NULL, " \t");
					double y = atof(str);
					str = strtok(NULL, " \t");
					double z = atof(str);

					cur->addFrame(x, y, z);
					curFrame++;
					if (curFrame > numFrames)
						numFrames = curFrame;
					str = strtok(NULL, " \t");
				}
				if (curParticle >= numParticles - 1)
				{
					danceInterp::OutputMessage("Finished parsing motion with %d frames...", numFrames);
					file.close();
					// add some dummy frames to the root
					for (int x = 0; x < numFrames; x++)
						root->addFrame(0.0, 0.0, 0.0);
					c->recalculateJointList();
					return c;
				}
				break;
			default:
				cerr << "State " << state << " not expected..." << endl;
				file.close();
				return c;
		}
	}
	danceInterp::OutputMessage("Finished parsing motion with %d frames...", numFrames);
	file.close();

	return c;
}
