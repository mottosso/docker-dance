/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "defs.h"
#include <iostream>

#include <Magick++.h>

#include "dance.h"
#include "stuff.h"
#include "imageManager.h"

#ifndef WIN32
#define BYTE unsigned char
#endif

ImageManager::ImageManager() {
	
	numRecords=0;
	ddbb= (ImageManagerRecord *)malloc(sizeof(ImageManagerRecord)*CHUNK_SIZE);
	if (ddbb==NULL) 
		maxNumRecords=0;
	else 
		maxNumRecords=CHUNK_SIZE;
}


ImageManager::~ImageManager() {
	int i;

	for (i=0; i<numRecords; i++)
		removeRecord(numRecords-1);
	free(ddbb);
	maxNumRecords=0;
}


// Load a texture and returns it m_tex (opengl id) (refcount depending)
int ImageManager::loadTexture(Texture *tex, char *filename) {
	int m_tex, id;

	id=getIdFromFilename(filename);
	if (id==-1) {
		char thefilename[1024];
		sprintf(thefilename, "%s", filename);
		m_tex=this->makeTextureFromFile(tex, thefilename, false);
		if (m_tex>=0) 
			addRecord(m_tex, filename);
		else
			return -1;
#ifdef _DEBUG
		danceInterp::OutputMessage("Image %s loaded (mtex=%d)", filename, m_tex);
#endif

	} else {
		ddbb[id].refCount++;
		m_tex=ddbb[id].m_tex;
	}

	return m_tex;
}

// Given a texture id, it unloads from memory (refcount depending). 
// Returns: -1 (m_tex does not exists), 0 (texture unloaded), 1 (refcount decreased)
int ImageManager::unLoadTexture(int m_tex) {

	int id = getIdFromMTex(m_tex);
	if (id<0) return -1;

	ddbb[id].refCount--;
	if (ddbb[id].refCount<=0) {
#ifdef _DEBUG
		danceInterp::OutputMessage("Image %s unloaded", ddbb[id].filename);
#endif
		
		glDeleteTextures(1,(const GLuint *)&m_tex);
		removeRecord(id);
		return 0;
	} else 
		return 1;
}


// Add a record to the database. Refcount is set to 1
int ImageManager::addRecord(int m_tex, char *filename) {
	
	if (numRecords+1 >= maxNumRecords) {
		ImageManagerRecord *tmp;

		tmp= (ImageManagerRecord *)realloc(ddbb, sizeof(ImageManagerRecord)*(this->maxNumRecords+CHUNK_SIZE));
		if (tmp==NULL) 
			return DANCE_ERROR;
		ddbb = tmp;
		this->maxNumRecords += CHUNK_SIZE;
	}

	ddbb[numRecords].m_tex=m_tex;
	ddbb[numRecords].filename = strdup(filename);
	ddbb[numRecords].refCount=1;

	numRecords++;

	return DANCE_OK;
}


// Remove a record from the database. It ignores the refcount
int ImageManager::removeRecord(int id) {
	if (id >= numRecords || id<0)
		return DANCE_ERROR;
	

	free(ddbb[id].filename);
	ddbb[id].filename=NULL;
	if (numRecords>1 && id!=numRecords-1)
		ddbb[id]=ddbb[numRecords-1];

	numRecords--;
	return DANCE_OK;
}


// Find a record in the database, given the filename
int ImageManager::getIdFromFilename(char *filename) {
	int i;

	for (i=0; i<this->numRecords; i++) 
		if (!strcmp(filename, ddbb[i].filename))
			return i;

	return -1;
}


// Find a record in the database, given the OpenGL id
int ImageManager::getIdFromMTex(int mtex) {
	int i;

	for (i=0; i<this->numRecords; i++) 
		if (mtex == ddbb[i].m_tex)
			return i;

	return -1;
}


// Returns the OpenGL texture id from filename
int ImageManager::getOpenGlIdFromFilename(char *filename) {
	int i;

	for (i=0; i<this->numRecords; i++)
		if (!strcmp(ddbb[i].filename, filename)) 
			return ddbb[i].m_tex;

	return -1;
}


// Reads an image into memory and read the texture into the graphics card memory. 
// Returns the OpenGL id, or -1 if error
int ImageManager::makeTextureFromFile(Texture *tex, char *fileName, bool make_mipmaps) 
{
	Magick::Image image;
	unsigned char *pixs;
	int depth, m_tex;

	try {
        // Read a file into image object
		image.read(fileName);
		image.flip();
		pixs = (unsigned char *)image.getConstPixels(0,0,image.columns(),image.rows());

		depth=32;
	}
	catch( Magick::Exception &error_ ) {
		danceInterp::OutputMessage("Error reading the file %s: %s\n", fileName, error_.what());
		return -1;
	}
	if ((m_tex=makeGLTexture(tex, make_mipmaps, pixs, image.columns(), image.rows(), depth)) < 0) {
		danceInterp::OutputMessage("Error loading %s", fileName);
		return -1;
	}
	return m_tex;
}




int ImageManager::makeGLTexture(Texture *tex, bool make_mipmaps, unsigned char *imageData, int width, int height, int depth) {

	BYTE* pData=NULL;
	int nerror;
	GLuint m_tex, mag_filter, min_filter, wrap_s, wrap_t, env_mode;

	glGenTextures(1, &m_tex);

	glBindTexture(GL_TEXTURE_2D, m_tex);

	tex->getSettings(&mag_filter, &min_filter, &wrap_s, &wrap_t, &env_mode);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,    mag_filter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, min_filter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrap_s);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrap_t);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, env_mode);

	glPixelStorei(GL_UNPACK_ALIGNMENT,1);

	if(make_mipmaps) {
		nerror=0;
		switch(depth)
		{
			case 8:
				nerror=gluBuild2DMipmaps(GL_TEXTURE_2D, 1, width, height, GL_LUMINANCE, GL_UNSIGNED_BYTE, imageData);
				break;
			case 24:
				nerror=gluBuild2DMipmaps(GL_TEXTURE_2D, 3, width, height, GL_BGR_EXT, GL_UNSIGNED_BYTE, imageData);
				break;
			case 32:
				nerror=gluBuild2DMipmaps(GL_TEXTURE_2D, 4, width, height, GL_BGRA_EXT, GL_UNSIGNED_BYTE, imageData);
				break;
		}
		if (nerror) {
			danceInterp::OutputMessage( (char*)gluErrorString(glGetError()));
			goto error_recovery;
		}
	} else  {
		//for non-mipmaping
		// make sure image has proprer dimensions
		int xSize2, ySize2;
		GLint glMaxTexDim;
		//Get the maximum texture size
		glGetIntegerv( GL_MAX_TEXTURE_SIZE, &glMaxTexDim );

		//Get the powers of 2 that correspond to the width and height of the original
		//or of the maxmaximum texture size if widthor height is larger than the maxmaximum texture size
		xSize2=ceilPower2(width);
		ySize2=ceilPower2(height);

        if (xSize2 > glMaxTexDim) xSize2 = glMaxTexDim;
		if (ySize2 > glMaxTexDim) ySize2 = glMaxTexDim;

		//if the new sizes are different than the old ones
		//resize and scale the "RGBImage"
		if ( xSize2 != width || ySize2 != height )
        {
		  #ifdef WIN32
			pData = (BYTE*)LocalAlloc( LMEM_FIXED,	xSize2 * ySize2 * depth/8 * sizeof(BYTE));
			#else
			pData = (BYTE*)malloc( xSize2 * ySize2 * depth/8 * sizeof(BYTE));
			#endif
			if (!pData)	
				goto error_recovery;

			switch (depth) {
				case 8:
					gluScaleImage(GL_LUMINANCE, width, height, GL_UNSIGNED_BYTE, imageData, xSize2, ySize2, GL_UNSIGNED_BYTE, pData);
					break;
				case 24:
					gluScaleImage(GL_BGR_EXT, width, height, GL_UNSIGNED_BYTE, imageData, xSize2, ySize2, GL_UNSIGNED_BYTE, pData);
					break;
				case 32:
					gluScaleImage(GL_BGRA_EXT, width, height, GL_UNSIGNED_BYTE, imageData, xSize2, ySize2, GL_UNSIGNED_BYTE, pData);
					break;
				default:
					danceInterp::OutputMessage("Unsupported image file format");
					#ifdef WIN32
					LocalFree(pData);
					#else
					free(pData);
					#endif
					goto error_recovery;
			}
			width=xSize2;
			height= ySize2;
			imageData = pData;
        }

		switch(depth)
		{
			case 24:
				glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, imageData);
				break;
			case 32:
				glTexImage2D(GL_TEXTURE_2D, 0, 4, width, height, 0, GL_BGRA_EXT, GL_UNSIGNED_BYTE, imageData);
				break;
			default:
				danceInterp::OutputMessage("Unsupported image file format");
				goto error_recovery;

		}
	}
	if (pData) 
	#ifdef WIN32
	LocalFree(pData);
	#else
	free(pData);
	#endif

	if ((nerror=glGetError ())!=GL_NO_ERROR) {
		danceInterp::OutputMessage("Error glTexImage2D: %s\n", (char*)gluErrorString(nerror));
		goto error_recovery;
	} else 
		return m_tex;

error_recovery:
	glDeleteTextures(1,&m_tex);
	return -1;

}

