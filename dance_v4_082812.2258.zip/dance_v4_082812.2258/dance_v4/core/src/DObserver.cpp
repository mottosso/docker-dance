#include "DObserver.h"

DObserver::DObserver()
{
}

DObserver::~DObserver()
{
}

