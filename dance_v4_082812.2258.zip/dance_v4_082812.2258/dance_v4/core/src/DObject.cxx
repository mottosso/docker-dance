/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "DObject.h"
#include "dance.h"
#include "danceInterp.h"
#include "DObjectRefList.h"
#include "DAttributeManager.h"
#include "DConnection.h"
#include "PlugInManager.h"
#include "DConnectionManager.h"

using namespace fltk;

unsigned int DObject::nextID = 10;

unsigned int DObject::GetNextID()
{
	unsigned int curID = nextID;
	nextID++;

	return curID;
}

DObject::DObject()
{
	Filename = "";
	m_uniqueID = GetNextID();
	m_win = NULL;
	setSelected(false);
	this->m_dependencies = new DObjectRefList();
	this->m_dependenciesReverse = new DObjectRefList();
	m_attributeManager = new DAttributeManager();

	m_visible = this->createBoolAttribute("visible", true, true, "Display", 10, false, true);

	setVisible(true);

}

DObject::~DObject()
{
	if (this->m_dependencies) delete this->m_dependencies;
	if (this->m_dependenciesReverse) delete this->m_dependenciesReverse;
	dance::AllSimulators->removeAllCallbacks(this);
	delete m_attributeManager;
}

int DObject::commandPlugIn(int argc, char	**argv)
{
	if (strcmp(argv[0],"type") == 0) 
	{
		danceInterp::OutputListElement(getType(),NULL);
		return DANCE_OK ;
	}
	else if (strcmp(argv[0],"name") == 0)
	{
		if (argc == 2) 
			setName(argv[1]);
		else 
			danceInterp::OutputListElement(getName(),NULL);
		return DANCE_OK ;
	}
	else if (strcmp(argv[0],"select") == 0)
	{
		this->setSelected(true);
		return DANCE_OK ;
	}
	else if (strcmp(argv[0],"unselect") == 0)
	{
		this->setSelected(false);
		return DANCE_OK ;
	}
	else if (strcmp(argv[0], "connect") == 0)
	{
		if (argc < 3)
		{ 
			danceInterp::OutputMessage("Use: connect <type> <object>");
			return DANCE_ERROR;
		}
		// get the connected object
		DObject* object = dance::getObject(argv[2]);
		if (!object)
		{
			danceInterp::OutputMessage("Cannot connect %s -> %s -> %s. No object named %s found. ", this->getName(), argv[1], argv[2], argv[2]);
			return DANCE_ERROR;
		}
		DConnection* connection = dance::connectionManager->makeConnection(this, argv[1], object);
		if (!connection)
		{
			danceInterp::OutputMessage("Cannot connect %s -> %s -> %s. Connection not valid. ", this->getName(), argv[1], argv[2]);
			return DANCE_ERROR;
		}
		return DANCE_CONTINUE;
	}
	else if (strcmp(argv[0], "disconnect") == 0)
	{
		if (argc < 3)
		{ 
			danceInterp::OutputMessage("Use: disconnect <type> <object>");
			return DANCE_ERROR;
		}
		DObject* object = dance::getObject(argv[2]);
		if (!object)
		{
			danceInterp::OutputMessage("Cannot connect %s -> %s -> %s. No object named %s found. ", this->getName(), argv[1], argv[2], argv[2]);
			return DANCE_ERROR;
		}
		dance::connectionManager->removeConnection(this, argv[1], object);

		return DANCE_CONTINUE;
	}
	else if (strcmp(argv[0],"set") == 0 || strcmp(argv[0],"setattribute") == 0 )
	{
		if (argc < 4)
		{ 
			danceInterp::OutputMessage("Use: set <bool> <name> <value>");
			return DANCE_ERROR;
		}
		std::string type = argv[1];
		if (type == "bool") 
		{
			std::string name = argv[2];

			bool attrVal = false;
			std::string value = argv[3];
			if (value == "true") 
				attrVal = true;
			else if (value == "false")
				attrVal = false;
			else 
			{
				danceInterp::OutputMessage("Attribute value %s is not a valid. Use true or false.", value.c_str());
				return DANCE_ERROR;
			}

			// check for existence of the attribute
			DAttribute* attr = getAttribute(name);
			BoolAttribute* battr = NULL;
			if (!attr)
			{
				battr = new BoolAttribute();
				battr->setName(name);
				this->addAttribute(battr);
			}
			else
			{
				battr = dynamic_cast<BoolAttribute*>(attr);
			}
			if (battr) 
			{
				if (battr->getAttributeInfo()->getReadOnly())
				{
					danceInterp::OutputMessage("Attribute %s.%s is readonly and cannot be changed.", this->getName(), name.c_str(), attrVal);
					return DANCE_OK;
				}
				battr->setValue(attrVal);
				danceInterp::OutputMessage("Set attribute %s.%s = %d", this->getName(), name.c_str(), attrVal);
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Attribute %s.%s is not a bool attribute.", this->getName(), name.c_str());
				return DANCE_ERROR;
			}
		}
		else if (type == "int")
		{
			std::string name = argv[2];
			std::string value = argv[3];
			int intVal = atoi(value.c_str());

			// check for existence of the attribute
			DAttribute* attr = getAttribute(name);
			IntAttribute* iattr = NULL;
			if (!attr)
			{
				iattr = new IntAttribute();
				iattr->setName(name);
				this->addAttribute(iattr);
			}
			else
			{
				iattr = dynamic_cast<IntAttribute*>(attr);
			}
			if (iattr) 
			{
				if (iattr->getAttributeInfo()->getReadOnly())
				{
					danceInterp::OutputMessage("Attribute %s.%s is readonly and cannot be changed.", this->getName(), name.c_str());
					return DANCE_OK;
				}
				iattr->setValue(intVal);
				if (argc == 6) // set the min and max values
				{
					iattr->setMin(atoi(argv[4]));
					iattr->setMax(atoi(argv[5]));
					danceInterp::OutputMessage("Set attribute %s.%s = %d in range (%d, %d)", this->getName(), name.c_str(), intVal, iattr->getMin(), iattr->getMax());
				}
				else
				{	
					danceInterp::OutputMessage("Set attribute %s.%s = %d", this->getName(), name.c_str(), intVal);
				}
				danceInterp::OutputMessage("Set attribute %s.%s = %d", this->getName(), name.c_str(), intVal);
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Attribute %s.%s is not an int attribute.", this->getName(), name.c_str());
				return DANCE_ERROR;
			}
		}
		else if (type == "double")
		{
			std::string name = argv[2];
			std::string value = argv[3];
			double doubleVal = atof(value.c_str());

			// check for existence of the attribute
			DAttribute* attr = getAttribute(name);
			DoubleAttribute* dattr = NULL;
			if (!attr)
			{
				dattr = new DoubleAttribute();
				dattr->setName(name);
				this->addAttribute(dattr);
			}
			else
			{
				dattr = dynamic_cast<DoubleAttribute*>(attr);
			}
			if (dattr) 
			{
				if (dattr->getAttributeInfo()->getReadOnly())
				{
					danceInterp::OutputMessage("Attribute %s.%s is readonly and cannot be changed.", this->getName(), name.c_str());
					return DANCE_OK;
				}
				dattr->setValue(doubleVal);
				if (argc == 6) // set the min and max values
				{
					dattr->setMin(atof(argv[4]));
					dattr->setMax(atof(argv[5]));
					danceInterp::OutputMessage("Set attribute %s.%s = %f in range (%f, %f)", this->getName(), name.c_str(), doubleVal, dattr->getMin(), dattr->getMax());
				}
				else
				{	
					danceInterp::OutputMessage("Set attribute %s.%s = %f", this->getName(), name.c_str(), doubleVal);
				}
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Attribute %s.%s is not a double attribute.", this->getName(), name.c_str());
				return DANCE_ERROR;
			}
		}
		else if (type == "string")
		{
			std::string name = argv[2];
			std::string value = argv[3];

			// check for existence of the attribute
			DAttribute* attr = getAttribute(name);
			StringAttribute* sattr = NULL;
			if (!attr)
			{
				sattr = new StringAttribute();
				sattr->setName(name);
				this->addAttribute(sattr);
			}
			else
			{
				sattr = dynamic_cast<StringAttribute*>(attr);
			}
			if (sattr) 
			{
				if (sattr->getAttributeInfo()->getReadOnly())
				{
					danceInterp::OutputMessage("Attribute %s.%s is readonly and cannot be changed.", this->getName(), name.c_str());
					return DANCE_OK;
				}
				sattr->setValue(value);
				danceInterp::OutputMessage("Set attribute %s.%s = %s", this->getName(), name.c_str(), value.c_str());
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Attribute %s.%s is not a string attribute.", this->getName(), name.c_str());
				return DANCE_ERROR;
			}
		}
		else if (type == "vec3")
		{
			if (argc < 6)
			{ 
				danceInterp::OutputMessage("Use: set <vec3> <name> <value1> <value2> <value3>");
				return DANCE_ERROR;
			}
			std::string name = argv[2];
			std::string value1 = argv[3];
			std::string value2 = argv[4];
			std::string value3 = argv[5];
			Vector vecVal;
			vecVal[0] = atof(value1.c_str());
			vecVal[1] = atof(value2.c_str());
			vecVal[2] = atof(value3.c_str());

			// check for existence of the attribute
			DAttribute* attr = getAttribute(name);
			Vec3Attribute* v3attr = NULL;
			if (!attr)
			{
				v3attr = new Vec3Attribute();
				v3attr->setName(name);
				this->addAttribute(v3attr);
			}
			else
			{
				v3attr = dynamic_cast<Vec3Attribute*>(attr);
			}
			if (v3attr) 
			{
				if (v3attr->getAttributeInfo()->getReadOnly())
				{
					danceInterp::OutputMessage("Attribute %s.%s is readonly and cannot be changed.", this->getName(), name.c_str());
					return DANCE_OK;
				}
				v3attr->setValue(vecVal);
				danceInterp::OutputMessage("Set attribute %s.%s = %f %f %f", this->getName(), name.c_str(), vecVal[0], vecVal[1], vecVal[2]);
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Attribute %s.%s is not a vec3 attribute.", this->getName(), name.c_str());
				return DANCE_ERROR;
			}
		}
		else if (type == "matrix")
		{
			if (argc < 19)
			{ 
				danceInterp::OutputMessage("Use: set <matrix> <name> <value1> <value2> ... <value16>");
				return DANCE_ERROR;
			}
			std::string name = argv[2];
			ArbMatrix matrix(4, 4);
			int index = 0;
			for (int r = 0; r < 4; r++)
			{
				for (int c = 0; c < 4; c++)
				{
					std::string strVal = argv[3 + index];
					matrix.elem(r, c) = atof(strVal.c_str());
				}
				index++;
			}
			// check for existence of the attribute
			DAttribute* attr = getAttribute(name);
			MatrixAttribute* matrixattr = NULL;
			if (!attr)
			{
				matrixattr = new MatrixAttribute();
				matrixattr->setName(name);
				this->addAttribute(matrixattr);
			}
			else
			{
				matrixattr = dynamic_cast<MatrixAttribute*>(attr);
			}
			if (matrixattr) 
			{
				if (matrixattr->getAttributeInfo()->getReadOnly())
				{
					danceInterp::OutputMessage("Attribute %s.%s is readonly and cannot be changed.", this->getName(), name.c_str());
					return DANCE_OK;
				}
				matrixattr->setValue(matrix);
				danceInterp::OutputMessage("Set attribute %s.%s = %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f ", this->getName(), name.c_str(),
											matrix.elem(0, 0), matrix.elem(0, 1), matrix.elem(0, 2), matrix.elem(0, 3),
											matrix.elem(1, 0), matrix.elem(1, 1), matrix.elem(1, 2), matrix.elem(1, 3),
											matrix.elem(2, 0), matrix.elem(2, 1), matrix.elem(2, 2), matrix.elem(2, 3),
											matrix.elem(3, 0), matrix.elem(3, 1), matrix.elem(3, 2), matrix.elem(3, 3));
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Attribute %s.%s is not a matrix attribute.", this->getName(), name.c_str());
				return DANCE_ERROR;
			}
		}
		else
		{
			danceInterp::OutputMessage("Attribute type %s is not a valid type. Use bool.", type.c_str());
			return DANCE_ERROR;
		}


		this->setSelected(false);
		return DANCE_OK ;
	}
	else if (strcmp(argv[0],"setrange") == 0 || strcmp(argv[0],"setattributerange") == 0 )
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Use: setrange <name> <min> <max>");
			return DANCE_ERROR;
		}
		std::string name = argv[1];
		DAttribute* attr = this->getAttribute(name);
		if (!attr)
		{
			danceInterp::OutputMessage("Could not find attribute  %s.%s", this->getName(), name.c_str());
			return DANCE_ERROR;
		}
		IntAttribute* intAttr = dynamic_cast<IntAttribute*>(attr);
		if (intAttr)
		{
			intAttr->setMin(atoi(argv[2]));
			intAttr->setMax(atoi(argv[3]));
			danceInterp::OutputMessage("Set attribute %s.%s to range (%d, %d)", this->getName(), name.c_str(), intAttr->getMin(), intAttr->getMax());

			return DANCE_OK;
		}
		DoubleAttribute* doubleAttr = dynamic_cast<DoubleAttribute*>(attr);
		if (doubleAttr)
		{
			doubleAttr->setMin(atof(argv[2]));
			doubleAttr->setMax(atof(argv[3]));
			danceInterp::OutputMessage("Set attribute %s.%s to range (%f, %f)", this->getName(), name.c_str(), doubleAttr->getMin(), doubleAttr->getMax());

			return DANCE_OK;
		}

		danceInterp::OutputMessage("Attribute %s.%s is not an int or double type, and does not have a range", this->getName(), name.c_str());
		return DANCE_ERROR;

		return DANCE_OK ;
	}
	else if (strcmp(argv[0],"remove") == 0 || strcmp(argv[0],"removeattribute") == 0 )
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Use: remove <name>");
			return DANCE_ERROR;
		}
		std::string name = argv[1];
		DAttribute* attr = this->getAttribute(name);
		if (!attr)
		{
			danceInterp::OutputMessage("Could not find attribute  %s.%s", this->getName(), name.c_str());
			return DANCE_ERROR;
		}
		if (attr->getAttributeInfo()->getLocked())
		{
			danceInterp::OutputMessage("Attribute %s.%s is locked and cannot be removed.", this->getName(), name.c_str());
			return DANCE_ERROR;
		}

		bool success = this->removeAttribute(name);
		if (success)
		{
			danceInterp::OutputMessage("Removed attribute %s.%s", this->getName(), name.c_str());
			return DANCE_OK;
		}
		else 
		{
			danceInterp::OutputMessage("Could not find attribute  %s.%s", this->getName(), name.c_str());
			return DANCE_ERROR;
		}
		return DANCE_OK ;
	}
	else if (strcmp(argv[0],"attrinfo") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Use: attrinfo <name> <readonly|hidden|locked|priority> |<val>|");
			return DANCE_ERROR;
		}

		std::string name = argv[1];
		DAttribute* attr = this->getAttribute(name);
		
		if (attr)
		{
			int index = 2;
			while (index < argc) 
			{
				std::string which = argv[index];
				if (which == "readonly")
				{
					if (argc == index + 1)
					{
						bool val = attr->getAttributeInfo()->getReadOnly();
						danceInterp::OutputListElement(val? "true" : "false");
						return DANCE_OK;
					}
					else
					{
						std::string val = argv[index + 1];
						if (val == "true")
							attr->getAttributeInfo()->setReadOnly(true);
						else if (val == "false")
							attr->getAttributeInfo()->setReadOnly(false);
						else
						{
							danceInterp::OutputMessage("Use: attrinfo <name> <readonly|hidden|locked|priority> |<val>|");
							return DANCE_ERROR;
						}

						danceInterp::OutputMessage("Set attribute %s.%s to readonly %s", this->getName(), name.c_str(), attr->getAttributeInfo()->getReadOnly()? "true" : "false");
						index += 2;
					}
				}
				else if (which == "hidden")
				{
					if (argc == index + 1)
					{
						bool val = attr->getAttributeInfo()->getHidden();
						danceInterp::OutputListElement(val? "true" : "false");
						return DANCE_OK;
					}
					else
					{
						std::string val = argv[index + 1];
						if (val == "true")
							attr->getAttributeInfo()->setHidden(true);
						else if (val == "false")
							attr->getAttributeInfo()->setHidden(false);
						else
						{
							danceInterp::OutputMessage("Use: attrinfo <name> <readonly|hidden|locked|priority> |<val>|");
							return DANCE_ERROR;
						}
						// notify the attribute manager of the change
						this->getAttributeManager()->notifyHideAttribute(attr);

						danceInterp::OutputMessage("Set attribute %s.%s to readonly %s", this->getName(), name.c_str(), attr->getAttributeInfo()->getHidden()? "true" : "false");
						index += 2;
					}
				}
				else if (which == "locked")
				{ 
					if (argc == index + 1)
					{
						bool val = attr->getAttributeInfo()->getLocked();
						danceInterp::OutputListElement(val? "true" : "false");
						return DANCE_OK;
					}
					else
					{
						std::string val = argv[index + 1];
						if (val == "true")
							attr->getAttributeInfo()->setLocked(true);
						else if (val == "false")
							attr->getAttributeInfo()->setLocked(false);
						else
						{
							danceInterp::OutputMessage("Use: attrinfo <name> <readonly|hidden|locked|priority> |<val>|");
							return DANCE_ERROR;
						}

						danceInterp::OutputMessage("Set attribute %s.%s to readonly %s", this->getName(), name.c_str(), attr->getAttributeInfo()->getLocked()? "true" : "false");
						index += 2;
					}
				}
				else if (which == "priority")
				{
					if (argc == index + 1)
					{
						int val = attr->getAttributeInfo()->getPriority();
						danceInterp::OutputListElement("%d", val);
						return DANCE_OK;
					}
					else
					{
						int val = atoi(argv[index + 1]);
						attr->getAttributeInfo()->setPriority(val);
						// notify the attribute manager of the change
						this->getAttributeManager()->notifyRemoveAttribute(attr);

						danceInterp::OutputMessage("Set attribute %s.%s to readonly %d", this->getName(), name.c_str(), attr->getAttributeInfo()->getPriority());
						index += 2;
					}
				}
			}
		}
		else 
		{
			danceInterp::OutputMessage("Could not find attribute  %s.%s", this->getName(), name.c_str());
			return DANCE_ERROR;
		}

		return DANCE_OK ;
	}


	return DANCE_CONTINUE;

}

 void DObject::output(int mode)
 {
	 if (this->isSelected())
	 {
		 BoundingBox* box = this->calcBoundingBox();
		 if (!box)
			 return;
		 glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT);
		 glDisable(GL_LIGHTING);
		 box->display(1.0, 1.0, 0.0, 0.5);
		 glPopAttrib();
	 }
 }

void DObject::setSelected(bool val)
{ 
	m_selected = val;
	Widget* window = getInterface();

	if (val)
		dance::selectionManager->addSelectedObject(this);
	else
		dance::selectionManager->removeSelectedObject(this);

	if (window != NULL) 
	{
		if (m_selected == true)
			dance::rootWindow->parameterWindow->addInterface(window, this->getName());
		else
			dance::rootWindow->parameterWindow->removeInterface(window);
	}
}

void DObject::displayBoundingBox(float	r, float g, float b, float a)
{
	m_BoundingBox.display(r,g,b,a);
}

bool DObject::isSelected()
{
	return m_selected;
};

unsigned int DObject::getID()
{
	return m_uniqueID;
}

Widget* DObject::getInterface()
{
	return NULL;
}

void DObject::addDependency(DObject* object)
{
	if (object == NULL)
		return;
	this->m_dependencies->add(object);
	object->addDependencyReverse(this);
}

void DObject::addDependencyOnly(DObject* object)
{
	if (object == NULL)
		return;
	this->m_dependencies->add(object);
}


void DObject::removeDependency(DObject* object)
{
	if (object == NULL)
		return;
	this->m_dependencies->remove(object);
	this->onDependencyRemoval(object);
	object->removeDependencyReverse(this);
}

void DObject::removeDependencyOnly(DObject* object)
{
	if (object == NULL)
		return;
	this->m_dependencies->remove(object);
}

void DObject::clearDependencies()
{
	int numDeps = this->m_dependencies->size();
	for (int x = numDeps - 1; x >= 0; x--)
		this->m_dependencies->remove(x);
}

void DObject::clearReverseDependencies()
{
	int numDepsRev = this->m_dependenciesReverse->size();
	for (int x = numDepsRev - 1; x >= 0; x--)
		this->m_dependenciesReverse->remove(x);
}

DObjectRefList* DObject::getDependencies()
{
	return this->m_dependencies;
}

void DObject::addDependencyReverse(DObject* object)
{
	this->m_dependenciesReverse->add(object);
}

void DObject::removeDependencyReverse(DObject* object)
{
	this->m_dependenciesReverse->remove(object);
}

DObjectRefList* DObject::getDependenciesReverse()
{
	return this->m_dependenciesReverse;
}

void DObject::onDependencyRemoval(DObject* object)
{
}

void DObject::save(int mode, std::ofstream& file)
{
	char buff[1024];
	
	if (mode == 0)
	{
		//file << "# " << this->getName() << " is not saving parameters " << std::endl;
	}
	else if (mode == 1)
	{
		// save all the attributes
		for (std::map<std::string, DAttribute*>::iterator iter = m_attributeList.begin();
			iter !=  m_attributeList.end();
			iter++)
		{
			sprintf(buff, "%s", iter->second->write().c_str());
			pythonSave(file, buff);
			sprintf(buff, "%s", iter->second->getAttributeInfo()->write().c_str());
			pythonSave(file, buff);
		}
		
	}
	else if (mode == 2)
	{
	}
}

 void DObject::pythonSave(std::ofstream& file, char* str)
 {
	 file << "dance." << this->getBaseType() << "(\"" << this->getName() << "\", " << str << ")" << std::endl;
 }

 void DObject::addAttribute(DAttribute* attr)
 {
	 // check for the existence of the attribute
	std::map<std::string, DAttribute*>::iterator iter = m_attributeList.find(attr->getName());
	if (iter != m_attributeList.end()) // attribute exists, remove the old attribute 
	{
		DAttribute* attr = iter->second;
	
		// notify the attribute manager of the change
		this->getAttributeManager()->notifyRemoveAttribute(attr);

		m_attributeList.erase(iter);
		delete attr;
	}

	m_attributeList[attr->getName()] = attr;
	attr->setObject(this);
	// notify the attribute manager of the change
	this->getAttributeManager()->notifyCreateAttribute(attr);
 }
 

 DAttribute* DObject::getAttribute(std::string name)
 {
	std::map<std::string, DAttribute*>::iterator iter = m_attributeList.find(name);
	if (iter != m_attributeList.end()) // attribute exists, remove the old attribute 
	{
		return iter->second;
	}
	else
	{
		return NULL;
	}
 }

 bool DObject::removeAttribute(std::string name)
 {
	// check for the existence of the attribute
	std::map<std::string, DAttribute*>::iterator iter = m_attributeList.find(name);
	if (iter != m_attributeList.end()) // attribute exists, remove the old attribute 
	{

		DAttribute* attr = iter->second;
	
		// notify the attribute manager of the change
		this->getAttributeManager()->notifyRemoveAttribute(attr);
		
		m_attributeList.erase(iter);
		delete attr;
		
		return true;
	}

	return false;
 }

 BoolAttribute* DObject::createBoolAttribute(std::string name, bool value, bool notifySelf, std::string groupName, int priority, 
	                                         bool isReadOnly, bool isLocked, bool isHidden)
 {
	 BoolAttribute* boolAttr = new BoolAttribute();
	 boolAttr->setName(name);
	 boolAttr->setValue(value);
	 boolAttr->getAttributeInfo()->setPriority(priority);
	 boolAttr->getAttributeInfo()->setReadOnly(isReadOnly);
	 boolAttr->getAttributeInfo()->setLocked(isLocked);
	 boolAttr->getAttributeInfo()->setHidden(isHidden);

	 this->addAttribute(boolAttr);

	 DAttributeGroup* group = this->getAttributeManager()->getGroup(groupName, true);
	 boolAttr->getAttributeInfo()->setGroup(group);

	 if (notifySelf)
		boolAttr->registerObserver(this);

	 return boolAttr;
}

IntAttribute* DObject::createIntAttribute(std::string name, int value, bool notifySelf, std::string groupName, int priority, 
												  bool isReadOnly, bool isLocked, bool isHidden)
 {
	 IntAttribute* intAttr = new IntAttribute();
	 intAttr->setName(name);
	 intAttr->setValue(value);
	 intAttr->getAttributeInfo()->setPriority(priority);
	 intAttr->getAttributeInfo()->setReadOnly(isReadOnly);
	 intAttr->getAttributeInfo()->setLocked(isLocked);
	 intAttr->getAttributeInfo()->setHidden(isHidden);

	 this->addAttribute(intAttr);

	 DAttributeGroup* group = this->getAttributeManager()->getGroup(groupName, true);
	 intAttr->getAttributeInfo()->setGroup(group);

	 if (notifySelf)
		intAttr->registerObserver(this);

	  return intAttr;
}

 DoubleAttribute* DObject::createDoubleAttribute(std::string name, double value, bool notifySelf, std::string groupName, int priority, 
												  bool isReadOnly, bool isLocked, bool isHidden)
 {
	 DoubleAttribute* doubleAttr = new DoubleAttribute();
	 doubleAttr->setName(name);
	 doubleAttr->setValue(value);
	 doubleAttr->getAttributeInfo()->setPriority(priority);
	 doubleAttr->getAttributeInfo()->setReadOnly(isReadOnly);
	 doubleAttr->getAttributeInfo()->setLocked(isLocked);
	 doubleAttr->getAttributeInfo()->setHidden(isHidden);

	 this->addAttribute(doubleAttr);

	 DAttributeGroup* group = this->getAttributeManager()->getGroup(groupName, true);
	 doubleAttr->getAttributeInfo()->setGroup(group);

	 if (notifySelf)
		doubleAttr->registerObserver(this);

	  return doubleAttr;
}

 Vec3Attribute* DObject::createVec3Attribute(std::string name, double val1, double val2, double val3, bool notifySelf, std::string groupName, int priority, 
												  bool isReadOnly, bool isLocked, bool isHidden)
 {
	 Vec3Attribute* vec3Attr = new Vec3Attribute();
	 vec3Attr->setName(name);
	 VectorObj vec(val1, val2, val3);
	 vec3Attr->setValue(vec.data());
	 vec3Attr->getAttributeInfo()->setPriority(priority);
	 vec3Attr->getAttributeInfo()->setReadOnly(isReadOnly);
	 vec3Attr->getAttributeInfo()->setLocked(isLocked);
	 vec3Attr->getAttributeInfo()->setHidden(isHidden);

	 this->addAttribute(vec3Attr);

	 DAttributeGroup* group = this->getAttributeManager()->getGroup(groupName, true);
	 vec3Attr->getAttributeInfo()->setGroup(group);

	 if (notifySelf)
		vec3Attr->registerObserver(this);

	  return vec3Attr;
}


 StringAttribute* DObject::createStringAttribute(std::string name, std::string value, bool notifySelf, std::string groupName, int priority, 
												  bool isReadOnly, bool isLocked, bool isHidden)
 {
	 StringAttribute* strAttr = new StringAttribute();
	 strAttr->setName(name);
	 strAttr->setValue(value);
	 strAttr->getAttributeInfo()->setPriority(priority);
	 strAttr->getAttributeInfo()->setReadOnly(isReadOnly);
	 strAttr->getAttributeInfo()->setLocked(isLocked);
	 strAttr->getAttributeInfo()->setHidden(isHidden);

	 this->addAttribute(strAttr);

	 DAttributeGroup* group = this->getAttributeManager()->getGroup(groupName, true);
	 strAttr->getAttributeInfo()->setGroup(group);
	
	 if (notifySelf)
		strAttr->registerObserver(this);

	 return strAttr;
}

 MatrixAttribute* DObject::createMatrixAttribute(std::string name, ArbMatrix& value, bool notifySelf, std::string groupName, int priority, 
												  bool isReadOnly, bool isLocked, bool isHidden)
 {
	 MatrixAttribute* matrixAttr = new MatrixAttribute();
	 matrixAttr->setName(name);
	 matrixAttr->setValue(value);
	 matrixAttr->getAttributeInfo()->setPriority(priority);
	 matrixAttr->getAttributeInfo()->setReadOnly(isReadOnly);
	 matrixAttr->getAttributeInfo()->setLocked(isLocked);
	 matrixAttr->getAttributeInfo()->setHidden(isHidden);

	 this->addAttribute(matrixAttr);

	 DAttributeGroup* group = this->getAttributeManager()->getGroup(groupName, true);
	 matrixAttr->getAttributeInfo()->setGroup(group);

	 if (notifySelf)
		matrixAttr->registerObserver(this);

	  return matrixAttr;
}



 std::map<std::string, DAttribute*>& DObject::getAttributeList()
 {
	return m_attributeList;
 }

void DObject::notify(DSubject* subject)
{
	if (subject == m_visible)
	{
		dance::AllViews->postRedisplay();
	}
}

DAttributeManager* DObject::getAttributeManager()
{
	return m_attributeManager;
}

void DObject::onConnect(DConnection* connection)
{
	if (connection->getFrom() == this)
		danceInterp::OutputMessage("Connection: %s --> (%s) --> %s", this->getName(), connection->getType().c_str(), connection->getTo()->getName());
}

void DObject::onDisconnect(DConnection* connection)
{
	if (connection->getFrom() == this)
		danceInterp::OutputMessage("Disconnection: %s --> (%s) --> %s", this->getName(), connection->getType().c_str(), connection->getTo()->getName());
}
