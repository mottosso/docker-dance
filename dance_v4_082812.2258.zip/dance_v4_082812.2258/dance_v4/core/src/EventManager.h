#ifndef _EVENTMANAGER_H
#define _EVENTMANAGER_H

#include "DObject.h"
#include <vector>

class EventCallback
{
	public:
		DObject* object;
		void (*cb)(DObject*, DObject*, DObject*);
		int priority;
};

class DLLENTRY EventManager
{
	public:
		EventManager();
		~EventManager();

		void pushCollisionEvent(DObject* obj, DObject* obj2);
		void registerCollisionEvent(DObject* data, int priority, void (*collisioncb)(DObject*, DObject*, DObject*));
		void unregisterCollisionEvent(DObject* object);
		void clearAllEvents();

	private:
		std::vector<EventCallback*> cbEvents;

};

#endif

