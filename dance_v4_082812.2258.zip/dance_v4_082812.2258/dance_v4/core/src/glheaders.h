#ifndef glheaders_h 
#define glheaders_h 1

#ifdef _MACOSX_
#include <OpenGL/gl.h>
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#include <fltk/gl.h>
#include <GL/glu.h>
#endif

#endif
