/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "dance.h"
#include "DActuator.h"
#include "DSystem.h"
#include "DLight.h"
#include "DView.h"
#include "DGeometry.h"
#include "ViewManager.h"
#include "PlugInManager.h"
#include "DSimulatorManager.h"
#include "DSimulator.h"
#include "danceInterp.h"
#include <vector>
#include <fltk/ask.h>
#include "Preference.h"
#include <fltk/ItemGroup.h>

#include <sstream>

using namespace fltk;
using namespace std;

SelectionWindow::SelectionWindow(int x,int y,int w,int h,const char* s) : Window(x,y,w,h,s)
{
	this->begin();

	int yDis = 20;

	browser = new MultiBrowser(10, yDis, w - 200, h - 120, "Select Objects"); 
	browser->align(ALIGN_TOP);


	inputObject = new Input(80, h - 95, 200, 25, "Object Name");
	inputObject->when(fltk::WHEN_CHANGED);
	inputObject->callback(this->objectcompleter_cb, this);

	//inputType = new Input(80, h - 70, 200, 25, "Object Types");
	//inputType->callback(this->objectcompleter_cb, this);

	box = new FlatBox("List Types"); 

	int yDis_ListTypes = 30;
	yDis += (h - 50);

	checkButton[0]  = new CheckButton(w - 150, yDis_ListTypes, 50, 30, "Actuators");		yDis_ListTypes += 25; 
	checkButton[0]->callback(type_check_button_cb, this);
	checkButton[1]  = new CheckButton(w - 150, yDis_ListTypes, 50, 30, "Geometry");			yDis_ListTypes += 25;
	checkButton[1]->callback(type_check_button_cb, this);
	checkButton[2]  = new CheckButton(w - 150, yDis_ListTypes, 50, 30, "Lights");			yDis_ListTypes += 25;
	checkButton[2]->callback(type_check_button_cb, this);
	checkButton[3]  = new CheckButton(w - 150, yDis_ListTypes, 50, 30, "Simulators");		yDis_ListTypes += 25;
	checkButton[3]->callback(type_check_button_cb, this);
	checkButton[4]  = new CheckButton(w - 150, yDis_ListTypes, 50, 30, "Systems");			yDis_ListTypes += 25;
	checkButton[4]->callback(type_check_button_cb, this);
	checkButton[5]  = new CheckButton(w - 150, yDis_ListTypes, 50, 30, "Views");			yDis_ListTypes += 25;
	checkButton[5]->callback(type_check_button_cb, this);
	checkButton[6]  = new CheckButton(w - 150, yDis_ListTypes, 50, 30, "Modifiers");			yDis_ListTypes += 25;
	checkButton[6]->callback(type_check_button_cb, this);
	checkButton[7]  = new CheckButton(w - 150, yDis_ListTypes, 50, 30, "Renderers");	yDis_ListTypes += 25;
	checkButton[7]->callback(type_check_button_cb, this);
	checkButton[8]  = new CheckButton(w - 150, yDis_ListTypes, 50, 30, "Other Plugins");	yDis_ListTypes += 25;
	checkButton[8]->callback(type_check_button_cb, this);

	for (int z = 0; z < 9; z++) // turn on every checkbutton
		checkButton[z]->value(1);
	for (int z = 0; z  < 9; z++)
		is_checked[z] = true;

	checkDependencies = new CheckButton(w - 150, yDis_ListTypes + 10, 50, 30, "Show dependencies");
	checkDependencies->callback(type_check_button_cb, this);

	button = new Button(w - 150, yDis - 120, 50, 25, "All");
	button->callback(types_all_cb, this);
	button = new Button(w - 100, yDis - 120, 50, 25, "None");
	button->callback(types_none_cb, this);
	button = new Button(w - 50, yDis - 120, 50, 25, "Invert");
	button->callback(types_invert_cb, this);
	
	Button* buttonDelete = new Button(w - 150, yDis - 60, 50, 25, "Delete");
	buttonDelete->callback(delete_cb, this);

	buttonChangeName = new Button(w - 70, yDis - 60, 50, 25, "Rename");
	buttonChangeName->callback(rename_cb, this);

	button = new Button( 10, yDis, 50, 25, "All");
	button->callback(objects_all_cb, this);
	button = new Button( 65, yDis, 50, 25, "None");
	button->callback(objects_none_cb, this);
	button = new Button( 120, yDis, 50, 25, "Invert");
	button->callback(objects_invert_cb, this);

	button = new Button(w - 150, yDis, 50, 25, "Select");
	button->callback(select_cb, this);
	button = new Button( w - 70, yDis, 50, 25, "Cancel");
	button->callback(cancel_cb, this);


	this->end();
	this->set_modal();
}


SelectionWindow::~SelectionWindow()
{
	delete box;
}

void SelectionWindow::show()
{
	Window::show();
	init();
	this->type_check_button_cb(NULL, (void*) this);

}

void SelectionWindow::init()
{
	for (int x = 0; x < 9; x++)
	{
		if (is_checked[x])
			this->checkButton[x]->value(1);
		else
			this->checkButton[x]->value(0);
	}
}

void SelectionWindow::addObjectToBrowserWithDependency(DObject* tempObject)
{
	DObjectRefList* refList = tempObject->getDependencies();
	std::string label = tempObject->getName();
	if (refList->size() > 0)
	{
		label.append(" (");
		std::stringstream strstr;
		strstr << refList->size();
		label.append(strstr.str());
		label.append(")");
	}

	ItemGroup* itemgroup = new ItemGroup((new std::string(label))->c_str());
	itemgroup->begin();
	browser->add(itemgroup);

	for (int d = 0; d < refList->size(); d++)
	{
		DObject* depObject = refList->get(d);
		itemgroup->add((const char*) depObject->getName());
	}
	itemgroup->end();
}



void SelectionWindow::addObjectToBrowser(DObject* obj)
{
	if (obj != NULL)
	{
		browser->add(obj->getName(), obj);
	}
}

void SelectionWindow::type_check_button_cb(Widget* o, void* p)
{
	SelectionWindow* sWin = (SelectionWindow*) p;
	sWin->removeAllObjects();
	DObject* tempObject;
	int a;

	for (int type_clicked = 0; type_clicked < 9; type_clicked++)
	{
		if (sWin->checkButton[type_clicked]->value() == 1)
		{
			switch (type_clicked)
			{
				case ACTUATOR:
					for (a = 0; a < dance::AllActuators->size(); a++)
					{
						tempObject = dance::AllActuators->get(a);
						if (sWin->checkDependencies->value())
							sWin->addObjectToBrowserWithDependency(tempObject);
						else
							sWin->addObjectToBrowser(tempObject);
					}
					break;
				case GEOMETRY:
					for (a = 0; a < dance::AllGeometry->size(); a++)
					{
						tempObject = dance::AllGeometry->get(a);
						if (sWin->checkDependencies->value())
							sWin->addObjectToBrowserWithDependency(tempObject);
						else
							sWin->addObjectToBrowser(tempObject);
					}
					break;
				case LIGHT:
					for (a = 0; a < dance::AllLights->size(); a++)
					{
						tempObject = dance::AllLights->get(a);
						if (sWin->checkDependencies->value())
							sWin->addObjectToBrowserWithDependency(tempObject);
						else
							sWin->addObjectToBrowser(tempObject);
					}
					break;
				case SIMULATOR:
					for (a = 0; a < dance::AllSimulators->size(); a++)
					{
						tempObject = dance::AllSimulators->get(a);
						if (sWin->checkDependencies->value())
							sWin->addObjectToBrowserWithDependency(tempObject);
						else
							sWin->addObjectToBrowser(tempObject);
					}
					
					break;
				case SYSTEM:
					for (a = 0; a < dance::AllSystems->size(); a++)
					{
						tempObject = dance::AllSystems->get(a);
						if (sWin->checkDependencies->value())
							sWin->addObjectToBrowserWithDependency(tempObject);
						else
							sWin->addObjectToBrowser(tempObject);
					}
					break;
				case VIEW:
					for (a = 0; a < dance::AllViews->size(); a++)
					{
						tempObject = dance::AllViews->get(a);
						if (sWin->checkDependencies->value())
							sWin->addObjectToBrowserWithDependency(tempObject);
						else
							sWin->addObjectToBrowser(tempObject);
					}
					break;
				case MODIFIER:
					for (a = 0; a < dance::AllModifiers->size(); a++)
					{
						tempObject = dance::AllModifiers->get(a);
						if (sWin->checkDependencies->value())
							sWin->addObjectToBrowserWithDependency(tempObject);
						else
							sWin->addObjectToBrowser(tempObject);
					}
					break;
				case RENDERER:
					for (a = 0; a < dance::AllRenderers->size(); a++)
					{
						tempObject = dance::AllRenderers->get(a);
						if (sWin->checkDependencies->value())
							sWin->addObjectToBrowserWithDependency(tempObject);
						else
							sWin->addObjectToBrowser(tempObject);
					}
					break;
				case GENERIC:
					for (a = 0; a < dance::AllGenericPlugins->size(); a++)
					{
						tempObject = dance::AllGenericPlugins->get(a);
						if (sWin->checkDependencies->value())
							sWin->addObjectToBrowserWithDependency(tempObject);
						else
							sWin->addObjectToBrowser(tempObject);
					}
					break;
			}
		}
	}
}

void SelectionWindow::types_all_cb(Widget* o, void* p)
{
	SelectionWindow* sWin = (SelectionWindow*) p;
	for (int i = 0; i < 9; i++)
	{
		sWin->checkButton[i]->value(1);
	}
	sWin->type_check_button_cb(o, p);
}

void SelectionWindow::types_none_cb(Widget* o, void* p) {
	SelectionWindow* sWin = (SelectionWindow*) p;
	for (int i = 0; i < 9; i++)
	{
		sWin->checkButton[i]->value(0);
	}
	sWin->type_check_button_cb(o, p);
}

void SelectionWindow::types_invert_cb(Widget* o, void* p) { 
	SelectionWindow* sWin = (SelectionWindow*) p;
	for (int i = 0; i < 9; i++)
	{
		if (sWin->checkButton[i]->value())
			sWin->checkButton[i]->value(0);
		else
			sWin->checkButton[i]->value(1);
	}
	sWin->type_check_button_cb(o, p);
}

void SelectionWindow::objects_all_cb(Widget* o, void* p) { 
	SelectionWindow* sWin = (SelectionWindow*) p;
	MultiBrowser* br = sWin->browser;

	for (int i = 0; i < br->size(); i++)
	{
		br->select(i);
	}
}
void SelectionWindow::objects_none_cb(Widget* o, void* p) { 
	SelectionWindow* sWin = (SelectionWindow*) p;
	MultiBrowser* br = sWin->browser;

	for (int i = 0; i < br->size(); i++)
	{
		br->deselect(i);
	}
}
void SelectionWindow::objects_invert_cb(Widget* o, void* p) { 


	SelectionWindow* sWin = (SelectionWindow*) p;
	MultiBrowser* br = sWin->browser;

	vector<bool> selectedObjects;
	for (int i = 0; i < br->size(); i++)
	{
		if (br->selected(i) == 1)
			selectedObjects.push_back(false);
		else
			selectedObjects.push_back(true);
	}
	br->deselect();
	for (int i = 0; i < br->size(); i++)
	{
		if (selectedObjects[i])
			//br->select(i, 2);
			br->select(i, true);
	}

}


void SelectionWindow::select_cb(Widget* o, void* p) { 
	SelectionWindow* sWin = (SelectionWindow*) p;
	MultiBrowser* br = sWin->browser;

	//save the state
	for (int i = 0; i < 9; i++)
		sWin->is_checked[i] = sWin->checkButton[i]->value() != 0;

	for (int i = 0; i < br->size(); i++)
	{
		if ( br->selected(i) == 1 ) //the item is selected
		{
			Widget* w = br->child(i);
			DObject* obj = sWin->getObjectFromWidget(w);
			if (obj)
			{
				obj->setSelected(true);
			}
			
		}
	}
	
	const int* cur = br->current_index();
	int level = br->current_level(); 
	if (level > 0)
	{
		Widget* w = br->goto_index(cur, level);
		DObject* obj = sWin->getObjectFromWidget(w);
		if (obj)
		{
			obj->setSelected(true);
		}
	}

	Preference::setWindowPreference("dance.selectionwindow", sWin);
	dance::writePreferences();

	sWin->hide();
	dance::AllViews->postRedisplay();
}
void SelectionWindow::cancel_cb(Widget* o, void* p) { 
	SelectionWindow* sWin = (SelectionWindow*) p;

	Preference::setWindowPreference("dance.selectionwindow", sWin);
	dance::writePreferences();

	sWin->hide();
}

void SelectionWindow::removeAllObjects()
{
	this->browser->clear();
}

void SelectionWindow::updateObjects()
{
	for (int i = 0; i < matchingObjects.size(); i++)
	{
		DObject* object = dance::getObject((char*) matchingObjects[i].c_str());
		if (object)
			addObjectToBrowser(object);
	}

}


void SelectionWindow::delete_cb(Widget* widget, void* data)
{
	SelectionWindow* sWin = (SelectionWindow*) data;
	MultiBrowser* br = sWin->browser;

	std::vector<DObject*> toDelete;

	for (int i = 0; i < br->size(); i++)
	{
		if ( br->selected(i) == 1 ) //the item is selected
		{
			Widget* w = br->child(i);
			DObject* obj =  sWin->getObjectFromWidget(w);
			if (obj)
			{
				toDelete.push_back(obj);
			}
		}
	}


	if (toDelete.size() == 0)
	{
		fltk::alert("Please select an object to delete.");
		return;
	}

	// verify the deletion
	int ret = fltk::ask("Delete these %d object(s)?", toDelete.size());
	if (ret)
	{
		for(std::vector<DObject*>::iterator iter = toDelete.begin(); iter != toDelete.end(); iter++)
		{
			bool success = dance::removeObject((*iter));
			if (!success)
			{
				fltk::alert("Problem removing object %s. Object has not been deleted.", (*iter)->getName());
			}
		}
	}
	dance::AllViews->postRedisplay();
	sWin->show();
}

void SelectionWindow::rename_cb(fltk::Widget* widget, void* data)
{
	SelectionWindow* sWin = (SelectionWindow*) data;
	MultiBrowser* br = sWin->browser;

	std::vector<DObject*> toRename;

	for (int i = 0; i < br->size(); i++)
	{
		//Widget* widget = br->goto_index(i);
		Widget* w = br->child(i);
		DObject* obj =  sWin->getObjectFromWidget(w);
		if (obj)
			if ( br->selected(i) == 1 ) //the item is selected
				toRename.push_back(obj);
	}

	if (toRename.size() == 0)
	{
		fltk::alert("Please select an object to rename.");
		return;
	}
	if (toRename.size() > 1)
	{
		fltk::alert("Please select only one object to rename.");
		return;
	}

	DObject* tobj = toRename[0];
	const char* newname = fltk::input("New name:", tobj->getName());
	if (newname != NULL)
	{
		bool ok = dance::rename(tobj, (char*) newname);
		if (!ok)
			fltk::alert("Cannot rename object to %s, object exists.", newname);
	}
	dance::AllViews->postRedisplay();
	sWin->show();
}

DObject* SelectionWindow::getObjectFromWidget(Widget* w)
{
	DObject* obj = NULL;
	if (this->checkDependencies->value())
	{
		std::string str = w->label();
		unsigned int pos = str.find(" (");
		if (pos != std::string::npos)
		{
			std::string str2 = str.substr(0, pos);
			obj = dance::getObject((char*) str2.c_str());
		}
		else
		{
			obj = dance::getObject((char*) str.c_str());
		}
	}
	else
	{
		obj = dance::getObject((char*) w->label());
	}
	return obj;
}

void SelectionWindow::objectcompleter_cb(fltk::Widget* widget, void* data)
{
	SelectionWindow* sWin = (SelectionWindow*) data;

	sWin->setMatchingObjects(sWin->inputObject->value());

	sWin->removeAllObjects();
	sWin->updateObjects();
}

void SelectionWindow::typecompleter_cb(fltk::Widget* widget, void* data)
{
}

void SelectionWindow::setMatchingObjects(std::string partial)
{
	matchingObjects.clear();
	
	DObject* tempObject = NULL;
	for (int a = 0; a < dance::AllActuators->size(); a++)
	{
		tempObject = dance::AllActuators->get(a);
		std::string name = tempObject->getName();
		if (name.find(partial) != std::string::npos)
			matchingObjects.push_back(name);
	}

	for (int a = 0; a < dance::AllGeometry->size(); a++)
	{
		tempObject = dance::AllGeometry->get(a);
		std::string name = tempObject->getName();
		if (name.find(partial) != std::string::npos)
			matchingObjects.push_back(name);
	}
				
	for (int a = 0; a < dance::AllLights->size(); a++)
	{
		tempObject = dance::AllLights->get(a);
		std::string name = tempObject->getName();
		if (name.find(partial) != std::string::npos)
			matchingObjects.push_back(name);
	}
			
	for (int a = 0; a < dance::AllSimulators->size(); a++)
	{
		tempObject = dance::AllSimulators->get(a);
		std::string name = tempObject->getName();
		if (name.find(partial) != std::string::npos)
			matchingObjects.push_back(name);
	}
	
	for (int a = 0; a < dance::AllSystems->size(); a++)
	{
		tempObject = dance::AllSystems->get(a);
		std::string name = tempObject->getName();
		if (name.find(partial) != std::string::npos)
			matchingObjects.push_back(name);
	}

	for (int a = 0; a < dance::AllViews->size(); a++)
	{
		tempObject = dance::AllViews->get(a);
		std::string name = tempObject->getName();
		if (name.find(partial) != std::string::npos)
			matchingObjects.push_back(name);
	}

	for (int a = 0; a < dance::AllModifiers->size(); a++)
	{
		tempObject = dance::AllModifiers->get(a);
		std::string name = tempObject->getName();
		if (name.find(partial) != std::string::npos)
			matchingObjects.push_back(name);
	}

	for (int a = 0; a < dance::AllRenderers->size(); a++)
	{
		tempObject = dance::AllRenderers->get(a);
		std::string name = tempObject->getName();
		if (name.find(partial) != std::string::npos)
			matchingObjects.push_back(name);
	}

	for (int a = 0; a < dance::AllGenericPlugins->size(); a++)
	{
		tempObject = dance::AllGenericPlugins->get(a);
		std::string name = tempObject->getName();
		if (name.find(partial) != std::string::npos)
			matchingObjects.push_back(name);
	}
}
