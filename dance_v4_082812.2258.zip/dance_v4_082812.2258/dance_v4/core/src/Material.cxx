/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifdef WIN32
#include <windows.h>
#endif
#include "opengl.h"

#ifdef _DEBUG
#include <fltk/ask.h>
#endif


#include <fltk/gl.h>
#include <string.h>
#include <stdlib.h>

#include "danceInterp.h"
#include "defs.h"
#include "Material.h"
#include "stuff.h"


static char seps[]="{,<>}=";


Material* Material::sCurrentMaterial = NULL;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Material::Material()
{
	texture = NULL;
	setToDefault();
	this->setMaterialName("UNKNOWN");
}


Material::~Material() {
	if (texture) delete texture;

        if (Material::getCurrentMaterial() == this)
        {
                setCurrentMaterial(NULL);
        }
}


void Material::setToDefault()
{
	// Some defaults. Same as OpenGL
    ambientColor[0] = 0.2f;
	ambientColor[1] = 0.2f;
	ambientColor[2] = 0.2f;
	ambientColor[3] = 1.0f;

	diffuseColor[0] = .5f;
	diffuseColor[1] = .5f;
	diffuseColor[2] = .5f;
	diffuseColor[3] = 1.0f;

	specularColor[0] = 0.1f;
	specularColor[1] = 0.1f;
	specularColor[2] = 0.1f;
	specularColor[3] = 1.0f;

	emissiveColor[0] = 0.0f;
	emissiveColor[1] = 0.0f;
	emissiveColor[2] = 0.0f;
	emissiveColor[3] = 1.0f;
	shininess = 64.0;

	if (texture != NULL)
		delete texture;
	texture = NULL;
}

void Material::setAmbientColor(float color[4])
{
	for (int x = 0; x < 4; x++)
		ambientColor[x] = color[x];
}

float* Material::getAmbientColor()
{
	return &ambientColor[0];
}

void Material::setDiffuseColor(float color[4])
{
	for (int x = 0; x < 4; x++)
		diffuseColor[x] = color[x];
}

float* Material::getDiffuseColor()
{
	return &diffuseColor[0];
}

void Material::setSpecularColor(float color[4])
{
	for (int x = 0; x < 4; x++)
		specularColor[x] = color[x];
}

float* Material::getSpecularColor()
{
	return &specularColor[0];
}

void Material::setEmissiveColor(float color[4])
{
	for (int x = 0; x < 4; x++)
		emissiveColor[x] = color[x];
}

float* Material::getEmissiveColor()
{
	return &emissiveColor[0];	
}

void Material::setShininess(float color)
{
	shininess = color;
	if (shininess < 0)
		shininess = 0;
	else if (shininess > 128)
		shininess = 128;
}

float Material::getShininess()
{
	return shininess;
}

void Material::setOpenGLMaterial(float alpha)
{
    if (Material::getCurrentMaterial() == this)
	{
		setAlpha(alpha) ;
		if (!glIsEnabled(GL_NORMALIZE))
			glEnable(GL_NORMALIZE);
		if (!glIsEnabled(GL_LIGHTING))
			glEnable(GL_LIGHTING);
		if (!glIsEnabled(GL_COLOR_MATERIAL))
			glEnable(GL_COLOR_MATERIAL);
		if (texture)
		{
			if (!glIsEnabled(GL_TEXTURE_2D))
				glEnable( GL_TEXTURE_2D );
			glColor4f(1.0f,1.0f,1.0f, alpha);
		}
        return;
	}
    Material::setCurrentMaterial(this);

	setAlpha(alpha) ;
	glEnable(GL_NORMALIZE);
	glEnable(GL_LIGHTING);
    glEnable(GL_COLOR_MATERIAL);
	
	if (texture) {
		glEnable( GL_TEXTURE_2D );
		glColor4f(1.0f,1.0f,1.0f, alpha);
		texture->MakeCurrent();
	}
	else {
		glDisable( GL_TEXTURE_2D );
		glDisable(GL_COLOR_MATERIAL);
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ambientColor);
		glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuseColor);
		glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specularColor);
		glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, emissiveColor);
		glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shininess);
	}

}

void Material::setAlpha(float a)
{
	this->ambientColor[3] = a ;
	this->diffuseColor[3] = a ;
	this->specularColor[3] = a ;
}


void Material::setMaterialName(const char* str)
{
	// eliminate any spaces in the name
	eliminatespaces(str, name);
	changechar(name, safename, '#', '_');
}

char* Material::getMaterialName()
{
	return &name[0];
}

char* Material::getSafeMaterialName()
{
	return &safename[0];
}

void Material::copy(Material* m)
{
	float* color;
	
	color = m->getAmbientColor();
	this->setAmbientColor(color);

	color = m->getDiffuseColor();
	this->setDiffuseColor(color);

	color = m->getSpecularColor();
	this->setSpecularColor(color);

	color = m->getEmissiveColor();
	this->setEmissiveColor(color);

	this->setShininess(m->getShininess());
	
	this->setMaterialName(m->name);
	this->texture=m->texture;
	m->texture=NULL;
}


// Returns 1 if colors a and b are similar
int colors_match(float *a, float  *b) {
	
	// TODO: Simply euclidean distance between rgb values (this is NOT CORRECT). It should be done in a perceptually linear space, as LUV
	// TODO (2): if both vectors are linearly dependent
	//float distance;

	//distance=sqrt((a[0]-b[0])*(a[0]-b[0])+(a[1]-b[1])*(a[1]-b[1])+(a[2]-b[2])*(a[2]-b[2]));
	
	float max;

	max=MAX(fabs(a[1]*b[0]-a[0]*b[1]), fabs(a[2]*b[0]-a[0]*b[2]));
	return max<0.1;
}


// Writes the object properties to the file in PovRay format
int Material::write_povray(std::ofstream & file) {

#ifdef _DEBUG
	file << "/* Material: " << safename << " */\n\n";
#endif

	file << "#declare " << safename;
	
	// 'default' is a reserved word in povray
	if (!strcmp("default", safename)) file << "_";
		
	file << " = texture {\n";

	if (has_texture()) 
		return texture->write_texture_povray(file);
	else
		return write_material_povray(file);
}


// Writes the material properties (color, not texture)
int Material::write_material_povray(std::ofstream & file)
{
	/* Pov-Ray does not have the 'specular' parameter in the definition of the material, but it has the highlight parameters:

		phong: intensity of the specular hightlight (0..1)
		phong_size: size of the spot (1..250)
		metallic: makes the material modify the color of the reflected light 

		How to convert from OpenGL -> PovRay

		finish.phong = 0.299R + 0.587G + 0.114B  (of the specularColor)
		finish.phong_size = shininess*249/128+1
		finish.metallic = abs(specularColor - diffuseColor) < threshold
		finish.ambient = ambientColor
		pigment = diffuseColor

		I don't know what to do with emissiveColor

		*/

	file << "  pigment { \n";
	file << "    color rgbt ";
	diffuseColor[3]=1.0f-diffuseColor[3];
	write_vector(file, diffuseColor, 4, VPOVRAY);
	diffuseColor[3]=1.0f-diffuseColor[3];
	file << "\n  }\n";
	file << "  finish { \n";
	file << "    ambient rgbt ";
	ambientColor[3]=1.0f-ambientColor[3];
	write_vector(file, ambientColor, 4, VPOVRAY);
	ambientColor[3]=1.0f-ambientColor[3];

	file << "\n    phong " << 0.299*specularColor[0]+0.587*specularColor[1]+0.114*specularColor[2] << \
		" phong_size " << shininess*249/128+1 << (colors_match(diffuseColor, specularColor)?" metallic\n":"\n");
	file << "  }\n}\n\n";

#ifdef _DEBUG
		file << "/* Ambient color: " << ambientColor[0] << " " << ambientColor[1] << " " << ambientColor[2] << " " << ambientColor[3]  << "\n";
		file << "Diffuse color: " << diffuseColor[0] << " " << diffuseColor[1] << " " << diffuseColor[2] << " " << diffuseColor[3] << "\n"  ;
		file << "Specular color: " << specularColor[0] << " " << specularColor[1] << " " << specularColor[2] << " " << specularColor[3] << "\n";
		file << "Emissive color: " << emissiveColor[0] << " " << emissiveColor[1] << " " << emissiveColor[2] << " " << emissiveColor[3] << "\n";
		file << "Shininess: " << shininess << "\n*/\n\n\n";
#endif
	return 0;
}




// Reads the object properties from the file in PovRay format
int Material::read_povray(std::ifstream & file, char *path) {
	std::string tok, mid;
	int stack, exit_status=0;
	
	my_C_tokenizer(file, NULL);
	
	// #declare 
	tok=my_C_tokenizer(file, seps);
	if (tok== "") return -1;  // end of file
	if (tok!= "#declare") return -2;

	// name
	mid=my_C_tokenizer(file, seps);
	if (mid=="") return -2;

	// 'default' is a reserved word in povray
	if (mid=="default_") mid="default";

	// = texture {
	if (my_C_tokenizer(file, seps)!= "=") return -2;
	if (my_C_tokenizer(file, seps)!= "texture") return -2;
	if (my_C_tokenizer(file, seps)!= "{") return -2;

	tok=my_C_tokenizer(file, seps);
	if (tok=="") return -2;

	while (tok!="}" && exit_status==0) {
		if (tok=="pigment") {
			tok=my_C_tokenizer(file, seps);
			if (tok!="{") return -2;

			// Here is where we decide if we have color or textures
			tok=my_C_tokenizer(file, seps);
	
			if (tok=="color") {
				exit_status=read_material_povray(file);
				//break;
			}
			else if (tok=="image_map") {
				texture=new Texture();
				exit_status=texture->read_texture_povray(file, path);
				if (exit_status) {
					delete texture;
					texture=NULL;
				}
				//break;
			} else return -2;
		}
		else 
		{ // this is a section we do not how to process: read from -{- to -}-
				
			tok=my_C_tokenizer(file, seps);
			if (tok!="{") return -2;
			stack=1;
			while (stack>0) {
				tok=my_C_tokenizer(file, seps);
				if (tok=="") return -2;				
				if (tok=="{") stack++;
				else if (tok=="}") stack--;
			}
		}
		
		tok=my_C_tokenizer(file, seps);
		if (tok=="") return -2;				
	}

	if (exit_status==0)	
	{
		setMaterialName((char *)mid.data());
	}

	return 0;
}


// Returns true if the object has a valid texture (has loaded an image)
bool Material::has_texture() {

	return (texture!=NULL && !texture->getTextureFileName(NULL));
}


// Reads the material properties
int Material::read_material_povray(std::ifstream & file)
{
	std::string tok;
	static char seps[]="{,<>}=";
	float pigment_color[4]={0.0f,0.0f,0.0f,1.0f}, finish_ambient[4]={0.1f,0.1f,0.1f,1.0f},
		finish_phong=0.0, finish_phong_size=40 ;
	float gray[4], black[4]={0.0f,0.0f,0.0f,1.0f}, k;
	int finish_metallic=0, i;


	if (read_povray_color(file, pigment_color)) return -2;
	tok=my_C_tokenizer(file, seps);
	if (tok!="}") return -2;

	tok=my_C_tokenizer(file, seps);
	if (tok!="finish") return -2;

	tok=my_C_tokenizer(file, seps);
	if (tok!="{") return -2;
	// 	three options: ambient, phong, metalic
	tok=my_C_tokenizer(file, seps);
	if (tok=="") return -2;
	while (tok!="}") {
		if (tok=="ambient") {
			if (read_povray_color(file, finish_ambient)) return -2;
		} else if (tok=="phong") 
		{
			tok=my_C_tokenizer(file, seps);
			if (tok=="") return -2;
			finish_phong=(float)atof(tok.data());
			tok=my_C_tokenizer(file, seps);
			if (tok=="}") continue; 
			else if (tok!="phong_size") return -2;
			tok=my_C_tokenizer(file, seps);
			if (tok=="}") continue;
			else if (tok=="") return -2;
			finish_phong_size=(float)atof(tok.data());
		} else if (tok=="metallic") 
				finish_metallic=1;				
		tok=my_C_tokenizer(file, seps);
		if (tok=="") return -2;
	}

	/* Everything read correctly. Now we translate PovRay -> OpenGL */
	/* See Material::write_povray for explanation */

	setAmbientColor(finish_ambient);
	setDiffuseColor(pigment_color);
	setShininess((finish_phong_size-1)*128/249);
	

	if (finish_metallic) {
		if (pigment_color[0]+pigment_color[1]+pigment_color[2] < 0.01) 
			setSpecularColor(black);
		else {
			k=(float)(finish_phong/(0.299*pigment_color[0]+0.587*pigment_color[1]+0.114*pigment_color[2]));
			for (i=0; i<3; i++) {
				pigment_color[i]*=k;
				if (pigment_color[i]<0.0f) pigment_color[i]=0.0f;
				else if (pigment_color[i]>1.0f) pigment_color[i]=1.0f;
			}
			setSpecularColor(pigment_color);
		}
	}
	else {
		for (i=0; i<3; i++) gray[i]=finish_phong;
		gray[3]=0.0f;
		setSpecularColor(gray);
	}
	setEmissiveColor(black);

	return 0;
}


void Material::setTexture(Texture* t)
{
	if (texture != NULL)
		delete texture;
	texture = t;
}

Texture* Material::getTexture()
{
	return texture;
}


// Reads the properties of the material from a .MTL Wavefront file
// 0: OK, -1: EOF, -2: Syntax error -3: Texture file format not supported
// Need the path where the .mtl is (or better, where the textures are). If there
// is no texture in the mtl file, the second argument is not used
int Material::read_mtl(std::ifstream & file, char *path) {
	
	char buffer[512];
	float color[4], *pcolor;

	// newmtl

	while (1) {
		if (readTrimmedLine(file, buffer, sizeof(buffer))) return -1;
		// Comment
		if (buffer[0]=='#') continue;   
		// Blank line
		if (buffer[0]==0) continue;   
		if (strncmp("newmtl ", buffer, 7)) 
			return -2;
		else 
			break;
	}

	setMaterialName(buffer+7);

	// Establising the Wavefront MTL default properties
	// See http://zoo.cs.yale.edu/classes/cs490/00-01a/mcnamara.antoine.amm43/mtl.html

	color[0]=color[1]=color[2]=0.2f;
	color[3]=1.0f;
	setAmbientColor(color);

	color[0]=color[1]=color[2]=0.8f;
	setDiffuseColor(color);


	color[0]=color[1]=color[2]=1.0f;
	setSpecularColor(color);

	color[0]=color[1]=color[2]=0.0f;
	setEmissiveColor(color);

	setShininess(0.0f);
	setTexture(NULL);

	// Keep on reading until finding a blank line or a "newmtl"
	
	int last_position=file.tellg();

	while (!readTrimmedLine(file, buffer, sizeof(buffer)) && buffer[0] && strncmp(buffer, "newmtl ", 7)) {
		switch (buffer[0]) {
			case 'K':
				if (sscanf(buffer+2, "%f %f %f", color, color+1, color+2)!=3) return -2;
				switch (buffer[1]) {
				case 'a':
					setAmbientColor(color);
					break;
				case 'd':
					setDiffuseColor(color);
					break;
				case 's':
					setSpecularColor(color);
					break;
				default:
					return -2;
				}
				break;
			case 'N':
				if (sscanf(buffer+2, "%f", color)!=1) return -2;
				setShininess(color[0]*128.0f/1000.0f);
				break;
			case 'd':
				if (sscanf(buffer+2, "%f", color+3)!=1) return -2;
				pcolor = getAmbientColor();
				pcolor[3]=color[3];
				setAmbientColor(pcolor);
				pcolor = getSpecularColor();
				pcolor[3]=color[3];
				setSpecularColor(pcolor);
				pcolor = getDiffuseColor();
				pcolor[3]=color[3];
				setDiffuseColor(pcolor);
				break;
			case 'm':
				{
					Texture *tmp;
					char dest[MAXPATHLENGTH];

					if (!strncmp(buffer, "map_d", 5)) break; // transparency map, not handled
					if (strncmp(buffer, "map_K", 5)) return -2;
					
					strcpy(dest, buffer+7);

					// first check the name in the mtl file
					if (!Texture::isFileAcceptable(dest)) {
						// try in the provided path
						buildPathName(dest, path, buffer+7);
						if (!Texture::isFileAcceptable(dest)) {
							danceInterp::OutputMessage("Texture file %s not found or format not supported\n", dest);
							return -3;
						}
					}
                    tmp=new Texture(dest);
					setTexture(tmp);
				}
				break;
			case 'i': // illum
				break ;
			default:
				return -2;
		}
		last_position=file.tellg();

	}
	// if the last line was the definition of a new material, rewind the file
	if (!strncmp(buffer, "newmtl ", 7)) 
		file.seekg(last_position);

	return 0;
}



// Writes the object properties to the file in MTL Wavefront format
int Material::write_mtl(std::ofstream & file) {
	char tfn[MAXPATHLENGTH];

	file << "newmtl " <<  getMaterialName() << "\n";
	file << "Ka " << ambientColor[0] << " " << ambientColor[1] << " " << ambientColor[2] << "\n";
	file << "Kd " << diffuseColor[0] << " " << diffuseColor[1] << " " << diffuseColor[2] << "\n";
	file << "Ks " << specularColor[0] << " " << specularColor[1] << " " << specularColor[2] << "\n";
	file << "d " << (specularColor[3]+diffuseColor[3]+ambientColor[3])/3.0f << "\n";
	file << "Ns " << getShininess() / 128.0 * 1000.0 << "\n";
	
	if (has_texture()) {
		this->texture->getTextureFileName(tfn);
		file << "map_Ka " << tfn << "\n";
	}
	
	file << "\n";
	return 0;
}


/* Reads the properties from an "Appearance" node of a VRML file. 
We suppose that "appearance Appearance" has already been read */
int Material::read_vrml(std::ifstream &file) {
	std::string tok;
    
	if (my_VRML_tokenizer(file, seps)!="{") {
		danceInterp::OutputMessage("Parse error: expected { for Appearance node.\n");
		return DANCE_ERROR;
	}

	tok=my_VRML_tokenizer(file, seps);
	while (tok!="}" && tok!="") {
        if (tok=="material") {
			if (DANCE_ERROR == parseMaterialNode(file)) 
				return DANCE_ERROR;
		}
		else if (tok=="texture") {
			if (DANCE_ERROR == parseTextureNode(file))
				return DANCE_ERROR;
		}
		tok=my_VRML_tokenizer(file, seps);
	}

	if (tok!="}") {
		danceInterp::OutputMessage("Error parsing Appearance node. Expect }\n");	
		return DANCE_ERROR;
	}

	return DANCE_OK;
}

int Material::parseMaterialNode(std::ifstream &file)
{
	std::string tok;
	float tmp[4];

	tok=my_VRML_tokenizer(file, seps);
	if (tok=="DEF") { // Parse definition label.
		tok=my_VRML_tokenizer(file, seps); // definition name.
		tok=my_VRML_tokenizer(file, seps); // read next token.
	}
	else if (tok=="USE") {
		tok=my_VRML_tokenizer(file, seps); // definition name.
		danceInterp::OutputMessage("Warning: ignoring USE instance of material.");
		return(DANCE_OK);
	}

	if (tok!="Material") {
		danceInterp::OutputMessage("Parse error: expected Material keyword for material node.\n");
		return DANCE_ERROR;
	}
	
	if (my_VRML_tokenizer(file, seps)!="{") {
		danceInterp::OutputMessage("Parse error: expected { for Material\n"); 
		return DANCE_ERROR;
	}

	tmp[3]=1.0f;

	tok=my_VRML_tokenizer(file, seps);
	while (tok!="}"  && tok!="") {
		if (tok=="diffuseColor") {
			for (int i=0;i<3;i++) {
				if ((tok=my_VRML_tokenizer(file, seps))=="") {
					danceInterp::OutputMessage("Parse error reading Material\n"); 
					return DANCE_ERROR;
				}
				tmp[i]=(float)atof(tok.c_str());
			}
			setDiffuseColor(tmp);
		}	

		if (tok=="ambientIntensity") {
			if ((tok=my_VRML_tokenizer(file, seps))=="") {
				danceInterp::OutputMessage("Parse error reading Material\n"); 
				return DANCE_ERROR;
			}
			tmp[0]=tmp[1]=tmp[2]=(float)atof(tok.c_str());
			setAmbientColor(tmp);
		}

		if (tok=="specularColor") {
			for (int i=0;i<3;i++) {
				if ((tok=my_VRML_tokenizer(file, seps))=="") {
					danceInterp::OutputMessage("Parse error reading Material\n"); 
					return DANCE_ERROR;
				}
				tmp[i]=(float)atof(tok.c_str());
			}
			setSpecularColor(tmp);
		}

		if (tok=="emissiveColor") {
			for (int i=0;i<3;i++) {
				if ((tok=my_VRML_tokenizer(file, seps))=="") {
					danceInterp::OutputMessage("Parse error reading Material\n"); 
					return DANCE_ERROR;
				}
				tmp[i]=(float)atof(tok.c_str());
			}
			setEmissiveColor(tmp);
		}
			
		if (tok=="shininess") {
			if ((tok=my_VRML_tokenizer(file, seps))=="") {
				danceInterp::OutputMessage("Parse error reading Material\n"); 
				return DANCE_ERROR;
			}
			setShininess((float)atof(tok.c_str()));
		}

		if (tok=="transparency") {
			if ((tok=my_VRML_tokenizer(file, seps))=="") {
				danceInterp::OutputMessage("Parse error reading Material\n"); 
				return DANCE_ERROR;
			}
			
			float transparency;
			transparency=(float)atof(tok.c_str());

			ambientColor[3]=diffuseColor[3]=tmp[3]=1.0f-transparency;
		}

		tok=my_VRML_tokenizer(file, seps);
	}

	if (tok!="}") {
		danceInterp::OutputMessage("Error parsing Material.\n");
		return DANCE_ERROR;
	}

	return DANCE_OK;
}



int Material::parseTextureNode(std::ifstream &file) {
	std::string tok;

	tok=my_VRML_tokenizer(file, seps);
	if (tok=="ImageTexture") {
		// Parsing image texture
		if (my_VRML_tokenizer(file, seps)!="{") {
			danceInterp::OutputMessage("Parser error in imageTexture node.\n");
			return DANCE_ERROR;
		}

		tok=my_VRML_tokenizer(file, seps);
		if (tok=="url") {
			char filename[300], car;
			// Read until encounter first quote.
			do {
				file.get(car);
			} while (car != '\"');
			// Read in characters until next quote.
			file.get(car);
			int count = 0;
			while (car != '\"') {
				filename[count++] = car;
				file.get(car);
			}
			filename[count] = '\0';
		}

		// Read until close quote or end of file.
		tok=my_VRML_tokenizer(file, seps);
		while (tok!="}" && tok!="") 
			tok=my_VRML_tokenizer(file, seps);

		if (tok!="}") 
			return DANCE_ERROR;
	}

	return DANCE_OK;
}

void Material::setCurrentMaterial(Material* m)
{
        Material::sCurrentMaterial = m;
}

Material* Material::getCurrentMaterial()
{
        return Material::sCurrentMaterial;
}

