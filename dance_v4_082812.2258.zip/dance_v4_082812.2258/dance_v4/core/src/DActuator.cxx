/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include <cstdlib>
#include "defs.h"
#include "DActuator.h"
#include "dance.h"
#include "DObjectList.h"
#include "danceInterp.h"
#include "ViewManager.h"
#include "PlugIn.h"

DActuator::DActuator() : PlugIn(), isEnabled( true )
{
	isAppliedAll = false;
	setBaseType("actuator");
}

int DActuator::commandPlugIn(int argc, char **argv)
{
    int ret = PlugIn::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

    if (strcmp(argv[0], "apply") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("USAGE:apply <all|objectName>") ;
			return DANCE_ERROR;
		}
		else if (strcmp(argv[1],"all") == 0)
		{
			setAppliedAllObjects(true);
			return DANCE_OK ;
		}
		else if (strcmp(argv[1],"none") == 0)
		{
			setAppliedAllObjects(false);
			return DANCE_OK ;
		}
		else 
		{
			DSystem* system = (DSystem*) dance::AllSystems->get(argv[1]);
			if (system != NULL)
			{
				setAppliedObject(system);
				danceInterp::OutputMessage("Actuator %s now applies to system %s", this->getName(), system->getName());
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("No system with name %s found", argv[1]);
				return DANCE_OK;
			}
		}	
    }
    else if( strcmp(argv[0], "remove") == 0	)
    {
		if( argc != 2 )
		{
			danceInterp::OutputMessage("Expected: remove <object name>\n") ;
			return DANCE_ERROR;
		}
		DSystem* system = dynamic_cast<DSystem*>(dance::AllSystems->get(argv[1]));
			
		if (system == NULL)
		{
			danceInterp::OutputMessage("No system with name %s found", argv[1]);
			return DANCE_OK;
		}
		else
		{
       		removeAppliedObject(system) ;
			return DANCE_OK ;
		}
    }
    
    return DANCE_CONTINUE;
}

void DActuator::ExertLoad(DSystem *sys, DSimulator* sim, double time, double dt, double *state, double *dstate)
{
}

void DActuator::setAppliedAllObjects(bool val)
{
	this->isAppliedAll = val;
}

bool DActuator::isAppliedAllObjects()
{
	return this->isAppliedAll;
}


int DActuator::getNumAppliedObjects()
{
	return appliedObjects.size();
}

DSystem* DActuator::getAppliedObject(int val)
{
	if (appliedObjects.size() > (unsigned int) val)
		return appliedObjects[val];
	else
		return NULL;
}

void DActuator::setAppliedObject(DSystem* obj)
{
	bool found = false;
	for (std::vector<DSystem*>::iterator iter = appliedObjects.begin(); iter != appliedObjects.end(); iter++)
	{
		if ((*iter) == obj)
		{
			found = true;
			break;
		}
	}
	if (!found)
	{
		appliedObjects.push_back(obj);
		this->addDependency(obj);
	}
}

void DActuator::removeAppliedObject(DSystem* sys) 
{
	for (std::vector<DSystem*>::iterator iter = appliedObjects.begin(); iter != appliedObjects.end(); iter++)
	{
		if ((*iter) == sys)
		{
			appliedObjects.erase(iter);
			this->removeDependency(sys);
			break;
		}
	}
}

bool DActuator::isInApplyList(DSystem* sys) 
{
	for (std::vector<DSystem*>::iterator iter = appliedObjects.begin(); iter != appliedObjects.end(); iter++)
	{
		if ((*iter) == sys)
		{
			return true;
		}
	}

	return false;
}

void DActuator::onDependencyRemoval(DObject* object)
{
	DSystem* sys = dynamic_cast<DSystem*>(object);
	if (sys != NULL)
	{
		if (this->isInApplyList(sys))
		{
			// remove from the applied list and remove the dependency
			for (std::vector<DSystem*>::iterator iter = appliedObjects.begin(); iter != appliedObjects.end(); iter++)
			{
				if ((*iter) == sys)
				{
					appliedObjects.erase(iter);
					this->removeDependency(sys);
					break;
				}
			}
		}
	}
}

void DActuator::save(int mode, std::ofstream& file)
{
	PlugIn::save(mode, file);

	char buff[512];

	if (mode == 0)
	{
	}
	else if (mode == 1)
	{
		// apply all
		if (this->isAppliedAllObjects())
		{
			sprintf(buff, "\"apply\", \"all\"");
			pythonSave(file, buff);
		}

		// apply to individual objects
		for (int x = 0; x < this->getNumAppliedObjects(); x++)
		{
			DObject* obj = this->getAppliedObject(x);
			sprintf(buff, "\"apply\", \"%s\"", obj->getName());
			pythonSave(file, buff);
		}
	}
}

void DActuator::enable( void )
{
	isEnabled = true;
}

void DActuator::disable( void )
{
	isEnabled = false;
}
