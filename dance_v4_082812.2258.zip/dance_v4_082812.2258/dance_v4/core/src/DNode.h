#ifndef _INPUT_H
#define _INPUT_H

#include "defs.h"
#include <vector>

class DInput;
class DOutput;

class DLLENTRY DNode
{
	public:	
		DNode();
		~DNode();

		virtual void addInput(DInput* input, int index);
		virtual DInput* getInput(int index);
		virtual DInput* getInput(std::string name);
		std::vector<DInput*>& getInputs();
		virtual void addOutput(DOutput* input, int index);
		virtual DOutput* getOutput(int index);
		virtual DOutput* getOutput(std::string name);
		std::vector<DOutput*>& getOutputs();

		virtual void evaluate();

		virtual void setDirty(bool val);
		virtual bool isDirty();

	protected:
		std::vector<DInput*> m_inputs;
		std::vector<DOutput*> m_outputs;
		bool m_dirty;
};

class DPipe
{
	public:
		DPipe(std::string name);
		void setNode(DNode* node);
		DNode* getNode();

		std::string getPipeName();

	protected:
		std::string m_name;
		DNode* m_node;
};

class DLLENTRY DInput : public DPipe
{
	public:	
		DInput(std::string name);
		~DInput();

		void setOutput(DOutput* output);
		DOutput* getOutput();

	private:
		DOutput* m_output;
	
};

class DLLENTRY DOutput : public DPipe
{
	public:	
		DOutput(std::string name);
		~DOutput();

		void setInput(DInput* input);
		DInput* getInput();

	private:
		DInput* m_input;

	
};

class DLLENTRY DBoolInput : public DInput
{
	public:	
		DBoolInput(std::string name);
		~DBoolInput();

		bool getNodeValue();
		void setNodeValue(bool val);

	private:
		bool m_nodeValue;
};

class DLLENTRY DBoolOutput : public DOutput
{
	public:	
		DBoolOutput(std::string name);
		~DBoolOutput();

		bool getNodeValue();
		void setNodeValue(bool val);

	private:
		bool m_nodeValue;
};


class DLLENTRY DBoolNode : public DNode
{
	public:	
		DBoolNode();
		~DBoolNode();

		virtual void evaluate();

	private:
		bool m_value;
		DBoolInput* m_in;
		DBoolOutput* m_out;

};

class DLLENTRY DOrNode : public DNode
{
	public:	
		DOrNode();
		~DOrNode();

		virtual void evaluate();

	private:
		bool m_value;
		DBoolInput* m_in1;
		DBoolInput* m_in2;
		DBoolOutput* m_out;

};






#endif