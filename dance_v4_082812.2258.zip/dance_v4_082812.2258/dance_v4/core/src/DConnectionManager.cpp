#include "DConnectionManager.h"
#include "DObject.h"

DConnectionManager::DConnectionManager()
{
	for (int c = 0; c < m_connections.size(); c++)
	{
		delete m_connections[c];
	}
}

DConnectionManager::~DConnectionManager()
{
}

DConnection* DConnectionManager::makeConnection(DObject* from, std::string type, DObject* to)
{
	if (!from || !to)
	{
		return NULL;
	}

	// make sure that this connection doesn't already exist
	for (std::vector<DConnection*>::iterator iter = m_connections.begin();
		iter != m_connections.end();
		iter++)
	{
		if ((*iter)->getType() == type)
		{
			if ((*iter)->getFrom() == from && (*iter)->getTo() == to)
			{
				return NULL;
			}
		}
	}

	DConnection* conn = new DConnection();
	conn->setFrom(from);
	conn->setType(type);
	conn->setTo(to);
	addConnection(conn);

	// notify the objects involved
	from->onConnect(conn);
	to->onConnect(conn);

	return conn;
}

bool DConnectionManager::removeConnection(DObject* from, std::string type, DObject* to)
{
	if (!from || !to)
		return false;

	for (std::vector<DConnection*>::iterator iter = m_connections.begin();
		iter != m_connections.end();
		iter++)
	{
		if ((*iter)->getType() == type)
		{
			if ((*iter)->getFrom() == from && (*iter)->getTo() == to)
			{
				(*iter)->getFrom()->onDisconnect((*iter));
				(*iter)->getTo()->onDisconnect((*iter));
				m_connections.erase(iter);
				return true;
			}
		}
	}

	return false;
}

bool DConnectionManager::removeConnection(DConnection* connection)
{
	for (std::vector<DConnection*>::iterator iter = m_connections.begin();
		iter != m_connections.end();
		iter++)
	{
		if ((*iter) == connection)
		{
			(*iter)->getFrom()->onDisconnect((*iter));
			(*iter)->getTo()->onDisconnect((*iter));
			m_connections.erase(iter);
			return true;
		}
	}

	return false;
}

bool DConnectionManager::addConnection(DConnection* connection)
{
	// make sure that the connection can be made
	// check the connection info for constraints

	bool ok = true;

	if (ok)
	{
		m_connections.push_back(connection);
		return true;
	}
	else
	{
		return false;
	}
}

void DConnectionManager::getConnections(DObject* object, std::vector<DConnection*>& list)
{
	// for faster access, this code should be replaced with a map
	for (int c = 0; c < m_connections.size(); c++)
	{
		if (m_connections[c]->getFrom() == object || m_connections[c]->getTo() == object)
			list.push_back(m_connections[c]);
	}
}

void DConnectionManager::getConnections(std::string type, std::vector<DConnection*>& list)
{
	// for faster access, this code should be replaced with a map
	for (int c = 0; c < m_connections.size(); c++)
	{
		if (m_connections[c]->getType() == type)
			list.push_back(m_connections[c]);
	}
}

void DConnectionManager::getFromConnections(std::string type, DObject* fromObject, std::vector<DConnection*>& list)
{
	// for faster access, this code should be replaced with a map
	for (int c = 0; c < m_connections.size(); c++)
	{
		if (m_connections[c]->getType() == type)
			if (fromObject == m_connections[c]->getFrom())
				list.push_back(m_connections[c]);
	}
}

void DConnectionManager::getToConnections(std::string type, DObject* toObject, std::vector<DConnection*>& list)
{
	// for faster access, this code should be replaced with a map
	for (int c = 0; c < m_connections.size(); c++)
	{
		if (m_connections[c]->getType() == type)
			if (toObject == m_connections[c]->getTo())
				list.push_back(m_connections[c]);
	}
}

