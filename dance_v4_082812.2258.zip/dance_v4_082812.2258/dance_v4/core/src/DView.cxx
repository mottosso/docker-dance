/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "DView.h"
#include <iostream>
//#include <fltk/glut.h>
//#include <FL/gl.h>

#include "opengl.h"



//#include <GL/glu.h>
#include "GLutilities.h"
#include "defs.h"
#include <cstdlib>
#include "dance.h"
#include "danceInterp.h"

#include "ViewManager.h"
#include "Quaternion.h"
#include "BoundingBox.h"
#include "DanceWindow.h"
#include "ViewWindow.h"
#include "DSimulatorManager.h"
#include "DLight.h"
#include "PlugIn.h"

using namespace fltk;

// DView:
//
DView::DView()
{
	 setBaseType("view");

       GridList = 0;
	Lights = 1;
	Solids = 1;
	Shadows	= 0;
	setShading(SHADE_SMOOTH);
	BackgroundColor[0] = .63f;
	BackgroundColor[1] = .63f;
	BackgroundColor[2] = .63f;
	BackgroundColor[3] = 1.0f;

	m_shadowMapSize = 1024;

	// Initialize view data	members.
	Modelview = new	double[16];
	for (int x = 0; x < 16; x++)
	{
		Modelview[x] = 0.0;
		if (x == 0 || x == 5 || x == 10 || x == 15)
			Modelview[x] = 1.0;
	}
	Projection = new double[16];
	for (int x = 0; x < 16; x++)
	{
		Projection[x] = 0.0;
		if (x == 0 || x == 5 || x == 10 || x == 15)
			Projection[x] = 1.0;
	}

	m_lightProjectionMatrix = new double[16];
	for (int x = 0; x < 16; x++)
	{
		m_lightProjectionMatrix[x] = 0.0;
		if (x == 0 || x == 5 || x == 10 || x == 15)
			m_lightProjectionMatrix[x] = 1.0;
	}
	m_lightViewMatrix = new double[16];
	for (int x = 0; x < 16; x++)
	{
		m_lightViewMatrix[x] = 0.0;
		if (x == 0 || x == 5 || x == 10 || x == 15)
			m_lightViewMatrix[x] = 1.0;
	}


	setBaseType("view");
	setType("view");

	setFrameNumber(1);
	strcpy(m_DumpDirectory, ".") ;
	m_HalfSizeCom[0] = '\0' ;
	strcpy(m_DumpFileName, "f") ;
	setDumped(false);

	init_antialiasing();
	setListInitted(false);
	setGrid(true);
	prevDepth = 1.0;
	setFOV(45.0);
	m_viewWindow = NULL;
	this->setDumped(false);
	setGridSize(20.0);
	setGridStep(2.0);
	setGridColor((float) .5, (float) .5, (float) .5);
	setGridHighlightColor((float) 0.0, (float) 0.0, (float) 0.0);
	setShowStats(false);
	ball = new ArcBall();
	setProjectionType(VIEW_PERSP);
	startFPS();

	setNear(.001);
	setFar(1000);
	m_dollyRate = this->createDoubleAttribute("dollyrate", .1, false, "Camera Params", 10);
	m_panRate = this->createDoubleAttribute("panrate", .001, false, "Camera Params", 10);
	m_zoomRate = this->createDoubleAttribute("zoomrate", .01, false, "Camera Params", 10);

	setNeedsReset(true);
	setUseAnaglyph(false);
	m_changed = true;
	m_cameraMoved = true;
}

// DView:
//	NOTE: Cannot call a constructor	within a constructor.
//
DView::DView( char *name, int x, int y, int width, int height)
{
	 setBaseType("view");
        GridList = 0;
	setName(name);
	Lights = 1;
	Solids = 1;
	Shadows	= 0;
	setShading(SHADE_SMOOTH);
	BackgroundColor[0] = .63f;
	BackgroundColor[1] = .63f;
	BackgroundColor[2] = .63f;
	BackgroundColor[3] = 1.0f;

	// Initialize view data	members.
	Modelview = new	double[16];
	for (int x = 0; x < 16; x++)
	{
		Modelview[x] = 0.0;
		if (x == 0 || x == 5 || x == 10 || x == 15)
			Modelview[x] = 1.0;
	}
	Projection = new double[16];
	for (int x = 0; x < 16; x++)
	{
		Projection[x] = 0.0;
		if (x == 0 || x == 5 || x == 10 || x == 15)
			Projection[x] = 1.0;
	}

	m_lightProjectionMatrix = new double[16];
	for (int x = 0; x < 16; x++)
	{
		m_lightProjectionMatrix[x] = 0.0;
		if (x == 0 || x == 5 || x == 10 || x == 15)
			m_lightProjectionMatrix[x] = 1.0;
	}
	m_lightViewMatrix = new double[16];
	for (int x = 0; x < 16; x++)
	{
		m_lightViewMatrix[x] = 0.0;
		if (x == 0 || x == 5 || x == 10 || x == 15)
			m_lightViewMatrix[x] = 1.0;
	}

	m_shadowMapSize =1024;

	setBaseType("view");
	setType("view");

	setFrameNumber(1);
	strcpy(m_DumpDirectory, ".") ;
	m_HalfSizeCom[0] = '\0' ;
	strcpy(m_DumpFileName, "f") ;
	setDumped(false);

	init_antialiasing();
	setListInitted(false);
	setGrid(true);
	setShowName(true);
	prevDepth = 1.0;

	setMode(MODE_NONE);
	setFOV(45.0);
	m_viewWindow = NULL;
	setGridSize(20.0);
	setGridStep(2.0);
	setGridColor((float) .5, (float) .5, (float) .5);
	setGridHighlightColor((float) .0, (float) .0, (float) .0);
	setShowStats(false);
	ball = new ArcBall();
	setProjectionType(VIEW_PERSP);
	startFPS();

	setNear(.001);
	setFar(1000);

	m_dollyRate = this->createDoubleAttribute("dollyrate", .1, false, "Camera Params", 10);
	m_panRate = this->createDoubleAttribute("panrate", .001, false, "Camera Params", 10);
	m_zoomRate = this->createDoubleAttribute("zoomrate", .01, false, "Camera Params", 10);

	setNeedsReset(true);
	setUseAnaglyph(false);

}

// ~View:
//	Destructor for View
DView::~DView()
{
	if (ball) delete ball;
	if (Modelview) delete [] Modelview;
	if (Projection)	delete [] Projection;
	if (m_lightProjectionMatrix) delete [] m_lightProjectionMatrix;
	if (m_lightViewMatrix)	delete [] m_lightViewMatrix;


	// disable all Callbacks
	if (dance::AllViews->isQuadView() || dance::AllViews->getViewFocus() == this)
	{
	   glFinish(); // Flush out any OpenGL calls in pipe.	   
	}

	if (m_viewWindow != NULL)
		delete m_viewWindow;
}

// adjustArcballCamera:
//	Adjust ball associated with the view	by using the given coords.
//	NOTE: This only works for the perspective camera view.
//
//	coords:	Coordinates for	ball->
//
void DView::adjustArcballCamera(HVect coords)
{
	if (getProjectionType() == VIEW_PERSP) {
 		ball->mouse(coords);
		ball->update();
		m_cameraMoved = true;
	}
}

// adjustArcballCircle:
//	Adjusts	centre and radius of ball circle
//
//	x,y: centre of ball
//	radius:	radius of ball
//
void DView::adjustArcballCircle(double x, double y, double radius)
{
	HVect coords; coords.x = (float)x; coords.y = (float)y;
	ball->place(coords, radius);
}

//
// AttachCamera:
//	Attach cameras to quadview. Must create	windows	first.
//	Builds the viewing and projection matrices.
//
void DView::AttachCamera(BoundingBox *box)
{
	if (box == NULL) 
		setCamera(SCALE_FOR_BB,-100.0,-100.0,-100.0,100.0,100.0,100.0);
	else 
		setCamera(SCALE_FOR_BB,box->xMin,box->yMin,box->zMin,
							   box->xMax,box->yMax,box->zMax);
	postRedisplay();

	m_cameraMoved = true;
}

// beginInteraction:
//	Begins an interactive session with the window.
//
//	mode:	Type of	edit mode
//
void DView::beginInteraction(int mode)
{
	switch(mode) {
	   case	camera_arcball:
		ball->beginDrag();
	   break;
	}
}

// usage:
//
void DView::usage()
{
	danceInterp::OutputMessage("USAGE:	view <name>\n"
		"create	persp|top|front|right <x> <y> <width> <height>\n"
		"|pan <x> <y>\n"
		"|target <x> <y> <z>\n"
		"|ball <x> <y>\n"
		"|distance <dist>\n"
		"|clipBounds <left> <right> <bottom> <top> <near> <far>\n"
		"|dump\n"
		"|refresh\n"
		"|background <r> <g> <b> <a> >\n"
		"|lights on|off\n"
		"|-postscript <filename>\n"
		"|shadows on|off\n"
		"|solids on|off\n"
		"|projection persp|ortho <left> <right> <bottom> <top> <near> <far>\n");
}

// Command:
//
int DView::commandPlugIn(int argc, char **argv)
{
	int ret = DObject::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

	char resultString[256];

	if (argc == 0) {
		usage();
		return DANCE_ERROR;
	}
	if (strcmp(argv[0],"background") == 0) {
		if (argc == 1) { // retrieve background colour
			float color[4];
			getBackgroundColor(color);
			sprintf(resultString,"%f",color[0]);
			danceInterp::OutputListElement(resultString);
			sprintf(resultString,"%f",color[1]);
			danceInterp::OutputListElement(resultString);
			sprintf(resultString,"%f",color[2]);
			danceInterp::OutputListElement(resultString);
			sprintf(resultString,"%f",color[3]);
			danceInterp::OutputListElement(resultString);

			if (this->m_viewWindow != NULL)
				this->m_viewWindow->updateGUI();
			return DANCE_OK;
		}
		else if (argc != 5) {
		   danceInterp::OutputMessage("background <r> <g> <b> <a>\n");
		   return(DANCE_ERROR);
		}
		setBackgroundColor((float)atof(argv[1]),(float)atof(argv[2]),
				   (float)atof(argv[3]),(float)atof(argv[4]));
		postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0],"antialiasing") == 0)
	{
		if (argc != 2)
		{
			danceInterp::OutputMessage("antialiasing <jitter_times>\n");
			return(DANCE_ERROR);
		}
		else {
		  jitter_times = atoi (argv[1]);
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[0],"projtype") == 0) {
		if (argc == 1) {
			if (getProjectionType() == VIEW_PERSP) strcpy(resultString,"persp");
			if (getProjectionType() == VIEW_TOP) strcpy(resultString,"top");
			if (getProjectionType() == VIEW_RIGHT) strcpy(resultString,"right");
			if (getProjectionType() == VIEW_FRONT) strcpy(resultString,"front");
			danceInterp::OutputResult("%s", resultString);
		}
		else {
			if (strcmp(argv[1],"persp") == 0) {
				setProjectionType(VIEW_PERSP);
			}
			else if (strcmp(argv[1],"top") == 0) setProjectionType(VIEW_TOP);
			else if (strcmp(argv[1],"front") == 0) setProjectionType(VIEW_FRONT);
			else if (strcmp(argv[1],"right") == 0) setProjectionType(VIEW_RIGHT);
			resetCamera();
			this->resetLights();
		}
		return DANCE_OK;
	}
/*	else if	(strcmp(argv[0],"create") == 0 ){
		if (argc != 6) {
			danceInterp::OutputMessage("create	",
			"<persp|top|right|front> <x> <y> <width> <height>\n");
			return DANCE_ERROR;
		}
		create(getName(),argv[1],atoi(argv[2]),atoi(argv[3]),
				atoi(argv[4]),atoi(argv[5]));
	}
*/
	else if	(strcmp(argv[0],"dump")	== 0) 
	{
	    if( argc < 2) 
	    {
			this->SaveFrame();
			return DANCE_OK ;
	    }

	    int count = 1 ;
	    while(count <= argc-1)
	    {
			if( strcmp(argv[count], "start") == 0 )
			{
				setDumped(true);
				count++;
				danceInterp::OutputMessage("%s will start screen rendering to folder %s...", this->getName(), this->getDumpDirectory());
				return DANCE_OK;
			}
			else if( strcmp(argv[count], "stop") == 0 )
			{
				danceInterp::OutputMessage("%s will stop screen rendering to folder %s...", this->getName(), this->getDumpDirectory());
				setDumped(false);
				count++ ;
				return DANCE_OK;
			}
			else if( strncmp(argv[count], "-f",2) == 0 )
			{
				if(argv[count][2] != '\0')
				{
					strcpy(m_DumpFileName, &argv[count][2]) ;
					danceInterp::OutputMessage("%s will now use filename %s....", this->getName(), this->getFileName());
					return DANCE_OK;
				}
				else
				{
					danceInterp::OutputMessage("usage: -f<fname> (no space between)") ;
					return DANCE_ERROR;
				}
			}
			else if( strncmp(argv[count], "-d",2) == 0 )
			{
				if(argv[count][2] != '\0')
				{
					strcpy(m_DumpDirectory, &argv[count][2]) ;
					danceInterp::OutputMessage("%s will now use folder %s for screen renderings...", this->getName(), this->getDumpDirectory());
					return DANCE_OK;
				}
				else
				{
					danceInterp::OutputMessage("usage: -d<dname> (no space between)") ;
					return DANCE_ERROR;
				}
				count++ ;
			}
			else if( strncmp(argv[count], "-n",2) == 0 )
			{
				if(argv[count][2] != '\0')
				{
					setFrameNumber(atoi( &argv[count][2]));
					danceInterp::OutputMessage("%s will now start at frame number %d...", this->getName(), this->getFrameNumber());
					return DANCE_OK;
				}
				else
				{
					danceInterp::OutputMessage("usage: -n<number> (no space between)") ;
					return DANCE_ERROR;
				}
			}
			else
			{
				return DANCE_ERROR;
			}
	    }
	    return DANCE_ERROR;
	}
	else if (strcmp(argv[0],"fitview") == 0) {
		BoundingBox *box = dance::GetSceneBox();
		AttachCamera(box);
		this->resetLights();

		return DANCE_OK;
	}	
	else if (strcmp(argv[0],"geometry") == 0) {
		if (argc == 1) {
			sscanf(resultString,"%d %d %d %d\n",&X,&Y,
			       &Width, &Height) ;
			danceInterp::OutputResult("%s",resultString);
		}
		return DANCE_OK ;
	}
	else if	( (strcmp(argv[0],"refresh") == 0) || (strcmp(argv[0], "redisplay") == 0) )
	{
		postRedisplay();
	}
	else if	(strcmp(argv[0],"lights") == 0)	{
		if (argc == 1) {
			if (Lights) 
				danceInterp::OutputMessage("on");
			else
				danceInterp::OutputMessage("off");
			return DANCE_OK;
		}
		if (strcmp(argv[1],"on") == 0) {
		   Lights = 1;
		   danceInterp::OutputMessage("Lights are on.");
		}
		else {
		   Lights = 0;
		   danceInterp::OutputMessage("Lights are off.\n");
		}

		if (this->m_viewWindow != NULL)
			this->m_viewWindow->updateGUI();

		postRedisplay();
		return DANCE_OK;
	}
	else if	(strcmp(argv[0],"solids") == 0)
	{
		if (argc == 1) {
			if (Solids) 
				danceInterp::OutputMessage("on");
			else
				danceInterp::OutputMessage("off");
			return DANCE_OK;
		}
		if (strcmp(argv[1],"on") == 0) {
		   Solids = 1;
		   danceInterp::OutputMessage("Solids are on.\n");
		}
		else {
		   Solids = 0;
		   danceInterp::OutputMessage("Solids are off.\n");
		}

		if (this->m_viewWindow != NULL)
			this->m_viewWindow->updateGUI();

		postRedisplay();
		return DANCE_OK;
	}
	else if	(strcmp(argv[0], "shading") == 0)
	{
		if (argc == 1) {
			if (Shading == SHADE_FLAT) 
				danceInterp::OutputMessage("flat");
			else
				danceInterp::OutputMessage("smooth");
			return DANCE_OK;
		}
		if (strcmp(argv[1], "flat") == 0)
		{
		   setShading(SHADE_FLAT);
		   danceInterp::OutputMessage("Shading is now flat.\n");
		}
		if (strcmp(argv[1], "smooth") == 0)
		{
		   setShading(SHADE_SMOOTH);
		   danceInterp::OutputMessage("Shading is now smooth.\n");
		}
		if (this->m_viewWindow != NULL)
			this->m_viewWindow->updateGUI();

		postRedisplay();
		return DANCE_OK;
	}
	else if	(strcmp(argv[0],"shadows") == 0) {
		if (strcmp(argv[1],"on") == 0) {
		   Shadows = 1;
		   danceInterp::OutputMessage("Shadows are	on.\n");
		}
		else {
		   Shadows = 0;
		   danceInterp::OutputMessage("Shadows are	off.\n");
		}

		if (this->m_viewWindow != NULL)
			this->m_viewWindow->updateGUI();

		postRedisplay();
		return DANCE_OK ;
	}
	else if (strcmp(argv[0],"pan") == 0) {
		if (argc == 3) {
			Panx = atof(argv[1]);
			Pany = atof(argv[2]);
			postRedisplay();
		}
		else {
			sprintf(resultString,"%f",Panx);
			danceInterp::OutputListElement(resultString);
			sprintf(resultString,"%f",Pany);
			danceInterp::OutputListElement(resultString);
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[0],"ball") == 0) {
		if (argc == 3) {
			HVect arccoords;
			arccoords.x = (float)atof(argv[1]);
		    arccoords.y = (float)atof(argv[2]);
			adjustArcballCamera(arccoords);
			ball->beginDrag();
			ball->endDrag();
			postRedisplay();
		}
		else {
			sprintf(resultString,"%f",ball->getQuat()->x);
			danceInterp::OutputListElement(resultString);
			sprintf(resultString,"%f",ball->getQuat()->y);
			danceInterp::OutputListElement(resultString);
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[0],"orientation") == 0) {
		if (argc == 17) {
			float init[16];
			for (int i=0;i<16;i++)
				init[i] = (float)atof(argv[i+1]);
			ball->init(init);
			postRedisplay();
		}
		else {
			HMatrix mat;
			ball->value(mat);
			for (int i=0; i < 16; i++) {
				sprintf(resultString,"%f",((float *)mat)[i]);
				danceInterp::OutputListElement(resultString);
			}
		}
		this->resetLights();

		return DANCE_OK;
	}
	else if (strcmp(argv[0],"distance") == 0) {
		if (argc == 2) {
			dollyCameraDist(atof(argv[1]));
			postRedisplay();
		}
		else {
			sprintf(resultString,"%f",Dist);
			danceInterp::OutputResult(resultString);
		}
		this->resetLights();

		return DANCE_OK;
	}
	else if (strcmp(argv[0],"target") == 0) {
		if (argc == 4) {
			Target[0] = (float)atof(argv[1]);
			Target[1] = (float)atof(argv[2]);
			Target[2] = (float)atof(argv[3]);
			postRedisplay();
		}
		else {
			sprintf(resultString,"%f",Target[0]);
			danceInterp::OutputListElement(resultString);

			sprintf(resultString,"%f",Target[1]);
			danceInterp::OutputListElement(resultString);

			sprintf(resultString,"%f",Target[2]);
			danceInterp::OutputListElement(resultString);
		}
		this->resetLights();

		return DANCE_OK;
	}
	else if (strcmp(argv[0],"clipBounds") == 0) {
		if (argc == 7) {
			Left = atof(argv[1]);
			Right = atof(argv[2]);
			Bottom = atof(argv[3]);
			Top = atof(argv[4]);
			Near = atof(argv[5]);
			Far = atof(argv[6]);
			setProjection(Left,Right,Bottom, Top, Near, Far);
			this->resetLights();
			postRedisplay();
		}
		else {
			sprintf(resultString,"%f",Left);
			danceInterp::OutputListElement(resultString);
			sprintf(resultString,"%f",Right);
			danceInterp::OutputListElement(resultString);
			sprintf(resultString,"%f",Bottom);
			danceInterp::OutputListElement(resultString);
			sprintf(resultString,"%f",Top);
			danceInterp::OutputListElement(resultString);
			sprintf(resultString,"%f",Near);
			danceInterp::OutputListElement(resultString);
			sprintf(resultString,"%f",Far);
			danceInterp::OutputListElement(resultString);
		}

		return DANCE_OK;
	}
	else if (strcmp(argv[0], "fov") == 0)
	{
		double val = atof(argv[1]);
		fov = val;
		danceInterp::OutputMessage("Field of view is now %f...", fov);
		this->setProjection();
		this->resetLights();
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "stats") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: view %s stats <on|off>", this->getName());
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "on") == 0)
		{
			this->setShowStats(true);
			danceInterp::OutputMessage("View %s is now showing Stats.", this->getName());
		
		}
		else if (strcmp(argv[1], "off") == 0)
		{
			this->setShowStats(false);
			danceInterp::OutputMessage("View %s is now showing Stats.", this->getName());
		}
		else
		{
			danceInterp::OutputMessage("Usage: view %s Stats <on|off>", this->getName());
			return DANCE_ERROR;
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "gridColor") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: view %s gridColor <r> <g> <b>", this->getName());
			return DANCE_ERROR;
		}
		float color[3];
		color[0] = (float) atof(argv[1]);
		color[1] = (float) atof(argv[2]);
		color[2] = (float) atof(argv[3]);
		this->setGridColor(color[0], color[1], color[2]);
		this->InitList();
		danceInterp::OutputMessage("Grid color is now %f %f %f", color[0], color[1], color[2]);
		dance::AllViews->postRedisplay();

		return DANCE_OK;
	}
	else if (strcmp(argv[0], "gridHighlightColor") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: view %s gridHighlightColor <r> <g> <b>", this->getName());
			return DANCE_ERROR;
		}
		float color[3];
		color[0] = (float) atof(argv[1]);
		color[1] = (float) atof(argv[2]);
		color[2] = (float) atof(argv[3]);
		this->setGridHighlightColor(color[0], color[1], color[2]);
		this->InitList();
		danceInterp::OutputMessage("Grid highlight color is now %f %f %f", color[0], color[1], color[2]);
		dance::AllViews->postRedisplay();

		return DANCE_OK;
	}
	else if (strcmp(argv[0], "grid") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: view %s grid <on|off>", this->getName());
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "on") == 0)
		{
			this->setGrid(true);
			danceInterp::OutputMessage("Grid will be shown in view %s.", this->getName());
			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "off") == 0)
		{
			this->setGrid(false);
			danceInterp::OutputMessage("Grid will not be shown in view %s.", this->getName());
			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Usage: view %s grid <on|off>", this->getName());
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "near") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.view(%s, \"near\", <nearplane>", this->getName());
			return DANCE_ERROR;
		}
		double near = (double) atof(argv[1]);
		if (near < 0)
		{
			danceInterp::OutputMessage("Near plane must be > 0.");
			return DANCE_ERROR;
		}
		if (near > getFar())
		{
			danceInterp::OutputMessage("Near plane must be < far plane (%f)", getFar());
			return DANCE_ERROR;
		}
		danceInterp::OutputMessage("Near plane set to %f", getNear());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "far") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.view(%s, \"far\", <farplane>", this->getName());
			return DANCE_ERROR;
		}
		double far = (double) atof(argv[1]);
		if (far < getNear())
		{
			danceInterp::OutputMessage("Far plane must be > near plane (%f).", getNear());
			return DANCE_ERROR;
		}
		setFar(far);
		danceInterp::OutputMessage("Far plane set to %f", getFar());
		return DANCE_OK;
	}
	else
	{
		usage();
		return DANCE_OK;
	}

	return DANCE_CONTINUE;
}

// dollyCamera:
//	Zoom camera in and out and specify target.
//
//	percentage: Percentage factor distance
//
void DView::dollyCamera(GLdouble	percentage)
{

	if (getProjectionType() != VIEW_PERSP)
		return;

	GLdouble dist =	percentage*Dist;
	dollyCameraDist(dist);

}

// dollyCameraDist:
//
void DView::dollyCameraDist(double dist) 
{
	// Do not adjust distance if in	orthographic mode.
	if (getProjectionType() == VIEW_PERSP)
	{
	    double ratiox = Right/Near;
	    double ratioy = Top/Near;

	    // Prevents	negative near clipping plane. However, we still	update the
	    // virtual_near value to allow us to gracefully zoom out without moving
	    // the near	clipping plane as we zoom out.
	    Virtual_near = Virtual_near	+ (dist	- Dist);

	    // Do not adjust near and far clipping planes if we	have reached the limits.
	    if (Virtual_near > Limit_near) {
	       Limit_near = 0.01;
	       Near += (dist - Dist);
	       Far += (dist - Dist);

	       Right= ratiox*Near;
	       Left = -1.0*Right;
	       Top = ratioy*Near;
	       Bottom =	-1.0*Top;

        setProjection(Left,Right,Bottom,Top,Near,Far);
	    }
	    else Limit_near = Near;

	    // Calculate new bounds for	left,right,top,bottom.
	    Dist = dist;

		if (this->m_viewWindow != NULL)
			this->m_viewWindow->updateGUI();
	}

	m_cameraMoved = true;
}

// drawArcball:
//	Draws ball in given view
//
//	view: Given view
//
void DView::drawArcball()
{
	ball->draw();
}

// endInteraction:
//	Ends an	interactive session with the window.
//
//	mode:	Type of	edit mode
//
void DView::endInteraction(int mode)
{
	switch(mode) {
	   case	camera_arcball:
		ball->endDrag();
	   break;
	}
}

// getBackgroundColor:
//	color[4]  : Returns r,g,b,a
//
void DView::getBackgroundColor(GLfloat color[4])
{
	memcpy(color,BackgroundColor,4*sizeof(GLfloat));
}

// getBounds:
//
void DView::getBounds(double *left, double *right, double *top, double *bottom)
{
	*left =	Left;
	*right = Right;
	*top = Top;
	*bottom	= Bottom;
}

// getCenter:
//
void DView::getCenter(double center[3])
{
	getWorldCoords(center, int((double) Width*0.5), 
			int((double) Height*0.5), 0.5);
}


// getCameraParms:
//	Retrieves the camera parameters	for the	given view.
//
//	view	  : view ID
//	dist	  : camera distance to target
//	panx, pany: Panning coordinates.
//	target	  : camera target
//
void DView::getCameraParms(GLdouble *dist,
		GLdouble *panx,	GLdouble *pany,	GLdouble target[3])
{
	*dist =	Dist;
	*panx =	Panx;
	*pany =	Pany;

	for (int i = 0;	i < 3; i++)
		target[i] = Target[i];
}

void DView::setCameraOrientation(float	mat[4][4])
{
	for (int	i=0; i < 4; i++)
		for (int j=0; j < 4;	j++)
		{
			if (i != 3)
				Modelview[i*4+j] = mat[i][j];
		}
}

void DView::setCameraTransformation(float mat[4][4])
{
	for (int	i=0; i < 4; i++)
		for (int j=0; j < 4;	j++)
			Modelview[i*4+j] = mat[i][j];
}

// getCameraOrientation:
//	Retrieves the orientation matrix for the camera.
//
void DView::getCameraOrientation(float mat[4][4])
{
       getCameraTransformation(mat);

       // Eliminate translational component.
       mat[3][0] = mat[3][1] = mat[3][2] = 0.0;
}

// getCameraTransformation:
//	Retrieves the transformation matrix for	the camera.
//
void DView::getCameraTransformation(float mat[4][4])
{
	double dmat[16];
	memcpy(dmat, Modelview, 16 * sizeof(GLdouble));

	// Convert to float matrix
	for (int	i=0; i < 4; i++)
		for (int j=0; j < 4;	j++)
			mat[i][j] = (float)dmat[i*4+j];
}


// getProjection:
//	Retrieves the projection matrix	for the	camera view.
//
void DView::getProjection(double	*projection)
{
	memcpy(projection,Projection,16*sizeof(double));
}

// getReferenceFrame:
//	Retrieves the reference	frame axes of the window.
//
//	view: Given view ID
//	basisX,	basisY,	basisZ:	basis vectors
//
void DView::getReferenceFrame(double basisX[3], double basisY[3], double	basisZ[3])
{
	getViewPlane(basisX,basisY);

	// Get cross product for third vector.
	basisZ[0] = basisX[1]*basisY[2]	- basisX[2]*basisY[1];
	basisZ[1] = basisX[2]*basisY[0]	- basisX[0]*basisY[2];
	basisZ[2] = basisX[0]*basisY[1]	- basisX[1]*basisY[0];
}

// getSize:
//	Retrieves the size of the window (active or given).
//
void DView::getSize(int &width, int &height)
{
    GLint rm ;
    glGetIntegerv(GL_RENDER_MODE, &rm) ;

	width = getWidth();
	height = getHeight();
}

void DView::setSize(int width, int height)
{
	setWidth(width);
	setHeight(height);
}

// getViewPlane:
//	Retrieves basis	vectors	for the	viewing	plane of the given window.
//	NOTE: Matrices mNow is in column major order (1st index	is column)
//	Basis vectors correspond to rows of the	matrix.
//
//	view: Given view ID
//	basisX,	basisY:	basis vectors
//

void DView::getViewPlane(double basisX[3], double basisY[3])
{
	HMatrix	mNow;
	ball->value(mNow);

	double basisZ[3];
	for (int i=0; i	< 3; i++) {
	    basisX[i] =	mNow[i][0];
	    basisY[i] =	mNow[i][1];
	    basisZ[i] =	mNow[i][2];
	}

	double x,y,z;
	if (getProjectionType() == VIEW_RIGHT) {
	    x =	basisX[0]; z = basisX[2];
	    basisX[0] =	z; basisX[2] = -1.0*x;

	    x =	basisY[0]; z = basisY[2];
	    basisY[0] =	z; basisY[2] = -1.0*x;
	}
	else if	(getProjectionType() == VIEW_TOP) {
	    y =	basisX[1]; z = basisX[2];
	    basisX[1] =	z; basisX[2] = -1.0*y;
	    y =	basisY[1]; z = basisY[2];
	    basisY[1] =	z; basisY[2] = -1.0*y;
	}
}

// getViewport:
//	Retrieves the viewport for the given view.
//
void DView::getViewport(int viewport[4])
{
    GLint rm ;
    glGetIntegerv(GL_RENDER_MODE, &rm) ;
    glGetIntegerv(GL_VIEWPORT,(GLint *)viewport);
}

// getWindowCoords:
//	Given a	world point, gets the window coordinates
//	NOTE: We use the Projection instead of reading
//	off the	PROJECTION stack directly because a picking operation
//	will alter the matrix on the stack and return incorrect	results.
//
void DView::getWindowCoords(GLdouble *world, GLdouble *win)
{
    GLint rm ;
    glGetIntegerv(GL_RENDER_MODE, &rm) ;
    int viewport[4]; glGetIntegerv(GL_VIEWPORT,(GLint *)viewport);
    
    gluProject(world[0],world[1],world[2],
	       Modelview,Projection,
	       (GLint *)viewport, &win[0],&win[1],&win[2]);
}

// getWorldCoords:
//	NOTE: We use the ViewsInfo[view].projection instead of reading
//	off the	PROJECTION stack directly because a picking operation
//	will alter the matrix on the stack and return incorrect	results.
//
double DView::getWorldCoords(GLdouble *world, int x, int y, GLdouble z)
{ 
    GLint rm ;
    glGetIntegerv(GL_RENDER_MODE, &rm) ;
    
	int viewport[4]; glGetIntegerv(GL_VIEWPORT,(GLint *)viewport);


	int winx = x;
	int winy = viewport[3] - y;
	if (z <	0.0)
	{
		float zfloat ;
		glReadPixels( winx, winy,
			  1,1,GL_DEPTH_COMPONENT,GL_FLOAT,&zfloat);
		if( fabs(zfloat - 1.0) < 0.000001 )
		    zfloat = (float)prevDepth ;
		z = (double) zfloat ;
	}
	gluUnProject((double) winx,(double) winy,z,
		     Modelview,Projection,
		     (GLint *)viewport,	&(world[0]),&(world[1]),&(world[2]));
	prevDepth = z ;
	return(z);
}

// moveCamera:
//	Moves the camera for the given view.
//
//	dist		: Distance from	camera to target.
//	panx,pany	: Translation of camera	pan.
//	target[3]	: Target in world space	of camera.
//	arccoords	: 2D vector of coordinates for the ball position.
//
void DView::moveCamera(GLdouble dist, GLdouble panx, GLdouble pany,
			  GLdouble target[3], HVect arccoords)
{
	// Set camera data.
	memcpy(Target, target, 3 * sizeof(GLdouble));
	Dist = dist;
	Panx = panx;
	Pany = pany;
	ball->mouse(arccoords);
}

// panCamera:
//	Pans the camera	around the viewing plane.
//
//	panx, pany: Panning coordinates.
//
void DView::panCamera(GLdouble panx, GLdouble pany)
{
	Panx = panx;
	Pany = pany;

	m_cameraMoved = true;
}

// pickProjection:
//	Resets projection matrix,
//
//	x,y :	x and y	coordinates of the picked pixel	in the window,
//		note that y starts at 0	from the top of	the window.
//	delX, delY : region around the pixel to	be picked
//
void DView::pickProjection(int x, int y,	double delX, double delY)
{
    GLint rm ;
    glGetIntegerv(GL_RENDER_MODE, &rm) ;  
    
    // Get viewport	data.
    GLint viewport[4];
    glGetIntegerv(GL_VIEWPORT,viewport);
    // Load	special	Picking	Matrix Projection
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPickMatrix(x ,viewport[3] - y, delX, delY, viewport);
    glMultMatrixd(Projection);
}

// positionCamera:
//	Positions the camera in	the world space.
//
void DView::PositionCamera()
{
//	GLint rm ;
  //  glGetIntegerv(GL_RENDER_MODE, &rm)  ;
	
	 glMatrixMode(GL_MODELVIEW);
	 glLoadIdentity();
	 if (!m_cameraMoved)
	 {
		glMultMatrixd(Modelview);
		return;
	 }

	 // Panning translation.
	 glTranslated(-1.0 * Panx, -1.0 * Pany, 0.0);

	 // Sets distance from viewer to target
	 // (valid only	for perspective	projection)
	 // RECALL: OpenGL uses	a right-handed coordinate system,
	 // so z positive is coming out	of the screen.

	 double* cameraPos = getCamera();
	 if (getProjectionType() == VIEW_PERSP) // perspective projection
	   gluLookAt(0.0, 0.0, Dist, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
//	 gluLookAt(1.0,3.5,4.0,1.0,3.5,0.0,0.0,1.0,0.0);
	 // ball rotation transformation.
	 HMatrix arcrot;
	 ball->value(arcrot);
	 glMultMatrixf((float *)arcrot);

	 // Make adjustments (rotations) to achieve different views.
	 switch(getProjectionType())	{
		case VIEW_TOP:
		     glRotatef(90.0, 1.0, 0.0, 0.0);
		break;
		case VIEW_RIGHT:
		     glRotatef(-90.0, 0.0, 1.0, 0.0);
		break;
	 }

	 // Points camera to desired target.
	 glTranslated(-1.0 * Target[0], -1.0 * Target[1], -1.0 * Target[2]);


	 // Store the modelview	matrix.
	 glGetDoublev(GL_MODELVIEW_MATRIX, Modelview);

	m_cameraMoved = false;
}

// resetCamera:
//	Resets camera to original orientation and pan.
//
void DView::resetCamera()
{
	panCamera(0.0,0.0);
	ball->init();
	ball->place(qOne,0.75);
	m_cameraMoved = true;
}


// setArcballConstraints:
//	Sets constraints for ball to	rotate about specified axes.
//
//	axisset: Axisset to activate.
void DView::setArcballConstraints(AxisSet axisset)
{
	ball->useSet(axisset);
}

// setBackgroundColor:
//	r,g,b,a	: Sets background color	to r,g,b,a
//
void DView::setBackgroundColor(float r, float g,	float b, float a)
{
	BackgroundColor[0] = r;
	BackgroundColor[1] = g;
	BackgroundColor[2] = b;
	BackgroundColor[3] = a;
	glClearColor(BackgroundColor[0], BackgroundColor[1], BackgroundColor[2], BackgroundColor[3]);
}

// setCamera:
//	Sets the projection matrix and viewing for the given view.
//	Ensures	that we	can initially see the contents of the
//	bounding box with corners (minx,miny,minz) and (maxx, maxy, maxz).
//
//	perspective	: 0 for	orthographic, 1	for perspective
//	scale		: amount viewing volume	is larger than bounding	box
//	minx, miny, minz,
//	maxx, maxy, maxz: Bounds for bounding box of visuals.
//
//	NOTES:
void DView::setCamera(double scale,
		      double minx, double miny, double minz, 
		      double maxx, double maxy, double maxz,
		      double scaleNear, double scaleFar) {

	// Initialize ball->
	if (ball == NULL)
	{
	    ball = new ArcBall();
	    ball->place(qOne,0.75);
	}

	// Calculate camera target.
	double target[3];
	target[0] = (minx + maxx)/2.0;
	target[1] = (miny + maxy)/2.0;
	target[2] = (minz + maxz)/2.0;

	// Since we want the entire bounding box to be seen, even if
	// we tumble around, we	must ensure that all box dimensions
	// can be seen from any	angle about the	target.
	// We calculate	the maximum radius about the target.
	double max_radius = sqrt(
			      pow(maxx-target[0],2.0) +
			      pow(maxy-target[1],2.0) +
			      pow(maxz-target[2],2.0)
			    );

	// Calculate the clipping planes for each dimension.
	double half_x =	max_radius*scale;
	double half_y =	max_radius*scale;
	double half_z =	max_radius*scale;

	double aspect = ((double)Width) / (double) Height ;
	double half_size = half_x ;
	if (half_y > half_size)	half_size = half_y;
	if (half_z > half_size)	half_size = half_z;
	
	// Calculate size of viewing volume.
	GLdouble left =	-aspect*half_size ;
	GLdouble right = aspect*half_size ;
	GLdouble bottom	= -half_size;
	GLdouble top = half_size;

	GLdouble nearV, farV, dist;

	

	// Projection parameters.
	if (getProjectionType() != VIEW_PERSP) {	// orthographic
	     nearV = -1.0*half_size;
	     farV = half_size;

	     //	Although this distance is really meaningless.
	     //	This value can be used to gauge	how much to
	     //	pan a camera.
	     dist = 2 * half_size;
	}
	else { // Perspective projection
	     //	Both near and far must be positive.
	     //	We scale the viewing volume a bit more in the z	direction,
	     //	to allow a slightly larger space between the near and far
	     //	clipping planes.
	     //

	     //	Move out about 5 times the depth of the	bounding box.
	  //dist = 2.0*half_size;
	  dist = scaleNear*half_size;
	  nearV = half_size;
	  farV = scaleFar*half_size;
	}

	// override near/far parameters
	//nearV = getNear();
	//farV = getFar();

	setProjection(left, right, bottom, top, nearV, farV);

	HVect arccoords;
	arccoords.x = arccoords.y = 0.0;
	moveCamera(dist, 0.0, 0.0, target, arccoords);

	// For correct dolly operations.
	// The setting of virtual_near allows us to clip inside	a solid	and still
	// keep	a very tight bound for the front and back clipping.
	Virtual_near = Near;
	Limit_near = 0.01;

}

// setProjection:
//	Sets the projection matrix from	the preset values.
//
void DView::setProjection()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	if (getProjectionType() != VIEW_PERSP)
	    glOrtho(Left, Right, Bottom, Top, Near, Far);
	else
	    glFrustum(Left, Right, Bottom, Top, Near, Far);
//		gluPerspective(fov, (Left - Right) / (Bottom - Top), Near, Far);

	glGetDoublev(GL_PROJECTION_MATRIX,Projection);

	setNeedsReset(false);
}

// setProjection:
//	Sets the projection matrix for the given window	to be orthographic
//	or perspective.
//
//	perspective: 0 for orthographic, 1 for perspective
//	left	   : left side of viewing volume.
//	right	   : right side	of viewing volume.
//	bottom	   : bottom side of viewing volume.
//	top	   : top side of viewing volume.
//	near	   : near clipping plane of viewing volume.
//	far	   : far clipping plane	of viewing volume.
//
void DView::setProjection(
	GLdouble left, GLdouble	right, GLdouble	bottom,	GLdouble top,
	GLdouble nearV,	GLdouble farV)
{

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	if (getProjectionType() == VIEW_PERSP)
	{
		glFrustum(left,right,bottom,top,nearV,farV);
//		gluPerspective(fov, (left - right) / (bottom - top), nearV, farV);
	}
	else
	{
	    glOrtho(left,right,bottom,top,nearV,farV);
	}
	glGetDoublev(GL_PROJECTION_MATRIX,Projection);
	
	Near = nearV;
	Far = farV;
	Left = left;
	Right =	right;
	Top = top;
	Bottom = bottom;

	// calculate the fov
	fov = 2.0 * atan(((top - bottom) / 2) / Dist) * 180.0 / M_PI;

	setNeedsReset(false);
}

// start:
//	Initialization stuff before drawing
//
void DView::start()
{
	glClearColor(BackgroundColor[0],BackgroundColor[1],
		     BackgroundColor[2],BackgroundColor[3]);
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

	if (Lights)
	{
		glEnable(GL_LIGHTING);
		for (int x = 0; x < dance::AllLights->size(); x++)
		{
			DLight* light = (DLight*) dance::AllLights->get(x);
			glEnable(light->getLightID());
		}
	}
	else
	{
		glDisable(GL_LIGHTING);
	}

	glEnable(GL_DEPTH_TEST);
	
}

void DView::InitShadowMap(void)
{
	if( (dance::AllLights->size() < 1 ) || !this->isShadows() )
		return ;



	DLight *light = (DLight *) dance::AllLights->get(0) ;

	GLfloat lightPosition[4] ;
	light->getPosition(lightPosition) ;
//#ifdef WIN32
	//Initialise extgl
	/*
	if(extgl_Initialize()!=0)
	{
		danceInterp::OutputMessage("Unable to Initialise extgl\n");
		return ;
	}

	//Check for necessary extensions
	if(!extgl_Extensions.ARB_depth_texture || !extgl_Extensions.ARB_shadow)
	{
		danceInterp::OutputMessage("I require ARB_depth_texture and ARB_shadow extensionsn\n");
		return ;
	}
#endif
	*/

	//int w = getWidth();
	//int h = getHeight();

	//Load identity modelview
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//Shading states
	glShadeModel(GL_SMOOTH);
//	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
//	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	//Depth states
	glClearDepth(1.0f);
	glDepthFunc(GL_LEQUAL);
	glEnable(GL_DEPTH_TEST);

	glDisable(GL_CULL_FACE);
	glCullFace(GL_FRONT) ;

	//We use glScale when drawing the scene
	glEnable(GL_NORMALIZE);

	if ( glIsTexture(m_shadowMapTexture) )
	{
		glDeleteTextures(1, &m_shadowMapTexture) ;
	}
	//Create the shadow map texture
	glGenTextures(1, &m_shadowMapTexture);

	//glBindTexture(GL_TEXTURE_2D, m_shadowMapTexture);
	glTexImage2D(	GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, m_shadowMapSize, m_shadowMapSize, 0,
		GL_DEPTH_COMPONENT, GL_UNSIGNED_BYTE, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

	//Calculate & save matrices
	//Load identity modelview
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix() ;
	glLoadIdentity();
	double lightDistance = sqrt( lightPosition[0]*lightPosition[0] +  
			lightPosition[1]*lightPosition[1] +
			lightPosition[2]*lightPosition[2] ) ;
	double near, far;
	this->getNearFar(&near, &far);
	double fov = this->getFOV();
	gluPerspective(fov, double(this->getWidth())/double(this->getHeight()), near, far);
	//GLfloat near = lightDistance - 50  ;
	//if( near < 1.0) near = 1.0 ;
	//GLfloat far = lightDistance + 200.0f;
	//gluPerspective(45.0f, 1.0f, near, far);
	glGetDoublev(GL_MODELVIEW_MATRIX, m_lightProjectionMatrix);

	glLoadIdentity();
	// The light position - the look at point should not be aligned with the up vector!!
	gluLookAt(	lightPosition[0], lightPosition[1], lightPosition[2],
		0.0f, 0.0f, 0.0f,
		0.0f, 0.0f, 1.0f);
	glGetDoublev(GL_MODELVIEW_MATRIX, m_lightViewMatrix);

	glPopMatrix();


}


// zoomCamera:
//	Zoom camera in as a percentage of the original viewport	size.
//
//	percentage: percentage to zoom in or out.
//
void DView::zoomCamera(GLdouble percentage)
{
	Left *=	percentage;
	Right *= percentage;
	Bottom *= percentage;
	Top *= percentage;
	setProjection(Left, Right, Bottom, Top, Near, Far);
	if (this->m_viewWindow != NULL)
		this->m_viewWindow->updateGUI();

	m_cameraMoved = true;
}
void DView::getNearFar(double * nearplane, double * farplane)
{
	*nearplane = Near;
	*farplane = Far;
}

// Returns the Frustum width at the given depth level (0,1)
double DView::getFrustumWidth(double depth)
{
	if (getProjectionType() == VIEW_PERSP)
	{
		double ratio = (Right - Left) * 0.5 / Near;
		double dist = Near * (1.0 - depth) + depth * Far;
		return(ratio * dist * 2.0);
	}
	else 
		return(Right - Left);
}

// Returns the Frustum width at the given depth level (0,1)
double DView::getFrustumHeight(double depth)
{
	if (getProjectionType() == VIEW_PERSP)
	{
		double ratio = (Top - Bottom) * 0.5 / Near;
		double dist = Near * (1.0 - depth) + depth * Far;
		return(ratio * dist * 2.0);
	}
	else 
		return(Top - Bottom);
}


double DView::getDepth(int x, int y)
{
	int viewport[4]; glGetIntegerv(GL_VIEWPORT,(GLint *)viewport);

	int winx = x;
	int winy = viewport[3] - y;

	float zfloat ;
	glReadPixels( winx, winy,
		  1,1,GL_DEPTH_COMPONENT,GL_FLOAT,&zfloat);
	return( (double) zfloat );
	
}


void DView::ReshapeCB(int x, int y, int width, int height)
{
	glViewport(x, y, width, height);
	
	GLdouble proj_height =  Top - Bottom;
	GLdouble proj_width = ((double) width/ (double) height) * (double) proj_height;
	Right =	proj_width/2.0;
	Left = -1*proj_width/2.0;


	/*
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	if (getProjectionType() == VIEW_PERSP)
	    glFrustum(Left, Right, Bottom, Top, Near, Far);
	else
	    glOrtho(Left, Right, Bottom, Top, Near, Far);

	glGetDoublev(GL_PROJECTION_MATRIX, Projection);
*/
	this->setProjection(Left, Right, Bottom, Top, Near, Far);
	// New x and y offsets for window.
	int newx = x; //dance::AllViews->getDanceWindow()->x();
	int newy = y; //dance::AllViews->getDanceWindow()->y();

	// Record new window changes for the triggering	window.
	setX(newx);
	setY(newy);
	Width = width;
	Height = height;

	setNeedsReset(false);

	// return back to model view
	glMatrixMode(GL_MODELVIEW) ;

	setMode(DView::MODE_NONE);
	m_cameraMoved = true;
}

void DView::GetState(double *state)
{
    state[0] = Target[0] ;
    state[1] = Target[1] ;
	state[2] = Target[2] ;
	state[3] = Left;
	state[4] = Right;
	state[5] = Top;
	state[6] = Bottom;

	Quaternion quat;
	float mat[4][4];
	getCameraOrientation(mat);
	quat.fromMatrix(mat);
	quat.getAxisAngle(&(state[8]),&(state[7]));
	
}    

void DView::postRedisplay()	
{ 
	setChanged(true);
}

void DView::set()
{
}

void DView::UpdateState(double *state)
{
	// Set target position.
    Target[0] = state[0] ;
    Target[1] = state[1] ;
	Target[2] = state[2] ;

	// Set viewing frustum (for zoom)
	Left = state[3];
	Right = state[4];
	Top = state[5];
	Bottom = state[6];
    setProjection(Left,Right,Bottom, Top, Near, Far);

	// Set camera orientation.
	Quaternion quat;
	float mat[4][4];

	quat.set(state[7],&(state[8]));
	quat.toMatrix(mat);
	ball->init((float *)mat);

    postRedisplay() ;
}

void DView::SaveFrame()
{
	DRenderer* renderer = dance::AllViews->getRenderer();
	if (renderer == NULL)
	{
		danceInterp::OutputMessage("No renderer present. Use: dance.viewmanager(\"renderer\", \"<renderer_name>\"");
		return;
	}
	
	bool success = renderer->render(dance::AllViews->getRenderer()->getRenderDirectory(), this->m_DumpFileName, this->getFrameNumber(), this->getWidth(), this->getHeight());
	if (!success)
	{
		danceInterp::OutputMessage("Screen was not rendered. Problem!");
	}
	else
	{
		this->setFrameNumber(this->getFrameNumber() + 1);
	}
}

void DView::printText(double *pos, const char *msg) {
  
  glRasterPos3d(pos[0], pos[1], pos[2]);
  
  glPushAttrib(GL_LIST_BIT|GL_ENABLE_BIT);
  glDisable(GL_LIGHTING);
  glListBase(base-32);
  glCallLists(strlen(msg), GL_UNSIGNED_BYTE, msg);
  glPopAttrib();

  danceInterp::OutputMessage("Printing %s", msg);
}


void DView::InitList()
{
	glDeleteLists(GridList, 1);
	GridList = glGenLists(1);
	if ( GridList == GL_INVALID_VALUE || GridList == GL_INVALID_OPERATION)
		danceInterp::OutputMessage("could not create gridlist");
	glNewList(GridList, GL_COMPILE);
	drawGrid();
	glEndList();
}

void DView::drawGrid()
{
	glPushAttrib(GL_LIGHTING_BIT | GL_COLOR_BUFFER_BIT | GL_LINE_BIT);
	bool colorChanged = false;
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
    glDisable(GL_COLOR_MATERIAL);

	glColor3f(gridColor[0], gridColor[1], gridColor[2]);			
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glHint(GL_LINE_SMOOTH_HINT, GL_DONT_CARE);
	glLineWidth(1);
//	glLineStipple(1, 0xAAAA);
	glBegin(GL_LINES);
	for (float x = -gridSize; x <= gridSize; x += gridStep)
	{
		if (x == 0.0) {
			colorChanged = true;
			glColor3f(gridHighlightColor[0], gridHighlightColor[1], gridHighlightColor[2]);
		}
		if (getProjectionType() == VIEW_PERSP || getProjectionType() == VIEW_TOP)
		{
			glVertex3f(x, 0.0, -gridSize);
			glVertex3f(x, 0.0, gridSize);
		}
		else if (getProjectionType() == VIEW_RIGHT)
		{
			glVertex3f(0.0, x, -gridSize);
			glVertex3f(0.0, x, gridSize);
		}
		else if (getProjectionType() == VIEW_FRONT)
		{
			glVertex3f(x, -gridSize, 0.0);
			glVertex3f(x, gridSize, 0.0);
		}
		if (colorChanged) {
			colorChanged = false;
			glColor3f(gridColor[0], gridColor[1], gridColor[2]);
		}

	}
	for (float x = -gridSize; x <= gridSize; x += gridStep)
	{
		if (x == 0) {
			colorChanged = true;
			glColor3f(gridHighlightColor[0], gridHighlightColor[1], gridHighlightColor[2]);
		}
		if (getProjectionType() == VIEW_PERSP || getProjectionType() == VIEW_TOP)
		{
			glVertex3f(-gridSize, 0.0, x);
			glVertex3f(gridSize, 0.0, x);
		}
		else if (getProjectionType() == VIEW_RIGHT)
		{
			glVertex3f(0.0, -gridSize, x);
			glVertex3f(0.0, gridSize, x);
		}
		else if (getProjectionType() == VIEW_FRONT)
		{
			glVertex3f(-gridSize, x, 0.0);
			glVertex3f(gridSize, x, 0.0);
		}
		if (colorChanged) {
			colorChanged = false;
			glColor3f(gridColor[0], gridColor[1], gridColor[2]);
		}
	}

	glEnd();
	glDisable(GL_BLEND);
//	glDisable(GL_LINE_STIPPLE);

	glPopAttrib();
}

BoundingBox* DView::calcBoundingBox(BoundingBox* box)
{
	if (this->m_showGrid)
	{
		if (getProjectionType() == VIEW_PERSP || getProjectionType() == VIEW_TOP)
		{
			m_BoundingBox.xMin = -gridSize;
			m_BoundingBox.xMax = gridSize;
			m_BoundingBox.yMin = 0;
			m_BoundingBox.yMax = 0;
			m_BoundingBox.zMin = -gridSize;
			m_BoundingBox.zMax = gridSize;
		}
		else if (getProjectionType() == VIEW_RIGHT)
		{
			m_BoundingBox.xMin = 0;
			m_BoundingBox.xMax = 0;
			m_BoundingBox.yMin = -gridSize;
			m_BoundingBox.yMax = gridSize;
			m_BoundingBox.zMin = -gridSize;
			m_BoundingBox.zMax = gridSize;
		}
		else if (getProjectionType() == VIEW_FRONT)
		{
			m_BoundingBox.xMin = (float) -gridSize;
			m_BoundingBox.xMax = (float) gridSize;
			m_BoundingBox.yMin = (float) -gridSize;
			m_BoundingBox.yMax = (float) gridSize;
			m_BoundingBox.zMin = 0;
			m_BoundingBox.zMax = 0;
		}

		if( box ) box->copy(&m_BoundingBox) ;
		return box;
	}
	else
	{
		return NULL;
	}
}

void DView::setProjectionType(int type)
{
	if (type == VIEW_FRONT ||
		type == VIEW_TOP ||
		type == VIEW_RIGHT ||
		type == VIEW_PERSP )
	{
		m_projectionType = type;
		InitList();
	}
	else
	{
		danceInterp::OutputMessage("Cannot set view projection type to %d, keeping projection type at %d", type, m_projectionType);
	}
}

int DView::getProjectionType()
{
	return m_projectionType;
}

int DView::getX()
{
	return X;
}

void DView::setX(int val)
{
	X = val;
}

int DView::getY()
{
	return Y;
}

void DView::setY(int val)
{
	Y = val;
}

int DView::getWidth()
{
	return Width;
}

void DView::setWidth(int val)
{
	Width = val;
}

int DView::getHeight()
{
	return Height;
}

void DView::setHeight(int val)
{
	Height = val;
}

int DView::getMode()
{
	return m_mode;
}

void DView::setMode(int val)
{
	m_mode = val;
}

bool DView::isChanged()
{
	return m_changed;
}

void DView::setChanged(bool val)
{
	m_changed = val;
}

// Handle camera motions.
void DView::handleCameraMotions(int eventType, int x, int y,	int width, int height, int diffx, int diffy)
{	
	switch(getMode())
	{
	   case DView::MODE_ARCBALL:
	   {
		 HVect arccoords;
		 arccoords.x = float(2.0)*(float)x/(float)width-float(1.0);
		 arccoords.y = -float(2.0)*(float)y/(float)height+float(1.0);
		 adjustArcballCamera(arccoords);
		 resetLights();
		 postRedisplay();
	   }
	   break;
	   case	DView::MODE_PAN:
	   {
	     GLdouble dist, panx, pany,	target[3];
	     getCameraParms(&dist, &panx,&pany,target);
		 
		 double worldwidth = getFrustumWidth(0.0);
		 // More intelligent pan that moves rotation point with it.
		 double basisx[3], basisy[3];
		 getViewPlane(basisx,basisy);
		 for (int i = 0; i < 3; i++)
			 target[i] += -diffx*basisx[i]* m_panRate->getValue() *worldwidth + diffy*basisy[i]* m_panRate->getValue() *worldwidth;
		 setTarget(target);
		 resetLights();
	     postRedisplay();
	   }
	   break;
	   case	DView::MODE_ZOOM:
	     //	Orthographic zoom and non-forshortening	zoom
	     if	(diffx + diffy > 0)
		     zoomCamera(1 + m_zoomRate->getValue());
	     else
		     zoomCamera(1 - m_zoomRate->getValue());
		 resetLights();
	     postRedisplay();
	   break;
	   case	DView::MODE_DOLLY:
	     //	Only for Perspective window, displays forshortening effects.
	     if	(diffx + diffy > 0)
		     dollyCamera(1 + m_dollyRate->getValue());
	     else
		     dollyCamera(1 - m_dollyRate->getValue());
		 resetLights();
	     postRedisplay();
	   break;
	}
}

void DView::handleCameraButtons(int eventType, int button, int state, int	x, int y, int width, int height)
{
	switch (button) {
	    case 1:
			if (eventType == fltk::PUSH)
			{
				setMode(DView::MODE_ARCBALL);
				bool shift = (fltk::get_key_state(fltk::LeftShiftKey) || fltk::get_key_state(fltk::RightShiftKey));
				if (shift)
					setArcballConstraints(CameraAxes);

				bool alt = (fltk::get_key_state(fltk::LeftAltKey) || fltk::get_key_state(fltk::RightAltKey));
				if (alt)
					setArcballConstraints(BodyAxes);

				if (!shift && !alt)
					setArcballConstraints(NoAxes);
	
				HVect arccoords;
				arccoords.x = float(2.0)*(float)x/(float)width-float(1.0);
				arccoords.y = -float(2.0)*(float)y/(float)height+float(1.0);
				adjustArcballCamera(arccoords);
				beginInteraction(camera_arcball);
				resetLights();
				postRedisplay();
			}
			else { 
				endInteraction(camera_arcball);
				setMode(DView::MODE_NONE);
				resetLights();

				postRedisplay();
			}
	     break;
	     case 2:
			if (button == 1 || button == 2 || button == 3)
				setMode(DView::MODE_PAN);
			else
			{
				setMode(DView::MODE_NONE);
		        resetLights();
				postRedisplay();
			}
	     break;
	     case 3:
			 if (button == 1 || button == 2 || button == 3)
			 {
				bool shift = fltk::get_key_state(fltk::RightShiftKey);
				if (!shift)
					shift = fltk::get_key_state(fltk::LeftShiftKey);
				if (shift)
					setArcballConstraints(CameraAxes);

				bool alt = (fltk::get_key_state(fltk::LeftAltKey) || fltk::get_key_state(fltk::RightAltKey));
				if (alt)
					setArcballConstraints(BodyAxes);

				if (!shift && !alt)
					setArcballConstraints(NoAxes);


			  if(alt)
				  setMode(DView::MODE_DOLLY);
			  if(!alt && !shift)
				  setMode(DView::MODE_ZOOM);

	          resetLights();
			  postRedisplay();

		  }
		else
		{
			setMode(DView::MODE_NONE);
	        resetLights();
			postRedisplay();
		}
	}

}

void DView::handleKeyboard(int eventType, unsigned char key, int x, int y)
{
	bool alt = (fltk::get_key_state(fltk::LeftAltKey) || fltk::get_key_state(fltk::RightAltKey));
	if (!alt && getMode() == DView::MODE_ARCBALL)
	{
		setMode(DView::MODE_NONE);
	}
}



void DView::drawName()
{
	glPushAttrib(GL_ENABLE_BIT);
	glDisable(GL_LIGHTING);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

	gluOrtho2D(0, this->getWidth(), 0, this->getHeight());

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
	glTranslatef(5, 2, 0);
	GLlabel((char*) this->getName());
	glEnable(GL_LIGHTING);
	glPopAttrib();
}

char* DView::getDumpDirectory()
{
	return this->m_DumpDirectory;
}

void DView::setDumpDirectory(char* dir)
{
	strcpy(this->m_DumpDirectory, dir);
}

Widget* DView::getInterface()
{
	if (m_viewWindow == NULL)
	{
		m_viewWindow = new ViewWindow(this, 0, 0, 300, 400, this->getName());
	}

	return m_viewWindow;
}

void DView::setShadows(bool val)
{
	if (val)
		Shadows = 1;
	else
		Shadows = 0;
}

void DView::setSolids(bool val)
{
	if (val)
		Solids = 1;
	else
		Solids = 0;
}

void DView::setLights(bool val)
{
	if (val)
		Lights = 1;
	else
		Lights = 0;
}

void DView::setFrameNumber(int fnum)
{
	m_FrameNumber = fnum;	
}

int DView::getFrameNumber()
{
	return m_FrameNumber;
}

bool DView::isDumped()
{
	return m_isDumped;
}

void DView::setDumped(bool val)
{
	m_isDumped = val;
}


void DView::setGridSize(float size)
{
	gridSize = size;
}

float DView::getGridSize()
{
	return gridSize;
}

void DView::setGridStep(float step)
{
	gridStep = step;
}

float DView::getGridStep()
{
	return gridStep;
}

void DView::setGridColor(float r, float g, float b)
{
	gridColor[0] = r;
	gridColor[1] = g;
	gridColor[2] = b;
}

void DView::getGridColor(float& r, float& g, float& b)
{
	r = gridColor[0];
	g = gridColor[1];
	b = gridColor[2];
}

void DView::setGridHighlightColor(float r, float g, float b)
{
	gridHighlightColor[0] = r;
	gridHighlightColor[1] = g;
	gridHighlightColor[2] = b;
}

void DView::getGridHighlightColor(float& r, float& g, float& b)
{
	r = gridHighlightColor[0];
	g = gridHighlightColor[1];
	b = gridHighlightColor[2];
}

void DView::setShowStats(bool val)
{
	m_showStats = val;
}

void DView::startFPS()
{
	m_fps = 0;
	m_timer.reset();
	m_frameCount = 0;
}

void DView::checkFPS()
{
	float elapsedTime = m_timer.getElapsedTime();
	m_fps = (float) m_frameCount / elapsedTime;
}

bool DView::isShowStats()
{
	return m_showStats;
}

void DView::showStats()
{
	glMatrixMode(GL_PROJECTION);
    glPushMatrix() ;
    glLoadIdentity() ;
    
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix() ;
    glLoadIdentity() ;

    gluOrtho2D(0.0f, 1.0f, 0.0f, 1.0f) ;
    
	glPushAttrib(GL_LIGHTING_BIT | GL_DEPTH_BUFFER_BIT);
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
//	fltk::glsetfont(HELVETICA, 12);
	checkFPS();

	static char buff[64];
	/*sprintf(buff, "Camera %4.2f %4.2f %4.2f Target %4.2f %4.2f %4.2f "
				  "Distance %4.2f "
				  "PanX %4.2f PanY %4.2f "
				  "FOV %4.2f", 
				  "FPS %6.2f",
				  Camera[0], Camera[1], Camera[2], 
				  Target[0], Target[1], Target[2], 
				  Dist, 
				  Panx, Pany, 
				  fov,
				  m_fps);*/
	if (m_fps < 10000 && m_fps > 0)
		sprintf(buff, "FPS %6.2f", m_fps);
	else
		sprintf(buff, "FPS N/A");


    glColor3f(1.0, 1.0, 0.0);
    glRasterPos3f(0, .1f, 0);
	fltk::gldrawtext(buff, strlen(buff));
 
	glPopAttrib();

	glMatrixMode(GL_PROJECTION) ;
    glPopMatrix() ;

    glMatrixMode(GL_MODELVIEW) ;
    glPopMatrix() ;

}

void DView::accFrustum(GLdouble left, GLdouble right, GLdouble bottom,
    GLdouble top, GLdouble m_near, GLdouble m_far, GLdouble pixdx, 
    GLdouble pixdy, GLdouble eyedx, GLdouble eyedy, 
    GLdouble focus)
{
    GLdouble xwsize, ywsize; 
    GLdouble dx, dy;
    GLint viewport[4];

    glGetIntegerv (GL_VIEWPORT, viewport);

    xwsize = right - left;
    ywsize = top - bottom;
    dx = -(pixdx*xwsize/(GLdouble) viewport[2] + 
            eyedx*m_near/focus);
    dy = -(pixdy*ywsize/(GLdouble) viewport[3] + 
            eyedy*m_near/focus);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum (left + dx, right + dx, bottom + dy, top + dy, 
        m_near, m_far);
    glMatrixMode(GL_MODELVIEW);
//    glLoadIdentity();
//    glTranslatef (-eyedx, -eyedy, 0.0);
}

void DView::accPerspective(GLdouble fovy, GLdouble aspect, 
    GLdouble m_near, GLdouble m_far, GLdouble pixdx, GLdouble pixdy, 
    GLdouble eyedx, GLdouble eyedy, GLdouble focus)
{
    GLdouble fov2,left,right,bottom,top;
	fov2 = ((fovy* M_PI) / 180.0) / 2.0;

    top = m_near / (cos(fov2) / sin(fov2));
    bottom = -top;
    right = top * aspect;
    left = -right;

    accFrustum (left, right, bottom, top, m_near, m_far, pixdx, pixdy, eyedx, eyedy, focus);
}

void DView::resetLights()
{
	for (int x = 0; x < dance::AllLights->size(); x++)
	{
		DLight* light = dynamic_cast<DLight*>(dance::AllLights->get(x));
		light->init();
	}
}

void DView::init_antialiasing()
{
	jitter_times = 1;

	m_jp[2][0].x = 0.25;
	m_jp[2][0].y = 0.75;
	m_jp[2][1].x = 0.75;
	m_jp[2][1].y = 0.25;

	m_jp[3][0].x = 0.5033922635;
	m_jp[3][0].y = 0.8317967229;
	m_jp[3][1].x = 0.7806016275;
	m_jp[3][1].y = 0.2504380877;
	m_jp[3][2].x = 0.2261828938;
	m_jp[3][2].y = 0.4131553612;

	m_jp[4][0].x = 0.375;
	m_jp[4][0].y= 0.25;
	m_jp[4][1].x = 0.125;
	m_jp[4][1].y= 0.75;
	m_jp[4][2].x = 0.875;
	m_jp[4][2].y= 0.25;
	m_jp[4][3].x = 0.625;
	m_jp[4][3].y= 0.75;

	m_jp[5][0].x = 0.5;
	m_jp[5][0].y = 0.5;
	m_jp[5][1].x = 0.3;
	m_jp[5][1].y = 0.1;
	m_jp[5][2].x = 0.7;
	m_jp[5][2].y = 0.9;
	m_jp[5][3].x = 0.9;
	m_jp[5][3].y = 0.3;
	m_jp[5][4].x = 0.1;
	m_jp[5][4].y = 0.7;

	m_jp[6][0].x = 0.4646464646;
	m_jp[6][0].y = 0.4646464646;
	m_jp[6][1].x = 0.1313131313;
	m_jp[6][1].y = 0.7979797979;
	m_jp[6][2].x = 0.5353535353;
	m_jp[6][2].y = 0.8686868686;
	m_jp[6][3].x = 0.8686868686;
	m_jp[6][3].y = 0.5353535353;
	m_jp[6][4].x = 0.7979797979;
	m_jp[6][4].y = 0.1313131313;
	m_jp[6][5].x = 0.2020202020;
	m_jp[6][5].y = 0.2020202020;


	m_jp[8][0].x = 0.5625;
	m_jp[8][0].y= 0.4375;
	m_jp[8][1].x = 0.0625;
	m_jp[8][1].y= 0.9375;
	m_jp[8][2].x = 0.3125;
	m_jp[8][2].y= 0.6875;
	m_jp[8][3].x = 0.6875;
	m_jp[8][3].y= 0.8125;
	m_jp[8][4].x = 0.8125;
	m_jp[8][4].y= 0.1875;
	m_jp[8][5].x = 0.9375;
	m_jp[8][5].y= 0.5625;
	m_jp[8][6].x = 0.4375;
	m_jp[8][6].y= 0.0625;
	m_jp[8][7].x = 0.1875;
	m_jp[8][7].y= 0.3125;
}

void DView::setTarget(Vector t)
{
	for (int x = 0; x < 3; x++)
		Target[x] = t[x];

	if (this->m_viewWindow != NULL)
		this->m_viewWindow->updateGUI();

	m_cameraMoved = true;
}


double* DView::getTarget()
{
	return &Target[0];
}

void DView::setCamera(Vector t)
{
	for (int x = 0; x < 3; x++)
		Camera[x] = t[x];

	if (this->m_viewWindow != NULL)
		this->m_viewWindow->updateGUI();
	
	m_cameraMoved = true;
}


double* DView::getCamera()
{
	float mat[4][4];
	this->getCameraTransformation(mat);

	for (int x = 0; x < 3; x++)
		Camera[x] = mat[3][x];

	return &Camera[0];
}

int DView::isLights()
{
	return Lights;
}

int DView::isShadows()
{
	return Shadows;
}
int DView::isSolids()
{
	return Solids;
}

double DView::getCameraDistance()
{
	return Dist;
}

void DView::setDistance(double dist)
{
	Dist = dist;
}

double DView::getDistance()
{
	return Dist;
}

void DView::setFOV(double f)
{
	fov = f;
}

double DView::getFOV()
{
	return fov;
}

void DView::save(int mode, std::ofstream& file)
{
	DObject::save(mode, file);

	if (mode == 0)
	{
		file << "dance.instance(\"view\", \"" << this->getName() << "\")" << std::endl;
	}
	else if (mode == 1)
	{
		char buff[512];

		if (this->getProjectionType() == VIEW_PERSP)
			sprintf(buff, "\"projtype\", \"persp\"");
		if (this->getProjectionType() == VIEW_TOP)
			sprintf(buff, "\"projtype\", \"top\"");
		if (this->getProjectionType() == VIEW_RIGHT)
			sprintf(buff, "\"projtype\", \"right\"");
		if (this->getProjectionType() == VIEW_FRONT)
			sprintf(buff, "\"projtype\", \"front\"");

		pythonSave(file, buff);

		// orientation of the view
		HMatrix mat;
		ball->value(mat);
		sprintf(buff,"\"orientation\", %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f", 
			((float *)mat)[0], ((float *)mat)[1], ((float *)mat)[2], ((float *)mat)[3],
			((float *)mat)[4], ((float *)mat)[5], ((float *)mat)[6], ((float *)mat)[7],
			((float *)mat)[8], ((float *)mat)[9], ((float *)mat)[10], ((float *)mat)[11],
			((float *)mat)[12], ((float *)mat)[13], ((float *)mat)[14], ((float *)mat)[15]);
		pythonSave(file, buff);

		// distance
		sprintf(buff, "\"distance\", %f", Dist);
		pythonSave(file, buff);

		// target
		sprintf(buff, "\"target\", %f, %f, %f", Target[0],Target[1],Target[2]);
		pythonSave(file, buff);

		// pan
		sprintf(buff, "\"pan\", %f, %f", Panx, Pany);
		pythonSave(file, buff);

		// background color
		sprintf(buff, "\"background\", %f, %f, %f, %f", BackgroundColor[0],BackgroundColor[1],BackgroundColor[2],BackgroundColor[3]);
		pythonSave(file, buff);

		// clip bounds
		sprintf(buff, "\"clipBounds\", %f, %f, %f, %f, %f, %f", Left, Right, Bottom, Top, Near, Far);
		pythonSave(file, buff);

		// grid
		if (this->showGrid())
		{
			sprintf(buff, "\"grid\", \"on\"");
		}
		else
		{
			sprintf(buff, "\"grid\", \"off\"");
		}
		pythonSave(file, buff);

		// grid color
		float color[3];
		this->getGridColor(color[0], color[1], color[2]);
		sprintf(buff, "\"gridColor\", %f, %f, %f", color[0], color[1], color[2]);
		pythonSave(file, buff);

		// grid highlight color
		this->getGridHighlightColor(color[0], color[1], color[2]);
		sprintf(buff, "\"gridHighlightColor\", %f, %f, %f", color[0], color[1], color[2]);
		pythonSave(file, buff);

		// shadows
		if (this->isShadows())
			sprintf(buff, "\"shadows\", \"on\"");
		else
			sprintf(buff, "\"shadows\", \"off\"");
		pythonSave(file, buff);

		// solids/wireframe
		if (this->isSolids())
			sprintf(buff, "\"solids\", \"on\"");
		else
			sprintf(buff, "\"solids\", \"off\"");
		pythonSave(file, buff);

	}

}


void DView::draw(int mode, int side)
{
	glEnable(GL_LIGHTING) ;
	if( 1) //!this->isShadows() )
	{
		this->start() ;
		this->PositionCamera() ;

		drawObjects(mode) ;
		// show the grid
		if (this->showGrid())
		{
			glCallList(this->GridList);
		}
		this->end() ;
		return ;
	}

	this->PositionCamera() ;
	InitShadowMap() ;
	
	int w = this->getWidth() ;
	int h = this->getHeight() ;
	GLfloat lightPosition[4] ;
	DLight *light = (DLight *) dance::AllLights->get(0) ;
	light->getPosition(lightPosition) ;

	//First pass - from light's point of view
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glMatrixMode(GL_PROJECTION);
	glLoadMatrixd(m_lightProjectionMatrix);

	glMatrixMode(GL_MODELVIEW);
	glLoadMatrixd(m_lightViewMatrix);

	//Use viewport the same size as the shadow map
	glViewport(0, 0, m_shadowMapSize, m_shadowMapSize);



	//Draw back faces into the shadow map
	glCullFace(GL_FRONT);
	glEnable(GL_CULL_FACE) ;

	//Disable color writes, and use flat shading for speed
	glShadeModel(GL_FLAT);
	glColorMask(0, 0, 0, 0);
	
	//Draw the scene
	drawObjects(mode | LDISPLAY_COMPUTE_SHADOW_MAP) ;
	
	//Read the depth buffer into the shadow map texture
	glBindTexture(GL_TEXTURE_2D, m_shadowMapTexture);
	glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, m_shadowMapSize, m_shadowMapSize);
	//GLfloat buf[262144] ;
	//glReadPixels(0, 0,  m_shadowMapSize, m_shadowMapSize,  GL_DEPTH_COMPONENT, GL_FLOAT, buf) ;

	//restore states
	glCullFace(GL_BACK);
	glShadeModel(GL_SMOOTH);
	glColorMask(1, 1, 1, 1);

	glDepthFunc(GL_LEQUAL);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND) ;
	
	

	//2nd pass - Draw from camera's point of view
	for( int i = 0 ; i < dance::AllLights->size() ; i++)
	{
		DLight *l = (DLight *) dance::AllLights->get(i) ;
		glDisable(l->getLightID() ) ;
	}
		this->PositionCamera() ;
	glClear(GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadMatrixd(Projection);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadMatrixd(Modelview);

	glViewport(0, 0, w, h);
	
	for( int i = 0 ; i < dance::AllLights->size() ; i++)
	{
		DLight *l = (DLight *) dance::AllLights->get(i) ;
		glEnable(l->getLightID() ) ;
	}

	glDisable(GL_BLEND) ;
	drawObjects(mode) ;
	


	//3rd pass
	//Draw with bright light
	light->init() ; // reset the lights
	for( int i = 0 ; i < dance::AllLights->size() ; i++)
	{
		DLight *l = (DLight *) dance::AllLights->get(i) ;
		glEnable(l->getLightID() ) ;
	}
	
	//Calculate texture matrix for projection
	//This matrix takes us from eye space to the light's clip space
	//It is postmultiplied by the inverse of the current view matrix when specifying texgen
	double  biasMatrix[4][4] = { {0.5f, 0.0f, 0.0f, 0.0f},
								{0.0f, 0.5f, 0.0f, 0.0f},
								{0.0f, 0.0f, 0.5f, 0.0f},
								{0.5f, 0.5f, 0.5f, 1.0f}};	//bias from [-1, 1] to [0, 1]
	
	//textureMatrix=biasMatrix*lightProjectionMatrix*lightViewMatrix;
	double textureMatrix[4][4] ;
	double biasMatrixTimesLightProjectionMatrix[4][4] ;

	//multArray(&biasMatrixTimesLightProjectionMatrix[0][0], &biasMatrix[0][0], m_lightProjectionMatrix,4,4,4) ;
	//multArray(&textureMatrix[0][0], &biasMatrixTimesLightProjectionMatrix[0][0],m_lightViewMatrix, 4,4,4) ;
	
	multArray(&biasMatrixTimesLightProjectionMatrix[0][0], m_lightProjectionMatrix, &biasMatrix[0][0],4,4,4) ;
	multArray(&textureMatrix[0][0], m_lightViewMatrix, &biasMatrixTimesLightProjectionMatrix[0][0], 4,4,4) ;
	

	double row[4] ;
	//Set up texture coordinate generation.
	for( int i = 0 ; i < 4 ; i++ )
	{
		row[i] = textureMatrix[i][0] ;
	}
	
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexGendv(GL_S, GL_EYE_PLANE, row); // row 0
	glEnable(GL_TEXTURE_GEN_S);

	for( int i = 0 ; i < 4 ; i++ )
	{
		row[i] = textureMatrix[i][1] ;
	}
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexGendv(GL_T, GL_EYE_PLANE, row); // row 1
	glEnable(GL_TEXTURE_GEN_T);

	for( int i = 0 ; i < 4 ; i++ )
	{
		row[i] = textureMatrix[i][2] ;
	}
	glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexGendv(GL_R, GL_EYE_PLANE, row); // row 2
	glEnable(GL_TEXTURE_GEN_R);

	for( int i = 0 ; i < 4 ; i++ )
	{
		row[i] = textureMatrix[i][3] ;
	}
	glTexGeni(GL_Q, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexGendv(GL_Q, GL_EYE_PLANE, row); // row 3
	glEnable(GL_TEXTURE_GEN_Q);

	//Bind & enable shadow map texture
	glBindTexture(GL_TEXTURE_2D, m_shadowMapTexture);
	glEnable(GL_TEXTURE_2D);

#ifdef WIN32
	//Enable shadow comparison
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE_ARB, GL_COMPARE_R_TO_TEXTURE);

	//Shadow comparison should be true (ie not in shadow) if r<=texture
	//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC_ARB, GL_LEQUAL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC_ARB, GL_GREATER);

	//Shadow comparison should generate an INTENSITY result
	glTexParameteri(GL_TEXTURE_2D, GL_DEPTH_TEXTURE_MODE_ARB, GL_INTENSITY);
#else
	//Enable shadow comparison
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_R_TO_TEXTURE);

	//Shadow comparison should be true (ie not in shadow) if r<=texture
	//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC_ARB, GL_LEQUAL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_GREATER);

	//Shadow comparison should generate an INTENSITY result
	glTexParameteri(GL_TEXTURE_2D, GL_DEPTH_TEXTURE_MODE_ARB, GL_INTENSITY);

#endif
	//Set alpha test to discard false comparisons
	glAlphaFunc(GL_GEQUAL, 0.99f);
	glEnable(GL_ALPHA_TEST);

	
	
	glCullFace(GL_BACK) ;
	glEnable(GL_CULL_FACE) ;
	glDisable(GL_LIGHTING) ;
	glColor4f(0.0,0.0,0.0,1) ;

	drawObjects(mode|LDISPLAY_USE_SHADOW_MAP) ;

	//Disable textures and texgen
	glDisable(GL_TEXTURE_2D);

	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_TEXTURE_GEN_R);
	glDisable(GL_TEXTURE_GEN_Q);

	//Restore other states
	glDisable(GL_ALPHA_TEST);


	// PASS 4 to get smooth shadows
	glEnable(GL_LIGHTING);
	glEnable(GL_BLEND) ;
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA) ;
	glHint(GL_LINE_SMOOTH_HINT, GL_DONT_CARE) ;
	drawObjects(mode|LDISPLAY_SHADOW_MAP_PASS4) ;
	glDisable(GL_BLEND);
	
	
	

}

void DView::drawObjects(int mode)
{
		// position the	lights
		if (this->isLights())
		{			
			for (int l = 0; l < dance::AllLights->size(); l++)
			{
				DLight* light = dynamic_cast<DLight*>(dance::AllLights->get(l));
				if (light->isVisible())
					light->output(mode);
			}
		}

		if( this->isSolids()) // show solids
			mode  = mode |  LDISPLAY_SOLID ;
		else // show wireframes
			mode  = mode |  LDISPLAY_WIRE;



		if ( !this->isListInitted() )
		{
			this->InitList();
			this->setListInitted(true);
		}

		dance::AllViews->output(mode);
		
		dance::AllSystems->output(mode);
		dance::AllSimulators->output(mode);
		// Added by Ari Shapiro 10/16/02
		dance::AllGenericPlugins->output(mode);

		dance::AllActuators->output(mode); 

		// Added by Ari Shapiro 6/7/03
		dance::AllGeometry->output(mode);

		// Added by Albert Chu 8/21/03
		dance::AllModifiers->output(mode);

		if (this->getMode() == DView::MODE_ARCBALL)
			this->drawArcball();	

		// fps?
		if (this->isShowStats())
		{
			this->showStats();
		}


}

void DView::setStartFrameNumber(int n)
{
	this->m_FrameNumber = n;
}

int DView::getStartFrameNumber()
{
	return this->m_FrameNumber;
}

void DView::setNear(double near)
{
	m_near = near;

	this->PositionCamera();
	this->resetLights();
	dance::AllViews->postRedisplay();
}

void DView::setFar(double far)
{
	m_far = far;

	this->PositionCamera();
	this->resetLights();
	dance::AllViews->postRedisplay();
}

double DView::getNear()
{
	return m_near;
}

double DView::getFar()
{
	return m_far;
}

void DView::setNeedsReset(bool val)
{
	m_needsReset = val;
}

bool DView::getNeedsReset()
{
	return m_needsReset;
}

void DView::setUseAnaglyph(bool val)
{
	m_useAnaglyph = val;
}

bool DView::getUseAnaglyph()
{
	return m_useAnaglyph;
}
