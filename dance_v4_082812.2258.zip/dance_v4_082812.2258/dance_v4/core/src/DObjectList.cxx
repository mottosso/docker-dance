/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "defs.h"
#include "danceInterp.h"
#include "DObjectList.h"
#include <stdlib.h>
#include "opengl.h"
#include "EventManager.h"
#include "dance.h"
#include "DConnectionManager.h"

#define	BINSIZE	10

DObjectList::DObjectList()
{
	numDObjects	= 0;
	numDanceBins = BINSIZE;
	Active = NULL;

	// Initialize plugin list.
	DObjects = (DObject **)malloc(sizeof(DObject *)*numDanceBins);

	m_id = DObject::GetNextID();

}

DObjectList::~DObjectList()
{
	for (int i=0; i	< numDObjects; i++)
		if (DObjects[i]) delete DObjects[i];
	free(DObjects);
}

// add:
//	Adds an	object to the list and set it as the active one.
bool DObjectList::add(DObject *obj)
{
	if (obj) {
		if (numDObjects == numDanceBins) {
		  numDanceBins += BINSIZE;
		  DObject **temp =
		  (DObject **)malloc(sizeof(DObject *)*numDanceBins);
		  memcpy(temp,DObjects,
			numDObjects	* sizeof(DObject *));
		  free(DObjects);
		  DObjects = temp;
		}
		Active = DObjects[numDObjects] = obj;
		numDObjects++;
	}
	else {
		danceInterp::OutputMessage("ERROR: add, passed in NULL pointer.");
		return false;
	}
	return true;

}

bool DObjectList::remove(int index)
{
	// Find	object at this index.
	DObject *obj = get(index);

	if (obj)
	{
		// check dependencies first
		DObjectRefList* deps = obj->getDependencies();
		int numDeps = deps->size();
		for (int i = numDeps - 1; i >= 0; i--)
		{
			DObject* object = deps->get(i);
			// unlink object
			object->removeDependencyReverse(obj);
		}

		// check the reverse dependencies
		DObjectRefList* revdeps = obj->getDependenciesReverse();
		int numDepsReverse = revdeps->size();
		for (int i = numDepsReverse - 1; i >= 0; i--)
		{
			DObject* object = revdeps->get(i);
			if (object == NULL)
				danceInterp::OutputMessage("No reverse dependency found for object %s. Check code.", obj->getName());
			else
				object->removeDependency(obj);
		}

	   if (Active == obj) Active = NULL;
	   obj->setSelected(false);

	   // remove from event manager
	   dance::eventManager->unregisterCollisionEvent(obj);

		// remove any connections to/from this object
		std::vector<DConnection*> list;
		dance::connectionManager->getConnections(obj, list);
		// remove any connection to this object
		for (std::vector<DConnection*>::iterator iter = list.begin();
			 iter != list.end();
			 iter++)
		{
			dance::connectionManager->removeConnection(*iter);
		}

		// remove attributes from this object
		std::map<std::string, DAttribute*>& attributeList = obj->getAttributeList();
		for (std::map<std::string, DAttribute*>::iterator iter = attributeList.begin();
			 iter != attributeList.end();
			 iter++)
		{
			delete iter->second;
		}

		// finally, remove the objects
		delete obj;

	   // Now shift	over all items down one.
	   for (int i =	index+1; i < numDObjects; i++)
		DObjects[i-1] = DObjects[i];
	   DObjects[numDObjects-1] = NULL;
	   numDObjects--;
	   return true;
	}
	return false;
}

bool DObjectList::remove(const char *name)
{
	// Find	object at this index.
	int index = getIndex(name);
	return remove(index);
}

bool DObjectList::remove(DObject* object)
{
	for (int x = 0; x < this->size(); x++)
	{
		if (this->get(x) == object)
		{
			return this->remove(x);
		}
	}

	return false;
}


void DObjectList::output(int mode)
{
	glPushName(this->getID());
	for (int i=0; i	< numDObjects; i++)	{
		glLoadName(DObjects[i]->getID());
		if (DObjects[i]->isVisible())
		{
			if (DObjects[i]->isSelected())
				mode = mode | LDISPLAY_SELECTION;
			DObjects[i]->output(mode);
		}
	}
	glPopName();
}

DObject *DObjectList::get(int index)
{
	if (index < 0 || index >= numDObjects)
		return NULL;
	return (DObjects[index]);
}


// get:	Returns	plugin by name
//
DObject *DObjectList::get(const char *name)
{
	DObject *plugin = NULL;
	for (int i=0; i	< numDObjects; i++)	{
		if (strcmp(DObjects[i]->getName(),name) == 0) {
			plugin = DObjects[i];
			break;
		}
	}

	return(plugin);
}

// getIndex: returns index, given name.
//
int DObjectList::getIndex(const char *name)
{
	for (int i=0; i	< numDObjects; i++)	{
		if (strcmp(DObjects[i]->getName(),name) == 0)
			return(i);
	}
	return(-1);
}

// Takes the name of the shared	object and finds the plugin
// The calling procedure has to	make sure that names
// are consistent!!

DObject *DObjectList::getByFileName(const char *name)
{
	DObject *plugin = NULL;
	for (int i=0; i	< numDObjects; i++)	{
		if (strcmp(DObjects[i]->getFileName(),name)	== 0) {
			plugin = DObjects[i];
			break;
		}
	}

	return(plugin);
}

// setActive:
//	Sets the active	object.
//
DObject *DObjectList::setActive(const char *name)
{
	if (name == NULL) {
		Active = NULL;
		return Active;
	}

	DObject *plugin = NULL;
	for (int i=0; i	< numDObjects; i++)	{
		if (strcmp(DObjects[i]->getName(),name) == 0) {
			plugin = DObjects[i];
			break;
		}
	}

	Active = plugin;
	return(Active);
}

// setActive:
//	Sets the active	object.
DObject *DObjectList::setActive(int index)
{
	if (index >= numDObjects ||	index <	0)
		Active = NULL;
	else
		Active = DObjects[index];
	return(Active);
}

// returns the number of objects that handled the keystroke
/*int DObjectList::KeyboardCB(unsigned char key, int x, int y)
{
    int count = 0 ;
    for (int i = 0; i	< numDObjects; i++)	{
       count += DObjects[i]->KeyboardCB(key, x, y) ;
    }
    return count ;
}
*/

unsigned int DObjectList::getID()
{
	return m_id;
}

int DObjectList::size()
{
	return numDObjects;
}

void DObjectList::save(int mode, std::ofstream& file)
{
	for (int x = 0; x < this->size(); x++)
	{
		DObject* object = this->get(x);
		object->save(mode, file);
	}
}

