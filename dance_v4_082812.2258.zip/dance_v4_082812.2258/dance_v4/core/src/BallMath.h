/**************************************************************************
	D.A.N.C.E.
	Dynamic Animation aNd Control Environment
	----------------------------------------------
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Ari Shapiro (ashapiro@cs.ucla.edu)
		Yong Cao (abingcao@cs.ucla.edu)
-----------------------------------------------
	
 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

 This software is distributed for noncommercial use in the hope that it will 
 be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
 to anyone for the consequences	of using it or for whether it serves any 
 particular purpose or works at all. No warranty is made about the software 
 or its performance.
***************************************************************************/


/***** BallMath.h - Essential routines for Arcball.  *****/
#ifndef	_H_BallMath
#define	_H_BallMath
#include "BallAux.h"

HVect MouseOnSphere(HVect mouse, HVect ballCenter, double ballRadius);

HVect ConstrainToAxis(HVect loose, HVect axis);

int NearestConstraintAxis(HVect	loose, HVect *axes, int	nAxes);

Quat Qt_FromBallPoints(HVect from, HVect to);

void Qt_ToBallPoints(Quat q, HVect *arcFrom, HVect *arcTo);

#endif
