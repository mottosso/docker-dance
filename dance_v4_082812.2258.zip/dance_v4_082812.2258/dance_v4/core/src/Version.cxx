#include "dance.h"
#include <sstream>

#define DANCEMAJORVERSION "4"
#define DANCEMINORVERSION "022712"

std::string dance::getMajorVersion()
{
	std::stringstream str;
	str << DANCEMAJORVERSION;
	return str.str();
}

std::string dance::getMinorVersion()
{
	std::stringstream str;
	str << DANCEMINORVERSION;
	return str.str();
}

