/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "AttributeWindow.h"

#include "dance.h"
#include "danceInterp.h"
#include "ViewManager.h"
#include "DObject.h"
#include <fltk/ColorChooser.h>
#include <fltk/Color.h>
#include <fltk/ask.h>
#include <fltk/CheckButton.h>
#include <fltk/Choice.h>
#include <fltk/ThumbWheel.h>
#include <fltk/Slider.h>
#include <limits>
#include <algorithm>

using namespace fltk;

AttributeWindow::AttributeWindow(DObject* obj, int x, int y, int w, int h, const char *s) : fltk::PackedGroup(x, y, w, h, s)
{
//	this->type(VERTICAL);

	setObject(obj);
	this->begin();
//	fltk::PackedGroup* packGroup = new fltk::PackedGroup(x, y, w, h);
//	packGroup->box(fltk::BORDER_FRAME);
//	packGroup->begin();
		//CollapsibleGroup* collapsibleGroup = new CollapsibleGroup(5, 5, w - 5, h, "Attributes");
		CollapsibleGroup* collapsibleGroup = new CollapsibleGroup(5, 5, w - 5, h, "Attributes");
		collapsibleGroup->color(fltk::YELLOW);
		collapsibleGroup->begin();
			mainGroup = new fltk::PackedGroup(80, 30, w - 85, 800);
			mainGroup->box(fltk::UP_BOX);
			mainGroup->begin();
			mainGroup->end();
		collapsibleGroup->end();
//	packGroup->end();
	this->box(DOWN_BOX);
	this->end();

	dirty = true;
}


AttributeWindow::~AttributeWindow()
{
}

void AttributeWindow::setDirty(bool val)
{
	dirty = val;
	//relayout();
}

void AttributeWindow::show()
{
	fltk::PackedGroup::show();
}

void AttributeWindow::setAttributeInfo(fltk::Widget* widget, DAttributeInfo* attrInfo)
{
	// this is NOT an efficient way to change the status of the widget...
	// since it requires one check for each widget
	fltk::Group* group = dynamic_cast<fltk::Group*>(widget);
	if (group)
	{
		for (int c = 0; c < group->children(); c++)
			setAttributeInfo(group->child(c), attrInfo);
		//group->redraw();
		//return;
	}

	if (attrInfo->getReadOnly())
	{
		if (widget->active())
			widget->deactivate();
	}
	else
	{
		if (!widget->active())
			widget->activate();
	}

	if (attrInfo->getHidden())
	{
		if (widget->visible())
			widget->hide();
	}
	else
	{
		if (!widget->visible())
			widget->show();
	}

	if (attrInfo->getLocked())
	{
		if (widget->color() != fltk::WHITE)
		{
			widget->color(fltk::WHITE);
			widget->redraw();
		}
	}
	else
	{
		if (widget->color() != fltk::GRAY75)
		{
			widget->color(fltk::GRAY75);
			widget->redraw();
		}
	}
	
	if (attrInfo->getPriority())
	{
		// reorder widget
	}
	else
	{
		// reorder widget
	}
}

bool AttributePriorityPredicate(const DAttribute* d1, const DAttribute* d2)
{
	DAttribute* a = const_cast<DAttribute*>(d1);
	DAttribute* b = const_cast<DAttribute*>(d2);
	
	if (a->getAttributeInfo()->getGroup() == b->getAttributeInfo()->getGroup())
	{
		return a->getAttributeInfo()->getPriority() < b->getAttributeInfo()->getPriority();
	}
	else 
	{
		if (a->getAttributeInfo()->getGroup() && b->getAttributeInfo()->getGroup())
			return a->getAttributeInfo()->getGroup()->getPriority() < b->getAttributeInfo()->getGroup()->getPriority();
		else if (a->getAttributeInfo()->getGroup())
			return true;
		else
			return false;
	}
}

void AttributeWindow::reorderAttributes()
{
	std::vector<DAttribute*> list;
	std::map<std::string, DAttribute*> attributes = object->getAttributeList();
	for (std::map<std::string, DAttribute*>::iterator iter = attributes.begin();
		iter != attributes.end();
		iter++)
	{
		if (!iter->second->getAttributeInfo()->getHidden())
			list.push_back(iter->second);
	}

	std::sort(list.begin(), list.end(), AttributePriorityPredicate);

	int widgetHeight = 25;
	int startY = 10;

	int numOutOfOrder = 0;
	int childNum = 0;
	int numChildren = mainGroup->children();
	for (std::vector<DAttribute*>::iterator sortedIter = list.begin();
		sortedIter != list.end();
		sortedIter++)
	{
		danceInterp::OutputMessage("Now writing attribute %s", (*sortedIter)->getName().c_str());
		// get the widget
		std::map<std::string, fltk::Widget*>::iterator mapIter = widgetMap.find((*sortedIter)->getName());
		if (mapIter != widgetMap.end())
		{
			fltk::Widget* widget = mapIter->second;
			if (mainGroup->child(childNum) != widget)
			{
				mainGroup->insert(*widget, childNum);
				numOutOfOrder++;
			}
			childNum++;
			/*
			int curY = widget->y();
			if (curY != startY) // make sure the widget is in the right place
			{
				widget->y(startY);
				numOutOfOrder++;
			}
			startY += widgetHeight;
			*/
		}
	}

	if (numOutOfOrder > 0)
		this->relayout();
}

void AttributeWindow::layout()
{
	if (dirty) 
	{
		std::vector<DAttributeGroup*>& attributeGroups = object->getAttributeManager()->getAttributeGroups();
		for (int g = 0; g < attributeGroups.size(); g++)
		{
		}


		int widgetHeight = 25;
		int startY = 10 + widgetHeight * widgetMap.size(); // start position for the next widget to be added
		std::map<std::string, DAttribute*>& attributes = object->getAttributeList();
		
		// compare the existing attribute list to the widget list
		std::map<std::string, int> attributeStatus;
		for (std::map<std::string, fltk::Widget*>::iterator mapIter = widgetMap.begin();
			 mapIter != widgetMap.end();
			 mapIter++)
		{
			attributeStatus[mapIter->first] = 0;
		}

		for (std::map<std::string, DAttribute*>::iterator iter = attributes.begin();
			iter != attributes.end();
			iter++)
		{
			DAttribute* attr = iter->second;
			std::string name = attr->getName();
			std::map<std::string, fltk::Widget*>::iterator mapIter = widgetMap.find(name);
			if (mapIter == widgetMap.end()) // widget not found, create it
			{
				attributeStatus[name] = 2; // attribute widget created

				DAttributeInfo* attrInfo = attr->getAttributeInfo();

				// bool -> checkbox
				BoolAttribute* boolAttr = dynamic_cast<BoolAttribute*>(attr);
				if (boolAttr) 
				{
					boolAttr->registerObserver(this);
					fltk::CheckButton* check = new fltk::CheckButton(100, startY, 150, 20, strdup(name.c_str()));
					check->flags(fltk::ALIGN_LEFT);
					check->value(boolAttr->getValue());
					startY += widgetHeight; // make sure the next widget starts lower
					check->callback(BoolCB, this);
					setAttributeInfo(check, attrInfo);
					mainGroup->add(check);
					widgetMap[name] = check;
					reverseWidgetMap[check] = name;
					continue;
				}
				// int -> input
				IntAttribute* intAttr = dynamic_cast<IntAttribute*>(attr);
				if (intAttr) 
				{
					intAttr->registerObserver(this);
					fltk::Group* intGroup = new fltk::Group(100, startY, 200, 20);
					intGroup->flags(fltk::ALIGN_LEFT);
					fltk::FloatInput* input = new fltk::FloatInput(0, 0, 60, 20, strdup(name.c_str()));
					input->value(intAttr->getValue());
					input->callback(IntCB, this);
					intGroup->add(input);
					// show a wheel is there is no limit
					// show a slider if there is a limit
					if (intAttr->getMin() == -std::numeric_limits<int>::max() || 
						intAttr->getMax() == std::numeric_limits<int>::max())
					{
						fltk::ThumbWheel* wheel = new fltk::ThumbWheel(70, 0, 100, 20);
						wheel->step(1);
						wheel->range(intAttr->getMin(), intAttr->getMax());
						wheel->value(intAttr->getValue());
						wheel->callback(IntCB, this);
						intGroup->add(wheel);
					}
					else
					{
						fltk::Slider* slider = new fltk::Slider(70, 0, 100, 20);
						slider->type(Slider::LINEAR);
						slider->step(1.0);
						slider->range(intAttr->getMin(), intAttr->getMax());
						slider->value(intAttr->getValue());
						slider->callback(IntCB, this);
						intGroup->add(slider);
					}
					
					startY += widgetHeight; // make sure the next widget starts lower
					
					setAttributeInfo(input, attrInfo);
					mainGroup->add(intGroup);
					widgetMap[name] = intGroup;
					reverseWidgetMap[intGroup] = name;
					continue;
				}
				// double -> floatinput
				DoubleAttribute* doubleAttr = dynamic_cast<DoubleAttribute*>(attr);
				if (doubleAttr) 
				{
					doubleAttr->registerObserver(this);
					fltk::Group* doubleGroup = new fltk::Group(100, startY, 200, 20);
					doubleGroup->flags(fltk::ALIGN_LEFT);
					fltk::FloatInput* input = new fltk::FloatInput(0, 0, 60, 20, strdup(name.c_str()));
					input->value(doubleAttr->getValue());
					input->callback(DoubleCB, this);
					doubleGroup->add(input);
					// show a wheel is there is no limit
					// show a slider if there is a limit
					if (doubleAttr->getMin() == -std::numeric_limits<double>::max() ||
						doubleAttr->getMax() == std::numeric_limits<double>::max())
					{
						fltk::ThumbWheel* wheel = new fltk::ThumbWheel(70, 0, 100, 20);
						wheel->step(.01);
						wheel->range(doubleAttr->getMin(), doubleAttr->getMax());
						wheel->value(doubleAttr->getValue());
						wheel->callback(DoubleCB, this);
						doubleGroup->add(wheel);
					}
					else
					{
						fltk::Slider* slider = new fltk::Slider(70, 0, 100, 20);
						slider->type(Slider::LINEAR);
						slider->step(.01);
						slider->range(doubleAttr->getMin(), doubleAttr->getMax());
						slider->value(doubleAttr->getValue());
						slider->callback(DoubleCB, this);
						doubleGroup->add(slider);
					}
					
					startY += widgetHeight; // make sure the next widget starts lower
					
					setAttributeInfo(doubleGroup, attrInfo);
					mainGroup->add(doubleGroup);
					widgetMap[name] = doubleGroup;
					reverseWidgetMap[doubleGroup] = name;
					continue;
				}
				// string -> input, or string -> choice
				StringAttribute* stringAttr = dynamic_cast<StringAttribute*>(attr);
				if (stringAttr) 
				{
					stringAttr->registerObserver(this);
					if (stringAttr->getValidValues().size() == 0)
					{
						fltk::Input* input = new fltk::Input(100, startY, 150, 20, strdup(name.c_str()));
						input->value(stringAttr->getValue().c_str());
						startY += widgetHeight; // make sure the next widget starts lower
						input->callback(StringCB, this);
						mainGroup->add(input);
						widgetMap[name] = input;
						reverseWidgetMap[input] = name;
					}
					else
					{
						fltk::Choice* choice = new fltk::Choice(100, startY, 150, 20, strdup(name.c_str()));
						// add all the options
						choice->add("-----");
						std::vector<std::string>& values = stringAttr->getValidValues();
						int selected = -1;
						for (int i = 0; i < values.size(); i++)
						{
							choice->add(values[i].c_str());
							if (stringAttr->getValue() == values[i])
								choice->value(i + 1);
						}
						if (stringAttr->getValue() == "")
							choice->value(0);
						startY += widgetHeight; // make sure the next widget starts lower
						choice->callback(StringCB, this);
						mainGroup->add(choice);
						widgetMap[name] = choice;
						reverseWidgetMap[choice] = name;
					}
					continue;
				}
				// vec3 -> 3 float inputs
				Vec3Attribute* vec3Attr = dynamic_cast<Vec3Attribute*>(attr);
				if (vec3Attr) 
				{
					vec3Attr->registerObserver(this);
					fltk::Group* vec3Group = new fltk::Group(100, startY, 200, 20, strdup(name.c_str()));
					vec3Group->flags(fltk::ALIGN_LEFT);
					double* val = vec3Attr->getValue();
					for (int x = 0; x < 3; x++)
					{
						fltk::FloatInput* finput = new fltk::FloatInput(x * 50, 0, 60, 20);
						finput->value(val[x]);
						finput->callback(Vec3CB, this);
						vec3Group->add(finput);
					}						
					startY += widgetHeight; // make sure the next widget starts lower
					setAttributeInfo(vec3Group, attrInfo);
					mainGroup->add(vec3Group);
					widgetMap[name] = vec3Group;
					reverseWidgetMap[vec3Group] = name;
					continue;
				}
			}
			else
			{
				attributeStatus[mapIter->first] = 1; // attribute widget found

				// check the string widgets to make sure that the valid values haven't changes
				StringAttribute* stringAttr = dynamic_cast<StringAttribute*>(attr);
				if (stringAttr) 
				{
					std::vector<std::string>& validValues = stringAttr->getValidValues();
					if (validValues.size() > 0)
					{
						bool resetChoiceList = false;
						fltk::Choice* choice = dynamic_cast<fltk::Choice*>(mapIter->second);
						if (choice)
						{
							if (validValues.size() != choice->children())
							{
								resetChoiceList = true;
							}
							else 
							{
								for (int c = 0; c < choice->children(); c++)
								{
									if (validValues[c] != choice->child(c)->label())
									{
										resetChoiceList = true;
										break;
									}
								}
							}
							if (resetChoiceList)
							{
								for (int c = choice->children() - 1; c >= 0; c--)
								{
									fltk::Widget* childWidget = choice->child(c);
									choice->remove(childWidget);
									delete childWidget;
								}
								choice->add("-----");
								for (int i = 0; i < validValues.size(); i++)
								{
									choice->add(validValues[i].c_str());
									if (stringAttr->getValue() == validValues[i])
										choice->value(i + 1);
								}
								if (stringAttr->getValue() == "")
									choice->value(0);
								choice->callback(StringCB, this); // is this necessary?
							}
						}
					}
				}
			}
		}

		// remove any unused attributes
		for (std::map<std::string, fltk::Widget*>::iterator mapIter = widgetMap.begin();
			 mapIter != widgetMap.end();
			 mapIter++)
		{
			if (attributeStatus[mapIter->first] == 0) 
			{
				mainGroup->remove(mapIter->second);
			}
		}

		reorderAttributes();
		dirty = false;
	}

	fltk::PackedGroup::layout();
}

void AttributeWindow::draw() 
{
	
	fltk::PackedGroup::draw();
}

DObject* AttributeWindow::getObject()
{
	return object;
}

void AttributeWindow::setObject(DObject* g)
{
	object = g;
	object->getAttributeManager()->registerObserver(this);
}

void AttributeWindow::BoolCB(Widget *w, void *data)
{
	AttributeWindow *cw = (AttributeWindow*) data;
	
	fltk::CheckButton* check = (fltk::CheckButton*) w;
	DObject* obj = cw->getObject();
	
	std::string name = "";
	std::map<fltk::Widget*, std::string>::iterator iter = cw->reverseWidgetMap.find(w);
	if (iter !=  cw->reverseWidgetMap.end())
		name = iter->second;
		
	if (name != "")
	{
		DAttribute* attr = obj->getAttribute(name);
		BoolAttribute* battr = dynamic_cast<BoolAttribute*>(attr);
		if (battr)
		{
			battr->setValue(check->value());
		}
		else
		{
			danceInterp::OutputMessage("Attribute with name %s.%s is not a boolean attribute. Please check code.", obj->getName(), check->label());
		}
	}
	else
	{
		danceInterp::OutputMessage("Attribute with name %s.%s is no longer present.", obj->getName(), check->label());
	}
}

void AttributeWindow::IntCB(Widget *w, void *data)
{
	AttributeWindow *attrWin = (AttributeWindow*) data;
	
	fltk::Group* intGroup = w->parent();

	fltk::FloatInput* input = dynamic_cast<fltk::FloatInput*>(intGroup->child(0));
	fltk::ThumbWheel* wheel = dynamic_cast<fltk::ThumbWheel*>(intGroup->child(1));
	fltk::Slider* slider = dynamic_cast<fltk::Slider*>(intGroup->child(1));
				
	// get the name of the attribute
	std::string name = "";
	std::map<fltk::Widget*, std::string>::iterator iter = attrWin->reverseWidgetMap.find(intGroup);
	if (iter !=  attrWin->reverseWidgetMap.end())
		name = iter->second;

	DObject* obj = attrWin->getObject();
	
	if (name != "")
	{
		DAttribute* attr = obj->getAttribute(name);
		IntAttribute* iattr = dynamic_cast<IntAttribute*>(attr);
		if (iattr)
		{
			// where did the input come from? The input, the wheel or the slider?
			int val = 0;
			if (w == input)
			{
				val = int(input->fvalue());
			}
			else if (w == wheel)
			{
				val = int(wheel->value());
			}
			else if (w == slider)
			{
				val = int(slider->value());
			}
			iattr->setValue(val);
		}
		else
		{
			danceInterp::OutputMessage("Attribute with name %s.%s is not an int attribute. Please check code.", obj->getName(), input->label());
		}
	}
	else
	{
		danceInterp::OutputMessage("Attribute with name %s.%s is no longer present.", obj->getName(), input->label());
	}
}

void AttributeWindow::DoubleCB(Widget *w, void *data)
{
	AttributeWindow *attrWin = (AttributeWindow*) data;
	
	fltk::Group* doubleGroup = w->parent();

	fltk::FloatInput* input = dynamic_cast<fltk::FloatInput*>(doubleGroup->child(0));
	fltk::ThumbWheel* wheel = dynamic_cast<fltk::ThumbWheel*>(doubleGroup->child(1));
	fltk::Slider* slider = dynamic_cast<fltk::Slider*>(doubleGroup->child(1));
				
	// get the name of the attribute
	std::string name = "";
	std::map<fltk::Widget*, std::string>::iterator iter = attrWin->reverseWidgetMap.find(doubleGroup);
	if (iter !=  attrWin->reverseWidgetMap.end())
		name = iter->second;

	DObject* obj = attrWin->getObject();
	
	if (name != "")
	{
		DAttribute* attr = obj->getAttribute(name);
		DoubleAttribute* dattr = dynamic_cast<DoubleAttribute*>(attr);
		if (dattr)
		{
			// where did the input come from? The input, the wheel or the slider?
			double val = 0;
			if (w == input)
			{
				val = input->fvalue();
			}
			else if (w == wheel)
			{
				val = wheel->value();
			}
			else if (w == slider)
			{
				val = slider->value();
			}
			dattr->setValue(val);
		}
		else
		{
			danceInterp::OutputMessage("Attribute with name %s.%s is not a double attribute. Please check code.", obj->getName(), input->label());
		}
	}
	else
	{
		danceInterp::OutputMessage("Attribute with name %s.%s is no longer present.", obj->getName(), input->label());
	}
}

void AttributeWindow::StringCB(Widget *w, void *data)
{
	AttributeWindow *cw = (AttributeWindow*) data;
	
	fltk::Input* input = dynamic_cast<fltk::Input*>(w);
	fltk::Choice* choice = dynamic_cast<fltk::Choice*>(w);

	DObject* obj = cw->getObject();
	
	// get the name of the attribute
	std::string name = "";
	std::map<fltk::Widget*, std::string>::iterator iter = cw->reverseWidgetMap.find(w);
	if (iter !=  cw->reverseWidgetMap.end())
		name = iter->second;

	if (name != "")
	{
		DAttribute* attr = obj->getAttribute(name);
		StringAttribute* strattr = dynamic_cast<StringAttribute*>(attr);
		if (strattr)
		{
			if (input)
			{
				strattr->setValue(input->value());
			}
			else
			{
				std::string choiceValue = choice->child(choice->value())->label();
				if (choiceValue == "-----")
					choiceValue = "";
				strattr->setValue(choiceValue);
			}
		}
		else
		{
			danceInterp::OutputMessage("Attribute with name %s.%s is not a string attribute. Please check code.", obj->getName(), input->label());
		}
	}
	else
	{
		danceInterp::OutputMessage("Attribute with name %s.%s is no longer present.", obj->getName(), input->label());
	}
}

void AttributeWindow::Vec3CB(Widget *w, void *data)
{
	AttributeWindow *attrWin = (AttributeWindow*) data;
	
	fltk::FloatInput* finput = (fltk::FloatInput*) w;
	fltk::Group* group = finput->parent();
	DObject* obj = attrWin->getObject();
	
	// get the name of the attribute
	std::string name = "";
	std::map<fltk::Widget*, std::string>::iterator iter = attrWin->reverseWidgetMap.find(group);
	if (iter !=  attrWin->reverseWidgetMap.end())
		name = iter->second;

	if (name != "")
	{
		DAttribute* attr = obj->getAttribute(name);
		Vec3Attribute* vec3attr = dynamic_cast<Vec3Attribute*>(attr);
		if (vec3attr)
		{
			// get all the children of the group
			Vector val;
			fltk::FloatInput* finput[3];
			for (int x = 0; x < 3; x++)
			{
				finput[x] = (fltk::FloatInput*) group->child(x);
				val[x] = finput[x]->fvalue();
			}
			vec3attr->setValue(val);
		}
		else
		{
			danceInterp::OutputMessage("Attribute with name %s.%s is not a vec3 attribute. Please check code.", obj->getName(), group->label());
		}
	}
	else
	{
		danceInterp::OutputMessage("Attribute with name %s.%s is no longer present.", obj->getName(), group->label());
	}
}

void AttributeWindow::notify(DSubject* subject)
{
	if (subject == this->getObject()->getAttributeManager())
	{
		setDirty(true);
		//relayout();
		return;
	}

	// assume that the notification came from a change in attribute value 
	// directly from the attribute
	DAttribute* attr = dynamic_cast<DAttribute*>(subject);
	if (attr)
	{
		DAttributeInfo* attrInfo = attr->getAttributeInfo();

		fltk::Widget* widget = NULL;
		// make sure that the attribute exists in the attribute map
		std::map<std::string, fltk::Widget*>::iterator iter = widgetMap.find(attr->getName());
		if (iter == widgetMap.end())
		{
			danceInterp::OutputMessage("Widget for attribute %s.%s was not found. Please check code.", this->object->getName(), attr->getName().c_str());
			return;
		}
		BoolAttribute* battr = dynamic_cast<BoolAttribute*>(attr);
		if (battr)
		{
			fltk::CheckButton* check = (fltk::CheckButton*) iter->second;
			check->value(battr->getValue());
			setAttributeInfo(check, attrInfo);
			return;
		}
		IntAttribute* iattr = dynamic_cast<IntAttribute*>(attr);
		if (iattr)
		{
			fltk::Group* group = (fltk::Group*) iter->second;
			int val = iattr->getValue();
			fltk::FloatInput* input = (fltk::FloatInput*) group->child(0);
			input->value(int(val));
			fltk::ThumbWheel* wheel = dynamic_cast<fltk::ThumbWheel*>( group->child(1));
			fltk::Slider* slider = dynamic_cast<fltk::Slider*>( group->child(1));
			if (wheel)
			{
				wheel->value(val);
			}
			else if (slider)
			{
				slider->value(val);
			}
			// did the range so as to cause a widget change type?
			if (wheel && 
				(iattr->getMin() != -std::numeric_limits<int>::max() && 
				 iattr->getMax() != std::numeric_limits<int>::max()))
			{
				// change the wheel to a slider
				int xpos = wheel->x();
				int ypos = wheel->y();
				int width = wheel->w();
				int height = wheel->h();
				fltk::Slider* slider = new fltk::Slider(xpos, ypos, width, height);
				slider->type(Slider::LINEAR);
				slider->range(float(iattr->getMin()), float(iattr->getMax()));
				slider->step(1);
				slider->value(val);
				slider->callback(IntCB, this);
				group->remove(wheel);
				group->add(slider);
				delete wheel;
			}
			else if (wheel && 
					 (wheel->minimum() != iattr->getMin() &&
					  wheel->maximum() != iattr->getMax()))
			{
				wheel->range(float(iattr->getMin()), float(iattr->getMax()));
			}
			else if (slider && 
				(iattr->getMin() == -std::numeric_limits<int>::max() && 
				 iattr->getMax() == std::numeric_limits<int>::max()))
			{
				// change the slider to a wheel
				int xpos = slider->x();
				int ypos = slider->y();
				int width = slider->w();
				int height = slider->h();
				fltk::ThumbWheel* wheel = new fltk::ThumbWheel(xpos, ypos, width, height);
				wheel->range(float(iattr->getMin()), float(iattr->getMax()));
				wheel->step(1);
				wheel->value(val);
				wheel->callback(IntCB, this);
				group->remove(slider);
				group->add(wheel);
				delete slider;
			}
			else if (slider && 
					 (slider->minimum() != iattr->getMin() &&
					  slider->maximum() != iattr->getMax()))
			{
				slider->range(float(iattr->getMin()), float(iattr->getMax()));
			}

			setAttributeInfo(group, attrInfo);
			
			return;
		}
		DoubleAttribute* dattr = dynamic_cast<DoubleAttribute*>(attr);
		if (dattr)
		{
			fltk::Group* group = (fltk::Group*) iter->second;
			double val = dattr->getValue();
			fltk::FloatInput* input = (fltk::FloatInput*) group->child(0);
			input->value(val);
			fltk::ThumbWheel* wheel = dynamic_cast<fltk::ThumbWheel*>(group->child(1));
			fltk::Slider* slider = dynamic_cast<fltk::Slider*>(group->child(1));
			if (wheel)
			{
				wheel->value(val);
			}
			else if (slider)
			{
				slider->value(val);
			}
			// did the range so as to cause a widget change type?
			if (wheel && 
				(dattr->getMin() != -std::numeric_limits<double>::max() && 
				 dattr->getMax() != std::numeric_limits<double>::max()))
			{
				// change the wheel to a slider
				int xpos = wheel->x();
				int ypos = wheel->y();
				int width = wheel->w();
				int height = wheel->h();
				fltk::Slider* slider = new fltk::Slider(xpos, ypos, width, height);
				slider->type(Slider::LINEAR);
				slider->range(dattr->getMin(), dattr->getMax());
				slider->step(.01);
				slider->value(val);
				slider->callback(DoubleCB, this);
				group->remove(wheel);
				group->add(slider);
				delete wheel;
			}
			else if (wheel && 
					 (wheel->minimum() != dattr->getMin() &&
					  wheel->maximum() != dattr->getMax()))
			{
				wheel->range(dattr->getMin(), dattr->getMax());
			}
			else if (slider && 
				(dattr->getMin() == -std::numeric_limits<double>::max() && 
				 dattr->getMax() == std::numeric_limits<double>::max()))
			{
				// change the slider to a wheel
				int xpos = slider->x();
				int ypos = slider->y();
				int width = slider->w();
				int height = slider->h();
				fltk::ThumbWheel* wheel = new fltk::ThumbWheel(xpos, ypos, width, height);
				wheel->range(dattr->getMin(), dattr->getMax());
				wheel->step(.01);
				wheel->value(val);
				wheel->callback(DoubleCB, this);
				group->remove(slider);
				group->add(wheel);
				delete slider;
			}
			else if (slider && 
					 (slider->minimum() != dattr->getMin() &&
					  slider->maximum() != dattr->getMax()))	
			{
				slider->range(dattr->getMin(), dattr->getMax());
			}
			
			setAttributeInfo(group, attrInfo);

			return;
		}
		StringAttribute* sattr = dynamic_cast<StringAttribute*>(attr);
		if (sattr)
		{
			std::vector<std::string>& validValues = sattr->getValidValues();
			if (validValues.size() == 0)
			{

				fltk::Input* input = dynamic_cast<fltk::Input*>(iter->second);
				if (!input)
				{ // widget used to be a list of values, so erase that widget and have it remade automatically
					// remove the widget from the attribute window
					mainGroup->remove(iter->second);
					// remove the widget from the attribute map
					widgetMap.erase(iter);
					dirty = true;
					return;
				}
				input->value(sattr->getValue().c_str());
 				setAttributeInfo(input, attrInfo);
			}
			else
			{
				fltk::Choice* choice = dynamic_cast<fltk::Choice*>(iter->second);
				if (!choice)
				{ // widget used to be an input, so erase that widget and have it remade automatically
					// remove the widget from the attribute window
					mainGroup->remove(iter->second);
					// remove the widget from the attribute map
					widgetMap.erase(iter);
					dirty = true;
					return;
				}
				// check to see if the choice list needs to be reset
				bool resetChoiceList = false;
				std::vector<std::string>& validValues = sattr->getValidValues();
				if (validValues.size() != choice->children())
				{
					resetChoiceList = true;
				}
				else
				{
					for (int c = 0; c < choice->children(); c++)
					{
						if (validValues[c] != choice->child(c)->label())
						{
							resetChoiceList = true;
							break;
						}
					}
				}
				if (resetChoiceList)
				{
					dirty = true;
					choice->clear();
					choice->add("-----");
					std::vector<std::string>& values = sattr->getValidValues();
					int selected = -1;
					for (int i = 0; i < values.size(); i++)
					{
						choice->add(values[i].c_str());
						if (sattr->getValue() == values[i])
							choice->value(i + 1);
					}
					if (sattr->getValue() == "")
						choice->value(0);
				}
				if (sattr->getValue() == "")
				{
					choice->value(0);
				}
				else
				{
					for (int c = 1; c < choice->children(); c++)
					{
						if (sattr->getValue() == choice->child(c)->label())
						{
							choice->value(c);
							break;
						}
					}
				}
				setAttributeInfo(choice, attrInfo);
			}
			return;
		}
		Vec3Attribute* vec3attr = dynamic_cast<Vec3Attribute*>(attr);
		if (vec3attr)
		{
			fltk::Group* group = (fltk::Group*) iter->second;
			double* val = vec3attr->getValue();
			fltk::FloatInput* finput[3];
			for (int x = 0; x < 3; x++)
			{
				finput[x] = (fltk::FloatInput*) group->child(x);
				char buff[64];
				sprintf(buff, "%f", val[x]);
				#ifdef __APPLE__
					finput[x]->value(val[x]);
				#else
					finput[x]->value(val[x]);
				#endif
			}
			setAttributeInfo(group, attrInfo);
			return;
		}
		
	}
	else
	{
		// non-attribute ?
		danceInterp::OutputMessage("AttributeWindow for object %s got a notify() with a non-attribute.", this->object->getName());
	}
}

