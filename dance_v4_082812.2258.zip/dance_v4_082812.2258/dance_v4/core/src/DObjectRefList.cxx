/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "defs.h"
#include "danceInterp.h"
#include "DObjectRefList.h"
#include <cstdlib>

#define	BINSIZE	10

DObjectRefList::DObjectRefList()
{
	numDObjects	= 0;
	numDanceBins = BINSIZE;

	// Initialize plugin list.
	DObjects = (DObject **)malloc(sizeof(DObject *)*numDanceBins);
}

DObjectRefList::~DObjectRefList()
{
	free(DObjects);
}

// add:
//	Adds an	object to the list and set it as the active one.
int DObjectRefList::add(DObject *obj)
{
	if (obj) {
		if (numDObjects == numDanceBins) {
		  numDanceBins += BINSIZE;
		  DObject **temp =
		  (DObject **)malloc(sizeof(DObject *)*numDanceBins);
		  memcpy(temp,DObjects,
			numDObjects	* sizeof(DObject *));
		  free(DObjects);
		  DObjects = temp;
		}
		DObjects[numDObjects] = obj;
		numDObjects++;
	}
	else {
		danceInterp::OutputMessage("ERROR: add, passed in NULL pointer.");
		return(0);
	}
	return(1);

}

int DObjectRefList::remove(int	index)
{
	// Find	object at this index.
	DObject *obj = get(index);

	if (obj) {
	   // Now shift	over all items down one.
	   for (int i =	index+1; i < numDObjects; i++)
		DObjects[i-1] = DObjects[i];
	   DObjects[numDObjects-1] = NULL;
	   numDObjects--;
	   return(1);
	}
	return(0);
}

int DObjectRefList::remove(char *name)
{
	// Find	object at this index.
	int index = getIndex(name);
	return(remove(index));
}

int DObjectRefList::remove(DObject* object)
{
	for (int i = 0; i < this->size(); i++)
	{
		if (this->DObjects[i] == object)
		{
			return remove(i);
		}
	}
	return -1;
}

DObject *DObjectRefList::get(int index)
{
	if (index < 0 || index >= numDObjects)
		return NULL;
	return (DObjects[index]);
}


// get:	Returns	plugin by name
//
DObject *DObjectRefList::get(char *name)
{
	DObject *obj = NULL;
	for (int i=0; i	< numDObjects; i++)	{
		if (strcmp(DObjects[i]->getName(),name) == 0) {
			obj = DObjects[i];
			break;
		}
	}

	return(obj);
}

// getIndex: returns index, given name.
//
int DObjectRefList::getIndex(char *name)
{
	for (int i=0; i	< numDObjects; i++)	{
		if (strcmp(DObjects[i]->getName(),name) == 0)
			return(i);
	}
	return(-1);
}

int DObjectRefList::size()
{
	return numDObjects;
}

