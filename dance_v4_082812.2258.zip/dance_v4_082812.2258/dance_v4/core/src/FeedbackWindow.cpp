/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "FeedbackWindow.h"
#include <fltk/ask.h>
#include "Preference.h"
#include "dance.h"
#include <sstream>

using namespace fltk;

FeedbackWindow::FeedbackWindow(int w, int h, char* name) : Window(w, h, name)
{
	this->begin();

	buttonFAQ = new Button(this->w() - 110, 10, 100, 20, "Go To DANCE FAQ");
	buttonFAQ->callback(faq_cb, this);
	
	inputEmail = new Input(10, 30, this->w() - 150, 20, "Your email:");
	inputEmail->align(fltk::ALIGN_TOP);

	inputFeedback = new MultiLineInput(10, 70, this->w() - 70, this->h() - 110, "Question or Feedback");
	inputFeedback->callback(dofeedback_cb, this);
	inputFeedback->align(fltk::ALIGN_TOP);

	buttonSend = new Button(10, this->h() - 30, 60, 20, "Send");
	buttonSend->callback(dofeedback_cb, this);

	buttonOk = new Button(this->w() - 80, this->h() - 30, 60, 20, "Cancel");
	buttonOk->callback(cancel_cb, this);

	this->end();
}

FeedbackWindow::~FeedbackWindow()
{
}

void FeedbackWindow::show()
{
	inputFeedback->empty();
	Window::show();
}

void FeedbackWindow::dofeedback_cb(fltk::Widget* widget, void* data)
{
	FeedbackWindow* fwin = (FeedbackWindow*) data;
	
	const char* dancedir = dance::getDanceDir();
	std::stringstream faqscript;
	faqscript << dancedir << "/feedback.py";
	int ret = danceInterp::load((char*) faqscript.str().c_str());
	if (ret == DANCE_ERROR) 
	{
		danceInterp::OutputMessage("Problem running feedback script %s", faqscript.str().c_str());
		return;
	}

	std::string email = fwin->inputEmail->value();
	std::string feedback = fwin->inputFeedback->value();

	std::stringstream feedbackcommand;
	feedbackcommand << "sendFeedback(\"" << email << "\", \"" << feedback << "\")";
	int ret2 = danceInterp::ExecuteCommandNoRecord((char*) feedbackcommand.str().c_str());

	if (ret2 == DANCE_OK)
		fltk::alert("Feedback message sent!");
	else
		fltk::alert("Problem sending feedback.");

	Preference::setWindowPreference("dance.feedbackwindow", fwin);
	Preference::replacePreference("dance.feedbackwindow.email", (char*) fwin->inputEmail->value());
	dance::writePreferences();
}

void FeedbackWindow::cancel_cb(fltk::Widget* widget, void* data)
{
	FeedbackWindow* fwin = (FeedbackWindow*) widget;

	Preference::setWindowPreference("dance.feedbackwindow", fwin);
	Preference::replacePreference("dance.feedbackwindow.email", (char*) fwin->inputEmail->value());
	dance::writePreferences();

	fwin->hide();
}

void FeedbackWindow::faq_cb(fltk::Widget* widget, void* data)
{
	const char* dancedir = dance::getDanceDir();
	std::stringstream faqscript;
	faqscript << dancedir << "/feedback.py";
	int ret = danceInterp::load((char*) faqscript.str().c_str());
	if (ret == DANCE_ERROR) 
	{
		danceInterp::OutputMessage("Problem running feedback script %s", faqscript.str().c_str());
		return;
	}
	danceInterp::ExecuteCommand("goToFAQ()");
}






