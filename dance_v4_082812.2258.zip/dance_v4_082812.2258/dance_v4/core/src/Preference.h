/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _PREFERENCES_
#define _PREFERENCES_


#include <fstream>
#include <vector>
#include <fltk/Widget.h>
 
#ifndef	DLLENTRY
#ifdef WIN32
#define	DLLENTRY __declspec(dllexport)
#else
#define	DLLENTRY
#endif
#endif

class DLLENTRY Preference
{
	public:
		Preference();
		Preference(const char* n, const char* v);
		void setName(const char* n);
		const char* getName();
		void setValue(const char* val);
		const char* getValue();

		static void loadPreferences(std::ifstream& file);
		static void writePreferences(std::ofstream& file);
		static void removeAllPreferences();

		static Preference* getPreference(const char* name);
		static const char* getPreferenceValue(const char* name);
		static void addPreference(Preference* pref);
		static void removePreference(const char* name);
		static void removePreference(Preference* pref);
		static void replacePreference(const char* name, const char* value);
		static void getWindowPreference(const char* name, fltk::Widget* widget);
		static void setWindowPreference(const char* name, fltk::Widget* widget);

		static void updateRecentPreferences(const char* prefix, int number, const char* recent);

	protected:
		std::string name;
		std::string value;
		
		static std::vector<Preference*> allpreferences;
};



#endif
