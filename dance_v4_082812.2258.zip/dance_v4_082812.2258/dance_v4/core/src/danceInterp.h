/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_DANCE_INTERP_H_
#define	_DANCE_INTERP_H_ 1


#include <stdarg.h>
//#include "CommandWindow.h"
#include "defs.h"

class DObjectList ;
class CommandWindow;

class DLLENTRY danceInterp {

	public:
		// Utility routines
		//static void checkEvents();

		// they have to be provided by the specific interpreter (i.e Tcl or python)
		static void OutputMessage(const char *format, ...) ;
		static void OutputResult(const char *format, ...) ;
		static void OutputListElement(const char *format, ...)  ;
		static int Init(int argc,	char **argv) ;
		static void getCurrentDirectory(char *dir) ;
		static int getDirectoryListing(char *dl, int maxSize, char *directory) ;
		static void getHistoryEvent(int n, char *cmd) ;
		static const char *getProfileFile() ;
		static int ExecuteCommand(const char *command) ;
		static int ExecuteCommandNoRecord(const char *command) ;
		static void flush() ;
		static int load(const char *filename) ;
		
		// Generic commands
		static int active(int argc, char **argv);
		static int all(int argc, char **argv);
		static int Command(const char *type, int argc,	char **argv);

		static int renderer(int argc, char **argv) { return Command("renderer",argc, argv) ;	}
		static int view(int argc, char **argv) {return Command("view",argc, argv) ;}
		static int light(int argc, char **argv)	{return Command("light",argc, argv) ;}
		static int system(int argc, char **argv) {return Command("system",argc, argv) ;}
		static int generic(int argc, char **argv){return Command("generic",argc, argv) ;}
		static int actuator(int argc, char **argv)	{return Command("actuator",argc, argv) ;}
		static int modifier(int argc, char **argv){ return Command("modifier",argc, argv) ;	}
		static int geometry(int argc, char **argv)	{return Command("geometry",argc, argv) ;}
		static int simulator(int argc, char **argv)	{return Command("simulator",argc, argv) ; }
		static int instance(int argc, char **argv);
		static int show(int argc, char **argv);
		static int exists(int argc, char **argv);
		static int Plugin(int argc, char **argv);
		static int proximity(int argc, char **argv);
		static int quit(int argc, char **argv);
		static int remove(int argc, char **argv);
		static int save(int argc, char **argv);
		static int simul(int argc, char **argv);
		static int viewmanager(int argc, char **argv) ;
		static int materialmanager(int argc, char **argv) ;
		static int reset(int argc, char **argv) ;
		static int rename(int argc, char **argv) ;
		static int chdir(int argc, char **argv) ;
		static int version(int argc, char **argv) ;

		static int showinterface(int argc, char **argv);
		static int hideinterface(int argc, char **argv);
		static int addinteraction(int argc, char **argv);
		static int removeinteraction(int argc, char **argv);
		static int checkUI(int argc, char **argv);

		static int dependency(int argc, char **argv);
		static int setNoOutput(int argc, char **argv);

	private:
		static DObjectList *getList(const char *type);
		static void appendMessage(const char *message);


};
#endif



