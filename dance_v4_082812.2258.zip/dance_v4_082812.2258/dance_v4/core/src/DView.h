/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_VIEW_H_
#define	_VIEW_H_ 1

#include "opengl.h"
#include <fltk/Window.h>
#include "DObject.h"

#include <fltk/gl.h>
#include "Timer.h"
#include "PlugIn.h"

#define ACSIZE  8

class DanceWindow;
class ViewWindow;

struct Jitter_Point
{
	double x;
	double y;
};

#define	SCALE_FOR_BB 1.0

enum EditModes {
	camera_arcball,
	camera_pan,
	camera_zoom
};

enum BufferModes {
	normal_mode=1,
	depth_mode=2
};

#define VIEWSTATESIZE 11
enum ViewStateType {
	eTargetx,
	eTargety,
	eTargetz,
	eLeft,
	eRight,
	eTop,
	eBottom,
	eAngle,
	eAxisx,
	eAxisy,
	eAxisz
};
#include "Ball.h"


class DLLENTRY DView : public PlugIn
{
	public:

		const static int MODE_NONE = 0;
		const static int MODE_ARCBALL = 1;
		const static int MODE_PAN = 2;
		const static int MODE_DOLLY = 3;
		const static int MODE_ZOOM = 4;

		const static int VIEW_TOP = 0;
		const static int VIEW_FRONT = 1;
		const static int VIEW_RIGHT = 2;
		const static int VIEW_PERSP = 3;
		
		DView();
		DView(char *name, int x, int y, int width, int height);
		~DView();

		int commandPlugIn(int argc, char **argv);

		void draw(int mode=0, int side = 0) ;
		void drawObjects(int mode=0) ;
		virtual void setTarget(Vector t);
		virtual double* getTarget();
		virtual void setCamera(Vector t);
		virtual double* getCamera();
		INLINE double getCameraDistance();
		void getCameraParms(double *dist, double *panx, double *pany, double target[3]);
		void getCameraOrientation(float	mat[4][4]);
		void getCameraTransformation(float mat[4][4]);
		void setCameraOrientation(float	mat[4][4]);
		void setCameraTransformation(float mat[4][4]);

		virtual void moveCamera(double dist, double panx, double pany, double target[3], HVect arccoords);
		virtual void panCamera(double panx, double pany);
		virtual void dollyCamera(double	percentage);
		virtual void dollyCameraDist(double dist);
		virtual void zoomCamera(double percentage);

		void setDistance(double dist);
		double getDistance();

		INLINE int getX();
		INLINE void setX(int val);
		INLINE int getY();
		INLINE void setY(int val);
		INLINE int getWidth();
		INLINE void setWidth(int val);
		INLINE int getHeight();
		INLINE void setHeight(int val);
		void setSize(int width, int height);
		void getSize(int &width, int &height);
		double getFrustumWidth(double depth);
		double getFrustumHeight(double depth);

		INLINE void setProjectionType(int type);
		INLINE int getProjectionType();

		INLINE bool showGrid() { return m_showGrid; }
		void setGrid(bool val) { m_showGrid = val; }
		void setGridSize(float size);
		float getGridSize();
		void setGridStep(float step);
		float getGridStep();
		void setGridColor(float r, float g, float b);
		void getGridColor(float& r, float& g, float& b);
		void setGridHighlightColor(float r, float g, float b);
		void getGridHighlightColor(float& r, float& g, float& b);
		void drawGrid();

		INLINE virtual int isLights();
		INLINE virtual int isShadows();
		INLINE virtual int isSolids();

		void setShadows(bool val);
		void setSolids(bool val);
		void setLights(bool val);

		void setBackgroundColor(float r, float g, float	b, float a);
		void getBackgroundColor(float color[4]);

		double getDepth(int x, int y);

		void getNearFar(double *nearplane, double *farplane);

		double *Projection;

		double Left,Right,Bottom,Top,Near,Far;

		int jitter_times;
		Jitter_Point m_jp[ACSIZE+1][ACSIZE+1];



        void ReshapeCB(int x, int y, int width, int height);
	
		virtual void adjustArcballCamera(HVect coords);
		virtual void adjustArcballCircle(double	x, double y, double radius);
		virtual void AttachCamera(BoundingBox *box);

		virtual void beginInteraction(int mode);
		virtual void endInteraction(int	mode);

		virtual void drawArcball();
		
		void drawName();
		void InitList();
		INLINE void end() {/*glutSwapBuffers();*/};
		


		void getProjection(double *projection);
		void getReferenceFrame(double basisX[3], double	basisY[3], double basisZ[3]);
		void getBounds(double *left, double *right, double *top,
			double *bottom);
		void getCenter(double center[3]);
		INLINE void getPosition(int *x,	int *y)	{ *x=X;	*y=Y;};
		
		void getViewPlane(double basisX[3], double basisY[3]);
		void getViewport(int viewport[4]);
		int getWindowIndex(char	*name);
		void getWindowCoords(double *world, double *win);
		double getWorldCoords(double *world, int x, int y, double	z=-1.0);


		INLINE void setShading(int val) { Shading = val; };
		INLINE int getShading() { return Shading; };


		virtual void handleCameraMotions(int eventType, int x, int y,	int width, int height, int diffx, int diffy);
		virtual void handleCameraButtons(int eventType, int button, int state, int	x, int y, int width, int height);
		void handleKeyboard(int eventType, unsigned char key, int x, int y);

		virtual void pickProjection(int	x, int y, double delX, double delY);
		virtual void PositionCamera();
		INLINE void postRedisplay();
		virtual void resetCamera();
		virtual void resetLights();
		INLINE void set();
		void setArcballConstraints(AxisSet axisset);
		
		void setCamera(double scale,
			       double minx, double miny, double	minz,
			       double maxx, double maxy, double	maxz, 
			       double scaleNear = 2.0, double scaleFar = 3.0);

		void printText(double *pos, const char *msg);

		virtual void setProjection();
		void setProjection(
			double left, double right,
			double bottom, double top,
			double nearV, double farV);
		void start();
		

        int GetStateSize() { return VIEWSTATESIZE ;} ;
        void UpdateState(double *state) ;
        void GetState(double *state) ;

        void SaveFrame() ;
		char* getDumpDirectory();
		void setDumpDirectory(char* dir);
		INLINE bool isListInitted() { return m_listInitted; }
		void setListInitted(bool val) { m_listInitted = val; }
		INLINE bool showName() { return m_showName; }
		void setShowName(bool val) { m_showName = val; }
		BoundingBox* calcBoundingBox(BoundingBox *);
		void setMode(int mode);
		int getMode();
		INLINE void setChanged(bool val);
		INLINE bool isChanged();
		INLINE void setNeedsReset(bool val);
		INLINE bool getNeedsReset();

		void setFrameNumber(int fnum);
		int getFrameNumber();

		bool isDumped();
		void setDumped(bool val);

		void setShowStats(bool val);
		bool isShowStats();
		void showStats();

		void setFOV(double fov);
		double getFOV();
		void setStartFrameNumber(int n);
		int getStartFrameNumber();

		fltk::Widget* getInterface();

		static void accFrustum(GLdouble left, GLdouble right, GLdouble bottom,
								GLdouble top, GLdouble m_near, GLdouble m_far, GLdouble pixdx, 
								GLdouble pixdy, GLdouble eyedx, GLdouble eyedy, 
								GLdouble focus);

		static void accPerspective(GLdouble fovy, GLdouble aspect, 
								GLdouble m_near, GLdouble m_far, GLdouble pixdx, GLdouble pixdy, 
								GLdouble eyedx, GLdouble eyedy, GLdouble focus);

		

		void save(int mode, std::ofstream& file);

		GLuint GridList;

		void startFPS();
		void checkFPS();
		int m_frameCount;

		void setNear(double near);
		void setFar(double far);
		double getNear();
		double getFar();

		void setUseAnaglyph(bool val);
		bool getUseAnaglyph();

		virtual void saveCurrentState(int mouseX, int mouseY) {};
		
	protected:
	
		float BackgroundColor[4];
		int X;
		int Y;
		int Width;
		int Height;
		int m_projectionType;
		bool m_listInitted;
		bool m_showGrid;
		bool m_showName;
		int base;
		bool m_changed;
		bool m_cameraMoved;
		bool m_needsReset;

		int Lights;
		int Shadows;
		int Solids;
		int Shading;


		// Camera data
		double Dist;
		double Panx, Pany;
		double Target[3];
		double Camera[3];
		
		double *Modelview;
		double *m_lightProjectionMatrix ;
		double *m_lightViewMatrix ;


		// Handles zooming with	clipping
		double Virtual_near;
		double Limit_near;

		void usage();
        char m_DumpDirectory[MAX_LINE] ;
        char m_HalfSizeCom[MAX_LINE] ;
        int m_FrameNumber ;
        bool m_isDumped ;
        char m_DumpFileName[MAX_LINE] ;
        void SetStartFrameNumber(int n) {m_FrameNumber = n;} ;
		void InitShadowMap(void) ;
  
		void init_antialiasing();
		GLdouble prevDepth;
		int m_mode;

		double fov;
		ViewWindow* m_viewWindow;
		float gridSize;
		float gridStep;
		float gridColor[3];
		float gridHighlightColor[3];
		bool m_showStats;
		ArcBall* ball;

		int m_shadowMapSize ;
		GLuint m_shadowMapTexture;
		Timer m_timer;
		float m_fps;

		double m_near;
		double m_far;

		DoubleAttribute* m_dollyRate;
		DoubleAttribute* m_panRate;
		DoubleAttribute* m_zoomRate;

		bool m_useAnaglyph;
};
#endif
