/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef CHARJOINT_H
#define CHARJOINT_H

#include "defs.h"
#include "vector.h"
#include <vector>
#include <string>
#include "PlugIn.h"

#include "Quaternion.h"
class Character;
class CharJointWindow;

class DLLEXPORT CharJoint : public PlugIn
{
	public:
		CharJoint(const char* name);
		~CharJoint();

		void output(int mode);
			
		void setOffset(double x, double y, double z);
		void getOffset(Vector &offset);
		void addChild(CharJoint* child);
		void removeChild(CharJoint* child);
		void setEndEffector(bool val);
		bool isEndEffector();
		void setEndEffectorOffset(double x, double y, double z);
		void getEndEffectorOffset(Vector &offset);
		//std::vector<CharJoint*> getChildren();
		int getNumChildren();
		CharJoint* getChild(int childNum);
		void setParent(CharJoint* parent);
		CharJoint* getParent();
		void setCharacter(Character* ch);
		Character* getCharacter();
		void getOffsetFromRoot(Vector &offset);
		void setChannels(int numOfChannels, int* channels);
		int getChannels(int* channels);
		int getNumChannels();

		void addFrame(double* vals);
		void addFrame(Quaternion* quat);
		void addFrame(double x, double y, double z);
		void setFrame(int frameNum, double val, int channel);
		void setFrame(int frameNum, double* vals);
		void setFrame(int frameNum, Quaternion* quat);

		void setPoint(int frameNum, double x, double y, double z);
		void setEndEffectorPoint(int frameNum, double x, double y, double z);

		void clearFrames();
		int getNumFrames();
		void setNumFrames(int num);
		void getFrames(int frameNum, double* frames);
		void getFramesByTime(double time, double* frames);
		double* getFrames(int frameNum);
		void getPoint(int frameNum, double& x, double& y, double& z);
		void getPoint(double time, Vector pos);
		void getEndEffectorPoint(double time, Vector pos);
		void getEndEffectorPoint(int frameNum, double& x, double& y, double& z);
		Quaternion* getQuaternion(int frameNum);
		Quaternion* getQuaternion(double time);
		double getFrameTime();
		void setFrameTime(double time);

		Quaternion* getGlobalQuaternion(int frameNum);
		void setOffsetAdjustment(int frameNum, double ratio);
		double getOffsetAdjustment(int frameNum);

		void calcTransMatrix(double time, bool useInterpolation = true);
		void getTransMatrix(double matrix[4][4]);
		void getWorldTransMatrix(double time, double matrix[4][4]);
		void getWorldTransMatrix(double matrix[4][4]);
		void setWorldTransMatrix(double matrix[4][4]);
		void addOffset(Vector offset);

		void setEndSiteName(char* name);
		char* getEndSiteName();
		void getWorldCoord(double time, Vector &pos);
		void getLocalCoordToJoint(double time, Vector &pos, CharJoint* joint);

		void setAxis(double* axis);
		void getAxis(double* axis);
		void getAxisMatrix(double axisMatrix[4][4]);
		void getAxisMatrixInverse(double axisMatrixInv[4][4]);
		bool useAxis();

		void setLimits(int channelNum, double low, double high);
		void getLimits(int channelNum, double& low, double& high);
		
		void setLength(double length);
		double getLength();
		void setDirection(double x, double y, double z);
		void getDirection(Vector direction);

		bool isIgnoreChannels();
		void setIgnoreChannels(bool val);

		CharJoint* copy(Character* c, CharJoint* parent, int startFrame, int endFrame);

		void setInterpolatedJoint(CharJoint* j);
		CharJoint* getInterpolatedJoint();

		static const int XPOSITION = 1;
		static const int YPOSITION = 2;
		static const int ZPOSITION = 3;

		static const int XROTATION = 4;
		static const int YROTATION = 5;
		static const int ZROTATION = 6;

		static int determineRotationOrder(int* channels, int numChannels, CharJoint* joint);

		double getLastTime();

		void getLimitsFromData(int channelNum, double& low, double& high);

		int numTranslationChannels();
		int getFirstTranslationChannel();
		int getLastTranslationChannel();

		void setCharacterIndex(int index);
		int getCharacterIndex();

		void calculatePath(int startFrame, int endFrame);
		std::vector<VectorObj>& getPath();

		std::vector<std::string>& getParameters();
		std::string getParameter(std::string match);
		
		std::vector<double*>& getRawFrameData();
		virtual fltk::Widget* getInterface();

		void onConnect(DConnection* connection);
		void onDisconnect(DConnection* connection);		
		void notify(DSubject* subject);
		virtual BoundingBox *calcBoundingBox(BoundingBox *box = NULL);
		
		double convertToLocalTime(double time);

	private:
		void calcTransMatrixBVH(double time, bool useInterpolation);
		void calcTransMatrixASFAMC(double time, bool useInterpolation);
		void getWorldCoordRecurse(double time, double matrix[4][4], CharJoint* node);
		void getLocalCoordToJointRecurse(double time, Vector &curPos, CharJoint* node, CharJoint* topNode);
		void calcGlobalQuaternionRecurse(int frameNum, const double parentMatrix[4][4], CharJoint* node);
		void convertToFrame(Quaternion* mg, double frames[6]);
		Quaternion* convertToQuaternion(double frames[6]);

		DoubleAttribute* m_offset[3];
		DoubleAttribute* m_endEffectorOffset[3];
		BoolAttribute* m_showTrajectories;
		BoolAttribute* m_showGesturePhases;
		BoolAttribute* m_showJoint;

		std::string m_endSiteName;
		std::vector<CharJoint*> m_children;
		bool m_isEndEffector;
		CharJoint* m_parent;
		int m_channels[6];
		int m_numChannels;
		bool m_ignoreChannels;
		double m_transMatrix[4][4];
		double m_worldTransMatrix[4][4];
		Character* m_character;
		double m_axis[3];
		double m_limitsLow[6];
		double m_limitsHigh[6];

		std::vector<double*> m_frames;
		std::vector<Quaternion*> m_quaternions;
		std::vector<double> m_points;
		std::vector<double> m_endEffectorPoints;

		Quaternion m_globalQuaternion;
		std::vector<double> m_offsetAdjustments;

		double m_frameTime;
		static Quaternion m_defaultQuaternion;
		bool m_useAxis;
		double m_axisRotMatrix[4][4];
		double m_axisRotMatrixInv[4][4];
		double m_length;
		Vector m_direction;
		CharJoint* m_interpolatedJoint;

		int uniqueID;
		static int curUniqueID;

		double m_lastTime;

		int m_firstTranslationChannel;
		int m_lastTranslationChannel;
		int m_characterIndex;

		std::vector<std::string> m_parameters;
		
		CharJointWindow* m_gui;
		bool m_worldMatrixDirty;
		std::vector<VectorObj> m_path;
};

#endif
