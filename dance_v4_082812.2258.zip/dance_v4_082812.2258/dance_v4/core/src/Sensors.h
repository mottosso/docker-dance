#ifndef _SENSORS_H_
#define _SENSORS_H_

#include "defs.h"
#include "vector.h"

class DLLENTRY Sensors
{
	public:
		Sensors();
		virtual double* GetCenterMass(Vector v);
		virtual double* GetCMvel(Vector v);
		virtual double* GetCMacc(Vector v);
		virtual double* GetGeomCenterSp(Vector v);
		virtual void ComputeSensors();
};

#endif

