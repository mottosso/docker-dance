/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "InstanceWindow.h"
#include <cstdio>
#include <cstdlib>
#include <fltk/filename.h>
#include <fltk/ask.h>
#include "danceInterp.h"
#include "dance.h"
#include "dancePython.h"
#include "Preference.h"
#ifdef WIN32
#include <windows.h>
#endif

using namespace fltk;

InstanceWindow::InstanceWindow(int x, int y, int w, int h, const char* name) : Window(x, y, w, h, name)
{
	this->begin();

	browserPlugins = new Browser(10, 30, this->w() - 30,  this->h() - 110, "Plugins");
	browserPlugins->callback(SelectPlugInCB, this);
	browserPlugins->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	
	inputName = new Input(40, this->h() - 80, this->w() - 70, 20, "Name");
	inputName->callback(CreateCB, this);
	inputName->when(fltk::WHEN_ENTER_KEY_ALWAYS);
	inputOptions = new Input(40, this->h() - 50, this->w() - 70, 20, "Options");
	buttonLoad = new Button(10, this->h() - 30, 80, 20, "Load Plugin");
	buttonLoad->callback(LoadCB, this);
	buttonCreate = new Button(this->w() - 160, this->h() - 30, 90, 20, "Create Instance");
	buttonCreate->callback(CreateCB, this);
	buttonCancel = new Button(this->w() - 60, this->h() - 30, 50, 20, "Cancel");
	buttonCancel->callback(CancelCB, this);

	this->resizable(browserPlugins);

	this->end();
}

void InstanceWindow::updateGUI()
{
	// get the file list from the DANCE_DIR/plugins/ folder
	browserPlugins->clear();

	// get any recently created plugins
	int count = 0;
	std::string base = "dance.create.";
	for (int x = 0; x < 5; x++)
	{
		char buff[512];
		sprintf(buff, "%s%d", base.c_str(), x);
		Preference* pref = Preference::getPreference(buff);
		if (pref != NULL)
		{
			browserPlugins->add(pref->getValue());
			count++;
		}
	}

	if (count > 0)
	{ // create a separator
		browserPlugins->add("----------------------------");
	}


	char buff[512];
	#ifdef WIN32
	sprintf(buff, "%s/plugins/win", dance::getDanceDir());
	#elif _MACOSX_
	sprintf(buff, "%s/plugins/osx", dance::getDanceDir());
	#else 
	sprintf(buff, "%s/plugins/linux", dance::getDanceDir());
	#endif
	dir(buff, false, browserPlugins);

	browserPlugins->callback(SelectPlugInCB, this);


	// place 
}

void InstanceWindow::show()
{
	this->updateGUI();
	SelectPlugInCB(NULL, this);
	Window::show();
}

void InstanceWindow::LoadCB(fltk::Widget* widget, void* data)
{
	InstanceWindow* win = (InstanceWindow*) data;
	
	Widget* w = win->browserPlugins->child(win->browserPlugins->value());

	if (w == NULL)
	{
		alert("Please select a plugin type.");
		return;
	}

	char buff[1024];
	sprintf(buff, "dance.plugin(\"%s\")", w->label());
	danceInterp::OutputMessage(buff);
	int ret = danceInterp::ExecuteCommand(buff);
	if (ret == DANCE_OK)
	{
		fltk::alert("The plugin %s was loaded.", w->label());
	}
}

void InstanceWindow::CreateCB(fltk::Widget* widget, void* data)
{
	InstanceWindow* win = (InstanceWindow*) data;
	
	if (win->inputName->value() == NULL || strlen(win->inputName->value()) == 0)
	{
		alert("Please enter a name for the object.");
		return;
	}

	Widget* w = win->browserPlugins->child(win->browserPlugins->value());

	if (w == NULL)
	{
		alert("Please select a plugin type.");
		return;
	}

	char buff[1024];
	if (strlen(win->inputOptions->value()) > 0)
		sprintf(buff, "dance.instance(\"%s\", \"%s\", \"%s\")", w->label(), win->inputName->value(), win->inputOptions->value());
	else
		sprintf(buff, "dance.instance(\"%s\", \"%s\")", w->label(), win->inputName->value());

	danceInterp::OutputMessage(buff);
	int ret = danceInterp::ExecuteCommand(buff);

	if (ret == DANCE_OK)
	{
		sprintf(buff, "dance.showinterface(\"%s\")", win->inputName->value());
		ret = danceInterp::ExecuteCommand(buff);		
		Preference::setWindowPreference("dance.instancewindow", win);
		Preference::updateRecentPreferences("dance.create.", MAXCREATEINSTANCES, (char*) w->label());
		dance::writePreferences();
		win->hide();
	}
	else
	{
		fltk::alert("An instance of %s was not be created. Please check the command window.", w->label());
	}
}

void InstanceWindow::CancelCB(fltk::Widget* widget, void* data)
{
	InstanceWindow* win = (InstanceWindow*) data;

	Preference::setWindowPreference("dance.instancewindow", win);
	dance::writePreferences();
	win->hide();
}

void InstanceWindow::SelectPlugInCB(fltk::Widget* widget, void* data)
{
	InstanceWindow* win = (InstanceWindow*) data;
	if (win == NULL)
		return;

	Widget* w = win->browserPlugins->child(win->browserPlugins->value());
	std::string tempname = w->label();
	if (tempname.find("----------------------------", 0) != std::string::npos) // ignore the separator
	{
		win->browserPlugins->select(win->browserPlugins->value(), false);
		win->inputName->value("");
		return;
	}
	for (int x = 0; x < 1000; x++)
	{
		std::string tempname2 = tempname;
		char buff[10];
		sprintf(buff, "%d", x);
		tempname2.append(buff);
		DObject* obj = dance::getObject((char*) tempname2.c_str());
		if (obj == NULL)
		{
			win->inputName->value(tempname2.c_str());
			break;
		}
	}

}

int InstanceWindow::dir(const char *szDir, bool bCountHidden, Browser* browser)
{
#ifdef WIN32
	#ifdef _DEBUG
	char* extension = "*_d.dll";
	int size = 6;
	#else
	char* extension = "*.dll";
	int size = 4;
	#endif
#else
	const char* extension = "*.so";
	int size = 3;
#endif
	browser->add("light");
	browser->add("view");
	char temp[8192];
	danceInterp::getDirectoryListing(temp, 8192, (char*) szDir);
	char* token;
	token = strtok(temp, " ");
	char buff[1024];
	while (token != NULL)
	{
		if (filename_match(token, extension))
		{			
//			danceInterp::OutputMessage("Loading plugin: %s", token);
			strncpy(buff, token, strlen(token) - size);
			buff[strlen(token) - size] = '\0';
			#ifndef _DEBUG
			// eliminate any _d.dll extensions
			if (!filename_match(token, "*_d.dll"))
				browser->add(buff);
			#else
			browser->add(buff);
			#endif
			
		}
		token = strtok(NULL, " ");
	}
	return -1;
}
