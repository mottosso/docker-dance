/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "DCollision.h"
#include "danceInterp.h"
#include "DSystem.h"

DCollision::DCollision(int num)
{
	setID(num);
	points = NULL;
	numPoints = 0;
	system = NULL;
}

DCollision::~DCollision()
{
	if (points != NULL)
		delete[] points;
	if (prevPoints != NULL)
		delete[] prevPoints;
	if (curPoints != NULL)
		delete[] curPoints;
	if (prevTimes != NULL)
		delete[] prevTimes;
	if (inCollision != NULL)
		delete[] inCollision;
}

void DCollision::setID(int num)
{
	id = num;
}

int DCollision::getID()
{
	return id;
}

int DCollision::getNumPoints()
{
	return numPoints;
}

void DCollision::setNumPoints(int num)
{
	numPoints = num;
	if (points != NULL)
		delete [] points;
	points = new Vector[numPoints];
	curPoints = new Vector[numPoints];
	prevPoints = new Vector[numPoints];
	inCollision = new bool[numPoints];
	prevTimes = new double[numPoints];
	resetAll();
}

double* DCollision::getPoint(int num)
{
	if (num < numPoints)
	{
		return points[num];
	}
	else
	{
		danceInterp::OutputMessage("Point desired exceeds number of points: %d > %d", num, numPoints);
		return NULL;
	}
}

void DCollision::setPoint(int num, Vector point)
{
	if (num < numPoints)
	{
		VecCopy(points[num], point);
	}
	else
	{
		danceInterp::OutputMessage("Point desired exceeds number of points: %d > %d", num, numPoints);
	}
}

void DCollision::getPointPrevPosition(int num, double* point)
{
	if (num < numPoints)
	{
		VecCopy(point, prevPoints[num]);
	}
	else
	{
		danceInterp::OutputMessage("Point desired exceeds number of points: %d > %d", num, numPoints);
	}
}

void DCollision::setPointPrevPosition(int num, double* point)
{
	if (num < numPoints)
	{
		VecCopy(prevPoints[num], point);

	}
	else
	{
		danceInterp::OutputMessage("Point desired exceeds number of points: %d > %d", num, numPoints);
	}
}

double* DCollision::getPointCurPosition(int num)
{
	if (num < numPoints)
	{
		return curPoints[num];
	}
	else
	{
		danceInterp::OutputMessage("Point desired exceeds number of points: %d > %d", num, numPoints);
		return NULL;
	}
}

void DCollision::setPointCurPosition(int num, double* point)
{
	if (num < numPoints)
	{
		VecCopy(curPoints[num], point);

	}
	else
	{
		danceInterp::OutputMessage("Point desired exceeds number of points: %d > %d", num, numPoints);
	}
}



double DCollision::getPointPrevTime(int num)
{
	if (num < numPoints)
	{
		return prevTimes[num];
	}
	else
	{
		danceInterp::OutputMessage("Point desired exceeds number of points: %d > %d", num, numPoints);
		return 0;
	}
}

void DCollision::setPointPrevTime(int num, double time)
{
	if (num < numPoints)
	{
		prevTimes[num] = time;
	}
	else
	{
		danceInterp::OutputMessage("Point desired exceeds number of points: %d > %d", num, numPoints);
	}
}

bool DCollision::isPointInCollision(int num)
{
	if (num < numPoints)
	{
		return inCollision[num];
	}
	else
	{
		danceInterp::OutputMessage("Point desired exceeds number of points: %d > %d", num, numPoints);
		return 0;
	}
}


void DCollision::setAllPointsCollision(bool val)
{
	for (int x = 0; x < numPoints; x++)
	{
		inCollision[x] = val;
	}
}

void DCollision::setPointInCollision(int num, bool val)
{
	if (num < numPoints)
	{
		inCollision[num] = val;
	}
	else
	{
		danceInterp::OutputMessage("Point desired exceeds number of points: %d > %d", num, numPoints);
	}
}

void DCollision::reset(int num)
{
	if (num < numPoints)
	{
		inCollision[num] = false;
	}
	else
	{
		danceInterp::OutputMessage("Point desired exceeds number of points: %d > %d", num, numPoints);
	}
}

void DCollision::resetAll()
{
	for (int x = 0; x < numPoints; x++)
		reset(x);
}

void DCollision::setSystem(DSystem* sys)
{
	system = sys;
}

DSystem* DCollision::getSystem()
{
	return system;
}



DSphereCollision::DSphereCollision(int num) : DCollision(num)
{
	radii = NULL;
}

DSphereCollision::~DSphereCollision()
{
	if (radii != NULL)
		delete[] radii;
}

void DSphereCollision::setNumPoints(int num)
{
	DCollision::setNumPoints(num);

	radii = new double[num];
}

double DSphereCollision::getRadius(int num)
{
	if (num < numPoints)
	{
		return radii[num];
	}
	else
	{
		danceInterp::OutputMessage("Radius desired exceeds number of points: %d > %d", num, numPoints);
		return 0;
	}
}

void DSphereCollision::setRadius(int num, double val)
{
	if (num < numPoints)
	{
		 radii[num] = val;
	}
	else
	{
		danceInterp::OutputMessage("Radius desired exceeds number of points: %d > %d", num, numPoints);
	}
}
