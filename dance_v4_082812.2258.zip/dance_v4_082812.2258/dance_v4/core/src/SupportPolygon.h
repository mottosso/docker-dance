/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef SupportPolygon_h
#define SupportPolygon_h

static const int MAX_NUM_PTS = 20 ;

class DLLENTRY SupportPolygon {
public:
  SupportPolygon() ;		

  int index[MAX_NUM_PTS] ;	// it holds the	index of the vertices that
				// actually belong to
				// the support polygon
  Vector lVertices[MAX_NUM_PTS]	;	// vertices in local coordinates
  Vector wVertices[MAX_NUM_PTS]	;	// vertices in world coordinates
  int nl ;			// number of left foot points in lVertices
  int nr ;			// number of right foot	points in lVertices
  int contactPointCount;  // number of vertices in lVertices and wVertices

  Vector spVertices[MAX_NUM_PTS] ; // convex hull support polygon vertices in world coordinates
  int nvertex ;			// number of vertices in the convex hull of the support polygon( ie, number elems in hullVertices)

  Vector nearCMPts[MAX_NUM_PTS]; // DEBUG

  const double* getGeometricCenter( void ) const { return myGeometricCenter; }
  void output(int mode)	;
  void compute(void) ;
  double *intersectLineSeg( const Vector p1, const Vector p2, Vector intersect) ;

  double nearestPoint( Vector outNearestPointOnSP, const Vector argPoint );
  double *computeGeometricCenter(Vector) ;
private:
	Vector myGeometricCenter;
} ;

#endif
