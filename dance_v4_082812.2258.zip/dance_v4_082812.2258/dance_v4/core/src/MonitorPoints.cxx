/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "MonitorPoints.h"
#include "danceInterp.h"

/** Constructor */
MonitorPoints::MonitorPoints()
{
    m_NumPoints = 0 ; 
    m_Point = NULL ; 
    m_PrevPos = NULL ;
    m_InCollision = NULL;
    m_PrevPosTimeStamp = NULL ;
	m_object = NULL ;
}

/** Destructor */
MonitorPoints::~MonitorPoints()
{ 
    if( m_NumPoints == 0 ) return ;
    Deallocate() ;
}

/** 
  * Allocates the neccessary memory for np number of points
  *
  * Allocates the vector arrays to hold the points, their previous position,
  * their under ground status.
  *
  * @param np 
  * The number of points
  * @returns 
  * The number of allocated points
  */
int MonitorPoints::Allocate(int np) {

  if( np < 1  ) return 0 ;
  
  if( m_Point != NULL ) delete [] m_Point  ;
  m_Point = new Vector [np] ;
  if( m_Point == NULL )
    {
      danceInterp::OutputMessage("MonitorPoints::Allocate:"
			      "Cannot allocate memory!") ;
      return 0 ;
    }
  
  if (m_InCollision != NULL) delete [] m_InCollision ;
  m_InCollision = new int [np] ;
  if( m_InCollision == NULL )
    {
      danceInterp::OutputMessage("MonitorPoints::Allocate:"
			      "Cannot allocate memory!") ;
      Deallocate() ;
      return 0 ;
    }
  
  if( m_PrevPos != NULL ) delete [] m_PrevPos ;
  m_PrevPos = new Vector [np] ;
  if( m_PrevPos == NULL )
    {
      danceInterp::OutputMessage("MonitorPoints::Allocate:"
			      "Cannot allocate memory!") ;
      Deallocate() ;
      return 0 ;
    }
  
  if( m_PrevPosTimeStamp != NULL ) delete [] m_PrevPosTimeStamp ;
  m_PrevPosTimeStamp = new double [np] ;
  if( m_PrevPosTimeStamp == NULL )
    {
      danceInterp::OutputMessage("MonitorPoints::Allocate:"
			      "Cannot allocate memory!") ;
      Deallocate() ;
      return 0 ;
    }
  
  if( m_object != NULL ) delete [] m_object ;
  m_object = new DObject *[np] ;
  if( m_object == NULL )
    {
      danceInterp::OutputMessage("MonitorPoints::Allocate:"
			      "Cannot allocate memory!") ;
      Deallocate() ;
      return 0 ;
    }
  
  
  m_NumPoints = np ;
  return np ;    
}

/**
  * Delete all the vector arrays 
  *
  * Deletes the m_PrevPos, m_Points, m_InCollision
  * and sets the m_NumPoints to zero
  */
void MonitorPoints::Deallocate() 
{
    if( m_Point != NULL ) delete [] m_Point  ;
    if (m_InCollision != NULL) delete [] m_InCollision ;
    if( m_PrevPos != NULL ) delete [] m_PrevPos ; 
    if( m_object != NULL ) delete [] m_object ;
	if (m_PrevPosTimeStamp != NULL) delete [] m_PrevPosTimeStamp;

    m_NumPoints = 0 ;
}

/** set all points to be above the ground */
void MonitorPoints::Reset()
{
	for( int i = 0 ; i < m_NumPoints ; i++ )
	{
		m_InCollision[i] = FALSE ;
		m_object[i] = NULL ;
	}
}

/** set all points to be above the ground */
void MonitorPoints::Reset(DObject *obj)
{
	for( int i = 0 ; i < m_NumPoints ; i++ )
	{
		if( m_object[i] == obj)
		{
			m_InCollision[i] = FALSE ;
			m_object[i] = NULL ;
		}
	}
}
