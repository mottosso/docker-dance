/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "GeometryWindow.h"
#include "dance.h"
#include "danceInterp.h"
#include "ViewManager.h"
#include "AttributeWindow.h"
#include <fltk/ColorChooser.h>
#include <fltk/Color.h>
#include <fltk/PackedGroup.h>
#include <fltk/ask.h>


using namespace fltk;

GeometryWindow::GeometryWindow(DGeometry* geom, int x, int y, int w, int h, const char *s) : ScrollGroup(x, y, w, h, s)
{
	setGeometry(geom);
	this->begin();

	fltk::PackedGroup* packedGroup = new fltk::PackedGroup(0, 0, 300, 600);
	packedGroup->begin();
	
		// add the attribute list
		AttributeWindow* attr = new AttributeWindow(this->geometry, 0, 0, 300, 400, "Attributes");
		attr->show();
		
		fltk::Group* transformGroup = new fltk::Group(0, 0, 300, 200, "Transform");
		transformGroup->flags(fltk::ALIGN_TOP | fltk::ALIGN_INSIDE_LEFT);
		transformGroup->box(fltk::BORDER_BOX);
		//transformGroup->flags(fltk::ALIGN_LEFT);
		transformGroup->begin();
			buttonReset = new Button(20, 25, 110, 20, "Reset Transformation");
			buttonReset->callback(ResetCB, this);

			buttonUpdate = new Button(20, 50, 50, 20, "Update");
			buttonUpdate->callback(UpdateCB, this);

			buttonCenter = new Button(20, 75, 50, 20, "Center");
			buttonCenter->callback(CenterCB, this);

			outputMaterial = new Output(80, 100, 110, 20, "Material");
			outputMaterial->color(fltk::GRAY75);
			buttonMaterial = new Button(200, 100, 60, 20, "Material");
			buttonMaterial->callback(MaterialButtonCB, this);

			choiceDisplay = new Choice(80, 125, 150, 20, "Show as:");
			choiceDisplay->add("Solid");
			choiceDisplay->add("Mesh");
			choiceDisplay->add("Points");
			choiceDisplay->callback(this->DisplayChoiceCB, this);
		transformGroup->end();

	packedGroup->end();

	this->end();

	updateGUI();
}

GeometryWindow::~GeometryWindow()
{
}

void GeometryWindow::show()
{
	this->updateGUI();
	ScrollGroup::show();
}

void GeometryWindow::updateGUI()
{
	if (this->active())
	{
		for (int x = 0; x < this->children(); x++)
		{
			Widget* w = this->child(x);
			w->activate();
		}
		DGeometry* geometry = this->getGeometry();

		double widthScale = .1;
		double heightScale = .1;
		if (dance::AllViews->getViewFocus() != NULL)
		{
			widthScale = dance::AllViews->getViewFocus()->getFrustumWidth(0.0) / 100.0;
			heightScale = dance::AllViews->getViewFocus()->getFrustumHeight(0.0) / 100.0;
		}

		// material name
		Material* m = this->getGeometry()->getMaterial();
		if (m != NULL)
		{
			this->outputMaterial->value(m->getMaterialName());
		}
		
		// display type
		choiceDisplay->activate();
		if (this->getGeometry()->isShowSolid())
			choiceDisplay->value(0);
		else if (this->getGeometry()->isShowMesh())
			choiceDisplay->value(1);
		else if (this->getGeometry()->isShowVertices())
			choiceDisplay->value(2);

	}
	else
	{
		for (int x = 0; x < this->children(); x++)
		{
			Widget* w = this->child(x);
			w->deactivate();
		}
		choiceDisplay->deactivate();
	}
}



void GeometryWindow::ResetCB(fltk::Widget *w, void *data)
{
	GeometryWindow *cw = (GeometryWindow*)data;

	int ok = fltk::ask("Reset transformation matrix?");
	if (ok)
	{
		double identity[4][4];
		setIdentMat(&identity[0][0], 4);
		cw->geometry->Translate(0, 0, 0);
		cw->geometry->Rotate(0.0, 0.0, 0.0);
		cw->geometry->Scale(1, 1, 1);
		cw->updateGUI();
		dance::AllViews->postRedisplay();
	}
}

void GeometryWindow::UpdateCB(Widget *w, void *data)
{
	GeometryWindow *cw = (GeometryWindow*)data;
	
	cw->updateGUI();

	dance::AllViews->postRedisplay();
}

DGeometry* GeometryWindow::getGeometry()
{
	return geometry;
}

void GeometryWindow::setGeometry(DGeometry* g)
{
	geometry = g;
}

void GeometryWindow::MaterialButtonCB(fltk::Widget *w, void *data)
{	
	GeometryWindow *cw = (GeometryWindow*)data;
	DGeometry* geom = cw->getGeometry();

	dance::rootWindow->materialWindow->setSelected(geom->getMaterial());
	dance::rootWindow->materialWindow->setSelectMode(true);
	dance::rootWindow->materialWindow->exec(dance::rootWindow);

	Material* m = dance::rootWindow->materialWindow->getSelected();
	if (m != NULL)
	{
		geom->setMaterial(m);
	}
	cw->updateGUI();
	dance::AllViews->postRedisplay();
}

void GeometryWindow::DisplayChoiceCB(fltk::Widget *w, void *data)
{
	GeometryWindow *gw = (GeometryWindow*) data;

	Choice* choice = (Choice*) w;

	switch (choice->value())
	{
	case 0:
		gw->getGeometry()->showSolid();
		break;
	case 1:
		gw->getGeometry()->showMesh();
		break;
	case 2:
		gw->getGeometry()->showVertices();
		break;
	}

	gw->updateGUI();
	dance::Refresh();

}

void GeometryWindow::CenterCB(fltk::Widget *w, void *data)
{
	GeometryWindow *gw = (GeometryWindow*) data;

	if (fltk::ask("Change vertices?"))
	{
		
		gw->geometry->Center(true);
	}
	else
	{
		gw->geometry->Center();
	}

	gw->updateGUI();
	dance::Refresh();
}

