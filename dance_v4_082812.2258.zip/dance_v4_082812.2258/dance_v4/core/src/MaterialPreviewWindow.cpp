/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "MaterialPreviewWindow.h"
#include <fltk/glut.h>

MaterialPreviewWindow::MaterialPreviewWindow(int x, int y, int w, int h, const char* name) : GlWindow(x, y, w, h, name)
{
	previewType = PREVIEW_SPHERE;
	material = NULL;
	fov = 45;
	qobj = NULL ;
}

MaterialPreviewWindow::~MaterialPreviewWindow()
{
	if( qobj) gluDeleteQuadric(qobj);
}

void MaterialPreviewWindow::setMaterial(Material* m)
{
	material = m;
	if (material->has_texture())
		previewType = PREVIEW_CUBE;
	else
		previewType = PREVIEW_SPHERE;
}

Material* MaterialPreviewWindow::getMaterial()
{
	return material;
}

void MaterialPreviewWindow::setPreviewType(int type)
{
	previewType = type;
}

int MaterialPreviewWindow::getPreviewType()
{
	return previewType;
}

void MaterialPreviewWindow::initLights()
{
	float position[4] = {-4.0f, 4.0f, 4.0f, 1.0};
	float diffuse[4] = {.4f, .4f, .4f, 1.0f};
	float specular[4] = {.1f, .1f, .1f, 1.0f};
	float ambient[4] = {.2f, .2f, .2f, 1.0f};

	glLightfv(GL_LIGHT0, GL_POSITION, position); 
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);

	glEnable(GL_LIGHT0);

	float position2[4] = {10.0f, 10.0f, 10.0f, 1.0f};
	float diffuse2[4] = {.3f, .3f, .3f, 1.0f};
	float specular2[4] = {.2f, .2f, .2f, 1.0f};
	float ambient2[4] = {.1f, .1f, .1f, 1.0f};

	glLightfv(GL_LIGHT1, GL_POSITION, position2); 
	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse2);
	glLightfv(GL_LIGHT1, GL_SPECULAR, specular2);
	glLightfv(GL_LIGHT1, GL_AMBIENT, ambient2);

	glEnable(GL_LIGHT1);
}

void MaterialPreviewWindow::draw()
{
	// set up the sphere if needed
	if (qobj == NULL )
	{
		qobj = gluNewQuadric();
		gluQuadricDrawStyle(qobj, GLU_FILL);
		gluQuadricNormals(qobj, GLU_SMOOTH);
		gluQuadricTexture(qobj, GL_TRUE);
	}

	setVector(target, 0.0, 0.0, 0.0);
	setVector(camera, -1.0, 1.0, 2.0);

	float bcolor[4] = {0.0, 0.0, 0.0, 1.0};
	glClearColor(bcolor[0], bcolor[1], bcolor[2], bcolor[3]);

	initLights();

	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);

	glViewport(0, 0, w(), h());
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluPerspective(fov, w() / h(), 0.0001, 100);


	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	gluLookAt(camera[0], camera[1], camera[2], target[0], target[1], target[2], 0, 1, 0);
	initLights();

	if (material)
	{
		material->setOpenGLMaterial();
	}

	switch (previewType)
	{
	case PREVIEW_SPHERE:
		if (material && material->has_texture())
			gluSphere(qobj, 1, 20, 20);
		else 
			glutSolidSphere(1, 20, 20);

		break;
	case PREVIEW_CUBE:
		if (material && material->has_texture())
		{
			glBegin(GL_QUADS);		

			// -X SIDE
			glTexCoord2f(1.0f, 0.0f); glVertex3f(-.5f, -.5f, .5f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(-.5f, .5f, .5f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-.5f, .5f, -.5f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-.5f, -.5f, -.5f);

			// +X SIDE
			glTexCoord2f(0.0f, 1.0f); glVertex3f(.5f, .5f, .5f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(.5f, -.5f, .5f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(.5f, -.5f, -.5f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(.5f, .5f, -.5f);

			// -Y SIDE  //
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-.5f, -.5f, .5f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(.5f, -.5f, .5f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(.5f, -.5f, -.5f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-.5f, -.5f, -.5f);

			// +Y SIDE 
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-.5f, .5f, .5f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(.5f, .5f, .5f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(.5f, .5f, -.5f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-.5f, .5f, -.5f);

			// +Z side
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-.5f, .5f, .5f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(.5f, .5f, .5f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(.5f, -.5f, .5f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-.5f, -.5f, .5f);

			// -Z side
			glTexCoord2f(1.0f, 1.0f); glVertex3f(-.5f, .5f, -.5f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(.5f, .5f, -.5f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(.5f, -.5f, -.5f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(-.5f, -.5f, -.5f);

			glEnd();
		}
		else
		{
			glutSolidCube(1);
		}
		break;
	case PREVIEW_PLANE:
		break;
	default:
		break;
	}
	glPopMatrix();

	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
}

