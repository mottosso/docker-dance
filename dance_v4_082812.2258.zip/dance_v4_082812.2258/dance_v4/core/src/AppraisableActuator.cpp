#include "AppraisableActuator.h"

AppraisableActuator::~AppraisableActuator()
{
	// Noop
}

double AppraisableActuator::success( void )
{ 
	// Default returns success.  Effectively, this says "I know what I'm doing
	// by applying a dumb actuator."
	return 1.0; 
}


double AppraisableActuator::canHandle( ArticulatedObject* argAO, const EquilibriumPose& argTargetPose, double argStartTimeSecs )
{
	// Default returns failure (inability to reach the target pose)
	return 0.0;
}
