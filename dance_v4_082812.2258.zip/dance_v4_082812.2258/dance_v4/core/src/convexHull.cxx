/******************************************

This File implements the 2D convex hull	calculation
of a set of points. The	algorithm used is the Graham one
as described in	the book
Computational Geometry in C
	  by Joseph O' Rourke


The method uses	the negative cosines of	the angles
instead	of the atan used in the	book.

***************************************/


#include <cstdio>
#include <cstdlib>
#include <math.h>
#ifdef _WIN32
#include <cfloat>
#define	MINFLOAT DBL_MIN
#elif _MACOSX_
#include <cfloat>
#define	MINFLOAT DBL_MIN
#else
#include <values.h>
#endif
#include "convexHull.h"

#ifndef	EPS
#define	EPS 0.000001
#endif

static VertexStruct *q0	;

static int compareVStruct(const	void *v1, const	void *v2)
{
    VertexStruct *vs1 =	( VertexStruct *) v1 ;
    VertexStruct *vs2 =	( VertexStruct *) v2 ;

    if(	fabs(vs1->negcosAngle -	vs2->negcosAngle) < EPS	)
	return 0 ;
    if(	vs1->negcosAngle > vs2->negcosAngle ) return 1 ;
    else return	-1 ;
}


void convexHull(int nvertex, VertexStruct *vertices, int *ncv,
		VertexStruct *convHull)
{

    if(	nvertex	== 0 ) return ;


    // find the	rightmost point	with the minimum x2 ;
    int indx_min = 0 ;
    double min	= vertices[0].x2 ;
    int	i;
    for( i = 1 ; i < nvertex ; i++ )
    {

	if( vertices[i].x2 < min )
	{
	    min	= vertices[i].x2 ;
	    indx_min = i ;
	}
    }

    q0 = &vertices[indx_min] ;

    // calculate the negative cos of the angles	between
    // all the vertices	and the
    // vertex with minimum x2. The angles go from 0 to pi
    for( i = 0 ; i < nvertex ; i++ )
    {
	// just	for the	sorting	algorithm
	// make	sure that the min goes as the first element.
	if( i == indx_min ) 
	{
	    vertices[i].negcosAngle = MINFLOAT ;
	}
	else
	{
	    double dx1 = vertices[i].x1 - vertices[indx_min].x1 ;
	    double dx2 = vertices[i].x2 - vertices[indx_min].x2 ;
	    vertices[i].negcosAngle = -dx1 / sqrt(dx1*dx1 + dx2*dx2) ;
	}
    }


    // move q0 to the beginning	of the array
    if(	indx_min != 0 )
    {
	VertexStruct v = vertices[0] ;
	vertices[0] = vertices[indx_min] ;
	vertices[indx_min] = v ;

	indx_min = 0 ;
    }
    // now sort	the vertices with respect to the negative
    // cosine of the angle skipping the	first one
    qsort(&vertices[1],	nvertex-1, sizeof(VertexStruct), compareVStruct) ;

    // now run the heap	algorinthm
    VertexHeap hp ;

    hp.push(&vertices[0]) ;	// should the previous vertices[indx_min]
    hp.push(&vertices[1]) ;
    hp.push(&vertices[2]) ;

    for( i = 3 ; i < nvertex ; i++ )
    {
	while( (hp.next_to_top() != NULL) && (Area2(hp.next_to_top(), hp.top(), &vertices[i]) < 0 ))
	{
	    hp.pop() ;
	}
	hp.push(&vertices[i]) ;
    }

    // now put the result in the  array	provided
    *ncv = 0 ;
    VertexStruct *v ;
    while( (v =	hp.pop()) != NULL )
    {
	convHull[*ncv] = *v ;
       (*ncv) ++ ;
    }


}

VertexStruct *VertexHeap::pop(void)
{
    if(	topElement == NULL ) return NULL;
    HeapElement	*temp =	topElement ;
    topElement = topElement->next ;
    VertexStruct *r = temp->v ;
    delete temp	;
    return r ;
}

void VertexHeap::push(VertexStruct *v)
{
    HeapElement	*newEl = new HeapElement(v) ;
    newEl->next	= topElement ;
    topElement = newEl ;
}


// Returns two time the	signed area of the triagle abc.
// The result is positive if the a,b,c are oriented ccw.
double Area2(VertexStruct *a, VertexStruct *b, VertexStruct *c)
{
    return
      a->x1*b->x2 - a->x2*b->x1	+
      a->x2*c->x1 - a->x1*c->x2	+
      b->x1*c->x2 - c->x1*b->x2	;
}
