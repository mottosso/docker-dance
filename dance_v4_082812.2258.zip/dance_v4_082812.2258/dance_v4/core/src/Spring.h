/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _SPRING_
#define _SPRING_

#include "vectorObj.h"
#include "matrix3x3.h"
#include "defs.h"
#include "arbVector.h"

class DLLENTRY Spring {
  
 protected:
  
  int part0, part1;
  double ks, kd;
  double restLength;

 public:

  static int verb;
  static bool calcJacobian;

  void setKs(double KS) { ks = KS;}
  void setKd(double KD) { kd = KD;}
  void setKsKd(double kS, double kD) {
    ks = kS; kd = kD;
  }

  double& getKs() { return ks;}
  double& getKd() { return kd;}

  Spring();
  ~Spring();
  
  int index0() { return part0;}
  int index1() { return part1;}

  void attach(double *state, int index0, int index1);
  void scaleRestLength(double a) { restLength *= a;}
  double& getRestLength() { return restLength;}

  // given the two state arrays, will compute forces for particle0 and
  // particle1

  void computeForces(ArbVector &state, VectorObj &force0, VectorObj &force1, 
		     Matrix3x3 &dfdx0, Matrix3x3 &dfdv0,
		     Matrix3x3 &dfdx1, Matrix3x3 &dfdv1);

  void computeJacobians(VectorObj &x0, VectorObj &x1, 
			VectorObj &v0, VectorObj &v1, 
			Matrix3x3 &dfdx0, Matrix3x3 &dfdv0, 
			Matrix3x3 &dfdx1, Matrix3x3 &dfdv1);

  // given two positions, will compute forces for particle0
  void computeForces(const VectorObj &pos0, const VectorObj &vel0, 
		     const VectorObj &pos1, const VectorObj &vel1, 
		     VectorObj &force, 
		     Matrix3x3 &dfdx0, Matrix3x3 &dfdv0);
		     

  // computes forces in one dimension
  void computeForces(const VectorObj &dir, 
		     double offset, double vel, VectorObj &force, 
		     Matrix3x3 &dfdx, Matrix3x3 &dfdv);

  void computeJacobians(const VectorObj &dir, 
			const VectorObj &x0, const VectorObj &v0, 
			Matrix3x3 &dfdx0, Matrix3x3 &dfdv0);

  void getValues(double *state, double &displacement, double &relVelocity);
  
  void printInterp();
};

#endif
