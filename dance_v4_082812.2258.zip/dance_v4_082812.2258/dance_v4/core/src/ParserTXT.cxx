/**************************************************************************
	D.A.N.C.E.
	Dynamic AnimatioN and Control Environment
	----------------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
-----------------------------------------------
	
 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

 This software is distributed for noncommercial use in the hope that it will 
 be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
 to anyone for the consequences	of using it or for whether it serves any 
 particular purpose or works at all. No warranty is made about the software 
 or its performance. Commercial use is prohibited.
***************************************************************************/

#include "ParserTXT.h"
#include <iostream>
#include <stack>
#include <stdlib.h>
#include "danceInterp.h"

using namespace std;

Character* ParserTXT::parse(std::string name, std::ifstream &file)
{
	// check to make sure we have properly opened the file
	if (!file.good())
	{
		danceInterp::OutputMessage("Could not open file\n");
		return NULL;
	}
	char line[4096];
	Character* c = new Character();
	c->setName(name.c_str());
	c->setIsBVH(false);
	int state = 0;
	char* str;
	CharJoint* cur = NULL;
	int numFrames = 0;
	int curFrame = -1;
	int curParticle = -1;
	CharJoint* root = NULL;
	int channels[6];
	vector<double> data;
	int which = 0;

	while(!file.eof() && file.good())
	{
		file.getline(line, 4096, '\n');
		if (strlen(line) == 0) // ignore blank lines
			continue;
		double x = 0, y = 0, z = 0 ;
		switch (state)
		{
			case 0:	// looking for headers
				str = strtok(line, " \t");	
				root = new CharJoint("root");
				c->setRoot(root);
				c->setIsPoints(true);
				channels[0] = CharJoint::XPOSITION;
				channels[1] = CharJoint::YPOSITION;
				channels[2] = CharJoint::ZPOSITION;
				channels[3] = CharJoint::XROTATION;
				channels[4] = CharJoint::YROTATION;
				channels[5] = CharJoint::ZROTATION;
				root->setChannels(6, channels);
				c->setShowBones(false);
				c->setShowJoints(false);
				c->setShowPoints(true);
				while (str != NULL)
				{
					if (which % 3 == 0) // since the names include the DOF, grab the name every third time
					{
						cur = new CharJoint(str);
						root->addChild(cur);
						cur->setParent(root);
						channels[0] = CharJoint::XROTATION;
						channels[1] = CharJoint::YROTATION;
						channels[2] = CharJoint::ZROTATION;
						cur->setChannels(3, channels);
					}
				
					which++;
					str = strtok(NULL, " \t");
				}
				c->recalculateJointList();
				state = 1;
				break;
			case 1:	// process each frame
				str = strtok(line, " \t");
				if (str == NULL)
				{
					
					return c;
				}
				numFrames++;
				curFrame++;
				while (str != NULL) // collect all the values for the frame
				{
					double val = atof(str);
					data.push_back(val);
					str = strtok(NULL, " \t");
				}
				cur = NULL;
				for (unsigned int i = 0; i < data.size(); i++)
				{
					double val = data[i];
					if (i % 3 == 0)
					{
						curParticle++;
						cur = c->getJointByIndex(curParticle);
						if (cur == NULL)
							break;
						x = val;
					}
					else if (i % 3 == 1)
					{
						y = val;
					}
					else if (i % 3 == 2)
					{
						z = val;
						cur->addFrame(x, y, z);
					}
					

				}
				// make sure that the root has the matching frame
				root->addFrame(0.0, 0.0, 0.0);
				break;
			default:
				cerr << "State " << state << " not expected..." << endl;
				file.close();
				return c;
		}
	}
	danceInterp::OutputMessage("Finished parsing motion with %d frames...", numFrames);
	file.close();

	return c;
}
