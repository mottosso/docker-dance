/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "Spring.h"
#include <math.h>
#include "danceInterp.h"
#include <fltk/gl.h>

int Spring::verb = 0;
bool Spring::calcJacobian = false;

Spring::Spring() {

  part0 = part1 = 0;
  
  restLength = 0;
  
  ks = 40.0;
  kd = 1.0;
}

Spring::~Spring() {
  
}



void Spring::attach(double *state, int i0, int i1) {
  
  double dist[3];
  double *pos0, *pos1;

  part0 = i0;
  part1 = i1;
  
  pos0 = state+i0*6;
  pos1 = state+i1*6;
  
  dist[0] = pos0[0]-pos1[0];
  dist[1] = pos0[1]-pos1[1];
  dist[2] = pos0[2]-pos1[2];

  restLength = sqrt(dist[0]*dist[0] + dist[1]*dist[1] + dist[2]*dist[2]);
  
  //restLength *= 0.5;

}

void Spring::getValues(double *state, double &disp, double &relVelocity) {
  
  double *pos0, *pos1, *vel0, *vel1;
  double len, delta[3], vSpring[3], deltaV[3];

  pos0 = state+part0*6;
  pos1 = state+part1*6;
  
  vel0 = state+part0*6+3;
  vel1 = state+part1*6+3;
  
  delta[0] = pos1[0]-pos0[0];
  delta[1] = pos1[1]-pos0[1];
  delta[2] = pos1[2]-pos0[2];

  len = sqrt(delta[0]*delta[0] + delta[1]*delta[1] + delta[2]*delta[2]);

  disp = restLength-len;
  
  vSpring[0] = (vel0[0]+vel1[0])/2.0;
  vSpring[1] = (vel0[1]+vel1[1])/2.0;
  vSpring[2] = (vel0[2]+vel1[2])/2.0;
  
  deltaV[0] = vel0[0]-vSpring[0];
  deltaV[1] = vel0[1]-vSpring[1];
  deltaV[2] = vel0[2]-vSpring[2];

  relVelocity = sqrt(deltaV[0]*deltaV[0] + deltaV[1]*deltaV[1] +
		     deltaV[2]*deltaV[2]);
}

void Spring::computeForces(const VectorObj &dir, 
			   double offset, double vel, VectorObj &force, 
			   Matrix3x3 &dfdx, Matrix3x3 &dfdv) {
  
  force = dir*((restLength-offset)*ks-vel*kd);
  
  if (calcJacobian) {
    computeJacobians(dir, dir*offset, dir*vel, dfdx, dfdv);
  } else {
    dfdx.clear();
    dfdv.clear();
  }

}

void Spring::computeJacobians(const VectorObj &dir, 
			      const VectorObj &x0, const VectorObj &v0, 
			      Matrix3x3 &dfdx0, Matrix3x3 &dfdv0) {
  
  VectorObj I_norm, I_vec, vel, dVdx0;
  VectorObj dIdx0x, dIdx0y, dIdx0z;
  double I, I2, I3, D, V;

  I_norm = dir;
  I_norm.normalize();
  
  I_vec = -x0;
  I = I_vec.length();
  I2 = I*I;
  I3 = I2*I;
  
  vel = -v0;

  D = I;
  V = vel.dot(I_norm);

  
  dIdx0x.x() = (I_vec.x()*I_vec.x() - I2)/I3;
  dIdx0x.y() = I_vec.x()*I_vec.y()/I3;
  dIdx0x.z() = I_vec.x()*I_vec.z()/I3;
  
  dIdx0y.x() = I_vec.x()*I_vec.y()/I3;
  dIdx0y.y() = (I_vec.y()*I_vec.y()-I2)/I3;
  dIdx0y.z() = I_vec.z()*I_vec.y()/I3;
  
  dIdx0z.x() = I_vec.x()*I_vec.z()/I3;
  dIdx0z.y() = I_vec.y()*I_vec.z()/I3;
  dIdx0z.z() = (I_vec.z()*I_vec.z()-I2)/I3;

  dVdx0.x() = vel.dot(dIdx0x);
  dVdx0.y() = vel.dot(dIdx0y);
  dVdx0.z() = vel.dot(dIdx0z);

  dfdx0[0][0] = I_norm.x()*(ks*-I_norm.x()+kd*dVdx0.x())+
    dIdx0x.x()*(ks*D+kd*V);
  dfdx0[0][1] = I_norm.y()*(ks*-I_norm.x()+kd*dVdx0.x())+
    dIdx0x.y()*(ks*D+kd*V);
  dfdx0[0][2] = I_norm.z()*(ks*-I_norm.x()+kd*dVdx0.x())+
    dIdx0x.z()*(ks*D+kd*V);
  dfdx0[1][0] = I_norm.x()*(ks*-I_norm.y()+kd*dVdx0.y())+
    dIdx0y.x()*(ks*D+kd*V);
  dfdx0[1][1] = I_norm.y()*(ks*-I_norm.y()+kd*dVdx0.y())+
    dIdx0y.y()*(ks*D+kd*V);
  dfdx0[1][2] = I_norm.z()*(ks*-I_norm.y()+kd*dVdx0.y())+
    dIdx0y.z()*(ks*D+kd*V);
  dfdx0[2][0] = I_norm.x()*(ks*-I_norm.z()+kd*dVdx0.z())+
    dIdx0z.x()*(ks*D+kd*V);
  dfdx0[2][1] = I_norm.y()*(ks*-I_norm.z()+kd*dVdx0.z())+
    dIdx0z.y()*(ks*D+kd*V);
  dfdx0[2][2] = I_norm.z()*(ks*-I_norm.z()+kd*dVdx0.z())+
    dIdx0z.z()*(ks*D+kd*V);
  
  dfdv0[0][0] = I_norm.x()*kd*-I_norm.x();
  dfdv0[0][1] = I_norm.y()*kd*-I_norm.x();
  dfdv0[0][2] = I_norm.z()*kd*-I_norm.x();
  
  dfdv0[1][0] = I_norm.x()*kd*-I_norm.y();
  dfdv0[1][1] = I_norm.y()*kd*-I_norm.y();
  dfdv0[1][2] = I_norm.z()*kd*-I_norm.y();
  
  dfdv0[2][0] = I_norm.x()*kd*-I_norm.z();
  dfdv0[2][1] = I_norm.y()*kd*-I_norm.z();
  dfdv0[2][2] = I_norm.z()*kd*-I_norm.z();
}

void Spring::computeForces(const VectorObj &pos0, const VectorObj &vel0, 
			   const VectorObj &pos1, const VectorObj &vel1, 
			   VectorObj &force0, 
			   Matrix3x3 &dfdx0, Matrix3x3 &dfdv0) {
  
  VectorObj delta;
  VectorObj deltaV;
  double len, lenV, x;
  
  delta = pos1-pos0;
  len = delta.length();

  delta.normalize();
  // delta is normalized, and points from part0 to part1

  deltaV = vel0-vel1;

  // lenV is the projection of the particle velocity onto the delta vector
  lenV = delta.dot(deltaV);

  x = -len;
  
  force0 = delta*-(x*ks+lenV*kd);

  if (calcJacobian) {
    computeJacobians(delta, pos1-pos0, vel0, 
		     dfdx0, dfdv0);
  } else {
    dfdx0.clear();
    dfdv0.clear();
  }
}

void Spring::computeForces(ArbVector &state, 
			   VectorObj &force0, VectorObj &force1,
			   Matrix3x3 &dfDx0, Matrix3x3 &dfDv0, 
			   Matrix3x3 &dfDx1, Matrix3x3 &dfDv1) {

  VectorObj pos0, pos1, vel0, vel1, delta, f;
  VectorObj deltaV;
  double len, lenV, x;

  pos0 = state.data()+part0*6;
  pos1 = state.data()+part1*6;
  vel0 = state.data()+part0*6+3;
  vel1 = state.data()+part1*6+3;

  delta = pos1-pos0;
  len = delta.length();

  delta.normalize();
  // delta is normalized, and points from part0 to part1

  deltaV = vel0-vel1;

  // lenV is the projection of the particle velocity onto the delta vector
  lenV = delta.dot(deltaV);

  x = restLength-len;
  
  f = delta*-(x*ks+lenV*kd);
  
  force0 = f;
  force1 = -f;

  if (calcJacobian) {
    // do the derivatives
    computeJacobians(pos0, pos1, vel0, vel1, dfDx0, dfDv0, dfDx1, dfDv1);
  }
}

void Spring::computeJacobians(VectorObj &x0, VectorObj &x1, 
			      VectorObj &v0, VectorObj &v1,
			      Matrix3x3 &dfdx0, Matrix3x3 &dfdv0,
			      Matrix3x3 &dfdx1, Matrix3x3 &dfdv1) {
  
  VectorObj I_vec, I_norm, vel;
  VectorObj dIdx0x, dIdx0y, dIdx0z;
  VectorObj dIdx1x, dIdx1y, dIdx1z;
  double I, I2, I3;
  double D, V;

  VectorObj dDdx0, dDdx1;
  VectorObj dVdx0, dVdx1;

  VectorObj dF01dx0x, dF01dx0y, dF01dx0z;
  VectorObj dF10dx1x, dF10dx1y, dF10dx1z;

  I_vec = x1;
  I_vec -= x0;
  I_norm = I_vec;
  I_norm.normalize();

  I = I_vec.length();

  I2 = I*I;
  I3 = I2*I;

  vel = v1;
  vel -= v0;

  D = I-restLength;
  V = vel.dot(I_norm);

  dIdx0x.x() = (I_vec.x()*I_vec.x() - I2)/I3;
  dIdx0x.y() = I_vec.x()*I_vec.y()/I3;
  dIdx0x.z() = I_vec.x()*I_vec.z()/I3;
  
  dIdx0y.x() = I_vec.x()*I_vec.y()/I3;
  dIdx0y.y() = (I_vec.y()*I_vec.y()-I2)/I3;
  dIdx0y.z() = I_vec.z()*I_vec.y()/I3;
  
  dIdx0z.x() = I_vec.x()*I_vec.z()/I3;
  dIdx0z.y() = I_vec.y()*I_vec.z()/I3;
  dIdx0z.z() = (I_vec.z()*I_vec.z()-I2)/I3;

  dIdx1x = -dIdx0x;
  dIdx1y = -dIdx0y;
  dIdx1z = -dIdx0z;
  
  dDdx0 = -I_norm;
  dDdx1 = I_norm;

  dVdx0.x() = vel.dot(dIdx0x);
  dVdx0.y() = vel.dot(dIdx0y);
  dVdx0.z() = vel.dot(dIdx0z);

  dVdx1.x() = vel.dot(dIdx1x);
  dVdx1.y() = vel.dot(dIdx1y);
  dVdx1.z() = vel.dot(dIdx1z);

  dfdx0[0][0] = I_norm.x()*(ks*-I_norm.x()+kd*dVdx0.x())+
    dIdx0x.x()*(ks*D+kd*V);
  dfdx0[0][1] = I_norm.y()*(ks*-I_norm.x()+kd*dVdx0.x())+
    dIdx0x.y()*(ks*D+kd*V);
  dfdx0[0][2] = I_norm.z()*(ks*-I_norm.x()+kd*dVdx0.x())+
    dIdx0x.z()*(ks*D+kd*V);
  dfdx0[1][0] = I_norm.x()*(ks*-I_norm.y()+kd*dVdx0.y())+
    dIdx0y.x()*(ks*D+kd*V);
  dfdx0[1][1] = I_norm.y()*(ks*-I_norm.y()+kd*dVdx0.y())+
    dIdx0y.y()*(ks*D+kd*V);
  dfdx0[1][2] = I_norm.z()*(ks*-I_norm.y()+kd*dVdx0.y())+
    dIdx0y.z()*(ks*D+kd*V);
  dfdx0[2][0] = I_norm.x()*(ks*-I_norm.z()+kd*dVdx0.z())+
    dIdx0z.x()*(ks*D+kd*V);
  dfdx0[2][1] = I_norm.y()*(ks*-I_norm.z()+kd*dVdx0.z())+
    dIdx0z.y()*(ks*D+kd*V);
  dfdx0[2][2] = I_norm.z()*(ks*-I_norm.z()+kd*dVdx0.z())+
    dIdx0z.z()*(ks*D+kd*V);
  
  dfdx1[0][0] = I_norm.x()*(-ks*I_norm.x()-kd*dVdx1.x()) +
    dIdx1x.x()*(-ks*D-kd*V);
  dfdx1[0][1] = I_norm.y()*(-ks*I_norm.x()-kd*dVdx1.x()) +
    dIdx1x.y()*(-ks*D-kd*V);
  dfdx1[0][2] = I_norm.z()*(-ks*I_norm.x()-kd*dVdx1.x()) +
    dIdx1x.z()*(-ks*D-kd*V);
  dfdx1[1][0] = I_norm.x()*(-ks*I_norm.y()-kd*dVdx1.y()) +
    dIdx1y.x()*(-ks*D-kd*V);
  dfdx1[1][1] = I_norm.y()*(-ks*I_norm.y()-kd*dVdx1.y()) +
    dIdx1y.y()*(-ks*D-kd*V);
  dfdx1[1][2] = I_norm.z()*(-ks*I_norm.y()-kd*dVdx1.y()) +
    dIdx1y.z()*(-ks*D-kd*V);
  dfdx1[2][0] = I_norm.x()*(-ks*I_norm.z()-kd*dVdx1.z()) +
    dIdx1z.x()*(-ks*D-kd*V);
  dfdx1[2][1] = I_norm.y()*(-ks*I_norm.z()-kd*dVdx1.z()) +
    dIdx1z.y()*(-ks*D-kd*V);
  dfdx1[2][2] = I_norm.z()*(-ks*I_norm.z()-kd*dVdx1.z()) +
    dIdx1z.z()*(-ks*D-kd*V);

  // now do the velocities
  
  dfdv0[0][0] = I_norm.x()*kd*-I_norm.x();
  dfdv0[0][1] = I_norm.y()*kd*-I_norm.x();
  dfdv0[0][2] = I_norm.z()*kd*-I_norm.x();
  
  dfdv0[1][0] = I_norm.x()*kd*-I_norm.y();
  dfdv0[1][1] = I_norm.y()*kd*-I_norm.y();
  dfdv0[1][2] = I_norm.z()*kd*-I_norm.y();
  
  dfdv0[2][0] = I_norm.x()*kd*-I_norm.z();
  dfdv0[2][1] = I_norm.y()*kd*-I_norm.z();
  dfdv0[2][2] = I_norm.z()*kd*-I_norm.z();
  
  dfdv1 = dfdv0;

}


void Spring::printInterp() {
  
  danceInterp::OutputMessage("connect %d %d: ks %f kd %f restLength %f", 
			  part0, part1, ks, kd, restLength);
}
