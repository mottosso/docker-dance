/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_DObjectList_H_
#define	_DObjectList_H_ 1

#include "DObject.h"


class DLLENTRY DObjectList {
private:
  DObject *Active;
  std::string Type;
  int m_id;
  
protected:
  int numDObjects;
  
public:
  DObject **DObjects;
  int numDanceBins;
  
  INLINE const char *getType() { return Type.c_str(); };
  INLINE void setType(const char *type)	{ Type = type; };
  
  DObjectList();
  virtual ~DObjectList();
  
  virtual bool add(DObject *obj);
  virtual bool remove(int index);
  virtual bool remove(const char* name);
  virtual bool remove(DObject* object);
  int size();
  void save(int mode, std::ofstream& file);
  
  DObject	*get(int index);
  DObject *get(const char *name);
  int getIndex(const char *name);
  INLINE DObject *getActive() { return Active; };
  DObject *setActive(const char *name);
  DObject *setActive(int index);
  virtual int commandPlugIn(int argc, char **argv) {return DANCE_CONTINUE;};
  void output(int	mode);
  DObject *getByFileName(const char *fname);
//  int KeyboardCB(unsigned char key, int x, int y) ;

  unsigned int getID();
  
};


#endif
