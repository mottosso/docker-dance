/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef _PROXIMITY_H_
#define _PROXIMITY_H_ 1
#include "defs.h"

class DObject;
class box;
class Volume {
	public:
		int m_Type;
		box *m_Object;
		DObject *m_DObject;
		double m_LowerBound;
		double m_UpperBound;
		double m_LocalPoint[3];
		Volume *m_Next;

		Volume();
};


class DLLENTRY Proximity {
	private:
		Volume * buildVolumeFromOBB(box *obb, double *local, DObject *danceObj);
		int Prune();
		void AddSortedItem(Volume *vol);
		Volume * m_SortedVolumes;
		double m_LocalPoint[3];
	
	public:
		int GetClosest(double point[3], double closest[3], DObject **obj);
		void GetLocalPoint(double localpoint[3]);
		Volume * InitializeAll(DObject *skipObj = NULL, int type = -1);
		Volume *m_Volumes;
		double m_TestPoint[3];
		void Clear();
		void Deallocate(Volume *wvol);
		int FindClosest(double point[3], double closest[3], double normal[3], DObject **obj, box **OBB);
		int GetClosestN(double point[3], int n, Volume **list, DObject *exclude = NULL);
		double Implicit(double world[3], double normal[3]);
		void Reset(Volume *wvol);

		Proximity();
		void AddItem(DObject *obj);
};
#endif
