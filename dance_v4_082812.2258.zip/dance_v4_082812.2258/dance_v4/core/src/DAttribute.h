#ifndef DATTRIBUTE_H
#define DATTRIBUTE_H

#include "defs.h"
#include "DSubject.h"
#include "vector.h"
#include "arbMatrix.h"
#include <string>
#include <vector>
#include <limits>

class DObject;
class DAttributeInfo;

class DLLENTRY DAttribute : public DSubject
{
	public:
		DAttribute(const std::string& name);	
		DAttribute();
		virtual ~DAttribute();
		void setName(const std::string& name);
		const std::string& getName() const;
		virtual std::string write() = 0;
		virtual void read() = 0;
		DAttributeInfo* getAttributeInfo();

		void setObject(DObject* object);
		DObject* getObject();


	protected:
		std::string m_name;
		DAttributeInfo* m_info;
		DObject* m_object;
};

class DLLENTRY DAttributeGroup 
{
	public:
		DAttributeGroup(const std::string& name);
		~DAttributeGroup();

		const std::string& getName() const;
		void setPriority(int val);
		int getPriority();

	protected:
		std::string m_name;
		int m_priority;
};


class DLLENTRY DAttributeInfo
{
	public:
		DAttributeInfo();
		~DAttributeInfo();

		void setPriority(int val);
		int getPriority();

		void setReadOnly(bool val);
		bool getReadOnly();
		void setLocked(bool val);
		bool getLocked();
		void setHidden(bool val);
		bool getHidden();
		void setGroup(DAttributeGroup* group);
		DAttributeGroup* getGroup();
		void setGroup(const std::string& groupName);

		std::string write();

		void setAttribute(DAttribute* attr);
		DAttribute* getAttribute();

	protected:
		bool m_readOnly;
		bool m_locked;
		int m_priority;
		bool m_hidden;
		DAttribute* m_attr;
		DAttributeGroup* m_group;
};

class DLLENTRY BoolAttribute : public DAttribute
{
	public:
		BoolAttribute();
		BoolAttribute(const std::string& name, bool val = true);
		~BoolAttribute();

		bool getValue(float time = -1.0);
		void setValue(const bool& val, float time = -1.0);
		void setDefaultValue(const bool& defaultVal);
		bool getDefaultValue();

		virtual std::string write();
		virtual void read();

	private:
		bool m_value;
		bool m_defaultValue;
};

class DLLENTRY IntAttribute : public DAttribute
{
	public:
		IntAttribute();
		IntAttribute(const std::string& name, int val = 0, int min = -std::numeric_limits<int>::max(), int max = std::numeric_limits<int>::max());
		~IntAttribute();

		int getValue(float time = -1.0);
		void setValue(const int& val, float time = -1.0);
		void setDefaultValue(const int& defaultVal);
		int getDefaultValue();
		int getMin();
		int getMax();
		void setMin(int val);
		void setMax(int val);
		
		virtual std::string write();
		virtual void read();

	private:
		int m_value;
		int m_defaultValue;
		int m_min;
		int m_max;
};

class DLLENTRY DoubleAttribute : public DAttribute
{
	public:
		DoubleAttribute();
		DoubleAttribute(const std::string& name, double val = 0, double min = -std::numeric_limits<double>::max(), double max = std::numeric_limits<double>::max());
		~DoubleAttribute();

		double getValue(float time = -1.0);
		void setValue(const double& val, float time = -1.0);
		void setDefaultValue(const double& defaultVal);
		double getDefaultValue();
		double getMin();
		double getMax();
		void setMin(double val);
		void setMax(double val);

		virtual std::string write();
		virtual void read();

	private:
		double m_value;
		double m_defaultValue;
		double m_min;
		double m_max;
};

class DLLENTRY StringAttribute : public DAttribute
{
	public:
		StringAttribute();
		StringAttribute(const std::string& name, std::string value = "");
		~StringAttribute();

		const std::string& getValue(float time = -1.0);
		void setValue(const std::string& val, float time = -1.0);
		void setDefaultValue(const std::string& defaultVal);
		const std::string& getDefaultValue();
		void setValidValues(const std::vector<std::string>& values);
		std::vector<std::string>& getValidValues();

		virtual std::string write();
		virtual void read();

	private:
		std::string m_value;
		std::string m_defaultValue;
		std::vector<std::string> m_validValues;
};

class DLLENTRY Vec3Attribute : public DAttribute
{
	public:
		Vec3Attribute();
		Vec3Attribute(const std::string& name);
		~Vec3Attribute();

		double* getValue(float time = -1.0);
		void setValue(Vector val, float time = -1.0);
		void setDefaultValue(const Vector& defaultVal);
		double* getDefaultValue();

		virtual std::string write();
		virtual void read();

	private:
		Vector m_value;
		Vector m_defaultValue;
};

class DLLENTRY MatrixAttribute : public DAttribute
{
	public:
		MatrixAttribute();
		MatrixAttribute(const std::string& name);
		~MatrixAttribute();

		ArbMatrix& getValue(float time = -1.0);
		void setValue(const ArbMatrix& matrix, float time = -1.0);
		void setDefaultValue(const ArbMatrix& matrix);
		ArbMatrix& getDefaultValue();

		virtual std::string write();
		virtual void read();

	private:
		ArbMatrix m_value;
		ArbMatrix m_defaultValue;
};


#endif
