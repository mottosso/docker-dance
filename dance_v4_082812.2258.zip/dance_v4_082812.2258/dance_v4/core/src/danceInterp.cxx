/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "dance.h"
#include "DObjectList.h"
#include "PlugInManager.h"
#include "DSimulatorManager.h"
#include "danceInterp.h"
#include "DSystem.h"
#include "ViewManager.h"
#include "DanceWindow.h"
#include "SelectionWindow.h"

#include <iostream>
#include <cstdlib>
#include <assert.h>

#ifndef WIN32
#include <unistd.h>
#endif

using namespace fltk;
using namespace std;

int danceInterp::showinterface(int argc, char **argv)
{
	if (dance::rootWindow->commandWindow == NULL)
		return DANCE_ERROR;

	if (argc > 2)
	{
		OutputMessage("USAGE: showinterface <object name>\n");
		return DANCE_ERROR;
	}

	// find the object of the given name
	DObject* object = dance::getObject(argv[0]);
	if (object != NULL)
	{
		Widget* window = object->getInterface();
		if (window == NULL)
		{
			danceInterp::OutputMessage("Object %s has no GUI interface.", object->getName());
			return DANCE_OK;
		}
		dance::rootWindow->parameterWindow->addInterface(window, object->getName());
		
		return DANCE_OK;
	}

	return DANCE_OK;
}

int danceInterp::hideinterface(int argc, char **argv)
{
	if (dance::rootWindow->commandWindow == NULL)
		return DANCE_ERROR;

	if (argc > 1)
	{
		OutputMessage("USAGE: hideinterface <object name>\n");
		return DANCE_ERROR;
	}

	// find the object of the given name
	DObject* object = dance::getObject(argv[0]);
	if (object != NULL)
	{
		Widget* widget = object->getInterface();
		dance::rootWindow->parameterWindow->removeInterface(widget);

		return DANCE_OK;
	}

	return DANCE_OK;
}

int danceInterp::addinteraction(int argc, char **argv)
{
	if (dance::rootWindow->commandWindow == NULL)
		return DANCE_ERROR;

	if (argc > 2)
	{
		OutputMessage("USAGE: addinteraction <object name>\n");
		return DANCE_ERROR;
	}

	// find the object of the given name
	DObject* object = dance::getObject(argv[0]);
	if (object != NULL)
	{
		dance::addInteraction(object);
		OutputMessage("Object %s will now handle interactions.", object->getName());
		return DANCE_OK;
	}

	return DANCE_OK;
}

int danceInterp::removeinteraction(int argc, char **argv)
{
	if (dance::rootWindow->commandWindow == NULL)
		return DANCE_ERROR;

	if (argc > 2)
	{
		OutputMessage("USAGE: removeinteraction <object name>\n");
		return DANCE_ERROR;
	}

	// find the object of the given name
	DObject* object = dance::getObject(argv[0]);
	if (object != NULL)
	{
		dance::removeInteraction(object);
		OutputMessage("Object %s will no longer handle interactions.", object->getName());
		return DANCE_OK;
	}

	return DANCE_OK;
}

void checkUIRecurse(fltk::Group* group)
{
	int leftEdge = group->x();
	int topEdge = group->y();
	int bottomEdge = group->h() + topEdge;
	int rightEdge = group->w() + leftEdge;

	for (int c = 0; c < group->children(); c++)
	{
		fltk::Widget* child = group->child(c);
		int childLeftEdge = child->x();
		int childTopEdge = child->y();
		int childBottomEdge = child->h() + childTopEdge;
		int childRightEdge = child->w() + childLeftEdge;
		std::string childName = child->label()? child->label() : "unknown";
		std::string parentName = group->label()? group->label() : "unknown";

		if (childLeftEdge < 0)
		{
			danceInterp::OutputMessage("Child %s to left of parent %s: %d -> %d", childName.c_str(), parentName.c_str(), childLeftEdge, leftEdge); 
		}
		if (childTopEdge < 0)
		{
			danceInterp::OutputMessage("Child %s above parent %s: %d -> %d", childName.c_str(), parentName.c_str(), childTopEdge, topEdge); 
		}
		if (childBottomEdge > group->h())
		{
			danceInterp::OutputMessage("Child %s below parent %s: %d -> %d", childName.c_str(), parentName.c_str(), childBottomEdge, group->h()); 
		}
		if (childRightEdge > group->w())
		{
			danceInterp::OutputMessage("Child %s to right of parent %s: %d -> %d", childName.c_str(), parentName.c_str(), childRightEdge, group->w()); 
		}

		fltk::Group* childGroup = dynamic_cast<Group*>(child);
		if (childGroup)
		{
			checkUIRecurse(childGroup);
		}
	}
}

int danceInterp::checkUI(int argc, char **argv)
{
	// check the UI for overlap
	fltk::Group* group = dance::rootWindow;

	checkUIRecurse(group);


	return DANCE_OK;
}

int danceInterp::setNoOutput(int argc, char **argv)
{
	if (argc > 1)
	{
		OutputMessage("USAGE: setNoOutput(0/1) \n");
		return DANCE_ERROR;
	}
	if( atoi(argv[0]) == 1 )
		dance::NoOutput = true  ;
	else
		dance::NoOutput = false  ;
	return DANCE_OK ;
}

int danceInterp::dependency(int argc, char **argv)
{
	if (argc > 1)
	{
		OutputMessage("USAGE: dependency <object name>\n");
		return DANCE_ERROR;
	}

	std::vector<DObject*> allobjects;
	if (argc == 1)
	{
		DObject* object = dance::getObject(argv[0]);
		if (object != NULL)
		{
			allobjects.push_back(object);
		}
		else
		{
			danceInterp::OutputMessage("No object with name %s found.", argv[0]);
			return DANCE_ERROR;
		}
	}
	else
	{
		for (int x = 0; x < dance::AllActuators->size(); x++)
		{
			DObject* object = dance::AllActuators->get(x);
			allobjects.push_back(object);
		}
		for (int x = 0; x < dance::AllGeometry->size(); x++)
		{
			DObject* object = dance::AllGeometry->get(x);
			allobjects.push_back(object);
		}
		for (int x = 0; x < dance::AllSystems->size(); x++)
		{
			DObject* object = dance::AllSystems->get(x);
			allobjects.push_back(object);
		}
		for (int x = 0; x < dance::AllSimulators->size(); x++)
		{
			DObject* object = dance::AllSimulators->get(x);
			allobjects.push_back(object);
		}
		for (int x = 0; x < dance::AllModifiers->size(); x++)
		{
			DObject* object = dance::AllModifiers->get(x);
			allobjects.push_back(object);
		}
		for (int x = 0; x < dance::AllRenderers->size(); x++)
		{
			DObject* object = dance::AllRenderers->get(x);
			allobjects.push_back(object);
		}
		for (int x = 0; x < dance::AllLights->size(); x++)
		{
			DObject* object = dance::AllLights->get(x);
			allobjects.push_back(object);
		}
		for (int x = 0; x < dance::AllViews->size(); x++)
		{
			DObject* object = dance::AllViews->get(x);
			allobjects.push_back(object);
		}
		for (int x = 0; x < dance::AllGenericPlugins->size(); x++)
		{
			DObject* object = dance::AllGenericPlugins->get(x);
			allobjects.push_back(object);
		}
	}

	for (std::vector<DObject*>::iterator iter = allobjects.begin(); iter != allobjects.end(); iter++)
	{
		DObject* object = (*iter);
		DObjectRefList* refs = object->getDependencies();
		DObjectRefList* reverserefs = object->getDependenciesReverse();
		danceInterp::OutputMessage("%s (%d forward, %d reverse):", object->getName(), refs->size(), reverserefs->size());
		danceInterp::OutputMessage("\tForward Dependencies for %s (%d):", object->getName(), refs->size());
		for (int x = 0; x < refs->size(); x++)
		{
			DObject* obj = refs->get(x);
			danceInterp::OutputMessage("\t\t%s", obj->getName());
		}
		danceInterp::OutputMessage("\tReverse Dependencies for %s (%d):", object->getName(), reverserefs->size());
		for (int x = 0; x < reverserefs->size(); x++)
		{
			DObject* obj = reverserefs->get(x);
			danceInterp::OutputMessage("\t\t%s", obj->getName());
		}

	}
	return DANCE_OK;

}



DObjectList	*danceInterp::getList(const char* type)
{
	int number; DObjectList **lists;
	dance::getLists(&number, &lists);

	int i;
	for (i=0; i<number; i++)
	    if (strcmp(lists[i]->getType(),type) == 0)
		break;
	if (i == number)
		return NULL;
	return (lists[i]);
}


int danceInterp::remove(int argc, char **argv)
{
    if(	argc !=	2) {
	danceInterp::OutputMessage("USAGE: remove <type> <name>\n");
	return(DANCE_ERROR);
    }

    DObjectList *list = getList(argv[0]);
    if (list ==	NULL) {
	danceInterp::OutputMessage("ERROR: Invalid type: %s", argv[0]);
	return(DANCE_ERROR);
    }

    if (list->remove(argv[1]) == 0) {
	danceInterp::OutputMessage("ERROR: DANCE object with name %s not found.", argv[1]);
	return DANCE_ERROR;
    }

    danceInterp::OutputMessage("OK");
	dance::AllViews->postRedisplay();
    
    return DANCE_OK ;
}

int danceInterp::exists(int argc, char **argv)
{
    if(	argc !=	1) {
	danceInterp::OutputMessage("USAGE: exists <name>\n");
	return(DANCE_ERROR);
    }

	DObject* obj = dance::getObject(argv[0]);
	if (obj != NULL)
	{
		danceInterp::OutputResult("yes");
	}
	else
	{
		danceInterp::OutputResult("no");
	}
    
    return DANCE_OK ;
}

int danceInterp::show(int argc,	char **argv)
{
    if(	argc < 1)
	{
		int numLists;
		DObjectList** lists;
		dance::getLists(&numLists, &lists);
		for (int x = 0; x < numLists; x++)
		{
		    DObjectList* list = lists[x];
			for (int i = 0; i < list->size(); i++)
			{
				DObject* obj = list->get(i);
				danceInterp::OutputListElement("%s",obj->getName());
			}
		}
		return DANCE_OK;
	}

    DObjectList *list = getList(argv[0]);
    if (list ==	NULL)
	{
		danceInterp::OutputMessage("ERROR: Invalid type: %s", argv[0]);
		return DANCE_ERROR;
    }

    DObject	*obj = NULL;
    if (argc ==	2)
	{
		int found = 0;
		for (int i = 0; i < list->size(); i++)
		{
			obj = list->get(i);
			if (strcmp(obj->getType(),argv[1]) == 0)
			{
				found = 1;
				danceInterp::OutputListElement("%s",obj->getName());
			}
		}
		if (found == 0)
		{
			danceInterp::OutputMessage("%s is not a valid plugin type.", argv[1]);
			return DANCE_ERROR;
		}
		return DANCE_OK;
    }
    else
	{
		for (int i = 0;	i < list->size(); i++)
		{
			obj	= list->get(i);
			danceInterp::OutputListElement("%s",obj->getName());
		}
    }

    return DANCE_OK ;
}





// all
//	Applies	a command to all members of a list.
//
int danceInterp::all(int argc, char **argv)
{
	if (argc <2) {
	   danceInterp::OutputMessage("USAGE:	all [actuator|constraint|view] <command>\n");
	   return DANCE_ERROR;
	}

	// Determine type.
	DObjectList	*list =	getList(argv[0]);
	if (list == NULL) {
	   danceInterp::OutputMessage("ERROR:	Unrecognized type.\n");
	   return DANCE_ERROR;
	}

	argc -=	1;
	argv +=	1;
	return(list->commandPlugIn(argc,argv));

}

// active
//	Sets the given object type with	the name active.
int danceInterp::active(int argc, char **argv)
{
	if (argc !=2) {
	   danceInterp::OutputMessage("USAGE:	active [actuator|system] <name>\n");
	   return DANCE_ERROR;
	}

	// Determine type.
	DObjectList	*list =	getList(argv[0]);
	if (list)
		list->setActive(argv[1]);
	else {
	   danceInterp::OutputMessage("ERROR:	Unrecognized type.\n");
	   return DANCE_ERROR;
	}

	danceInterp::OutputMessage("OK");
	return DANCE_OK;
}

// instance
//	Create instances of the	desired	objects.
int danceInterp::instance(int argc, char **argv)
{
	if (argc < 2)
	{
	   danceInterp::OutputMessage("USAGE:	instance <type>	<name>\n");
	   return DANCE_ERROR;
	}

	// Analyze type.
	DObject *obj = NULL;
	PlugIn *plugin = NULL ;

	if( (strcmp(argv[0], "view") != 0 ) && (strcmp(argv[0], "light") != 0 ) )
	    plugin = dance::AllPlugIns->GetInstance(argv[0],argv[1], argc-2,&argv[2]);
	
	if (plugin == NULL)
	{
	     //	Test for other types of	objects	(non-plugins)
	     DObjectList *list = getList(argv[0]);
	     if	(list == NULL)
		 {
		   danceInterp::OutputMessage("ERROR: %s instance creation failed.", argv[0]) ;
		   return DANCE_ERROR;
	     }
	     obj = dance::getInstance(argv[0],argv[1],argc-2,&argv[2]);

	     //	getInstance may	perform	its own	list management.

	     if (obj == NULL)
		 {
			if ((strcmp(argv[0],"view") !=	0) && (strcmp(argv[1],"quadview") != 0))
			{
				danceInterp::OutputMessage("ERROR: Must use a specific plugin name.\n");
				return DANCE_ERROR;
			}
			return	DANCE_OK;
	     }

	}
	else
	{
	     obj = plugin;

	     //	Initialize interface.
//	     plugin->initInterface(interp) ;
	}


	// Now add this	instance to the	appropriate list.
	DObjectList* list = getList(obj->getBaseType());
	if (list) {
		// Check for duplicate.
		if (list->get(argv[1]) != NULL)	{
		    delete obj;
		    //danceInterp::OutputMessage("ERROR: Name already exists for type. Deleting	object.\n");
		    //return DANCE_ERROR;
		    danceInterp::OutputMessage("WARNING: Name %s already exists for type. Deleting extra object.\n",
				argv[1]);
		} else {
		  list->add(obj);
		}
		list->setActive(argv[1]);
	}
	else
	{
	   danceInterp::OutputMessage("ERROR:	%s Unrecognized DANCE object type.\n", argv[0]);
		if (obj->getBaseType() == NULL)
			danceInterp::OutputMessage("obj->getBaseType() = is NULL");
		else
			danceInterp::OutputMessage("obj->getBaseType() = %s", obj->getBaseType());
	   return DANCE_ERROR;
	}

	// update the interface structures
//	danceInterp::ExecuteCommand("updateAll") ;
	dance::AllViews->postRedisplay();
	danceInterp::OutputMessage("OK");
	return DANCE_OK;
}

// quit
//	Quits the application.
//
int danceInterp::quit(int argc,	char **argv)
{
	dance::DeleteAll();
	dance::quit();
	return(0);
}

// save
//	Saves all or individual	Dance objects.
//
int danceInterp::save(int argc,	char **argv)
{
	if (argc <= 1)
	{
		danceInterp::OutputMessage("USAGE:	save <filename>\n");
		return DANCE_ERROR;
	}

	dance::save(argv[0]);

	return DANCE_OK;
}

int danceInterp::rename(int argc, char **argv)
{
	if (argc <= 2)
	{
		danceInterp::OutputMessage("USAGE:	rename <object> <name>\n");
		return DANCE_ERROR;
	}

	if (strlen(argv[1]) == 0)
	{
		danceInterp::OutputMessage("Object must be renamed to a proper name.");
		return DANCE_ERROR;
	}

	DObject* obj = dance::AllPlugIns->get(argv[0]);
	if (obj == NULL)
	{
		danceInterp::OutputMessage("No object named '%s' found.", argv[0]);
		return DANCE_ERROR;
	}

	dance::rename(obj, argv[1]);
	return DANCE_OK;
}

int danceInterp::chdir(int argc, char **argv)
{
	if (argc < 1)
	{
		danceInterp::OutputMessage("USAGE:	chdir <object>\n");
		return DANCE_ERROR;
	}

	// convert the dir to an absolute directory, if needed
	std::string convertedDir = dance::convertPathToAbsolutePath(argv[0]);
	char command[1024];
	sprintf(command, "os.chdir(\"%s\")",convertedDir.c_str());
	int res = danceInterp::ExecuteCommand(command) ;
	if( res == DANCE_ERROR) 
	{
		danceInterp::OutputMessage("The chdir |%s| produced an error.", command) ;
	}

	// synchronize the dance current directory
	char dir[1024];
	danceInterp::getCurrentDirectory(dir) ;
	if (strcmp(dance::rootWindow->commandWindow->getCurrentDirectory(), dir) != 0)
			dance::rootWindow->commandWindow->setCurrentDirectory(dir);

	return DANCE_OK;
}

int danceInterp::version(int argc, char **argv)
{
	danceInterp::OutputResult((char*) dance::getVersion().c_str());

	return DANCE_OK;
}

/** Handles	commands */
int danceInterp::Command(const char *type, int argc, char	**argv)
{
	 if (argc <= 1)	{
	     danceInterp::OutputMessage("USAGE:	%s <name> [<args> ...]\n",type);
	     return DANCE_ERROR;
	 }

	 DObjectList *list = getList(type);
	 DObject *obj = NULL;
	 if (list == NULL) {
	     danceInterp::OutputMessage("ERROR: Non-recognizable or no active DANCE object.\n");
			return DANCE_ERROR;
	 }
	 else {
		obj = list->get(argv[0]);

		if (obj	== NULL) {
			danceInterp::OutputMessage("ERROR: %s %s doesn't exist.", type, argv[0]);
			return DANCE_ERROR;
		}
		argc -=	1;
		argv +=	1;
	}

	return(obj->commandPlugIn(argc,argv));
}


/**
 * Adds the plugin into the PlugInManager registry list.
 *
 * A PlugIn is added into the PlugInManager registry list without creating an
 * instance of the specified PlugIn (ie., does not associate a name with it).
 * This is useful for cases where a PlugIn may be required by another PlugIn,
 * so that it must exist in the registry before the dependent PlugIn is instanced.
 *
 * @param int argc
 * @param char **argv
 * @return int 
 */
int danceInterp::Plugin(int argc, char **argv)
{
	if (argc != 1) {
		danceInterp::OutputMessage("Usage: dance.plugin( \"<plugin-type>\" )");
		return DANCE_ERROR;
	}
		
	PlugIn *proxy =	dance::AllPlugIns->AddProxy(argv[0]);
	if (proxy == NULL)
		return DANCE_ERROR;
	return DANCE_OK;
}
	
// start stop or re-start the simulation for all objects
// Also	makes the shared object	using the system function
// when	a simulation starts.
// If running in no display mode then it calls idleCB for ever.
// LIMITATIONS: Can take only 20 arguments
int danceInterp::simul(int argc, char **argv)
{
    dance::AllSimulators->Command(argc, argv) ;
    
    return DANCE_OK ;
}

int danceInterp::viewmanager(int argc, char **argv)
{
	int ret = dance::AllViews->commandPlugIn(argc, argv) ;
    
    return ret;
}

int danceInterp::materialmanager(int argc, char **argv)
{
	int ret = dance::MaterialManager->commandPlugIn(argc, argv) ;
    
    return ret ;
}

