/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <math.h>
#include "danceInterp.h"

#include "KeyFrame.h"

#ifndef MAX_LINE
#define MAX_LINE 256
#endif

static void parseComment(FILE *fp)
{
        // Read comment until newline.
        while (fgetc(fp) != (int)'\n');
        return ;
}

KeyFrame::KeyFrame()
{
	m_params = NULL;
    setNumParams(0);
    setNext(NULL);
    setPrevious(NULL);
    setTime(0);
}

KeyFrame::KeyFrame(int numParams)
{
	m_params = NULL;
    setNumParams(numParams);
    setNext(NULL);
    setPrevious(NULL);
    setTime(0);

}

KeyFrame::KeyFrame(double time, int numParams, double* params)
{
	m_params = NULL;
	setNumParams(numParams);

	for (int i = 0; i < m_numParams; i++)
		m_params[i] = params[i] ;

	setNext(NULL);
	setPrevious(NULL);
	setTime(time);
}

KeyFrame::KeyFrame(KeyFrame* kf)
{
	if (kf == NULL)
	{
		danceInterp::OutputMessage("Setting new key frame to NULL key frame.");
		m_params = NULL;
		setNumParams(0);
		setNext(NULL);
		setPrevious(NULL);
		setTime(0);
		return;
	}
	m_params = NULL;
	setNumParams(kf->getNumParams());

	double* params = kf->getParams();
	for (int i = 0; i < m_numParams; i++)
		m_params[i] = params[i] ;

	setNext(NULL);
	setPrevious(NULL);
	setTime(kf->getTime());
}

KeyFrame::~KeyFrame()
{
    if (m_params != NULL)
		delete [] m_params;
}

double KeyFrame::getParam(int index)
{
	if (index >= 0 && index < getNumParams())
		return m_params[index];
	else
	{
		danceInterp::OutputMessage("Cannot return parameter %d of keyframe, only %d parameters.", index, getNumParams());
		return 0.0;
	}
}

void KeyFrame::setParam(int index, double val)
{
	if (index >= 0 && index < getNumParams())
		m_params[index] = val;
	else
		danceInterp::OutputMessage("Cannot set parameter %d of keyframe, only %d parameters.", index, getNumParams());
}

void KeyFrame::getParams(double* params)
{
	for (int x = 0; x < getNumParams(); x++)
		params[x] = m_params[x];
}

double* KeyFrame::getParams()
{
	return this->m_params;
}

void KeyFrame::setParams(double* params)
{
	for (int x = 0; x < getNumParams(); x++)
		m_params[x] = params[x];
}

double KeyFrame::getTime()
{
	return m_time;
}

void KeyFrame::setTime(double t)
{
	m_time = t;
}

void KeyFrame::setNumParams(int num)
{
	if (m_params == NULL)
	{
		if (num > 0)
			m_params = new double[num] ;
	}
	else 
	{
		if (num != getNumParams()) // want to allocate a differenly sized keyframe
		{
			// change the keyframe size
			double* frame = new double[num];
			int low = getNumParams();
			if (num < low)
				low = num;
			for (int x = 0; x < low; x++)
				frame[x] = m_params[x];
			delete [] m_params;
			m_params = frame;
		}
	}
	m_numParams = num;
}

int KeyFrame::getNumParams()
{
	return m_numParams;
}

void KeyFrame::save(FILE *fp)
{
    fprintf(fp, "\t\tkeyFrame {");
    fprintf(fp, " time %lf", m_time);
    for( int i = 0 ; i < getNumParams() ; i++ )
    {
		if (getParam(i) == 0.0)
			fprintf(fp, " 0");
		else
			fprintf(fp, " %lf", getParam(i));
    }
    fprintf(fp, " }\n") ;
}

int KeyFrame::load(FILE *fp)
{
	char token[MAX_LINE];
	int result ;
	double param[MAX_NUM_PARAM] ;
	int done = FALSE ;
	int timeRead = FALSE ;

	// get the opening bracket
	int scanResult = fscanf(fp,"%s", token) ;
	if (scanResult < 0 || strcmp(token, "{") != 0 )
	{
		printf("ERROR: KeyFrame read: expected '{'\n'") ;
		return 0 ;
	}
	int cur = 0;
	do {
		result = fscanf(fp,"%s",token);
		if( result > 0 )
		{
			if( strcmp(token, "#") == 0 )
				parseComment(fp) ;
			else if( strcmp(token, "}") == 0 )
			{
				done = TRUE ;
			}
			else if( strcmp(token, "time") == 0 )
			{
				result =  fscanf(fp,"%s",token);
				if( result > 0 )
					m_time = atof(token) ;
				{
					timeRead = TRUE ;
				}
			}
			else		// read param
			{
				param[cur] = atof(token) ;
				cur++ ;
			}
		}
		else
		{
			printf("Unexpected end of file!\n") ;
		}

	} while ((!feof(fp)) && (done == FALSE)) ;

	if( feof(fp) )
	{
		printf("ERROR: Key frame not read properly.\n") ;
	}

	if( timeRead == FALSE ) 
	{
		printf("ERROR: time of keyframe not read properly.\n") ;
	}

	if( cur > 0 )
	{
		setNumParams(cur);
		setParams(param);
	}

	return getNumParams() ;
}

KeyFrame* KeyFrame::getNext()
{
	return m_next;
}

KeyFrame* KeyFrame::getPrevious()
{
	return m_previous;
}

void KeyFrame::setNext(KeyFrame* kf)
{
	m_next = kf;
}

void KeyFrame::setPrevious(KeyFrame* kf)
{
	m_previous = kf;
}







