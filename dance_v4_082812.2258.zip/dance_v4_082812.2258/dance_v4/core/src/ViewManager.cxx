/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "dance.h"
#include "ViewManager.h"
#include "DView.h"
#include "DanceWindow.h"
#include "danceInterp.h"
#include "BoundingBox.h"

ViewManager::ViewManager()
{
}

ViewManager::ViewManager(int argc, char	**argv)
{
	m_focus = NULL;
	for (int l = 0; l < MAXNUMVIEWS; l++)
		m_viewAtlocation[l] = NULL;
	setActiveLocation(-1);
	
	m_isQuadView = false;
	setRenderer(NULL);
	currentView = NULL;
}

void ViewManager::AttachCameras(BoundingBox *box)
{
	for (int i=0; i	< size(); i++)
	{
		DView *view = (DView *)get(i);
		    view->AttachCamera(box);
	}
}

ViewManager::~ViewManager()
{
		for (int i=0; i	< numDObjects; i++)
			if (DObjects[i]) {
				delete DObjects[i];
				DObjects[i] = NULL;
			}
		numDObjects = 0;
}

void ViewManager::FitView()
{  
	BoundingBox box;
	std::map<std::string, DObject*>& selectedObjects = dance::selectionManager->getSelectedObjects();
	if (selectedObjects.size())
	{
		for (std::map<std::string, DObject*>::iterator iter = selectedObjects.begin();
			iter != selectedObjects.end();
			iter++)
		{
			(*iter).second->calcBoundingBox(&box);
		}	
	}
	else
	{
		BoundingBox* b = dance::GetSceneBox(false);
		box.merge(*b);
	}
	AttachCameras(&box);
}


DView *ViewManager::getViewFocus()
{
	return m_focus;
}

void ViewManager::setViewFocus(DView* view)
{
	m_focus = view;
	for (int v = 0; v < MAXNUMVIEWS; v++)
	{
		if (m_viewAtlocation[v] == m_focus)
			setActiveLocation(v);
	}
	if (m_focus != NULL)
		m_focus->resetLights();
}

void ViewManager::move()
{
	for	(int i = 0; i <	size();	i++)
	{
		 DView *view = (DView *)get(i);

		int currx = dance::rootWindow->danceWindow ->x();
		int curry = dance::rootWindow->danceWindow ->y();
		int currw = dance::rootWindow->danceWindow ->w();
		int currh = dance::rootWindow->danceWindow ->h();
		// Check if window was	moved.
		if (currx != view->getX() || curry != view->getY())
		//	The window *might* have	moved. Check if	it really has.
		if	(currw == view->getWidth() && currh == view->getHeight())
		{
			int diffx = currx - view->getX();
			int diffy = curry - view->getY();
			view->setX(currx); view->setY(curry);

			// Position the other windows.
			int index = getIndex(view->getName());

			for (int j = 1; j <= size()-1 ; j++)
			{
				DView	*wview = (DView *)get((index+j)%size());
				wview->setX(wview->getX() + diffx);
				wview->setY(wview->getY() + diffy);
			}

			break;
		} // end check if window moved.
	} // end for
}

void ViewManager::postRedisplay()
{
	if (this->isQuadView())
	{
		for (int i = 0; i < size(); i++)
		{
			DView *view = (DView *)get(i);
			if (i == 0 && this->getViewFocus() == NULL)
				this->setViewFocus(view);
			view->postRedisplay();
		}
	}
	else
	{
		if (this->getViewFocus() != NULL)
			this->getViewFocus()->postRedisplay();
	}


	dance::rootWindow->danceWindow->redraw();
}

void ViewManager::postRedisplayActive()
{
	postRedisplay();
}

int ViewManager::commandPlugIn(int argc, char * * argv)
{
	if (strcmp(argv[0],"refresh") == 0 || strcmp(argv[0], "redisplay") == 0)
	{
		postRedisplay();
	}
	else if (strcmp(argv[0],"fitview") == 0)
	{
		FitView();
	}
	else if (strcmp(argv[0], "renderer") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: viewmanager renderer <renderer_name>");
			return DANCE_ERROR;
		}
		else
		{
			DRenderer* renderer = (DRenderer*) dance::AllRenderers->get(argv[1]);
			if (renderer == NULL)
			{
				danceInterp::OutputMessage("Renderer %s not found.", argv[1]);
				return DANCE_ERROR;
			}
			else
			{
				this->setRenderer(renderer);
				danceInterp::OutputMessage("Renderer %s has been loaded and is available for use.", argv[1]);
				return DANCE_OK;
			}
			return DANCE_ERROR;
		}
	}	
	else if (strcmp(argv[0], "viewfocus") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.viewmanager(\"viewfocus\", \"<view>\"");
			return DANCE_ERROR;
		}
		DView* view = (DView*) dance::AllViews->get(argv[1]);
		if (view == NULL)
		{
			danceInterp::OutputMessage("No view named '%s' found.", argv[1]);
			return DANCE_ERROR;
		}
		dance::AllViews->setViewFocus(view);
		return DANCE_OK;
	}
	else
		return DANCE_ERROR;

	return DANCE_CONTINUE;
}

bool ViewManager::isQuadView()
{
	return m_isQuadView;
}

void ViewManager::setQuadView(bool val)
{
	m_isQuadView = val;
	dance::AllViews->postRedisplay();
}

DView* ViewManager::getWindowAtLocation(int location)
{
	if (location < MAXNUMVIEWS)
		return m_viewAtlocation[location];
	else
		return NULL;
}

void ViewManager::setWindowAtLocation(int location, DView* view)
{
	if (location >= 0 && location < MAXNUMVIEWS)
		m_viewAtlocation[location] = view;
	else
		danceInterp::OutputMessage("Cannot set view %s to location %d, only %d locations exist.", MAXNUMVIEWS, view->getName(), location);
}

DView* ViewManager::createView(char *name, int argc, char** argv)
{
	int count = 0;
	for (int v = 0; v < MAXNUMVIEWS; v++)
		if (this->getWindowAtLocation(v) != NULL)
			count++;

	int ProjectionType = -1;

	if (argc > 0 && strlen(argv[0]) != 0)
	{
		if (strcmp(argv[0],"top") == 0)
			ProjectionType = DView::VIEW_TOP;
		else if (strcmp(argv[0],"right") == 0)
			ProjectionType = DView::VIEW_RIGHT;
		else if (strcmp(argv[0],"front") == 0)
			ProjectionType = DView::VIEW_FRONT;
		else if (strcmp(argv[0],"persp") == 0)
			ProjectionType = DView::VIEW_PERSP;
	}
	else
	{
		ProjectionType = DView::VIEW_PERSP;
	}

	if (ProjectionType == -1)
	{
		danceInterp::OutputMessage("Cannot create view with type '%s', use <persp|top|front|right>");
		return NULL;
	}

	int x;
	int y;
	int width;
	int height;

	if (argc > 1)
	{
		x = (int)atof(argv[1]);
		y = (int)atof(argv[2]);
		width = (int)atof(argv[3]);
		height = (int)atof(argv[4]);
	}
	else
	{
		x = 1;
		y = 1;
		width = 1;
		height = 1;
	}

	// make sure that the view doesn't already exist
	DView* alreadyThere = (DView*) this->get(name);
	if (alreadyThere != NULL)
	{
		danceInterp::OutputMessage("A view named %s already exists. Please change the view name to create a new one.", name);
		return NULL;
	}

	DView* view = new DView(name, x, y, width, height);
	int viewLocation = -1;
	for (int v = 0; v < MAXNUMVIEWS; v++)
	{
		if (m_viewAtlocation[v] == NULL)
		{
			m_viewAtlocation[v] = view;
			viewLocation = v;
			break;
		}
	}

	int w = dance::rootWindow->danceWindow ->w();
	int h = dance::rootWindow->danceWindow ->h();

	if (isQuadView() && viewLocation != -1)
	{
		switch (viewLocation)
		{
		case ViewManager::TOP_LEFT:
			view->setX(2);
			view->setY(h / 2 + 2);
			break;
		case ViewManager::TOP_RIGHT:
			view->setX(w / 2 + 2);
			view->setY(h / 2 + 2);
			break;
		case ViewManager::BOTTOM_LEFT:
			view->setX(2);
			view->setY(2);
			break;
		case ViewManager::BOTTOM_RIGHT:
			view->setX(w / 2 + 2);
			view->setY(2);
			break;

		}
		view->setWidth(w / 2 - 4);
		view->setHeight(h / 2 - 4);
	}
	else
	{
		view->setX(0);
		view->setY(0);
		view->setWidth(w);
		view->setHeight(h);
	}
	view->setProjectionType(ProjectionType);

	// add the view at the next quadview location
	view->setCamera(SCALE_FOR_BB,-1.0,-1.0,-1.0,1.0,10.0,10.0);

	return view;
}

DView* ViewManager::copyView(DView* copyView, char* name)
{
	int count = 0;
	for (int v = 0; v < MAXNUMVIEWS; v++)
		if (this->getWindowAtLocation(v) != NULL)
			count++;

	//int ProjectionType = copyView->getProjectionType();
	int x = copyView->getX();
	int y = copyView->getY();
	int width = copyView->getWidth();
	int height = copyView->getHeight();

	DView* view = new DView(name, x, y, width, height);
	int viewLocation = -1;
	for (int v = 0; v < MAXNUMVIEWS; v++)
	{
		if (m_viewAtlocation[v] == NULL)
		{
			m_viewAtlocation[v] = view;
			viewLocation = v;
			break;
		}
	}

	float mat[4][4];
	copyView->getCameraOrientation(mat);
	view->setCameraOrientation(mat);

	double target[3];
	double panx;
	double pany;
	double distance;

	copyView->getCameraParms(&distance, &panx, &pany, target);
	view->setDistance(distance);
	view->setTarget(target);
	view->panCamera(panx, pany);
	view->setTarget(target);

	double* camera = copyView->getCamera();
	view->setCamera(camera);

	view->setShowName(copyView->showName());
	view->setLights(copyView->isLights() == 1? true : false);
	view->setShadows(copyView->isShadows()== 1? true : false);
	view->setSolids(copyView->isSolids() == 1? true : false);
	view->setShading(copyView->getShading());

	float bgcolor[4];
	copyView->getBackgroundColor(bgcolor);
	view->setBackgroundColor(bgcolor[0], bgcolor[1], bgcolor[2], 1.0);

	view->setGrid(copyView->showGrid());
	view->setGridStep(copyView->getGridStep());
	view->setGridSize(copyView->getGridSize());
	float gridcolor[3];
	copyView->getGridColor(gridcolor[0], gridcolor[1], gridcolor[2]);
	view->setGridColor(gridcolor[0], gridcolor[1], gridcolor[2]);
	float gridhighlightcolor[3];
	copyView->getGridHighlightColor(gridhighlightcolor[0], gridhighlightcolor[1], gridhighlightcolor[2]);
	copyView->setGridColor(gridhighlightcolor[0], gridhighlightcolor[1], gridhighlightcolor[2]);
		
	view->setDumpDirectory(copyView->getDumpDirectory());

	view->setFrameNumber(copyView->getFrameNumber());
	view->setDumped(copyView->isDumped());
	view->setFileName(copyView->getFileName());
	view->setStartFrameNumber(copyView->getStartFrameNumber());

	view->setFOV(copyView->getFOV());
	view->setShowStats(copyView->isShowStats());
	
	view->PositionCamera();
	view->resetLights();
	return view;
}


int ViewManager::getActiveLocation()
{
	return m_activeLocation;
}

void ViewManager::setActiveLocation(int v)
{
	m_activeLocation = v;
}

bool ViewManager::add(DObject *obj)
{
	bool ret = DObjectList::add(obj);

	if (ret)
		dance::rootWindow->updateViewMenu(this);

	return ret;
}


void ViewManager::resetActiveLocations()
{
	for (int x = 0; x < MAXNUMVIEWS; x++)
	{
		if (m_activeLocation == x && m_viewAtlocation[x] == NULL)
			m_activeLocation = -1;
	}
}

bool ViewManager::remove(int index)
{
	DView* view = dynamic_cast<DView*>(this->get(index));
	bool focus = (view == this->getViewFocus());
	int loc = getViewLocation(view);
	bool success = false;
	if (loc != -1)
		success = DObjectList::remove(index);

	if (success)
	{
		if (focus)
			this->setViewFocus(NULL);
		dance::rootWindow->updateViewMenu(this);
		if (loc != -1)
			setWindowAtLocation(loc, NULL);
		resetActiveLocations();
	}

	return success;
}

bool ViewManager::remove(char* name)
{
	DView* view = dynamic_cast<DView*>(this->get(name));
	bool focus = (view == this->getViewFocus());
	int loc = getViewLocation(view);
	bool success = DObjectList::remove(name);

	if (success)
	{
		dance::rootWindow->updateViewMenu(this);
		setWindowAtLocation(loc, NULL);
		resetActiveLocations();
		if (focus)
			this->setViewFocus(NULL);
	}

	return success;
}

bool ViewManager::remove(DObject* obj)
{
	DView* view = dynamic_cast<DView*>(obj);
	bool focus = (view == this->getViewFocus());
	int loc = getViewLocation(view);
	bool success = DObjectList::remove(obj);

	if (success)
	{
		dance::rootWindow->updateViewMenu(this);
		setWindowAtLocation(loc, NULL);
		resetActiveLocations();
		if (focus)
			this->setViewFocus(NULL);
	}

	return success;
}


void ViewManager::setRenderer(DRenderer* renderer)
{
	m_curRenderer = renderer;
}

DRenderer* ViewManager::getRenderer()
{
	return m_curRenderer;
}

int ViewManager::getNumViews()
{
	return this->size();
}

int ViewManager::getViewLocation(DView* view)
{
	for (int x = 0; x < MAXNUMVIEWS; x++)
		if (this->m_viewAtlocation[x] == view)
			return x;

	return -1;
}

void ViewManager::save(int mode, std::ofstream& file)
{
	DObjectList::save(mode, file);

	// set the current renderer
	if (this->getRenderer() != NULL)
	{
		file << "dance.viewmanager(\"renderer\", \"" << this->getRenderer()->getName() << "\")" << std::endl;
	}

	// set the view focus
	if (this->getViewFocus() != NULL)
	{
		file << "dance.viewmanager(\"viewfocus\", \"" << this->getViewFocus()->getName() << "\")" << std::endl;
	}
}


