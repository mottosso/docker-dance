/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _MATERIALEDITORWINDOW_
#define _MATERIALEDITORWINDOW_

#include <fltk/Window.h>
#include <fltk/Button.h>
#include <fltk/ValueInput.h>
#include <fltk/Output.h>
#include "Material.h"
#include "MaterialPreviewWindow.h"

class DLLENTRY MaterialEditorWindow : public fltk::Window
{
	public:
		MaterialEditorWindow(int x, int y, int w, int h, const char* name);

		void setMaterial(Material* m);
		Material* getMaterial();

		void restoreMaterial();
		void show();

		void updateGUI();

		static void color_cb(fltk::Widget* widget, void* data);
		static void inputcolor_cb(fltk::Widget* widget, void* data);
		static void shininess_cb(fltk::Widget* widget, void* data);
		static void texture_cb(fltk::Widget* widget, void* data);
		static void name_cb(fltk::Widget* widget, void* data);
		static void save_cb(fltk::Widget* widget, void* data);
		static void restore_cb(fltk::Widget* widget, void* data);
		static void cancel_cb(fltk::Widget* widget, void* data);

		fltk::Input* inputName;

		fltk::ValueInput* inputAmbient[3];
		fltk::ValueInput* inputDiffuse[3];
		fltk::ValueInput* inputSpecular[3];
		fltk::ValueInput* inputShininess;
		fltk::ValueInput* inputEmission[3];

		fltk::Button* buttonAmbient;
		fltk::Button* buttonDiffuse;
		fltk::Button* buttonSpecular;
		fltk::Button* buttonEmission;

		fltk::Output* outputTexture;
		fltk::Button* buttonTexture;

		fltk::Button* buttonSave;
		fltk::Button* buttonRestore;
		fltk::Button* buttonCancel;

		MaterialPreviewWindow* windowPreview;

	private:
		Material* material;

		Material materialCopy;

};

#endif

