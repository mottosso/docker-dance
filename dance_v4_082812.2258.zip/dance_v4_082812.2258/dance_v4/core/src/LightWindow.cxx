/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "LightWindow.h"
#include "dance.h"
#include "danceInterp.h"
#include "ViewManager.h"
#include <fltk/ColorChooser.h>
#include <fltk/ask.h>

using namespace fltk;

// Comments: The style of this code was adapted from GeometryWindow.cpp/.h

LightWindow::LightWindow(DLight* dlight, int x, int y, int w, int h, const char *s) : Group(x, y, w, h, s)
{
	this->begin();

	// ======= Get all the information for light to preset the values for the widgets ==========
	float lightCoords[4];							
	m_light = dlight;
	m_light->getPosition(lightCoords);

	float ambientVals[4];
	m_light->getAmbient(ambientVals);

	float diffuseVals[4];
	m_light->getDiffuse(diffuseVals);

	float specularVals[4];
	m_light->getSpecular(specularVals);

	// ========== Construct the Widgets for each parameter of the light =================================

	Group* groupPosition = new Group(10, 10, 300, 100, "Position");
	groupPosition->box(fltk::BORDER_BOX);
	groupPosition->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupPosition->begin();

	m_inputX = new ValueInput(20, 20, 60, 20, "X");
	m_inputX->callback(TranslateKeyCB, this);
	m_inputX->value(lightCoords[0]);			// put intial X coordinate of this light in box state.
	m_thumbWheelX = new ThumbWheel(90, 20, 60, 20, NULL);
	m_thumbWheelX->callback(TranslateCB, this);
	m_thumbWheelX->type(Slider::TICK_ABOVE);
	m_thumbWheelX->range(-100.0, 100.0);
	m_thumbWheelX->value(lightCoords[0]);			// put initial X coordinate of this light in roller state
	m_thumbWheelX->step(0.05);

	m_inputY = new ValueInput(20, 50, 60, 20, "Y");
	m_inputY->callback(TranslateKeyCB, this);
	m_inputY->value(lightCoords[1]);			// put intial Y coordinate of this light in box state.
	m_thumbWheelY = new ThumbWheel(90, 50, 60, 20, NULL);
	m_thumbWheelY->callback(TranslateCB, this);
	m_thumbWheelY->type(Slider::TICK_ABOVE);
	m_thumbWheelY->range(-100.0, 100.0);
	m_thumbWheelY->value(lightCoords[1]);			// put initial Y coordinate of this light in roller state
	m_thumbWheelY->step(0.05);

	m_inputZ = new ValueInput(20, 80, 60, 20, "Z");
	m_inputZ->callback(TranslateKeyCB, this);
	m_inputZ->value(lightCoords[2]);			// put intial Z coordinate of this light in box state.
	m_thumbWheelZ = new ThumbWheel(90, 80, 60, 20, NULL);
	m_thumbWheelZ->callback(TranslateCB, this);
	m_thumbWheelZ->type(Slider::TICK_ABOVE);
	m_thumbWheelZ->range(-100.0, 100.0);
	m_thumbWheelZ->value(lightCoords[2]);			// put initial Z coordinate of this light in roller state
	m_thumbWheelZ->step(0.05);
	
	checkDirectional = new CheckButton(180, 20, 80, 20, "Directional?");
	checkDirectional->callback(DirectionalCB, this);

	checkRelativeToCamera = new CheckButton(180, 50, 80, 20, "Relative to Camera?");
	checkRelativeToCamera->callback(RelativeToCameraCB, this);
	checkVisible = new CheckButton(180, 80, 80, 20, "Visible?");
	checkVisible->callback(VisibleCB, this);

	groupPosition->end();

	// ============== Widgets for Ambient Color ========================================= //
	Group* groupAmbient = new Group(10, 120, 300, 115);
	groupAmbient->box(fltk::BORDER_BOX);
	groupAmbient->begin();
	
	m_buttonAmbient = new Button(5, 5, 50, 20, "Ambient");
	m_buttonAmbient->callback(AmbientColorCB, this);

	m_inputAmbientR = new ValueInput(40, 30, 60, 20, "Red");
	m_inputAmbientR->callback(AmbientKeyCB, this);
	m_inputAmbientR->step(0.01);
	m_sliderAmbientR = new ValueSlider(100, 30, 170, 20, NULL);
	m_sliderAmbientR->callback(AmbientCB, this);
	m_sliderAmbientR->type(Slider::TICK_ABOVE);
	m_sliderAmbientR->range(0, 1);
	m_sliderAmbientR->value(0.0);
	m_sliderAmbientR->step(0.01);

	m_inputAmbientG = new ValueInput(40, 60, 60, 20, "Green");
	m_inputAmbientG->callback(AmbientKeyCB, this);
	m_inputAmbientG->step(0.01);
	m_sliderAmbientG = new ValueSlider(100, 60, 170, 20, NULL);
	m_sliderAmbientG->callback(AmbientCB, this);
	m_sliderAmbientG->type(Slider::TICK_ABOVE);
	m_sliderAmbientG->range(0, 1);
	m_sliderAmbientG->value(0.0);
	m_sliderAmbientG->step(0.01);

	m_inputAmbientB = new ValueInput(40, 90, 60, 20, "Blue");
	m_inputAmbientB->callback(AmbientKeyCB, this);
	m_inputAmbientB->step(0.01);
	m_sliderAmbientB = new ValueSlider(100, 90, 170, 20, NULL);
	m_sliderAmbientB->callback(AmbientCB, this);
	m_sliderAmbientB->type(Slider::TICK_ABOVE);
	m_sliderAmbientB->range(0, 1);
	m_sliderAmbientB->value(0.0);
	m_sliderAmbientB->step(0.01);

	groupAmbient->end();

	// ============== Widgets for Diffuse Color ========================================= //
	Group* groupDiffuse = new Group(10, 235, 300, 115);
	groupDiffuse->box(fltk::BORDER_BOX);
	groupDiffuse->begin();
	
	m_buttonDiffuse = new Button(5, 5, 50, 20, "Diffuse");
	m_buttonDiffuse->callback(DiffuseColorCB, this);

	m_inputDiffuseR = new ValueInput(40, 30, 60, 20, "Red");
	m_inputDiffuseR->callback(DiffuseKeyCB, this);
	m_inputDiffuseR->step(0.01);
	m_sliderDiffuseR = new ValueSlider(100, 30, 170, 20, NULL);
	m_sliderDiffuseR->callback(DiffuseCB, this);
	m_sliderDiffuseR->type(Slider::TICK_ABOVE);
	m_sliderDiffuseR->range(0, 1);
	m_sliderDiffuseR->value(0.0);
	m_sliderDiffuseR->step(0.01);

	m_inputDiffuseG = new ValueInput(40, 60, 60, 20, "Green");
	m_inputDiffuseG->callback(DiffuseKeyCB, this);
	m_inputDiffuseG->step(0.01);
	m_sliderDiffuseG = new ValueSlider(100, 60, 170, 20, NULL);
	m_sliderDiffuseG->callback(DiffuseCB, this);
	m_sliderDiffuseG->type(Slider::TICK_ABOVE);
	m_sliderDiffuseG->range(0, 1);
	m_sliderDiffuseG->value(0.0);
	m_sliderDiffuseG->step(0.01);

	m_inputDiffuseB = new ValueInput(40, 90, 60, 20, "Blue");
	m_inputDiffuseB->callback(DiffuseKeyCB, this);
	m_inputDiffuseB->step(0.01);
	m_sliderDiffuseB = new ValueSlider(100, 90, 170, 20, NULL);
	m_sliderDiffuseB->callback(DiffuseCB, this);
	m_sliderDiffuseB->type(Slider::TICK_ABOVE);
	m_sliderDiffuseB->range(0, 1);
	m_sliderDiffuseB->value(0.0);
	m_sliderDiffuseB->step(0.01);

	groupDiffuse->end();


	// ============== Widgets for Specular Color ========================================= //
	Group* groupSpecular = new Group(10, 360, 300, 115);
	groupSpecular->box(fltk::BORDER_BOX);
	groupSpecular->begin();
	
	m_buttonSpecular = new Button(5, 5, 50, 20, "Specular");
	m_buttonSpecular->callback(SpecularColorCB, this);

	m_inputSpecularR = new ValueInput(40, 30, 60, 20, "Red");
	m_inputSpecularR->callback(SpecularKeyCB, this);
	m_inputSpecularR->step(0.01);
	m_sliderSpecularR = new ValueSlider(100, 30, 170, 20, NULL);
	m_sliderSpecularR->callback(SpecularCB, this);
	m_sliderSpecularR->type(Slider::TICK_ABOVE);
	m_sliderSpecularR->range(0, 1);
	m_sliderSpecularR->value(0.0);
	m_sliderSpecularR->step(0.01);

	m_inputSpecularG = new ValueInput(40, 60, 60, 20, "Green");
	m_inputSpecularG->callback(SpecularKeyCB, this);
	m_inputSpecularG->step(0.01);
	m_sliderSpecularG = new ValueSlider(100, 60, 170, 20, NULL);
	m_sliderSpecularG->callback(SpecularCB, this);
	m_sliderSpecularG->type(Slider::TICK_ABOVE);
	m_sliderSpecularG->range(0, 1);
	m_sliderSpecularG->value(0.0);
	m_sliderSpecularG->step(0.01);

	m_inputSpecularB = new ValueInput(40, 90, 60, 20, "Blue");
	m_inputSpecularB->callback(SpecularKeyCB, this);
	m_inputSpecularB->step(0.01);
	m_sliderSpecularB = new ValueSlider(100, 90, 170, 20, NULL);
	m_sliderSpecularB->callback(SpecularCB, this);
	m_sliderSpecularB->type(Slider::TICK_ABOVE);
	m_sliderSpecularB->range(0, 1);
	m_sliderSpecularB->value(0.0);
	m_sliderSpecularB->step(0.01);

	groupSpecular->end();

	// ===== Initialize the variables that will remember the previous values for light settings ======
	oldX = 0;
	oldY = 0;
	oldZ = 0;

	oldAmbientR = 0;
	oldAmbientG = 0;
	oldAmbientB = 0;
	
	oldDiffuseR = 0;
	oldDiffuseG = 0;
	oldDiffuseB = 0;

	oldSpecularR = 0;
	oldSpecularG = 0;
	oldSpecularB = 0;

	Group* groupAttenuation = new Group(10, 485, 300, 55, "Attentuation");
	groupAttenuation->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupAttenuation->box(fltk::BORDER_BOX);
	groupAttenuation->begin();

	inputConstantAttentuation = new Input(60, 20, 30, 20, "Constant");
	inputConstantAttentuation->callback(AttenuationCB, this);
	inputLinearAttentuation = new Input(130, 20, 30, 20, "Linear");
	inputLinearAttentuation->callback(AttenuationCB, this);
	inputQuadraticAttentuation = new Input(220, 20, 30, 20, "Quadratic");
	inputQuadraticAttentuation->callback(AttenuationCB, this);

	groupAttenuation->end();

	Group* groupSpot = new Group(10, 550, 300, 80, "Spotlight Parameters");
	groupSpot->box(fltk::BORDER_BOX);
	groupSpot->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);

	groupSpot->begin();
	checkSpotlight = new CheckButton(10, 20, 80, 20, "Spotlight?");
	checkSpotlight->callback(SpotlightCB, this);
	inputSpotDirection[0] = new Input(160, 20, 30, 20, "Spot Direction");
	inputSpotDirection[0]->callback(SpotlightParametersCB, this);
	inputSpotDirection[1] = new Input(200, 20, 30, 20);
	inputSpotDirection[1]->callback(SpotlightParametersCB, this);
	inputSpotDirection[2] = new Input(250, 20, 30, 20);
	inputSpotDirection[2]->callback(SpotlightParametersCB, this);
	inputSpotCutoffAngle = new Input(70, 50, 30, 20, "Cutoff Angle");
	inputSpotCutoffAngle->callback(SpotlightParametersCB, this);
	inputSpotExponent  = new Input(200, 50, 30, 20, "Spot Exponent");
	inputSpotExponent->callback(SpotlightParametersCB, this);
	groupSpot->end();
	
	this->end();

	this->updateGUI();
}

void LightWindow::show()
{
	this->updateGUI();
	Group::show();
}


void LightWindow::updateGUI()
{
	GLfloat color[4];

	m_light->getAmbient(color);
	this->m_inputAmbientR->value(color[0]);
	this->m_inputAmbientG->value(color[1]);
	this->m_inputAmbientB->value(color[2]);
	this->m_sliderAmbientR->value(color[0]);
	this->m_sliderAmbientG->value(color[1]);
	this->m_sliderAmbientB->value(color[2]);

	m_light->getDiffuse(color);
	this->m_inputDiffuseR->value(color[0]);
	this->m_inputDiffuseG->value(color[1]);
	this->m_inputDiffuseB->value(color[2]);
	this->m_sliderDiffuseR->value(color[0]);
	this->m_sliderDiffuseG->value(color[1]);
	this->m_sliderDiffuseB->value(color[2]);

	m_light->getSpecular(color);
	this->m_inputSpecularR->value(color[0]);
	this->m_inputSpecularG->value(color[1]);
	this->m_inputSpecularB->value(color[2]);
	this->m_sliderSpecularR->value(color[0]);
	this->m_sliderSpecularG->value(color[1]);
	this->m_sliderSpecularB->value(color[2]);

	if (m_light->isVisible())
		this->checkVisible->value(1);
	else
		this->checkVisible->value(0);

	if (m_light->isRelativeToCamera())
		this->checkRelativeToCamera->value(1);
	else
		this->checkRelativeToCamera->value(0);

	char buff[80];
	if (m_light->isDirectional())
	{
		this->checkDirectional->value(1);
		// directional lights are not spotlights, disable all spotlight params
		this->checkSpotlight->deactivate();
		for (int i = 0; i < 3; i++)
			this->inputSpotDirection[i]->deactivate();
		this->inputSpotCutoffAngle->deactivate();
		this->inputSpotExponent->deactivate();
	}
	else
	{
		this->checkDirectional->value(0);
		this->checkSpotlight->activate();
	// spotlight
		if (m_light->isSpotlight())
		{
			this->checkSpotlight->value(1);
			GLfloat dir[3];
			m_light->getSpotDirection(dir);
			for (int i = 0; i < 3; i++)
			{
				sprintf(buff, "%f", dir[i]);
				this->inputSpotDirection[i]->value(buff);
			}
			sprintf(buff, "%f", m_light->getSpotCutoffAngle());
			this->inputSpotCutoffAngle->value(buff);
			sprintf(buff, "%f", m_light->getSpotExponent());
			this->inputSpotExponent->value(buff);

			for (int i = 0; i < 3; i++)
				this->inputSpotDirection[i]->activate();
			this->inputSpotCutoffAngle->activate();
			this->inputSpotExponent->activate();
		}
		else
		{
			this->checkSpotlight->value(0);
			for (int i = 0; i < 3; i++)
				this->inputSpotDirection[i]->deactivate();
			this->inputSpotCutoffAngle->deactivate();
			this->inputSpotExponent->deactivate();
		}
	}

	// attentuation

	sprintf(buff, "%f", this->getLight()->getLinearAttentuation());
	this->inputLinearAttentuation->value(buff);
	sprintf(buff, "%f", this->getLight()->getConstantAttentuation());
	this->inputConstantAttentuation->value(buff);
	sprintf(buff, "%f", this->getLight()->getQuadraticAttentuation());
	this->inputQuadraticAttentuation->value(buff);

	
}

// ========== Manages the callback for translating the x,y,z coordinates of the light =========
void LightWindow::TranslateCB(Widget *w, void *data)
{
	LightWindow *cw = (LightWindow*)data;
	
	cw->m_inputX->value( cw->m_thumbWheelX->value() );
	cw->m_inputY->value( cw->m_thumbWheelY->value() );
	cw->m_inputZ->value( cw->m_thumbWheelZ->value() );
	
	float params[4];
	params[0] = float(cw->m_inputX->value());
	params[1] = float(cw->m_inputY->value());
	params[2] = float(cw->m_inputZ->value());
	params[3] = float(1.0);
	cw->getLight()->setPosition(params);

	cw->oldX = cw->m_inputX->value();
	cw->oldY = cw->m_inputY->value();
	cw->oldZ = cw->m_inputZ->value();

	cw->updateGUI();
	dance::AllViews->postRedisplay();
}

// ========== Manages the callback for translating the x,y,z coordinates of the light =========
void LightWindow::TranslateKeyCB(Widget *w, void *data)
{
	LightWindow *cw = (LightWindow*)data;
	
	cw->m_thumbWheelX->value( cw->m_inputX->value() );
	cw->m_thumbWheelY->value( cw->m_inputY->value() );
	cw->m_thumbWheelZ->value( cw->m_inputZ->value() );
	
	float params[4];
	params[0] = float(cw->m_inputX->value());
	params[1] = float(cw->m_inputY->value());
	params[2] = float(cw->m_inputZ->value());
	params[3] = 1.0;
	cw->getLight()->setPosition(params);

	cw->oldX = cw->m_inputX->value();
	cw->oldY = cw->m_inputY->value();
	cw->oldZ = cw->m_inputZ->value();

	cw->updateGUI();
	dance::AllViews->postRedisplay();
}


// === Callback for the Sliders that control Ambient Light settings in RGB ====
void LightWindow::AmbientCB(Widget *w, void *data)
{
	LightWindow *cw = (LightWindow*)data;
	
	// update the Key input box with the slider values
	cw->m_inputAmbientR->value( cw->m_sliderAmbientR->value() );
	cw->m_inputAmbientG->value( cw->m_sliderAmbientG->value() );
	cw->m_inputAmbientB->value( cw->m_sliderAmbientB->value() );

	// save the old ambience values
	cw->oldAmbientR = cw->m_sliderAmbientR->value();
	cw->oldAmbientG = cw->m_sliderAmbientG->value();
	cw->oldAmbientB = cw->m_sliderAmbientB->value();
	
	// save new ambience values into DLight object attached to this window
	float params[4];
	params[0] = float(cw->m_inputAmbientR->value());
	params[1] = float(cw->m_inputAmbientG->value());
	params[2] = float(cw->m_inputAmbientB->value());
	params[3] = 1.0;
	cw->getLight()->setAmbient(params);

	cw->updateGUI();
	dance::AllViews->postRedisplay();
}

// === Callback for the ColorChooser button that controls Ambient Light settings in RGB ====
void LightWindow::AmbientColorCB(Widget *w, void *data) 
{
	LightWindow* cw = (LightWindow*) data;
	
	GLfloat color[4];
	float r,g,b;
	cw->getLight()->getAmbient(color);
	r = color[0];
	g = color[1];
	b = color[2];

	if (fltk::color_chooser("Ambient Color", r, g, b))
	{
		// save the chosen rgb values for the chosen color into an array so it can be 
		float params[4];
		params[0] = float(r);
		params[1] = float(g);
		params[2] = float(b);
		params[3] = 1.0;
		cw->getLight()->setAmbient(params);

		// Update the text box for ambient color
		cw->m_inputAmbientR->value(r);
		cw->m_inputAmbientG->value(g);
		cw->m_inputAmbientB->value(b);

		// Update the slider for ambient color
		cw->m_sliderAmbientR->value(r);
		cw->m_sliderAmbientG->value(g);
		cw->m_sliderAmbientB->value(b);

		cw->updateGUI();
		dance::AllViews->postRedisplay();
	}
}

// === Callback for the text boxes that control Ambient Light settings in RGB ====
void LightWindow::AmbientKeyCB(Widget *w, void *data)
{
	LightWindow *cw = (LightWindow*)data;

	// update the slider with the Key input box
	cw->m_sliderAmbientR->value( cw->m_inputAmbientR->value() );
	cw->m_sliderAmbientG->value( cw->m_inputAmbientG->value() );
	cw->m_sliderAmbientB->value( cw->m_inputAmbientB->value() );

	// save the old ambience values
	cw->oldAmbientR = cw->m_sliderAmbientR->value();
	cw->oldAmbientG = cw->m_sliderAmbientG->value();
	cw->oldAmbientB = cw->m_sliderAmbientB->value();

	// save new ambience values into DLight object attached to this window
	float params[4];
	params[0] = float(cw->m_inputAmbientR->value());
	params[1] = float(cw->m_inputAmbientG->value());
	params[2] = float(cw->m_inputAmbientB->value());
	params[3] = 1.0;
	cw->getLight()->setAmbient(params);

	cw->updateGUI();
	dance::AllViews->postRedisplay();
}

// === Callback for the ColorChooser button that controls Diffuse Light settings in RGB ====
void LightWindow::DiffuseColorCB(Widget *w, void *data) 
{
	LightWindow* cw = (LightWindow*) data;

	GLfloat color[4];
	float r,g,b;
	cw->getLight()->getAmbient(color);
	r = color[0];
	g = color[1];
	b = color[2];

    if (fltk::color_chooser("Diffuse Color", r, g, b))
	{
		// save the chosen rgb values for the chosen color into an array so it can be 
		float params[4];
		params[0] = float(r);
		params[1] = float(g);
		params[2] = float(b);
		params[3] = 1.0;
		cw->getLight()->setDiffuse(params);

		// Update the text box for ambient color
		cw->m_inputDiffuseR->value(r);
		cw->m_inputDiffuseG->value(g);
		cw->m_inputDiffuseB->value(b);

		// Update the slider for ambient color
		cw->m_sliderDiffuseR->value(r);
		cw->m_sliderDiffuseG->value(g);
		cw->m_sliderDiffuseB->value(b);

		cw->updateGUI();
		dance::AllViews->postRedisplay();	// update the dance light
	}

}

void LightWindow::DiffuseCB(Widget *w, void *data)
{
	double r, g, b;
	LightWindow *cw = (LightWindow*)data;

	cw->m_inputDiffuseR->value(cw->m_sliderDiffuseR->value());
	cw->m_inputDiffuseG->value(cw->m_sliderDiffuseG->value());
	cw->m_inputDiffuseB->value(cw->m_sliderDiffuseB->value());
	
	r = g = b = 0;
	r = cw->m_inputDiffuseR->value();
	g = cw->m_inputDiffuseG->value();
	b = cw->m_inputDiffuseB->value();

	cw->oldDiffuseR = r;
	cw->oldDiffuseG = r;
	cw->oldDiffuseB = b;

	// update the DLight values for diffuse
	float params[4];
	params[0] = float(cw->m_inputDiffuseR->value());
	params[1] = float(cw->m_inputDiffuseG->value());
	params[2] = float(cw->m_inputDiffuseB->value());
	params[3] = 1.0;
	cw->getLight()->setDiffuse(params);
	
	cw->updateGUI();
	dance::AllViews->postRedisplay();
}

void LightWindow::DiffuseKeyCB(Widget *w, void *data)
{
	double r, g, b;
	LightWindow *cw = (LightWindow*)data;

	cw->m_sliderDiffuseR->value(cw->m_inputDiffuseR->value());
	cw->m_sliderDiffuseG->value(cw->m_inputDiffuseG->value());
	cw->m_sliderDiffuseB->value(cw->m_inputDiffuseB->value());
	
	r = g = b = 0;
	r = cw->m_inputDiffuseR->value();
	g = cw->m_inputDiffuseG->value();
	b = cw->m_inputDiffuseB->value();

	cw->oldDiffuseR = r;
	cw->oldDiffuseG = g;
	cw->oldDiffuseB = b;

	// update the DLight values for diffuse
	float params[4];
	params[0] = float(cw->m_inputDiffuseR->value());
	params[1] = float(cw->m_inputDiffuseG->value());
	params[2] = float(cw->m_inputDiffuseB->value());
	params[3] = 1.0;
	cw->getLight()->setDiffuse(params);
	
	cw->updateGUI();
	dance::AllViews->postRedisplay();
}

// === Callback for the Sliders that control Specular Light settings in RGB ====
void LightWindow::SpecularCB(Widget *w, void *data)
{
	LightWindow *cw = (LightWindow*)data;
	
	// update the Key input box with the slider values
	cw->m_inputSpecularR->value( cw->m_sliderSpecularR->value() );
	cw->m_inputSpecularG->value( cw->m_sliderSpecularG->value() );
	cw->m_inputSpecularB->value( cw->m_sliderSpecularB->value() );

	// save the old Specular values
	cw->oldSpecularR = cw->m_sliderSpecularR->value();
	cw->oldSpecularG = cw->m_sliderSpecularG->value();
	cw->oldSpecularB = cw->m_sliderSpecularB->value();
	
	// save new Specular values into DLight object attached to this window
	float params[4];
	params[0] = float(cw->m_inputSpecularR->value());
	params[1] = float(cw->m_inputSpecularG->value());
	params[2] = float(cw->m_inputSpecularB->value());
	params[3] = 1.0;
	cw->getLight()->setSpecular(params);

	cw->updateGUI();
	dance::AllViews->postRedisplay();
}

// === Callback for the ColorChooser button that controls Specular Light settings in RGB ====
void LightWindow::SpecularColorCB(Widget *w, void *data) 
{
	LightWindow* cw = (LightWindow*) data;

	GLfloat color[4];
	float r,g,b;
	cw->getLight()->getAmbient(color);
	r = color[0];
	g = color[1];
	b = color[2];

	if (fltk::color_chooser("Specular Color", r, g, b))
	{
		// save the chosen rgb values for the chosen color into an array so it can be 
		float params[4];
		params[0] = float(r);
		params[1] = float(g);
		params[2] = float(b);
		params[3] = 1.0;
		cw->getLight()->setSpecular(params);

		// Update the text box for Specular color
		cw->m_inputSpecularR->value(r);
		cw->m_inputSpecularG->value(g);
		cw->m_inputSpecularB->value(b);

		// Update the slider for Specular color
		cw->m_sliderSpecularR->value(r);
		cw->m_sliderSpecularG->value(g);
		cw->m_sliderSpecularB->value(b);

		cw->updateGUI();
		dance::AllViews->postRedisplay();
	}
}

// === Callback for the text boxes that control Specular Light settings in RGB ====
void LightWindow::SpecularKeyCB(Widget *w, void *data)
{
	LightWindow *cw = (LightWindow*)data;

	// update the slider with the Key input box
	cw->m_sliderSpecularR->value( cw->m_inputSpecularR->value() );
	cw->m_sliderSpecularG->value( cw->m_inputSpecularG->value() );
	cw->m_sliderSpecularB->value( cw->m_inputSpecularB->value() );

	// save the old Specular values
	cw->oldSpecularR = cw->m_sliderSpecularR->value();
	cw->oldSpecularG = cw->m_sliderSpecularG->value();
	cw->oldSpecularB = cw->m_sliderSpecularB->value();

	// save new Specular values into DLight object attached to this window
	float params[4];
	params[0] = float(cw->m_inputSpecularR->value());
	params[1] = float(cw->m_inputSpecularG->value());
	params[2] = float(cw->m_inputSpecularB->value());
	params[3] = 1.0;
	cw->getLight()->setSpecular(params);

	cw->updateGUI();
	dance::AllViews->postRedisplay();
}

DLight* LightWindow::getLight()
{
	return m_light;
}

void LightWindow::DirectionalCB(fltk::Widget *w, void *data)
{
	LightWindow* window = (LightWindow*) data;
	CheckButton* check = (CheckButton*) w;
	window->getLight()->setDirectional(check->value() == 1? true : false);
	window->updateGUI();
	dance::AllViews->postRedisplay();
}

void LightWindow::AttenuationCB(fltk::Widget *w, void *data)
{
	LightWindow* window = (LightWindow*) data;
	window->getLight()->setConstantAttentuation(atof(window->inputConstantAttentuation->value()));
	window->getLight()->setLinearAttentuation(atof(window->inputLinearAttentuation->value()));
	window->getLight()->setQuadraticAttentuation(atof(window->inputQuadraticAttentuation->value()));
	window->updateGUI();
	dance::AllViews->postRedisplay();
}

void LightWindow::SpotlightCB(fltk::Widget *w, void *data)
{
	LightWindow* window = (LightWindow*) data;
	CheckButton* check = (CheckButton*) w;
	window->getLight()->setSpotlight(check->value());
	window->updateGUI();
	dance::AllViews->postRedisplay();
}

void LightWindow::SpotlightParametersCB(fltk::Widget *w, void *data)
{
	LightWindow* window = (LightWindow*) data;

	GLfloat dir[3];
	dir[0] = (GLfloat) atof(window->inputSpotDirection[0]->value());
	dir[1] = (GLfloat) atof(window->inputSpotDirection[1]->value());
	dir[2] = (GLfloat) atof(window->inputSpotDirection[2]->value());

	window->getLight()->setSpotDirection(dir);
	window->getLight()->setSpotCutoffAngle(atof(window->inputSpotCutoffAngle->value()));
	window->getLight()->setSpotExponent(atof(window->inputSpotExponent->value()));
	window->updateGUI();
	dance::AllViews->postRedisplay();
}

void LightWindow::RelativeToCameraCB(fltk::Widget *w, void *data)
{
	LightWindow* window = (LightWindow*) data;
	CheckButton* check = (CheckButton*) w;

	fltk::alert("Feature not yet implemented.");
	check->value(false);

	if (true) return;


	if (check->value())
		window->getLight()->setRelativeToCamera(true);
	else
		window->getLight()->setRelativeToCamera(false);
	window->updateGUI();
	dance::AllViews->postRedisplay();
}

void LightWindow::VisibleCB(fltk::Widget *w, void *data)
{
	LightWindow* window = (LightWindow*) data;
	CheckButton* check = (CheckButton*) w;

	if (check->value())
		window->getLight()->setVisible(true);
	else
		window->getLight()->setVisible(false);
	window->updateGUI();
	dance::AllViews->postRedisplay();
}

