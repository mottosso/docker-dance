/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "PlugInManager.h"
#include "danceInterp.h"
#include "DSimulatorManager.h"
#include "dance.h"


#include <cstdlib>
#ifdef WIN32
#include "windlfcn.h"
#else
#include <dlfcn.h>
#endif



/**
 * Adds an entry in the PlugInManager registry for the given PlugIn.
 *
 * Only an entry in the registry is created without creating an actual instance.
 * This is useful in situations where a plugin may need another plugin for successful
 * linking, but not require an actual instance.
 * @param char *type
 * @return PlugIn 
 */
PlugIn *PlugInManager::AddProxy(char *type)
{
	PlugIn* proxy = NULL;
	std::map<std::string, PlugIn*>::iterator iter = m_proxies.find(type);
	if (iter == m_proxies.end())
	{
		char *filename = GetPlugInFilename(type);
		proxy =	LoadPlugIn(filename);
		if (proxy == NULL)  
		{
			danceInterp::OutputMessage("Cannot load plugin file: %s. It may depend on "
						"another plugin that is not loaded.",filename);
			return(NULL);
		}
		
		
		proxy->setFileName(filename);
		
		// Sets	name to	type of	class, and type	to base	class.
		proxy->setName(type);
		proxy->setType(type);

		// remove any attributes from the proxy

		std::map<std::string, DAttribute*>& attributeList = proxy->getAttributeList();
		for (std::map<std::string, DAttribute*>::iterator iter = attributeList.begin();
			 iter != attributeList.end();
			 iter++)
		{
			delete iter->second;
		}

		m_proxies[type] = proxy;
		danceInterp::OutputMessage("PlugIn %s added to DANCE.",type);	
    }
	else
	{
		proxy = (*iter).second;
	}
    
    return proxy;
}

PlugIn *PlugInManager::GetInstance(char *type, char	*name, int argc, char **argv)
{
	// Check if proxy already exists for the type of plugin.
	// The name stores the type of the object created. The type stores
	// its base class name which is	the same as the	type.
	// This	is only	for the	proxy which doesn't relaly have	a name.

	PlugIn *proxy =	AddProxy(type);
	if (proxy == NULL) 
		return(NULL);
	
	PlugIn *instance = proxy->create(argc, argv);
	if (instance ==	NULL)
		return(NULL);

	instance->setName(name);
	instance->setType(type);

	return(instance);
}

char *PlugInManager::GetPlugInFilename(char *type)
{
	static char plugInName[256];


    // Add extension if	required.
#ifdef WIN32
	    sprintf(plugInName,"%s/plugins/win/%s",dance::getDanceDir(),type);
	    if (strcmp(&(type[strlen(type)-4]),".dll") != 0)
#ifdef _DEBUG
		strcat(plugInName,"_d.dll");
#else
		strcat(plugInName,".dll");
#endif
#else
#ifdef _MACOSX_
    sprintf(plugInName,"%s/plugins/osx/%s",dance::getDanceDir(),type);
#else // Linux
    sprintf(plugInName,"%s/plugins/linux/%s",dance::getDanceDir(),type);
#endif
    if (strcmp(&(type[strlen(type)-3]),".so") != 0)
		strcat(plugInName,".so");
#endif

    return (plugInName);
}

typedef	PlugIn * (*plugInFactory)();
PlugIn *PlugInManager::LoadPlugIn(char *filename)
{
    void *handle = NULL;


    FILE *fp = fopen(filename, "r") ;
    if( fp == NULL ) 
    {
	danceInterp::OutputMessage("ERROR:LoadPlugIn: File %s doesn't exist.",  filename) ;
	return NULL ;
    }
    else fclose(fp) ;

    handle = dlopen(filename, RTLD_NOW|RTLD_GLOBAL);
    if(	handle == NULL ) 
    {
	danceInterp::OutputMessage("ERROR:LoadPlugin: Cannot get handle on %s.", filename) ;
	danceInterp::OutputMessage("%s", dlerror()) ;
	return	NULL;
    }    
    plugInFactory proxyFactory = (plugInFactory) dlsym(handle, "Proxy");
    if (proxyFactory == NULL) {
	danceInterp::OutputMessage("ERROR: Cannot find Proxy in %s",
				filename) ;
	dlclose(handle);
	return (NULL);
    }
    
    PlugIn *proxy = proxyFactory();

	// remove all callbacks for the proxy AS 4/19/05
	dance::AllSimulators->removeAllCallbacks(proxy);
    

    return(proxy);
}


// Tests if given type is a plugin (dynamically loaded)
int PlugInManager::IsPlugin(char * type)
{
	std::map<std::string, PlugIn*>::iterator iter = m_proxies.find(type);
	if (iter == m_proxies.end())
		return 0;
	else
		return 1;
}
