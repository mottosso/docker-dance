/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "DMaterialManagerWindow.h"
#include "DMaterialManager.h"
#include "dance.h"
#include "ViewManager.h"

using namespace fltk;

DMaterialManagerWindow::DMaterialManagerWindow(int x, int y, int w, int h, const char* name) : Window(x, y, w, h, name)
{
	this->set_modal();

	this->begin();

	buttonSelect = new Button(10,  h - 40, 80, 20, "Select");
	buttonSelect->callback(select_cb, this);
	buttonCancel = new Button(w - 100, h  - 40, 80, 20, "Cancel");
	buttonCancel->callback(cancel_cb, this);
	buttonEdit = new Button(220, 20, 80, 20, "Edit");
	buttonEdit->callback(edit_cb, this);
	buttonCopy = new Button(220, 50, 80, 20, "Copy");
	buttonCopy->callback(copy_cb,this);
	buttonRemove = new Button(220, 80, 80, 20, "Remove");
	buttonRemove->callback(remove_cb, this);

	browserMaterials = new Browser(10, 20, 200, 200, "Materials");
	browserMaterials->callback(changematerial_cb, this);

	windowPreview = new MaterialPreviewWindow(220, 140, 150, 150, "Preview");

	this->end();

	setSelectMode(false);
	updateGUI();
}

DMaterialManagerWindow::~DMaterialManagerWindow()
{

}

void DMaterialManagerWindow::show()
{
	updateGUI();
	Window::show();
}

bool DMaterialManagerWindow::exec(const fltk::Window* parent, bool grab)
{
	updateGUI();
	return Window::exec(parent, grab);
}


Material* DMaterialManagerWindow::getSelected()
{
	return selectedMaterial;
}

void DMaterialManagerWindow::updateGUI()
{
	if (getSelectMode())
	{
		buttonSelect->activate();
	}
	else
	{
		buttonSelect->deactivate();
	}

	browserMaterials->clear();
	bool found = false;
	if (dance::MaterialManager != NULL)
	{
		int numMaterials = dance::MaterialManager->getNumMaterials();
		for (int x = 0; x < numMaterials; x++)
		{
			Material* m = dance::MaterialManager->getMaterialbyIndex(x);
			browserMaterials->add(m->getMaterialName());
			if (this->getSelected() != NULL && m == this->getSelected())
			{
				browserMaterials->select(x);
				windowPreview->setMaterial(m);
				windowPreview->redraw();
				found = true;
			}
		}
	}
	if (!found)
	{
		browserMaterials->select(0);
		if (dance::MaterialManager != NULL)
		{
			Material* m = dance::MaterialManager->getMaterialbyIndex(0);
			if (m != NULL)
			{
				windowPreview->setMaterial(m);
				windowPreview->redraw();
			}
		}
	}
}

void DMaterialManagerWindow::setSelectMode(bool val)
{
	selectMode = val;
}

bool DMaterialManagerWindow::getSelectMode()
{
	return selectMode;
}

void DMaterialManagerWindow::setSelected(Material* m)
{
	selectedMaterial = m;
}


void DMaterialManagerWindow::cancel_cb(fltk::Widget* widget, void* data)
{
	DMaterialManagerWindow* win = (DMaterialManagerWindow*) data;
	win->setSelected(NULL); 
	win->hide();
}

void DMaterialManagerWindow::select_cb(fltk::Widget* widget, void* data)
{
	DMaterialManagerWindow* win = (DMaterialManagerWindow*) data;
	
	int materialNum = win->browserMaterials->value();
	Material* m = dance::MaterialManager->getMaterialbyIndex(materialNum);

	win->setSelected(m); 

	win->hide();

	win->windowPreview->setMaterial(m);

	win->updateGUI();
	dance::AllViews->postRedisplay();
}

void DMaterialManagerWindow::changematerial_cb(fltk::Widget* widget, void* data)
{
	DMaterialManagerWindow* win = (DMaterialManagerWindow*) data;
	
	int materialNum = win->browserMaterials->value();
	Material* m = dance::MaterialManager->getMaterialbyIndex(materialNum);

	win->setSelected(m); 

	win->windowPreview->setMaterial(m);

	win->updateGUI();
}


void DMaterialManagerWindow::edit_cb(fltk::Widget* widget, void* data)
{
	DMaterialManagerWindow* win = (DMaterialManagerWindow*) data;
	
	int materialNum = win->browserMaterials->value();
	Material* m = dance::MaterialManager->getMaterialbyIndex(materialNum);

	// show the material editor
	dance::rootWindow->materialEditorWindow->setMaterial(m);
	dance::rootWindow->materialEditorWindow->exec();
	win->updateGUI();
	dance::AllViews->postRedisplay();
}

void DMaterialManagerWindow::copy_cb(fltk::Widget* widget, void* data)
{
	DMaterialManagerWindow* win = (DMaterialManagerWindow*) data;
	
	int materialNum = win->browserMaterials->value();
	Material* m = dance::MaterialManager->getMaterialbyIndex(materialNum);

	Material* m2 = new Material();
	m2->copy(m);

	std::string name = m->getMaterialName();
	name.append("1");
	m2->setMaterialName((char*) name.c_str());
	dance::MaterialManager->addMaterial(m2);
	win->updateGUI();
}

void DMaterialManagerWindow::remove_cb(fltk::Widget* widget, void* data)
{
	dance::AllViews->postRedisplay();
}

