#include "DConnection.h"
#include "DObject.h"

DConnection::DConnection()
{
}

DConnection::~DConnection()
{
}

DObject* DConnection::getFrom()
{
	return m_from;
}

void DConnection::setFrom(DObject* object)
{
	m_from = object;
}

DObject* DConnection::getTo()
{
	return m_to;
}

void DConnection::setTo(DObject* object)
{
	m_to = object;
}

void DConnection::setType(std::string type)
{
	m_type = type;
}

std::string DConnection::getType()
{
	return m_type;
}
	
