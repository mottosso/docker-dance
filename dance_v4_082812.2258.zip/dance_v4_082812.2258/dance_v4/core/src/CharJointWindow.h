#ifndef _CHARJOINTWINDOW_H
#define _CHARJOINTWINDOW_H

#include <fltk/Window.h>
#include <fltk/ScrollGroup.h>
#include "Character.h"

class DLLENTRY CharJointWindow : public fltk::ScrollGroup
{
public:
	CharJointWindow(CharJoint*, int,int,int,int,const char*);
	~CharJointWindow();

	CharJoint* charJoint;
};

#endif
