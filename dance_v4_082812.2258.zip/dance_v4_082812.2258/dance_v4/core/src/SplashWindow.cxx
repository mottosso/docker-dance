#include "SplashWindow.h"
#include <fltk/Group.h>
#include <fltk/Output.h>
#include <fltk/draw.h>
#include <sstream>

SplashWindow::SplashWindow(const char* splashImage, int x, int y, int w, int h, const char* name) 
					: fltk::Window(x, y, w, h, name)
{
	this->begin();

	fltk::Group* group = new fltk::Group(0, 0, w, h, "DANCE");
	// load the splash image
	if (splashImage)
	{
		image = fltk::jpegImage::get(splashImage);
		if (image)
		{
			group->image(image);
		}
		else
		{
			new fltk::Output(0, 0, w, h, "DANCE");
		}
	}
	else
	{
		new fltk::Output(0, 0, w, h, "DANCE");
	}

	okButton = new fltk::Button(w - 80, h - 30, 60, 20, "Ok");
	okButton->callback(hidesplash, this);
	this->end();

	this->setAutoHide(true);
	this->setAutoHideTime(3.0);
}

SplashWindow::~SplashWindow()
{
}

void SplashWindow::hidesplash(fltk::Widget* widget, void* data)
{
	SplashWindow* splash = (SplashWindow*) data;
	splash->hide();
}

void SplashWindow::draw()
{
	fltk::Window::draw();

	setcolor(fltk::BLACK);
	int curX = w() / 2;
	int curY = 50;
	int height = 10;
	for (unsigned int x = 0; x < info.size(); x++)
	{
		if (x == 0)
		{
			int width;
			fltk::measure(info[x].c_str(), width, height);
		}
		
		fltk::drawtext(info[x].c_str(), (float) curX, (float) curY);
		curY += height + 2;
	}
}

void SplashWindow::setInfo(std::vector<std::string> infoToWrite)
{
	info.clear();

	for (unsigned int x = 0; x < infoToWrite.size(); x++)
		info.push_back(infoToWrite[x]);
}

void SplashWindow::setAutoHide(bool val)
{
	autoHide = val;
	if (autoHide)
		okButton->hide();
	else
		okButton->show();
}

bool SplashWindow::isAutoHide()
{
	return autoHide;
}

void SplashWindow::setAutoHideTime(float seconds)
{
	autoHideTime = seconds;
}

float SplashWindow::getAutoHideTime()
{
	return autoHideTime;
}




