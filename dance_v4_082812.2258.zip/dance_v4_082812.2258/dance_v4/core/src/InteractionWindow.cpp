/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "InteractionWindow.h"
#include "dance.h"
#include <fltk/ask.h>
#include <fltk/Item.h>
#include <fltk/Font.h>
#include "Preference.h"

using namespace fltk;

InteractionWindow::InteractionWindow(int x, int y, int w, int h, const char* name) : Window(x, y, w, h, name)
{

	this->begin();

	browserObjects = new Browser(10, 25, 165, h-95, "Objects");
	browserObjects->align(ALIGN_LEFT | ALIGN_TOP);
	browserObjects->callback(ObjectSelectedCB, this);

	buttonAdd = new Button(185, 100, 30, 20, "@->");
	buttonAdd->callback(AddInteractionCB, this);
	
	buttonRemove = new Button(185, 150, 30, 20, "@<-");
	buttonRemove->callback(RemoveInteractionCB, this);
    
	browserInteractions = new Browser(225, 25, 165, h-95, "Interactions");
	browserInteractions->align(ALIGN_LEFT | ALIGN_TOP);
	browserInteractions->callback(InteractionSelectedCB, this);

	buttonClose = new Button(w-80, h-30, 70, 20, "Close");
	buttonClose->callback(CloseCB, this);

	this->end();

	this->set_modal();

	buttonAdd->deactivate();
	buttonRemove->activate();

	objectSelected[0] = '\0';
	interactionSelected[0] = '\0';
}

void InteractionWindow::show()
{
	this->updateGUI();
	Window::show();
}

void InteractionWindow::updateGUI()
{
	browserObjects->clear();
	browserInteractions->clear();

	// add all objects
	for (int x = 0; x < dance::AllGenericPlugins->size(); x++)
	{
		DObject* obj = dance::AllGenericPlugins->get(x);
		if (!dance::isInInteractStack(obj))
			browserObjects->add(dance::AllGenericPlugins->get(x)->getName());
	}

	for (int x = 0; x < dance::AllGeometry->size(); x++)
	{
		DObject* obj = dance::AllGeometry->get(x);
		if (!dance::isInInteractStack(obj))
			browserObjects->add(dance::AllGeometry->get(x)->getName());
	}

	for (int x = 0; x < dance::AllActuators->size(); x++)
	{
		DObject* obj = dance::AllActuators->get(x);
		if (!dance::isInInteractStack(obj))
			browserObjects->add(dance::AllActuators->get(x)->getName());
	}

	for (int x = 0; x < dance::AllLights->size(); x++)
	{
		DObject* obj = dance::AllLights->get(x);
		if (!dance::isInInteractStack(obj))
			browserObjects->add(dance::AllLights->get(x)->getName());
	}

	for (int x = 0; x < dance::AllModifiers->size(); x++)
	{
		DObject* obj = dance::AllModifiers->get(x);
		if (!dance::isInInteractStack(obj))
			browserObjects->add(dance::AllModifiers->get(x)->getName());
	}

	for (int x = 0; x < dance::AllSimulators->size(); x++)
	{
		DObject* obj = dance::AllSimulators->get(x);
		if (!dance::isInInteractStack(obj))
			browserObjects->add(dance::AllSimulators->get(x)->getName());
	}

	for (int x = 0; x < dance::AllSystems->size(); x++)
	{
		DObject* obj = dance::AllSystems->get(x);
		if (!dance::isInInteractStack(obj))
			browserObjects->add(dance::AllSystems->get(x)->getName());
	}

	for (int x = 0; x < dance::AllViews->size(); x++)
	{
		DObject* obj = dance::AllViews->get(x);
		if (!dance::isInInteractStack(obj))
			browserObjects->add(dance::AllViews->get(x)->getName());
	}

	for (int x = 0; x < dance::AllRenderers->size(); x++)
	{
		DObject* obj = dance::AllRenderers->get(x);
		if (!dance::isInInteractStack(obj))
			browserObjects->add(dance::AllRenderers->get(x)->getName());
	}

	// add all objects in the interact stack
	int numInteractions = dance::getNumInteractions();
	for (int x = numInteractions - 1; x >= 0; x--)
	{
		DObject* obj = dance::getInteraction(x);
		browserInteractions->add(obj->getName());
	}

	// reselect the proper widget
	if (strlen(objectSelected) > 0)
	{
		for (int x = 0; x < this->browserObjects->size(); x++)
		{
			const char* obj = this->browserObjects->child(x)->label();
			if (strcmp(obj, objectSelected) == 0)
			{
				this->browserObjects->select(x);
				break;
			}
		}

		buttonAdd->activate();
		buttonRemove->deactivate();
		browserInteractions->deselect();
	}
	else if (strlen(interactionSelected) > 0)
	{
		for (int x = 0; x < this->browserInteractions->size(); x++)
		{
			const char* obj = this->browserInteractions->child(x)->label();
			if (strcmp(obj, interactionSelected) == 0)
			{
				this->browserInteractions->select(x);
				break;
			}
		}
		buttonAdd->deactivate();
		buttonRemove->activate();
		browserObjects->deselect();
	}
	else
	{
		buttonAdd->deactivate();
		buttonRemove->deactivate();
		browserObjects->deselect();
		browserInteractions->deselect();
	}
}


void InteractionWindow::AddInteractionCB(fltk::Widget* o, void* p)
{
	InteractionWindow* win = (InteractionWindow*) p;

	// determine which object is selected
	int selected = win->browserObjects->value();
	if (selected > -1)
	{
		Widget* w = win->browserObjects->child(selected);
		DObject* obj = dance::getObject((char*) w->label());
		if (obj == NULL)
		{
			danceInterp::OutputMessage("No object with name '%s' found.", obj->getName());
		}
		else
		{
			dance::addInteraction(obj);
			strcpy(win->interactionSelected, obj->getName());
			win->objectSelected[0] = '\0';
		}
	}
	win->updateGUI();
}

void InteractionWindow::RemoveInteractionCB(fltk::Widget* o, void* p)
{
	InteractionWindow* win = (InteractionWindow*) p;

	// determine which interaction objects is selected
	int selected = win->browserInteractions->value();
	if (selected > -1)
	{
		Widget* w = win->browserInteractions->child(selected);
		DObject* obj = dance::getObject((char*) w->label());
		if (obj == NULL)
		{
			danceInterp::OutputMessage("No object with name '%s' found.", obj->getName());
		}
		else
		{
			dance::removeInteraction(obj);
			strcpy(win->objectSelected, obj->getName());
			win->interactionSelected[0] = '\0';
		}
	}
	win->updateGUI();
}

void InteractionWindow::CloseCB(fltk::Widget* o, void* p)
{
	InteractionWindow* win = (InteractionWindow*) p;

	Preference::setWindowPreference("dance.interactionwindow", win);
	dance::writePreferences();
	win->hide();
}

void InteractionWindow::ObjectSelectedCB(fltk::Widget* o, void* p)
{
	InteractionWindow* win = (InteractionWindow*) p;

	win->buttonAdd->activate();
	win->browserInteractions->deselect();
	win->buttonRemove->deactivate();
}

void InteractionWindow::InteractionSelectedCB(fltk::Widget* o, void* p)
{
	InteractionWindow* win = (InteractionWindow*) p;

	//int selected = win->browserInteractions->value();

	win->buttonRemove->activate();
	win->browserObjects->deselect();
	win->buttonAdd->deactivate();
}

