/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _TEXTURE_H_
#define _TEXTURE_H_

#include "defs.h"
#include <cstdio>
#include "opengl.h"

/*
Usage:
	(create/load texture)
	Texture* tex = new Texture("foo.bmp",true);

	(values can be any from the list at the end of the file)
	tex->ChangeSettings(GL_LINEAR,GL_LINEAR_MIPMAP_LINEAR,GL_REPEAT,GL_REPEAT,GL_MODULATE);
	
	(if you have more than one texture and you need to flip between them)
	tex->MakeCurrent(&TextureName);

	make calls using texture here...
*/

// Define the maximun size of a texture (if the image is greater, it will be scaled to this size)
#define MAX_TEXTURE_SIZE 512

class DLLENTRY Texture
{
public:
	Texture(){ fname=NULL; 	loaded=false; m_tex=0; initParameters(); }
	Texture(char* fname,	bool make_mipmaps=true);
	~Texture();

	// Sets the file name, but it is not really loaded until MakeCurrent is called
	int load(char *fname, bool make_mipmaps=true);

	void ChangeSettings(GLuint mag_filter, 
		GLuint min_filter,
		GLuint wrap_s,
		GLuint wrap_t,
		GLuint env_mode);

	// Loads the texture in the graphics card and/or selects it. Make sure it returns 0 before using the texture!!
	int MakeCurrent();

	void getSettings(GLuint *mag_filter, GLuint *min_filter=NULL,GLuint *wrap_s=NULL,
		GLuint *wrap_t=NULL, GLuint *env_mode=NULL);

	// Writes the object properties to the file in PovRay format
	int write_texture_povray(std::ofstream & file, const char* mapType = NULL, const char* transform = NULL);

	// Copies the path of the texture file name. Returns 0 if ok
	int getTextureFileName(char *dest);

	// Reads the texture properties from the file in PovRay format
	int read_texture_povray(std::ifstream & file, char *path);

	// Determines if the file provided can be used as a texture (it exists, it is readable
	// and it is one of the known formats)
	static int isFileAcceptable(char *file);

	GLuint getMTex();

private:

	GLuint m_tex;
	char *fname;
	GLuint mag_filter, min_filter, wrap_s, wrap_t, env_mode;
	char extension[4];   // in povray types
	bool make_mipmaps, loaded;

	void releaseTexture();

	int reallyLoad();
	
	void initParameters();

};

/*
 Parameters for ChangeSettings:
 mag_filter
    GL_LINEAR
	GL_NEAREST

 min_filter
	GL_LINEAR_MIPMAP_LINEAR
	GL_LINEAR_MIPMAP_NEAREST
	GL_LINEAR
	GL_NEAREST_MIPMAP_LINEAR
	GL_NEAREST_MIPMAP_NEAREST
	GL_NEAREST

 wrap_s
	GL_REPEAT
	GL_CLAMP
	
 wrap_t
	GL_REPEAT
	GL_CLAMP

 env_mode
	GL_BLEND
	GL_DECAL
	GL_MODULATE
	GL_REPLACE
*/

#endif

