/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/


#include "DanceWindow.h"

#include "dance.h"
#include "danceInterp.h"
#include "DLight.h"
#include "DObjectList.h"


//#include <GL/glu.h>
//#include "GLutilities.h"
#include "DActuator.h"
#include "ViewManager.h"
#include "Event.h"
#include "Preference.h"


bool InitSet = true;
int ycoord, ychange, xcoord, xchange, diff;

#define PI_ 3.14159265358979323846

// Static globals restricted to this file's scope.
// Better to leave them here, then in the physical interface as private
// static members.
static int InitMousePosition = 0; // Flag if mouse position is initialized.
static int PressedButtonID = 0 ; // glut mouse callaback doesn't return the button id.
				// so we use this to fill in event->buttonID




DanceWindow::DanceWindow(int x,int y,int w,int h,const char* s) : GlWindow(x, y, w, h, s)
{
	this->resizable(this);
	m_lastMode = -1;
	init();
	m_windowChanged = false;
	this->set_click_to_focus();
	m_pickMode = false;
}

DanceWindow::~DanceWindow()
{
}

void DanceWindow::init()
{
	// glShadeModel(GL_SMOOTH); // commented out by Petros 6/2/07, create bus error on a mac
	//glutInit(0, NULL);
}


int DanceWindow::handle(int eventType)
{
	Event event;
	if (dance::AllViews == NULL)
		return GlWindow::handle(eventType);

	DView* view = dance::AllViews->getViewFocus();
	event.setView(dance::AllViews->getViewFocus());
	event.setEventType(eventType);

	// check for an escape sequence first to avoid lockup
	if (eventType ==  fltk::KEY && fltk::event_key() == 27)
	{
		for (int x = 0; x < dance::AllViews->size(); x++)
			dance::AllViews->get(x)->setSelected(false);
 		for (int x = 0; x < dance::AllGeometry->size(); x++)
			dance::AllGeometry->get(x)->setSelected(false);
		for (int x = 0; x < dance::AllSimulators->size(); x++)
			dance::AllSimulators->get(x)->setSelected(false);
		for (int x = 0; x < dance::AllSystems->size(); x++)
			dance::AllSystems->get(x)->setSelected(false);
		for (int x = 0; x < dance::AllActuators->size(); x++)
			dance::AllActuators->get(x)->setSelected(false);
		for (int x = 0; x < dance::AllLights->size(); x++)
			dance::AllLights->get(x)->setSelected(false);
		for (int x = 0; x < dance::AllModifiers->size(); x++)
			dance::AllModifiers->get(x)->setSelected(false);
		for (int x = 0; x < dance::AllGenericPlugins->size(); x++)
			dance::AllGenericPlugins->get(x)->setSelected(false);
		for (int x = 0; x < dance::AllGenericPlugins->size(); x++)
			dance::AllRenderers->get(x)->setSelected(false);
		// enter command mode
		dance::AllViews->postRedisplay();
		return GlWindow::handle(eventType);
	}

	// handle the interactions with other selected DObjects
	for (int cur = dance::getNumInteractions() - 1; cur >= 0; cur--)
	{
		DObject* obj = dance::getInteraction(cur);
		int interactContinue = obj->interact(&event);
		if (interactContinue == -1)
			return eventType;
	}

	switch (eventType)
	{
		case fltk::KEYUP:
		case fltk::KEY:
		case fltk::SHORTCUT:
			KeyboardCB(eventType, fltk::event_key(), 0, 0);
			dance::Refresh();
			return 1;
			
			break;
		case  fltk::PUSH:
			m_lastX = fltk::event_x();
			m_lastY = fltk::event_y();
// HACK ! REMOVE WHEN DONE

if (view)	
{
	view->saveCurrentState(m_lastX, m_lastY);
}
			MouseCB(eventType, fltk::event_button(), fltk::event_key(), fltk::event_x(), fltk::event_y(), false);
			dance::Refresh();
			return 1;
//				redraw();
//				Fl::check();
			break;
		case  fltk::MOVE:
			break;
		case  fltk::DRAG:
			MotionCB(eventType, fltk::event_x(),fltk::event_y());
			dance::Refresh();
//				redraw();
//				Fl::check();
			// Removed by AS 12/22/04
			//PassiveMotionCB(Fl::event_x(),Fl::event_y());

//				redraw();
//				Fl::check();
			return 1;
			break;
		case  fltk::RELEASE:
 			MouseCB(eventType, fltk::event_button(), 1, fltk::event_x(), fltk::event_y(), true);
//				dance::MouseCB(Fl::event_button(),Fl::event_state(FL_RELEASE),Fl::event_x(),Fl::event_y());
			dance::Refresh();
			return 1;
			break;
		case fltk::FOCUS:
			return 1;
			break;
	}

	return GlWindow::handle(eventType);
}

uchar DanceWindow::type() const
{
	return DANCEWINDOWTYPE;
}

void DanceWindow::show()
{
	GlWindow::show();
}

void DanceWindow::layout()
{
	m_windowChanged = true;
	if (dance::AllViews != NULL)
	{
		int w = this->w();
		int h = this->h();
		if (!dance::AllViews->isQuadView()) // single view only
		{
			DView* view = dance::AllViews->getViewFocus();
			if (view == NULL)
				return;
			view->ReshapeCB(0, 0, w, h);
		}
		else // quad view, set up viewports for each window
		{
			for (int v = 0; v < 4; v++)
			{
				DView* view = dance::AllViews->getWindowAtLocation(v);
				if (view == NULL)
					continue;

				if (v == ViewManager::TOP_LEFT)
				{
					view->ReshapeCB(2, h / 2 + 2, w / 2 - 4, h / 2 - 4);
				}
				else if (v == ViewManager::TOP_RIGHT)
				{
					view->ReshapeCB(w / 2 + 2, h / 2 + 2, w / 2 - 4, h / 2 - 4);
				}
				if (v == ViewManager::BOTTOM_LEFT)
				{
					view->ReshapeCB(2, 2, w / 2 - 4, h / 2 - 4);
				}
				if (v == ViewManager::BOTTOM_RIGHT)
				{
					view->ReshapeCB(w / 2 + 2, 2, w / 2 - 4, h / 2 - 4);
				}
			}
		}
	}
	GlWindow::layout();
}



void DanceWindow::resize(int x, int y, int w, int h)
{

	this->x(x);
	this->y(y);
	this->w(w);
	this->h(h);

	if (!dance::AllViews->isQuadView()) // single view only
	{
		DView* view = dance::AllViews->getViewFocus();
		if (view == NULL)
			return;
		view->ReshapeCB(0, 0, w, h);
	}
	else // quad view, set up viewports for each window
	{
		for (int v = 0; v < 4; v++)
		{
			DView* view = dance::AllViews->getWindowAtLocation(v);
			if (view == NULL)
				continue;

			if (v == ViewManager::TOP_LEFT)
			{
				view->ReshapeCB(2, h / 2 + 2, w / 2 - 4, h / 2 - 4);
			}
			else if (v == ViewManager::TOP_RIGHT)
			{
				view->ReshapeCB(w / 2 + 2, h / 2 + 2, w / 2 - 4, h / 2 - 4);
			}
			if (v == ViewManager::BOTTOM_LEFT)
			{
				view->ReshapeCB(2, 2, w / 2 - 4, h / 2 - 4);
			}
			if (v == ViewManager::BOTTOM_RIGHT)
			{
				view->ReshapeCB(w / 2 + 2, 2, w / 2 - 4, h / 2 - 4);
			}
		}
	}

	GlWindow::resize(x, y, w, h);

}
//Textures
GLuint shadowMapTexture;

//window size
int windowWidth, windowHeight;
float cameraProjectionMatrix[16];
float cameraViewMatrix[16];
float lightViewMatrix[16];
float lightProjectionMatrix[16];
float cameraPosition[3] = {-2.5f, 3.5f,-2.5f};

// this function is used to test the shadow maps
void DrawScene(float angle)
{
	//Display lists for objects
	static GLuint spheresList=0, torusList=0, baseList=0;

	//Create spheres list if necessary
	if(!spheresList)
	{
		spheresList=glGenLists(1);
		glNewList(spheresList, GL_COMPILE);
		{
			glColor3f(0.0f, 1.0f, 0.0f);
			glPushMatrix();

			glTranslatef(0.45f, 1.0f, 0.45f);
			glutSolidSphere(0.2, 24, 24);

			glTranslatef(-0.9f, 0.0f, 0.0f);
			glutSolidSphere(0.2, 24, 24);

			glTranslatef(0.0f, 0.0f,-0.9f);
			glutSolidSphere(0.2, 24, 24);

			glTranslatef(0.9f, 0.0f, 0.0f);
			glutSolidSphere(0.2, 24, 24);

			glPopMatrix();
		}
		glEndList();
	}

	//Create torus if necessary
	if(!torusList)
	{
		torusList=glGenLists(1);
		glNewList(torusList, GL_COMPILE);
		{
			glColor3f(1.0f, 0.0f, 0.0f);
			glPushMatrix();

			glTranslatef(0.0f, 0.5f, 0.0f);
			glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
			glutSolidTorus(0.2, 0.5, 24, 48);

			glPopMatrix();
		}
		glEndList();
	}

	//Create base if necessary
	if(!baseList)
	{
		baseList=glGenLists(1);
		glNewList(baseList, GL_COMPILE);
		{
			glColor3f(0.0f, 0.0f, 1.0f);
			glPushMatrix();

			glScalef(1.0f, 0.05f, 1.0f);
			glutSolidCube(3.0f);

			glPopMatrix();
		}
		glEndList();
	}


	//Draw objects
	glCallList(baseList);
	glCallList(torusList);
	
	glPushMatrix();
	glRotatef(angle, 0.0f, 1.0f, 0.0f);
	glCallList(spheresList);
	glPopMatrix();
}

bool Init(void)
{
	/***
	if(extgl_Initialize()!=0)
	{
		danceInterp::OutputMessage("Unable to Initialise extgl\n");
		return false;
	}
	//Check for necessary extensions
	if(!extgl_Extensions.ARB_depth_texture || !extgl_Extensions.ARB_shadow)
	{
		danceInterp::OutputMessage("I require ARB_depth_texture and ARB_shadow extensionsn\n");
		return false;
	}
	
**/
	
	//Load identity modelview
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//Shading states
	glShadeModel(GL_SMOOTH);
	glClearColor((GLclampf) .7, (GLclampf) .7, (GLclampf) .7, (GLclampf) 1.0);
	//glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	//Depth states
	glClearDepth(1.0f);
	glDepthFunc(GL_LEQUAL);
	glEnable(GL_DEPTH_TEST);

	glEnable(GL_CULL_FACE);

	//We use glScale when drawing the scene
	glEnable(GL_NORMALIZE);

	//Create the shadow map texture
	glGenTextures(1, &shadowMapTexture);
	glBindTexture(GL_TEXTURE_2D, shadowMapTexture);

	int shadowMapSize = 512;
	IntAttribute* attrMapSize = dynamic_cast<IntAttribute*>(dance::AllViews->getViewFocus()->getAttribute("shadowmapsize"));
	if (attrMapSize)
		shadowMapSize = attrMapSize->getValue();

	glTexImage2D(	GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, shadowMapSize, shadowMapSize, 0,
					GL_DEPTH_COMPONENT, GL_UNSIGNED_BYTE, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

	//Use the color as the ambient and diffuse material
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	glEnable(GL_COLOR_MATERIAL);
	
	//White specular material color, shininess 16
	GLfloat white[4] = {1.0f, 1.0f, 1.0f, 1.0f};
	glMaterialfv(GL_FRONT, GL_SPECULAR, white);
	glMaterialf(GL_FRONT, GL_SHININESS, 16.0f);

	//Calculate & save matrices
	glPushMatrix();
	
	glLoadIdentity();
	double fov = 45.0f;
	DoubleAttribute* attrFov = dynamic_cast<DoubleAttribute*>(dance::AllViews->getViewFocus()->getAttribute("fov"));
	if (attrFov)
		fov = attrFov->getValue();
	gluPerspective(fov, (float)windowWidth/windowHeight, 1.0f, 100.0f);
	glGetFloatv(GL_MODELVIEW_MATRIX, cameraProjectionMatrix);
	
	glLoadIdentity();
	double* cameraPos = dance::AllViews->getViewFocus()->getCamera();
	double* cameraTarget =  dance::AllViews->getViewFocus()->getTarget();
	Vec3Attribute* attrUp = dynamic_cast<Vec3Attribute*>(dance::AllViews->getViewFocus()->getAttribute("up"));
	Vector baseUp = {0, 1, 0};
	double* up = &baseUp[0];
	if (attrUp)
		up = attrUp->getValue();

	gluLookAt(cameraPos[0], cameraPos[1], cameraPos[2],
				cameraTarget[0], cameraTarget[1], cameraTarget[2],
				up[0], up[1], up[2]);
	glGetFloatv(GL_MODELVIEW_MATRIX, cameraViewMatrix);
	
	glLoadIdentity();
	gluPerspective(fov, 1.0f, 2.0f, 8.0f);
	glGetFloatv(GL_MODELVIEW_MATRIX, lightProjectionMatrix);
	
	glLoadIdentity();
	DLight* light = dynamic_cast<DLight*>(dance::AllLights->get(0));
	GLfloat lightPos[4];
	light->getPosition(lightPos);
	gluLookAt(	lightPos[0], lightPos[1], lightPos[2],
				cameraTarget[0], cameraTarget[1], cameraTarget[2],
				up[0], up[1], up[2]);
	glGetFloatv(GL_MODELVIEW_MATRIX, lightViewMatrix);
	
	glPopMatrix();


	return true;
}

void Display(void)
{
	//angle of spheres in scene. Calculate from time
	float angle= (dance::AllSimulators->getCurrentTime() * 1000.0);



	//First pass - from light's point of view
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glMatrixMode(GL_PROJECTION);
	glLoadMatrixf(lightProjectionMatrix);

	glMatrixMode(GL_MODELVIEW);
	glLoadMatrixf(lightViewMatrix);

	//Use viewport the same size as the shadow map
	int shadowMapSize = 512;
	IntAttribute* attrMapSize = dynamic_cast<IntAttribute*>(dance::AllViews->getViewFocus()->getAttribute("shadowmapsize"));
	if (attrMapSize)
		shadowMapSize = attrMapSize->getValue();
	glViewport(0, 0, shadowMapSize, shadowMapSize);

	//Draw back faces into the shadow map
	glCullFace(GL_FRONT);

	//Disable color writes, and use flat shading for speed
	glShadeModel(GL_FLAT);
	glColorMask(0, 0, 0, 0);
	
	//Draw the scene
	//DrawScene(angle);
	dance::AllViews->getViewFocus()->drawObjects(LDISPLAY_SOLID | LDISPLAY_COMPUTE_SHADOW_MAP);
	//Read the depth buffer into the shadow map texture
	glBindTexture(GL_TEXTURE_2D, shadowMapTexture);
	glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, shadowMapSize, shadowMapSize);

	//restore states
	glCullFace(GL_BACK);
	glShadeModel(GL_SMOOTH);
	glColorMask(1, 1, 1, 1);
	

	

	//2nd pass - Draw from camera's point of view
	glClear(GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadMatrixf(cameraProjectionMatrix);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadMatrixf(cameraViewMatrix);

	glViewport(0, 0, windowWidth, windowHeight);

	//Use dim light to represent shadowed areas
	GLfloat whitepoint2[4] = {.2f, .2f, .2f, .2f};
	GLfloat white[4] = {1.0f, 1.0f, 1.0f, 1.0f};
	GLfloat black[4] = {.0f, .0f, .0f, 0.0f};
	DLight* light = dynamic_cast<DLight*>(dance::AllLights->get(0));
	GLfloat lightPos[4];
	light->getPosition(lightPos);
	glLightfv(GL_LIGHT1, GL_POSITION, lightPos);
	glLightfv(GL_LIGHT1, GL_AMBIENT, whitepoint2);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, whitepoint2);
	glLightfv(GL_LIGHT1, GL_SPECULAR, black);
	glEnable(GL_LIGHT1);
	glEnable(GL_LIGHTING);

	//DrawScene(angle);
	dance::AllViews->getViewFocus()->drawObjects(LDISPLAY_SOLID | LDISPLAY_COMPUTE_SHADOW_MAP);
	


	//3rd pass
	//Draw with bright light
	glLightfv(GL_LIGHT1, GL_DIFFUSE, white);
	glLightfv(GL_LIGHT1, GL_SPECULAR, white);

	//Calculate texture matrix for projection
	//This matrix takes us from eye space to the light's clip space
	//It is postmultiplied by the inverse of the current view matrix when specifying texgen
	/*
	static MATRIX4X4 biasMatrix(0.5f, 0.0f, 0.0f, 0.0f,
								0.0f, 0.5f, 0.0f, 0.0f,
								0.0f, 0.0f, 0.5f, 0.0f,
								0.5f, 0.5f, 0.5f, 1.0f);	//bias from [-1, 1] to [0, 1]
	MATRIX4X4 textureMatrix=biasMatrix*lightProjectionMatrix*lightViewMatrix;
	*/
	float  biasMatrix[4][4] = { {0.5f, 0.0f, 0.0f, 0.0f},
								{0.0f, 0.5f, 0.0f, 0.0f},
								{0.0f, 0.0f, 0.5f, 0.0f},
								{0.5f, 0.5f, 0.5f, 1.0f}};	//bias from [-1, 1] to [0, 1]
	
	//textureMatrix=biasMatrix*lightProjectionMatrix*lightViewMatrix;
	float textureMatrix[4][4] ;
	float biasMatrixTimesLightProjectionMatrix[4][4] ;

	//multArray(&biasMatrixTimesLightProjectionMatrix[0][0], &biasMatrix[0][0], m_lightProjectionMatrix,4,4,4) ;
	//multArray(&textureMatrix[0][0], &biasMatrixTimesLightProjectionMatrix[0][0],m_lightViewMatrix, 4,4,4) ;
	
	multArrayf(&biasMatrixTimesLightProjectionMatrix[0][0], lightProjectionMatrix, &biasMatrix[0][0],4,4,4) ;
	multArrayf(&textureMatrix[0][0], lightViewMatrix, &biasMatrixTimesLightProjectionMatrix[0][0], 4,4,4) ;
	


	//Set up texture coordinate generation.
	double row[4] ;
	//Set up texture coordinate generation.
	for( int i = 0 ; i < 4 ; i++ )
	{
		row[i] = textureMatrix[i][0] ;
	}
	
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexGendv(GL_S, GL_EYE_PLANE, row); // row 0
	glEnable(GL_TEXTURE_GEN_S);

	for( int i = 0 ; i < 4 ; i++ )
	{
		row[i] = textureMatrix[i][1] ;
	}
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexGendv(GL_T, GL_EYE_PLANE, row); // row 1
	glEnable(GL_TEXTURE_GEN_T);

	for( int i = 0 ; i < 4 ; i++ )
	{
		row[i] = textureMatrix[i][2] ;
	}
	glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexGendv(GL_R, GL_EYE_PLANE, row); // row 2
	glEnable(GL_TEXTURE_GEN_R);

	for( int i = 0 ; i < 4 ; i++ )
	{
		row[i] = textureMatrix[i][3] ;
	}
	glTexGeni(GL_Q, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexGendv(GL_Q, GL_EYE_PLANE, row); // row 3
	glEnable(GL_TEXTURE_GEN_Q);

	//Bind & enable shadow map texture
	glBindTexture(GL_TEXTURE_2D, shadowMapTexture);
	glEnable(GL_TEXTURE_2D);

	//Enable shadow comparison
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_R_TO_TEXTURE);

	//Shadow comparison should be true (ie not in shadow) if r<=texture
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);

	//Shadow comparison should generate an INTENSITY result
	glTexParameteri(GL_TEXTURE_2D, GL_DEPTH_TEXTURE_MODE, GL_INTENSITY);

	//Set alpha test to discard false comparisons
	glAlphaFunc(GL_GEQUAL, 0.99f);
	glEnable(GL_ALPHA_TEST);

	//DrawScene(angle);
	dance::AllViews->getViewFocus()->drawObjects(LDISPLAY_SOLID);
	
	//Disable textures and texgen
	glDisable(GL_TEXTURE_2D);

	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_TEXTURE_GEN_R);
	glDisable(GL_TEXTURE_GEN_Q);

	//Restore other states
	glDisable(GL_LIGHTING);
	glDisable(GL_ALPHA_TEST);



	//Update frames per second counter
	//fpsCounter.Update();

	//Print fps
//	static char fpsString[32];
//	sprintf(fpsString, "%.2f", fpsCounter.GetFps());
	
	//Set matrices for ortho
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(-1.0f, 1.0f, -1.0f, 1.0f);

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	//Print text
/*	glRasterPos2f(-1.0f, 0.9f);
	for(unsigned int i=0; i<strlen(fpsString); ++i)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, fpsString[i]);
*/
	//reset matrices
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();

	// show the grid
	if (dance::AllViews->getViewFocus()->showGrid())
	{
		glCallList(dance::AllViews->getViewFocus()->GridList);
	}

	glFinish();
}
void DanceWindow::draw()
{	
	GLint renderMode[1];
	glGetIntegerv(GL_RENDER_MODE, &renderMode[0]);
	
	if (renderMode[0] == GL_RENDER)
	{
		static bool once = false;

		if (dance::AllViews->getViewFocus() && dance::AllViews->getViewFocus()->isShadows())
		{
			
			if (!once || dance::AllViews->getViewFocus()->getNeedsReset())
			{
				windowWidth=this->w(), windowHeight=this->h();
				glPushMatrix();
				glLoadIdentity();
				double fov = 45.0f;
				DoubleAttribute* attrFov = dynamic_cast<DoubleAttribute*>(dance::AllViews->getViewFocus()->getAttribute("fov"));
				if (attrFov)
					fov = attrFov->getValue();
				gluPerspective(fov, (float)windowWidth/windowHeight, 1.0f, 100.0f);
				glGetFloatv(GL_MODELVIEW_MATRIX, cameraProjectionMatrix);
				glPopMatrix();

				//Init();

				once = true;
			}
			Init();
			Display();
			dance::CheckError("Display callback") ;
			return;
		}
		else
		{
			once = false;
		}
	}




	// if the window is iconized do not attempt to draw
	if( dance::rootWindow->iconic() == true || 
		!dance::rootWindow->visible())
		return ;

	if (dance::AllViews->currentView &&
		dance::AllViews->currentView->isShowStats())
		dance::AllViews->currentView->showStats();



	int counter = 0;
	int currentMode;
	bool scissorEnabled = false;

	bool moveMode = false;

	int v = 0;
 	if (!dance::AllViews->isQuadView())
	{
		v = dance::AllViews->getActiveLocation();
		currentMode = v;
	}
	else
	{
		currentMode = 0;
		if (dance::AllViews->getViewFocus()->getMode() != DView::MODE_NONE)
		{
			v = dance::AllViews->getActiveLocation();
			moveMode = true;
		}
	}
	v = 0;

	while (v == 0) //if (true) //while (v < 4 && v != -1)
	{
		DView* view = dance::AllViews->getViewFocus(); //(DView*) dance::AllViews->get(v); //getWindowAtLocation(v);
		if (view == NULL) // if we have < 4 views, ignore the parts of the screen that have no views
		{
			v++;
			continue;
		}
		if (view->isChanged())
		{
			view->setChanged(false);
		}
		//		else
		//		{
		//			v++;
		//			continue;
		//		}
		if (counter == 0) // clear the screen before we draw into the first viewport
		{

			if (!moveMode)
				glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

			if (dance::AllViews->isQuadView()) // if quadview, draw the crosshairs & focus
			{
				if (!moveMode)
				{
					glViewport(0, 0, w(), h());
					glMatrixMode(GL_PROJECTION);
					glLoadIdentity();
					gluOrtho2D(0, w(), 0, h());

					glMatrixMode(GL_MODELVIEW);
					glLoadIdentity();

					glPushAttrib(GL_LIGHTING_BIT | GL_COLOR_BUFFER_BIT);
					glDisable(GL_LIGHTING);
					// draw the crosshairs
					glColor3f(1.0, 1.0, 1.0);
					glBegin(GL_LINES);
					glVertex2f((GLfloat)0.0, (GLfloat)(h() / (GLfloat)(2)));
					glVertex2f((GLfloat)w(), (GLfloat)(h() / (GLfloat)(2)));
					glVertex2f((GLfloat)(w() / (GLfloat)(2)), (GLfloat)0.0);
					glVertex2f((GLfloat)(w() / (GLfloat)(2)), (GLfloat)h());
					glEnd();

					// draw the view focus
					GLfloat leftX = 0.0;
					GLfloat rightX = 0.0;
					GLfloat topY = 0.0;
					GLfloat bottomY = 0.0;				

					if (dance::AllViews->getActiveLocation() == dance::AllViews->TOP_LEFT)
					{
						leftX = 1.0;
						rightX = (GLfloat)((GLfloat)w() / (GLfloat)2 - (GLfloat)(1.0));
						topY = (GLfloat)((GLfloat)h() - (GLfloat)1.0);
						bottomY = (GLfloat)((GLfloat)h() / (GLfloat)2 + (GLfloat)1);
					}
					else if (dance::AllViews->getActiveLocation() == dance::AllViews->TOP_RIGHT)
					{
						leftX = (GLfloat)((GLfloat)w() / (GLfloat)2 + (GLfloat)1.0);
						rightX = (GLfloat)((GLfloat)w() - (GLfloat)1.0);
						topY = (GLfloat)((GLfloat)h() - (GLfloat)1.0);
						bottomY = (GLfloat)((GLfloat)h() / (GLfloat)2 + (GLfloat)1);
					}
					else if (dance::AllViews->getActiveLocation() == dance::AllViews->BOTTOM_LEFT)
					{
						leftX = (GLfloat)1.0;
						rightX = (GLfloat)((GLfloat)w() / (GLfloat)2 - (GLfloat)1.0);
						topY = (GLfloat)((GLfloat)h() / (GLfloat)2 - (GLfloat)1.0);
						bottomY = (GLfloat)(1.0);
					}
					else if (dance::AllViews->getActiveLocation() == dance::AllViews->BOTTOM_RIGHT)
					{
						leftX = (GLfloat)((GLfloat)w() / (GLfloat)2 + (GLfloat)1.0);
						rightX = (GLfloat)((GLfloat)w() - (GLfloat)1.0);
						topY = (GLfloat)((GLfloat)h() / (GLfloat)2 - (GLfloat)1.0);
						bottomY = (GLfloat)(1.0);
					}
					// emphasis the window of focus by drawing a yellow border around that view
					// or a red focus if we are in selection mode
					glColor3f(1.0, 1.0, 0.0);
					glBegin(GL_LINE_LOOP);
					glVertex2f(leftX, topY);
					glVertex2f(rightX, topY);
					glVertex2f(rightX, bottomY);
					glVertex2f(leftX, bottomY);
					glVertex2f(leftX, bottomY);
					glEnd();
					glPopAttrib();

				}
			}

			glEnable(GL_DEPTH_TEST);
			if (dance::AllViews->isQuadView())
			{
				glEnable(GL_SCISSOR_TEST);
				scissorEnabled = true;
			}

		}

		for (int side = 0; side < 2; side++)
		{
			if (!view->getUseAnaglyph() && side == 1)
				break;
			 if (view->getUseAnaglyph() && side == 0)
			 {
				//glColorMask(GL_TRUE,GL_FALSE,GL_FALSE,GL_TRUE);	// left - red
				glColorMask(GL_FALSE,GL_TRUE,GL_FALSE,GL_TRUE);	// left - green
			 }
			 else if (view->getUseAnaglyph() && side == 1) 
			 {
				glClear(GL_DEPTH_BUFFER_BIT);
				//glColorMask(GL_FALSE,GL_FALSE,GL_TRUE,GL_TRUE); // right - blue
				glColorMask(GL_TRUE,GL_FALSE,GL_TRUE,GL_TRUE); // right - magenta
				//glColorMask(GL_TRUE,GL_FALSE,GL_FALSE,GL_TRUE); // right - red
				
			 }


			//		if (glIsEnabled(GL_LIGHTING))
			//			glDisable(GL_LIGHTING);
			counter++;	

			dance::AllViews->currentView = view;
			if (view->getNeedsReset() || m_windowChanged || currentMode == 0 || currentMode != m_lastMode) // don't reset the projection matrix if we haven't changed modes
			{
				glViewport(view->getX(), view->getY(), view->getWidth(), view->getHeight());
				if (dance::AllViews->isQuadView())
					glScissor(view->getX(), view->getY(), view->getWidth(), view->getHeight());
				if (moveMode)
					glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

				if (m_pickMode)
					view->pickProjection(m_pickX, m_pickY, 1, 1);
				else
					view->setProjection();
				m_windowChanged = false;
			}

			int mode = 0 ;
			view->draw(mode, side) ;
			if (view->getUseAnaglyph())
			{
				if (side == 1) // right eye
				{
					glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE); 
				}
			}
		} // end left/right anaglyph mode
	
		view->m_frameCount++;
		if (view->isShowStats())
			view->showStats();



		//		view->drawName();

		if (view->isDumped())
		{
			// obtain the current renderer
			DRenderer* renderer = dance::AllViews->getRenderer();
			if (renderer != NULL)
			{
				view->SaveFrame();
				
			}
			else
				danceInterp::OutputMessage("WARNING: No renderer present to render the view") ;
			v++ ;
		}

		/*if (!dance::AllViews->isQuadView())
		break;*/
		else if (moveMode)
			break;
		else
			v++;
	}
	dance::AllViews->currentView = NULL;
	if (scissorEnabled)
		glDisable(GL_SCISSOR_TEST);

	m_lastMode = currentMode;
	if (dance::AllViews->getNumViews() == 0)
	{
		glClearColor((GLclampf) .7, (GLclampf) .7, (GLclampf) .7, (GLclampf) 1.0);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	}

	dance::CheckError("Display callback") ;
}

void DanceWindow::KeyboardCB(int eventType, unsigned char key, int x, int y)
{
	DView* view = dance::AllViews->getViewFocus();
	if (view == NULL && key != 'h')
		return;

	BoundingBox* box;
	box = NULL;
    switch(key)
	{
	case ' ': // space bar - reset view
		view->resetCamera();
		view->PositionCamera();
		view->resetLights();
		dance::AllViews->postRedisplay();
		break;
	case 'f': // put all objects into focus
		dance::AllViews->FitView();
		dance::Refresh();
		/*
		box = dance::GetSceneBox();
		if (box == NULL)
		{
			BoundingBox box2;
			view->calcBoundingBox(&box2);
			box = &box2;
		}
		view->AttachCamera(box);
		view->resetLights();
		view->postRedisplay();
		*/
		break ;
	case 'g': // toggle grid
		if (view->showGrid())
            view->setGrid(false);
		else
            view->setGrid(true);
		view->resetLights();
		view->postRedisplay();
		break ;
	case 'h': // open selection window
		if (dance::rootWindow->selectionWindow->visible() && dance::rootWindow->selectionWindow->shown())
		{
			dance::rootWindow->selectionWindow->hide();
		}
		else
		{
			Preference::getWindowPreference("dance.selectionwindow", dance::rootWindow->selectionWindow);
			dance::rootWindow->selectionWindow->show();
		}
		break;

	//case 's': // enter selection mode
	//	dance::AppMode = selection_mode;
	//	danceInterp::OutputMessage("Entering selection mode...");
	//	m_pickX = -1; // reset picking coordinates
	//	m_pickY = -1;
	//	dance::AllViews->postRedisplay();
	//	break;
	//case 'w': // toggle quadview
	//	if (dance::AllViews->isQuadView())
	//		dance::AllViews->setQuadView(false);
	//	else
	//		dance::AllViews->setQuadView(true);
	//	view->resetLights();
	//	dance::AllViews->postRedisplay();
	//	break;
	case 'z': // zoom selected
		/*
		box = dance::GetSceneBox(true);
		if (box == NULL)
		{
			BoundingBox box2;
			view->calcBoundingBox(&box2);
			box = &box2;
		}
		view->resetLights();
		view->AttachCamera(box);
		view->postRedisplay();
		*/
		break ;
	}
	view->handleKeyboard(eventType, key, x, y);	

    return;	
}

// Callback for	mouse motion with button pressed.
void DanceWindow::MotionCB(int eventType, int x, int	y)
{
	int button = fltk::event_key();
	if (button == 0)
		return;

	DView* view = dance::AllViews->getViewFocus();
	if (view == NULL)
		return;

	if (dance::AllViews->isQuadView()) // set the view focus according to the proper quadrant
	{
		DView* newview = NULL;
		if (x < this->w() / 2) // left
		{
			if (y < this->h() / 2) // top
			{
				newview = dance::AllViews->getWindowAtLocation(ViewManager::TOP_LEFT);
				if (newview == NULL)
					return;
				x -= 2;
				y -= 2;
			}
			else // bottom
			{
				newview = dance::AllViews->getWindowAtLocation(ViewManager::BOTTOM_LEFT);
				if (newview == NULL)
					return;
				x -= 2;
				y -= newview->getHeight();
			}
		}
		else  // right
		{
			if (y < this->h() / 2) // top
			{
				newview = dance::AllViews->getWindowAtLocation(ViewManager::TOP_RIGHT);
				if (newview == NULL)
					return;
				x -= newview->getWidth();
				y -= 2;
			}
			else // bottom
			{
				newview = dance::AllViews->getWindowAtLocation(ViewManager::BOTTOM_RIGHT);
				if (newview == NULL)
					return;
				x -= newview->getWidth();
				y -= newview->getHeight();
			}
		}
		if (newview != NULL)
		{
			dance::AllViews->setViewFocus(newview);
		}
	}

	if ( y < 0 )
	{
	    // danceInterp::OutputMessage("y = %d", y) ;
	    return ;
	}
	if ( x < 0 )
	{
	    // danceInterp::OutputMessage("x = %d", x) ;
	    return ;
	}

	// Calculate differentials of mouse position.
	static int oldx, oldy;
	if (InitMousePosition) {
	     oldx = x; oldy = y;
	     InitMousePosition = 0;
	}
	int diffx = x -	oldx;
	int diffy = y -	oldy;
	oldx = x; oldy = y;

	// Get window parameters.

	int width, height;
	view->getSize(width, height);
	view->getWorldCoords(dance::CursorPosn, x, y);
	
	// the diffx, diffy values correspond to differences between mouse callback times
	view->handleCameraMotions(eventType, x, y, width, height, diffx, diffy);
	// use the following to track the mouse difference from the original click location
//	view->handleCameraMotions(eventType, x, y, width, height, x - m_lastX, y - m_lastY);
	
	if (dance::FitviewAlways == TRUE)
		dance::AllViews->FitView();


}

void DanceWindow::MouseCB(int eventType, int button, int state, int x, int y, bool released)
{
	bool alt = (fltk::get_key_state(fltk::LeftAltKey) || fltk::get_key_state(fltk::RightAltKey));
				
	if (!alt)
	{
		if (!released)
		  return;
		bool shift = (fltk::get_key_state(fltk::LeftShiftKey) || fltk::get_key_state(fltk::RightShiftKey));
	   m_pickMode = true;
	   GLuint selectBuffer[512];
	   GLint hits;
	   glSelectBuffer(512, selectBuffer);
	   glRenderMode(GL_SELECT);
	   glInitNames();
	   m_pickX = x;
	   m_pickY = y;
	   // call 'draw' with pick coordinates set, which will force drawing to the select buffer
	   m_lastMode = -1;
	   double near;
	   double far;
	   dance::AllViews->getViewFocus()->getNearFar(&near, &far);
	   dance::AllViews->getViewFocus()->pickProjection(m_pickX, m_pickY, near, far);
	   this->draw();
	   hits = glRenderMode(GL_RENDER);
	   // which object was hit
	   std::set<DObject*> existingSelections;
	   std::map<std::string, DObject*>& selections = dance::selectionManager->getSelectedObjects();
	   for (std::map<std::string, DObject*>::iterator iter = selections.begin();
			iter != selections.end();
			iter++)
	   {
		   existingSelections.insert((*iter).second);
	   }
		std::set<DObject*> currentSelections;
	   if (hits == 0)
	   {
		   //danceInterp::OutputMessage("No hits");
	   }
	   else
	   {
		   int numHit = 0;
		   int current = 0;
		   DObject* closestObject = NULL;
		   int leastDistance = std::numeric_limits<int>::max();
		   for (int h = 0; h < hits; h++)
		   {
			   // find the location of the id picked
			   int numNames = selectBuffer[current];
			   current += 3;
			   if (numNames > 0)
			   {
				   for (int n = 0; n < numNames; n++)
				   {
					   bool found = false;
					   for (int d = 0; d < 7; d++)
					   {
						   DObjectList* list = NULL;
						   switch (d)
						   {
						   case 0:
							   list = dance::AllGeometry;
							   break;
						   case 1:
							   list = dance::AllActuators;
							   break;
						   case 2:
							   list = dance::AllSystems;
							   break;
						   case 3:
							   list = dance::AllLights;
							   break;
						   case 4:
							   list = dance::AllModifiers;
							   break;
						   case 5:
							   list = dance::AllSimulators;
							   break;
						   case 6:
							   list = dance::AllGenericPlugins;
							   break;

						   }
							// select only the first objects hit
							for (int g = 0; g < list->size(); g++)
							{
								// select the object hit
								DObject* danceObj = list->get(g);
								if (danceObj->getID() == selectBuffer[current])
								{
									int curDist = selectBuffer[current + 1];
									if (curDist < leastDistance)
									{
										closestObject = danceObj;
										leastDistance = curDist;
									}
									std::set<DObject*>::iterator iter = existingSelections.find(danceObj);
									if (iter != existingSelections.end())
										danceObj->setSelected(false);
									else
										danceObj->setSelected(true);
									currentSelections.insert(danceObj);		    
									danceInterp::OutputMessage("Hit: %s %d", danceObj->getName(), curDist);

									found = true;
									numHit++;
									break;
								}
							}
							if (found)
								break;
					   }

				   }
			   }
			}
		   if (closestObject)
		   {
			
			   danceInterp::OutputMessage("Closest Object was %s", closestObject->getName());
		   }
	   }
	   if (!shift)
	   { // deselect any objects that were not explicitly deselected
		   for (std::set<DObject*>::iterator iter = existingSelections.begin();
			   iter != existingSelections.end();
			   iter++)
		   {
			   std::set<DObject*>::iterator iter2 = currentSelections.find(*iter);
				if (iter2 == currentSelections.end())
					(*iter)->setSelected(false);
		   }
	   }
	   m_lastMode = -1;
	   m_pickMode = false;
	   dance::AllViews->postRedisplay();
	   return;
	}
	if (true)
	{
		if (button == 1 || button == 2 || button == 3)
		{ 
			InitMousePosition =	1;
			if (dance::AllViews->isQuadView()) // set the view focus according to the proper quadrant
			{
				DView* newview = NULL;
				if (x < this->w() / 2) // left
				{
					if (y < this->h() / 2) // top
					{
						newview = dance::AllViews->getWindowAtLocation(ViewManager::TOP_LEFT);
						if (newview == NULL)
							return;

						x -= 2;
						y -= 2;
					}
					else // bottom
					{
						newview = dance::AllViews->getWindowAtLocation(ViewManager::BOTTOM_LEFT);
						if (newview == NULL)
							return;
						x -= 2;
						y -= newview->getHeight();
					}
				}
				else  // right
				{
					if (y < this->h() / 2) // top
					{
						newview = dance::AllViews->getWindowAtLocation(ViewManager::TOP_RIGHT);
						if (newview == NULL)
							return;
						x -= newview->getWidth();
						y -= 2;
					}
					else // bottom
					{
						newview = dance::AllViews->getWindowAtLocation(ViewManager::BOTTOM_RIGHT);
						if (newview == NULL)
							return;
						x -= newview->getWidth();
						y -= newview->getHeight();
					}
				}
				if (newview != NULL)
				{
					dance::AllViews->setViewFocus(newview);
				}
			}
		}
	}

	DView* view = dance::AllViews->getViewFocus();
	if (view == NULL)
		return;

	// set the pressed button id
    PressedButtonID = button ;
    if ( x < 0 || y < 0 )
	{
	    // danceInterp::OutputMessage("x,y = %d, %d", x, y) ;
	    return ;
	}

	int width,height;

	view->getSize(width, height);
	Event event;
	event.setWindow(view, x, y, width, height);
	event.setButtons(button,state);

	static int item[256];
	item[0]	= -1;

	view->handleCameraButtons(eventType, button, state, x, y, width, height);
		
	view->postRedisplay() ;
}


void DanceWindow::resetAllLights()
{
	DView* view = dance::AllViews->getViewFocus();
	if (view != NULL)
	if (view != NULL)
	{
		view->PositionCamera();
		view->resetLights();
	}
}



