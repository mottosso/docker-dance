/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/



#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <string>
#include <vector>
#include <fstream>
#include "dance.h"
#include <fltk/PackedGroup.h>
#include <fltk/file_chooser.h>
#include <fltk/ask.h>
#include <fltk/Font.h>
#include "CommandWindow.h"
#include "DSimulator.h"
#include "danceInterp.h"
#include "DModifier.h"
#include "DActuator.h"
#include "DSystem.h" 
#include "DLight.h"
#include "DView.h"
#include "DGeometry.h"
#include "ViewManager.h"
#include "PlugInManager.h"
#include "DSimulatorManager.h"
#include "DConnectionManager.h"
//#include "GLutilities.h"
#include <fltk/filename.h>
#include <ctime>
#include "stuff.h"
#include "Preference.h"
#ifdef WIN32
#include <direct.h>
#endif

 //extern fltk::NamedStyle* group_style;

//#include "jitter.h" // edit by abingcao

unsigned long getImageMagickQuantumDepth(void);

#ifdef WIN32
#include <process.h> // for getpid()
#else
#include <unistd.h>
#include <sys/time.h>
#endif

using namespace fltk;
using namespace std;

enum MenuChoices {
	eConstraintPickObj1,
	eConstraintPickObj2,
	eConstraintPickPoint,
	eConstraintSet,
	eConstraintQuit,
};

char dance::initScript[1024];

bool dance::NoOutput = false ;
int dance::numDanceLists = 0;
DObjectList	**dance::DanceLists = NULL;
DObjectList	*dance::AllActuators = NULL;
DObjectList	*dance::AllSystems = NULL;
DObjectList	*dance::AllLights = NULL;
DObjectList	*dance::AllGeometry = NULL;
DObjectList	*dance::AllModifiers = NULL;
DObjectList	*dance::AllGenericPlugins = NULL;
DRendererManager* dance::AllRenderers = NULL;
PlugInManager *dance::AllPlugIns = NULL;
ViewManager *dance::AllViews = NULL;
DSimulatorManager *dance::AllSimulators = NULL;
DMaterialManager* dance::MaterialManager = NULL;
string dance::saveDir = "";
string dance::tempDir = "";
string dance::danceDir = "";
EventManager* dance::eventManager = NULL;
DConnectionManager* dance::connectionManager = NULL;
DSelectionManager* dance::selectionManager = NULL;

RootWindow* dance::rootWindow = NULL;

float dance::shadowAlpha = 0.7f ;

int dance::FitviewAlways = FALSE;
std::vector<DObject*> dance::interactStack;

double dance::CursorPosn[3] = { 0,0,0} ;

void dance::CheckError(const char *mes)
{
	const GLubyte *errString ;
	GLenum errCode ;
	if((errCode = glGetError()) != GL_NO_ERROR) {
		errString = gluErrorString(errCode) ;
 		danceInterp::OutputMessage("%s ------------- Open gl error: %s, %d",mes, errString, errCode) ;
	}
}

// getInstance:
//
DObject *dance::getInstance(
				char *type, char *name,	int argc, char **argv)
{
	// make sure that the name doesn't already exist
	DObject* existing = dance::getObject(name);
	if (existing)
		return NULL;

	DObject *obj =	NULL;
	if	(strcmp(type,"light") == 0)
	{
		obj = new DLight(name, argc, argv);
		dance::rootWindow->danceWindow->resetAllLights();
	}
	else if (strcmp(type,"view") == 0)
	{	
		obj	= AllViews->createView( name, argc, argv);
		if (obj != NULL)
		{
			DView *view = (DView *)obj;
			AllViews->setViewFocus(view);
			// focus the window
			BoundingBox* box = dance::GetSceneBox();
			if (box == NULL)
			{
				BoundingBox box2;
				view->calcBoundingBox(&box2);
				box = &box2;
			}
			view->AttachCamera(box);
			// reset the lights
			dance::rootWindow->danceWindow->resetAllLights();
			view->postRedisplay();
		}
	}

	AllViews->postRedisplay();

	//	set the	name! This is important!
	if( obj !=	NULL )
		obj->setName(name) ;

	return(obj);
}

// getLists:
//	Returns	list of	lists of dance objects.
//
void dance::getLists(int *number, DObjectList ***lists)
{
	*number	= numDanceLists;
	*lists = DanceLists;
}

DObjectList	*dance::getList(const char *listname)
{
	if (strcmp(listname,"actuator")	== 0) return (AllActuators);
	if (strcmp(listname,"system") == 0) return (AllSystems);
	if (strcmp(listname,"light") ==	0) return (AllLights);
	if (strcmp(listname,"geometry")	== 0) return (AllGeometry);
	if (strcmp(listname,"simulator") == 0) return (AllSimulators);
	if (strcmp(listname,"view")	== 0) return (AllViews);
	if (strcmp(listname,"modifier")	== 0) return (AllModifiers);
	if (strcmp(listname,"generic")	== 0) return (AllGenericPlugins);
	if (strcmp(listname,"renderer")	== 0) return (AllRenderers);

	return (NULL);
}

// change the FLTK theme defaults
// from http://www.mail-archive.com/fltk@easysw.com/msg02002.html
bool my_theme()
{
 // Reset to fltk's default theme
 fltk::reset_theme();

 // Change some widget's defaults
 int bgcolor = 0x43434300;
 int textcolor = 0xababab00;
 int selectioncolor = 0x97a8a800;
 int defaultSize = 10;
 int defaultLabelSize = 10;

 fltk::Style* style = fltk::Style::find( "Slider" );
 if ( style )
   {
    //style->color( bgcolor );
    //style->textcolor( textcolor );
    //style->buttoncolor( bgcolor );
    style->textsize( defaultSize );
    style->labelsize( defaultLabelSize );
    //style->labelcolor( textcolor );


    style->highlight_textcolor( 0xFFFF0000 );
   }

 // this is broken...
 style = fltk::Style::find( "Group" );
//    style = group_style;
 if ( style )
   {
    //style->color( bgcolor );
   // style->textcolor( textcolor );
    //style->buttoncolor( bgcolor );
    style->textsize( defaultSize );
    style->labelsize( defaultLabelSize );
    //style->labelcolor( textcolor );
   }

  style = fltk::Style::find( "Button" );
 if ( style )
   {
    //style->color( bgcolor );
    //style->textcolor( textcolor );
    //style->buttoncolor( bgcolor );
    style->textsize( defaultSize );
    style->labelsize( defaultLabelSize );
    //style->labelcolor( textcolor );
    //style->selection_color( selectioncolor );
   }

  style = fltk::Style::find( "Tabs" );
//    style = group_style;
 if ( style )
   {
    //style->color( bgcolor );
    //style->textcolor( textcolor );
    //style->buttoncolor( bgcolor );
    style->textsize( defaultSize );
    style->labelsize( defaultLabelSize );
    //style->labelcolor( textcolor );
   }

  style = fltk::Style::find( "Check_Button" );
//    style = group_style;
 if ( style )
   {
    //style->color( bgcolor );
    //style->textcolor( textcolor );
    //style->buttoncolor( bgcolor );
    style->textsize( defaultSize );
    style->labelsize( defaultLabelSize );
    //style->labelcolor( textcolor );
   }

   style = fltk::Style::find( "Collapsible_Group" );
//    style = group_style;
 if ( style )
   {
    //style->color( bgcolor );
    //style->textcolor( textcolor );
    //style->buttoncolor( bgcolor );
    style->textsize( defaultSize );
    style->labelsize( defaultLabelSize );
    //style->labelcolor( textcolor );
   }

    style = fltk::Style::find( "Choice" );
//    style = group_style;
 if ( style )
   {
    //style->color( bgcolor );
    //style->textcolor( textcolor );
    //style->buttoncolor( bgcolor );
    style->textsize( defaultSize );
    style->labelsize( defaultLabelSize );
    //style->labelcolor( textcolor );
   }

     style = fltk::Style::find( "Input" );
//    style = group_style;
 if ( style )
   {
    //style->color( bgcolor );
    //style->textcolor( textcolor );
    //style->buttoncolor( bgcolor );
    style->textsize( defaultSize );
    style->labelsize( defaultLabelSize );
    //style->labelcolor( textcolor );
   }

      style = fltk::Style::find( "Output" );
//    style = group_style;
 if ( style )
   {
    //style->color( bgcolor );
    //style->textcolor( textcolor );
    //style->buttoncolor( bgcolor );
    style->textsize( defaultSize );
    style->labelsize( defaultLabelSize );
    //style->labelcolor( textcolor );
   }

 style = fltk::Style::find( "Widget" );
 if ( style )
   {
    //style->color( bgcolor );
    //style->textcolor( textcolor );
    //style->buttoncolor( bgcolor );
    style->textsize( defaultSize );
    style->labelsize( defaultLabelSize );
    //style->labelcolor( textcolor );
    //style->selection_color( selectioncolor );
   }

 // change down box to draw a tad darker than default
 fltk::FrameBox* box;
 box = (fltk::FrameBox*) fltk::Symbol::find( "down_" );
 if ( box ) box->data(  "2HHOOAA" );


 return true;
}


void dance::initialize(int argc, char **argv)
{
	
#ifdef WIN32
    srand(getpid()) ;
    //srand(0);
#else
// initializes the random number generator
    struct timeval tp ;
    struct timezone tzp ;

    gettimeofday( &tp, &tzp) ;
        int seed = tp.tv_sec + getpid() ;
    srand48(seed) ;
        fprintf(stderr,"seed %d rand %lf\n", seed, drand48());
        
    //srand48(0);
      
#endif

	//fltk::visual(DOUBLE_BUFFER | DEPTH_BUFFER | STENCIL_BUFFER); 

	#ifdef WIN32
	int depth = getImageMagickQuantumDepth();
	if (depth != 8) {
		fltk::alert("DANCE will work best with the 8 bits per pixel version of ImageMagick. \nPlease, download and install the "\
			"file ImageMagick-6.X.X-Q8-windows-dll.exe (for windows) or the textures will not work properly (%d)");
	}	
	#endif
	//fltk::use_system_file_chooser(true);
//        int val = fltk::visual(fltk::DOUBLE_BUFFER | fltk::RGB_COLOR | fltk::DEPTH_BUFFER | fltk::STENCIL_BUFFER);
	int val = fltk::visual(fltk::DOUBLE_BUFFER | fltk::RGB_COLOR | fltk::DEPTH_BUFFER | fltk::ALPHA_BUFFER);
        //int val = fltk::visual(fltk::DOUBLE_BUFFER );
printf("%d", val);
        if (!val)
        {
                std::cout << "PROBLEM?" << std::endl;
        }

		fltk::theme( &my_theme );


	const char* dd = getenv("DANCE_DIR");
	
	if (dd != NULL)
	{
		dance::setDanceDir(dd);
	}
	else
	{
		std::string danceVar = "dance_v4";
		// extract the current working directory
		std::string binPath = argv[0];
		// find the dance_v4 directory
		unsigned int pos = binPath.rfind(danceVar);
		if (pos != std::string::npos)
		{
			int final = pos;
			// search for the entire folder (up to a '/' or '\')
			for (unsigned int i = pos + danceVar.size(); i < binPath.size(); i++)
			{
				if (binPath[i] == '/' || binPath[i] == '\\')
				{
					final = i;
					break;
				}
			}
			std::string implicitDanceDir = binPath.substr(0, final);
			dance::setDanceDir(implicitDanceDir.c_str());
		}
		else
		{
			// could not find the dance_v4 directory
			fltk::alert("Please set the DANCE_DIR environment variable\nto the location of your dance_v4 installation then restart the application.");
			exit(1);
		}
	}

	std::string danceDir = dance::getDanceDir();

	// load the user preferences
	dance::loadPreferences();
        // set the default font size
        fltk::Font** allfonts;
        int numFonts = fltk::list_fonts(allfonts);
        for (int x = 0; x < numFonts; x++)
                std::cout << allfonts[x]->name() << std::endl;

		
        //Font* myfont = fltk::font("Verdana");
        Font* myfont = fltk::font("fixed");
        if (myfont)
        {
                int fontSize = 8;
                fltk::setfont(myfont, fontSize);
                std::cout << "Set default font to " << myfont->name() << " at " << fontSize << std::endl;
        }

	fltk::use_system_file_chooser(true);
	rootWindow = new RootWindow(50, 50, 1024, 768, "DANCE");
	Preference::getWindowPreference("dance.rootwindow", rootWindow);
	Preference* winwidth = Preference::getPreference("dance.rootwindow.width");
	Preference* winheight= Preference::getPreference("dance.rootwindow.height");
	if (winwidth != NULL && winheight != NULL)
	{
		int rootw = atoi(winwidth->getValue());
		int rooth = atoi(winheight->getValue());
		rootWindow->resize(rootWindow->x(), rootWindow->y(), rootw, rooth);
	}

	rootWindow->show();

	// Initialize Dance lists.
	numDanceLists = 9;
	DanceLists = new DObjectList *[numDanceLists];
	// Order is important, some objects will not work without others 
	// already defined.
	DanceLists[0] =	AllViews = new ViewManager(argc,argv); AllViews->setType("view");
	DanceLists[1] =	AllLights = new	DObjectList; AllLights->setType("light");
	DanceLists[2] =	AllGeometry = new DObjectList; AllGeometry->setType("geometry");
	DanceLists[3] =	AllSystems = new DObjectList; AllSystems->setType("system");
	DanceLists[4] =	AllActuators = new DObjectList; AllActuators->setType("actuator");
	DanceLists[5] = AllSimulators = new DSimulatorManager; AllSimulators->setType("simulator");
	DanceLists[6] = AllGenericPlugins = new DObjectList; AllGenericPlugins->setType("generic");
	DanceLists[7] = AllModifiers = new DObjectList; AllModifiers->setType("modifier");
	DanceLists[8] = AllRenderers = new DRendererManager; AllRenderers->setType("renderer");
	AllPlugIns = new PlugInManager;	AllPlugIns->setType("plugin");

	dance::eventManager = new EventManager();

	dance::connectionManager = new DConnectionManager();
	dance::selectionManager = new DSelectionManager();

	danceInterp::Init(argc,argv);
	danceInterp::flush() ;

	MaterialManager = new DMaterialManager();
	char  stockfilename[MAXPATHLENGTH];
	
	strcpy(stockfilename, danceDir.c_str());
	
	strcat(stockfilename, STOCK_FILENAME);

	switch (MaterialManager->loadStock(stockfilename)) {
	case -2:
		danceInterp::OutputMessage("Material stock file not found. It should be in %s\n", stockfilename);
		break;
	case -1:
		danceInterp::OutputMessage("Material stock in %s corrupted\n", stockfilename);
		danceInterp::OutputMessage("%d stock materials read\n", MaterialManager->getNumMaterials());
		break;
	default:
		danceInterp::OutputMessage("%d stock materials read\n", MaterialManager->getNumMaterials());
	}

	dance::rootWindow->updateFileMenu();

	// update the current directory in case the interpreter changed it
	char dir[512] ;	
	danceInterp::getCurrentDirectory(dir) ;
	if (strcmp(dance::rootWindow->commandWindow->getCurrentDirectory(), dir) != 0)
	{
			dance::rootWindow->commandWindow->setCurrentDirectory(dir);
	}


	char scriptsDir[512];
	sprintf(scriptsDir, "%s/scripts/", dance::getDanceDir());

	reloadScripts(scriptsDir);
	danceInterp::OutputMessage("DANCE_DIR=%s", dance::getDanceDir());
	dance::rootWindow->simControlWindow->updateGUI();

	char filename[256];
	sprintf(filename,"%s/%s", dance::getDanceDir(), danceInterp::getProfileFile());
	strcpy(dance::initScript, filename);

	dance::rootWindow->danceWindow->show();

	while (true)
	{
		fltk::wait();
		if (dance::rootWindow->danceWindow->shown())
			break;
	}

	fltk::flush();

	// create a temporary work area if it doesn't already exist
	tempDir = dance::getDanceDir();
	tempDir.append("/tmp");
	if (!filename_isdir(tempDir.c_str()))
	{
#ifdef WIN32
		int mkdirSuccess = CreateDirectory(tempDir.c_str(), NULL);
		if (mkdirSuccess == 0)
        {
                danceInterp::OutputMessage("Failed to create work area directory '%s'. This might cause problems when saving files to temp area.", tempDir.c_str());
        }
#else
		char str[1024];
		sprintf(str, "mkdir %s", tempDir.c_str());
		int mkdirSuccess = system(str);
        if (mkdirSuccess != 0)
        {
                danceInterp::OutputMessage("Failed to create work area directory '%s'. This might cause problems when saving files to temp area.", str);
        }
#endif
	}

	loadProfile();
	danceInterp::getCurrentDirectory(dir) ;
	if (strcmp(dance::rootWindow->commandWindow->getCurrentDirectory(), dir) != 0)
	{
			dance::rootWindow->commandWindow->setCurrentDirectory(dir);
	}
	fltk::flush();
	dance::AllViews->postRedisplay();
	dance::rootWindow->commandWindow->show();


	if (argc > 1) // command line arguments are present
	{
		// check the file extension 
		char* extension = filename_ext(argv[1]);
		if (strcmp(extension, ".dpy") == 0) // dance session
		{
			dance::resetAll(); 
			danceInterp::load(argv[1]);
			danceInterp::flush();
		}
		else if (strcmp(extension, ".py") == 0) // dance script
		{
			danceInterp::load(argv[1]);
			danceInterp::flush();
		}
		else if( !strcmp( argv[1], "-o" ) && (argc == 3) )
		{
			FILE* file = freopen( argv[2], "w", stdout );
			if (!file) 
			{
				std::cout << "Could not open stdout for writing." << std::endl;
			}
			std::cout << "------- DANCE - cout STDOUT ------\n";
			fprintf( stdout, "------- DANCE - stdout STDOUT ------\n" );
		}
		else
		{
			danceInterp::OutputMessage("Could not recognize file extension of command line argument '%s'. Please include either a .dpy session or a .py script file.", argv[1]);
		}
	}
	fltk::run();

}

/**
 * Gets a bounding box for the entire scene.
 *
 * <full description>
 * @param void
 * @return BoundingBox *
 */
BoundingBox *dance::GetSceneBox(bool selected)
{
      static BoundingBox b; // Use static to allow returnable pointer.
	  b.MakeEmpty();

	  // Loop through systems.
	  int i;
	  for( i = 0 ; i < AllSystems->size() ;	i++ )
	  {
	      DSystem *obj = (DSystem *) AllSystems->get(i);
		  if (!selected || obj->isSelected())
		  {
			BoundingBox box;
			obj->calcBoundingBox(&box) ;
			b.merge(&b,&box);
		  }
	  }
	  
	  // Loop through actuators.
	  for (	i=0; i < AllActuators->size(); i++)
	  {
	      DActuator *wactuator	= (DActuator *)AllActuators->get(i);
		  if (!selected || wactuator->isSelected())
		  {
			BoundingBox box;
			if (wactuator->calcBoundingBox(&box))
				b.merge(&b,&box);
		  }
	  }

	  // Loop through geometry.
	  for (	i=0; i < AllGeometry->size(); i++)
	  {
	      DGeometry* wgeometry	= (DGeometry *) AllGeometry->get(i);
		  if (!selected || wgeometry->isSelected())
		  {
			BoundingBox box;
			if (wgeometry->calcBoundingBox(&box))
				b.merge(&b,&box);
		  }
	  }

	  // Loop through modifiers
	  for (	i=0; i < AllModifiers->size(); i++)
	  {
	      DModifier* modifier	= (DModifier*) AllModifiers->get(i);
		  if (!selected || modifier->isSelected())
		  {
			BoundingBox box;
			if (modifier->calcBoundingBox(&box))
				b.merge(&b,&box);
		  }
	  }
      
	  // Loop through simulators
	  for (	i=0; i < AllSimulators->size(); i++)
	  {
	      DSimulator* simulator	= (DSimulator*) AllSimulators->get(i);
		  if (!selected || simulator->isSelected())
		  {
			BoundingBox box;
			if (simulator->calcBoundingBox(&box))
				b.merge(&b,&box);
		  }
	  }

	  // Loop through generics
	  for (	i=0; i < dance::AllGenericPlugins->size(); i++)
	  {
	      PlugIn* plugin	= (PlugIn*) AllGenericPlugins->get(i);
		  if (!selected || plugin->isSelected())
		  {
			BoundingBox box;
			if (plugin->calcBoundingBox(&box))
				b.merge(&b,&box);
		  }
	  }

	  // Use the current view 
	  if (dance::AllViews->getViewFocus() != NULL)
	  {
			BoundingBox box;
			if (dance::AllViews->getViewFocus()->calcBoundingBox(&box))
				b.merge(&b,&box);
	  }

      // If bounding box is empty, do NOT attempt to change the viewing volume
      // to be an empty box. Instead, we return early (and keep the current viewing
      // volume.
      if (b.isEmpty())
		return NULL;
	  return (&b);
    
}

/*
// Initialize visual objects here.
//
// minx,miny,minz,
// maxx,maxy,maxz: Bounding box	of initial geometry.
static void initializeObjects(double *minx, double *miny, double *minz,
			      double *maxx, double *maxy, double *maxz)
{
	// If you have custom geometry.	You can	intialize and
	// customize the object	here. You will also need to
	// compute a bounding box for the geometry to ensure
	// the camera initially	encompasses the	geometry.

	// Initial bounding box.
	*minx =	-20.0;
	*miny =	-20.0;
	*minz =	-20.0;

	*maxx =	20.0;
	*maxy =	20.0;
	*maxz =	20.0;
}
*/

void dance::mainLoop()
{
	fltk::run();
}

void dance::IdleCB()
{
	int redisplay = 0 ;

	// if needed simulate
	if (AllSimulators->getSimulationMode() == dance::AllSimulators->MODE_SIMULATION)
	{
		// redisplay shows whether we want to redisplay
		// because of simulation or not.
		redisplay = AllSimulators->Step() ;
	}
	else if (AllSimulators->getSimulationMode() == dance::AllSimulators->MODE_PLAYBACK)
	{
		AllSimulators->playbackStep();
	}
}

void dance::DeleteAll()
{
	delete dance::AllPlugIns;

	delete AllSystems;
	AllSystems = NULL;
	delete AllActuators;
	AllActuators = NULL;
	delete AllGeometry;
	AllGeometry = NULL;
	delete AllLights;
	AllLights = NULL;
	delete AllViews;
	AllViews = NULL;
	delete AllSimulators;
	AllSimulators = NULL;
	delete AllGenericPlugins;
	AllGenericPlugins = NULL;
	delete AllRenderers;
	AllRenderers = NULL;
	delete AllModifiers;
	AllModifiers = NULL;
}

void dance::Refresh()
{
    AllViews->postRedisplay() ;
}

char* dance::getCurrentSaveDirectory()
{
	return (char*) saveDir.c_str();
}

char* dance::getTemporaryWorkDirectory()
{
	return (char*) tempDir.c_str();
}

bool dance::save(char* filename)
{
	// create a directory in which to save all files
	// first, strip the path from the name of the file
	char temppath[1024];
	getPathName(temppath, filename);
	char path[1024];
	convertbackslashes(temppath, path);
	char sessionname[1024];
	getFilename(filename, true, sessionname);

	// generate random names
	char dirname[512];
	// create this directory if it doesn't already exists
	sprintf(dirname, "dancesession.%s", sessionname);
	saveDir = path;
	saveDir = convertPathToRelativePath(saveDir);
	saveDir.append("/");
	saveDir.append(dirname);
	std::string actualSaveDir = convertPathToAbsolutePath(saveDir);
	// make sure this directory doesn't already exist
	if (!filename_isdir(actualSaveDir.c_str()))
	{
                danceInterp::OutputMessage("Creating directory %s", 	actualSaveDir.c_str());
		#ifdef WIN32
			int mkdirSuccess = CreateDirectory(actualSaveDir.c_str(), NULL);
			if (mkdirSuccess == 0)
			{
					danceInterp::OutputMessage("Cannot create directory '%s' - session will not be saved!",	actualSaveDir.c_str());
					return false;
			}
		#else
			char str[1024];
			sprintf(str, "mkdir %s", actualSaveDir.c_str());
			int mkdirSuccess = system(str);
			if (mkdirSuccess != 0)
			{
					danceInterp::OutputMessage("Cannot create directory '%s' - session will not be saved!",
					str);
					return false;
			}
		#endif
	}
	else
	{
		int ok = fltk::ask("A session with this name already exists.\nAre you sure you want to overwrite it?");
		if (!ok)
			return false;
	}

	// save old directory
	string prevDir = dance::rootWindow->commandWindow->getCurrentDirectory();
	string relPrevDir = convertPathToRelativePath(prevDir);
	// change to the new directory
	string changeDirCommand = "dance.chdir(\"";
	changeDirCommand.append(saveDir.c_str());
	changeDirCommand.append("\")");
	danceInterp::ExecuteCommandNoRecord((char*) changeDirCommand.c_str());

	// create an output file
	std::ofstream sessionFile(filename);
	sessionFile << "# DANCE session\n";

	sessionFile << "dance.chdir(\"" << saveDir << "\")\n";

	// load the plugins to resolve dependency issues
	// horrendously inefficient - we should probably build a dependency graph
	// into the proxies upon loading AS 8/20/05

	std::vector<string> loadedPlugins;
	std::vector<PlugIn*> pluginsNeeded;

	// load the plugins needed array
	for (int x = 0; x < dance::AllPlugIns->size(); x++)
	{
		PlugIn* obj = (PlugIn*) dance::AllPlugIns->get(x);
		pluginsNeeded.push_back(obj);
	}

	while (pluginsNeeded.size() > 0)
	{
		for (vector<PlugIn*>::iterator iter = pluginsNeeded.begin(); iter != pluginsNeeded.end(); iter++)
		{
			bool added = false;
			PlugIn* obj = *iter;
			int numDependentPlugins = obj->getNumPluginDependents();
			int numLoaded = 0;
			for (int d = 0; d < numDependentPlugins; d++)
			{
				const char* pluginName = obj->getPluginDependent(d);
				// find the plugin in the loadedPlugins list
				for (unsigned int i = 0; i < loadedPlugins.size(); i++)
				{
					if (strcmp(pluginName, loadedPlugins[i].c_str()) == 0)
					{
						numLoaded++;
						break;
					}
				}
			}
			if (numLoaded == numDependentPlugins)
			{
				// make sure that it isn't already loaded
				bool found = false;
				for (vector<string>::iterator striter = loadedPlugins.begin(); striter != loadedPlugins.end(); striter++)
				{
					if (strcmp(obj->getType(), (*striter).c_str()) == 0)
					{
						found = true;
						break;
					}
				}
				if (!found)
				{
					sessionFile << "dance.plugin(\"" << obj->getType() << "\")" << endl;
					iter = pluginsNeeded.erase(iter);
					loadedPlugins.push_back(obj->getType());
					added = true;
				}
			}
			if (added)
				break;
		}



	}
	
	for (int mode = 0; mode < 3; mode++)
	{
		sessionFile << "# mode " << mode << endl;
		dance::AllViews->save(mode, sessionFile);
		dance::AllLights->save(mode, sessionFile);
		dance::AllRenderers->save(mode, sessionFile);
		dance::AllGeometry->save(mode, sessionFile);
		dance::AllActuators->save(mode, sessionFile);
		dance::AllModifiers->save(mode, sessionFile);
		dance::AllSimulators->save(mode, sessionFile);
		dance::AllSystems->save(mode, sessionFile);
		dance::AllGenericPlugins->save(mode, sessionFile);
	}

	// show the GUI interface of any object currently shown
	for (int x = 0; x < dance::rootWindow->parameterWindow->getNumTabInterfaces(); x++)
	{
		// compare the interface 
		Widget* widget = dance::rootWindow->parameterWindow->getTabInterface(x);
		sessionFile << "dance.showinterface(\"" << widget->label() << "\")" << endl;
	}
	for (int x = 0; x < dance::rootWindow->parameterWindow->getNumFloatingInterfaces(); x++)
	{
		Widget* widget = dance::rootWindow->parameterWindow->getFloatingInterface(x);
		sessionFile << "dance.showinterface(\"" << widget->label() << "\")" << endl;
	}

	// add objects on the interaction stack
	int numInteractions = dance::getNumInteractions();
	for (int x = 0; x < numInteractions; x++)
	{
		DObject* obj = dance::getInteraction(x);
		sessionFile << "dance.addinteraction(\"" << obj->getName() << "\")" << endl;
	}


    // set the simulation times
    sessionFile << "dance.simul(\"setSimulationTimeStep\", " << dance::AllSimulators->getSimulationTimeStep() << ")" << std::endl;
    sessionFile << "dance.simul(\"setDisplayTimeStep\", " << dance::AllSimulators->getDisplayTimeStep() << ")" << std::endl;
    sessionFile << "dance.simul(\"setEndTime\", " << dance::AllSimulators->getEndTime() << ")" << std::endl;
    sessionFile << "dance.simul(\"setCurrentTime\", " << dance::AllSimulators->getCurrentTime() << ")" << std::endl;
	
    
    sessionFile << "dance.chdir(\"" << relPrevDir << "\")\n";
    
    sessionFile.close();

    saveDir.clear();    
    
    // change back the previous directory
	changeDirCommand = "dance.chdir(\"";
	changeDirCommand.append(relPrevDir.c_str());
	changeDirCommand.append("\")");
	danceInterp::ExecuteCommandNoRecord((char*) changeDirCommand.c_str());

	return true;
}

void dance::quit()
{
	if (fltk::ask("Are you sure you want to quit?"))
	{
		// save the position of the main window
		Preference::setWindowPreference("dance.rootwindow", dance::rootWindow);
		// save the width and height of the main window
		char width[40];
		char height[40];
		sprintf(width, "%d", dance::rootWindow->w());
		sprintf(height, "%d", dance::rootWindow->h());
		Preference::replacePreference("dance.rootwindow.width", width);
		Preference::replacePreference("dance.rootwindow.height", height);

		dance::clear();

		// remove all lists and managers
		DeleteAll();

		delete dance::MaterialManager;
		delete dance::rootWindow;
		delete dance::eventManager;
		delete [] dance::DanceLists;

		// save the user preferences
		dance::writePreferences();

		// remove preferences
		Preference::removeAllPreferences();



//		delete dance::selectionWindow;
		exit(0); // goodbye!
	}
}

bool dance::rename(DObject* object, char* name)
{
	if (object != NULL)
	{
		DObject* rObj = dance::getObject(name);
		if (rObj == NULL)
		{
			object->setName(name);
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}


DObject* dance::getObject(char* name)
{
	DObject* object = NULL;
	object = dance::AllActuators->get(name);
	if (object != NULL)
		return object;

	object = dance::AllGenericPlugins->get(name);
	if (object != NULL)
		return object;

	object = dance::AllGeometry->get(name);
	if (object != NULL)
		return object;

	object = dance::AllLights->get(name);
	if (object != NULL)
		return object;

	object = dance::AllModifiers->get(name);
	if (object != NULL)
		return object;

	object = dance::AllPlugIns->get(name);
	if (object != NULL)
		return object;

	object = dance::AllSimulators->get(name);
	if (object != NULL)
		return object;

	object = dance::AllSystems->get(name);
	if (object != NULL)
		return object;

	object = dance::AllViews->get(name);
	if (object != NULL)
		return object;

	object = dance::AllRenderers->get(name);
	if (object != NULL)
		return object;


	return object;


}

bool dance::removeObject(DObject* obj)
{
	if (dance::AllActuators->get(obj->getName()) == obj)
		return dance::AllActuators->remove(obj);

	if (dance::AllGenericPlugins->get(obj->getName()) == obj)
		return dance::AllGenericPlugins->remove(obj);

	if (dance::AllGeometry->get(obj->getName()) == obj)
		return dance::AllGeometry->remove(obj);

	if (dance::AllLights->get(obj->getName()) == obj)
		return dance::AllLights->remove(obj);

	if (dance::AllModifiers->get(obj->getName()) == obj)
		return dance::AllModifiers->remove(obj);

	if (dance::AllPlugIns->get(obj->getName()) == obj)
		return dance::AllPlugIns->remove(obj);

	if (dance::AllSimulators->get(obj->getName()) == obj)
		return dance::AllSimulators->remove(obj);

	if (dance::AllSystems->get(obj->getName()) == obj)
		return dance::AllSystems->remove(obj);

	if (dance::AllViews->get(obj->getName()) == obj)
		return dance::AllViews->remove(obj);

	if (dance::AllRenderers->get(obj->getName()) == obj)
		return dance::AllRenderers->remove(obj);

	return false;
}

void dance::clear()
{
	// reset the simulators
	if (dance::AllSimulators->getSimulationMode() == dance::AllSimulators->MODE_SIMULATION && dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_RUNNING)
		dance::AllSimulators->Stop();

	// first, remove all objects from the system
	for (int x = dance::AllGenericPlugins->size() - 1; x >= 0; x--)
		dance::AllGenericPlugins->remove(x);

	for (int x = dance::AllGeometry->size() - 1; x >= 0; x--)
		dance::AllGeometry->remove(x);

	for (int x = dance::AllActuators->size() - 1; x >= 0; x--)
		dance::AllActuators->remove(x);

	for (int x = dance::AllLights->size() - 1; x >= 0; x--)
		dance::AllLights->remove(x);

	for (int x = dance::AllModifiers->size() - 1; x >= 0; x--)
		dance::AllModifiers->remove(x);

	for (int x = dance::AllSimulators->size() - 1; x >= 0; x--)
		dance::AllSimulators->remove(x);

	for (int x = dance::AllSystems->size() - 1; x >= 0; x--)
		dance::AllSystems->remove(x);

	for (int x = dance::AllViews->size() - 1; x >= 0; x--)
		dance::AllViews->remove(x);

	for (int x = dance::AllRenderers->size() - 1; x >= 0; x--)
		dance::AllRenderers->remove(x);

	// remove all data from the event system
	dance::AllSimulators->removeAllCallbacks();

	dance::AllSimulators->setCurrentTime(0.0);
	dance::AllSimulators->setPlaybackTime(0.0);
	dance::AllSimulators->calculatePlaybackEndTime();
	dance::AllSimulators->setSimulationMode(dance::AllSimulators->MODE_SIMULATION);
	dance::AllSimulators->setSimulationState(dance::AllSimulators->STATE_NOT_RUNNING);

	// empty the interaction stack
	int numInteractions = dance::getNumInteractions();
	for (int x = numInteractions - 1; x >= 0; x--)
	{
		DObject* obj = dance::getInteraction(x);
		dance::removeInteraction(obj);
	}

	// reset the material manager
	dance::MaterialManager->remove_materials();

}

void dance::loadProfile()
{
	// second, rerun the profile.xxx file
	char filename[256];
	sprintf(filename,"%s/%s",dance::getDanceDir(), danceInterp::getProfileFile());    

	danceInterp::load(filename);
	dance::rootWindow->danceWindow->resetAllLights();
}

void dance::resetAll()
{
	dance::clear();

	// reload the stock file
	std::string stockfilename = dance::getDanceDir();
	stockfilename.append(STOCK_FILENAME);
	switch (MaterialManager->loadStock((char*) stockfilename.c_str())) {
	case -2:
		danceInterp::OutputMessage("Material stock file not found. It should be in %s\n", stockfilename.c_str());
		break;
	case -1:
		danceInterp::OutputMessage("Material stock in %s corrupted\n", stockfilename.c_str());
		danceInterp::OutputMessage("%d stock materials read\n", MaterialManager->getNumMaterials());
		break;
	default:
		danceInterp::OutputMessage("%d stock materials read\n", MaterialManager->getNumMaterials());
	}

	// update the directory
	char dir[256] ;
	danceInterp::getCurrentDirectory(dir);
	if ( strcmp(dance::rootWindow->commandWindow->getCurrentDirectory(), dir) )             
	{
			dance::rootWindow->commandWindow->setCurrentDirectory(dir);
			dance::rootWindow->commandWindow->redraw();
	}

}

bool dance::isInInteractStack(DObject* obj)
{
	for(vector<DObject*>::iterator iter = dance::interactStack.begin(); iter != dance::interactStack.end(); iter++)
	{
		if ((*iter) == obj)
		{
			return true;
		}
	}

	return false;

}


void dance::addInteraction(DObject* obj)
{
	// make sure that the interaction is not already in the stack
	for(vector<DObject*>::iterator iter = dance::interactStack.begin(); iter != dance::interactStack.end(); iter++)
	{
		if ((*iter) == obj)
		{
			dance::interactStack.erase(iter);
			break;
		}
	}

	dance::interactStack.push_back(obj);

}

void dance::removeInteraction(DObject* obj)
{
	for(vector<DObject*>::iterator iter = dance::interactStack.begin(); iter != dance::interactStack.end(); iter++)
	{
		if ((*iter) == obj)
		{
			dance::interactStack.erase(iter);
			break;
		}
	}
}

DObject* dance::getInteraction(int num)
{
	return dance::interactStack[num];
}

int dance::getNumInteractions()
{
	return dance::interactStack.size();
}

void dance::reloadScripts(const char *scriptsDir)
{
	// erase the old scripts menu
	for (int x = dance::rootWindow->menubar->children() - 1; x >= 0; x--)
	{
		Widget* widget = dance::rootWindow->menubar->child(x);
		if (strcmp(widget->label(), "Scripts") == 0)
		{
			Group* group = (Group*) widget;
			for (int x = group->children() - 1; x >= 0; x--)
				group->remove(x);
		}
	}

	// create the new menu
	dance::rootWindow->menubar->add("Scripts/Run script",	CTRL+'u', RootWindow::runScript_cb, 0);
	dance::rootWindow->menubar->add("Scripts/Reload Scripts", 0, RootWindow::reloadscripts_cb,0, MENU_DIVIDER);
	reloadScriptsByDir(scriptsDir, "");
}

void dance::reloadScriptsByDir(const char *scriptsDir, const char* parentStr)
{
#ifdef WIN32
	// eliminate the current list
	char buff[512];
	char path[MAXPATHLENGTH];
	WIN32_FIND_DATA fd;
	DWORD dwAttr = FILE_ATTRIBUTE_DIRECTORY;
	//if( !bCountHidden) dwAttr |= FILE_ATTRIBUTE_HIDDEN;
	sprintf( path, "%s\\*", scriptsDir);
	HANDLE hFind = FindFirstFile( path, &fd);
	if(hFind != INVALID_HANDLE_VALUE)
	{
		int count = 0;
		do
		{
			if( !(fd.dwFileAttributes & dwAttr))
			{
				if (filename_match(fd.cFileName, "*.py"))
				{
					// eliminate the .py ending
					strncpy(buff, fd.cFileName, strlen(fd.cFileName) - 3);
					buff[strlen(fd.cFileName) - 3] = '\0';
					// add the name to the root window
					char entry[512];
					sprintf(entry, "Scripts/%s%s", parentStr, buff);
					dance::rootWindow->menubar->add(entry, 0, RootWindow::runUserScript_cb, 0, 0);
				}
			}
			else 
			{
				if (!strcmp(fd.cFileName, "..") == 0 && !strcmp(fd.cFileName, ".") == 0)
				{
					// recurse into this directory
					char newdir[1024];
					sprintf(newdir, "%s/%s", scriptsDir, fd.cFileName);
					char newParentStr[1024];
					sprintf(newParentStr, "%s%s/", parentStr, fd.cFileName);

					reloadScriptsByDir(newdir, newParentStr);
				}
			}
		} while( FindNextFile( hFind, &fd));
		FindClose( hFind);
	}
#else
	char buff[8192];
	danceInterp::getDirectoryListing(buff, 8192, (char*) scriptsDir);
	char* token = strtok(buff, " ");
	char scriptName[512];
	std::vector<std::string> allentries;
	while (token != NULL)
	{
		std::string s = token;
		allentries.push_back(s);
		token = strtok(NULL, " ");
	}

	for (unsigned int x = 0; x < allentries.size(); x++)
	{
		char absfilename[2048];
		sprintf(absfilename, "%s%s", scriptsDir, allentries[x].c_str());

		if (!filename_isdir(absfilename))
		{

			if (filename_match(allentries[x].c_str(), "*.py"))
			{
				strncpy(scriptName, allentries[x].c_str(),  strlen(allentries[x].c_str()) - 3);
				scriptName[strlen(allentries[x].c_str()) - 3] = '\0';
				// add the name to the root window
				char entry[512];
				sprintf(entry, "Scripts/%s%s", parentStr, scriptName);
				dance::rootWindow->menubar->add(entry, 0, RootWindow::runUserScript_cb, 0, 0);
			}
		}
		else
		{
			if (!strcmp(allentries[x].c_str(), "..") == 0 && !strcmp(allentries[x].c_str(),  ".") == 0)
			{
				// recurse into this directory
				char newdir[1024];
				sprintf(newdir, "%s/%s", scriptsDir, allentries[x].c_str());
				char newParentStr[1024];
				sprintf(newParentStr, "%s%s/", parentStr, allentries[x].c_str());
				reloadScriptsByDir(newdir, newParentStr);
			}
		}

	}

#endif
}

void dance::loadPreferences()
{
	// look for a file called "preferences.ini"
	char filename[1024];
	sprintf(filename, "%s/preferences.ini", dance::getDanceDir());
	std::ifstream file(filename);
	if (!file.good())
	{
		file.close();
		return;
	}
	else
	{ 
		Preference::loadPreferences(file);
	}
	file.close();
}

void dance::writePreferences()
{
	// write the preferences to a preference file
	char filename[1024];
	sprintf(filename, "%s/preferences.ini", dance::getDanceDir());
	std::ofstream file(filename);
	if (file.good())
	{
		Preference::writePreferences(file);
	}
	else
	{
		danceInterp::OutputMessage("Could not open file %s for writing...", filename);
	}
	file.close();
}

std::string dance::convertPathToAbsolutePath(std::string path)
{
	// get the DANCE directory
	const char* danceDir = NULL;
	danceDir = getenv("DANCE_DIR");
	if (!danceDir)
		return path;

	std::string fullDanceDir = danceDir;
	std::replace_if(fullDanceDir.begin(), fullDanceDir.end(), std::bind2nd(std::equal_to<char>(),'\\'), '/');

	if (fullDanceDir[fullDanceDir.size() - 1] != '/')
		fullDanceDir.append("/");

	std::string danceRelPrefix = "DANCE://";

	int loc = path.find(danceRelPrefix);
	if (loc == 0)
	{
		std::stringstream absPath;
		absPath << fullDanceDir << path.substr(danceRelPrefix.size());
		return absPath.str();
	}
	else
	{
		return path;
	}
}

std::string dance::convertPathToRelativePath(std::string path)
{
	// get the DANCE directory
	const char* danceDir = NULL;
	danceDir = getenv("DANCE_DIR");
	if (!danceDir)
		return path;
	
	std::string fullDanceDir = danceDir;
	std::replace_if(fullDanceDir.begin(), fullDanceDir.end(), std::bind2nd(std::equal_to<char>(),'\\'), '/');

	// convert backslashes to forward slashes
	std::string relpath = path;
	std::replace_if(relpath.begin(), relpath.end(), std::bind2nd(std::equal_to<char>(),'\\'), '/');

#ifdef WIN32
	// make sure that the path has a drive letter
	char buffer[_MAX_PATH];
	if (relpath[0] == '/')
	{
		_getcwd(buffer, _MAX_PATH);
		// extract the drive
		std::stringstream temp;
		temp << buffer[0] << buffer[1] << relpath;
		relpath = temp.str();
	}
#endif
	// find the DANCE directory in the path
	int loc = path.find(fullDanceDir);
	if (loc == 0)
	{
		// replace the prefix with DANCE://
		std::string relPrefix = "DANCE://";
		std::string suffix =  relpath.substr(fullDanceDir.size());
		
		// eliminate any slashes
		int slashLoc = 0;
		while (slashLoc == 0)
		{
			slashLoc = suffix.find_first_of('/');
			if (slashLoc == 0)
			{
				std::string tempSuffix = suffix.substr(slashLoc + 1);
				suffix = tempSuffix;
			}
		}
		
		std::stringstream relPath;
		relPath << relPrefix << suffix;
		return relPath.str();
	}
	else
	{
		return path;
	}
}

const char* dance::getDanceDir()
{
	return danceDir.c_str();
}

void dance::setDanceDir(const char* directory)
{
	danceDir = directory;
}

std::string dance::getVersion()
{
	std::stringstream ver;
	ver << dance::getMajorVersion() << "." << dance::getMinorVersion();
	return ver.str();
}

