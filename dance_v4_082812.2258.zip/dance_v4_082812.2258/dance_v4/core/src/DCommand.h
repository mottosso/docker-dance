#ifndef DCOMMAND_H
#define DCOMMAND_H

#include "defs.h"
#include <string>
#include <map>
#include <vector>
#include <limits>

#include "vectorObj.h"
#include "arbMatrix.h"

static int IntMin = -999;
static int IntMax = 999;
static double DoubleMin = -999.0;
static double DoubleMax = 999.0;

enum DCommandOptionType
{
	COMMANDTYPE_NONE,
	COMMANDTYPE_BOOL,
	COMMANDTYPE_INT,
	COMMANDTYPE_DOUBLE,
	COMMANDTYPE_STRING,
	COMMANDTYPE_VECTOR,
	COMMANDTYPE_MATRIX
};

class DLLENTRY DCommandOption
{
	public:
		DCommandOption(int optionType, bool optional);
		~DCommandOption();

		void setOptionType(int type);
		int getOptionType();
		void setOptional(bool val);
		bool isOptional();
		void setValidStringValues(std::vector<std::string> values);
		std::vector<std::string>& getValidStringValues();
		void setMinInt(int min);
		int getMinInt();
		void setMaxInt(int max);
		int getMaxInt();
		void setMinDouble(double min);
		double getMinDouble();
		void setMaxDouble(double max);
		double getMaxDouble();
	
private:
		int m_optionType;
		bool m_isOptional;
		int m_minInt;
		int m_maxInt;
		double m_minDouble;
		double m_maxDouble;
		std::vector<std::string> m_validStringValues;
};

class DLLENTRY DCommand
{
	public:
		DCommand(std::string name);
		~DCommand();

		std::map<std::string, DCommandOption*>& getOptions();

		void addNoneOption(std::string name, bool optional = false);
		void addBoolOption(std::string name, bool optional = false);
		void addIntOption(std::string name, bool optional = false, int min = IntMin, int max = IntMax);
		void addDoubleOption(std::string name, bool optional = false, double min = DoubleMin, double max = DoubleMax);
		void addStringOption(std::string name, bool optional = false, std::vector<std::string> validValues = std::vector<std::string>());
		void addVectorOption(std::string name, bool optional = false);
		void addMatrixOption(std::string name, bool optional = false);

		std::string getUsage();

	private:
		std::string m_name;
		std::map<std::string, DCommandOption*> m_options;
};

class DLLENTRY DCommandToken
{
	public:
		DCommandToken();
		~DCommandToken();

		void addOption(DCommandOption* option);
		bool isValidOption(std::string name);

		void setOptionValueBool(DCommandOption* option, bool val);
		void setOptionValueInt(DCommandOption* option, int val);
		void setOptionValueDouble(DCommandOption* option, double val);
		void setOptionValueVector(DCommandOption* option, VectorObj val);
		void setOptionValueMatrix(DCommandOption* option, ArbMatrix matrix);

		bool getOptionValueBool(DCommandOption* option);
		int getOptionValueInt(DCommandOption* option);
		double getOptionValueDouble(DCommandOption* option);
		VectorObj getOptionValueVector(DCommandOption* option);
		ArbMatrix getOptionValueMatrix(DCommandOption* option);

		void setIsOk(bool val);
		void setSyntaxError(std::string msg);
		bool isOk();
		std::string getSyntaxError();

		bool getBoolValue();
		int getIntValue();
		double getDoubleValue();
		std::string getStringValue();
		VectorObj getVectorValue();
		ArbMatrix getMatrixValue();

	private:
		bool m_isOk;
		std::string m_syntaxError;

		std::map<DCommandOption*, bool> m_boolValues;
		std::map<DCommandOption*, int> m_intValues;
		std::map<DCommandOption*, double> m_doubleValues;
		std::map<DCommandOption*, std::string> m_stringValues;
		std::map<DCommandOption*, VectorObj> m_vec3Values;
		std::map<DCommandOption*, ArbMatrix> m_matrixValues;
};

class DLLENTRY DCommandParser
{
	public:
		static DCommandToken* parseCommand(std::map<std::string, DCommand*>& commands, int argc, char* argv[]) {return NULL;};
};

#endif