/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "MaterialEditorWindow.h"
#include <fltk/ColorChooser.h>
#include <fltk/file_chooser.h>
#include "dance.h"
#include "ViewManager.h"
#include "Preference.h"

using namespace fltk;

MaterialEditorWindow::MaterialEditorWindow(int x, int y, int w, int h, const char* name) : Window(x, y, w, h, name)
{
	material = NULL;

	this->begin();

	inputName = new Input(80, 20, 100, 20, "Name");
	inputName->callback(name_cb, this);

	buttonAmbient = new Button(20, 50, 50, 20, "Ambient");
	buttonAmbient->callback(color_cb, this);
	for (int x = 0; x < 3; x++)
	{
		inputAmbient[x] = new ValueInput(80 + 60 * x, 60, 50, 20);
		inputAmbient[x]->callback(inputcolor_cb, this);
		inputAmbient[x]->color(fltk::GRAY75);
	}

	buttonDiffuse = new Button(20, 80, 50, 20, "Diffuse");
	buttonDiffuse->callback(color_cb, this);
	for (int x = 0; x < 3; x++)
	{
		inputDiffuse[x] = new ValueInput(80 + 60 * x, 80, 50, 20);
		inputDiffuse[x]->callback(inputcolor_cb, this);
		inputDiffuse[x]->color(fltk::GRAY75);
	}

	buttonSpecular = new Button(20, 110, 50, 20, "Specular");
	buttonSpecular->callback(color_cb, this);
	for (int x = 0; x < 3; x++)
	{
		inputSpecular[x] = new ValueInput(80 + 60 * x, 110, 50, 20);
		inputSpecular[x]->callback(color_cb, this);
		inputSpecular[x]->color(fltk::GRAY75);
	}

	buttonEmission = new Button(20, 140, 50, 20, "Emission");
	buttonEmission->callback(color_cb, this);
	for (int x = 0; x < 3; x++)
	{
		inputEmission[x] = new ValueInput(80 + 60 * x, 140, 50, 20);
		inputEmission[x]->callback(inputcolor_cb, this);
		inputEmission[x]->color(fltk::GRAY75);
	}

	inputShininess = new ValueInput(80, 170, 60, 20, "Shininess");
	inputShininess->callback(shininess_cb, this);


	outputTexture = new Output(80, 200, 150, 20, "Texture");
	buttonTexture = new Button(240, 200, 30, 20, "...");
	buttonTexture->callback(texture_cb, this);

	buttonSave = new Button(20, h - 30, 50, 20, "Save");
	buttonSave->callback(save_cb, this);

	buttonRestore = new Button(80, h - 30, 50, 20, "Restore");
	buttonRestore->callback(restore_cb, this);

	buttonCancel = new Button(w - 60, h - 30, 50, 20, "Cancel");
	buttonCancel->callback(cancel_cb, this);

//	windowPreview = new MaterialPreviewWindow(80, 230, 200, 150, "Preview");

	this->end();
	
	this->updateGUI();
}

void MaterialEditorWindow::show()
{
	this->updateGUI();
	Window::show();
}


void MaterialEditorWindow::updateGUI()
{
//	windowPreview->setMaterial(material);

	if (material == NULL)
		return;

	float* color = material->getAmbientColor();
	for (int x = 0; x < 3; x++)
		inputAmbient[x]->value(color[x]);

	color = material->getDiffuseColor();
	for (int x = 0; x < 3; x++)
		inputDiffuse[x]->value(color[x]);

	color = material->getEmissiveColor();
	for (int x = 0; x < 3; x++)
		inputEmission[x]->value(color[x]);

	color = material->getSpecularColor();
	for (int x = 0; x < 3; x++)
		inputSpecular[x]->value(color[x]);

	inputShininess->value(material->getShininess());

	inputName->value(material->getMaterialName());

	//Texture* t = material->getTexture();
}

void  MaterialEditorWindow::setMaterial(Material* m)
{
	material = m;
	materialCopy.copy(material);
	updateGUI();
	dance::AllViews->postRedisplay();
}

Material*  MaterialEditorWindow::getMaterial()
{
	return material;
}

void MaterialEditorWindow::restoreMaterial()
{
	if (material != NULL)
		material->copy(&materialCopy);
}

void MaterialEditorWindow::inputcolor_cb(fltk::Widget* widget, void* data)
{
	MaterialEditorWindow* win = (MaterialEditorWindow*) data;
	ValueInput* input = dynamic_cast<ValueInput*>(widget);

	float* ambient = win->getMaterial()->getAmbientColor();
	float* diffuse = win->getMaterial()->getDiffuseColor();
	float* specular = win->getMaterial()->getSpecularColor();
	float* emissive = win->getMaterial()->getEmissiveColor();

	float a[4], d[4], s[4], e[4];
	for (int x = 0; x < 4; x++)
	{
		a[x] = ambient[x];
		d[x] = diffuse[x];
		s[x] = specular[x];
		e[x] = emissive[x];
	}

	// diffuse
	if (input == win->inputDiffuse[0])
	{
		d[0] = (float) input->value();
		win->getMaterial()->setDiffuseColor(d);
	}
	else if (input == win->inputDiffuse[1])
	{
		d[1] = (float) input->value();
		win->getMaterial()->setDiffuseColor(d);
	}
	else if (input == win->inputDiffuse[2])
	{
		d[2] = (float) input->value();
		win->getMaterial()->setDiffuseColor(d);
	}
	// ambient
	else if (input == win->inputAmbient[0])
	{
		d[0] = (float) input->value();
		win->getMaterial()->setAmbientColor(d);
	}
	if (input == win->inputAmbient[1])
	{
		a[1] = (float) input->value();
		win->getMaterial()->setAmbientColor(d);
	}
	if (input == win->inputAmbient[2])
	{
		a[2] = (float) input->value();
		win->getMaterial()->setAmbientColor(d);
	}
	// specular
	if (input == win->inputSpecular[0])
	{
		s[0] = (float) input->value();
		win->getMaterial()->setSpecularColor(d);
	}
	if (input == win->inputSpecular[1])
	{
		s[1] = (float) input->value();
		win->getMaterial()->setSpecularColor(d);
	}
	if (input == win->inputSpecular[2])
	{
		s[2] = (float) input->value();
		win->getMaterial()->setSpecularColor(d);
	}
	if (input == win->inputEmission[0])
	{
		e[0] = (float) input->value();
		win->getMaterial()->setEmissiveColor(d);
	}
	if (input == win->inputEmission[0])
	{
		e[1] = (float) input->value();
		win->getMaterial()->setEmissiveColor(d);
	}
	if (input == win->inputEmission[0])
	{
		e[2] = (float) input->value();
		win->getMaterial()->setEmissiveColor(d);
	}
	win->updateGUI();
	dance::AllViews->postRedisplay();
}

void MaterialEditorWindow::color_cb(fltk::Widget* widget, void* data)
{
	MaterialEditorWindow* win = (MaterialEditorWindow*) data;
	Button* button = dynamic_cast<Button*>(widget);

	// get the appropriate color
	if (button == win->buttonAmbient)
	{
		float* color = win->getMaterial()->getAmbientColor();
		float fcolor[4];
		for (int x = 0; x < 4; x++)
			fcolor[x] = color[x];
		int ret = fltk::color_chooser("Ambient Color", fcolor[0], fcolor[1], fcolor[2]);
		if (ret != 0)
		{
			win->getMaterial()->setAmbientColor(fcolor);
			win->updateGUI();
			dance::AllViews->postRedisplay();
		}
	}
	else if (button == win->buttonDiffuse)
	{
		float* color = win->getMaterial()->getDiffuseColor();
		float fcolor[4];
		for (int x = 0; x < 4; x++)
			fcolor[x] = color[x];
		int ret = fltk::color_chooser("Diffuse Color", fcolor[0], fcolor[1], fcolor[2]);
		if (ret != 0)
		{
			win->getMaterial()->setDiffuseColor(fcolor);
			win->updateGUI();
			dance::AllViews->postRedisplay();
		}
	}
	else if (button == win->buttonSpecular)
	{
		float* color = win->getMaterial()->getSpecularColor();
		float fcolor[4];
		for (int x = 0; x < 4; x++)
			fcolor[x] = color[x];
		int ret = fltk::color_chooser("Specular Color", fcolor[0], fcolor[1], fcolor[2]);
		if (ret != 0)
		{
			win->getMaterial()->setSpecularColor(fcolor);
			win->updateGUI();
			dance::AllViews->postRedisplay();
		}
	}
	else if (button == win->buttonEmission)
	{
		float* color = win->getMaterial()->getEmissiveColor();
		float fcolor[4];
		for (int x = 0; x < 4; x++)
			fcolor[x] = color[x];
		int ret = fltk::color_chooser("Emissive Color", fcolor[0], fcolor[1], fcolor[2]);
		if (ret != 0)
		{
			win->getMaterial()->setEmissiveColor(fcolor);
			win->updateGUI();
			dance::AllViews->postRedisplay();
		}
	}
}

void MaterialEditorWindow::shininess_cb(fltk::Widget* widget, void* data)
{
}

void MaterialEditorWindow::texture_cb(fltk::Widget* widget, void* data)
{
	const char* file = fltk::file_chooser("Please choose a texture file:", "{*.bmp | *.png | *.jpg}", NULL);
	if (file != NULL)
	{
	}
}

void MaterialEditorWindow::name_cb(fltk::Widget* widget, void* data)
{
	MaterialEditorWindow* win = (MaterialEditorWindow*) data;

	Input* input = dynamic_cast<Input*>(widget);

	win->getMaterial()->setMaterialName((char*) input->value());
}

void MaterialEditorWindow::save_cb(fltk::Widget* widget, void* data)
{
	MaterialEditorWindow* win = (MaterialEditorWindow*) data;

	Preference::setWindowPreference("dance.materialeditorwindow", win);
	dance::writePreferences();

	win->hide();
}

void MaterialEditorWindow::restore_cb(fltk::Widget* widget, void* data)
{
	MaterialEditorWindow* win = (MaterialEditorWindow*) data;

	win->restoreMaterial();
	win->updateGUI();
	dance::AllViews->postRedisplay();
}

void MaterialEditorWindow::cancel_cb(fltk::Widget* widget, void* data)
{
	MaterialEditorWindow* win = (MaterialEditorWindow*) data;

	win->restoreMaterial();
	dance::AllViews->postRedisplay();

	Preference::setWindowPreference("dance.materialeditorwindow", win);
	dance::writePreferences();
	win->hide();
}





