/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include <cstdlib>
#include "opengl.h"
#include "DLight.h"
#include "dance.h"
#include "danceInterp.h"
#include "ViewManager.h"
#include "DView.h"
#include "PlugIn.h"
#include "LightWindow.h"

#include "stuff.h"

#define	LDISPLAY_WIRE	 1
#define MAX_ALLOWED_LIGHTS (4096)

static int *gLightArray = NULL;

using namespace fltk;
using namespace std;


DLight::DLight(char *name, int argc, char **argv)
{
	// Determine the maximum number of lights available.
	GLint maxLights; glGetIntegerv(GL_MAX_LIGHTS,&maxLights);

	// Cap the max lights at something reasonable.
	// GL sometimes returns garbage for GL_MAX_LIGHTS, 
	// so this is just a sanity check
	maxLights = std::min( MAX_ALLOWED_LIGHTS, (int) maxLights );

	// Initialize light array.
	if (gLightArray == NULL)	{
		gLightArray = new int[maxLights];
		for (int i=0; i	< maxLights; i++) gLightArray[i]	= 0;
	}


	// Find position of first non-defined light.
	int i;
	for (i=0; i < maxLights; i++) 
		if (gLightArray[i] == 0) break;


	if (i == maxLights) {
		danceInterp::OutputListElement("WARNING: Reusing Light	0 as all lights	are already in use.\n",(char *)NULL);
		m_ID = (GLenum)GL_LIGHT0;
		return;
	}
	else {
	   m_ID =	(GLenum)(GL_LIGHT0 + i);
	   gLightArray[i] = 1;
	}

	setType("light");
	setBaseType("light");

	m_Type = ePoint;

	GLfloat value[4];



	// Set default values based on OpenGL standard.
	if (m_ID == GL_LIGHT0) {
		m_Diffuse[0] = m_Diffuse[1] = m_Diffuse[2] = m_Diffuse[3] = 1.0;
		m_Specular[0] = m_Specular[1] = m_Specular[2] = m_Specular[3] = 1.0;
	}
	else {
		m_Diffuse[0] = m_Diffuse[1] = m_Diffuse[2] = .3f; 
		m_Diffuse[3] = 1.0f;
		m_Specular[0] = m_Specular[1] = m_Specular[2] = 0.3f;
		m_Specular[3] = 1.0f;
	}
	m_Ambient[0] = m_Ambient[1] = m_Ambient[2] = 0.2f; m_Ambient[3] = 1.0f;
	m_Position[0] = m_Position[1] = 0.0; m_Position[2] = 100.0; m_Position[3] = 1.0;

	// Override light parameters if arguments provided.
	if( argc == 5 )
	{
		value[0] = (float)atof(argv[1]);
		value[1] = (float)atof(argv[2]);
		value[2] = (float)atof(argv[3]);
		value[3] = (float)atof(argv[4]);
	
		if (strcmp(argv[0],"position") == 0)
			memcpy(m_Position,value,4*sizeof(GLfloat));
		else if (strcmp(argv[0],"diffuse") == 0)
			memcpy(m_Diffuse,value,4*sizeof(GLfloat));
		else if (strcmp(argv[0],"specular") == 0)
			memcpy(m_Specular,value,4*sizeof(GLfloat));
		else if (strcmp(argv[0],"ambient") == 0)
			memcpy(m_Ambient,value,4*sizeof(GLfloat));
	}


	m_isSpotLight = false;
	m_isDirectional = false;
	m_spotExponent = 0.0;
	m_spotCutoffAngle = 180.0;
	m_constantAttenuation = 1.0;
	m_linearAttenuation = 0.0;
	m_quadraticAttenuation = 0.0;
	m_spotDirection[0] = 0;
	m_spotDirection[1] = 0;
	m_spotDirection[2] = -1;
	m_isRelativeToCamera = false;

	init();

	m_lightWindow = NULL;

	this->setVisible(false);
}

DLight::~DLight()
{
	// Disable light for all views.
	for (int i = 0;	i < dance::AllViews->size(); i++) {
		DView *view = (DView *)dance::AllViews->get(i);
		view->set();
		glDisable(m_ID);
	}
	gLightArray[(m_ID-GL_LIGHT0)] = 0;

	if (m_lightWindow != NULL)
		delete m_lightWindow;

	// if this is the only light, remove the light array
	if (dance::AllLights->size() <= 1)
	{
		delete [] gLightArray;
		gLightArray = NULL;
	}
	
}

int DLight::commandPlugIn(int argc, char **argv)
{
	int ret = DObject::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

	if (strcmp(argv[0], "reset") == 0)
	{
		this->init();
		danceInterp::OutputMessage("Light %s has been reset.", this->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "allstatus") == 0)
	{
		this->showStatus();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "visible") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: light %s visible <on|off>", this->getName());
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "on") == 0)
		{
			this->setVisible(true);
			danceInterp::OutputMessage("light %s is now visible.", this->getName());
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "off") == 0)
		{
			this->setVisible(false);
			danceInterp::OutputMessage("light %s is now not visible.", this->getName());
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Usage: light %s visible <on|off>", this->getName());
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0],"position") == 0 || strcmp(argv[0],"diffuse") == 0 || strcmp(argv[0],"ambient") == 0 || strcmp(argv[0],"specular") == 0)
	{
		GLfloat* parm;
		if (strcmp(argv[0],"position") == 0)
		{
			parm = m_Position;
		}
		else if	(strcmp(argv[0],"diffuse") == 0)
		{
			parm = m_Diffuse;
		}
		else if	(strcmp(argv[0],"ambient") == 0)
		{
			parm = m_Ambient; 
		}
		else if	(strcmp(argv[0],"specular") == 0)
		{
			parm = m_Specular;
		}

		GLfloat	value[4];
		if (argc == 1)
		{
			char resultString[256];
			memcpy(value,parm,4*sizeof(GLfloat));
			sprintf(resultString,"%f %f %f %f\n",value[0],value[1],value[2],value[3]);
			danceInterp::OutputListElement(resultString,NULL);
			init();
			return DANCE_OK;
		}
		if( argc != 5 )
		{
			danceInterp::OutputMessage("Usage: light <name> "
				"position|diffuse|ambient|specular a1 a2 a3 a4") ;
			return DANCE_ERROR ;
		}
		value[0] = (GLfloat) atof(argv[1]);
		value[1] = (GLfloat) atof(argv[2]);
		value[2] = (GLfloat) atof(argv[3]);
		value[3] = (GLfloat) atof(argv[4]);
		memcpy(parm,value,4*sizeof(GLfloat));
		this->init();

		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "directional") == 0)
	{
		if (argc < 2)
		{
			// usage
			return DANCE_ERROR;
		}

		if (strcmp(argv[1], "on") == 0)
		{
			this->setDirectional(true);
			this->init();

			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "off") == 0)
		{
			this->setDirectional(false);
			this->init();

			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else
		{
			// usage
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "spotlight") == 0)
	{
		if (argc < 2)
		{
			// usage
			return DANCE_ERROR;
		}

		if (strcmp(argv[1], "on") == 0)
		{
			this->setSpotlight(true);
			this->init();

			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "off") == 0)
		{
			this->setSpotlight(false);
			this->init();

			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else
		{
			// usage
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "spotlight_direction") == 0)
	{
		if (argc < 4)
		{
			// usage
			return DANCE_ERROR;
		}
		GLfloat direction[3];
		direction[0] = (float) atof(argv[1]);
		direction[1] = (float) atof(argv[2]);
		direction[2] = (float) atof(argv[3]);

		this->setSpotDirection(direction);
		this->init();
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "spotlight_cutoff_angle") == 0)
	{
		if (argc < 2)
		{
			// usage
			return DANCE_ERROR;
		}

		double angle = atof(argv[1]);
		this->setSpotCutoffAngle(angle);
		this->init();
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "spotlight_exponent") == 0)
	{
		if (argc < 2)
		{
			// usage
			return DANCE_ERROR;
		}

		double exp = atof(argv[1]);
		this->setSpotExponent(exp);
		this->init();
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "constant_attentuation") == 0)
	{
		if (argc < 2)
		{
			// usage
			return DANCE_ERROR;
		}

		double attentuation = atof(argv[1]);
		this->setConstantAttentuation(attentuation);
		this->init();
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "linear_attentuation") == 0)
	{
		if (argc < 2)
		{
			// usage
			return DANCE_ERROR;
		}

		double attentuation = atof(argv[1]);
		this->setLinearAttentuation(attentuation);
		this->init();
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "quadratic_attentuation") == 0)
	{
		if (argc < 2)
		{
			// usage
			return DANCE_ERROR;
		}

		double attentuation = atof(argv[1]);
		this->setQuadraticAttentuation(attentuation);
		this->init();
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}

	return DANCE_CONTINUE;
}

void DLight::output(int mode)
{
	// directional lights come from infinite distances, so don't show them
	if (!this->isDirectional())
	{
		glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT);

		glDisable(GL_LIGHTING);
		glColor3f(1.0, 1.0, 0.0);

		glMatrixMode(GL_MODELVIEW);
		glPushMatrix();
		glTranslatef(m_Position[0],m_Position[1],m_Position[2]);

		double radius = 0.02 * dance::AllViews->getViewFocus()->getFrustumWidth(0.0);
		glutWireSphere(radius, 8, 6);
		glPopMatrix();

		glPopAttrib();
	}
}

void DLight::init()
{

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	// make sure that the modelview matrix   
	// doesn't change the position of the light
	glLoadIdentity();
	// multiply the camera matrix
	float matrix[4][4];
	DView* view = dance::AllViews->getViewFocus();
	if( view == NULL ) 
	{
		danceInterp::OutputMessage("There are no views in the system! Can't have a light without a view") ;
		return ;
	}
	view->getCameraTransformation(matrix);

	glMultMatrixf(&matrix[0][0]);
		
	glLightfv(m_ID, GL_POSITION, m_Position); 
	glLightfv(m_ID, GL_DIFFUSE, m_Diffuse);
	glLightfv(m_ID, GL_SPECULAR, m_Specular);
	glLightfv(m_ID, GL_AMBIENT, m_Ambient);
	glLightf(m_ID, GL_CONSTANT_ATTENUATION, this->m_constantAttenuation);
	glLightf(m_ID, GL_LINEAR_ATTENUATION, this->m_linearAttenuation);
	glLightf(m_ID, GL_QUADRATIC_ATTENUATION, this->m_quadraticAttenuation);

	if (this->m_isSpotLight)
	{
		glLightf(m_ID, GL_SPOT_CUTOFF, this->m_spotCutoffAngle);
		glLightfv(m_ID, GL_SPOT_DIRECTION, this->m_spotDirection);
		glLightf(m_ID, GL_SPOT_EXPONENT, this->m_spotExponent);
	}
	else
	{
		glLightf(m_ID, GL_SPOT_CUTOFF, 180.0); // no spotlight
	}

	glEnable(m_ID);
	glPopMatrix();
}

void DLight::getAmbient(GLfloat* ambient)
{
	for (int i = 0; i < 4; i++)
		ambient[i] = m_Ambient[i];
}

void DLight::getDiffuse(GLfloat* diffuse)
{
	for (int i = 0; i < 4; i++)
		diffuse[i] = m_Diffuse[i];
}

void DLight::getSpecular(GLfloat* specular)
{
	for (int i = 0; i < 4; i++)
		specular[i] = m_Specular[i];
}

void DLight::getPosition(GLfloat* position)
{
	for (int i = 0; i < 4; i++)
		position[i] = m_Position[i];
}

void DLight::setAmbient(GLfloat* ambient)
{
	for (int i = 0; i < 4; i++)
		m_Ambient[i] = ambient[i];
	this->init();
}

void DLight::setDiffuse(GLfloat* diffuse)
{
	for (int i = 0; i < 4; i++)
		m_Diffuse[i] = diffuse[i];
	this->init();
}

void DLight::setSpecular(GLfloat* specular)
{
	for (int i = 0; i < 4; i++)
		m_Specular[i] = specular[i];
	this->init();
}

void DLight::setPosition(GLfloat* position)
{
	for (int i = 0; i < 4; i++)
		m_Position[i] = position[i];
	this->init();
}

Widget* DLight::getInterface()
{
	if (m_lightWindow == NULL)
	{
		m_lightWindow = new LightWindow(this, -1, -1, -1, -1, this->getName());
	}

	return m_lightWindow;
}

GLenum DLight::getLightID()
{
	return m_ID;
}


void DLight::setDirectional(bool val)
{
	this->m_isDirectional = val;
	if (val)
	{
		this->m_Position[3] = 0.0;
		// directional lights may not be spotlights
		this->m_isSpotLight = false;
	}
	else
	{
		this->m_Position[3] = 1.0;
	}

	this->init();
}

bool DLight::isDirectional()
{
	return this->m_isDirectional;
}

void DLight::setSpotlight(bool val)
{
	this->m_isSpotLight = val;
	if (val)
	{
		if (this->m_spotCutoffAngle < 0)
			this->m_spotCutoffAngle = 0;
		else if (this->m_spotCutoffAngle > 90)
			this->m_spotCutoffAngle = 90;
	}
	else
	{
			this->m_spotCutoffAngle = 180;
	}
	this->init();
}

bool DLight::isSpotlight()
{
	return this->m_isSpotLight;
}

void DLight::setSpotDirection(GLfloat dir[3])
{
	this->m_spotDirection[0] = dir[0];
	this->m_spotDirection[1] = dir[1];
	this->m_spotDirection[2] = dir[2];
	this->init();
}

void DLight::getSpotDirection(GLfloat dir[3])
{
	dir[0] = this->m_spotDirection[0];
	dir[1] = this->m_spotDirection[1];
	dir[2] = this->m_spotDirection[2];
}

void DLight::setSpotCutoffAngle(double val)
{
	this->m_spotCutoffAngle = (GLfloat) val;
	this->init();
}

double DLight::getSpotCutoffAngle()
{
	return this->m_spotCutoffAngle;
}

void DLight::setConstantAttentuation(double val)
{
	this->m_constantAttenuation = (GLfloat) val;
	this->init();
}

double DLight::getConstantAttentuation()
{
	return this->m_constantAttenuation;
}

void DLight::setLinearAttentuation(double val)
{
	this->m_linearAttenuation = (GLfloat) val;
	this->init();
}

double DLight::getLinearAttentuation()
{
	return this->m_linearAttenuation;
}

void DLight::setQuadraticAttentuation(double val)
{
	this->m_quadraticAttenuation = (GLfloat) val;
	this->init();
}

double DLight::getQuadraticAttentuation()
{
	return this->m_quadraticAttenuation;
}

void DLight::setSpotExponent(double val)
{
	m_spotExponent = (GLfloat) val;
	this->init();
}

double DLight::getSpotExponent()
{
	return m_spotExponent;
}

void DLight::setRelativeToCamera(bool val)
{
	this->m_isRelativeToCamera = val;
	this->init();
}

bool DLight::isRelativeToCamera()
{
	return this->m_isRelativeToCamera;
}

void DLight::showStatus()
{
	for (int x = 0; x < dance::AllLights->size(); x++)
	{
		DLight* light = (DLight*) dance::AllLights->get(x);
		if (glIsEnabled(light->getLightID()))
		{
			danceInterp::OutputMessage("Light %s (OpenGL enum %d) is enabled.", getName(), getLightID());
			GLfloat params[4];
			glGetLightfv(getLightID(), GL_AMBIENT, params);
			danceInterp::OutputMessage("Ambient is %f %f %f %f", params[0], params[1], params[2], params[3]);
			glGetLightfv(getLightID(), GL_DIFFUSE, params);
			danceInterp::OutputMessage("Diffuse is %f %f %f %f", params[0], params[1], params[2], params[3]);
			glGetLightfv(getLightID(), GL_SPECULAR, params);
			danceInterp::OutputMessage("Specular is %f %f %f %f", params[0], params[1], params[2], params[3]);
			glGetLightfv(getLightID(), GL_POSITION, params);
			danceInterp::OutputMessage("Position is %f %f %f %f", params[0], params[1], params[2], params[3]);
			glGetLightfv(getLightID(), GL_SPOT_DIRECTION, params);
			danceInterp::OutputMessage("Spot direction is %f %f %f", params[0], params[1], params[2]);
			glGetLightfv(getLightID(), GL_SPOT_EXPONENT, params);
			danceInterp::OutputMessage("Spot exponent is %f", params[0]);
			glGetLightfv(light->getLightID(), GL_SPOT_CUTOFF, params);
			danceInterp::OutputMessage("Spot Cutoff is %f", params[0]);
			glGetLightfv(light->getLightID(), GL_CONSTANT_ATTENUATION, params);
			danceInterp::OutputMessage("Constant Attentuation is %f", params[0]);
			glGetLightfv(light->getLightID(), GL_LINEAR_ATTENUATION, params);
			danceInterp::OutputMessage("Linear Attenuation is %f", params[0]);
			glGetLightfv(light->getLightID(), GL_QUADRATIC_ATTENUATION, params);
			danceInterp::OutputMessage("Quadratic Attenuation is %f", params[0]);
		}
		else
		{
			danceInterp::OutputMessage("Light %s (OpenGL enum %d) is not enabled.", light->getName(), light->getLightID());
		}
	}
}


// Writes the source properties into the file
void DLight::render(int argc, char ** argv, std::ofstream & file)
{
	float lightPos[4];
	float lightDiffuse[4];
	

	if (argc > 0 && strcmp(argv[0],"povray") == 0)
	{
#ifdef _DEBUG
		file << "/* DLight: \n";
		//this->write_properties(file);
		file << "*/\n\n";
#endif

		file << "\nlight_source {";
		getPosition(lightPos);
		write_vector(file, lightPos, 3, VPOVRAY);
		
		// it seems opengl lights are too bright for povray
		file << " color rgb .9*";

		getDiffuse(lightDiffuse);
		write_vector(file, lightDiffuse, 3, VPOVRAY);


//		getAmbient(lightAmbient);
//		getSpecular(lightSpecularity);			

		
		switch(m_Type)
		{
		case ePoint:			
			break;
		case eAmbient:
			file << "\nshadowless"; 
			break;
		case eDirectional:
			file << "\nparallel";
			file << "\npoint_at ";
			write_vector(file, m_spotDirection, 3, VPOVRAY);
			break;
		case eSpotLight:
			file << "\nspotlight";
			file << "\npoint_at ";
			write_vector(file, m_spotDirection, 3, VPOVRAY);
			file << "\nradius " << m_spotCutoffAngle;
			file << "\nfalloff " << m_spotCutoffAngle;
			file << "\ntightness " << m_spotExponent;
			break;
		default:
			break;
		}

		file << "\n}\n\n";

	}
}

void DLight::save(int mode, std::ofstream& file)
{
	DObject::save(mode, file);

	if (mode == 0)
	{
		// instantiate the light
		file << "dance.instance(\"light\", \"" << this->getName() << "\")" << endl;
	}
	else if (mode == 1)
	{
		GLfloat val[4];
		char buff[256];

		// position
		this->getPosition(val);
		sprintf(buff, "\"position\", %f, %f, %f, %f", val[0], val[1], val[2], val[3]);
		pythonSave(file, buff);

		// diffuse
		this->getDiffuse(val);
		sprintf(buff, "\"diffuse\", %f, %f, %f, %f", val[0], val[1], val[2], val[3]);
		pythonSave(file, buff);

		// specular
		this->getSpecular(val);
		sprintf(buff, "\"specular\", %f, %f, %f, %f", val[0], val[1], val[2], val[3]);
		pythonSave(file, buff);

		// ambient
		this->getAmbient(val);
		sprintf(buff, "\"ambient\", %f, %f, %f, %f", val[0], val[1], val[2], val[3]);
		pythonSave(file, buff);
;

		// is the light visible?
		if (this->isVisible())
		{
			sprintf(buff, "\"visible\", \"on\"");
		}
		else
		{
			sprintf(buff, "\"visible\", \"off\"");
		}
		pythonSave(file, buff);

		// directional
		if (this->isDirectional())
		{
			sprintf(buff, "\"directional\", \"on\"");
		}
		else
		{
			sprintf(buff, "\"directional\", \"off\"");
		}
		pythonSave(file, buff);


		// spotlight?
		if (this->isSpotlight())
		{
			sprintf(buff, "\"spotlight\", \"on\"");
			pythonSave(file, buff);

			// spotlight direction
			this->getSpotDirection(val);
			sprintf(buff, "\"spotlight_direction\", %f, %f, %f", val[0], val[1], val[2]);
			pythonSave(file, buff);

			// spotlight exponent
			sprintf(buff, "\"spotlight_exponent\", %f", this->getSpotExponent());
			pythonSave(file, buff);

			// spotlight cutoff angle
			sprintf(buff, "\"spotlight_cutoff_angle\", %f", this->getSpotCutoffAngle());
			pythonSave(file, buff);

		}
		else
		{
			sprintf(buff, "\"spotlight\", \"off\"");
			pythonSave(file, buff);
		}

		// constant attentuation
		sprintf(buff, "\"constant_attentuation\", %f", this->getConstantAttentuation());
		pythonSave(file, buff);

		// linear attentuation
		sprintf(buff, "\"linear_attentuation\", %f", this->getLinearAttentuation());
		pythonSave(file, buff);

		// quadratic attentuation
		sprintf(buff, "\"quadratic_attentuation\", %f", this->getQuadraticAttentuation());
		pythonSave(file, buff);

	}
}

