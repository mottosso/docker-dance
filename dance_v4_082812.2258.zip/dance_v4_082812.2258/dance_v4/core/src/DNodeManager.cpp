#include "DNodeManager.h"

DNodeManager::DNodeManager()
{
}

DNodeManager::~DNodeManager()
{
}

void DNodeManager::setRoot(DNode* node)
{
	m_root = node;
}

DNode* DNodeManager::getRoot()
{
	return m_root;
}

