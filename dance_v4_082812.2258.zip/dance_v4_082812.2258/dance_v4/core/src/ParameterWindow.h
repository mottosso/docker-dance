/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef PARAMETERWINDOW_H
#define PARAMETERWINDOW_H

#include "defs.h"

#include <fltk/Window.h>
#include <fltk/TabGroup.h>
#include <fltk/Button.h>
#include <vector>
#include "FloatingParameterWindow.h"

class DLLENTRY ParameterWindow : public fltk::Group
{
	public:
		ParameterWindow(int x, int y, int w, int h, const char* name);

		void addInterface(fltk::Widget* panel, const char* name);
		void removeInterface(fltk::Widget* panel);

		void floatInterface(fltk::Widget* panel);
		void dockInterface(fltk::Widget* panel);

		int getNumTabInterfaces();
		Widget* getTabInterface(int num);
		int getNumFloatingInterfaces();
		Widget* getFloatingInterface(int num);

		static void floatwidget_cb(fltk::Widget* w, void* data);
		static void selectwidget_cb(fltk::Widget* w, void* data);
		static void removewidget_cb(fltk::Widget* w, void* data);

		fltk::TabGroup* tabGroup;
		fltk::Button* buttonFloat;
		fltk::Button* buttonRemove;
		fltk::Button* buttonSelect;

		std::vector<FloatingParameterWindow*> floatingWindows;


};


#endif
