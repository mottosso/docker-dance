#ifndef DCONNECTION_H
#define DCONNECTION_H
#include "defs.h"

#include <string>

class DObject;

class DLLEXPORT DConnection
{
	public:
		DConnection();
		~DConnection();

		DObject* getFrom();
		void setFrom(DObject* object);
		DObject* getTo();
		void setTo(DObject* object);

		void setType(std::string type);
		std::string getType();
	
	protected:
		std::string m_type;
		DObject* m_from;
		DObject* m_to;
};


#endif


