/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef SELECTIONWINDOW_H
#define SELECTIONWINDOW_H
#include <vector>
#include "DObject.h"
#include <fltk/Window.h>
#include <fltk/glut.h>

#include <fltk/Box.h>
#include <fltk/MultiBrowser.h>
#include <fltk/Button.h>
#include <fltk/CheckButton.h>
#include <fltk/Input.h>

class DLLENTRY SelectionWindow : public fltk::Window
{
public:
	SelectionWindow(int,int,int,int, const char*);
	~SelectionWindow();

	void resize(int,int,int,int);
	uchar type() const;

	static const uchar SELECTIONWINDOWTYPE = uchar(260);

	void show();

private:
	
	const static int ACTUATOR = 0;
	const static int GEOMETRY = 1;
	const static int LIGHT = 2;
	const static int SIMULATOR = 3;
	const static int SYSTEM = 4;
	const static int VIEW = 5;
	const static int MODIFIER = 6;
	const static int RENDERER = 7;
	const static int GENERIC = 8;

	void init();
	void KeyboardCB(unsigned char key, int x, int y);
	void addObjectToBrowser(DObject* obj);
	void addObjectToBrowserWithDependency(DObject* obj);
	void removeAllObjects();
	void updateObjects();
	DObject* getObjectFromWidget(Widget* w);

	fltk::MultiBrowser* browser;
	fltk::FlatBox* box;
	fltk::Button* button;
	fltk::CheckButton* checkButton[9];
	fltk::Button* buttonChangeName;
	fltk::CheckButton* checkDependencies;
	fltk::Input* inputObject;
	fltk::Input* inputType;

	//memory of previous state
	bool is_checked[9];

	//callbacks
	static void types_all_cb(fltk::Widget* o, void* p);
	static void types_none_cb(fltk::Widget* o, void* p);
	static void types_invert_cb(fltk::Widget* o, void* p);
	static void objects_all_cb(fltk::Widget* o, void* p);
	static void objects_none_cb(fltk::Widget* o, void* p);
	static void objects_invert_cb(fltk::Widget* o, void* p);
	static void select_cb(fltk::Widget* o, void* p);
	static void cancel_cb(fltk::Widget* o, void* p);
	static void type_check_button_cb(fltk::Widget* o, void* p);
	static void delete_cb(fltk::Widget* widget, void* data);
	static void rename_cb(fltk::Widget* widget, void* data);
	static void objectcompleter_cb(fltk::Widget* widget, void* data);
	static void typecompleter_cb(fltk::Widget* widget, void* data);

	std::vector<std::string> matchingObjects;
	void setMatchingObjects(std::string partial);
}
;

#endif
