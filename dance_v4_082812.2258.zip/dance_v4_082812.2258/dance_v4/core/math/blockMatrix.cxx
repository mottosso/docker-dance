/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include <assert.h>
#include "blockMatrix.h"
#include <string>

int BlockMatrix::verb = 0;

BlockMatrix::BlockMatrix() {
  
  blockRow = blockCol = 0;

}

BlockMatrix::~BlockMatrix() {
  
  clear();
}

void BlockMatrix::setSize(int br, int bc, int r, int c) {
  
  int i;
  blockList bList;

  clear();
  rowList.clear();
  colList.clear();
  
  blockRow = br;
  blockCol = bc;
  
  for (i=0 ; i < r ; i++) {
    rowList.push_back(bList);
  }
  
  for (i=0 ; i < c ; i++) {
    colList.push_back(bList);
  }
}

bool BlockMatrix::isEmpty() {
  
  unsigned int i;
  
  for (i=0 ; i < rowList.size() ; i++) {
    if (!rowList[i].empty()) {
      return false;
    }
  }

  return true;
}

void BlockMatrix::zeroBlocks() {
  
  unsigned int i;
  blockListIt it;
  
  for (i=0 ; i < rowList.size() ; i++) {
    for (it=rowList[i].begin() ; it != rowList[i].end() ; it++) {
      (*it)->mat.clear();
    }
  }
  
}

void BlockMatrix::clear() {
  
  unsigned int i;
  blockListIt it;

  // first delete all the Block data structures

  for (i=0 ; i < rowList.size() ; i++) {
    for (it=rowList[i].begin() ; it != rowList[i].end() ; it++ ) {
      delete (*it);
    }
  }

  // erase all the row linked lists
  for (i=0 ; i < rowList.size() ; i++) {
    rowList[i].clear();
  }

  // erase all the col linked lists
  for (i=0 ; i < colList.size() ; i++) {
    colList[i].clear();
  }

}

const BlockMatrix::_Block* BlockMatrix::getBlock(int row, int col) const {
  
  cBlockListIt it;
  
  for (it=rowList[row].begin() ; it!=rowList[row].end() ; it++) {
    if ((*it)->col==col) {
      return (*it);
    }
    if ((*it)->col>col) {
      break;
    }
  }

  return 0;

}

BlockMatrix::_Block* BlockMatrix::getBlock(int row, int col) {
  
  blockListIt it;
  
  for (it=rowList[row].begin() ; it!=rowList[row].end() ; it++) {
    if ((*it)->col==col) {
      return (*it);
    }
    if ((*it)->col>col) {
      break;
    }
  }

  return 0;
}

BlockMatrix::_Block* BlockMatrix::addBlock(int row, int col) {
  
  _Block* result;
  blockListIt rowIt, colIt;

  result = getBlock(row, col);

  if (result) {
    return result;
  }

  result = new _Block;
  result->mat.setSize(blockRow, blockCol);
  
  result->row = row;
  result->col = col;
  
  // setup the iterators to point to the insertion points
  
  if (rowList[row].empty()) {
    rowIt = rowList[row].begin();
  } else {
    for(rowIt=rowList[row].begin() ; rowIt!=rowList[row].end() ; rowIt++) {
      if ((*rowIt)->col>=col) {
	break;
      }
    }
  }

  if (colList[col].empty()) {
    colIt = colList[col].begin();
  } else {
    for (colIt=colList[col].begin() ; colIt != colList[col].end() ; colIt++) {
      if ((*colIt)->row>=row) {
	break;
      }
    }
  }
  
  rowList[row].insert(rowIt, result);
  colList[col].insert(colIt, result);

  return result;
}

void BlockMatrix::dumpBlockPattern() {
  
  unsigned int i, j;
  _Block *bl;
  std::string str;
  char buf[64];

  for (i=0 ; i < rowList.size() ; i++) {
    str = "";
    for (j=0 ; j < colList.size() ; j++) {
      bl = getBlock(i, j);
      if (bl) {
	sprintf(buf, "j%d.%d ", i, j);
      } else {
	sprintf(buf, "**** ");
      }
      str += buf;
    }
    
//    danceInterp::OutputMessage((char*)str.c_str());
  }

}
void BlockMatrix::printInterp(const char *fmt) {
  
  unsigned int bi, bj;
  int i, j;
  std::string buf;
  static char tmp[256];
  _Block *currBlock;

  for (bi=0 ; bi < rowList.size() ; bi++) {

    for (i=0 ; i < blockRow ; i++) {

      buf = "";
      for (bj = 0 ; bj < colList.size() ; bj++) {

	currBlock = getBlock(bi, bj);
	
	buf += "| ";
	if (!currBlock) {
	  for (j=0 ; j < blockCol ; j++) {
	    sprintf(tmp, "x ");
	    buf += tmp;
	  }
	} else {
	  for (j=0 ; j < blockCol ; j++) {
	    //sprintf(tmp, "%e ", currBlock->mat.elem(i, j));
	    //sprintf(tmp, "%f ", currBlock->mat.elem(i, j));
	    sprintf(tmp, fmt, currBlock->mat.elem(i, j));
	    buf += tmp;
	  }
	}
	
      }
      buf += "|";
//      danceInterp::OutputMessage((char*)buf.c_str());
    }
    
//    danceInterp::OutputMessage("---------------");
  }
}

void BlockMatrix::dumpRow(int row) {
 
fprintf(stderr,"Commented out by Petros, It does not compile on osx") ;

assert(false) ; 
//  blockListIt it;
 // std::string buf;
  //static char tmp[64];
//
 // sprintf(tmp, "Row %d: ", row);
  //buf = tmp;
//
 // for (it=rowList[row].begin() ; it != rowList[row].end() ; it++) {
  //  sprintf(tmp, "col %d at %x | ", (*it)->col, (int) (*it));
   // buf += tmp;
  //}
//  danceInterp::OutputMessage((char*)buf.c_str());

}

void BlockMatrix::dumpCol(int col) {

fprintf(stderr,"Commented out by Petros, It does not compile on osx") ;

assert(false) ;

//  blockListIt it;
 // std::string buf;
  //static char tmp[64];

  //sprintf(tmp, "Col %d: ", col);
 // buf = tmp;

  //for (it=colList[col].begin() ; it != colList[col].end() ; it++) {
   // sprintf(tmp, "row %d at %x | ", (*it)->row, (int) (*it));
   // buf += tmp;
 // }
//  danceInterp::OutputMessage((char*)buf.c_str());
  
}

void BlockMatrix::removeBlock(int row, int col) {
  
  blockListIt itRow, itCol;
  
  for (itRow=rowList[row].begin() ; itRow != rowList[row].end() ; itRow++) {
    if ((*itRow)->col==col) {
      break;
    }
    if ((*itRow)->col>col) {
      // failed
      return;
    }
  }

  for (itCol = colList[col].begin() ; itCol != colList[col].end() ; itCol++) {
    if ((*itCol)->row==row) {
      break;
    }
    
    if ((*itCol)->row>row) {
      // failed
      return;
    }
  }

  delete (*itRow);
  
  rowList[row].erase(itRow);
  colList[col].erase(itCol);

}

void BlockMatrix::copyBlocks(BlockMatrix &to) const {
  
  unsigned int row;
  cBlockListIt it;

  to.setSize(blockRow, blockCol, rowList.size(), colList.size());
  
  for(row=0 ; row < rowList.size() ; row++) {
    for (it=rowList[row].begin() ; it != rowList[row].end() ; it++) {
      to.addBlock((*it)->row, (*it)->col);
    }
  }
}

void BlockMatrix::copyBlocksTransp(BlockMatrix &to) const {
  
  unsigned int row;
  cBlockListIt it;
  
  to.setSize(blockCol, blockRow, colList.size(), rowList.size());
  
  for (row=0 ; row < rowList.size() ; row++) {
    for (it=rowList[row].begin() ; it != rowList[row].end() ; it++) {
      to.addBlock((*it)->col, (*it)->row);
    }
  }
}

void BlockMatrix::preConditionProductTransp(const BlockMatrix &rMat,
					    const BlockMatrix &tMat) {
  
  
  unsigned int r, c, def;
  int i;

  if (rMat.blockCol != tMat.blockCol) {
//    danceInterp::OutputMessage("BlockMatrix::preConditionProductTransp block row/col mismatch");
    return;
  }

  if (rMat.getCol() != tMat.getCol()) {
//    danceInterp::OutputMessage("BlockMatrix::preConditionProductTransp row/col mismatch");
    return;
  }
  
  setSize(rMat.blockRow, tMat.blockRow, rMat.getRow(), tMat.getRow());
  
  for (r=0 ; r < rowList.size() ; r++) {
    for (c=0 ; c < colList.size() ; c++) {

      def = 0;
      
      for (i=0 ; i < rMat.getCol() ; i++) {
	if (rMat.getBlock(r, i) && tMat.getBlock(c, i)) {
	  def = 1;
	  break;
	}
      }
      
      if (def) {
	addBlock(r, c)->mat.clear();
      }
    }
  }
}


void BlockMatrix::preConditionProduct(const BlockMatrix &a, 
				      const BlockMatrix &b) {
  
  unsigned int r, c, def;
  int i;

  if (a.blockCol!=b.blockRow) {
//    danceInterp::OutputMessage("BlockMatrix::preConditionProduct block row/col mismatch");
    return;
  }

  if (a.getCol() != b.getRow()) {
//    danceInterp::OutputMessage("BlockMatrix::preConditionProduct row/col mismatch");
    return;
  }

  setSize(a.blockRow, b.blockCol, a.getRow(), b.getCol());
  
  // create the blocks that are defined
  
  for (r=0 ; r < rowList.size() ; r++) {
    for (c=0 ; c < colList.size() ; c++) {
      def = 0;
      
      for (i=0 ; i < a.getCol() ; i++) {
	if (a.getBlock(r, i) && b.getBlock(i, c)) {
	  def = 1;
	  break;
	}
      }
      if (def) {
	addBlock(r, c)->mat.clear();
      }
    }
  }
}

char* BlockMatrix::getDim() {
  
  static char buf[128];
  
  sprintf(buf, "blockDim %d %d rowCol %d %d", blockRow, blockCol, 
	  rowList.size(), colList.size());
  
  return buf;
}

void BlockMatrix::multTransp(BlockMatrix &to, const BlockMatrix &from, 
			     ArbMatrix &mat) const {
  
  unsigned int r, c;
  int i;
  _Block *bl;
  const _Block *blA, *blB;
  
  for (r=0 ; r < to.rowList.size() ; r++) {
    for (c=0 ; c < to.colList.size() ; c++) {
      
      bl = to.getBlock(r, c);
      
      if (!bl) {
	continue;
      }
      
      bl->mat.clear();
      
      for (i=0 ; i < getCol() ; i++) {
	blA = getBlock(r, i);
	blB = from.getBlock(c, i);
	
	if (blA && blB) {
	  blA->mat.multTransp(mat, blB->mat);
	  bl->mat += mat;
	}
      }
    }
  }
}

void BlockMatrix::mult(BlockMatrix &to, const BlockMatrix &from, 
		       ArbMatrix &mat) const {
  
  unsigned int r, c;
  int i;
  _Block *bl;
  const _Block *blA, *blB;

  for (r=0 ; r < to.rowList.size() ; r++) {
    for (c = 0 ; c < to.colList.size(); c++) {
      bl = to.getBlock(r, c);
      if (!bl) {
	continue;
      }
      
      bl->mat.clear();

      for (i=0 ; i < getCol() ; i++) {
	blA = getBlock(r, i);
	blB = from.getBlock(i, c);
	
	if (blA&&blB) {
	  blA->mat.multResize(mat, blB->mat);
	  bl->mat += mat;
	}
      }
    }
  }
}

void BlockMatrix::dumpDiagonal(ArbVector &to) const {
  
  int row, col, i, s;
  const _Block *bl;

  if (blockRow==blockCol) {
    
    row = rowList.size();
    col = colList.size();

    s = row<col?row:col;

    for (i=0 ; i < s ; i++) {
      bl = getBlock(i, i);
      if (bl) {
	bl->mat.dumpDiagonal(to, i*blockRow);
      }
    }
    
    return;
  }

//  danceInterp::OutputMessage("BlockMatrix::dumpDiagonal for block row/col %d/%d", 
//			  blockRow, blockCol);
}

void BlockMatrix::multTransp(ArbVector &to, double *from) const {

  unsigned int col;
  int i, j;
  int rOffset, cOffset;
  cBlockListIt it;
  const _Block *bl;

  if (int(to.size())<int(blockCol*colList.size())) {
//    danceInterp::OutputMessage("BlockMatrix::multTransp colsize mismatch");
  }

  to.clear();

  for (col=0 ; col < colList.size() ; col++) {
    
    cOffset = col*blockCol;

    for (it=colList[col].begin() ; it != colList[col].end() ; ++it) {
      bl = (*it);

      rOffset = bl->row*blockRow;

      for (i=0 ; i < blockCol ; i++) {
	for (j=0 ; j < blockRow ; j++) {
	  to[cOffset+i] += from[rOffset+j]*bl->mat.elem(j, i);
	}
      }
    }
  }
}

void BlockMatrix::multTransp(ArbVector &to, const ArbVector &from) const {

  unsigned int col;
  int i, j;
  int rOffset, cOffset;
  cBlockListIt it;
  const _Block *bl;

  if (int(to.size()) < int(blockCol*colList.size())) {
//    danceInterp::OutputMessage("BlockMatrix::multTransp colsize mismatch");
  }

  to.clear();

  for (col=0 ; col < colList.size() ; col++) {
    
    cOffset = col*blockCol;

    for (it=colList[col].begin() ; it != colList[col].end() ; ++it) {
      bl = (*it);

      rOffset = bl->row*blockRow;

      for (i=0 ; i < blockCol ; i++) {
	for (j=0 ; j < blockRow ; j++) {
	  to[cOffset+i] += from[rOffset+j]*bl->mat.elem(j, i);
	}
      }
    }
  }
}

void BlockMatrix::mult(ArbVector &to, const ArbVector &from) const {
  
  unsigned int row;
  int i, j;
  int rOffset, cOffset;
  cBlockListIt it;
  const _Block *bl;

  if (int(to.size())<int(blockRow*rowList.size())) {
//    danceInterp::OutputMessage("BlockMatrix::multTransp rowsize mismatch");
  }

  to.clear();

  for (row=0 ; row < rowList.size() ; row++) {
    
    rOffset = row*blockRow;

    for (it=rowList[row].begin() ; it != rowList[row].end() ; it++) {
      bl = (*it);

      cOffset = bl->col*blockCol;

      for (i=0 ; i < blockRow ; i++) {
	for (j=0 ; j < blockCol ; j++) {
	  to[rOffset+i] += from[cOffset+j]*bl->mat.elem(i, j);
	}
      }
    }
  }
}

void BlockMatrix::mult(ArbVector &to, double *from) const {
  
  unsigned int row;
  int i, j;
  int rOffset, cOffset;
  cBlockListIt it;
  const _Block *bl;

  if (int(to.size())<int(blockRow*rowList.size())) {
//    danceInterp::OutputMessage("BlockMatrix::multTransp rowsize mismatch");
  }

  to.clear();

  for (row=0 ; row < rowList.size() ; row++) {
    
    rOffset = row*blockRow;

    for (it=rowList[row].begin() ; it != rowList[row].end() ; it++) {
      bl = (*it);

      cOffset = bl->col*blockCol;

      for (i=0 ; i < blockRow ; i++) {
	for (j=0 ; j < blockCol ; j++) {
	  to[rOffset+i] += from[cOffset+j]*bl->mat.elem(i, j);
	}
      }
    }
  }
}
