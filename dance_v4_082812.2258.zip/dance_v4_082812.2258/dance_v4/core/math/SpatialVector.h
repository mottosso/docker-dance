/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _SPATIALVECTOR_
#define _SPATIALVECTOR_

#include "mathdefs.h"
#include "vectorObj.h"

// Spatial Vector as defined in Robot Dynamics Algorithmsj by
// Roy Featherstone

class VectorObj;

class SpatialVector {
  
 protected:
  
  double vec[6];
  
 public:
  SpatialVector();
  SpatialVector(const VectorObj &angular, const VectorObj &linear);
  ~SpatialVector();

  void clear();
  void assign(double wx, double wy, double wz, 
	      double vx, double vy, double vz);

  void assign(const VectorObj &lineVec, 
	      const VectorObj &freeVec);

  void getLineVector(VectorObj &vec) const;
  void getFreeVector(VectorObj &vec) const;

  void setLineVector(const VectorObj &vec);
  void setFreeVector(const VectorObj &vec);

  inline double* data() { return vec;}
  inline const double* data() const { return vec;}
  
  inline double& operator[](int i) { return vec[i];}
  inline const double operator[](int i) const { return vec[i];}

  //~~~~~~~~ added by alice, summer 05
  inline SpatialVector operator+ (const SpatialVector &sp);
  inline SpatialVector operator- (const SpatialVector &sp);
  inline SpatialVector& operator= (const SpatialVector &sp);
  inline SpatialVector operator* (const double a);
  inline SpatialVector& operator+= (const SpatialVector &sp);
  void print();
  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
};

inline SpatialVector SpatialVector::operator+ (const SpatialVector &sp)
{
	SpatialVector temp;
	for ( int i=0; i<6; i++ )
	{
		temp.vec[i] = vec[i] + sp.vec[i];
	}
	return temp;
}

inline SpatialVector SpatialVector::operator- (const SpatialVector &sp)
{
	SpatialVector temp;
	for ( int i=0; i<6; i++ )
	{
		temp.vec[i] = vec[i] - sp.vec[i];
	}
	return temp;
}

inline SpatialVector& SpatialVector::operator= (const SpatialVector &sp)
{
	for ( int i = 0; i < 6; i++ )
	{
		vec[i] = sp.vec[i];
	}
	return *this;
}

inline SpatialVector SpatialVector::operator* (const double a)
{
	SpatialVector temp;
	for ( int i=0; i<6; i++ )
	{
		temp.vec[i] = vec[i] * a;
	}
	return temp;
}

inline SpatialVector& SpatialVector::operator+= (const SpatialVector &sp)
{
	for ( int i = 0; i < 6; i++ )
	{
		vec[i] = vec[i] + sp.vec[i];
	}
	return *this;
}

#endif

