/**************************************************

Copyright 2005 by Ari Shapiro and Petros Faloutsos



DANCE

Dynamic ANimation and Control Environment



 ***************************************************************

 ******General License Agreement and Lack of Warranty ***********

 ****************************************************************



This software is distributed for noncommercial use in the hope that it will 

be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility

to anyone for the consequences	of using it or for whether it serves any 

particular purpose or works at all. No warranty is made about the software 

or its performance. Commercial use is prohibited. 



Any plugin code written for DANCE belongs to the developer of that plugin,

who is free to license that code in any manner desired.



Content and code development by third parties (such as FLTK, Python, 

ImageMagick, ODE) may be governed by different licenses.

You may modify and distribute this software as long as you give credit 

to the original authors by including the following text in every file 

that is distributed:

*/

/*********************************************************

	Copyright 2005 by Ari Shapiro and Petros Faloutsos



	DANCE

	Dynamic ANimation and Control Environment

	-----------------------------------------

	AUTHOR:

		Ari Shapiro (ashapiro@cs.ucla.edu)

	ORIGINAL AUTHORS: 

		Victor Ng (victorng@dgp.toronto.edu)

		Petros Faloutsos (pfal@cs.ucla.edu)

	CONTRIBUTORS:

		Yong Cao (abingcao@cs.ucla.edu)

		Paco Abad (fjabad@dsic.upv.es)

**********************************************************/



#include "diagonalMatrix.h"

#include "blockMatrix.h"



DiagonalMatrix::DiagonalMatrix() {

  

}





DiagonalMatrix::DiagonalMatrix(int s) {

  

  data.setSize(s);



}



void DiagonalMatrix::setSize(int s) {

  data.setSize(s);

}



DiagonalMatrix& DiagonalMatrix::operator=(double a) {

  

  data = a;

  return *this;



}



void DiagonalMatrix::mult(ArbVector &to, const ArbVector &from) const {

  

  int i;



  if (from.size()!=data.size() || to.size()!=data.size()) {

//    danceInterp::OutputMessage("DiagonalMatrixt::mult size mismatch\n");

  }



  for (i=0 ; i < data.size() ; i++) {

    to[i] = data[i]*from[i];

  }

}



void DiagonalMatrix::multResize(ArbMatrix &to, const ArbMatrix &from) const {

  

  int i, j;



  if (from.getRow() != data.size()) {

//    danceInterp::OutputMessage("DiagonalMatrix::multResize row size mismatch");

  }



  to.setSize(data.size(), from.getCol());

  

  for (i=0 ; i < from.getCol() ; i++) {

    for (j=0 ; j < data.size() ; j++) {

      to.elem(j, i) = data[j] * from.elem(j, i);

    }

  }

}



void DiagonalMatrix::multTransp(BlockMatrix &to,

				const BlockMatrix &from) const {

  

  BlockMatrix::cBlockListIt it;

  BlockMatrix::_Block *bl;



  unsigned int i;



  if (from.getCol()*from.getBlockCol()!=data.size()) {

//    danceInterp::OutputMessage("DiagonalMatrix::multTransp col size mismatch");

  }

  

  // iterate over all the blocks



  for (i=0 ; i < from.rowList.size() ; i++) {

    for (it=from.rowList[i].begin() ; it != from.rowList[i].end() ; it++) {



      // get the corresponding transposed 'to'block for this

      // 'from' block

      // we're not checking for null returned blocks to help in the 

      // debugging process



      bl = to.getBlock((*it)->col, (*it)->row);

      multTransp(bl->mat, (*it)->mat, (*it)->col*from.blockCol);



    }

  }

}



void DiagonalMatrix::multTransp(ArbMatrix &to, const ArbMatrix &from, 

				int offset) const {

  

  int i, j;



  for (i=0 ; i < from.getRow() ; i++) {

    for (j=0 ; j < from.getCol() ; j++) {

      to.elem(j, i) = data[j+offset] * from.elem(i, j);

    }

  }



}



void DiagonalMatrix::multResizeTransp(ArbMatrix &to, 

				      const ArbMatrix &from) const {

  

  int i, j;



  if (from.getCol()!=data.size()) {

//    danceInterp::OutputMessage("DiagonalMatrix::multResizeTransp col size mismatch\n");

  }

  

  to.setSize(data.size(), from.getRow());

  

  for (i=0 ; i < from.getRow() ; i++) {

    for (j=0 ; j < data.size() ; j++) {

      to.elem(j, i) = data[j] * from.elem(i, j);

    }

  }

}



void DiagonalMatrix::printInterp() {

  

  int i, j;

  static char buf[256], tt[64];



  for (i=0 ; i < data.size() ; i++) {

    if (i==0) {

      sprintf(buf, "[ ");

    } else {

      sprintf(buf, "  ");

    }

    for (j=0 ; j < i ; j++) {

      strcat(buf, "0 ");

    }

    

    sprintf(tt, "%f ", data[i]);

    strcat(buf, tt);



    for (j=0 ; j < data.size()-1-i ; j++) {

      strcat(buf, "0 ");

    }

    

    if (i==data.size()-1) {

      strcat(buf, " ]");

    }

    

//    danceInterp::OutputMessage(buf);

  }

}

