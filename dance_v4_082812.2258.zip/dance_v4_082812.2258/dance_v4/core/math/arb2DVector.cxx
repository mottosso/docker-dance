/**************************************************

Copyright 2005 by Ari Shapiro and Petros Faloutsos



DANCE

Dynamic ANimation and Control Environment



 ***************************************************************

 ******General License Agreement and Lack of Warranty ***********

 ****************************************************************



This software is distributed for noncommercial use in the hope that it will 

be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility

to anyone for the consequences	of using it or for whether it serves any 

particular purpose or works at all. No warranty is made about the software 

or its performance. Commercial use is prohibited. 



Any plugin code written for DANCE belongs to the developer of that plugin,

who is free to license that code in any manner desired.



Content and code development by third parties (such as FLTK, Python, 

ImageMagick, ODE) may be governed by different licenses.

You may modify and distribute this software as long as you give credit 

to the original authors by including the following text in every file 

that is distributed:

*/

/*********************************************************

	Copyright 2005 by Ari Shapiro and Petros Faloutsos



	DANCE

	Dynamic ANimation and Control Environment

	-----------------------------------------

	AUTHOR:

		Ari Shapiro (ashapiro@cs.ucla.edu)

	ORIGINAL AUTHORS: 

		Victor Ng (victorng@dgp.toronto.edu)

		Petros Faloutsos (pfal@cs.ucla.edu)

	CONTRIBUTORS:

		Yong Cao (abingcao@cs.ucla.edu)

		Paco Abad (fjabad@dsic.upv.es)

**********************************************************/

#include "arb2DVector.h"

#include "blockMatrix.h"



Arb2DVector::Arb2DVector() {

  

  data = 0;

  row = col = 0;

}



Arb2DVector::~Arb2DVector() {

  

  clearData();

  

}



void Arb2DVector::clearData() {

  

  int i;

  if (data) {

    for (i=0 ; i < row ; i++) {

      delete [] data[i];

    }

  }



  delete [] data;



  data = 0;

}

void Arb2DVector::setSize(int r, int c) {

  

  int i;



  if (r <= row && c <= col) {

    return;

  }

  

  clearData();

  

  row = r;

  col = c;



  data = new double*[row];

  

  for (i=0 ; i < row ; i++) {

    data[i] = new double[col];

  }

}



void Arb2DVector::copy(BlockMatrix &B, int rOffset, int cOffset) {

  

  int r, c, i, j;

  int br, bc, aRow, aCol;

  const BlockMatrix::_Block *bl;



  br = B.getBlockRow();

  bc = B.getBlockCol();



  aRow = B.getRow();

  aCol = B.getCol();



  // iterate over all blocks

  for (r=0 ; r < aRow ; r++) {

    for (c=0 ; c < aCol ; c++) {

      

      bl = B.getBlock(r, c);

      

      // copy the block

      

      if (bl) {

	for (i=0 ; i < br ; i++) {

	  for (j=0 ; j < bc ; j++) {

	    //elem(r*br+i, c*bc+j) = bl->mat.elem(i, j);

	    data[r*br+i+rOffset][c*bc+j+cOffset] = bl->mat.elem(i, j);

	  }

	}

      } else {

	for (i=0 ; i < br ; i++) {

	  for (j=0 ; j < bc ; j++) {

	    //elem(r*br+i, c*bc+j) = 0.0;

	    data[r*br+i+rOffset][c*bc+j+cOffset] = 0.0;

	  }

	}

      }

    }

  }

}



void Arb2DVector::printInterp() {

  

  int i, j;

  std::string str;

  static char buf[256];



  for (i=0 ; i < row ; i++) {

    

    for (j=0 ; j < col ; j++) {

      if (j==0) {

	sprintf(buf, "%f ", data[i][j]);

	str = buf;

      } else {

	sprintf(buf, "%f ", data[i][j]);

	str += buf;

      }

    }

//    danceInterp::OutputMessage((char*)str.c_str());

  }

}



void Arb2DVector::clear() {

  

  int i, j;



  for (i=0 ; i < row ; i++) {

    for (j=0 ; j < col ; j++) {

      data[i][j] = 0;

    }

  }

}

