/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	myMATH_H
#define	myMATH_H

#include "vector.h"
#include "CoordSystem.h"

#include <cmath>

int isZero(double a, double tol = 10e-12) ;

int isZero(float a, float tol = 10e-12) ;

double DNCRandom(double max, double min) ;

double VecLength(double *v, int size) ;
double VecLength2(double *v, int size);
double VecDist(const Vector a, const Vector b) ;
double VecDist_(const Vector a, const Vector b) ;

void calcNormal(Vector *p[],int	nver, Vector v)	;

/*** Point ***/

// void localToWorld( Vector plocal, Vector pworld, CoordSystem   * cs) ;


//void printPoints(double	* geom,	int size, int dim) ;


double	inter(double a,	double b, double t) ;


/**** Array ****/
void copyMatrix44(double to[4][4], double from[4][4]);

void D2ArrayCopy( int n,int m,double *c,double *a) ;

void I2ArrayCopy( int n,int m,int *c,int *a) ;

void transpArray(double to[4][4], double from[4][4]);

double * transpArray(double *at, double	*a, int	n, int m) ;
float *  transpArrayFloat(float *at, float *a, int n, int m) ;

double * addArray(double *c, double *a,	double *b, int n, int m) ;

double * subtractArray(double *c, double *a, double *b,	int n, int m) ;

double * multNumArray( double num, double * a, int n, int m) ;

double * MultNumArray( double *c, double num, double * a, int n, int m)	;

double * multArray(double *c, double *a, double	*b, int	n1, int	m, int n2) ;
float * multArrayf(float *c, float *a, float	*b, int	n1, int	m, int n2) ;

void multArray4x4(double c[4][4], double a[4][4], double b[4][4]);
void multArray4x4(double c[4][4], double a[4][4], double b[16]);

double qT_M_q(double *m, double	*q, int	n) ;

//void printArray( double	*a, int	n, int m) ;

int isDiagonal(double *a,int n)	;

/*************** end array ****************/

double Norm(double q[],	int n) ;

/*** other ***/
double Bernst3(	double x, int i) ;

double dBernst3( double	x, int i) ;

double ddBernst3( double x, int	i) ;

double * EulerIntegr(double dq[], double q[], int n, double dt)	;




/**********************************************
 Rotation using	matrices
 **********************************************/

void rotateCSorigin_mat(CoordSystem *cs, double	rot[3][3]) ;
void rotatePoint_mat(Vector point, double rot[3][3]) ;
void transformPoint_mat(Vector point, double rot[4][4])	;
void transformPoints_mat(Vector *points, int n, Vector	*newpoints, double transmat[4][4]) ;
void rotPoint_mat4(Vector point, double transmat[4][4]) ;
void relativeToFrame(double mat[4][4], double wmat[4][4], double rmat[4][4]);

void XRotatePoints(Vector *points, int npoints, double degrees) ;
void YRotatePoints(Vector *points, int npoints, double degrees) ;
void ZRotatePoints(Vector *points, int npoints, double degrees) ;

void XRotatePoints(float* points, int npoints, double degrees) ;
void YRotatePoints(float* points, int npoints, double degrees) ;
void ZRotatePoints(float* points, int npoints, double degrees) ;

void XRotatePoints(double* points, int npoints, double degrees) ;
void YRotatePoints(double* points, int npoints, double degrees) ;
void ZRotatePoints(double* points, int npoints, double degrees) ;

char * convIntToStr(int frameNumber, char *s) ;

/**********************************************************/

void embedCsInCs(CoordSystem * cs_guest, CoordSystem * cs_host)	;

double *constrTransfMatrixFromCs(double	m[4][4], CoordSystem *cs) ;

double *invSmart4(double inv[4][4], double a[4][4]) ;

double * quatToMat(double q[4],double m[4][4]) ;


void setIdentMat(double *m, int n) ;

void compRotMat4(double c[4][4], double m1[4][4], double m2[4][4]) ;


double *lineIntersection(Vector v1, Vector v2, Vector w1, Vector w2, 
			 Vector intersection, int infinite) ;

/// Y index is ignored.
/// v1 -> v2 is considered infinite if argInfiniteV is true
/// w1 -> w2 is considered infinite if argInfiniteW is true
int lineIntersection2D( Vector outIntersection, 
					    const Vector v1, const Vector v2, bool argInfiniteV, 
						const Vector w1, const Vector w2, bool argInfiniteW );

void SetMatRx(double mat[4][4], double rx);

void SetMatRy(double mat[4][4], double ry);

void SetMatRz(double mat[4][4], double rz);

void TransMatFromScaleRotTrans(double mat[4][4], double sx, double sy, double sz, double rx, double ry, double rz, double tx, double ty, double tz);

void invert_matrix (double A[4][4], double Ainv[4][4]);
void adjoint( double in[4][4], double out[4][4] );
double det4x4( double m[4][4] );
double det3x3( double a1, double a2, double a3, double b1, double b2, double b3, double c1, 
			  double c2, double c3 );
double det2x2( double a, double b, double c, double d);

double degtorad(double deg);
double radtodeg(double rad);


#endif


