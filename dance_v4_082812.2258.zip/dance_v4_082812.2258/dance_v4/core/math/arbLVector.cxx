/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "arbLVector.h"
#include <string>
#include <cfloat>

ArbLVector::ArbLVector() {
  
  _size = 0;
  _data = 0;
}

ArbLVector::ArbLVector(int s) {
  
  _size = s;
  
  _data = new long[_size];

}

ArbLVector::~ArbLVector() {
  
  if (_data) {
    delete [] _data;
  }
}

void ArbLVector::setSize(int s) {
  
  if (_size==s) {
    return;
  }

  if (_data) {
    delete [] _data;
  }
  
  _size = s;
  _data = new long[_size];

}

void ArbLVector::operator*=(long a) {
  int i;
  
  for (i=0 ; i < _size ; i++) {
    _data[i] *= a;
  }
}

void ArbLVector::operator-=(const ArbLVector &a) {
  
  int i;
  
  for (i=0 ; i < _size ; i++) {
    _data[i] -= a[i];
  }
}

void ArbLVector::operator+=(const ArbLVector &a) {
  
  int i;
  
  for (i=0 ; i < _size ; i++) {
    _data[i] += a[i];
  }
}

ArbLVector &ArbLVector::operator=(const ArbLVector &a) {
  int i;
  
  if (_size!=a.size()) {
    setSize(a.size());
  }

  for (i=0 ; i < _size ; i++) {
    _data[i] = a[i];
  }
  
  return *this;
}

ArbLVector& ArbLVector::operator=(long a) {
  int i;
  
  for (i=0 ; i < _size ; i++) {
    _data[i] = a;
  }
  
  return *this;
}

void ArbLVector::clear() {
  int i;
  
  for (i=0 ; i < _size ; i++) {
    _data[i] = 0;
  }
}

bool ArbLVector::operator==(long a) const {
  
  int i;
  
  for (i=0 ; i < _size ; i++) {
    if (_data[i]!=a) {
      return false;
    }
  }

  return true;
}

bool ArbLVector::operator==(const ArbLVector &a) const {
  
  int i;
  
  if (_size!=a.size()) {
    return false;
  }

  for (i=0 ; i < _size ; i++) {
    if (_data[i]!=a[i]) {
      return false;
    }
  }

  return true;
}

void ArbLVector::mult(ArbLVector &to, long sc) {
  
  int i;
  
  for (i=0 ; i < _size ; i++) {
    to[i] = _data[i]*sc;
  }
}

void ArbLVector::writeTo(long *to) {
  int i;
  
  for (i=0 ; i < _size ; i++) {
    to[i] = _data[i];
  }
}

void ArbLVector::printInterp(const char *disp) {
  
  char Buf[64];
  int i;
  std::string buf;
  
  buf = "[ ";
  for (i=0; i < _size ; i++) {
    sprintf(Buf, disp, _data[i]);
    buf += Buf;
  }

  buf += "]";
  
//  danceInterp::OutputMessage((char*)buf.c_str());

}

bool ArbLVector::isNan() const {
  
  return false;
}
