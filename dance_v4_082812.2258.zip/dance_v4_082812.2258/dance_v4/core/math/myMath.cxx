/**************************************************

Copyright 2005 by Ari Shapiro and Petros Faloutsos



DANCE

Dynamic ANimation and Control Environment



 ***************************************************************

 ******General License Agreement and Lack of Warranty ***********

 ****************************************************************



This software is distributed for noncommercial use in the hope that it will 

be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility

to anyone for the consequences	of using it or for whether it serves any 

particular purpose or works at all. No warranty is made about the software 

or its performance. Commercial use is prohibited. 



Any plugin code written for DANCE belongs to the developer of that plugin,

who is free to license that code in any manner desired.



Content and code development by third parties (such as FLTK, Python, 

ImageMagick, ODE) may be governed by different licenses.

You may modify and distribute this software as long as you give credit 

to the original authors by including the following text in every file 

that is distributed:

*/

/*********************************************************

	Copyright 2005 by Ari Shapiro and Petros Faloutsos



	DANCE

	Dynamic ANimation and Control Environment

	-----------------------------------------

	AUTHOR:

		Ari Shapiro (ashapiro@cs.ucla.edu)

	ORIGINAL AUTHORS: 

		Victor Ng (victorng@dgp.toronto.edu)

		Petros Faloutsos (pfal@cs.ucla.edu)

	CONTRIBUTORS:

		Yong Cao (abingcao@cs.ucla.edu)

		Paco Abad (fjabad@dsic.upv.es)

**********************************************************/

#include <cstdlib>

#include "mathdefs.h"

#include "myMath.h"



#define	EPSI	 (1.0e-6)

#define	MAX_ITER  100



int isZero(double a, double tol)

{

	if( fabs(a) < tol ) return 1 ;

	else return 0 ;

}



int isZero(float a, float tol)

{

	if( fabs(a) < tol ) return 1 ;

	else return 0 ;

}





int converg(double *x,double *x1, int n) ;





double VecLength(double *v, int size)

{

    double sum = 0 ;

    for( int i = 0 ; i < size ; i++)

		sum += v[i]*v[i] ;



	return sqrt(sum) ;

}



double VecLength2(double *v, int size)

{

    double sum = 0 ;

    for( int i = 0 ; i < size ; i++)

		sum += v[i]*v[i] ;

    return sum;

}



double VecDist(const Vector a, const Vector b)

{

	return sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2]));

}



double VecDist_(const Vector a, const Vector b)

{

	return sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2]));

}



/*************************************

  calcNormal()

  DOES:	calculates the normal given an array of	POINTERS to vectors

************************************/

void calcNormal(Vector *p[],int	nver, Vector n)

{

    int	i,j ;

    double *pi,*pj ;



    for( i = 0,j = 1 ; i < nver-1 ; i++,j++ )

    {



	pi = *p[i] ;

	pj = *p[j] ;



	n[0] +=	(pi[1]-pj[1])*(pi[2] + pj[2]) ;

	n[1] +=	(pi[2]-pj[2])*(pi[0] + pj[0]) ;

	n[2] +=	(pi[0]-pj[0])*(pi[1] + pj[1]) ;

    }

    pi = *p[i] ;

    pj = *p[0] ;

    n[0] += (pi[1]-pj[1])*(pi[2] + pj[2]) ;

    n[1] += (pi[2]-pj[2])*(pi[0] + pj[0]) ;

    n[2] += (pi[0]-pj[0])*(pi[1] + pj[1]) ;

    VecNormalize(n) ;

    return ;

}





/*

void

printPoints(double * geom, int size, int dim)

{

	int	i,j ;



	for( i = 0 ; i < size ;	i++)

	{

		for( j = 0 ; j < dim ; j++ )

			printf("%f ", *(geom+i*dim+j)) ;

		printf("\n") ;

	}

}

*/

double

inter(double a,	double b, double t)

{

	return a*(1.0-t)+b*t ;

}



/**** Array Functions ***/



void copyMatrix44(double to[4][4], double from[4][4])

{

	for (int i = 0 ; i < 4 ; i++)

		for (int j = 0 ; j < 4 ; j++)

			to[i][j] = from[i][j];

}





void D2ArrayCopy( int n,int m,double *c,double *a)

{

	int i, j ;



	for( i = 0 ; i < n ; i++)

		for( j = 0 ; j < m ; j++)

			*(c+i*m+j) = *(a+i*m+j)	;

	return ;

}



void I2ArrayCopy( int n, int m,	int *c,	int *a)

{

    int	i, j ;



    for( i = 0 ; i < n ; i++)

	for( j = 0 ; j < m ; j++)

	    *(c+i*m+j) = *(a+i*m+j) ;

	return ;

}



void transpArray(double to[4][4], double from[4][4]) {

  

  int i, j;

  

  for (i=0 ; i < 4 ; i++) {

    for (j=0 ; j < 4 ; j++) {

      to[i][j] = from[j][i];

    }

  }

}



double * transpArray(double *at, double	*a, int	n, int m)

{

    int	i, j ;



	for( i = 0 ; i < n ; i++)

		for( j = 0 ; j < m ; j++)

			*(at+j*n+i) = *(a+i*m+j) ;

	return at ;

}



float  * transpArrayFloat(float	*at, float *a, int n, int m)

{

    int	i, j ;



	for( i = 0 ; i < n ; i++)

		for( j = 0 ; j < m ; j++)

			*(at+j*n+i) = *(a+i*m+j) ;

	return at ;

}





double * addArray(double *c, double *a,	double *b, int n, int m)

{

    int	i, j ;



	for( i = 0 ; i < n ; i++)

		for( j = 0 ; j < m ; j++)

			*(c+i*m+j) = *(a+i*m+j)	+ *(b+i*m+j) ;

	return c ;

}



double * subtractArray(double *c, double *a, double *b,	int n, int m)

{

    int	i, j ;



	for( i = 0 ; i < n ; i++)

		for( j = 0 ; j < m ; j++)

			*(c+i*m+j) = *(a+i*m+j)	- *(b+i*m+j) ;

	return c ;

}





double * multNumArray( double num, double * a, int n, int m)

{

    int	i, j ;



	for( i = 0 ; i < n ; i++)

	for( j = 0 ; j < m ; j++)

			*(a+i*m+j) *= num ;

	return (double *) a ;

}





double * MultNumArray( double *c, double num, double * a, int n, int m)

{

    int	i, j ;



	for( i = 0 ; i < n ; i++)

	for( j = 0 ; j < m ; j++)

			*(c+i*m+j) = *(a+i*m+j)	* num ;

	return (double *) c ;

}



// multArray:

//

// returns C = AB, matrix product of n1 x m and m x n2 matrix

double * multArray(double *c, double *a, double	*b, int	n1, int	m, int n2)

{

    int	i, j, k	;



	for( i = 0 ; i < n1 ; i++)

		for ( j	= 0 ; j	< n2 ; j++)

		{

			*(c+i*n2+j) = 0.0 ;

			for( k = 0 ; k < m ; k++)

				*(c+i*n2+j) += *(a+i*m+k) * (*(b+k*n2+j))  ;

				/** c[i][j] = Sa[i][k]*b[k][j] **/

		}

	return (double *) c ;

}

float * multArrayf(float *c, float *a, float	*b, int	n1, int	m, int n2)

{

    int	i, j, k	;



	for( i = 0 ; i < n1 ; i++)

		for ( j	= 0 ; j	< n2 ; j++)

		{

			*(c+i*n2+j) = 0.0 ;

			for( k = 0 ; k < m ; k++)

				*(c+i*n2+j) += *(a+i*m+k) * (*(b+k*n2+j))  ;

				/** c[i][j] = Sa[i][k]*b[k][j] **/

		}

	return (float *) c ;

}




void multArray4x4(double c[4][4], double a[4][4], double b[4][4])

{

	for (int row = 0; row < 4; row++)

		for (int col = 0; col < 4; col++)

			c[row][col] = a[row][0] * b[0][col] + a[row][1] * b[1][col] + a[row][2] * b[2][col] + a[row][3] * b[3][col];

}



void multArray4x4(double c[4][4], double a[4][4], double b[16])

{

	for (int row = 0; row < 4; row++)

		for (int col = 0; col < 4; col++)

			//c[row][col] = a[row][0] * b[col * 4] + a[row][1] * b[col * 4 + 1] + a[row][2] * b[col * 4 + 2] + a[row][3] * b[col * 4 + 3];

			c[row][col] = a[row][0] * b[col] + a[row][1] * b[col + 4] + a[row][2] * b[col + 8] + a[row][3] * b[col + 12];

			

}





double qT_M_q(double *m, double	*q, int	n)

{

	double rel, rel1 ;

	int i,j	;



	rel = 0.0 ;

	for( i = 0 ; i < n ; i++)

	{

		rel1 = 0.0 ;

		for( j = 0 ; j < n ; j++)

			rel1 = rel1 + *(m+i*n+j) * (*(q+j)) ;

		rel = rel+rel1*(*(q+i))	;

	}

	return rel ;

}





/*void printArray( double	*a, int	n, int m)

{

	int i,j	;



	for( i = 0 ; i < n ; i++)

	{

	    for( j = 0 ; j < m ; j++)

		printf("%lf ", *(a+i*m+j)) ;

	    printf("\n") ;

	}

	return ;

}*/





double Norm(double q[],	int n)

{

	double x = 0.0 ;

	int	i ;



	for ( i	= 0 ; i	< n ; i++)

		x += q[i]*q[i] ;

	return (double)	sqrt(x)	;

}



/*

void localToWorld( Vector plocal, Vector pworld, CoordSystem  *	cs)

{

	pworld[0] = cs->origin[0] + plocal[0]*cs->x[0]+

	    plocal[1]*cs->y[0] + plocal[2]*cs->z[0] ;

	pworld[1] = cs->origin[1] + plocal[0]*cs->x[1] +

	    plocal[1]*cs->y[1] + plocal[2]*cs->z[1] ;

	pworld[2] = cs->origin[2] + plocal[0]*cs->x[2] +

	    plocal[1]*cs->y[2] + plocal[2]*cs->z[2] ;

	    return ;

}

*/



/*******************************************

  PROC:	ddBerstn3()

  DOES:	returns	the second derivative with respect to x

********************************************/

double ddBernst3( double x, int	i)

{

    double  t = 0;



    switch(i)

    {

    case 0:

	t = 6*(1-x) ;

	break ;

    case 1:

	t = 18*x-12 ;

	break ;

    case 2:

	t = 6-18*x ;

	break ;

    case 3:

	t = 6*x	;

	break ;

    }

    return t ;

}



/*******************************************

  PROC:	dBerstn3()

  DOES:	returns	the first derivative with respect to x

********************************************/

double dBernst3( double	x, int i)

{

    double  t = 0;



    switch(i)

    {

    case 0:

	t = -3*(1-x)*(1-x) ;

	break ;

    case 1:

	t = (1-x)*(3-9*x) ;

	break ;

    case 2:

	t = x*(6-9*x) ;

	break ;

    case 3:

	t = 3*x*x ;

	break ;

    }

    return t ;

}



/** BernsteinPolynomials degree	3 **/

double Bernst3(	double x, int i)

{

    double  t  = 0;


    switch(i)

    {

    case 0:

	t = (1-x) ;

	t = t*t*t ;

	break ;

    case 1:

	t = 1-x	;

	t = 3*x*t*t ;

	break ;

    case 2:

	t = 3*x*x*(1-x)	;

	break ;

    case 3:

	t = x*x*x ;

	break ;

    default:

	fprintf(stderr,"Bernst3, illegal exponent!\n") ;

	break ;

    }

    return t ;

}



/* old for efficiency I	skip the pow()

double dBernst3( double	x, int i)

{

    double  t ;



    t =	 pow(x,	i)*pow(1-x, 3-i) ;

    if ( (i == 0) || (i	== 3) )

	return t ;

    else

	return 3*t ;

}

*/



double * EulerIntegr(double dq[], double q[], int n, double dt)

{

	int i ;



	for( i = 0; i <	n ; i++)

		q[i] = q[i] + dt*dq[i] ;

	return &q[0] ;

}









/***************************************************

 *	      Rotation functions		   *

 *	    ----------------------		   *

 * All of them accept 2	quaternions  an	angle in   *

 * in rad and an axis. If  quaternions are given   *

 * then	they are				   *

 * used. Otherwise quaternions are constructed.	   *

 * rotatePoint2D is an exception (2D rotation.	   *

 * ----------------------------------------------- *

 * ATTENTION !!	: In order for the functions to	   *

 * work	the quaternions	should be of unit mag.	   *

 * Currently for effeciency I have left	the norma- *

 * lization fot	the calling function.		   *

 * However the functiond construct unit	quaternions*

 ***************************************************/



void rotatePoint2D(Vector point, double	theta)

{

	double costh = cos(theta) ;

	double sinth = sin(theta) ;

	double x,y ;



	x = point[0]*costh - point[1]*sinth ;

	y = point[0]*sinth + point[1]*costh ;

	point[0] = x ;

	point[1] = y ;

	point[2] = 0.0 ;

	return ;

}









/************************************************

  Rotation using a matrix 3x3

 ************************************************/

void rotateCSorigin_mat(CoordSystem *cs, double	rot[3][3])

{

    rotatePoint_mat(cs->x, rot)	;

    rotatePoint_mat(cs->y, rot)	;

    rotatePoint_mat(cs->z, rot)	;

    return ;

}



void rotatePoint_mat(Vector point, double rot[3][3])

{

    Vector temp	;



    multArray(&temp[0],	&rot[0][0], &point[0], 3,3,1) ;

    point[0] = temp[0] ; point[1] = temp[1] ; point[2] =temp[2]	;

    return ;

}



//  transformPoint_mat:

//	transform given	point with transformation matrix by premultiplying

//	the matrix which is in column-major form

//

//	point	: Vector of size 3 doubles

//	transmat: Transformation matrix	in column-major	form.

//

void transformPoint_mat(Vector point, double transmat[4][4])

{

    double transpoint[4];

    transpoint[0] = point[0];

    transpoint[1] = point[1];

    transpoint[2] = point[2];

    transpoint[3] = 1.0;



    double newpoint[4]={0.0,0.0,0.0,0.0};



    // transmat	is in column-major order and is	pre-multiplied with

    // point (a	row vector)

    for	(int i=0; i < 4; i++)

	for (int j=0; j	< 4; j++)

		newpoint[i] += transmat[j][i]*transpoint[j];



//    double n1 =	1.0 / newpoint[3];

    point[0] = newpoint[0];//*n1 ;

    point[1] = newpoint[1];//*n1 ;

    point[2] = newpoint[2];//*n1 ;

    return ;

}





//  transformPoints_mat:

//	transform given	points with transformation matrix by premultiplying

//	the matrix which is in column-major form

//

//	point	: Array	of vectors of size 3 doubles

//	transmat: Transformation matrix	in column-major	form.

//	n	: number of points

//

void transformPoints_mat(Vector	*points, int n,	Vector *newpoints,

			 double	transmat[4][4])

{

    double transpoint[4];

    double newpoint[4] ;



    for( int np	= 0 ; np < n ; np++ )

    {

	transpoint[0] =	points[np][0];

	transpoint[1] =	points[np][1];

	transpoint[2] =	points[np][2];

	transpoint[3] =	1.0;



	newpoint[0] = newpoint[1] = newpoint[2]	= newpoint[3] =	0 ;





	// transmat is in column-major order and is pre-multiplied with

	// point (a row	vector)

	for (int i=0; i	< 4; i++)

	    for	(int j=0; j < 4; j++)

		newpoint[i] += transmat[j][i]*transpoint[j];



	double n1 = 1.0	/ newpoint[3];

	newpoints[np][0] = newpoint[0]*n1 ;

	newpoints[np][1] = newpoint[1]*n1 ;

	newpoints[np][2] = newpoint[2]*n1 ;

    }

    return ;

}



// as the above	but does only the rotation

void rotPoint_mat4(Vector point, double	transmat[4][4])

{

    double newpoint[3] = {0.0,0.0,0.0};



    // transmat	is in column-major order and is	pre-multiplied with

    // point (a	row vector)

    for	(int i=0; i < 3; i++)

	for (int j=0; j	< 3; j++)

		newpoint[i] += transmat[j][i]*point[j];



    point[0] = newpoint[0];

    point[1] = newpoint[1];

    point[2] = newpoint[2] ;

    return ;

}







/*********************************************

convIntToSt : converts a integer to a string

**********************************************/



char * convIntToStr(int	frameNumber, char *s)

{

    int	n = 0 ;

    int	m,p,i ;

    char t[80] ;



	if (frameNumber	== 0)

	{

	s[0] = '0' ;

	s[1] = '\0' ;

	return s ;

	}

    p =	frameNumber ;

    while (p !=	0)

    {

	m = p %	10 ;

	p = p /	10 ;

	switch(	m )

	{

	case 0:	t[n] = '0' ;

	    break ;

	case 1:	t[n] = '1' ;

	    break ;

	case 2 : t[n] =	'2' ;

	    break ;

	case 3:	t[n] = '3' ;

	    break ;

	case 4:	t[n] = '4' ;

	    break ;

	case 5:	t[n] = '5' ;

	    break ;

	case 6:	t[n] = '6' ;

	    break ;

	case 7:	t[n] = '7' ;

	    break ;

	case 8:	t[n] = '8' ;

	    break ;

	case 9:	t[n] = '9' ;

	    break ;

	}



	n++ ;

    }



    /**	now flip around	the string **/

    for( i = 0 ; i < n ; i++)

	s[i] = t[n-i-1]	;

    s[n] = '\0'	;

    return s ;

}







/************************************************************

	PROC: converg()

	DOES:	checks how close to successive solutions are.

		If they	are close then returns true.

*************************************************************/



int converg(double *x,double *x1, int n)

{

	int i ;

	double s ;



	s = 0 ;

	for( i = 0 ; i < n ; i++)

		s = s +	fabs(x[i]-x1[i]) ;



	if ( s/n < EPSI)

		return 1 ;

	else return 0 ;

}





/*****************************************************

  PROC:	embedCsInCs()

  DOES:	changes	the cs_guest such that it is given with

	respect	to the cs_host.	Both systems must

	initially be with respect to the same one

*******************************************************/

void embedCsInCs(CoordSystem *cs_guest,	CoordSystem *cs_host)

{

    double x,y,z ;



    VecSubtract(cs_guest->origin, cs_guest->origin, cs_host->origin) ;



    /* Now I have the guest origin in the reference frame of the */

    /* host frame. I have to transform it with respect to the host */

    /* frame itselfm which may be rotated with respect to its reference	frame */

    x =	VecDotProd(cs_guest->origin,cs_host->x)	;

    y =	VecDotProd(cs_guest->origin,cs_host->y)	;

    z =	VecDotProd(cs_guest->origin,cs_host->z)	;

    cs_guest->origin[0]	= x ;

    cs_guest->origin[1]	= y ;

    cs_guest->origin[2]	= z ;



    x =	VecDotProd(cs_guest->x,cs_host->x) ;

    y =	VecDotProd(cs_guest->x,cs_host->y) ;

    z =	VecDotProd(cs_guest->x,cs_host->z) ;

    cs_guest->x[0] = x ;

    cs_guest->x[1] = y ;

    cs_guest->x[2] = z ;



    x =	VecDotProd(cs_guest->y,cs_host->x) ;

    y =	VecDotProd(cs_guest->y,cs_host->y) ;

    z =	VecDotProd(cs_guest->y,cs_host->z) ;



    cs_guest->y[0] = x ;

    cs_guest->y[1] = y ;

    cs_guest->y[2] = z ;



    x =	VecDotProd(cs_guest->z,cs_host->x) ;

    y =	VecDotProd(cs_guest->z,cs_host->y) ;

    z =	VecDotProd(cs_guest->z,cs_host->z) ;



    cs_guest->z[0] = x ;

    cs_guest->z[1] = y ;

    cs_guest->z[2] = z ;



    /* Normalize unit vectors */

    VecNormalize(cs_guest->x) ;

    VecNormalize(cs_guest->y) ;

    VecNormalize(cs_guest->z) ;



    return ;

}



/**************************************************************

  PROC:	constrTransfMatrixFromCs()

  DOES:

   constructs the  transpose (following	the OpenGL convention

   of the transformation matrix	that transforms	points from

   cs coordinate to the	reference frame	of cs

****************************************************************/

double *constrTransfMatrixFromCs(double	m[4][4], CoordSystem *cs)

{

/*    This also	works

    m[0] = cs->x[0] ;

    m[1] = cs->x[1] ;

    m[2] = cs->x[2] ;

    m[3] = 0.0 ;

    m[4] = cs->y[0] ;

    m[5] = cs->y[1] ;

    m[6] = cs->y[2] ;

    m[7] = 0.0 ;

    m[8] = cs->z[0] ;

    m[9] = cs->z[1] ;

    m[10] = cs->z[2] ;

    m[11]= 0.0 ;

    m[12] = cs->origin[0] ;

    m[13] = cs->origin[1] ;

    m[14] = cs->origin[2] ;

    m[15] = 1.0	;

*/

    /* construct the transpose following the OpenGl convention */

    /* for storing matrices */

    VecCopy(m[0],cs->x)	;

    VecCopy(m[1],cs->y)	;

    VecCopy(m[2],cs->z)	;

    m[3][3] = 1.0 ;

    m[3][0] = cs->origin[0] ;

    m[3][1] = cs->origin[1] ;

    m[3][2] = cs->origin[2] ;

    m[0][3] = 0.0 ;

    m[1][3] = 0.0 ;

    m[2][3] = 0.0 ;

    return &m[0][0] ;

}



/**************************************************

  PROC:	invSmart4()

  DOES:	inverts	a 4x4 transformation matrix that consists

	of rotation and	translation only. The 3x3 part is

	orthonormal so there is	a smart	way to do it.

	The matrix is in column	order (following the

	OpenGL transpose convention. Thus I have to multiply

	from the left side.

	The inversion is done as follows:

	a = R*T	-> a^(-1) = T^(-1)*R^(-1) etc

	To avoid coputations with zeroes I do the

	matrix multiplication myself.

***************************************************/



double *invSmart4old(double inv[4][4],double a[4][4])

{

    int	i,j ;

    double t[3]	;



    for( i = 0 ; i < 3 ; i++)

	for( j = 0 ; j < 3 ; j++)

	    inv[i][j] =	a[j][i]	;

    inv[0][3] =	0.0 ;

    inv[1][3] =	0.0 ;

    inv[2][3] =	0.0 ;

    inv[3][3] =	1.0 ;



    t[0] = a[3][0] ;

    t[1] = a[3][1] ;

    t[2] = a[3][2] ;

    inv[3][0] =	-(t[0]*inv[0][0]+t[1]*inv[1][0]+t[2]*inv[2][0])	;

    inv[3][1] =	-(t[0]*inv[0][1]+t[1]*inv[1][1]+t[2]*inv[2][1])	;

    inv[3][2] =	-(t[0]*inv[0][2]+t[1]*inv[1][2]+t[2]*inv[2][2])	;



    /*

    SbMatrix *m	= new SbMatrix(a[0][0],	a[0][1], a[0][2], a[0][3],

	       a[1][0],	a[1][1], a[1][2], a[1][3],

	       a[2][0],	a[2][1], a[2][2], a[2][3],

	       a[3][0],	a[3][1], a[3][2], a[3][3]) ;

    SbMatrix In	= m->inverse() ;

    for( i = 0 ; i < 4 ; i++ )

	for( j = 0 ; j < 4 ; j++ )

	    inv[i][j] =	In[i][j] ;



    */

    return &inv[0][0] ;

}





// PROC: invSmart4()

// DOES: inverts a matrix of the form:

//	 A = [ a00, a01, a02, 0,

//	       a10, a11, a12, 0,

//	       a20, a21, a22, 0,

//	       tx, ty, tz, 1]



double *invSmart4(double inv[4][4],double a[4][4])

{

    double t4,t6,t8,t10,t12,t14,t17,t27,

      t28, t31,	t32, t35, t36,t49,t51,t59 ;

    double tx =	a[3][0]	;

    double ty =	a[3][1]	;

    double tz =	a[3][2]	;



    double a00 = a[0][0] ;

    double a01 = a[0][1] ;

    double a02 = a[0][2] ;

    double a10 = a[1][0] ;

    double a11 = a[1][1] ;

    double a12 = a[1][2] ;

    double a20 = a[2][0] ;

    double a21 = a[2][1] ;

    double a22 = a[2][2] ;



    t4 = a00*a11;

    t6 = a00*a21;

    t8 = a10*a01;

    t10	= a10*a21;

    t12	= a20*a01;

    t14	= a20*a11;

    t17	= 1.0/(t4*a22-t6*a12-t8*a22+t10*a02+t12*a12-t14*a02);

    t27	= a10*a22;

    t28	= a20*a12;

    t31	= a00*a22;

    t32	= a20*a02;

    t35	= a00*a12;

    t36	= a10*a02;

    t49	= tx*a11;

    t51	= tx*a21;

    t59	= tx*a01;

    inv[0][0] =	(a11*a22-a21*a12)*t17;

    inv[0][1] =	-(a01*a22-a21*a02)*t17;

    inv[0][2] =	(a01*a12-a11*a02)*t17;

    inv[0][3] =	0.0;

    inv[1][0] =	-(t27-t28)*t17;

    inv[1][1] =	(t31-t32)*t17;

    inv[1][2] =	-(t35-t36)*t17;

    inv[1][3] =	0.0;

    inv[2][0] =	(t10-t14)*t17;

    inv[2][1] =	-(t6-t12)*t17;

    inv[2][2] =	(t4-t8)*t17;

    inv[2][3] =	0.0;

    inv[3][0] =	-(t10*tz-t27*ty-t14*tz+t28*ty+t49*a22-t51*a12)*t17;

    inv[3][1] =	(t6*tz-t31*ty-t12*tz+t32*ty+t59*a22-t51*a02)*t17;

    inv[3][2] =	-(t4*tz-t35*ty-t8*tz+t36*ty+t59*a12-t49*a02)*t17;

    inv[3][3] =	1.0;



    return &inv[0][0] ;

}



double * quatToMat(double q[4],double m[4][4])

{

    double w,x,y,z;

    double xs,ys,zs,wx,wy,wz,xx,yy,zz,xy,yz,xz;



    w =	q[0];

    x =	q[1];

    y =	q[2];

    z =	q[3];



    xs = x + x;

    ys = y + y;

    zs = z + z;

    wx = w*xs;

    wy = w*ys;

    wz = w*zs;

    xx = x*xs;

    yy = y*ys;

    zz = z*zs;

    xy = x*ys;

    yz = y*zs;

    xz = x*zs;

    m[0][0] = 1.0 - (yy+zz);

    m[0][1] = xy-wz;

    m[0][2] = xz+wy;

    m[0][3] = 0.0;

    m[1][0] = xy + wz;

    m[1][1] = 1.0 - (xx+zz);

    m[1][2] = yz - wx;

    m[1][3] = 0.0;

    m[2][0] = xz-wy;

    m[2][1] = yz + wx;

    m[2][2] = 1.0 - (xx+yy);

    m[2][3] = 0.0;

    m[3][0] = 0.0;

    m[3][1] = 0.0;

    m[3][2] = 0.0;

    m[3][3] = 1.0;



    return &m[0][0] ;

}



//------------------------------------------

void setIdentMat(double	*mat,int n)

{

    int	i, j ;



    for( i = 0 ; i < n ; i++)

	for( j = 0 ; j < n ; j++ )

	    if(i == j)

		*(mat+i*n+j) = 1.0 ;

	    else

		*(mat+i*n+j) = 0.0 ;

}



int isDiagonal(double *a,int n)

{

    int	i,j ;

    int	res = TRUE ;



    for( i = 0 ; i < n ; i++ )

	for( j = 0 ; j < n ; j++ )

	    if(	i != j)

		if(*(a+i*n+j) != (double) 0.0)

		    res	= FALSE	;

    return res ;

}



// multipies two 4x4 matrices using only the 3x3 part

// (rotational one). The translation one is left untouched!!

void compRotMat4(double	c[4][4], double	m1[4][4], double m2[4][4])

{

    int	i,j,k ;



    for( i = 0 ; i < 3 ; i++)

    {



	for( j = 0 ; j < 3 ; j++ )

	{

	    c[i][j] = 0.0 ;

	    for( k = 0 ; k < 3 ; k++)

		c[i][j]	+= m1[i][k]*m2[k][j] ;

	}

    }

}



// relativeToFrame:

//

// Returns the new coordinate frame axes of wmat relative to the coordinate

// frame rmat. 

//

// NOTE: does not take into account translation. Assumes 0,0,0 translation.

void relativeToFrame(double mat[4][4], double wmat[4][4], double rmat[4][4])

{

	// Take	transpose of reference frame.

	double tmat[4][4];

	transpArray(&tmat[0][0], &rmat[0][0], 4,4);

	multArray(&mat[0][0], &tmat[0][0], &wmat[0][0],4,4,4);

}



// Calculates the intersection of the line defined by points v1,v2 with the

// line defined by w1,w2. If infinite is 1 then the lines are considered infinite.

// Otherwise the lines are treated as line segments.

// If there is no intersection NULL is returned.

double *lineIntersection(Vector v1, Vector v2, Vector w1, Vector w2, 

			 Vector intersection, int infinite )

{

    int i ;

    double t2, x2x1, ay,py,az,pz ;



    x2x1 = v2[0] - v1[0] ;



    py = (w2[0] - w1[0])*(v2[1] - v1[1]) +

         (v2[0] - v1[0])*(w1[1] - w2[1]) ;

    ay = w1[1]*(v2[0] - v1[0]) +

         v2[1]*(v1[0] - w1[0]) +

         v1[1]*(w1[0] - v2[0]) ;

    if ( (fabs(py) < EPSI) && (fabs(ay) < EPSI) )

    {  /** means same projection on xy-plane

         try to see the xz plane

         **/

        pz = (w2[0] - w1[0])*(v2[2] - v1[2]) +

             (v2[0] - v1[0])*(w1[2] - w2[2]) ;

        az = w1[2]*(v2[0] - v1[0]) +

             v2[2]*(v1[0] - w1[0]) +

             v1[2]*(w1[0] - v2[0]) ;

        if ( (fabs(pz) < EPSI) && (fabs(az) < EPSI) )

        {

            fprintf(stderr, "interscpLines: lines coincide\n") ;

            return NULL ;

        }

        else if ( (fabs(pz) < EPSI) && (fabs(az) > EPSI) )

        {

            return NULL ;

        }

        else

        {

	    //printf("pz = %lf\n", pz) ;

            t2 = az / pz ;

            for( i = 0 ; i < 3 ; i++)

                intersection[i] = (1-t2)*w1[i] + t2*w2[i] ;

        }

    }

    else if ( (fabs(py) < EPSI) && (fabs(ay) > EPSI) )

    {

        return NULL ;

    }

    else

    {

	//printf("py = %lf\n", py) ;

        t2 = ay / py ;

        for( i = 0 ; i < 3 ; i++)

            intersection[i] = (1-t2)*w1[i] + t2*w2[i] ;

    }



    // if infinites is not 1

    // check to see if the intersection point is in the line segments

    if( infinite == 0 )

    {

	if( (v1[0] - intersection[0])*(v2[0] - intersection[0]) > 0.0 )

	    return NULL ;

	else if( (v1[1] - intersection[1])*(v2[1] - intersection[1]) > 0.0 )

	    return NULL ;

	else if( (v1[2] - intersection[2])*(v2[2] - intersection[2]) > 0.0 )

	    return NULL ;

	else if( (w1[0] - intersection[0])*(w2[0] - intersection[0]) > 0.0 )

	    return NULL ;

	else if( (w1[1] - intersection[1])*(w2[1] - intersection[1]) > 0.0 )

	    return NULL ;

	else if( (w1[2] - intersection[2])*(w2[2] - intersection[2]) > 0.0 )

	    return NULL ;

    }

   

    return (double *) &intersection[0] ;



}



/// v1 -> v2 is considered infinite if argInfiniteV is true

/// w1 -> w2 is considered infinite if argInfiniteW is true

int lineIntersection2D( Vector outIntersection, const Vector v1, const Vector v2, bool argInfiniteV, const Vector w1, const Vector w2, bool argInfiniteW )

{

	// All in same y

	double x0 = v1[0]; double y0 = v1[2];

	double x1 = v2[0]; double y1 = v2[2];

	double x2 = w1[0]; double y2 = w1[2];

	double x3 = w2[0]; double y3 = w2[2];

	zeroVector( outIntersection );



	double d=(x1-x0)*(y3-y2)-(y1-y0)*(x3-x2);

	if (fabs(d) < EPSI ) 

	{

		// parallel

		return -1;

	}

	double AB = ((y0-y2)*(x3-x2)-(x0-x2)*(y3-y2)) / d;

	if( argInfiniteW || (AB >= 0.0 && AB <= 1.0) )

	{

		double CD = ((y0-y2)*(x1-x0)-(x0-x2)*(y1-y0)) / d;

		if( argInfiniteV || (CD >= 0.0 && CD <= 1.0) )

		{ 

			outIntersection[0] = x0 + AB * (x1-x0);

			outIntersection[2] = y0 + AB * (y1-y0);

			return 1;

		}

	}

	// no intersection

	return 0;

}





void XRotatePoints(float *points, int npoints, double degrees)

{

    // transform degrees into rad

    double angle = degrees *0.01745329252 ;  // M_PI / 180.0 ;

   

    double c = cos(angle) ;

    double s = sin(angle) ;

	float temp[3];

   

    for( int i = 0 ; i < npoints ; i++ )

    {

		temp[1] = points[i * 3 + 1]; // Ari prefers this style "it's easier to understand!"

		temp[2] = points[i * 3 + 2];

//		memcpy(temp, &points[i * 3], 3 * sizeof(float)); // Paco prefers this style "it's faster and shorter!"

		points[i * 3 + 1] = temp[1] * c - temp[2] * s ;

		points[i * 3 + 2] = temp[1] * s + temp[2] * c ;

    }

	

}



void YRotatePoints(float *points, int npoints, double degrees)

{

    // transform degrees into rad

    double angle = degrees *0.01745329252 ; // M_PI / 180.0 ;

   

    double c = cos(angle) ;

    double s = sin(angle) ;

	float temp[3];

   

    for( int i = 0 ; i < npoints ; i++ )

    {

		temp[0] = points[i * 3]; // Ari prefers this style "it's easier to understand!"

		temp[2] = points[i * 3 + 2];

//		memcpy(temp, &points[i * 3], 3 * sizeof(float)); // Paco prefers this style "it's faster and shorter!"

		points[i * 3] = temp[0]*c + temp[2]*s ;

		points[i * 3 + 2] = -temp[0]*s + temp[2]*c ;

    }

	

}



void ZRotatePoints(float *points, int npoints, double degrees)

{

    // transform degrees into rad

    double angle = degrees *0.01745329252 ; // M_PI / 180.0 ;

   

    double c = cos(angle) ;

    double s = sin(angle) ;

	float temp[3];

   

    for( int i = 0 ; i < npoints ; i++ )

    {

		temp[0] = points[i * 3]; // Ari prefers this style "it's easier to understand!"

		temp[1] = points[i * 3 + 1];

//		memcpy(temp, &points[i * 3], 3 * sizeof(float)); // Paco prefers this style "it's faster and shorter!"

		points[i * 3] = temp[0]*c - temp[1]*s ;

		points[i * 3 + 1] = temp[0]*s + temp[1]*c ;

    }

	

}





void XRotatePoints(double *points, int npoints, double degrees)

{

    // transform degrees into rad

    double angle = degrees *0.01745329252 ;  // M_PI / 180.0 ;

   

    double c = cos(angle) ;

    double s = sin(angle) ;

	float temp[3];

   

    for( int i = 0 ; i < npoints ; i++ )

    {

		temp[1] = points[i * 3 + 1]; // Ari prefers this style "it's easier to understand!"

		temp[2] = points[i * 3 + 2];

//		memcpy(temp, &points[i * 3], 3 * sizeof(float)); // Paco prefers this style "it's faster and shorter!"

		points[i * 3 + 1] = temp[1] * c - temp[2] * s ;

		points[i * 3 + 2] = temp[1] * s + temp[2] * c ;

    }

	

}



void YRotatePoints(double *points, int npoints, double degrees)

{

    // transform degrees into rad

    double angle = degrees *0.01745329252 ; // M_PI / 180.0 ;

   

    double c = cos(angle) ;

    double s = sin(angle) ;

	float temp[3];

   

    for( int i = 0 ; i < npoints ; i++ )

    {

		temp[0] = points[i * 3]; // Ari prefers this style "it's easier to understand!"

		temp[2] = points[i * 3 + 2];

//		memcpy(temp, &points[i * 3], 3 * sizeof(float)); // Paco prefers this style "it's faster and shorter!"

		points[i * 3] = temp[0]*c + temp[2]*s ;

		points[i * 3 + 2] = -temp[0]*s + temp[2]*c ;

    }

	

}



void ZRotatePoints(double *points, int npoints, double degrees)

{

    // transform degrees into rad

    double angle = degrees *0.01745329252 ; // M_PI / 180.0 ;

   

    double c = cos(angle) ;

    double s = sin(angle) ;

	float temp[3];

   

    for( int i = 0 ; i < npoints ; i++ )

    {

		temp[0] = points[i * 3]; // Ari prefers this style "it's easier to understand!"

		temp[1] = points[i * 3 + 1];

//		memcpy(temp, &points[i * 3], 3 * sizeof(float)); // Paco prefers this style "it's faster and shorter!"

		points[i * 3] = temp[0]*c - temp[1]*s ;

		points[i * 3 + 1] = temp[0]*s + temp[1]*c ;

    }

	

}





void XRotatePoints(Vector *points, int npoints, double degrees)

{

    // transform degrees into rad

    double angle = degrees *0.01745329252 ;  // M_PI / 180.0 ;

   

    double c = cos(angle) ;

    double s = sin(angle) ;

   

    for( int i = 0 ; i < npoints ; i++ )

    {

	Vector point ;

	VecCopy(point, points[i]) ;

	points[i][1] = point[1]*c - point[2]*s ;

	points[i][2] = point[1]*s + point[2]*c ;

    }

	

}



void YRotatePoints(Vector *points, int npoints, double degrees)

{

    // transform degrees into rad

    double angle = degrees *0.01745329252 ; // M_PI / 180.0 ;

   

    double c = cos(angle) ;

    double s = sin(angle) ;

   

    for( int i = 0 ; i < npoints ; i++ )

    {

	Vector point ;

	VecCopy(point, points[i]) ;

	points[i][0] = point[0]*c + point[2]*s ;

	points[i][2] = -point[0]*s + point[2]*c ;

    }

	

}



void ZRotatePoints(Vector *points, int npoints, double degrees)

{

    // transform degrees into rad

    double angle = degrees *0.01745329252 ;  // M_PI / 180.0 ;

   

    double c = cos(angle) ;

    double s = sin(angle) ;

   

    for( int i = 0 ; i < npoints ; i++ )

    {

	Vector point ;

	VecCopy(point, points[i]) ;

	points[i][0] = point[0]*c - point[1]*s ;

	points[i][1] = point[0]*s + point[1]*c ;

    }

	

}





double DNCRandom(double max, double min)

{

    double x;

	

#ifdef WIN32 

    static double factor = 1.0 / (double) RAND_MAX ;

    x = (double) rand()*factor ;

#else

    x = drand48() ;

    //  printf(" x = %lf ", x) ;

#endif

    // x is in [0.0, 1.0) so scale it to the proper values

	

	return x*(max - min) + min ;



}



void SetMatRx(double mat[4][4], double rx)

{

	setIdentMat(&mat[0][0], 4) ;

	double c = cos(rx) ;

	double s = sin(rx) ;

	mat[1][1] = c ;

	mat[1][2] = -s ;

	mat[2][1] = s ;

	mat[2][2] = c  ;

}



void SetMatRy(double mat[4][4], double ry)

{

	setIdentMat(&mat[0][0], 4) ;

	double c = cos(ry) ;

	double s = sin(ry) ;

	mat[0][0] = c ;

	mat[0][2] = s ;

	mat[2][0] = -s ;

	mat[2][2] = c  ;

}



void SetMatRz(double mat[4][4], double rz)

{

	setIdentMat(&mat[0][0], 4) ;

	double c = cos(rz) ;

	double s = sin(rz) ;

	mat[0][0] = c ;

	mat[0][1] = -s ;

	mat[1][0] = s ;

	mat[1][1] = c  ;

}



void TransMatFromScaleRotTrans(double mat[4][4], double sx, double sy, double sz, double rx, double ry, double rz, double tx, double ty, double tz)

{

	double mat_tmp2[4][4], mat_tmp[4][4], mrx[4][4], mry[4][4], mrz[4][4], mats[4][4] ;



	setIdentMat(&mats[0][0], 4) ;

	mats[0][0] = sx;

	mats[1][1] = sy;

	mats[2][2] = sz;



	setIdentMat(&mat_tmp[0][0], 4) ;

	setIdentMat(&mat_tmp2[0][0], 4) ;

	setIdentMat(&mat[0][0], 4) ;

	SetMatRx(mrx, rx) ;

	SetMatRy(mry, ry) ;

	SetMatRz(mrz, rz) ;

	

	multArray(&mat_tmp[0][0], &mrz[0][0], &mry[0][0], 4, 4, 4);

	multArray(&mat_tmp2[0][0], &mat_tmp[0][0], &mrx[0][0], 4, 4, 4);

	multArray(&mat[0][0], &mat_tmp2[0][0], &mats[0][0], 4, 4, 4);



	mat[0][3] = tx ;

	mat[1][3] = ty ;

	mat[2][3] = tz ;



}



/*

 * Invert a 4x4 matrix.  Changed slightly from Richard Carling's code

 * in "Graphics Gems I".

 */



#define SMALL_NUMBER    1.e-8

void invert_matrix (double A[4][4], double Ainv[4][4]) {

  int i, j;

  double det ;



  adjoint( A, Ainv );



  det = det4x4( A );



  if ( fabs( det ) < SMALL_NUMBER) {

    fprintf(stderr,"invert_matrix: matrix is singular!");

    return;

  }



  for (i=0; i<4; i++)

    for(j=0; j<4; j++)

      Ainv[i][j] = Ainv[i][j] / det;

}



void adjoint( double in[4][4], double out[4][4] ) {

  double a1, a2, a3, a4, b1, b2, b3, b4;

  double c1, c2, c3, c4, d1, d2, d3, d4;





  a1 = in[0][0]; b1 = in[0][1]; 

  c1 = in[0][2]; d1 = in[0][3];



  a2 = in[1][0]; b2 = in[1][1]; 

  c2 = in[1][2]; d2 = in[1][3];



  a3 = in[2][0]; b3 = in[2][1];

  c3 = in[2][2]; d3 = in[2][3];



  a4 = in[3][0]; b4 = in[3][1]; 

  c4 = in[3][2]; d4 = in[3][3];



  out[0][0]  =   det3x3( b2, b3, b4, c2, c3, c4, d2, d3, d4);

  out[1][0]  = - det3x3( a2, a3, a4, c2, c3, c4, d2, d3, d4);

  out[2][0]  =   det3x3( a2, a3, a4, b2, b3, b4, d2, d3, d4);

  out[3][0]  = - det3x3( a2, a3, a4, b2, b3, b4, c2, c3, c4);

        

  out[0][1]  = - det3x3( b1, b3, b4, c1, c3, c4, d1, d3, d4);

  out[1][1]  =   det3x3( a1, a3, a4, c1, c3, c4, d1, d3, d4);

  out[2][1]  = - det3x3( a1, a3, a4, b1, b3, b4, d1, d3, d4);

  out[3][1]  =   det3x3( a1, a3, a4, b1, b3, b4, c1, c3, c4);

        

  out[0][2]  =   det3x3( b1, b2, b4, c1, c2, c4, d1, d2, d4);

  out[1][2]  = - det3x3( a1, a2, a4, c1, c2, c4, d1, d2, d4);

  out[2][2]  =   det3x3( a1, a2, a4, b1, b2, b4, d1, d2, d4);

  out[3][2]  = - det3x3( a1, a2, a4, b1, b2, b4, c1, c2, c4);

        

  out[0][3]  = - det3x3( b1, b2, b3, c1, c2, c3, d1, d2, d3);

  out[1][3]  =   det3x3( a1, a2, a3, c1, c2, c3, d1, d2, d3);

  out[2][3]  = - det3x3( a1, a2, a3, b1, b2, b3, d1, d2, d3);

  out[3][3]  =   det3x3( a1, a2, a3, b1, b2, b3, c1, c2, c3);

}



double det4x4( double m[4][4] ) 

{

  double ans;

  double a1, a2, a3, a4, b1, b2, b3, b4, c1, c2, c3, c4, d1, d2, d3, d4;

 



  a1 = m[0][0]; b1 = m[0][1]; 

  c1 = m[0][2]; d1 = m[0][3];



  a2 = m[1][0]; b2 = m[1][1]; 

  c2 = m[1][2]; d2 = m[1][3];



  a3 = m[2][0]; b3 = m[2][1]; 

  c3 = m[2][2]; d3 = m[2][3];



  a4 = m[3][0]; b4 = m[3][1]; 

  c4 = m[3][2]; d4 = m[3][3];



  ans = a1 * det3x3( b2, b3, b4, c2, c3, c4, d2, d3, d4)

    - b1 * det3x3( a2, a3, a4, c2, c3, c4, d2, d3, d4)

    + c1 * det3x3( a2, a3, a4, b2, b3, b4, d2, d3, d4)

    - d1 * det3x3( a2, a3, a4, b2, b3, b4, c2, c3, c4);

  return ans;

}



//double det3x3( a1, a2, a3, b1, b2, b3, c1, c2, c3 )

  //   double a1, a2, a3, b1, b2, b3, c1, c2, c3;

double det3x3( double a1, double a2, double a3, double b1, double b2, double b3, double c1, 

			  double c2, double c3 )

{

  double ans;



  ans = a1 * det2x2( b2, b3, c2, c3 )

    - b1 * det2x2( a2, a3, c2, c3 )

    + c1 * det2x2( a2, a3, b2, b3 );

  return ans;

}



//double det2x2( a, b, c, d)

  //   double a, b, c, d; 

double det2x2( double a, double b, double c, double d)

{

  double ans;

  ans = a * d - b * c;

  return ans;

}



double degtorad(double deg)

{

	return deg * M_PI / 180.0;

}



double radtodeg(double rad)

{

	return rad * 180.0 / M_PI;

}





