/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _MAT3X3_
#define _MAT3X3_

// this is a ROW MAJOR matrix. Row major was chosen to make the addressing
// similar to regular matrix notation. mat[x][y] accesses row x, column y. 
// Matrrix3x3 is an array of 3 VectorObj vectors. 

#include "vectorObj.h"
#include "mathdefs.h"

class VectorObj;
class ArbMatrix;

class Matrix3x3 {
  
 protected:
  
  VectorObj mat[3];
  static double toGL[16];
  
 public:
  
  Matrix3x3(){}
  Matrix3x3(double matrix[4][4]);
  Matrix3x3(float matrix[4][4]);
  Matrix3x3( double xx, double xy, double xz, double yx, double yy, double yz, double zx, double zy, double zz );
  ~Matrix3x3(){}

  void to4x4(double matrix[4][4]);
  void from4x4(double matrix[4][4]);
  void from4x4(const double matrix[4][4]);
  
  inline VectorObj &operator[](int i) { return mat[i];}
  inline const VectorObj &operator[](int i) const { return mat[i];}

  void assignRowMajor(double *);
  void assignColMajor(double *);

  double *data() { return mat[0].data();}

  void clear();
  Matrix3x3 &identity();

  bool operator==(const Matrix3x3 &a) const;
  Matrix3x3 &operator=(const Matrix3x3 &a);
  
  void operator+=(const Matrix3x3 &a);
  void operator-=(const Matrix3x3 &a);

  void assignDiagonal(double a, double b, double c);
  void assignDiagonal(const VectorObj &a);
  
  void assignRow(int i, const VectorObj &a);
  void assignColumn(int i, const VectorObj &a);

  Matrix3x3 operator+(const Matrix3x3 &a) const;
  Matrix3x3 operator-(const Matrix3x3 &a) const;

  Matrix3x3 operator*(double a) const;
  Matrix3x3 operator/(double a) const;
  
  Matrix3x3 operator*(const Matrix3x3 &a) const;
  void operator*=(const Matrix3x3 &a);

  void operator*=(double a);
  void operator/=(double a);

  VectorObj operator*(const VectorObj &vec) const;

  Matrix3x3 adjoint() const;
  double determinant() const;
  void detDebug() const;

  void invert();
  
  // performs the outer product on two ArbMatrix. It automatically takes
  // the transpose of a_1x3, then filling its contents with the outer product
  //void outerProduct(ArbMatrix &a_1x3, ArbMatrix &b_1x3);
  void outerProduct(const VectorObj &a, const VectorObj &b);

  void fileDisplay(const char *fName);

  void setScale(const VectorObj &s);
  void setRotation(VectorObj &axis, double rot);
  
  Matrix3x3 transpose() const;

  double* getGlMatrix();

  // Duplicated in Python Script Controllers.
  enum {XYZ, XZY, YXZ, YZX, ZXY, ZYX,
	XY, XZ, YX, YZ, ZX, ZY};

  int matToEuler(int order, VectorObj &xyzAngles, 
		 bool staticFrame=true) const;
  double matToEuler1D(int order);
  void matToEuler1DTwoSolutions(int axis, double& solution1, double& solution2);
  int matToEuler2D(int rotOrder, VectorObj &eaFinal, 
		   bool staticFrame) const;
  void matToEulerTwoSolutions(int order, VectorObj &eaFinal1, VectorObj &eaFinal2);


  void matFromEuler(int order, const VectorObj &xyzAngles);
  void matFromEuler1D(int order, const VectorObj &xyzAngles);
  void matFromEuler2D(int order, const VectorObj &xyzAngles);

  enum {X, Y, Z};
  void setRotateMatrix(int axis, double amt);
  void setDerivRotateMatrix(int axis, double amt);

  // given an axis, this will return the derivative w.r.t. axis
  void getDeriv(int axis, Matrix3x3 &deriv) const;
  void getDeriv(int axis, int rotOrder, Matrix3x3 &deriv) const;
 
  // set matrix to rotation about axis. Length of axis is the amount of 
  // rotation in radians
  void matFromAxis(const VectorObj &axis);
  void matToAxis(VectorObj &axis) const;

  Matrix3x3& calcCross(const VectorObj &omega);

  static int getReverseRotationOrder(int order, int numAxis);

};


#endif
