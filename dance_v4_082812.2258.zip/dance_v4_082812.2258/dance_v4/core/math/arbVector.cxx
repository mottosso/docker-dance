/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "arbVector.h"
#include <cfloat>

ArbVector::ArbVector() {
  
  _size = 0;
  _data = 0;
}

ArbVector::ArbVector(int s) {
  
  _size = s;
  _data = new double[_size];

}

ArbVector::ArbVector(const ArbVector& a) {
  
  _data = 0;
  _size = 0;

  *this = a;
}

ArbVector::~ArbVector() {
  
  if (_data) {
    delete [] _data;
  }
}

void ArbVector::setSize(int newSize) {
  
  double *oldData;
  int oldSize, s, i;

  if (_size==newSize) {
    return;
  }

  oldData = _data;
  oldSize = _size;

  //if (_data) {
  //delete [] _data;
  //}
  
  _size = newSize;

  if (_size>0) {
    _data = new double[_size];

    s = _size<oldSize?_size:oldSize;
    
    if (s>0) {
      for (i=0 ; i < s ; i++) {
	_data[i] = oldData[i];
      }
    }
    
    if (oldData) {
      delete [] oldData;
    }

  } else {
    _data = 0;
  }

}

void ArbVector::operator*=(double a) {
  int i;
  
  for (i=0 ; i < _size ; i++) {
    _data[i] *= a;
  }
}

void ArbVector::operator-=(const ArbVector &a) {
  
  int i;
  
  for (i=0 ; i < _size ; i++) {
    _data[i] -= a[i];
  }
}

void ArbVector::operator+=(const ArbVector &a) {
  
  int i;
  
  for (i=0 ; i < _size ; i++) {
    _data[i] += a[i];
  }
}

void ArbVector::copy(const ArbVector &a) {
  
  int s, i;

  s = a.size()<_size?a.size():_size;

  for (i=0 ; i < s ; i++) {
    _data[i] = a[i];
  }
}


ArbVector &ArbVector::operator=(const ArbVector &a) {
  int i;
  
  if (_size!=a.size()) {
    setSize(a.size());
  }

  for (i=0 ; i < _size ; i++) {
    _data[i] = a[i];
  }
  
  return *this;
}

ArbVector& ArbVector::operator=(double a) {
  int i;
  
  for (i=0 ; i < _size ; i++) {
    _data[i] = a;
  }
  
  return *this;
}

void ArbVector::clear() {
  int i;
  
  for (i=0 ; i < _size ; i++) {
    _data[i] = 0;
  }
}

bool ArbVector::operator==(double a) const {
  
  int i;
  
  for (i=0 ; i < _size ; i++) {
    if (_data[i]!=a) {
      return false;
    }
  }

  return true;
}

bool ArbVector::operator==(const ArbVector &a) const {
  
  int i;
  
  if (_size!=a.size()) {
    return false;
  }

  for (i=0 ; i < _size ; i++) {
    if (_data[i]!=a[i]) {
      return false;
    }
  }

  return true;
}

void ArbVector::mult(ArbVector &to, double sc) {
  
  int i;
  
  for (i=0 ; i < _size ; i++) {
    to[i] = _data[i]*sc;
  }
}

void ArbVector::writeTo(double *to) {
  int i;
  
  for (i=0 ; i < _size ; i++) {
    to[i] = _data[i];
  }
}

#if 0
void ArbVector::dumpTo(std::string &str) {
  
  int i;
  char Buf[128];

  str = "[ ";
  for (i=0 ; i < _size ; i++) {
    sprintf(Buf, "%f ", _data[i]);
    //str += Buf;
    str += "Num ";
  }
  
  str += "]\n";
}
#else
void ArbVector::dumpTo(const char *fName) {

  FILE *fp;
  int i;

  fp = fopen(fName, "a");
  if (!fp) {
//    danceInterp::OutputMessage("ArbVector::dumpTo Error: Can't open %s for writing", 
//			    fName);
  } else {

    fprintf(fp, "[ ");
    for (i=0 ; i < _size ; i++) {
      fprintf(fp, "%f ", _data[i]);
    }
    fprintf(fp, "]");
    fflush(fp);
    fclose(fp);
  }
}
#endif

bool ArbVector::isNan() const {
  
  int i;
  
  for (i=0 ; i < _size ; i++) {
#ifdef WIN32
    if (!_finite(_data[i])) {
      return true;
    }
#endif
#ifdef __linux
    if (isnan(_data[i])) {
      return true;
    }
#endif
    
  }

  return false;
}


#if 1
#include <assert.h>

double& ArbVector::operator[](int i) { 
  if (i<0 || i>=_size) {
//    danceInterp::OutputMessage("ArbVector::operator[] %d", i);
    //assert(0);
  }
  return _data[i];
}

const double& ArbVector::operator[](int i) const { 
  if (i<0 || i>=_size) {
//    danceInterp::OutputMessage("ArbVector::operator[] %d", i);
    //assert(0);
  }
  return _data[i];
}

#endif
