/**************************************************

Copyright 2005 by Ari Shapiro and Petros Faloutsos



DANCE

Dynamic ANimation and Control Environment



 ***************************************************************

 ******General License Agreement and Lack of Warranty ***********

 ****************************************************************



This software is distributed for noncommercial use in the hope that it will 

be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility

to anyone for the consequences	of using it or for whether it serves any 

particular purpose or works at all. No warranty is made about the software 

or its performance. Commercial use is prohibited. 



Any plugin code written for DANCE belongs to the developer of that plugin,

who is free to license that code in any manner desired.



Content and code development by third parties (such as FLTK, Python, 

ImageMagick, ODE) may be governed by different licenses.

You may modify and distribute this software as long as you give credit 

to the original authors by including the following text in every file 

that is distributed:

*/

/*********************************************************

	Copyright 2005 by Ari Shapiro and Petros Faloutsos



	DANCE

	Dynamic ANimation and Control Environment

	-----------------------------------------

	AUTHOR:

		Ari Shapiro (ashapiro@cs.ucla.edu)

	ORIGINAL AUTHORS: 

		Victor Ng (victorng@dgp.toronto.edu)

		Petros Faloutsos (pfal@cs.ucla.edu)

	CONTRIBUTORS:

		Yong Cao (abingcao@cs.ucla.edu)

		Paco Abad (fjabad@dsic.upv.es)

**********************************************************/



#include "SpatialVector.h"

#include "vectorObj.h"



SpatialVector::SpatialVector() {



}



SpatialVector::SpatialVector(const VectorObj &a,

			     const VectorObj &l) {

  vec[0] = a[0];

  vec[1] = a[1];

  vec[2] = a[2];



  vec[3] = l[0];

  vec[4] = l[1];

  vec[5] = l[2];

}



SpatialVector::~SpatialVector() {



}



void SpatialVector::clear() {

  

  vec[0] = vec[1] = vec[2] = vec[3] = vec[4] = vec[5] = 0;

}



void SpatialVector::assign(double wx, double wy, double wz, 

			   double vx, double vy, double vz) {

  

  vec[0] = wx;

  vec[1] = wy;

  vec[2] = wz;

  vec[3] = vx;

  vec[4] = vy;

  vec[5] = vz;



}



void SpatialVector::assign(const VectorObj &lineVec, 

			   const VectorObj &freeVec) {

  

  vec[0] = lineVec[0];

  vec[1] = lineVec[1];

  vec[2] = lineVec[2];



  vec[3] = freeVec[0];

  vec[4] = freeVec[1];

  vec[5] = freeVec[2];



}



void SpatialVector::getLineVector(VectorObj &v) const {

  

  v[0] = vec[0];

  v[1] = vec[1];

  v[2] = vec[2];



}



void SpatialVector::getFreeVector(VectorObj &v) const{

  

  v[0] = vec[3];

  v[1] = vec[4];

  v[2] = vec[5];



}



void SpatialVector::setLineVector(const VectorObj &v) {

  

  vec[0] = v[0];

  vec[1] = v[1];

  vec[2] = v[2];

  

}



void SpatialVector::setFreeVector(const VectorObj &v) {



  vec[3] = v[0];

  vec[4] = v[1];

  vec[5] = v[2];

}



void SpatialVector::print()

{

	printf("( fv(%f, %f, %f) lv(%f, %f, %f) )\n", 

		vec[0], vec[1], vec[2], vec[3], vec[4], vec[5]);

}

