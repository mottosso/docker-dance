/**************************************************

Copyright 2005 by Ari Shapiro and Petros Faloutsos



DANCE

Dynamic ANimation and Control Environment



 ***************************************************************

 ******General License Agreement and Lack of Warranty ***********

 ****************************************************************



This software is distributed for noncommercial use in the hope that it will 

be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility

to anyone for the consequences	of using it or for whether it serves any 

particular purpose or works at all. No warranty is made about the software 

or its performance. Commercial use is prohibited. 



Any plugin code written for DANCE belongs to the developer of that plugin,

who is free to license that code in any manner desired.



Content and code development by third parties (such as FLTK, Python, 

ImageMagick, ODE) may be governed by different licenses.

You may modify and distribute this software as long as you give credit 

to the original authors by including the following text in every file 

that is distributed:

*/

/*********************************************************

	Copyright 2005 by Ari Shapiro and Petros Faloutsos



	DANCE

	Dynamic ANimation and Control Environment

	-----------------------------------------

	AUTHOR:

		Ari Shapiro (ashapiro@cs.ucla.edu)

	ORIGINAL AUTHORS: 

		Victor Ng (victorng@dgp.toronto.edu)

		Petros Faloutsos (pfal@cs.ucla.edu)

	CONTRIBUTORS:

		Yong Cao (abingcao@cs.ucla.edu)

		Paco Abad (fjabad@dsic.upv.es)

**********************************************************/



#include "matrix3x3.h"

#include "arbMatrix.h"

#include "Quaternion.h"

#include "vectorObj.h"

//#include "danceInterp.h"

#include "assert.h"







double Matrix3x3::toGL[16];



Matrix3x3::Matrix3x3(double m[4][4])

{

	for (int i=0 ; i < 3 ; i++) 

		for (int j=0 ; j < 3 ; j++)

			(*this)[i][j] = m[i][j];

}



Matrix3x3::Matrix3x3(float m[4][4])

{

	for (int i=0 ; i < 3 ; i++) 

		for (int j=0 ; j < 3 ; j++)

			(*this)[i][j] = (double) m[i][j];

}



Matrix3x3::Matrix3x3( double xx, double xy, double xz, double yx, double yy, double yz, double zx, double zy, double zz )

{

	(*this)[0][0] = xx;

	(*this)[0][1] = xy;

	(*this)[0][2] = xz;

	(*this)[1][0] = yx;

	(*this)[1][1] = yy;

	(*this)[1][2] = yz;

	(*this)[2][0] = zx;

	(*this)[2][1] = zy;

	(*this)[2][2] = zz;

}





void Matrix3x3::to4x4(double matrix[4][4])

{

	for (int i=0 ; i < 3 ; i++) 

		for (int j=0 ; j < 3 ; j++)

			 matrix[i][j] = (*this)[i][j];

}



void Matrix3x3::from4x4(double matrix[4][4])

{

	for (int i=0 ; i < 3 ; i++) 

		for (int j=0 ; j < 3 ; j++)

			 (*this)[i][j] = matrix[i][j];

}



void Matrix3x3::from4x4(const double matrix[4][4])

{

	for (int i=0 ; i < 3 ; i++) 

		for (int j=0 ; j < 3 ; j++)

			(*this)[i][j] = matrix[i][j];

}





void Matrix3x3::clear() {

  

  int i, j;

  

  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      (*this)[i][j] = 0.0;

    }

  }

}



bool Matrix3x3::operator==(const Matrix3x3 &a) const {

  

  if (fabs(mat[0][0]-a[0][0])>1e-8 || fabs(mat[0][1]-a[0][1])>1e-8 || 

      fabs(mat[0][2]-a[0][2])>1e-8 ||

      fabs(mat[1][0]-a[1][0])>1e-8 || fabs(mat[1][1]-a[1][1])>1e-8 || 

      fabs(mat[1][2]-a[1][2])>1e-8 ||

      fabs(mat[2][0]-a[2][0])>1e-8 || fabs(mat[2][1]-a[2][1])>1e-8 || 

      fabs(mat[2][2]-a[2][2])>1e-8) {

    return false;

  }



  return true;

}



Matrix3x3 &Matrix3x3::operator=(const Matrix3x3 &a) {

  mat[0] = a[0];

  mat[1] = a[1];

  mat[2] = a[2];

  

  return *this;

}



Matrix3x3 &Matrix3x3::identity() {

  clear();

  mat[0][0] = mat[1][1] = mat[2][2] = 1.0;

  

  return *this;

}



void Matrix3x3::operator+=(const Matrix3x3 &a) {

  

  int i, j;

  

  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      mat[i][j] += a[i][j];

    }

  }

}



void Matrix3x3::operator-=(const Matrix3x3 &a) {

  

  int i, j;

  

  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      mat[i][j] -= a[i][j];

    }

  }

}



void Matrix3x3::assignDiagonal(double a, double b, double c) {

  

  mat[0][0] = a;

  mat[1][1] = b;

  mat[2][2] = c;



}



void Matrix3x3::assignDiagonal(const VectorObj &a) {

  mat[0][0] = a[0];

  mat[1][1] = a[1];

  mat[2][2] = a[2];

}



Matrix3x3 Matrix3x3::operator+(const Matrix3x3 &a) const {

  

  int i, j;

  Matrix3x3 result;



  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      result[i][j] = mat[i][j] + a[i][j];

    }

  }



  return result;

}



Matrix3x3 Matrix3x3::operator-(const Matrix3x3 &a) const {

  

  int i, j;

  Matrix3x3 result;



  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      result[i][j] = mat[i][j]- a[i][j];

    }

  }

  return result;

}



Matrix3x3 Matrix3x3::operator*(double a) const {



  int i, j;

  Matrix3x3 result;



  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      result[i][j] = mat[i][j] * a;

    }

  }

  return result;

}



Matrix3x3 Matrix3x3::operator/(double a) const {



  int i, j;

  Matrix3x3 result;



  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      result[i][j] = mat[i][j] / a;

    }

  }

  return result;

}



VectorObj Matrix3x3::operator*(const VectorObj &vec) const {

  

  VectorObj result;

  

  result[0] = vec[0]*mat[0][0] + vec[1]*mat[0][1] + vec[2]*mat[0][2];

  result[1] = vec[0]*mat[1][0] + vec[1]*mat[1][1] + vec[2]*mat[1][2];

  result[2] = vec[0]*mat[2][0] + vec[1]*mat[2][1] + vec[2]*mat[2][2];

  

  return result;

}



void Matrix3x3::detDebug() const {



  

//  danceInterp::OutputMessage("term 0 %f\n", mat[0][0]*mat[1][1]*mat[2][2]);

//  danceInterp::OutputMessage("term 1 %f\n", mat[0][1]*mat[1][2]*mat[2][0]);

//  danceInterp::OutputMessage("term 2 %f\n", mat[0][2]*mat[1][0]*mat[2][1]);

//  danceInterp::OutputMessage("term 3 %f\n", mat[0][0]*mat[1][2]*mat[2][1]);

//  danceInterp::OutputMessage("term 4 %f\n", mat[0][2]*mat[1][1]*mat[2][0]);

//  danceInterp::OutputMessage("term 5 %f\n", mat[0][1]*mat[1][0]*mat[2][2]);

}





double Matrix3x3::determinant() const {

  

  return mat[0][0]*mat[1][1]*mat[2][2] + 

    mat[0][1]*mat[1][2]*mat[2][0] +

    mat[0][2]*mat[1][0]*mat[2][1] -

    mat[0][0]*mat[1][2]*mat[2][1] -

    mat[0][2]*mat[1][1]*mat[2][0] -

    mat[0][1]*mat[1][0]*mat[2][2];

}



Matrix3x3 Matrix3x3::adjoint() const {

  

  Matrix3x3 result;

  

  result[0][0] = mat[1][1]*mat[2][2]-mat[1][2]*mat[2][1];

  result[0][1] = -(mat[0][1]*mat[2][2] - mat[0][2]*mat[2][1]);

  result[0][2] = mat[0][1]*mat[1][2]-mat[0][2]*mat[1][1];

  

  result[1][0] = -(mat[1][0]*mat[2][2]-mat[1][2]*mat[2][0]);

  result[1][1] = mat[0][0]*mat[2][2]-mat[0][2]*mat[2][0];

  result[1][2] = -(mat[0][0]*mat[1][2]-mat[0][2]*mat[1][0]);

  

  result[2][0] = mat[1][0]*mat[2][1]-mat[1][1]*mat[2][0];

  result[2][1] = -(mat[0][0]*mat[2][1]-mat[0][1]*mat[2][0]);

  result[2][2] = mat[0][0]*mat[1][1]-mat[0][1]*mat[1][0];



  return result;

}



void Matrix3x3::operator*=(double a) {

  

  int i, j;

  

  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      mat[i][j] *= a;

    }

  }

}



void Matrix3x3::operator/=(double a) {

  

  int i, j;

  

  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      mat[i][j] /= a;

    }

  }

}



void Matrix3x3::invert() {

  

  double det = determinant();

  (*this) = adjoint();

  (*this) /= det;

  

}



void Matrix3x3::fileDisplay(const char *fName) {

  

  FILE *p;

  

  p = fopen(fName, "a");

  

  fprintf(p, "[<%f %f %f>\n", mat[0][0], mat[0][1], mat[0][2]);

  fprintf(p, " <%f %f %f>\n", mat[1][0], mat[1][1], mat[1][2]);

  fprintf(p, " <%f %f %f>]\n",mat[2][0], mat[2][1], mat[2][2]);

  

  fclose(p);

	  

}



Matrix3x3 Matrix3x3::operator*(const Matrix3x3 &a) const {

  

  Matrix3x3 result;

  int i, j, k;



  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      result[i][j] = 0;

      for (k=0 ; k < 3 ; k++) {

	result[i][j] += mat[i][k]*a[k][j];

      }

    }

  }

  

  return result;

}



void Matrix3x3::operator*=(const Matrix3x3 &a) {

  

  Matrix3x3 tmp = (*this) * a;

  

  *this = tmp;



}



void Matrix3x3::assignRowMajor(double *a) {

  

  int i, j;



  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      mat[i][j] = a[i*3+j];

    }

  }

}



void Matrix3x3::assignColMajor(double *a) {

  

  int i, j;

  

  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      mat[j][i] = a[i*3+j];

    }

  }

}



void Matrix3x3::assignRow(int i, const VectorObj &a) {

  

  mat[i] = a;

}



void Matrix3x3::assignColumn(int i, const VectorObj &a) {

  

  mat[0][i] = a[0];

  mat[1][i] = a[1];

  mat[2][i] = a[2];



}



#if 0

void Matrix3x3::outerProduct(ArbMatrix &a_1x3, ArbMatrix &b_1x3) {

  

  int i, j;

  

  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      mat[i][j] = a_1x3.elem(0, i)*b_1x3.elem(0, j);

    }

  }

}

#endif

void Matrix3x3::outerProduct(const VectorObj &a, const VectorObj &b) {

  

  int i, j;

  

  for (i=0 ; i < 3 ; i++) {

    for (j=0 ; j < 3 ; j++) {

      mat[i][j] = a[i]*b[j];

    }

  }

}



void Matrix3x3::setScale(const VectorObj &s) {

  

  clear();

  mat[0][0] = s[0];

  mat[1][1] = s[1];

  mat[2][2] = s[2];



}



void Matrix3x3::setRotation(VectorObj &axis, double rot) {

  

  Quaternion quat;



  quat.setAxisAngle(axis.data(), rot);

  quat.toMatrix(*this);



}



Matrix3x3 Matrix3x3::transpose() const {

  

  Matrix3x3 result;

  

  result[0][0] = mat[0][0];

  result[1][0] = mat[0][1];

  result[2][0] = mat[0][2];



  result[0][1] = mat[1][0];

  result[1][1] = mat[1][1];

  result[2][1] = mat[1][2];



  result[0][2] = mat[2][0];

  result[1][2] = mat[2][1];

  result[2][2] = mat[2][2];

  

  return result;

}



double* Matrix3x3::getGlMatrix() {

  

  toGL[0] = mat[0][0];

  toGL[1] = mat[1][0];

  toGL[2] = mat[2][0];

  toGL[3] = 0;

  

  toGL[4] = mat[0][1];

  toGL[5] = mat[1][1];

  toGL[6] = mat[2][1];

  toGL[7] = 0;

  

  toGL[8] = mat[0][2];

  toGL[9] = mat[1][2];

  toGL[10] = mat[2][2];

  toGL[11] = 0;

  toGL[12] = 0;

  toGL[13] = 0;

  toGL[14] = 0;

  toGL[15] = 1.0;



  return toGL;

}



#define EulFrmS	     0

#define EulFrmR	     1

#define EulFrm(ord)  ((unsigned)(ord)&1)

#define EulRepNo     0

#define EulRepYes    1

#define EulRep(ord)  (((unsigned)(ord)>>1)&1)

#define EulParEven   0

#define EulParOdd    1

#define EulPar(ord)  (((unsigned)(ord)>>2)&1)

#define EulSafe	     "\000\001\002\000"

#define EulNext	     "\001\002\000\001"

#define EulAxI(ord)  ((int)(EulSafe[(((unsigned)(ord)>>3)&3)]))

#define EulAxJ(ord)  ((int)(EulNext[EulAxI(ord)+(EulPar(ord)==EulParOdd)]))

#define EulAxK(ord)  ((int)(EulNext[EulAxI(ord)+(EulPar(ord)!=EulParOdd)]))

#define EulAxH(ord)  ((EulRep(ord)==EulRepNo)?EulAxK(ord):EulAxI(ord))

    /* EulGetOrd unpacks all useful information about order simultaneously. */

/*#define EulGetOrd(ord,i,j,k,h,n,s,f) {unsigned o=ord;f=o&1;o>>1;s=o&1;o>>1;\

    n=o&1;o>>1;i=EulSafe[o&3];j=EulNext[i+n];k=EulNext[i+1-n];h=s?k:i;}*/

#define EulGetOrd(ord,i,j,k,h,n,s,f) {unsigned o=ord;f=o&1;o=o>>1;s=o&1;o=o>>1;\
    n=o&1;o=o>>1;i=EulSafe[o&3];j=EulNext[i+n];k=EulNext[i+1-n];h=s?k:i;}

    /* EulOrd creates an order value between 0 and 23 from 4-tuple choices. */

#define EulOrd(i,p,r,f)	   (((((((i)<<1)+(p))<<1)+(r))<<1)+(f))

    /* Static axes */

#define EulOrdXYZs    EulOrd(X,EulParEven,EulRepNo,EulFrmS)

#define EulOrdXYXs    EulOrd(X,EulParEven,EulRepYes,EulFrmS)

#define EulOrdXZYs    EulOrd(X,EulParOdd,EulRepNo,EulFrmS)

#define EulOrdXZXs    EulOrd(X,EulParOdd,EulRepYes,EulFrmS)

#define EulOrdYZXs    EulOrd(Y,EulParEven,EulRepNo,EulFrmS)

#define EulOrdYZYs    EulOrd(Y,EulParEven,EulRepYes,EulFrmS)

#define EulOrdYXZs    EulOrd(Y,EulParOdd,EulRepNo,EulFrmS)

#define EulOrdYXYs    EulOrd(Y,EulParOdd,EulRepYes,EulFrmS)

#define EulOrdZXYs    EulOrd(Z,EulParEven,EulRepNo,EulFrmS)

#define EulOrdZXZs    EulOrd(Z,EulParEven,EulRepYes,EulFrmS)

#define EulOrdZYXs    EulOrd(Z,EulParOdd,EulRepNo,EulFrmS)

#define EulOrdZYZs    EulOrd(Z,EulParOdd,EulRepYes,EulFrmS)

    /* Rotating axes */

#define EulOrdZYXr    EulOrd(X,EulParEven,EulRepNo,EulFrmR)

#define EulOrdXYXr    EulOrd(X,EulParEven,EulRepYes,EulFrmR)

#define EulOrdYZXr    EulOrd(X,EulParOdd,EulRepNo,EulFrmR)

#define EulOrdXZXr    EulOrd(X,EulParOdd,EulRepYes,EulFrmR)

#define EulOrdXZYr    EulOrd(Y,EulParEven,EulRepNo,EulFrmR)

#define EulOrdYZYr    EulOrd(Y,EulParEven,EulRepYes,EulFrmR)

#define EulOrdZXYr    EulOrd(Y,EulParOdd,EulRepNo,EulFrmR)

#define EulOrdYXYr    EulOrd(Y,EulParOdd,EulRepYes,EulFrmR)

#define EulOrdYXZr    EulOrd(Z,EulParEven,EulRepNo,EulFrmR)

#define EulOrdZXZr    EulOrd(Z,EulParEven,EulRepYes,EulFrmR)

#define EulOrdXYZr    EulOrd(Z,EulParOdd,EulRepNo,EulFrmR)

#define EulOrdZYZr    EulOrd(Z,EulParOdd,EulRepYes,EulFrmR)



#define DBL_EPSILON 10e-9



int Matrix3x3::matToEuler(int o, VectorObj &eaFinal, 

			  bool staticFrame) const {

  

  int order  = XYZ;

  int i,j,k,h,n,s,f;

  VectorObj ea;



  if (o>=XY) {

    return matToEuler2D(o, eaFinal, staticFrame);

  }



  if (staticFrame==false) {

    switch(o) {

    case XYZ:

      o = ZYX;

      break;

    case XZY:

      o = YZX;

      break;

    case YXZ:

      o = ZXY;

      break;

    case YZX:

      o = XZY;

      break;

    case ZXY:

      o = YXZ;

      break;

    case ZYX:

      o = XYZ;

      break;

    }

  }



  switch(o) {

  case XYZ:

    order = EulOrdXYZs;

    break;

  case XZY:

    order = EulOrdXZYs;

    break;

  case YXZ:

    order = EulOrdYXZs;

    break;

  case YZX:

    order = EulOrdYZXs;

    break;

  case ZXY:

    order = EulOrdZXYs;

    break;

  case ZYX:

    order = EulOrdZYXs;

    break;

  }



  

  EulGetOrd(order,i,j,k,h,n,s,f);

  if (s==EulRepYes) {

    double tmpCombo = mat[i][j]*mat[i][j] + mat[i][k]*mat[i][k];

    if( tmpCombo < 0 )

    {

      tmpCombo = 0;

    }

    double sy = sqrt( tmpCombo );

    if (sy > 16*DBL_EPSILON) {

      ea.x() = atan2(mat[i][j], mat[i][k]);

      ea.y() = atan2(sy, mat[i][i]);

      ea.z() = atan2(mat[j][i], -mat[k][i]);

    } else {

      ea.x() = atan2(-mat[j][k], mat[j][j]);

      ea.y() = atan2(sy, mat[i][i]);

      ea.z() = 0;

    }

  } else {

    double tmpCombo = mat[i][i]*mat[i][i] + mat[j][i]*mat[j][i];

    if( tmpCombo < 0 )

    {

      tmpCombo = 0;

    }

    double cy = sqrt(tmpCombo);

    if (cy > 16*DBL_EPSILON) {

      ea.x() = atan2(mat[k][j], mat[k][k]);

      ea.y() = atan2(-mat[k][i], cy);

      ea.z() = atan2(mat[j][i], mat[i][i]);

    } else {

      ea.x() = atan2(-mat[j][k], mat[j][j]);

      ea.y() = atan2(-mat[k][i], cy);

      ea.z() = 0;

    }

  }

  if (n==EulParOdd) {

    ea.x() = -ea.x(); ea.y() = - ea.y(); ea.z() = -ea.z();

  }



  if (f==EulFrmR) {

    double t = ea.x(); ea.x() = ea.z(); ea.z() = t;

  }



  // final fix!

  switch(o) {

  case XYZ:

    eaFinal = ea;

    break;

  case XZY:

    eaFinal.x() = ea.x();

    eaFinal.y() = ea.z();

    eaFinal.z() = ea.y();

    break;

  case YXZ:

    eaFinal.x() = ea.y();

    eaFinal.y() = ea.x();

    eaFinal.z() = ea.z();

    break;

  case YZX:

    eaFinal.x() = ea.z();

    eaFinal.y() = ea.x();

    eaFinal.z() = ea.y();

    break;

  case ZXY:

    eaFinal.x() = ea.y();

    eaFinal.y() = ea.z();

    eaFinal.z() = ea.x();

    break;

  case ZYX:

    eaFinal.x() = ea.z();

    eaFinal.y() = ea.y();

    eaFinal.z() = ea.x();

    break;

  }

  

  //if (staticFrame==false) {

  if (0) {

    // swap eaFinal.x() and eaFinal.z()

    double t;

    

    t = eaFinal.x();

    eaFinal.x() = eaFinal.z();

    eaFinal.z() = t;



  }



  return 0;

}



void Matrix3x3::matToEuler1DTwoSolutions(int axis, double& solution1, double& solution2)

{

	if (axis == X)

	{

		solution1 = atan2(mat[2][1], mat[2][2]);

		solution2 = atan2(M_PI - mat[2][1], mat[2][2]);

	}

	else if (axis == Y)

	{

		solution1 = atan2(mat[0][2], mat[0][2]);

		solution2 = atan2(M_PI - mat[0][2], mat[0][2]);

	}

	else if (axis == Z)

	{

		solution1 = atan2(mat[1][0], mat[1][1]);

		solution2 = atan2(M_PI - mat[1][0], mat[1][1]);

	}

}



double Matrix3x3::matToEuler1D(int axis)

{
	double result = 0;

	if (axis == X)

	{

		result = atan2(mat[2][1], mat[2][2]);

	}

	else if (axis == Y)

	{

		result = atan2(mat[0][2], mat[0][2]);

	}

	else if (axis == Z)

	{

		result = atan2(mat[1][0], mat[1][1]);

	}



	return result;

/*	

  double result;

  int p0, p1;

  VectorObj pole0, pole1, img0;



  p0 = (axis+1)%3;

  p1 = (axis+2)%3;



  img0[0] = mat[0][p0];

  img0[1] = mat[1][p0];

  img0[2] = mat[2][p0];



  pole0.clear();

  pole0[p0] = 1.0;



  pole1.clear();

  pole1[p1] = 1.0;

  

  result = acos(pole0.dot(img0));

  

  if (img0.dot(pole1)<0) {

    result *= -1;

  }



  return result;

  */

}





int Matrix3x3::matToEuler2D(int rotOrder, VectorObj &eaFinal, 

			    bool staticFrame) const {

  

  VectorObj tt, axis, pole, sign;

  Matrix3x3 tmp, rot;

  double angle;

  int poleIndex, axisIndex;



  tmp = *this;



  if (staticFrame==false) {

    switch(rotOrder) {

    case XY:

      rotOrder = YX;

      break;

    case XZ:

      rotOrder = ZX;

      break;

    case YX:

      rotOrder = XY;

      break;

    case YZ:

      rotOrder = ZY;

      break;

    case ZX:

      rotOrder = XZ;

      break;

    case ZY:

      rotOrder = YZ;

      break;

    }

  }



  // basically, we're finding a poleIndex rotation to align the

  // axisIndex



  switch(rotOrder) {

  case XY:

    // find a y-rotation that aligns the X axis

    poleIndex = 1;

    axisIndex = 0;

    break;

  case XZ:

    // find a z-rotation that aligns the X axis

    poleIndex = 2;

    axisIndex = 0;

    break;

  case YX:

    // find an x-rotation that aligns the y axis

    poleIndex = 0;

    axisIndex = 1;

    break;

  case YZ:

    // find a z-rotations that aligns the y axis

    poleIndex = 2;

    axisIndex = 1;

    break;

  case ZX:

    // find an x-rotation that aligns the z axis

    poleIndex = 0;

    axisIndex = 2;

    break;

  case ZY:

    // find a y rotation that aligns the z axis

    poleIndex = 1;

    axisIndex = 2;

    break;

  default:

	  //danceInterp::OutputMessage("Matrix3x3::matToEuler2D No such order %d", rotOrder);

	  // no such order!

	  return 1 ;

	  break ;

  }



  tt[0] = tmp[0][axisIndex];

  tt[1] = tmp[1][axisIndex];

  tt[2] = tmp[2][axisIndex];

  

  pole.clear();

  pole[poleIndex] = 1;



  axis.clear();

  axis[axisIndex] = 1;



  sign = axis.cross(pole);



#if 0

  if (fabs(tt.dot(pole))>1e-6) {

    danceInterp::OutputMessage("Matrix3x3::matToEuler2D Error A:");

    danceInterp::OutputMessage("<%f %f %f> not perpendicular to <%f %f %f>", 

			    tt[0], tt[1], tt[2], 

			    axis[0], axis[1], axis[2]);

    return 1;

  }

#endif



  double dotprodttaxis = tt.dot(axis);

  if( fabs( dotprodttaxis ) > 1 )

  {

	 tt.normalize();

	 axis.normalize();

	 dotprodttaxis = tt.dot(axis);

  }

  angle = acos( dotprodttaxis );

  if (tt.dot(sign)>0) {

    angle *= -1.0;

  }



  eaFinal[1] = angle;



  rot.setRotateMatrix(poleIndex, -angle);

  rot *= tmp;

  

  // now rot should be a pure axisIndex rotation

  

  tt[0] = rot[0][poleIndex];

  tt[1] = rot[1][poleIndex];

  tt[2] = rot[2][poleIndex];

  

#if 0

  if (fabs(tt.dot(axis))>1e-6) {

    danceInterp::OutputMessage("Matrix3x3::matToEuler2D Error B:");

    danceInterp::OutputMessage("<%f %f %f> not perpendicular to <%f %f %f>", 

			    tt[0], tt[1], tt[2], 

			    axis[0], axis[1], axis[2]);

    return 1;

  }

#endif



  double dotprodttpole = tt.dot(pole);

  if( fabs( dotprodttpole ) > 1 )

  {

	  tt.normalize();

	  pole.normalize();

	  dotprodttpole = tt.dot(pole);

  }

  angle = acos(dotprodttpole);

  if (tt.dot(sign)<0) {

    angle *= -1.0;

  }



  eaFinal[0] = angle;



  if (staticFrame==false) {

    double t;

    // swap

    t = eaFinal[0];

    eaFinal[0] = eaFinal[1];

    eaFinal[1] = t;

  }



  return 0;

}



void Matrix3x3::setRotateMatrix(int axis, double amt) {

  

  double c, s;



  c = cos(amt);

  s = sin(amt);



  switch(axis) {

  case X:

    mat[1][1] = c;

    mat[1][2] = -s;

    mat[2][1] = s;

    mat[2][2] = c;

    mat[0][0] = 1.0;

    mat[1][0] = 0;

    mat[2][0] = 0;

    mat[0][1] = 0;

    mat[0][2] = 0;

    break;

  case Y:

    mat[0][0] = c;

    mat[0][2] = s;

    mat[2][0] = -s;

    mat[2][2] = c;

    mat[1][0] = 0;

    mat[0][1] = 0;

    mat[1][1] = 1;

    mat[2][1] = 0;

    mat[1][2] = 0;

    break;

  case Z:

    mat[0][0] = c;

    mat[0][1] = -s;

    mat[1][0] = s;

    mat[1][1] = c;

    mat[2][0] = 0;

    mat[2][1] = 0;

    mat[2][2] = 1;

    mat[0][2] = 0;

    mat[1][2] = 0;

    break;

  }

}



void Matrix3x3::setDerivRotateMatrix(int axis, double amt) {

  

  double s, c;

  

  s = sin(amt);

  c = cos(amt);

  

  switch(axis) {

  case X:

    mat[0][0] = 0; mat[0][1] = 0; mat[0][2] = 0;

    mat[1][0] = 0; mat[1][1] = -s; mat[1][2] = -c;

    mat[2][0] = 0; mat[2][1] = c; mat[2][2] = -s;

    break;

  case Y:

    mat[0][0] = -s; mat[0][1] = 0; mat[0][2] = c;

    mat[1][0] = 0; mat[1][1] = 0; mat[1][2] = 0;

    mat[2][0] = -c; mat[2][1] = 0; mat[2][2] = -s;

    break;

  case Z:

    mat[0][0] = -s; mat[0][1] = -c; mat[0][2] = 0;

    mat[1][0] = c; mat[1][1] = -s; mat[1][2] = 0;

    mat[2][0] = 0; mat[2][1] = 0; mat[2][2] = 0;

    break;

  }

}



void Matrix3x3::matFromEuler1D(int order, const VectorObj &xyzAngles)

{

	Matrix3x3 m;



	switch (order)

	{

	case Matrix3x3::X:

		m.setRotateMatrix(X, xyzAngles[0]);

		*this = m;

		break;

	case Matrix3x3::Y:

		m.setRotateMatrix(Y, xyzAngles[0]);

		*this = m;

		break;

	case Matrix3x3::Z:

		m.setRotateMatrix(Z, xyzAngles[0]);

		*this = m;

		break;

	}

}



void Matrix3x3::matFromEuler2D(int order, const VectorObj &xyzAngles)

{

	Matrix3x3 m, n;



	switch (order)

	{

	case Matrix3x3::XY:

		m.setRotateMatrix(X, xyzAngles[0]);

		n.setRotateMatrix(Y, xyzAngles[1]);

		*this = n * m;

		break;

	case Matrix3x3::XZ:

		m.setRotateMatrix(X, xyzAngles[0]);

		n.setRotateMatrix(Z, xyzAngles[1]);

		*this = n * m;

		break;

	case Matrix3x3::YX:

		m.setRotateMatrix(Y, xyzAngles[0]);

		n.setRotateMatrix(X, xyzAngles[1]);

		*this = n * m;

		break;

	case Matrix3x3::YZ:

		m.setRotateMatrix(Y, xyzAngles[0]);

		n.setRotateMatrix(Z, xyzAngles[1]);

		*this = n * m;

		break;

	case Matrix3x3::ZX:

		m.setRotateMatrix(Z, xyzAngles[0]);

		n.setRotateMatrix(X, xyzAngles[1]);

		*this = n * m;

		break;

	case Matrix3x3::ZY:

		m.setRotateMatrix(Z, xyzAngles[0]);

		n.setRotateMatrix(Y, xyzAngles[1]);

		*this = n * m;

		break;

	}

}





void Matrix3x3::matFromEuler(int order, const VectorObj &vec) {

  

  Matrix3x3 x, y, z;

  

  x.setRotateMatrix(X, vec.x());

  y.setRotateMatrix(Y, vec.y());

  z.setRotateMatrix(Z, vec.z());

  

  //identity();

  

  switch(order) {

  case XYZ:

    *this = z*y*x;

    break;

  case XZY:

    *this = y*z*x;

    break;

  case YXZ:

    *this = z*x*y;

    break;

  case YZX:

    *this = x*z*y;

    break;

  case ZXY:

    *this = y*x*z;

    break;

  case ZYX:

    *this = x*y*z;

    break;

  }

}



void Matrix3x3::getDeriv(int axis, int rotOrder, Matrix3x3 &deriv) const {



  VectorObj eul;

  Matrix3x3 x, y, z;

  

  matToEuler(rotOrder, eul);

  

  switch(axis) {

  case X:

    x.setDerivRotateMatrix(X, eul.x());

    y.setRotateMatrix(Y, eul.y());

    z.setRotateMatrix(Z, eul.z());

    break;

  case Y:

    x.setRotateMatrix(X, eul.x());

    y.setDerivRotateMatrix(Y, eul.y());

    z.setRotateMatrix(Z, eul.z());

    break;

  case Z:

    x.setRotateMatrix(X, eul.x());

    y.setRotateMatrix(Y, eul.y());

    z.setDerivRotateMatrix(Z, eul.z());

    break;

  }

  

  switch(rotOrder) {

  case XYZ:

    deriv = z*y*x;

    break;

  case XZY:

    deriv = y*z*x;

    break;

  case YXZ:

    deriv = z*x*y;

    break;

  case YZX:

    deriv = x*z*y;

    break;

  case ZXY:

    deriv = y*x*z;

    break;

  case ZYX:

    deriv = x*y*z;

    break;

  }

}



void Matrix3x3::getDeriv(int axis, Matrix3x3 &deriv) const {

  

  VectorObj eul;

  Matrix3x3 x, y, z;



  matToEuler(XYZ, eul);

  

  switch(axis) {

  case X:

    x.setDerivRotateMatrix(X, eul.x());

    y.setRotateMatrix(Y, eul.y());

    z.setRotateMatrix(Z, eul.z());

    break;

  case Y:

    x.setRotateMatrix(X, eul.x());

    y.setDerivRotateMatrix(Y, eul.y());

    z.setRotateMatrix(Z, eul.z());

    break;

  case Z:

    x.setRotateMatrix(X, eul.x());

    y.setRotateMatrix(Y, eul.y());

    z.setDerivRotateMatrix(Z, eul.z());

    break;

  }



  //danceInterp::OutputMessage("Matrix3x3::getDeriv axis %d x", axis);

  //x.printInterp();

  //danceInterp::OutputMessage("y");

  //y.printInterp();

  //danceInterp::OutputMessage("z");

  //z.printInterp();

  

  deriv = z*y*x;



}



void Matrix3x3::matFromAxis(const VectorObj &a) {

  

  double len;

  Quaternion quat;

  VectorObj axis;



  axis = a;

  len = axis.length();

  

  if (len>0) {

    axis /= len;

    

    quat.setAxisAngle(axis.data(), len);

    quat.toMatrix(*this);



  } else {

    identity();

  }

}



void Matrix3x3::matToAxis(VectorObj &axis) const {

  

  Quaternion quat;

  double len;



  quat.fromMatrix(*this);

  quat.getAxisAngle(axis.data(), &len);

  axis *= len;



}





Matrix3x3& Matrix3x3::calcCross(const VectorObj &o) {

  

  mat[0][0] = 0; mat[0][1] = -o.z(); mat[0][2] = o.y();

  mat[1][0] = o.z(); mat[1][1] = 0; mat[1][2] = -o.x();

  mat[2][0] = -o.y(); mat[2][1] = o.x(); mat[2][2] = 0;



  return *this;

}



void Matrix3x3::matToEulerTwoSolutions(int order, VectorObj &eaFinal1, VectorObj &eaFinal2)

{ // from "Computing Euler Angles from a Rotation Matrix", Slabaugh

	double theta1 = 0, theta2 = 0; // Y

	double psi1 = 0, psi2 = 0; // X

	double phi1 = 0, phi2 = 0; // Z



	if (order == XYZ)

	{

		if (this->mat[2][0] != -1.0 && this->mat[2][0] != 1.0)

		{

			theta1 = -asin(this->mat[2][0]);

			theta2 = M_PI - theta1;

			double cosTheta1 = cos(theta1);

			double cosTheta2 = cos(theta2);

			psi1 = atan2(this->mat[2][1] / cosTheta1, this->mat[2][2] / cosTheta1);

			psi2 = atan2(this->mat[2][1] / cosTheta2, this->mat[2][2] / cosTheta2);

			phi1 = atan2(this->mat[1][0] / cosTheta1, this->mat[0][0] / cosTheta1);

			phi2 = atan2(this->mat[1][0] / cosTheta2, this->mat[0][0] / cosTheta2);

		}

		else // gimbal lock

		{

			phi1 = phi2 = 0;

			double delta = atan2(this->mat[0][1], this->mat[0][2]);

			if (this->mat[2][0] == -1.0)

			{

				theta1 = theta2 = M_PI;

				psi1 = psi2 = theta1 + delta;

			}

			else

			{

				theta1 = -M_PI / 2.0;

				psi1 = phi2 = -phi1 + delta;

			}

		}

	}

	else if (order == XZY)

	{

		if (this->mat[1][0] != -1.0 && this->mat[1][0] != 1.0)

		{

			phi1 = asin(this->mat[1][0]);

			phi2 = M_PI - phi1;

			double cosPhi1 = cos(phi1);

			double cosPhi2 = cos(phi2);

			psi1 = atan2(-this->mat[2][2] / cosPhi1, this->mat[2][1] / cosPhi1);

			psi2 = atan2(-this->mat[2][2] / cosPhi2, this->mat[2][1] / cosPhi2);

			theta1 = atan2(-this->mat[2][0] / cosPhi1, this->mat[0][0] / cosPhi1);

			theta2 = atan2(-this->mat[2][0] / cosPhi2, this->mat[0][0] / cosPhi2);

		}

		else // gimbal lock

		{

			phi1 = phi2 = 0;

			double delta = atan2(this->mat[0][1], this->mat[0][2]);

			if (this->mat[2][0] == -1.0)

			{

				theta1 = theta2 = M_PI;

				psi1 = psi2 = theta1 + delta;

			}

			else

			{

				theta1 = -M_PI / 2.0;

				psi1 = phi2 = -phi1 + delta;

			}						

		}

	}

	else if (order == YXZ)

	{

		if (this->mat[2][1] != -1.0 && this->mat[2][1] != 1.0)

		{

			psi1 = asin(this->mat[2][1]);

			psi2 = M_PI - psi1;

			double cosPsi1 = cos(psi1);

			double cosPsi2 = cos(psi2);

			phi1 = atan2(-this->mat[0][1] / cosPsi1, this->mat[1][1] / cosPsi1);

			phi2 = atan2(-this->mat[0][1] / cosPsi2, this->mat[1][1] / cosPsi2);

			theta1 = atan2(-this->mat[0][2] / cosPsi1, this->mat[2][2] / cosPsi1);

			theta2 = atan2(-this->mat[0][2] / cosPsi2, this->mat[2][2] / cosPsi2);

		}

		else // gimbal lock

		{

			assert(false) ;

		}

	}

	else if (order == YZX)

	{

		assert(false) ;

	}

	else if (order == ZXY)

	{

		assert(false) ;

	}

	else if (order == ZYX)

	{

		assert(false) ;

	}





	eaFinal1.assign(-psi1, -theta1, -phi1);

	eaFinal2.assign(-psi2, -theta2, -phi2);

}



int Matrix3x3::getReverseRotationOrder(int order, int numAxis)

{

	if (numAxis == 1)

	{

		return order;

	}

	else if (numAxis == 2)

	{

		switch(order)

		{

		case Matrix3x3::XY:

			return Matrix3x3::YX;

			break;

		case Matrix3x3::XZ:

			return Matrix3x3::ZX;

			break;

		case Matrix3x3::YX:

			return Matrix3x3::XY;

			break;

		case Matrix3x3::YZ:

			return Matrix3x3::ZY;

			break;

		case Matrix3x3::ZX:

			return Matrix3x3::XZ;

			break;

		case Matrix3x3::ZY:

			return Matrix3x3::YZ;

			break;

		default:

			return order;

		}

	}

	else if (numAxis == 3)

	{

		switch (order)

		{

		case Matrix3x3::XYZ:

			return Matrix3x3::ZYX;

			break;

		case Matrix3x3::XZY:

			return Matrix3x3::XZY;

			break;

		case Matrix3x3::YXZ:

			return Matrix3x3::YXZ;

			break;

		case Matrix3x3::YZX:

			return Matrix3x3::XZY;

			break;

		case Matrix3x3::ZXY:

			return Matrix3x3::YXZ;

			break;

		case Matrix3x3::ZYX:

			return Matrix3x3::XYZ;

			break;

		default:

			return order;

		}

	}

	else

	{

		return order;

	}

}







