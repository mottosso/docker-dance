/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _SPATIALMATRIX_
#define _SPATIALMATRIX_

#include "mathdefs.h"
#include "SpatialVector.h"

// ROW MAJOR implementation of a spatial matrix as defined by Featherstone
// in Robot Dynamics Algorithms. Basically, it's a 6x6 matrix. Can
// be thought of as a 2x2 matrix, where each element is a 3x3 matrix

class Matrix3x3;

class SpatialMatrix {

 protected:
  SpatialVector vec[6];
  int numColUsed;
  static SpatialMatrix scratch;

 public:
  
  SpatialMatrix();
  ~SpatialMatrix();
  
  inline SpatialVector& operator[](int i) { return vec[i];}
  inline const SpatialVector& operator[](int i) const { return vec[i];}
  
  void clear();
  SpatialMatrix& identity();

  double *data() { return vec[0].data();}
  const double* data() const { return vec[0].data();}
  

  void add(const SpatialMatrix &a, const SpatialMatrix &b);
  void subtract(const SpatialMatrix &a, const SpatialMatrix &b);
  void multiply(const SpatialMatrix &a, const SpatialMatrix &b);

  void getSubmatrix(int i, int j, Matrix3x3 &mat) const;
  void setSubmatrix(int i, int j, const Matrix3x3 &mat);

  void setTranslate(const VectorObj &vec);
  void setRotation(const Matrix3x3 &mat);

  // This does a translate, then a rotate
  void setXform(const VectorObj &trans, const Matrix3x3 &rot);
  
  void setMomentOfInertia(double mass, const VectorObj &centerOfMass, 
			  const Matrix3x3 &rotInertia);
  
  // invert using LU decomposition. 
  // Use for inverting arbitrary matrices
  void invertLU();

  // invert using LDL decomposition. 
  // Use for symmetric positive definite matrices
  void invertLDL();

  //~~~~~added by alice, summer 05
  int getNumColUsed(){ return numColUsed; }
  void setNumColUsed(int num){ numColUsed = num; }
  inline SpatialMatrix operator+ (const SpatialMatrix &a);
  inline SpatialMatrix operator- (const SpatialMatrix &a);
  inline SpatialMatrix operator* (const SpatialMatrix &a);
  inline SpatialMatrix& operator= (const SpatialMatrix &a);
  //spatial cross, pg29
  SpatialMatrix& calcSpatialCross(const SpatialVector &sv);
  SpatialVector *dataAll() { return vec; }
  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

};

inline SpatialMatrix SpatialMatrix::operator+ (const SpatialMatrix &a)
{
	SpatialMatrix result;
	int i, j;  
	for (i=0 ; i < 6 ; i++) 
	{
		for (j=0 ; j < 6 ; j++) 
		{
			result.vec[i][j] = vec[i][j] + a[i][j];
		}
	}
	return result;
}
inline SpatialMatrix SpatialMatrix::operator- (const SpatialMatrix &a)
{
	SpatialMatrix result;
	int i, j;  
	for (i=0 ; i < 6 ; i++) 
	{
		for (j=0 ; j < 6 ; j++) 
		{
			result.vec[i][j] = vec[i][j] - a[i][j];
		}
	}
	return result;
}
inline SpatialMatrix SpatialMatrix::operator* (const SpatialMatrix &a)
{
	SpatialMatrix result;
	int i, j, k;
	for (i=0 ; i < 6 ; i++) 
	{
		for (j=0 ; j < 6 ; j++) 
		{
			result.vec[i][j] = 0;
			for (k=0 ; k < 6 ; k++) 
			{
				result.vec[i][j] += vec[i][k] * a[k][j];
			}
		}
	}
	return result;
}

inline SpatialMatrix& SpatialMatrix::operator= (const SpatialMatrix &a)
{
	for ( int i=0; i<6; i++ )
	{
		vec[i] = a.vec[i];
	}
	return *this;
}

#endif
