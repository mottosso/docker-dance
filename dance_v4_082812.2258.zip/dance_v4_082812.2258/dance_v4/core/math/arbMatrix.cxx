/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "arbMatrix.h"
#include "blockMatrix.h"
#include "matrix3x3.h"

#include <string>

int ArbMatrix::verb = 1;
Arb2DVector ArbMatrix::nrCopy;
int* ArbMatrix::indxc = 0;
int* ArbMatrix::indxr = 0;
int* ArbMatrix::ipiv = 0;


ArbMatrix::ArbMatrix() {
  
  row = col = 0;
  data = 0;
  dataSize = 0;
}

ArbMatrix::ArbMatrix(const ArbMatrix &a) {
  int i;

  row = a.getRow();
  col = a.getCol();
  dataSize = row*col;

  data = new double[row*col];
  
  for (i=0 ; i < row*col ; i++) {
    data[i] = a.getData()[i];
  }
}

ArbMatrix& ArbMatrix::operator=(const ArbMatrix& a) {
  
  int i;

  setSize(a.getRow(), a.getCol());

  for (i=0 ; i < row*col ; i++) {
    data[i] = a.getData()[i];
  }

  return *this;
}

ArbMatrix::ArbMatrix(int r, int c) {
  
  row = r;
  col = c;
  
  data = new double[row*col];

  dataSize = row*col;
}

ArbMatrix::~ArbMatrix() {
  
  if (data) {
    delete [] data;
  }
}

void ArbMatrix::setIdentity() {

  for (int r = 0; r < row; r++)
    for (int c = 0; c < col; c++)
      if (r == c)
	elem(r, c) = 1.0;
      else
	elem(r, c) = 0.0;
}

void ArbMatrix::setSize(int r, int c) {
  

  if (r==0 && c==0) {

    //if (data) {
    //delete [] data;
    //}

    row = col = 0;
    //data = 0;
  } else if (row!=r || col!=c) {

    if (r*c>dataSize) {
      
      if (data) {
	delete [] data;
      }
      dataSize = r*c;
      data = new double[dataSize];
    }

    row = r;
    col = c;
    
  }
}

void ArbMatrix::mult(ArbVector &to, const ArbVector &from) const {
  
  int i, j;
  
  if (to.size()<row) {
//    danceInterp::OutputMessage("ArbMatrix::mult rowsize mismatch\n");
  }

  if (from.size()<col) {
    //danceInterp::OutputMessage("ArbMatrix::mult colsize mismatch\n");
  }

  for (i=0 ; i < row ; i++) {
    to[i] = 0.0;
    for (j=0 ; j < col ; j++) {
      to[i] += elem(i, j)*from[j];
    }
  }
}

void ArbMatrix::multTransp(ArbVector &to, const ArbVector &from) const {
  
  int i, j;

  if (to.size()<col) {
    //danceInterp::OutputMessage("ArbMatrix::multTransp colsize mismatch\n");
  }

  if (from.size()<row) {
//    danceInterp::OutputMessage("ArbMatrix::multTransp rowsize mismatch\n");
  }
  
  for (i=0 ; i < col ; i++) {
    to[i] = 0.0;
    for (j=0 ; j < row ; j++) {
      to[i] += elem(j, i)*from[j];
    }
  }
}

void ArbMatrix::multTransp(ArbVector &to, double *from) const {
  
  int i, j;
  
  if (to.size()<col) {
//    danceInterp::OutputMessage("ArbMatrix::multTransp colsize mismatch\n");
  }

  for (i=0 ; i < col ; i++) {
    to[i] = 0.0;
    for (j=0 ; j < row ; j++) {
      to[i] += elem(j, i)*from[j];
    }
  }
}

void ArbMatrix::preConditionMult(const ArbMatrix &a, const ArbMatrix &b) {
  
  if (a.getCol()!=b.getRow()) {
//    danceInterp::OutputMessage("ArbMatrix::preConditionMult row/col mismatch");
  }
  
  setSize(a.getRow(), b.getCol());
  
}

void ArbMatrix::multTransp(ArbMatrix &to, const ArbMatrix &from) const {
  
  int i, j, k;
  
  if (col!=from.getCol()) {
//    danceInterp::OutputMessage("ArbMatrix::multTransp warning col/col size mismatch");
  }

  for (j=0 ; j < to.getCol() ; j++) {
    for (i=0 ; i < to.getRow() ; i++) {
      to.elem(i, j) = 0;
      for (k=0 ; k < col ; k++) {
	to.elem(i, j) += elem(i, k) * from.elem(j, k);
      }
    }
  }
}

void ArbMatrix::mult(ArbMatrix &to, const ArbMatrix &from) const {
  
  int i, j, k;

  for (j=0 ; j < to.getCol() ; j++) {
    for (i=0 ; i < to.getRow() ; i++) {
      to.elem(i, j) = 0.0;
      for (k=0 ; k < col ; k++) {
	to.elem(i, j) += elem(i, k)*from.elem(k, j);
      }
    }
  }
}

void ArbMatrix::multResizeTr(ArbMatrix &to, const ArbMatrix &from) const {
  
  int i, j, k;

  if (from.getRow()!=row) {
//    danceInterp::OutputMessage("ArbMatrix::multResizeTr row/col mismatch\n");
  }

  to.setSize(col, from.getCol());

  for (j=0 ; j < to.getCol() ; j++) {
    for (i=0 ; i < to.getRow() ; i++) {
      to.elem(i, j) = 0.0;
      //for (k=0 ; k < col ; k++) {
      for (k=0 ; k < row ; k++) {
	to.elem(i, j) += elemTr(i, k)*from.elem(k, j);
      }
    }
  }

}

void ArbMatrix::multResize(ArbMatrix &to, const ArbMatrix &from) const {
  
  int i, j, k;

  if (from.getRow()!=col) {
//    danceInterp::OutputMessage("ArbMatrix::multResize row/col mismatch\n");
  }
  
  to.setSize(row, from.getCol());
  
  for (j=0 ; j < to.getCol() ; j++) {
    for (i=0 ; i < to.getRow() ; i++) {
      to.elem(i, j) = 0.0;
      for (k=0 ; k < col ; k++) {
	to.elem(i, j) += elem(i, k)*from.elem(k, j);
      }
    }
  }
}

void ArbMatrix::dumpDiagonal(ArbVector &to, int offset) const {
  
  int min, i;
  
  min = row<col?row:col;
  
  for (i=0 ; i < min ; i++) {
    to[i+offset] = elem(i, i);
  }
}

void ArbMatrix::printInterp(bool transp) {
  
  int i, j;
  std::string buf;
  static char tt[64];

  if (!transp) {
    for (i=0 ; i < row ; i++) {
      if (i==0) {
	//sprintf(buf, "[ ");
	buf = "[ ";
      } else {
	//sprintf(buf, "  ");
	buf = "  ";
      }
      for (j=0 ; j < col ; j++) {
	sprintf(tt, "%f ", elem(i, j));
	//strcat(buf, tt);
	buf += tt;
      }
      if (i==row-1) {
	//strcat(buf, " ]");
	buf += " ]";
      }
//      danceInterp::OutputMessage((char*)buf.c_str());
    }
  } else {
    for (i=0 ; i < col ; i++) {
      if (i==0) {
	//sprintf(buf, "[ ");
	buf = "[ ";
      } else {
	//sprintf(buf, "  ");
	buf = "  ";
      }
      for (j=0 ; j < row ; j++) {
	sprintf(tt, "%f ", elem(j, i));
	//strcat(buf, tt);
	buf += tt;
      }
      if (i==col-1) {
	//strcat(buf, " ]");
	buf += " ]";
      }
//      danceInterp::OutputMessage((char*)buf.c_str());
    }
    
  }
}

void ArbMatrix::clear() {
  
  int i, s;
  
  s = row*col;

  for (i=0; i < s ; i++) {
    data[i] = 0;
  }
}

void ArbMatrix::operator+=(const Matrix3x3 &a) {
  
  elem(0, 0) += a[0][0];
  elem(0, 1) += a[0][1];
  elem(0, 2) += a[0][2];

  elem(1, 0) += a[1][0];
  elem(1, 1) += a[1][1];
  elem(1, 2) += a[1][2];

  elem(2, 0) += a[2][0];
  elem(2, 1) += a[2][1];
  elem(2, 2) += a[2][2];

}

void ArbMatrix::operator-=(const ArbMatrix &a) {

  int i, size;
  
  if (row!=a.getRow() || col!=a.getCol()) {
//    danceInterp::OutputMessage("ArbMatrix::operator-= row/col mismatch");
  }

  size = row*col;
  
  for (i=0 ; i < size ; i++) {
    data[i] -= a.data[i];
  }
}

void ArbMatrix::operator+=(const ArbMatrix &a) {
  
  int i, size;
  
  size = row*col;
  
  for (i=0 ; i < size ; i++) {
    data[i] += a.data[i];
  }
}

ArbMatrix& ArbMatrix::operator=(const Matrix3x3 &a) {
  
  elem(0, 0) = a[0][0];
  elem(0, 1) = a[0][1];
  elem(0, 2) = a[0][2];

  elem(1, 0) = a[1][0];
  elem(1, 1) = a[1][1];
  elem(1, 2) = a[1][2];

  elem(2, 0) = a[2][0];
  elem(2, 1) = a[2][1];
  elem(2, 2) = a[2][2];

  return *this;
}

ArbMatrix& ArbMatrix::operator=(const BlockMatrix& a) {
  
  int r, c, i, j;
  int br, bc, aRow, aCol;
  const BlockMatrix::_Block *bl;

  br = a.getBlockRow();
  bc = a.getBlockCol();

  aRow = a.getRow();
  aCol = a.getCol();
  r = aRow*br;
  c = aCol*bc;
  
  setSize(r, c);
  clear();

  // iterate over all blocks
  for (r=0 ; r < aRow ; r++) {
    for (c=0 ; c < aCol ; c++) {
      
      bl = a.getBlock(r, c);
      
      // copy the block
      
      if (bl) {
	for (i=0 ; i < br ; i++) {
	  for (j=0 ; j < bc ; j++) {
	    elem(r*br+i, c*bc+j) = bl->mat.elem(i, j);
	  }
	}
      } else {
	for (i=0 ; i < br ; i++) {
	  for (j=0 ; j < bc ; j++) {
	    elem(r*br+i, c*bc+j) = 0.0;
	  }
	}
      }
    }
  }

  return *this;
}

double ArbMatrix::determinant() const {
  
  double result, pTerm, nTerm;
  int top, i, r, cf, cb;

  result = 0;

  if (row!=col) {
//    danceInterp::OutputMessage("ArbMatrix::determinant called on non-square matrix");
    return result;
  }
  
  if (col==1) {
    return elem(0, 0);
  }

  if (col==2) {
    return elem(0, 0)*elem(1, 1)-elem(1, 0)*elem(0, 1);
  }

  // got this GREAT tip from Cameron Conell @ UCLA for determinant formulation
  // mirror the matrix on both sides. Iterate across top row, shoot two 
  // diagonals. One foreward, one backward. These are your product terms. Add
  // them to the result if they are foreward, subtract if they are backwards. 

  for (top=0 ; top < col ; top++) {

    pTerm = nTerm = 1.0;

    for (i=0 ; i < col ; i++) {
      cf = top+i;
      cb = top-i;
      r = i;
      if (cf>=col) {
	cf -= col;
      }
      if (cb<0) {
	cb += col;
      }
      pTerm *= elem(r, cf);
      nTerm *= elem(r, cb);
    }
    
    result += pTerm;
    result -= nTerm;
  }

  return result;
}



double ArbMatrix::coFactor(int r, int c, ArbMatrix &sc) const {
  
  int i, j, rr, cc;
  double result;

  if (row!=col) {
//    danceInterp::OutputMessage("ArbMatrix::coFactor called on nonsquare matrix");
    return 0;
  }
  
  // copy the current matrix, minus the row(r) and col(c)

  for (i=0 ; i < row-1 ; i++) {
    for (j=0 ; j < col-1 ; j++) {
      if (i>=r) {
	rr = i+1;
      } else {
	rr = i;
      }
      
      if (j>=c) {
	cc = j+1;
      } else {
	cc = j;
      }
      
      sc.elem(i, j) = elem(rr, cc);
    }
  }
  
  result = sc.determinant();
  
  if ((r+c)%2==1) {
    result *= -1;
  }
  
  return result;
}

void ArbMatrix::operator*=(double a) {
  
  int i, s;
  
  s = row*col;
  for (i=0 ; i < s ; i++) {
    data[i] *= a;
  }
}

void ArbMatrix::operator/=(double a) {
  
  int i, s;
  
  s = row*col;
  for (i=0 ; i < s ; i++) {
    data[i] /= a;
  }
}

void ArbMatrix::adjoint(ArbMatrix &a) const {
  
  ArbMatrix sc;
  int i, j;

  a.setSize(row, col);
  sc.setSize(row-1, col-1);

  for (i=0 ; i < row ; i++) {
    for (j=0 ; j < col ; j++) {
      a.elem(i, j) = coFactor(i, j, sc);
    }
  }
}

#define NRANSI
#include "nrutil.h"
#define SWAP(a,b) {temp=(a);(a)=(b);(b)=temp;}

void gaussj(double **a, int n, double **b, int m,
	    int *indxc, int *indxr, int *ipiv) {
  //int *indxc,*indxr,*ipiv;
  int i = 0,icol = 0,irow = 0,j = 0,k = 0,l = 0,ll = 0;
  double big,dum,pivinv,temp;
  
  //indxc=ivector(1,n);
  //indxr=ivector(1,n);
  //ipiv=ivector(1,n);
  
  for (j=1;j<=n;j++) ipiv[j]=0;
  for (i=1;i<=n;i++) {
    big=0.0;
    for (j=1;j<=n;j++) {
      if (ipiv[j] != 1) {
	for (k=1;k<=n;k++) {
	  if (ipiv[k] == 0) {
	    if (fabs(a[j][k]) >= big) {
	      big=fabs(a[j][k]);
	      irow=j;
	      icol=k;
	    }
	  }
	}
      }
    }

    ++(ipiv[icol]);
    if (irow != icol) {
      for (l=1;l<=n;l++) 
	SWAP(a[irow][l],a[icol][l])
	  for (l=1;l<=m;l++) SWAP(b[irow][l],b[icol][l])
			       }
    indxr[i]=irow;
    indxc[i]=icol;
    if (a[icol][icol] == 0.0) nrerror("gaussj: Singular Matrix");
    pivinv=1.0/a[icol][icol];
    a[icol][icol]=1.0;
    for (l=1;l<=n;l++) a[icol][l] *= pivinv;
    for (l=1;l<=m;l++) b[icol][l] *= pivinv;
    for (ll=1;ll<=n;ll++)
      if (ll != icol) {
	dum=a[ll][icol];
	a[ll][icol]=0.0;
	for (l=1;l<=n;l++) a[ll][l] -= a[icol][l]*dum;
	for (l=1;l<=m;l++) b[ll][l] -= b[icol][l]*dum;
      }
  }
  for (l=n;l>=1;l--) {
    if (indxr[l] != indxc[l])
      for (k=1;k<=n;k++)
	SWAP(a[k][indxr[l]],a[k][indxc[l]]);
  }

  //free_ivector(ipiv,1,n);
  //free_ivector(indxr,1,n);
  //free_ivector(indxc,1,n);
}
#undef SWAP
#undef NRANSI

void ArbMatrix::invGaussJordan(ArbMatrix &a) const {
  
  int n, i, j;
  
  n = getRow();
  
  if (nrCopy.getRow()<n) {
    if (indxc) {
      delete [] indxc;
    }
    if (indxr) {
      delete [] indxr;
    }
    if (ipiv) {
      delete [] ipiv;
    }
    
    nrCopy.setSize(n+1, n+1);
    
    indxc = new int[n+1];
    indxr = new int[n+1];
    ipiv = new int[n+1];
  }

  for (i=0 ; i < n ; i++) {
    for (j=0 ; j < n ; j++) {
      nrCopy[i+1][j+1] = elem(i, j);
    }
  }
  
  gaussj(nrCopy.getData(), n, 0, 0, indxc, indxr, ipiv);

  a.setSize(n, n);
  
  for (i=0 ; i < n ; i++) {
    for (j=0 ; j < n ; j++) {
      a.elem(i, j) = nrCopy[i+1][j+1];
    }
  }
}

void ArbMatrix::invLuDecomp(ArbMatrix &a) const {
  
}

void ArbMatrix::inverse(ArbMatrix &a, int type) const {
  
  switch(type) {
  case GAUSS_JORDAN:
    invGaussJordan(a);
    break;
  case LU_DECOMP:
    invLuDecomp(a);
    break;
  }

#if 0
  a.setSize(row, col);
  adjoint(a);
  a /= determinant();
#endif  
}

void ArbMatrix::copy(const BlockMatrix &B) {
  
  int r, c, i, j;
  int br, bc, aRow, aCol;
  const BlockMatrix::_Block *bl;

  br = B.getBlockRow();
  bc = B.getBlockCol();

  aRow = B.getRow();
  aCol = B.getCol();

  // iterate over all blocks
  for (r=0 ; r < aRow ; r++) {
    for (c=0 ; c < aCol ; c++) {
      
      bl = B.getBlock(r, c);
      
      // copy the block
      
      if (bl) {
	for (i=0 ; i < br ; i++) {
	  for (j=0 ; j < bc ; j++) {
	    elem(r*br+i, c*bc+j) = bl->mat.elem(i, j);
	  }
	}
      } else {
	for (i=0 ; i < br ; i++) {
	  for (j=0 ; j < bc ; j++) {
	    elem(r*br+i, c*bc+j) = 0.0;
	  }
	}
      }
    }
  }
}

void ArbMatrix::transpose() {
  
  ArbMatrix tmp;
  int sw, i, j;

  tmp = *this;
  
  sw = row;
  row = col;
  col = sw;
  
  for (i=0 ; i < row ; i++) {
    for (j=0 ; j < col ; j++) {
      elem(i, j) = tmp.elem(j, i);
    }
  }
}

int ArbMatrix::singularFix(double tol) {
  
  int i, j, r, c;
  bool found;

  r = c = -1;

  // find zero row
  for (i=0 ; i < row ; i++) {
    found = true;
    for (j=0 ; j < col ; j++) {
      //if (elem(i, j)!=0.0) {
      if (fabs(elem(i, j))>tol) {
	found = false;
	break;
      }
    }
    if (found) {
      r = i;
      break;
    } 
  }

  // no row found
  if (r==-1) {
    return 0;
  }

  // find zero col
  for (j=0 ; j < col ; j++) {
    found = true;
    for (i=0 ; i < row ; i++) {
      //if (elem(i, j)!=0.0) {
      if (fabs(elem(i, j))>tol) {
	found = false;
	break;
      }
    }
    if (found) {
      c = j;
      break;
    } 
  }

  if (r!=-1 && c!=-1) {
    elem(r, c) = 1.0;
  }
  return (r!=-1 && c!=-1);
}

#if 0
#include <assert.h>

double &ArbMatrix::elem(int r, int c) {
  if (r>=row || c>=col || r<0 || c<0) {
    danceInterp::OutputMessage("ArbMatrix::elem A at %x %d %d size %d %d", 
			    this, r, c, row, col);
    assert(0);
  }
  return data[r*col+c];
}
const double& ArbMatrix::elem(int r, int c) const {
  if (r>=row || c>=col || r<0 || c<0) {
    danceInterp::OutputMessage("ArbMatrix::elem B %d %d", r, c);
    assert(0);
  }
  return data[r*col+c];
}
#endif

bool ArbMatrix::isZero(double tol) {
  
  int s, i;
  bool result;

  s = row * col;
  
  result = true;
  for (i=0 ; i < s ; i++) {
    if (fabs(data[i])>tol) {
      result = false;
      break;
    }
  }

  return result;
}
