/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _ARBVECTOR_
#define _ARBVECTOR_

#include "mathdefs.h"

#include <string>

class ArbVector {
  
 protected:
  int _size;
  double *_data;
  
 public:
  
  ArbVector();
  ArbVector(int size);
  ~ArbVector();

  ArbVector(const ArbVector &a);
  
  int size() const { return _size;}
  void setSize(int s);
  
#if 0
  inline double& operator[](int i) { return _data[i];}
  inline const double& operator[](int i) const { return _data[i];}
#else
  double& operator[](int i);
  const double& operator[](int i) const;
#endif
  
  inline double* data() { return _data;}
  
  void operator*=(double a);
  void operator+=(const ArbVector &a);
  void operator-=(const ArbVector &a);

  ArbVector& operator=(const ArbVector& a);
  ArbVector& operator=(double);

  // this will copy between vectors of arbitrary size
  void copy(const ArbVector &a);

  void clear();
  
  bool operator==(const ArbVector &a) const;
  bool operator==(double) const;

  bool isNan() const;

  void mult(ArbVector &to, double sc);
  void writeTo(double *to);

  void printInterp(int num);
  void printInterp(const char *disp="%f ", int bracket=-1);

  void dumpTo(const char *fName);

};

#endif
