/**************************************************

Copyright 2005 by Ari Shapiro and Petros Faloutsos



DANCE

Dynamic ANimation and Control Environment



 ***************************************************************

 ******General License Agreement and Lack of Warranty ***********

 ****************************************************************



This software is distributed for noncommercial use in the hope that it will 

be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility

to anyone for the consequences	of using it or for whether it serves any 

particular purpose or works at all. No warranty is made about the software 

or its performance. Commercial use is prohibited. 



Any plugin code written for DANCE belongs to the developer of that plugin,

who is free to license that code in any manner desired.



Content and code development by third parties (such as FLTK, Python, 

ImageMagick, ODE) may be governed by different licenses.

You may modify and distribute this software as long as you give credit 

to the original authors by including the following text in every file 

that is distributed:

*/

/*********************************************************

	Copyright 2005 by Ari Shapiro and Petros Faloutsos



	DANCE

	Dynamic ANimation and Control Environment

	-----------------------------------------

	AUTHOR:

		Ari Shapiro (ashapiro@cs.ucla.edu)

	ORIGINAL AUTHORS: 

		Victor Ng (victorng@dgp.toronto.edu)

		Petros Faloutsos (pfal@cs.ucla.edu)

	CONTRIBUTORS:

		Yong Cao (abingcao@cs.ucla.edu)

		Paco Abad (fjabad@dsic.upv.es)

**********************************************************/

#include "SpatialMatrix.h"

#include "matrix3x3.h"



SpatialMatrix SpatialMatrix::scratch;



// these derivations all come from Robot Dynamics Algorithms by Roy 

// Featherstone. (RDA). 



SpatialMatrix::SpatialMatrix() {

	numColUsed = 6;

}



SpatialMatrix::~SpatialMatrix() {



}



void SpatialMatrix::clear() {

  

  vec[0].clear();

  vec[1].clear();

  vec[2].clear();

  vec[3].clear();

  vec[4].clear();

  vec[5].clear();

}



void SpatialMatrix::getSubmatrix(int i, int j, Matrix3x3 &mat) const {

  

  int bi, bj;

  

  bi = i*3;

  bj = j*3;

  

  mat[0][0] = vec[bi][bj];

  mat[0][1] = vec[bi][bj+1];

  mat[0][2] = vec[bi][bj+2];



  mat[1][0] = vec[bi+1][bj];

  mat[1][1] = vec[bi+1][bj+1];

  mat[1][2] = vec[bi+1][bj+2];



  mat[2][0] = vec[bi+2][bj];

  mat[2][1] = vec[bi+2][bj+1];

  mat[2][2] = vec[bi+2][bj+2];



}



void SpatialMatrix::setSubmatrix(int i, int j, const Matrix3x3 &mat) {

  

  int bi, bj;

  

  bi = i*3;

  bj = j*3;

  

  vec[bi][bj] = mat[0][0];

  vec[bi][bj+1] = mat[0][1];

  vec[bi][bj+2] = mat[0][2];



  vec[bi+1][bj] = mat[1][0];

  vec[bi+1][bj+1] = mat[1][1];

  vec[bi+1][bj+2] = mat[1][2];



  vec[bi+2][bj] = mat[2][0];

  vec[bi+2][bj+1] = mat[2][1];

  vec[bi+2][bj+2] = mat[2][2];

  

}



SpatialMatrix& SpatialMatrix::identity() {

  

  clear();

  

  vec[0][0] = 1;

  vec[1][1] = 1;

  vec[2][2] = 1;

  vec[3][3] = 1;

  vec[4][4] = 1;

  vec[5][5] = 1;



  return *this;

}



// RDA p 24



void SpatialMatrix::setTranslate(const VectorObj &vec) {



  Matrix3x3 mat;

  

  mat.clear();

  

  setSubmatrix(0, 1, mat);

  

  mat.identity();

  setSubmatrix(0, 0, mat);

  setSubmatrix(1, 1, mat);



  mat.calcCross(-vec);

  setSubmatrix(1, 0, mat);

  

}



// RDA p 25



void SpatialMatrix::setRotation(const Matrix3x3 &rot) {

  

  Matrix3x3 zero;



  zero.clear();

  

  setSubmatrix(0, 1, zero);

  setSubmatrix(1, 0, zero);

  

  setSubmatrix(0, 0, rot);

  setSubmatrix(1, 1, rot);

  

}



// RDA p 26



void SpatialMatrix::setXform(const VectorObj &trans, const Matrix3x3 &rot) {

  

  Matrix3x3 mat, r;

  

  mat.clear();

  

  setSubmatrix(0, 1, mat);

  

  setSubmatrix(0, 0, rot);

  setSubmatrix(1, 1, rot);

  

  r.calcCross(-trans);

  

  mat = rot*r;

  setSubmatrix(0, 1, mat);

  

}



// RDA p 39

void SpatialMatrix::setMomentOfInertia(double mass, 

				       const VectorObj &com, 

				       const Matrix3x3 &rotInertia) {

  

  Matrix3x3 mat, A, B;

  

  mat.identity() *= mass;

  

  setSubmatrix(0, 1, mat);

  

  mat.calcCross(-com) *= mass;

  setSubmatrix(0, 0, mat);

  

  mat.calcCross(com) *= mass;

  setSubmatrix(1, 1, mat);

  

  A.calcCross(com);

  B.calcCross(-com);



  mat = A*B*mass;

  mat += rotInertia;

  setSubmatrix(1, 0, mat);

}



#include <cmath>

#define NRANSI

#include "nrutil.h"

#define TINY 1.0e-20



void ludcmp(double **a, int n, int *indx, double *d)

{

  int i = 0,imax = 0,j = 0,k = 0;

  double big,dum,sum,temp;

  double *vv;

  

  vv=dvector(1,n);

  *d=1.0;

  for (i=1;i<=n;i++) {

    big=0.0;

    for (j=1;j<=n;j++)

      if ((temp=fabs(a[i][j])) > big) big=temp;

    if (big == 0.0) nrerror("Singular matrix in routine ludcmp");

    vv[i]=1.0/big;

  }

  for (j=1;j<=n;j++) {

    for (i=1;i<j;i++) {

      sum=a[i][j];

      for (k=1;k<i;k++) sum -= a[i][k]*a[k][j];

      a[i][j]=sum;

    }

    big=0.0;

    for (i=j;i<=n;i++) {

      sum=a[i][j];

      for (k=1;k<j;k++)

	sum -= a[i][k]*a[k][j];

      a[i][j]=sum;

      if ( (dum=vv[i]*fabs(sum)) >= big) {

	big=dum;

	imax=i;

      }

    }

    if (j != imax) {

      for (k=1;k<=n;k++) {

	dum=a[imax][k];

	a[imax][k]=a[j][k];

	a[j][k]=dum;

      }

      *d = -(*d);

      vv[imax]=vv[j];

    }

    indx[j]=imax;

    if (a[j][j] == 0.0) a[j][j]=TINY;

    if (j != n) {

      dum=1.0/(a[j][j]);

      for (i=j+1;i<=n;i++) a[i][j] *= dum;

    }

  }

  free_dvector(vv,1,n);

}



void lubksb(double **a, int n, int *indx, double b[])

{

  int i,ii=0,ip,j;

  double sum;

  

  for (i=1;i<=n;i++) {

    ip=indx[i];

    sum=b[ip];

    b[ip]=b[i];

    if (ii)

      for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];

    else if (sum) ii=i;

    b[i]=sum;

  }

  for (i=n;i>=1;i--) {

    sum=b[i];

    for (j=i+1;j<=n;j++) sum -= a[i][j]*b[j];

    b[i]=sum/a[i][i];

  }

}









#undef TINY

#undef NRANSI





void SpatialMatrix::invertLU() {



  int index[6], i, j;

  double c, col[6];



  scratch = *this;

  

  ludcmp((double**)&scratch[-1][-1], 6, index-1, &c);

  

  for (j=1 ; j <= 6 ; j++) {

    for (i=1 ; i <= 6 ; i++) {

      col[i] = 0.0;

    }

    col[j] = 1.0;

    

    lubksb((double**)&scratch[-1][-1], 6, index-1, col-1);

    for (i=1 ; i <= 6 ; i++) {

      vec[i-1][j-1] = col[i];

    }

  }

}



void SpatialMatrix::invertLDL() {



}



void SpatialMatrix::add(const SpatialMatrix &a, const SpatialMatrix &b) {

  

  int i, j;

  

  for (i=0 ; i < 6 ; i++) {

    for (j=0 ; j < 6 ; j++) {

      vec[i][j] = a[i][j] + b[i][j];

    }

  }

}



void SpatialMatrix::subtract(const SpatialMatrix &a, const SpatialMatrix &b) {



  int i, j;

  

  for (i=0 ; i < 6 ; i++) {

    for (j=0 ; j < 6 ; j++) {

      vec[i][j] = a[i][j] - b[i][j];

    }

  }

}



void SpatialMatrix::multiply(const SpatialMatrix &a, const SpatialMatrix &b) {



  int i, j, k;

  

  for (i=0 ; i < 6 ; i++) {

    for (j=0 ; j < 6 ; j++) {

      vec[i][j] = 0;

      for (k=0 ; k < 6 ; k++) {

	vec[i][j] += a[i][k]*b[k][j];

      }

    }

  }

}



SpatialMatrix& SpatialMatrix::calcSpatialCross(const SpatialVector &sv)

{

	Matrix3x3 mat;

	VectorObj lv, fv;

	sv.getFreeVector(fv);

	sv.getLineVector(lv);

	

	mat.calcCross(lv);

	setSubmatrix(0, 0, mat);

	setSubmatrix(1, 1, mat);



	mat.calcCross(fv);

	setSubmatrix(1, 0, mat);



	mat.clear();

	setSubmatrix(0, 1, mat);



	return *this;

}

