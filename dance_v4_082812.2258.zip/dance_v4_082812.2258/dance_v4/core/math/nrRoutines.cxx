/**************************************************************************
	D.A.N.C.E.
	Dynamic Animation aNd Control Environment
	----------------------------------------------
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Ari Shapiro (ashapiro@cs.ucla.edu)
		Yong Cao (abingcao@cs.ucla.edu)
-----------------------------------------------
	
 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

 This software is distributed for noncommercial use in the hope that it will 
 be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
 to anyone for the consequences	of using it or for whether it serves any 
 particular purpose or works at all. No warranty is made about the software 
 or its performance.
***************************************************************************/



#include <cmath>
#define NRANSI
#include "nrutil.h"
#define CON 1.4
#define CON2 (CON*CON)
#define BIG 1.0e30
#define NTAB 10
#define SAFE 2.0

double dfridr(double (*func)(double), double x, double h, double *err) {

  int i,j;
  double errt,fac,hh,**a,ans;
  
  if (h == 0.0) nrerror("h must be nonzero in dfridr.");
  a=dmatrix(1,NTAB,1,NTAB);
  hh=h;
  a[1][1]=((*func)(x+hh)-(*func)(x-hh))/(2.0*hh);
  *err=BIG;
  for (i=2;i<=NTAB;i++) {
    hh /= CON;
    a[1][i]=((*func)(x+hh)-(*func)(x-hh))/(2.0*hh);
    fac=CON2;
    for (j=2;j<=i;j++) {
      a[j][i]=(a[j-1][i]*fac-a[j-1][i-1])/(fac-1.0);
      fac=CON2*fac;
      errt=DMAX(fabs(a[j][i]-a[j-1][i]),fabs(a[j][i]-a[j-1][i-1]));
      if (errt <= *err) {
	*err=errt;
	ans=a[j][i];
      }
    }
    if (fabs(a[i][i]-a[i-1][i-1]) >= SAFE*(*err)) break;
  }
  free_dmatrix(a,1,NTAB,1,NTAB);
  return ans;
}

template <class T>
double dfridrT(T *t, double (T::*func)(double), 
	      double x, double h, double *err) {

  int i,j;
  double errt,fac,hh,**a,ans;
  
  if (h == 0.0) nrerror("h must be nonzero in dfridr.");
  a=dmatrix(1,NTAB,1,NTAB);
  hh=h;
  //a[1][1]=((*func)(x+hh)-(*func)(x-hh))/(2.0*hh);
  a[1][1]=((*t->func)(x+hh)-(*t->func)(x-hh))/(2.0*hh);
  *err=BIG;
  for (i=2;i<=NTAB;i++) {
    hh /= CON;
    //a[1][i]=((*func)(x+hh)-(*func)(x-hh))/(2.0*hh);
    a[1][i]=((*t->func)(x+hh)-(*t->func)(x-hh))/(2.0*hh);
    fac=CON2;
    for (j=2;j<=i;j++) {
      a[j][i]=(a[j-1][i]*fac-a[j-1][i-1])/(fac-1.0);
      fac=CON2*fac;
      errt=DMAX(fabs(a[j][i]-a[j-1][i]),fabs(a[j][i]-a[j-1][i-1]));
      if (errt <= *err) {
	*err=errt;
	ans=a[j][i];
      }
    }
    if (fabs(a[i][i]-a[i-1][i-1]) >= SAFE*(*err)) break;
  }
  free_dmatrix(a,1,NTAB,1,NTAB);
  return ans;
}

#undef CON
#undef CON2
#undef BIG
#undef NTAB
#undef SAFE
#undef NRANSI

