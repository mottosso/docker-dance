/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef _ARBMATRIX_
#define _ARBMATRIX_

#include "mathdefs.h"
#include "arbVector.h"
#include "arb2DVector.h"

class BlockMatrix;
class Matrix3x3;

// Row Major matrix of arbtrary size

class ArbMatrix {
  
 protected:
  
  int row, col;
  double *data;
  int dataSize;
  
  static Arb2DVector nrCopy;
  static int *indxc;
  static int *indxr;
  static int *ipiv;

  void invGaussJordan(ArbMatrix &a) const;
  void invLuDecomp(ArbMatrix &a) const;


 public:
  
  static int verb;

  ArbMatrix(double* m);
  ArbMatrix(const ArbMatrix &a);
  ArbMatrix(int r, int c);
  ArbMatrix(); 
  virtual ~ArbMatrix();
  
  void clear();
  ArbMatrix& operator=(const ArbMatrix &a);
  ArbMatrix& operator=(const BlockMatrix& a);
  ArbMatrix& operator=(const Matrix3x3& a);

  void copy(const BlockMatrix &a);

  inline int getRow() const { return row;}
  inline int getCol() const { return col;}
  inline int getSize() const { return row*col;}

  inline int getRowTr() const { return col;}
  inline int getColTr() const { return row;}

  void setIdentity();
  void setSize(int r, int c);

  inline double* getData() { return data;}
  inline const double* getData() const { return data;}

  // take out the inline to test for out of bounds access. VERY useful
  // for debugging.
#if 1
  inline double &elem(int r, int c) {
    return data[r*col+c];
  }
  inline const double& elem(int r, int c) const {
    return data[r*col+c];
  }
  inline double &elemTr(int r, int c) { return elem(c, r);}
  inline const double& elemTr(int r, int c) const { return elem(c, r);}

#else
  double &elem(int r, int c);
  const double& elem(int r, int c) const;
#endif

  void mult(ArbVector &to, const ArbVector &from) const;
  void multTransp(ArbVector &to, const ArbVector &from) const;
  void multTransp(ArbVector &to, double *from) const;

  // will precondition (resize) the matrix to accept the product
  // this=a*b
  void preConditionMult(const ArbMatrix &a, const ArbMatrix &b);
  
  // will do to=this*from. 'to' must be preconditioned using
  // preConditionMult above
  void mult(ArbMatrix &to, const ArbMatrix &from) const;

  // will do to=this*transp(from). 'to' must be preconditioned
  void multTransp(ArbMatrix &to, const ArbMatrix &from) const;

  // to=this*from - will resize 'to'
  void multResize(ArbMatrix &to, const ArbMatrix &from) const;
  
  // to = tr(this)*from - will resize 'to'
  void multResizeTr(ArbMatrix &to, const ArbMatrix &from) const;

  void dumpDiagonal(ArbVector &to, int offset=0) const;

  void printInterp(bool transp=false);

  void operator+=(const ArbMatrix &mat);
  void operator+=(const Matrix3x3 &mat);
  void operator-=(const ArbMatrix &mat);
  void operator*=(double);
  void operator/=(double);

  // only defined for square matrices
  double determinant() const;

  // provide a scratch matrix to avoid having to reallocate 
  // one on the stack. Should be (row-1, col-1)
  double coFactor(int r, int c, ArbMatrix &sc) const;
  
  enum { GAUSS_JORDAN, LU_DECOMP };
  void inverse(ArbMatrix &a, int type) const;

  // this searches the matrix for a row/column of all zeroes
  // if it finds one, puts a '1' in that row/column and returns 1
  // else returns 0
  int singularFix(double tol=1e-6);
  
  bool isZero(double tol=1e-6);

  void adjoint(ArbMatrix &a) const;

  void transpose();
};

#endif
