/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _BLOCKMATRIX_
#define _BLOCKMATRIX_

#include "mathdefs.h"
#include "arbMatrix.h"

#ifdef WIN32
//#pragma warning(disable:4251 4786)
#endif

#include <deque>
#include <list>

class BlockMatrix {
  
 public:

  typedef struct {
    ArbMatrix mat;
    int row, col;
  } _Block;
  
  static int verb;

 protected:

  typedef std::list<_Block*> blockList;
  typedef std::list<_Block*>::iterator blockListIt;
  typedef std::list<_Block*>::reverse_iterator rBlockListIt;
  typedef std::list<_Block*>::const_iterator cBlockListIt;
  typedef std::list<_Block*>::const_reverse_iterator crBlockListIt;

  std::deque<blockList> rowList, colList;
  
  int blockRow, blockCol;

  friend class DiagonalMatrix;

 public:

  BlockMatrix();
  ~BlockMatrix();
  
  bool isEmpty();
  void clear();
  void zeroBlocks();

  inline int getRow() const { return rowList.size();}
  inline int getCol() const { return colList.size();}

  inline int getBlockRow() const { return blockRow;}
  inline int getBlockCol() const { return blockCol;}

  // row/col is in block units, not scalar units
  // setSize will clear the matrix
  void setSize(int blockRow, int blockCol, int row, int col);

  _Block* addBlock(int row, int col);
  _Block* getBlock(int row, int col);
  const _Block* getBlock(int row, int col) const;

  void removeBlock(int row, int col);

  // debug display routines
  void printInterp(const char *format="%f ");
  void dumpBlockPattern();

  void dumpRow(int row);
  void dumpCol(int col);
  char* getDim();

  // copy the block structure only. Good for creating a block matrix to 
  // be used as an intermediate in a calculation
  void copyBlocks(BlockMatrix &to) const;
  void copyBlocksTransp(BlockMatrix &to) const;
  
  // this preconditions the blockMatrix for multiplying two block matrices
  void preConditionProduct(const BlockMatrix &a, const BlockMatrix &b);
  
  // multiplies to=this*from. 'to' MUST be preconditioned using 
  // preConditionProduct above. The scratch matrix must be presized 
  // scratch.setSize(to.getBlockRow(), to.getBlockCol());
  // Do this at the beginning of the simulation to avoid having to allocate
  // memory for each simulation step
  void mult(BlockMatrix &to, const BlockMatrix &from, 
	    ArbMatrix &scratch) const;

  // this preconditions the blockMatrix for mulitiplying two block matrices
  // one is transposed
  void preConditionProductTransp(const BlockMatrix &regMatrix,
				 const BlockMatrix &transpMatrix);

  // multiplies to=this*transp(from). 'to' MUST be preconditioned using
  // preConditionProductTransp above. The scratch matrix must be presized
  // scratch.setSize(to.getBlockRow(), to.getBlockCol());
  // Do this at the beginning of the simulation to avoid having to allocate
  // memory for each simulation step
  void multTransp(BlockMatrix &to, const BlockMatrix &from, 
		  ArbMatrix &scratch) const;

  // to = tr(this)*from
  void multTransp(ArbVector &to, double *from) const;
  void multTransp(ArbVector &to, const ArbVector &from) const;
  
  // to = this*from
  void mult(ArbVector &to, const ArbVector &from) const;
  void mult(ArbVector &to, double *from) const;

  void dumpDiagonal(ArbVector &to) const;
};

#endif
