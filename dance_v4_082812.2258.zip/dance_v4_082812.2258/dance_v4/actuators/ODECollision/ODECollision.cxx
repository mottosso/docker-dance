/**************************************************

Copyright 2005 by Ari Shapiro and Petros Faloutsos



DANCE

Dynamic ANimation and Control Environment



 ***************************************************************

 ******General License Agreement and Lack of Warranty ***********

 ****************************************************************



This software is distributed for noncommercial use in the hope that it will 

be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility

to anyone for the consequences	of using it or for whether it serves any 

particular purpose or works at all. No warranty is made about the software 

or its performance. Commercial use is prohibited. 



Any plugin code written for DANCE belongs to the developer of that plugin,

who is free to license that code in any manner desired.



Content and code development by third parties (such as FLTK, Python, 

ImageMagick, ODE) may be governed by different licenses.

You may modify and distribute this software as long as you give credit 

to the original authors by including the following text in every file 

that is distributed: */



/*********************************************************

	Copyright 2005 by Ari Shapiro and Petros Faloutsos



	DANCE

	Dynamic ANimation and Control Environment

	-----------------------------------------

	AUTHOR:

		Ari Shapiro (ashapiro@cs.ucla.edu)

	ORIGINAL AUTHORS: 

		Victor Ng (victorng@dgp.toronto.edu)

		Petros Faloutsos (pfal@cs.ucla.edu)

	CONTRIBUTORS:

		Yong Cao (abingcao@cs.ucla.edu)

		Paco Abad (fjabad@dsic.upv.es)

**********************************************************/



#include "ODECollision.h"

#include "dance.h"

#include "danceInterp.h"

#include "DObjectList.h"

#include "DSimulatorManager.h"

#include "ViewManager.h"

#include "DCollision.h"

#include "DCollisionHierarchy.h"

#include "ODECollisionWindow.h"

#include "ArticulatedObject.h"

#include "Link.h"

#include "Model.h"

#include "Cube.h"

#include "Sphere.h"

#include "Capsule.h"

#include "Plane.h"

#include "matrix3x3.h"

#include "Quaternion.h"

#include "ODESim.h"


using namespace std;



PlugIn *Proxy()

{

	return new ODECollision;

};





PlugIn *ODECollision::create(int argc, char **argv)

{



    danceInterp::OutputMessage("Allocating ODECollision.") ;

    ODECollision	*g = new ODECollision();



    if(	g == NULL )

    {

		danceInterp::OutputMessage("ERROR: out of memory.") ;

		return g ;

    }



    return g ;

}





ODECollision::ODECollision() : DActuator()

{

	odeCollisionWindow = NULL;



	dance::AllSimulators->addSimStartCB(this, -1, simStartCB);

	dance::AllSimulators->addBeforeSimStepCB(this, -1, simBeforeStepCB);

	dance::AllSimulators->addAfterSimStepCB(this, -1, simAfterStepCB);



	numCol = 0;



	this->setShowCollisionPoints(false);

	this->setSelfCollisions(true);

	this->setLinkCollisions(false);

	this->setDisableAdjacentLinks(true);



	currentSpace = NULL;

	setShowCollisionGeometry(false);



	this->setSpaceType(ODECollision::SPACEHASH);

//    this->setSpaceType(ODECollision::SPACEQUADTREE);

 

	this->setContactGroupID(NULL);



	resetAllContactFlags();

	this->setContactFlags("dContactBounce", true);



	this->contactMu = .1f;

	this->contactMu2 = .1f;

	this->contactBounce = 0.1f;

	this->contactBounceVel = 0.0f;

	this->contactSoftCFM = .1f;

	this->contactSoftERP = .1f;

	this->contactMotion1 = .1f;

	this->contactMotion2 = .1f;

	this->contactSlip1 = .1f;

	this->contactSlip2 = .1f;	

}



ODECollision::~ODECollision()

{

	if (odeCollisionWindow != NULL)

		delete odeCollisionWindow;



	clearCollisionInfo();



	// delete the contact joint group

	if (this->getContactGroupID() != NULL)

		dJointGroupDestroy(this->getContactGroupID());



	// delete the Collision space, ODE destroy requires non-null

	if (NULL != this->currentSpace)

	{

		dSpaceDestroy(this->currentSpace);

	}

}



void ODECollision::startSimulation()

{

	// remove the old space

	clearCollisionInfo();



	for(int i = 0; i < MAX_CONTACTS; i++)

	{

		contact[i].surface.mode = this->contactFlags; 

		contact[i].surface.mu = this->contactMu;

		contact[i].surface.mu2 = this->contactMu2;

		contact[i].surface.bounce = this->contactBounce;

		contact[i].surface.bounce_vel = this->contactBounceVel;

		contact[i].surface.soft_erp = this->contactSoftERP;

		contact[i].surface.soft_cfm = this->contactSoftCFM;

		contact[i].surface.motion1 = this->contactMotion1;

		contact[i].surface.motion2 = this->contactMotion2;

		contact[i].surface.slip1 = this->contactSlip1;

		contact[i].surface.slip2 = this->contactSlip2;

	}



	// create the new space

	if (this->getSpaceType() == ODECollision::SPACESIMPLE)

	{

		currentSpace = dSimpleSpaceCreate(0);

	}

	else if (this->getSpaceType() == ODECollision::SPACEHASH)

	{

		currentSpace = dHashSpaceCreate(0);

	}
	else if (this->getSpaceType() == ODECollision::SPACEQUADTREE)

	{

        dVector3 min;

        min[0] = min[1] = min[2] = 0.0;

        dVector3 extent;

        extent[0] = extent[1] = extent[2] = 100000.0;

        

        currentSpace = dQuadTreeSpaceCreate( 0, min, extent, 1 );

	}
	

	int systemsAffected = 0;

	if (this->isAppliedAllObjects())

		systemsAffected = dance::AllSystems->size();

	else

		systemsAffected = this->getNumAppliedObjects();



	for (int x = 0; x < systemsAffected; x++)

	{

		DSystem* system = NULL;

		if (this->isAppliedAllObjects())

			system = (DSystem*) dance::AllSystems->get(x);

		else

			system = (DSystem*) this->getAppliedObject(x);

		ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(system);

		if (ao == NULL)

		{

			danceInterp::OutputMessage("System %s is not an articulated object. No collisions set for that system.", system->getName());

			continue;

		}



		for (int l = 0; l < ao->getNumLinks(); l++)

		{

			Link* link = ao->getLink(l);

			double invMat[4][4];



			// check for props

			DGeometry* prop = link->getGeometryProp();

			if (prop != NULL)

			{

				link->getInvGeometryPropTransMat(invMat);

				ODECollisionData* data = this->createCollisionData(ao, l, prop, invMat);			

				if (data != NULL)

				{

					collisions.push_back(data);

				}

				else

				{

					danceInterp::OutputMessage("Cannot use prop %s for ODE collisions. No collisions for link will be calculated.", prop->getName());

				}

			}



			// use collisions on 1) collision geometry, then 2) collision spheres, then 3) geometry

			DGeometry* geometry = link->getGeometryCollision(); // collision geometry

			if (geometry != NULL)

			{

				link->getInvGeometryCollisionTransMat(invMat);

				ODECollisionData* data = this->createCollisionData(ao, l, geometry, invMat);			

				if (data != NULL)

				{

					collisions.push_back(data);

					continue;

				}

				else

				{

					danceInterp::OutputMessage("Cannot use collision geometry '%s' for ODE collisions. Trying collision spheres...", geometry->getName());

				}

			}

			int numSpheres = link->getNumSpheres();

			for (int s = 0; s < numSpheres; s++) // collision spheres

			{

				double radius = link->getSphereScale(s);

				Vector offset;

				link->getSphereTranslation(s, offset[0], offset[1], offset[2]);

				ODECollisionData* data = this->createCollisionData(ao, l, s, radius, offset);			

				if (data != NULL)

					collisions.push_back(data);

			}	

			if (numSpheres == 0)

			{

				geometry = link->getGeometry(); // regular geometry

				if (geometry != NULL)

				{

					link->getInvGeometryTransMat(invMat);

					ODECollisionData* data = this->createCollisionData(ao, l, geometry, invMat);			

					if (data != NULL)

					{

						collisions.push_back(data);

						continue;

					}

					else

					{

						danceInterp::OutputMessage("Cannot use geometry %s for ODE collisions. No collisions for link will be calculated.", geometry->getName());

					}

				}

			}

		}

	}



	// make sure this fixed geometry doesn't already exist...

	// could happen when a fixed geometry suddenly becomes a simulated object

	bool found = true;

	while (found)

	{

		found = false;

		for (int x = 0; x < this->getNumFixedGeometries(); x++)

		{

			DGeometry* geometry = this->getFixedGeometry(x);

			for (unsigned int c = 0; c < this->collisions.size(); c++)

			{

				if (this->collisions[c]->geom == geometry)

				{

					found = true;

					this->removeFixedGeometry(geometry);

					break;

				}

			}

			if (found)

				break;

		}

	}



	// now add the fixed geometry

	for (int x = 0; x < this->getNumFixedGeometries(); x++)

	{

		DGeometry* geometry = this->getFixedGeometry(x);

		ODECollisionData* data = this->createCollisionData(NULL, -1, geometry, NULL);			

		if (data != NULL)

			collisions.push_back(data);

	}

}



ODECollisionData* ODECollision::createCollisionData(ArticulatedObject* ao, int linkNum, int sphereNum, double radius, Vector offset)

{

	ODECollisionData* data = new ODECollisionData();

	data->ao = ao;

	if (ao != NULL)

		data->sim = dynamic_cast<ODESim*>(ao->getSimulator(0));

	data->linkNum = linkNum;

	data->sphereNum = sphereNum;

	data->sphereRadius = radius;

	VecCopy(data->sphereOffset, offset);



	dGeomID id = dCreateSphere(currentSpace, radius);

	data->geomID = id;



	return data;

}



ODECollisionData* ODECollision::createCollisionData(ArticulatedObject* ao, int linkNum, DGeometry* geometry, double invMat[4][4])

{

	Model* model = dynamic_cast<Model*>(geometry);

	if (model != NULL)

		return createModel(ao, linkNum, model, invMat);



	Cube* cube = dynamic_cast<Cube*>(geometry);

	if (cube != NULL)

		return createCube(ao, linkNum, cube, invMat);



	Plane* plane = dynamic_cast<Plane*>(geometry);

	if (plane != NULL)

		return createPlane(ao, linkNum, plane, invMat);



	Sphere* sphere = dynamic_cast<Sphere*>(geometry);

	if (sphere != NULL)

		return createSphere(ao, linkNum, sphere, invMat);



	Capsule* capsule = dynamic_cast<Capsule*>(geometry);

	if (capsule != NULL)

		return createCapsule(ao, linkNum, capsule, invMat);



	CompositeGeometry* composite = dynamic_cast<CompositeGeometry*>(geometry);

	if (composite != NULL)

	{

		// createComposite function will add collision data automatically

		createComposite(ao, linkNum, composite, invMat);

		return NULL;

	}



	danceInterp::OutputMessage("Unknown geometry type for object '%s', cannot create collision data.", geometry->getName());

	return NULL;

}



ODECollisionData* ODECollision::createModel(ArticulatedObject* ao, int linkNum, Model* model, double invMat[4][4])

{

	ODECollisionData* data = new ODECollisionData();

	data->linkNum = linkNum;

	data->geom = model;

	data->ao = ao;

	double scaling[3] = {1.0, 1.0, 1.0};

	if (ao != NULL)

	{

		data->sim = dynamic_cast<ODESim*>(ao->getSimulator(0));

		// account for any link scaling

		Link* link = ao->getLink(linkNum);

		if (model == link->getGeometry())

		{

			double* geomScale = link->getGeometryScale();

			VecCopy(scaling, geomScale);

		}

		else if (model == link->getGeometryCollision())

		{

			double* geomScale = link->getGeometryCollisionScale();

			VecCopy(scaling, geomScale);

		}

	}



	// create the mesh

	data->meshData = new MeshData();



	// calculate the current vertex positions 

	// based on the transformation matrix

	double transMatrix[4][4];

	model->getTransMatrix(transMatrix);



	// factor in the scaling

	for (int s = 0; s < 3; s++)

		transMatrix[s][s] *= scaling[s];



	// calculate the model's vertices

	data->meshData->numVertices = model->numvertices;

	data->meshData->vertices = new double[model->numvertices * 3];

	for (unsigned int v = 0; v < model->numvertices; v++)

	{

		Vector point = { model->vertices[v * 3], 

					     model->vertices[v * 3 + 1], 

					     model->vertices[v * 3 + 2] };



		transformPoint_mat(point, transMatrix);

		for (int x = 0; x < 3; x++)

		{

			data->meshData->vertices[v * 3 + x] = point[x];

		}

	}



	// copy the model's triangles

	data->meshData->numTriangles = model->numtriangles;

	data->meshData->triangles = new int[model->numtriangles * 3];

	for (unsigned int t = 0; t < model->numtriangles; t++)

	{

		for (int x = 0; x < 3; x++)

		{

			data->meshData->triangles[t * 3 + x] = model->triangles[t].vindices[x];

		}

	}



	// pass in the vertices and faces

	dTriMeshDataID trimeshId = dGeomTriMeshDataCreate(); 

	dGeomTriMeshDataBuildDouble (trimeshId,

        // Vertices

		data->meshData->vertices,

		3*sizeof(double), data->meshData->numVertices,

        // Faces

		data->meshData->triangles,

		data->meshData->numTriangles, 3*sizeof(int));



	dGeomID id = dCreateTriMesh (currentSpace, trimeshId,

                        NULL,

                        NULL,

                        NULL);



	data->geomID = id;

	if (invMat != NULL)

		D2ArrayCopy(4, 4, &data->invMat[0][0], &invMat[0][0]);



	return data;

}



ODECollisionData* ODECollision::createCube(ArticulatedObject* ao, int linkNum, Cube* cube, double invMat[4][4])

{

	ODECollisionData* data = new ODECollisionData();

	data->linkNum = linkNum;

	data->geom = cube;

	data->ao = ao;

	if (ao != NULL)

		data->sim = dynamic_cast<ODESim*>(ao->getSimulator(0));



	// get the length, width and height

	Vector scaling;

	cube->getScaling(scaling);

	double length = scaling[0];

	double width = scaling[1];

	double height = scaling[2];

	dGeomID id = dCreateBox(currentSpace, length, width, height); 

	data->geomID = id;

	if (invMat != NULL)

		D2ArrayCopy(4, 4, &data->invMat[0][0], &invMat[0][0]);

	return data;

}



ODECollisionData* ODECollision::createSphere(ArticulatedObject* ao, int linkNum, Sphere* sphere, double invMat[4][4])

{

	ODECollisionData* data = new ODECollisionData();

	data->linkNum = linkNum;

	data->geom = sphere;

	data->ao = ao;

	if (ao != NULL)

		data->sim = dynamic_cast<ODESim*>(ao->getSimulator(0));



	// get the radius of the sphere

	// since spheres may be scaled non-uniformly, take the largest axis

	Vector scaling;

	sphere->getScaling(scaling);

	double radius = scaling[0];

	if (radius < scaling[1])

		radius = scaling[1];

	if (radius < scaling[2])

		radius = scaling[2];

	dGeomID id = dCreateSphere(currentSpace, radius);

	data->geomID = id;

	if (invMat != NULL)

		D2ArrayCopy(4, 4, &data->invMat[0][0], &invMat[0][0]);

	return data;

}



ODECollisionData* ODECollision::createCapsule(ArticulatedObject* ao, int linkNum, Capsule* capsule, double invMat[4][4])

{

	ODECollisionData* data = new ODECollisionData();

	data->linkNum = linkNum;

	data->geom = capsule;

	data->ao = ao;

	if (ao != NULL)

		data->sim = dynamic_cast<ODESim*>(ao->getSimulator(0));



	// get the radius and length of the capsule

	// capsules do not use the scaling parameters

	double radius = capsule->getRadius();

	double length = capsule->getLength();

	dGeomID id = dCreateCCylinder (currentSpace, radius, length);

	data->geomID = id;

	if (invMat != NULL)

		D2ArrayCopy(4, 4, &data->invMat[0][0], &invMat[0][0]);

	return data;

}



ODECollisionData* ODECollision::createPlane(ArticulatedObject* ao, int linkNum, Plane* plane, double invMat[4][4])

{

	 // new method, use a flattened cube so as to match the size of the DANCE plane 

	ODECollisionData* data = new ODECollisionData();

	data->linkNum = linkNum;

	data->geom = plane;

	data->ao = ao;

	if (ao != NULL)

		data->sim = dynamic_cast<ODESim*>(ao->getSimulator(0));



	// get the length, width and height

	Vector scaling;

	plane->getScaling(scaling);

	double length = scaling[0];

	double width = scaling[2];

	VecCopy(data->planeLengths, scaling);

	dGeomID id = dCreateBox(currentSpace, length, PLANE_WIDTH, width); // create a flat box to simulate a plane

	data->geomID = id;

	if (invMat != NULL)

		D2ArrayCopy(4, 4, &data->invMat[0][0], &invMat[0][0]);

	data->isPlane = true;

	return data;

}



void ODECollision::createComposite(ArticulatedObject* ao, int linkNum, CompositeGeometry* composite, double invMat[4][4])

{

	std::vector<ODECollisionData*> datas;



	if (composite != NULL)

	{

		double compositeTransMatrix[4][4];

		composite->getTransMatrix(compositeTransMatrix);

		for (int x = 0; x < composite->getNumGeometries(); x++)

		{

			ODECollisionData* data = NULL;



			DGeometry* compositePart = composite->getGeometry(x);

			Cube* cube = dynamic_cast<Cube*>(compositePart);

			if (cube != NULL)

			{

				data = createCube(ao, linkNum, cube, invMat);

			}

			

			Plane* plane = dynamic_cast<Plane*>(compositePart);

			if (plane != NULL)

			{

				data = createPlane(ao, linkNum, plane, invMat);

			}



			Sphere* sphere = dynamic_cast<Sphere*>(compositePart);

			if (sphere != NULL)

			{

				data = createSphere(ao, linkNum, sphere, invMat);

			}



			Capsule* capsule = dynamic_cast<Capsule*>(compositePart);

			if (capsule != NULL)

			{

				data = createCapsule(ao, linkNum, capsule, invMat);

			}



			if (data != NULL)

			{

				data->hasCompositeMatrix = true;

				copyMatrix44(data->compositeMat, compositeTransMatrix);

				collisions.push_back(data);

			}

		}

	}

}



void ODECollision::beforeStep(double time)

{

	forcesApplied = false;



	// save the old mesh/model positions

	for (unsigned int m = 0; m < this->collisions.size(); m++)

	{

		if (dGeomGetClass(this->collisions[m]->geomID) == dTriMeshClass)

		{

			if (this->collisions[m]->bodyID != NULL)

			{

//				 const double *DoubleArrayPtr =  Bodies[BodyIndex].TransformationMatrix->GetArray();

//				 dGeomTriMeshDataSet( this->collisions[m]->bodyID, TRIMESH_LAST_TRANSFORMATION, (void *) DoubleArrayPtr );

			}

		}

	}

}



void ODECollision::afterStep(double time)

{

	// remove the joint group for contact joints

	if (contactGroupID != NULL)

	{

		dJointGroupEmpty(contactGroupID);

	}

}





void ODECollision::ExertLoad(DSystem *mainsys, DSimulator* simulator, double time, double dt, double *state, double *dstate)

{

	if (this->getNumAppliedObjects() == 0 && !this->isAppliedAllObjects())

		return;



	if (!this->forcesApplied)

	{

		forcesApplied = true;

		this->updateMatrices();

		dSpaceCollide(currentSpace, this, collideCallback);

	}

}





void ODECollision::output(int mode)

{

	if (this->isShowCollisionPoints())

	{

		glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT);

		glDisable(GL_LIGHTING);

		glColor3f(1.0, 1.0, 0.0);

		glPointSize(20);

		glBegin(GL_POINTS);

		for (int x = 0; x < numCol; x++)

		{	

			glVertex3d(curCollisions[x][0], curCollisions[x][1], curCollisions[x][2]);

		}

		glEnd();

		glPopAttrib();

	}



	if (this->isShowCollisionGeometry())

	{

		glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT);

		glDisable(GL_LIGHTING);

		glColor3f(1.0, 1.0, 0.0);

		for (unsigned int x = 0; x < this->collisions.size(); x++)

		{

			int type = dGeomGetClass(this->collisions[x]->geomID);

			switch (type)

			{

			case dBoxClass:

				{

					dVector3 result;

					dGeomBoxGetLengths(this->collisions[x]->geomID, result);

					Vector half = {result[0] / 2.0, result[1] / 2.0, result[2] / 2.0};

					double matrix[4][4];

					setIdentMat(&matrix[0][0], 4);

					const dReal* rotation = dGeomGetRotation(this->collisions[x]->geomID);

					for (int r = 0; r < 3; r++)

						for (int c = 0; c < 3; c++)

							 matrix[c][r] = rotation[r * 4 + c];

					const dReal* pos = dGeomGetPosition(this->collisions[x]->geomID);

					for (int p = 0; p < 3; p++)

						matrix[3][p] = pos[p];



					// unit cube

					Vector points[8];

					setVector(points[0], half[0], half[1], half[2]);

					setVector(points[1], half[0], -half[1], half[2]);

					setVector(points[2], half[0], half[1], -half[2]);

					setVector(points[3], half[0], -half[1], -half[2]);

					setVector(points[4], -half[0], half[1], half[2]);

					setVector(points[5], -half[0], -half[1], half[2]);

					setVector(points[6], -half[0], half[1], -half[2]);

					setVector(points[7], -half[0], -half[1], -half[2]);

					glPushMatrix();

					glMultMatrixd(&matrix[0][0]);

					drawBox(points);

					glPopMatrix();

				}

				break;

			case dSphereClass:

				{

					double radius = dGeomSphereGetRadius(this->collisions[x]->geomID);

					double matrix[4][4];

					setIdentMat(&matrix[0][0], 4);

					const dReal* rotation = dGeomGetRotation(this->collisions[x]->geomID);

					for (int r = 0; r < 3; r++)

						for (int c = 0; c < 3; c++)

							 matrix[c][r] = rotation[r * 4 + c];

					const dReal* pos = dGeomGetPosition(this->collisions[x]->geomID);

					for (int p = 0; p < 3; p++)

						matrix[3][p] = pos[p];

					

					glPushMatrix();

					glMultMatrixd(&matrix[0][0]);

					glutWireSphere(radius, 10, 10);

					glPopMatrix();

				}

				break;

			case dCCylinderClass:

				{

					double matrix[4][4];

					setIdentMat(&matrix[0][0], 4);

					const dReal* rotation = dGeomGetRotation(this->collisions[x]->geomID);

					for (int r = 0; r < 3; r++)

						for (int c = 0; c < 3; c++)

							 matrix[c][r] = rotation[r * 4 + c];

					const dReal* pos = dGeomGetPosition(this->collisions[x]->geomID);

					for (int p = 0; p < 3; p++)

						matrix[3][p] = pos[p];





					dReal radius, length;

					dGeomCCylinderGetParams(this->collisions[x]->geomID, &radius, &length);

					glPushMatrix();

					glMultMatrixd(&matrix[0][0]);

					glTranslated(0, 0, -length / 2.0);

					//gluCylinder(qobj, radius, radius, length, 10, 10);

					GLUquadricObj* qobj=gluNewQuadric();

					gluQuadricDrawStyle(qobj, GLU_FILL);

					gluQuadricNormals(qobj, GLU_SMOOTH);

					gluQuadricTexture(qobj, GL_TRUE);

					gluCylinder(qobj, radius, radius, length, 10, 10);



					glutWireSphere(radius, 10, 10);

					glTranslated(0, 0, length);

					glutWireSphere(radius, 10, 10);

					glPopMatrix();

				}

				break;

			case dPlaneClass:

				danceInterp::OutputMessage("DANCE is not current using ODE's plane structure...");

				break;

			case dTriMeshClass:

				{

					double matrix[4][4];

					setIdentMat(&matrix[0][0], 4);

					const dReal* rotation = dGeomGetRotation(this->collisions[x]->geomID);

					for (int r = 0; r < 3; r++)

						for (int c = 0; c < 3; c++)

							 matrix[c][r] = rotation[r * 4 + c];

					const dReal* pos = dGeomGetPosition(this->collisions[x]->geomID);

					for (int p = 0; p < 3; p++)

						matrix[3][p] = pos[p];

					

					

					glPushMatrix();

//					glMultMatrixd(&matrix[0][0]);



					int numTriangles = dGeomTriMeshGetTriangleCount(this->collisions[x]->geomID);

					glBegin(GL_TRIANGLES);

					dVector3 v0, v1, v2;

					for (int t = 0; t < numTriangles * 3; t++)

					{

						dGeomTriMeshGetTriangle (this->collisions[x]->geomID, t, &v0,

                              &v1, &v2);

						glVertex3dv((const GLdouble*)v0);

						glVertex3dv((const GLdouble*)v1);

						glVertex3dv((const GLdouble*)v2);

					}

					glEnd();

					glPopMatrix();			

				}

				break;

			}

		}

		glPopAttrib();

	}



}



void ODECollision::drawBox(Vector points[8])

{

	// -X side

	glBegin(GL_LINE_LOOP);		

	glVertex3dv(points[5]);

	glVertex3dv(points[4]);

	glVertex3dv(points[6]);

	glVertex3dv(points[7]);

	glEnd();



	// +X SIDE

	glBegin(GL_LINE_LOOP);		

	glVertex3dv(points[0]);

	glVertex3dv(points[1]);

	glVertex3dv(points[3]);

	glVertex3dv(points[2]);

	glEnd();



	// -Y SIDE  //

	glBegin(GL_LINE_LOOP);		

	glVertex3dv(points[7]);

	glVertex3dv(points[3]);

	glVertex3dv(points[1]);

	glVertex3dv(points[5]);

	glEnd();



	// +Y SIDE 

	glBegin(GL_LINE_LOOP);		

	glVertex3dv(points[4]);

	glVertex3dv(points[0]);

	glVertex3dv(points[2]);

	glVertex3dv(points[6]);

	glEnd();



	// +Z side

	glBegin(GL_LINE_LOOP);		

	glVertex3dv(points[5]);

	glVertex3dv(points[1]);

	glVertex3dv(points[0]);

	glVertex3dv(points[4]);

	glEnd();

}



// calculate the bounding box for the ground plane.

BoundingBox *ODECollision::calcBoundingBox(BoundingBox *box)

{

	return box;

}



int ODECollision::commandPlugIn(int argc, char **argv)

{

	int ret = DActuator::commandPlugIn(argc, argv);

	if (ret == DANCE_OK || ret == DANCE_ERROR)

		return ret;

	

	if (strcmp(argv[0], "check_collision") == 0)

	{

		this->ExertLoad(NULL, NULL, 0, 0, NULL, NULL);

		danceInterp::OutputMessage("Collisions checked.");

		return DANCE_OK;

	}

	else if (strcmp(argv[0], "self_collisions") == 0)

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"self_collisions\", <on|off>", this->getName());

			return DANCE_ERROR;

		}

		if (strcmp(argv[1], "on") == 0)

		{

			this->setSelfCollisions(true);

			danceInterp::OutputMessage("ODECollision %s will use self-collisions.", this->getName());

			if (this->odeCollisionWindow != NULL)

				odeCollisionWindow->updateGUI();

			return DANCE_OK;

		}

		else if (strcmp(argv[1], "off") == 0)

		{

			this->setSelfCollisions(false);

			danceInterp::OutputMessage("ODECollision %s will not use self-collisions.", this->getName());

			if (this->odeCollisionWindow != NULL)

				odeCollisionWindow->updateGUI();

			return DANCE_OK;

		}

		else

		{

			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"self_collisions\", <on|off>",this->getName());

			return DANCE_ERROR;

		}

	}

	else if (strcmp(argv[0], "show_collision_geometry") == 0)

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"show_collision_geometry\", <true|false>", this->getName());

			return DANCE_ERROR;

		}

		if (strcmp(argv[1], "true") == 0)

		{

			this->setShowCollisionGeometry(true);

			danceInterp::OutputMessage("NovodexCollision %s will now show collision geometry.", this->getName());

			if (this->odeCollisionWindow != NULL)

				odeCollisionWindow->updateGUI();

			return DANCE_OK;

		}

		else if (strcmp(argv[1], "false") == 0)

		{

			this->setShowCollisionGeometry(false);

			danceInterp::OutputMessage("NovodexCollision %s ill now not show collision geometry.", this->getName());

			if (this->odeCollisionWindow != NULL)

				odeCollisionWindow->updateGUI();

			return DANCE_OK;

		}

		else

		{

			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"show_collision_geometry\", <true|false>",this->getName());

			return DANCE_ERROR;

		}

	}

	else if (strcmp(argv[0], "link_collisions") == 0)

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"link_collisions\", <on|off>", this->getName());

			return DANCE_ERROR;

		}

		if (strcmp(argv[1], "on") == 0)

		{

			this->setLinkCollisions(true);

			danceInterp::OutputMessage("ODECollision %s will use link collisions.", this->getName());

			if (this->odeCollisionWindow != NULL)

				odeCollisionWindow->updateGUI();

			return DANCE_OK;

		}

		else if (strcmp(argv[1], "off") == 0)

		{

			this->setLinkCollisions(false);

			danceInterp::OutputMessage("ODECollision %s will not use link collisions.", this->getName());

			if (this->odeCollisionWindow != NULL)

				odeCollisionWindow->updateGUI();

			return DANCE_OK;

		}

		else

		{

			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"link_collisions\", <on|off>", this->getName());

			return DANCE_ERROR;

		}

	}	

	else if (strcmp(argv[0], "adjacent_link_collisions") == 0)

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"adjacent_link_collisions\", <on|off>", this->getName());

			return DANCE_ERROR;

		}

		if (strcmp(argv[1], "on") == 0)

		{

			this->setDisableAdjacentLinks(true);

			danceInterp::OutputMessage("ODECollision %s will collide adjacent links with each other.", this->getName());

			if (this->odeCollisionWindow != NULL)

				odeCollisionWindow->updateGUI();

			return DANCE_OK;

		}

		else if (strcmp(argv[1], "off") == 0)

		{

			this->setDisableAdjacentLinks(false);

			danceInterp::OutputMessage("ODECollision %s will not collide adjacent links with each other.", this->getName());

			if (this->odeCollisionWindow != NULL)

				odeCollisionWindow->updateGUI();

			return DANCE_OK;

		}

		else

		{

			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"adjacent_link_collisions\", <on|off>", this->getName());

			return DANCE_ERROR;

		}

	}

	else if (strcmp(argv[0], "contact_flags") == 0)

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"contact_flags\", <val>", this->getName());

			return DANCE_ERROR;

		}



		int flags = atoi(argv[1]);

		this->setContactFlags(flags);

		danceInterp::OutputMessage("Contact flags have been set to %d", this->getContactFlags());

		if (this->odeCollisionWindow != NULL)

			odeCollisionWindow->updateGUI();

		return DANCE_OK;

	}

	else if (strcmp(argv[0], "apply_geometry") == 0)

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"apply_geometry\", \"<geometry>\")", this->getName());

			return DANCE_ERROR;

		}

		DGeometry* geom = (DGeometry*) dance::AllGeometry->get(argv[1]);

		if (geom == NULL)

		{

			danceInterp::OutputMessage("No geometry named %s found.", argv[1]);

			return DANCE_ERROR;

		}

		this->addFixedGeometry(geom);

		danceInterp::OutputMessage("Stationary geometry %s will now be considered for collisions.", geom->getName());

		if (this->odeCollisionWindow != NULL)

			odeCollisionWindow->updateGUI();



		return DANCE_OK;

	}

	else if (strcmp(argv[0], "remove_geometry") == 0)

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"remove_geometry\", \"<geometry>\")", this->getName());

			return DANCE_ERROR;

		}

		DGeometry* geom = (DGeometry*) dance::AllGeometry->get(argv[1]);

		if (geom == NULL)

		{

			danceInterp::OutputMessage("No geometry named %s found.", geom->getName());

			return DANCE_ERROR;

		}

		this->addFixedGeometry(geom);

		danceInterp::OutputMessage("Stationary geometry %s will no longer to considered for collisions.", geom->getName());

		if (this->odeCollisionWindow != NULL)

			odeCollisionWindow->updateGUI();

		return DANCE_OK;

	}

	else if (strcmp(argv[0], "param") == 0)

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"param\", \"<mu|mu2|bounce|bounce_vel|soft_erp|soft_cfm|motion1|motion2|slip1|slip2>\", <val>)", this->getName());

			return DANCE_ERROR;

		}

		double val = atof(argv[2]);

		this->setContactParam(argv[1], val);

		return DANCE_OK;

	}



	return DANCE_CONTINUE;	

}



fltk::Widget* ODECollision::getInterface()

{

	if (this->odeCollisionWindow == NULL)

	{

		odeCollisionWindow = new ODECollisionWindow(this, 0, 0, 300, 400, this->getName());

	}



	return odeCollisionWindow;

}



void ODECollision::render(int argc, char** argv, std::ofstream& file)

{

	if (argc > 0 && strcmp(argv[0],"povray") == 0)

	{

	}

}



void ODECollision::simStartCB(DObject* object, double time)

{

	ODECollision* pg = (ODECollision*) object;

	pg->startSimulation();

}



void ODECollision::simBeforeStepCB(DObject* object, double time)

{

	ODECollision* pg = (ODECollision*) object;

	pg->beforeStep(time);

}





void ODECollision::simAfterStepCB(DObject* object, double time)

{

	ODECollision* pg = (ODECollision*) object;

	pg->afterStep(time);

}





void ODECollision::setShowCollisionPoints(bool val)

{

	showCollisionPoints = val;

}



bool ODECollision::isShowCollisionPoints()

{

	return showCollisionPoints;

}



void ODECollision::setSelfCollisions(bool val)

{

	selfCollisions = val;

}



bool ODECollision::isSelfCollisions()

{

	return selfCollisions;

}



void ODECollision::setLinkCollisions(bool val)

{

	linkCollisions = val;

}



bool ODECollision::isLinkCollisions()

{

	return linkCollisions;

}



void ODECollision::setDisableAdjacentLinks(bool val)

{

	disableAdjacentLinks = val;

}



bool ODECollision::isDisableAdjacentLinks()

{

	return disableAdjacentLinks;

}



void ODECollision::onDependencyRemoval(DObject* object)

{

	DActuator::onDependencyRemoval(object);



	DGeometry* geom = dynamic_cast<DGeometry*>(object);

	if (geom == NULL)

		return;



	if (this->isFixedGeometryPresent(geom))

	{

		for (std::vector<DGeometry*>::iterator iter = fixedGeometry.begin(); iter != fixedGeometry.end(); iter++)

		{

			if ((*iter) == geom)

			{				

				fixedGeometry.erase(iter);

				if (this->odeCollisionWindow != NULL)

					this->odeCollisionWindow->updateGUI();



				return;

			}

		}

	}

}



void ODECollision::save(int mode, std::ofstream& file)

{

	char buff[512];



	if (mode == 0)

	{

		file << "dance.instance(\"ODECollision\", \"" << this->getName() << "\")" << std::endl; 

	}

	else if (mode == 1)

	{

		// self collisions?

		if (this->isSelfCollisions())

		{

			sprintf(buff, "\"self_collisions\", \"on\"");

		}

		else

		{

			sprintf(buff, "\"self_collisions\", \"off\"");

		}

		pythonSave(file, buff);



		// link collisions?

		if (this->isLinkCollisions())

		{

			sprintf(buff, "\"link_collisions\", \"on\"");

		}

		else

		{

			sprintf(buff, "\"link_collisions\", \"off\"");

		}

		pythonSave(file, buff);



		// adjacent link collisions?

		if (this->isDisableAdjacentLinks())

		{

			sprintf(buff, "\"adjacent_link_collisions\", \"on\"");

		}

		else

		{

			sprintf(buff, "\"adjacent_link_collisions\", \"off\"");

		}

		pythonSave(file, buff);



		// show collision geometry?

		if (this->isShowCollisionGeometry())

		{

			sprintf(buff, "\"show_collision_geometry\", \"true\"");

		}

		else

		{

			sprintf(buff, "\"show_collision_geometry\", \"false\"");

		}

		pythonSave(file, buff);



		// contact flags

		sprintf(buff, "\"contact_flags\", %d", this->getContactFlags());

		pythonSave(file, buff);



		// contact parameters

		sprintf(buff, "\"param\", \"mu\", %8.4f", contactMu);

		pythonSave(file, buff);

		sprintf(buff, "\"param\", \"mu2\", %8.4f", contactMu2);

		pythonSave(file, buff);

		sprintf(buff, "\"param\", \"bounce\", %8.4f", contactBounce);

		pythonSave(file, buff);

		sprintf(buff, "\"param\", \"bounce_vel\", %8.4f", contactBounceVel);

		pythonSave(file, buff);

		sprintf(buff, "\"param\", \"soft_erp\", %g", contactSoftERP);

		pythonSave(file, buff);

		sprintf(buff, "\"param\", \"soft_cfm\", %g", contactSoftCFM);

		pythonSave(file, buff);

		sprintf(buff, "\"param\", \"motion1\", %8.4f", contactMotion1);

		pythonSave(file, buff);

		sprintf(buff, "\"param\", \"motion2\", %8.4f", contactMotion2);

		pythonSave(file, buff);

		sprintf(buff, "\"param\", \"slip1\", %8.4f", contactSlip1);

		pythonSave(file, buff);

		sprintf(buff, "\"param\", \"slip2\", %8.4f", contactSlip2);

		pythonSave(file, buff);

	}

	else if (mode == 2)

	{

		for (unsigned int x = 0; x < this->fixedGeometry.size(); x++)

		{

			sprintf(buff, "\"apply_geometry\", \"%s\"", this->fixedGeometry[x]->getName());

			pythonSave(file, buff);

		}

	}



	DActuator::save(mode, file);



}



int ODECollision::getNumFixedGeometries()

{

	return fixedGeometry.size();

}



void ODECollision::addFixedGeometry(DGeometry* geom)

{

	bool isPresent = this->isFixedGeometryPresent(geom);

	if (isPresent)

		return;



	fixedGeometry.push_back(geom);

	this->addDependency(geom);

}



DGeometry* ODECollision::getFixedGeometry(int index)

{

	if (fixedGeometry.size() > index)

		return fixedGeometry[index];

	else

		return NULL;

}



void ODECollision::removeFixedGeometry(DGeometry* geom)

{

	for (vector<DGeometry*>::iterator iter = fixedGeometry.begin(); iter != fixedGeometry.end(); iter++)

	{

		if ((*iter) == geom)

		{

			fixedGeometry.erase(iter);

			this->removeDependency(geom);

			return;

		}

	}

}



void ODECollision::removeFixedGeometry(int num)

{

	int count = 0;

	for (vector<DGeometry*>::iterator iter = fixedGeometry.begin(); iter != fixedGeometry.end(); iter++)

	{

		if (num == count)

		{

			DGeometry* geom = *iter;

			fixedGeometry.erase(iter);

			this->removeDependency(geom);

			return;

		}

		else

		{

			count++;

		}

	}

}



void ODECollision::removeAllFixedGeometries()

{

	int num = this->getNumFixedGeometries();

	for (int x = 0; x < num; x++)

	{

		this->removeFixedGeometry(0);

	}

}



bool ODECollision::isFixedGeometryPresent(DGeometry* geom)

{

	for (unsigned int x = 0; x < fixedGeometry.size(); x++)

	{

		if (fixedGeometry[x] != NULL && fixedGeometry[x] == geom)

			return true;

	}



	return false;

}



enum {SPACESIMPLE, SPACEHASH, SPACEQUADTREE};

void ODECollision::setSpaceType(int type)

{

	spaceType = type;

}



int ODECollision::getSpaceType()

{

	return spaceType;

}



bool ODECollision::checkCollision()

{

	this->clearCollisionInfo();

	this->startSimulation();



	this->updateMatrices();

	dSpaceCollide(currentSpace, this, collideCallback);



	int numCollisions = this->getNumCollisions();

	if (numCollisions > 0)

		return true;

	else

		return false;

}



dJointGroupID ODECollision::getContactGroupID()

{

	return contactGroupID;

}



void ODECollision::setContactGroupID(dJointGroupID id)

{

	contactGroupID = id;

}



void ODECollision::collideCallback(void* data, dGeomID o1, dGeomID o2)

{

	ODECollision* odeCollision = (ODECollision*) data;

  

	int numc = dCollide(o1,o2,MAX_CONTACTS,&odeCollision->contact[0].geom,sizeof(dContact));

	int collisionCount = 0;

	for (int c = 0; c < numc; c++)

	{

		ODECollisionData* data1 = odeCollision->findCollisionData(odeCollision->contact[c].geom.g1);

		ODECollisionData* data2 = odeCollision->findCollisionData(odeCollision->contact[c].geom.g2);

		dWorldID world = NULL;

		dBodyID body1 = NULL;

		dBodyID body2 = NULL;

		//ODESim* odesim2 = NULL;



		if (data1 && data1->ao != NULL)  // not fixed geometry

		{  

			ODESim* odesim1 = data1->sim;

			if (odesim1 != NULL)

			{

				world = odesim1->getODEWorldID();

				body1 = odesim1->getODEBodyID(data1->linkNum);

			}

		}

		if (data2 && data2->ao != NULL)  // not fixed geometry

		{  

			ODESim* odesim2 = data2->sim;

			if (odesim2 != NULL)

			{

				world = odesim2->getODEWorldID();

				body2 = odesim2->getODEBodyID(data2->linkNum);

			}

		}



		if ((data1 && data1->ao != NULL) && (data2 && data2->ao !=
NULL))

		{

			if (data1->ao == data2->ao)

			{

				if (!odeCollision->isSelfCollisions()) // self-collisions

					continue;

				if (data1->linkNum == data2->linkNum && !odeCollision->isLinkCollisions()) // inter-link collisions

					continue;

				if (odeCollision->isDisableAdjacentLinks() && data1->linkNum != data2->linkNum) // intra-link collisions

				{

					// are these links adjacent?

					Link* link1 = data1->ao->link[data1->linkNum];

					Link* link2 = data2->ao->link[data2->linkNum];



					if (link1->getParentLink() == link2 || link2->getParentLink() == link1)

						continue;

				}

			}

		}



		collisionCount++; 

		if (world != NULL)

		{

			if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_RUNNING)

			{

				if (odeCollision->getContactGroupID() == NULL)

				{

					dJointGroupID groupID = dJointGroupCreate(100);

					odeCollision->setContactGroupID(groupID);

				}

				// set the coefficient of restitution

				//double bounce1 = .1;

				//double bounce2 = .1;

				if (data1->ao != NULL)

				{

					double bounce1 = data1->ao->getLink(data1->linkNum)->getRestitution();

					if (data2->ao != NULL)

					{

						double bounce2 = data2->ao->getLink(data2->linkNum)->getRestitution();

						if (bounce1 > bounce2)

							odeCollision->contact[c].surface.bounce =  bounce1;

						else

							odeCollision->contact[c].surface.bounce =  bounce2;

					}

					else

					{

						odeCollision->contact[c].surface.bounce =  bounce1;

					}

				}

				else if (data2->ao != NULL)

				{

						double bounce2 = data2->ao->getLink(data2->linkNum)->getRestitution();

						odeCollision->contact[c].surface.bounce =  bounce2;

				}

				dJointID contactJoint = dJointCreateContact(world, odeCollision->getContactGroupID(), &odeCollision->contact[c]);				

				dJointAttach(contactJoint, body1, body2);

				if (data1 && (data1->ao != NULL) )

				{

					DCollision** col = data1->ao->getPointCollisionData();

					if( col && data1->ao->getNumPointCollisionData() > 0)

					{

						if( col[data1->linkNum] )

						{

						col[data1->linkNum]->setAllPointsCollision(true);

					}

						else

						{

							danceInterp::OutputMessage( "Error: ODECollision.  Collision points not defined for link %d.", data1->linkNum );

				}

					}

				}

				if( data2 && data2->ao )

				{

					DCollision** col = data2->ao->getPointCollisionData();

					if( col && data2->ao->getNumPointCollisionData() > 0)

					{

						col[data2->linkNum]->setAllPointsCollision(true);

					}

					else

					{

						danceInterp::OutputMessage( "Error: ODECollision.  Collision points not defined for link %d.", data2->linkNum );

					}

				}



			}

		}

	}

	odeCollision->setNumCollisions(collisionCount);



}



void ODECollision::updateMatrices()

{

	// update the transformation matrices

	double matrix[4][4];



	for (vector<ODECollisionData*>::iterator iter = collisions.begin(); iter != collisions.end(); iter++)

	{

		ODECollisionData* data = *iter;

		if (!data)
		{
			danceInterp::OutputMessage("Collision data is empty, please check collision data construction...");
			continue;
		}



		if (data->ao != NULL && data->sphereNum >= 0) // articulated object collision sphere

		{

			// get the link matrix

			Link* link = data->ao->getLink(data->linkNum);

			link->getWTransMat(matrix);

			// calculate the  sphere offset

			Vector sphereLoc;

			VecCopy(sphereLoc, data->sphereOffset);

			transformPoint_mat(sphereLoc, matrix);

			setVector(matrix[3], sphereLoc[0], sphereLoc[1], sphereLoc[2]);

			updateCollisionObjectMatrix(data->geomID, matrix);

		}

		else

		{

			int geomType = dGeomGetClass(data->geomID);

			data->geom->getTransMatrix(matrix);



			if (geomType == dSphereClass)

			{

				// remove the sphere radius from the rotation

				double radius = dGeomSphereGetRadius(data->geomID);



				for (int c = 0; c < 3; c++)

				{

					matrix[c][0] /= radius;

					matrix[c][1] /= radius;

					matrix[c][2] /= radius;

				}

			}

			else if (geomType == dCCylinderClass)

			{

				// capsules do not use scaling. Rather, they have length and radius parameters.

			}

			else if (geomType == dBoxClass)

			{

				Vector scaling;

				data->geom->getScaling(scaling);

				for (int c = 0; c < 3; c++)

				{

					matrix[c][0] /= scaling[c];

					matrix[c][1] /= scaling[c];

					matrix[c][2] /= scaling[c];

				}

			}		

			else if (geomType == dTriMeshClass)

			{

				// point locations are already factored in

				// to the trimesh vertex locations

				setIdentMat(&matrix[0][0], 4);

			}		



			// add in composite matrix if present

			if (data->hasCompositeMatrix)

			{

				double temp[4][4];

				multArray4x4(temp, matrix, data->compositeMat);

				copyMatrix44(matrix, temp);

			}



			if (data->linkNum > -1)

			{ // geometry attached to AO need to be: 1) placed in link local coordinates, 2) positioned via link's world matrix

				Link* link = data->ao->getLink(data->linkNum);

				double linkMatrix[4][4];

				link->getWTransMatGeom(linkMatrix);

				double temp[4][4]; 

				//multArray(&temp[0][0], &matrix[0][0], &data->invMat[0][0], 4, 4, 4);

				multArray4x4(temp, matrix, data->invMat);

				//multArray(&matrix[0][0], &temp[0][0], &linkMatrix[0][0], 4, 4, 4);

				multArray4x4(matrix, temp, linkMatrix);

				

			}



			// set the position

			dGeomSetPosition((*iter)->geomID, matrix[3][0], matrix[3][1], matrix[3][2]);



			// set the rotation

			dMatrix3 dm;

			dRSetIdentity(dm);

			for (int r = 0; r < 3; r++)

				for (int c = 0; c < 3; c++)

					dm[r * 4 + c] = matrix[c][r];



			dGeomSetRotation((*iter)->geomID, dm);



		}

	}

}



void ODECollision::updateCollisionObjectMatrix(dGeomID geomID, double matrix[4][4])

{

	// set the position

	dGeomSetPosition(geomID, matrix[3][0], matrix[3][1], matrix[3][2]);



	// set the rotation

	dMatrix3 dm;

	for (int r = 0; r < 3; r++)

		for (int c = 0; c < 3; c++)

			dm[r * 4 + c] = matrix[c][r];

	dGeomSetRotation(geomID, dm);

}



void ODECollision::setShowCollisionGeometry(bool val)

{

	showCollisionGeometry = val;

}



bool ODECollision::isShowCollisionGeometry()

{

	return showCollisionGeometry;

}



void ODECollision::setNumCollisions(int num)

{

	numCollisions = num;

}



int ODECollision::getNumCollisions()

{

	return numCollisions;

}





void ODECollision::clearCollisionInfo()

{

	// remove all geometries

	if (currentSpace != NULL)

	{

		dSpaceDestroy(currentSpace);

		currentSpace = NULL;

	}



	if (this->getContactGroupID() != NULL)

	{

		dJointGroupEmpty(this->getContactGroupID());

	}





	this->setNumCollisions(0);



	for (unsigned int x = 0; x < collisions.size(); x++)

	{

		delete collisions[x];

	}

	collisions.clear();



	if (this->getContactGroupID() != NULL)

	{

		dJointGroupEmpty(this->getContactGroupID());

	}

}



ODECollisionData* ODECollision::findCollisionData(dGeomID id)

{

	// for now, perform a linear search. A hash table would be better...

	for (unsigned int x = 0; x < collisions.size(); x++)

	{

		if (collisions[x]->geomID == id)

			return collisions[x];

	}

	return NULL;

}



void ODECollision::setContactFlags(int flag)

{

	contactFlags = flag;



	// set the variables based on the flag value

	if (contactFlags & dContactMu2)

		this->flagMu2 = true;

	else

		this->flagMu2 = false;

	if (contactFlags & dContactFDir1)

		this->flagFDir1 = true;

	else

		this->flagFDir1 = false;

	if (contactFlags & dContactBounce)

		this->flagBounce = true;

	else

		this->flagBounce = false;

	if (contactFlags & dContactSoftERP)

		this->flagSoftERP = true;

	else

		this->flagSoftERP = false;

	if (contactFlags & dContactSoftCFM)

		this->flagSoftCFM = true;

	else

		this->flagSoftCFM = false;

	if (contactFlags & dContactMotion1)

		this->flagMotion1 = true;

	else

		this->flagMotion1 = false;

	if (contactFlags & dContactMotion2)

		this->flagMotion2 = true;

	else

		this->flagMotion2 = false;

	if (contactFlags & dContactSlip1)

		this->flagSlip1 = true;

	else

		this->flagSlip1 = false;

	if (contactFlags & dContactSlip2)

		this->flagSlip2 = true;

	else

		this->flagSlip2 = false;

	if (contactFlags & dContactApprox1_1)

		this->flagApprox1_1 = true;

	else

		this->flagApprox1_1 = false;

	if (contactFlags & dContactApprox1_2)

		this->flagApprox1_2 = true;

	else

		this->flagApprox1_2 = false;

	if (contactFlags & dContactApprox1)

		this->flagApprox1 = true;

	else

		this->flagApprox1 = false;

}



int ODECollision::getContactFlags()

{

	return contactFlags;

}



void ODECollision::setContactFlags(const char* flagName, bool val)

{

	if (strcmp(flagName, "dContactMu2") == 0)

		this->flagMu2 = val;

	else if (strcmp(flagName, "dContactFDir1") == 0)

		this->flagFDir1 = val;

	else if (strcmp(flagName, "dContactBounce") == 0)

		this->flagBounce = val;

	else if (strcmp(flagName, "dContactSoftERP") == 0)

		this->flagSoftERP = val;

	else if (strcmp(flagName, "dContactSoftCFM") == 0)

		this->flagSoftCFM = val;

	else if (strcmp(flagName, "dContactMotion1") == 0)

		this->flagMotion1 = val;

	else if (strcmp(flagName, "dContactMotion2") == 0)

		this->flagMotion2 = val;

	else if (strcmp(flagName, "dContactSlip1") == 0)

		this->flagSlip1 = val;

	else if (strcmp(flagName, "dContactSlip2") == 0)

		this->flagSlip2 = val;

	else if (strcmp(flagName, "dContactApprox1_1") == 0)

		this->flagApprox1_1 = val;

	else if (strcmp(flagName, "dContactApprox1_2") == 0)

		this->flagApprox1_2 = val;

	else if (strcmp(flagName, "dContactApprox1") == 0)

		this->flagApprox1 = val;

	else

		danceInterp::OutputMessage("Flag '%s' not understood.", flagName);



	contactFlags = 0;

	if (this->flagMu2)

		contactFlags = contactFlags | dContactMu2;

	if (this->flagFDir1)

		contactFlags = contactFlags | dContactFDir1;

	if (this->flagBounce)

		contactFlags = contactFlags | dContactBounce;

	if (this->flagSoftERP)

		contactFlags = contactFlags | dContactSoftERP;

	if (this->flagSoftCFM)

		contactFlags = contactFlags | dContactSoftCFM;

	if (this->flagMotion1)

		contactFlags = contactFlags | dContactMotion1;

	if (this->flagMotion2)

		contactFlags = contactFlags | dContactMotion2;

	if (this->flagSlip1)

		contactFlags = contactFlags | dContactSlip1;

	if (this->flagSlip2)

		contactFlags = contactFlags | dContactSlip2;

	if (this->flagApprox1_1)

		contactFlags = contactFlags | dContactApprox1_1;

	if (this->flagApprox1_2)

		contactFlags = contactFlags | dContactApprox1_2;

	if (this->flagApprox1)

		contactFlags = contactFlags | dContactApprox1;

}



bool ODECollision::getContactFlags(const char* flagName)

{

	if (strcmp(flagName, "dContactMu2") == 0)

	{

		return this->flagMu2;

	}

	else if (strcmp(flagName, "dContactFDir1") == 0)

	{

		return this->flagFDir1;

	}

	else if (strcmp(flagName, "dContactBounce") == 0)

	{

		return this->flagBounce;

	}

	else if (strcmp(flagName, "dContactSoftERP") == 0)

	{

		return this->flagSoftERP;

	}

	else if (strcmp(flagName, "dContactSoftCFM") == 0)

	{

		return this->flagSoftCFM;

	}

	else if (strcmp(flagName, "dContactMotion1") == 0)

	{

		return this->flagMotion1;

	}

	else if (strcmp(flagName, "dContactMotion2") == 0)

	{

		return this->flagMotion2;

	}

	else if (strcmp(flagName, "dContactSlip1") == 0)

	{

		return this->flagSlip1;

	}

	else if (strcmp(flagName, "dContactSlip2") == 0)

	{

		return this->flagSlip2;

	}

	else if (strcmp(flagName, "dContactApprox1_1") == 0)

	{

		return this->flagApprox1_1;

	}

	else if (strcmp(flagName, "dContactApprox1_2") == 0)

	{

		return this->flagApprox1_2;

	}

	else if (strcmp(flagName, "dContactApprox1") == 0)

	{

		return this->flagApprox1;

	}

	else

	{

		danceInterp::OutputMessage("Flag '%s' not understood.", flagName);

		return false;

	}

}



void ODECollision::setContactParam(const char* paramName, double val)

{

	if (strcmp(paramName, "mu") == 0)

	{

		this->contactMu = val;

	}

	else if (strcmp(paramName, "mu2") == 0)

	{

		this->contactMu2 = val;

	}

	else if (strcmp(paramName, "bounce") == 0)

	{

		this->contactBounce = val;

	}

	else if (strcmp(paramName, "bounce_vel") == 0)

	{

		this->contactBounceVel = val;

	}

	else if (strcmp(paramName, "soft_erp") == 0)

	{

		this->contactSoftERP = val;

	}

	else if (strcmp(paramName, "soft_cfm") == 0)

	{

		this->contactSoftCFM = val;

	}

	else if (strcmp(paramName, "motion1") == 0)

	{

		this->contactMotion1 = val;

	}

	else if (strcmp(paramName, "motion2") == 0)

	{

		this->contactMotion2 = val;

	}

	else if (strcmp(paramName, "slip1") == 0)

	{

		this->contactSlip1 = val;

	}

	else if (strcmp(paramName, "slip2") == 0)

	{

		this->contactSlip2 = val;

	}

	else

	{

		danceInterp::OutputMessage("Parameter '%s' with value '%6.2f' not understood. Parameter was not set.", paramName, val);

	}

}



double ODECollision::getContactParam(const char* paramName)

{

	if (strcmp(paramName, "mu") == 0)

	{

		return this->contactMu;

	}

	else if (strcmp(paramName, "mu2") == 0)

	{

		return this->contactMu2;

	}

	else if (strcmp(paramName, "bounce") == 0)

	{

		return this->contactBounce;

	}

	else if (strcmp(paramName, "bounce_vel") == 0)

	{

		return this->contactBounceVel;

	}

	else if (strcmp(paramName, "soft_erp") == 0)

	{

		return this->contactSoftERP;

	}

	else if (strcmp(paramName, "soft_cfm") == 0)

	{

		return this->contactSoftCFM;

	}

	else if (strcmp(paramName, "motion1") == 0)

	{

		return this->contactMotion1;

	}

	else if (strcmp(paramName, "motion2") == 0)

	{

		return this->contactMotion2;

	}

	else if (strcmp(paramName, "slip1") == 0)

	{

		return this->contactSlip1;

	}

	else if (strcmp(paramName, "slip2") == 0)

	{

		return this->contactSlip2;

	}

	else

	{

		danceInterp::OutputMessage("Parameter '%s' not understood.", paramName);

		return 0.0;

	}

}





void ODECollision::resetAllContactFlags()

{

	this->flagMu2 = false;

	this->flagFDir1 = false;

	this->flagBounce = false;

	this->flagSoftERP = false;

	this->flagSoftCFM = false;

	this->flagMotion1 = false;

	this->flagMotion2 = false;

	this->flagSlip1 = false;

	this->flagSlip2 = false;

	this->flagApprox1_1 = false;

	this->flagApprox1_2 = false;

	this->flagApprox1 = false;

}



int ODECollision::getNumPluginDependents()

{

	return 6;

}



const char* ODECollision::getPluginDependent(int num)

{

	if (num == 0) return "ODESim";

	else if (num == 1) return "ArticulatedObject";

	else if (num == 2) return "Plane";

	else if (num == 3) return "Cube";

	else if (num == 4) return "Sphere";

	else if (num == 5) return "Capsule";

	else return "";

}



ODECollisionData::ODECollisionData()

{

	ao = NULL;

	sim = NULL;

	linkNum = -1;

	sphereNum = -1;

	zeroVector(sphereOffset);

	geom = NULL;

	geomID = NULL;

	bodyID = NULL;

	setIdentMat(&invMat[0][0], 4);

	isPlane = false;

	setIdentMat(&compositeMat[0][0], 4);

	hasCompositeMatrix = false;

	meshData = NULL;

}



ODECollisionData::~ODECollisionData()

{

	if (meshData)

		delete meshData;

}













