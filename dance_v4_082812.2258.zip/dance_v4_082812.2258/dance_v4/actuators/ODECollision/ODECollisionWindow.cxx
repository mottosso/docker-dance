/**************************************************

Copyright 2005 by Ari Shapiro and Petros Faloutsos



DANCE

Dynamic ANimation and Control Environment



 ***************************************************************

 ******General License Agreement and Lack of Warranty ***********

 ****************************************************************



This software is distributed for noncommercial use in the hope that it will 

be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility

to anyone for the consequences	of using it or for whether it serves any 

particular purpose or works at all. No warranty is made about the software 

or its performance. Commercial use is prohibited. 



Any plugin code written for DANCE belongs to the developer of that plugin,

who is free to license that code in any manner desired.



Content and code development by third parties (such as FLTK, Python, 

ImageMagick, ODE) may be governed by different licenses.

You may modify and distribute this software as long as you give credit 

to the original authors by including the following text in every file 

that is distributed: */



/*********************************************************

	Copyright 2005 by Ari Shapiro and Petros Faloutsos



	DANCE

	Dynamic ANimation and Control Environment

	-----------------------------------------

	AUTHOR:

		Ari Shapiro (ashapiro@cs.ucla.edu)

	ORIGINAL AUTHORS: 

		Victor Ng (victorng@dgp.toronto.edu)

		Petros Faloutsos (pfal@cs.ucla.edu)

	CONTRIBUTORS:

		Yong Cao (abingcao@cs.ucla.edu)

		Paco Abad (fjabad@dsic.upv.es)

**********************************************************/



#include "ODECollisionWindow.h"



#include <fltk/Button.h>

#include <cstdlib>

#include "ODECollision.h"

#include "dance.h"

#include "ViewManager.h"

#include <fltk/FileChooser.h>

#include "ArticulatedObject.h"

#include "Link.h"

#include "DGeometry.h"

#include <fltk/ask.h>



using namespace fltk;



ODECollisionWindow::ODECollisionWindow(ODECollision* collision, int x, int y, int width, int height, const char* name) : Group(x, y, width, height, name)

{

	const char* flagNames[12] = {"dContactMu2", "dContactFDir1", "dContactBounce", "dContactSoftERP", "dContactSoftCFM", "dContactMotion1", "dContactMotion2", "dContactSlip1", "dContactSlip2", "dContactApprox1_1", "dContactApprox1_2", "dContactApprox1"};



	const char* names[10] = {"mu", "mu2", "bounce", "bounce_vel", "soft_erp", "soft_cfm", "motion1", "motion2", "slip1", "slip2"};



	this->begin();



	odeCollision = collision;



	checkShowCollisionPoints = new CheckButton(10, 10, 80, 20, "Show collision points");

	checkShowCollisionPoints->callback(ShowCollisionPointsCB, this);



	checkShowCollisionGeometry = new CheckButton(10, 35, 80, 20, "Show collision geometry");

	checkShowCollisionGeometry->callback(ShowCollisionGeometryCB, this);



	checkSelfCollisions = new CheckButton(10, 60, 80, 20, "Self collisions");

	checkSelfCollisions->callback(SelfCollisionsCB, this);



	checkLinkCollisions = new CheckButton(10, 85, 80, 20, "Link collisions");

	checkLinkCollisions->callback(LinkCollisionsCB, this);



	checkDisableAdjacentLinkCollisions = new CheckButton(10, 110, 80, 20, "Disable adjacent link collisions");

	checkDisableAdjacentLinkCollisions->callback(DisableAdjacentLinkCollisionsCB, this);



	buttonCheckCollisions = new Button(10, 135, 80, 20, "Check Collisions");

	buttonCheckCollisions->callback(this->CheckCollisionsCB, this);



	groupApplied = new GroupAppliedSystems(this->odeCollision, 10, 160, 150, 200, "Systems Affected");



	browserGeometry = new Browser(10, 390, 150, 150, "Geometry Affected");



	buttonUpdate = new Button(10, 560, 60, 20, "Update");

	buttonUpdate->callback(this->UpdateCB, this);



	double curX = 200;

	double curY = 10;





	for (int x = 0; x < 12; x++)

	{

		this->checkContactFlags[x] = new CheckButton(curX, curY, 60, 20, flagNames[x]);

		checkContactFlags[x]->callback(this->UpdateFlagsCB, this);

		curY += 25;

	}



	curX = 240;

	for (int x = 0; x < 10; x++)

	{

		inputContactParam[x] = new FloatInput(curX, curY, 60, 20, names[x]);

		inputContactParam[x]->callback(UpdateParamsCB, this);

		curY += 25;

	}



	this->end();



	this->updateGUI();

}



void ODECollisionWindow::show()

{

	this->updateGUI();

	Group::show();

}



void ODECollisionWindow::updateGUI()

{

	groupApplied->activate();

	groupApplied->updateGUI();



	checkSelfCollisions->value(this->odeCollision->isSelfCollisions());

	checkLinkCollisions->value(this->odeCollision->isLinkCollisions());

	this->checkDisableAdjacentLinkCollisions->value(this->odeCollision->isDisableAdjacentLinks());

	if (this->odeCollision->isSelfCollisions())

		this->checkDisableAdjacentLinkCollisions->activate();

	else

		this->checkDisableAdjacentLinkCollisions->deactivate();



	// update the fixed geometry list

	this->browserGeometry->clear();

	for (int x = 0; x < dance::AllGeometry->size(); x++)

	{

		DGeometry* geometry = (DGeometry*) dance::AllGeometry->get(x);

		// make sure that this geometry isn't part of an existing articulated object

		bool found = false;

		for (int a = 0; a < dance::AllSystems->size(); a++)

		{

			ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get(a));

			if (ao != NULL)

			{

				for (int l = 0; l < ao->getNumLinks(); l++)

				{

					Link* link = ao->getLink(l);

					if (link->getGeometry() == geometry || link->getGeometryCollision() == geometry || link->getGeometryProp() == geometry)

					{

						found = true;

						break;

					}

				}

			}

			if (found)

				break;

		}

		if (!found)

		{

			// make sure that geometry isn't part of a composite geometry

			for (int c = 0; c < dance::AllGeometry->size(); c++)

			{

				CompositeGeometry* cgeometry = dynamic_cast<CompositeGeometry*>(dance::AllGeometry->get(c));

				if (cgeometry != NULL)

				{

					for (int a = 0; a < cgeometry->getNumGeometries(); a++)

					{

						if (cgeometry->getGeometry(a) == geometry)

						{

							found = true;

							break;

						}

					}

				}

				if (found)

					break;

			}

			if (!found)

			{

				CheckButton* check = new CheckButton(0, 0, this->browserGeometry->w() - 20, 20, geometry->getName());

				check->callback(FixedGeometryCollisionCB, this);

				bool isChecked  = false;

				for (int f = 0; f < this->odeCollision->getNumFixedGeometries(); f++)

				{

					if (this->odeCollision->getFixedGeometry(f) == geometry)

					{

						isChecked = true;

					}

				}  

				check->value(isChecked);

				this->browserGeometry->add(check);

			}

		}

	}



	this->checkShowCollisionGeometry->value(this->odeCollision->isShowCollisionGeometry());



	// update the flags

	for (int x = 0; x < 12; x++)

		this->checkContactFlags[x]->value(this->odeCollision->getContactFlags((char*) this->checkContactFlags[x]->label()));



	if (this->odeCollision->getContactFlags("dContactMu2") == false)

		this->inputContactParam[1]->deactivate();

	else

		this->inputContactParam[1]->activate();



	if (this->odeCollision->getContactFlags("dContactBounce") == false)

	{

		this->inputContactParam[2]->deactivate();

		this->inputContactParam[3]->deactivate();

	}

	else

	{

		this->inputContactParam[2]->activate();

		this->inputContactParam[3]->activate();

	}



	if (this->odeCollision->getContactFlags("dContactSoftERP") == false)

		this->inputContactParam[4]->deactivate();

	else

		this->inputContactParam[4]->activate();



	if (this->odeCollision->getContactFlags("dContactSoftCFM") == false)

		this->inputContactParam[5]->deactivate();

	else

		this->inputContactParam[5]->activate();



	if (this->odeCollision->getContactFlags("dContactMotion1") == false)

		this->inputContactParam[6]->deactivate();

	else

		this->inputContactParam[6]->activate();



	if (this->odeCollision->getContactFlags("dContactMotion2") == false)

		this->inputContactParam[7]->deactivate();

	else

		this->inputContactParam[7]->activate();



	if (this->odeCollision->getContactFlags("dContactSlip1") == false)

		this->inputContactParam[8]->deactivate();

	else

		this->inputContactParam[8]->activate();



	if (this->odeCollision->getContactFlags("dContactSlip2") == false)

		this->inputContactParam[9]->deactivate();

	else

		this->inputContactParam[9]->activate();



	// update the contact parameters

	for (int x = 0; x < 10; x++)

		this->inputContactParam[x]->value(this->odeCollision->getContactParam((char*) this->inputContactParam[x]->label()));

}







void ODECollisionWindow::ShowCollisionPointsCB(Widget *w, void *data)

{

	ODECollisionWindow* win = (ODECollisionWindow*) data;



	win->odeCollision->setShowCollisionPoints(win->checkShowCollisionPoints->value());



	win->updateGUI();

}



void ODECollisionWindow::SelfCollisionsCB(Widget *w, void *data)

{

	ODECollisionWindow* win = (ODECollisionWindow*) data;



	win->odeCollision->setSelfCollisions(win->checkSelfCollisions->value());



	win->updateGUI();

}



void ODECollisionWindow::LinkCollisionsCB(Widget *w, void *data)

{

	ODECollisionWindow* win = (ODECollisionWindow*) data;



	win->odeCollision->setLinkCollisions(win->checkLinkCollisions->value());



	win->updateGUI();

}





void ODECollisionWindow::DisableAdjacentLinkCollisionsCB(fltk::Widget *w, void *data)

{

	ODECollisionWindow* win = (ODECollisionWindow*) data;



	win->odeCollision->setDisableAdjacentLinks(win->checkDisableAdjacentLinkCollisions->value());



	win->updateGUI();

}





void ODECollisionWindow::FixedGeometryCollisionCB(Widget *w, void *data)

{	

	ODECollisionWindow* win = (ODECollisionWindow*) data;



	CheckButton* check = (CheckButton*) w;



	if (check->value())

	{

		DGeometry* geom = (DGeometry*) dance::AllGeometry->get((char*) check->label());

		if (geom != NULL)

		{

			win->odeCollision->addFixedGeometry(geom);

		}

	}

	else

	{

		DGeometry* geom = (DGeometry*) dance::AllGeometry->get((char*) check->label());

		if (geom != NULL)

		{

			win->odeCollision->removeFixedGeometry(geom);

		}

	}

}



void ODECollisionWindow::UpdateCB(Widget *w, void *data)

{

	ODECollisionWindow* win = (ODECollisionWindow*) data;



	win->updateGUI();

}



void ODECollisionWindow::ShowCollisionGeometryCB(Widget *w, void *data)

{

	ODECollisionWindow* win = (ODECollisionWindow*) data;



	win->odeCollision->setShowCollisionGeometry(win->checkShowCollisionGeometry->value());



	win->updateGUI();

	dance::Refresh();

}



void ODECollisionWindow::CheckCollisionsCB(Widget *w, void *data)

{

	ODECollisionWindow* win = (ODECollisionWindow*) data;



	bool ret = win->odeCollision->checkCollision();



	win->updateGUI();

	dance::Refresh();



	if (ret)

		fltk::alert("Collisions!");

	else

		fltk::alert("No collisions!");

}



void ODECollisionWindow::UpdateParamsCB(fltk::Widget *w, void *data)

{

	ODECollisionWindow* win = (ODECollisionWindow*) data;



	for (int x = 0; x < 10; x++)

	{

		win->odeCollision->setContactParam((char*) win->inputContactParam[x]->label(), win->inputContactParam[x]->fvalue());

	}



	win->updateGUI();

}



void ODECollisionWindow::UpdateFlagsCB(fltk::Widget *w, void *data)

{

	ODECollisionWindow* win = (ODECollisionWindow*) data;



	for (int x = 0; x < 12; x++)

	{

		win->odeCollision->setContactFlags((char*) win->checkContactFlags[x]->label(), win->checkContactFlags[x]->value());

	}



	win->updateGUI();

}





