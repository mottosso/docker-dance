/**************************************************

Copyright 2005 by Ari Shapiro and Petros Faloutsos



DANCE

Dynamic ANimation and Control Environment



 ***************************************************************

 ******General License Agreement and Lack of Warranty ***********

 ****************************************************************



This software is distributed for noncommercial use in the hope that it will 

be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility

to anyone for the consequences	of using it or for whether it serves any 

particular purpose or works at all. No warranty is made about the software 

or its performance. Commercial use is prohibited. 



Any plugin code written for DANCE belongs to the developer of that plugin,

who is free to license that code in any manner desired.



Content and code development by third parties (such as FLTK, Python, 

ImageMagick, ODE) may be governed by different licenses.

You may modify and distribute this software as long as you give credit 

to the original authors by including the following text in every file 

that is distributed: */



/*********************************************************

	Copyright 2005 by Ari Shapiro and Petros Faloutsos



	DANCE

	Dynamic ANimation and Control Environment

	-----------------------------------------

	AUTHOR:

		Ari Shapiro (ashapiro@cs.ucla.edu)

	ORIGINAL AUTHORS: 

		Victor Ng (victorng@dgp.toronto.edu)

		Petros Faloutsos (pfal@cs.ucla.edu)

	CONTRIBUTORS:

		Yong Cao (abingcao@cs.ucla.edu)

		Paco Abad (fjabad@dsic.upv.es)

**********************************************************/



#ifndef	_ODECOLLISION_H

#define	_ODECOLLISION_H

#ifndef dDOUBLE
#define dDOUBLE
#endif

#include <ode/ode.h>

#include "DActuator.h"

#include "DSystem.h"

#include "ArticulatedObject.h"

#include "DObjectRefList.h"

#include "DGeometry.h"

#include <fltk/Widget.h>

#include <vector>

#include "Plane.h"

#include "Model.h"

#include "Cube.h"

#include "Sphere.h"

#include "Capsule.h"

#include "ODESim.h"

#include "CompositeGeometry.h"



class ODECollisionWindow;



#define MAXDISABLEDLINKS 10



class MeshData

{

	public:

		double* vertices;

		int numVertices;

		int* triangles;

		int numTriangles;

};



class ODECollisionData

{

	public:

		ODECollisionData();

		~ODECollisionData();

		

		ArticulatedObject* ao;     // associated AO

		ODESim* sim;

		int linkNum;

		int sphereNum;

		double sphereRadius;

		Vector sphereOffset;



		DGeometry* geom;           

		bool isPlane;

		Vector planeLengths;



		dGeomID geomID;

		dBodyID bodyID;

		MeshData* meshData;



		double invMat[4][4];

		double compositeMat[4][4];

		bool hasCompositeMatrix;

};



#define PLANE_WIDTH .01

#define MAX_CONTACTS 10000



class ODECollision : public DActuator

{

	public:

		PlugIn* create(int argc, char **argv) ;

		

		ODECollision()	;

		~ODECollision() ;



		void ExertLoad(DSystem *mainsys, DSimulator* simulator, double time, double dt,	double *state, double *dstate) ;



		void output(int mode)	;

		void render(int argc, char** argv, std::ofstream& file);



		BoundingBox *calcBoundingBox(BoundingBox *box);



		int commandPlugIn(int argc, char	**argv)	;



		fltk::Widget* getInterface();



		void startSimulation();

		void step(double time);

		void beforeStep(double time);

		void afterStep(double time);



		void setShowCollisionPoints(bool val);

		bool isShowCollisionPoints();



		void setSelfCollisions(bool val);

		bool isSelfCollisions();

		void setLinkCollisions(bool val);

		bool isLinkCollisions();

		void setDisableAdjacentLinks(bool val);

		bool isDisableAdjacentLinks();



		int getNumFixedGeometries();

		void addFixedGeometry(DGeometry* geom);

		DGeometry* getFixedGeometry(int index);

		void removeFixedGeometry(DGeometry* geom);

		void removeFixedGeometry(int index);

		void removeAllFixedGeometries();

		bool isFixedGeometryPresent(DGeometry* geom);



		void onDependencyRemoval(DObject* object);

		int getNumPluginDependents();

		const char* getPluginDependent(int num);



		void save(int mode, std::ofstream& file);



		enum {SPACESIMPLE, SPACEHASH, SPACEQUADTREE};

		void setSpaceType(int type);

		int getSpaceType();



		bool checkCollision();

		void setShowCollisionGeometry(bool val);

		bool isShowCollisionGeometry();



		void updateMatrices();

		static void collideCallback(void* data, dGeomID o1, dGeomID o2);



		void setNumCollisions(int num);

		int getNumCollisions();

		

		dContact contact[MAX_CONTACTS];

		dJointGroupID getContactGroupID();

		void setContactGroupID(dJointGroupID id);



		void setContactFlags(int flag);

		int getContactFlags();

		void setContactFlags(const char* paramName, bool val);

		bool getContactFlags(const char* paramName);

		void setContactParam(const char* paramName, double val);

		double getContactParam(const char* paramName);



	private:

		static void simStartCB(DObject* object, double time);

		static void simBeforeStepCB(DObject* object, double time);

		static void simAfterStepCB(DObject* object, double time);

		void drawBox(Vector points[8]);

		void updateCollisionObjectMatrix(dGeomID geomID, double matrix[4][4]);

		void resetAllContactFlags();



		ODECollisionData* createCollisionData(ArticulatedObject* ao, int linkNum, int sphereNum, double radius, Vector offset);

		ODECollisionData* createCollisionData(ArticulatedObject* ao, int linkNum, DGeometry* geom, double invMat[4][4]);



		ODECollisionData* findCollisionData(dGeomID id);

		void clearCollisionInfo();

		ODECollisionData* createCube(ArticulatedObject* ao, int linkNum, Cube* cube, double invMat[4][4]);

		ODECollisionData* createModel(ArticulatedObject* ao, int linkNum, Model* model, double invMat[4][4]);

		ODECollisionData* createPlane(ArticulatedObject* ao, int linkNum, Plane* plane, double invMat[4][4]);

		ODECollisionData* createSphere(ArticulatedObject* ao, int linkNum, Sphere* sphere, double invMat[4][4]);

		ODECollisionData* createCapsule(ArticulatedObject* ao, int linkNum, Capsule* capsule, double invMat[4][4]);

		void createComposite(ArticulatedObject* ao, int linkNum, CompositeGeometry* composite, double invMat[4][4]);



		ODECollisionWindow* odeCollisionWindow;



		Vector curCollisions[100];

		int numCol;

		std::vector<ODECollisionData*> collisions;

		bool showCollisionPoints;

		bool selfCollisions;

		bool linkCollisions;

		bool disableAdjacentLinks;

		dSpaceID currentSpace;

		int spaceType;

		bool showCollisionGeometry;

		int numCollisions;

		std::vector<DGeometry*> fixedGeometry;

		dJointGroupID contactGroupID;

		bool forcesApplied;



		double contactMu;

		double contactMu2;

		double contactBounce;

		double contactBounceVel;

		double contactSoftERP;

		double contactSoftCFM;

		double contactMotion1;

		double contactMotion2;

		double contactSlip1;

		double contactSlip2;

		bool flagMu2;

		bool flagFDir1;

		bool flagBounce;

		bool flagSoftERP;

		bool flagSoftCFM;

		bool flagMotion1;

		bool flagMotion2;

		bool flagSlip1;

		bool flagSlip2;

		bool flagApprox1_1;

		bool flagApprox1_2;

		bool flagApprox1;

		int contactFlags;

};







#endif











