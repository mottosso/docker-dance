#ifndef CMForceTorqueWINDOW
#define CMForceTorqueWINDOW

#include <fltk/Group.h>
#include <fltk/FloatInput.h>
#include <fltk/CheckButton.h>
#include <fltk/ThumbWheel.h>

class CMForceTorque;

class CMForceTorqueWindow : public fltk::Group
{
public:
	CMForceTorqueWindow(CMForceTorque* f, int x, int y, int width, int height, const char* name);
	void updateGUI();

	static void StartTimeChangeCB(fltk::Widget *w, void *data);
	static void DurationChangeCB(fltk::Widget *w, void *data);
	static void AccelerationChangeCB(fltk::Widget *w, void *data);
	static void AccelerationChangeRollerCB(fltk::Widget *w, void *data);

/*
	static void PositionChangeCB(fltk::Widget *w, void *data);
	static void PositionChangeRollerCB(fltk::Widget *w, void *data);
	static void DirectionChangeCB(fltk::Widget *w, void *data);
	static void DirectionChangeRollerCB(fltk::Widget *w, void *data);
	static void MagnitudeChangeCB(fltk::Widget *w, void *data);
	static void MagnitudeChangeRollerCB(fltk::Widget *w, void *data);
	static void SizeChangeCB(fltk::Widget *w, void *data);
	static void SizeChangeRollerCB(fltk::Widget *w, void *data);
	static void ShowChangeCB(fltk::Widget *w, void *data);
	static void ApplyAllCB(fltk::Widget *w, void *data);
	*/

	CMForceTorque* m_CMForceTorque;

	fltk::FloatInput* inputAcceleration[3];
	fltk::ThumbWheel* rollerAcceleration[3];

	fltk::FloatInput* inputStartTime;
	fltk::FloatInput* inputDuration;

/*
	fltk::FloatInput* inputPosition[3];
	fltk::ThumbWheel* rollerPosition[3];

	fltk::FloatInput* inputImpulse[3];
	fltk::ThumbWheel* rollerImpulse[3];

	fltk::FloatInput* inputImpulseTime;

	fltk::FloatInput* inputDirection[3];
	fltk::ThumbWheel* rollerDirection[3];

	fltk::FloatInput* inputMagnitude;
	fltk::ThumbWheel* rollerMagnitude;

	fltk::FloatInput* inputSize;
	fltk::ThumbWheel* rollerSize;

	fltk::CheckButton* checkShowForce;
	fltk::CheckButton* checkApplyAll;
	fltk::CheckButton* checkCollide;
*/		
};
#endif
