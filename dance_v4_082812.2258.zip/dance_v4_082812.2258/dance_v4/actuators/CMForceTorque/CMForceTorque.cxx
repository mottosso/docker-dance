#include <cstdio>
#include <cstdlib>
#include "dance.h"
#include "danceInterp.h"

#include "GLutilities.h"
#include "DObjectList.h"
#include "CMForceTorque.h"
#include "DSimulator.h"
#include "CMForceTorqueWindow.h"

PlugIn *Proxy(void) { return (new CMForceTorque); } ;

CMForceTorque::CMForceTorque()
: m_startTime( 0 ), m_duration( 0 ), m_CMForceTorqueWindow( 0 )
{
	zeroVector( m_acceleration );

	
	/*
	magnitude	= 1.0 ;
    direction[0] = 0.0 ;
    direction[1] = 0.0 ;
    direction[2] = 1.0 ;
    position[0]	= 0.0 ;
    position[1]	= 0.0 ;
    position[2]	= 0.0 ;

	m_impulse[0] = 1.0;
	m_impulse[1] = 0.0;
	m_impulse[2] = 0.0;

	m_impulseTime = 1.0;

	m_acc_time  = 10 ; // seconds
	m_maxAngle = 1.5 ; // degrees
	m_delay = 5 ; // seconds
	m_frequency = 0.2; // Hertz
	m_maxVel = 20 ; // Km/h
    link = 0 ;
    artObj = NULL ;
	m_CMForceTorqueWindow = NULL;
	this->setSize(.1);
	dance::AllSimulators->addBeforeSimStepCB(this, 10, beforeStep);
	*/
}

CMForceTorque::~CMForceTorque()
{
    return ;
}



PlugIn *CMForceTorque::create(int argc, char **argv)
{
    CMForceTorque *f = new CMForceTorque ;

    if(	f == NULL )
    {
		danceInterp::OutputMessage( "Cannot allocate memory!\n") ;
		return NULL ;
    }
    return f ;
}


void CMForceTorque::ExertLoad(DSystem *ao, DSimulator* sim, double time, double dt, double *state, double *dstate)
{
	if( !this->isAppliedAllObjects() && !this->isInApplyList(ao) )
	{
		return;
	}

/*	
	double maxVel = m_maxVel*1000.0/3600.0 ; // 20 Km/h

	double acc = maxVel / m_acc_time ;
	double const_time = 50 ; //  seconds


	double t = time - GetStartTime() ;
	if( t < m_acc_time )
	{
	    acc ;
	}
	else if ( t < (m_acc_time + const_time) )
	{
		acc = 0 ;
	}
	else if( t < (2*m_acc_time+const_time) )
	{
		acc = -acc ;
	}
	else
		acc = 0 ;

	double ksLin =100000 ;
	double kdLin =10000 ;

	double Ixx = 10000000 ;
	Vector force = {0,0,0}, zero = {0,0,0}, forceLocal ;
	force[0] = ao->GetGroupMass(0)*acc;
	// make sure we stay on the same height
	force [1] = ksLin*(0 - state[1]) - kdLin*dstate[1] ;
	force [2] = ksLin*(0 - state[2]) - kdLin*dstate[2] ;

	sim->GetOrientation(-1, force, 0,forceLocal);
	sim->PointForce(0, zero, forceLocal) ;
	//Vector negGrav = {0,9.8,0} ;
	//sim->FieldForce(negGrav) ;

	Quaternion q(state[3],state[4], state[5], state[6]) ;
	Matrix3x3 mat ;
	q.toMatrix(mat) ;
	VectorObj euler ;
	mat.matToEuler(Matrix3x3::XYZ, euler,false) ;
	double MaxThetaX = m_maxAngle*M_PI/ 180.0 ;
	double thetaX = 0 ;
	
	if( t > m_delay)
		thetaX = MaxThetaX*sin( 0.2*(double) 2*M_PI*(t - m_delay)) ;
	else
		thetaX = 0 ;
	Vector torque = {0,0,0};
	torque[0] = 30000*Ixx*(thetaX - euler[0]) - 9000.0*dstate[3] ;
	torque[1] = 30000*(0 - euler[1]) - 900.0*dstate[4] ;
	torque[2] = 30000*(0 - euler[2]) - 900.0*dstate[5] ;
	sim->BodyTorque(0,torque) ;
	//danceInterp::OutputMessage("Torque %lf %lf %lf", torque[0], torque[1], torque[2])  ;
	*/
	Vector force;
//	Vector forceLocal;
	Vector zero= {0,0,0};

	if( (time >= m_startTime) && (time < (m_startTime + m_duration)) )
	{
		danceInterp::OutputMessage("actuator %s starting at time %f", this->getName(), time);
		VecCopy( force, m_acceleration );
		VecNumMul( force, force, ao->GetGroupMass(0) );

		//sim->GetOrientation( -1, force, 0, forceLocal );
		sim->PointForce( 0, zero, force );
		//danceInterp::OutputMessage( "DEBUG: CMForceTorque::ExertForce() applying acceleration of %f %f %f", m_acceleration[0], m_acceleration[1], m_acceleration[2] );
	}	
}


int CMForceTorque::commandPlugIn(int argc, char **argv)
{
	int ret = DActuator::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

    if(	strcmp(argv[0],"acceleration") == 0	)
    {
		if( argc < 4 )
		{
			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"acceleration\", <x>, <y>, <z> )", this->getName());
			return DANCE_ERROR ;
		}

		for( int i = 0; i < 3; ++i )
		{
			m_acceleration[i] = atof(argv[i + 1]) ;
		}

		dance::Refresh();  //???
		return DANCE_OK;
    }
	else if( strcmp(argv[0],"start_time") == 0 )
	{
		if( argc < 2 )
		{
			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"start_time\", <val>)", this->getName());
			return DANCE_ERROR ;
		}
		m_startTime = atof( argv[1] ) ;
		dance::Refresh();
		return DANCE_OK;
	}
	else if( strcmp(argv[0],"duration") == 0 )
	{
		if( argc < 2 )
		{
			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"duration\", <val>)", this->getName());
			return DANCE_ERROR ;
		}
		m_duration = atof( argv[1] ) ;
		dance::Refresh();
		return DANCE_OK;
	}
/*




    else if( strcmp(argv[0],"direction") == 0 )
    {
		if( argc < 4 )
		{
			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"direction\", <x>, <y>, <z>", this->getName());
			return DANCE_ERROR ;
		}

		direction[0] = atof(argv[1]) ;
		direction[1] = atof(argv[2]) ;
		direction[2] = atof(argv[3]) ;
		VecNormalize(direction) ;

		this->setDirection(direction);
		dance::Refresh();

		return DANCE_OK;
    }
    else if( strcmp(argv[0],"magnitude") == 0 )
    {
		if( argc < 2 )
		{
			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"magnitude\", <val>", this->getName());
			return DANCE_ERROR ;
		}
		magnitude = atof(argv[1]) ;
		dance::Refresh();

		return DANCE_OK;
    }
	else if( strcmp( argv[0], "impulse") == 0 )
	{
		if( argc != 4 )
		{
			danceInterp::OutputMessage( "Usage: dance.actuator(\"%s\", \"impulse\", <x>, <y>, <z>", getName() );
			return DANCE_ERROR;
		}
		for( int i = 0; i <3; ++i )
		{
			m_impulse[i] = atof( argv[1+i] );
		}
		dance::Refresh();
		return DANCE_OK;
	}
	else if( strcmp(argv[0],"impulse_time") == 0 )
	{
		if( argc < 2 )
		{
			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"impulse_time\", <val>", this->getName());
			return DANCE_ERROR ;
		}
		m_impulseTime = atof(argv[1]) ;
		dance::Refresh();
		return DANCE_OK;
	}
	else if( strcmp(argv[0],"delay") == 0 )
	{
		if( argc < 2 )
		{
			danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"delay\", <val>", this->getName());
			return DANCE_ERROR ;
		}
		// NOTE direction used for velocity and delay
		direction[1] = atof(argv[1]) ;
		dance::Refresh();
		return DANCE_OK;
	}
    else
    {
		danceInterp::OutputMessage("Usage: dance.actuator(\"%s\", \"delay\", <val>", this->getName());
		return DANCE_ERROR ;
    }
*/
    return DANCE_CONTINUE;
}

void CMForceTorque::output(int mode)
{
	return ;
}
/*
void CMForceTorque::getPosition(Vector pos)
{
	position[0] = this->m_acc_time;
	position[1] = this->m_frequency ;
	position[2] = this->m_maxAngle ;
	for (int x = 0; x < 3; x++)
		pos[x] = position[x];
}

void CMForceTorque::setPosition(Vector pos)
{
	for (int x = 0; x < 3; x++)
		position[x] = 	pos[x]  ;
	this->m_acc_time = pos[0] ;
	this->m_frequency = pos[1] ;
	this->m_maxAngle = pos[2] ;

	if (this->m_CMForceTorqueWindow != NULL)
		this->m_CMForceTorqueWindow->updateGUI();
}

void CMForceTorque::getDirection(Vector dir)
{
	direction[0] = m_maxVel ;
	direction[1] = m_delay ;
	for (int x = 0; x < 3; x++)
		dir[x] = direction[x];
}

void CMForceTorque::setDirection(Vector dir)
{
	m_maxVel = dir[0] ;
	m_delay = dir[1] ;
	for (int x = 0; x < 3; x++)
		direction[x] = dir[x];
}

double CMForceTorque::getMagnitude()
{
	return magnitude;
}

void CMForceTorque::setMagnitude(double mag)
{
	magnitude = mag;
}

void CMForceTorque::setImpulse( Vector arg )
{
	VecCopy( m_impulse, arg );
	danceInterp::OutputMessage( "Impulse set to %f %f %f", m_impulse[0], m_impulse[1], m_impulse[2] );
}

void CMForceTorque::getImpulse( Vector out )
{
	VecCopy( out, m_impulse );
}

void CMForceTorque::setImpulseTime( double argSecs )
{
	m_impulseTime = argSecs;
	danceInterp::OutputMessage( "Impulse time set to %f", m_impulseTime );
}

double CMForceTorque::getImpulseTime( void )
{
	return m_impulseTime;
}
*/
fltk::Widget* CMForceTorque::getInterface()
{
	if (m_CMForceTorqueWindow == NULL)
	{
		m_CMForceTorqueWindow = new CMForceTorqueWindow(this, 0, 0, 300, 350, this->getName());
	}

	return m_CMForceTorqueWindow;
}

int CMForceTorque::getNumPluginDependents()
{
	return 0;
}

const char* CMForceTorque::getPluginDependent(int num)
{
	return NULL;
}

void CMForceTorque::save(int mode, std::ofstream& file)
{
	if (mode == 0)
	{
		file << "dance.instance(\"CMForceTorque\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
		char buff[512];

		// start time
		sprintf(buff, "\"start_time\", %f", m_startTime );
		pythonSave(file, buff);
		// duration
		sprintf(buff, "\"duration\", %f", m_duration );
		pythonSave(file, buff);

		// acceleration
		sprintf(buff, "\"acceleration\", %f, %f, %f", m_acceleration[0], m_acceleration[1], m_acceleration[2] );
		pythonSave(file, buff);

/*

		// magnitude
		sprintf(buff, "\"magnitude\", %f", this->getMagnitude());
		pythonSave(file, buff);

		// size
		sprintf(buff, "\"size\", %f", this->getSize());
		pythonSave(file, buff);

		// direction
		Vector direction;
		this->getDirection(direction);
		sprintf(buff, "\"direction\", %f, %f, %f", direction[0], direction[1], direction[2]);
		pythonSave(file, buff);

		// position
		Vector position;
		this->getPosition(position);
		sprintf(buff, "\"position\", %f, %f, %f", position[0], position[1], position[2]);
		pythonSave(file, buff);

		// impulse
		Vector imp;
		getImpulse( imp );
		sprintf(buff, "\"impulse\", %f, %f, %f", imp[0], imp[1], imp[2]);
		pythonSave(file, buff);

		// impulse time
		sprintf(buff, "\"impulse_time\", %f", getImpulseTime() );
		pythonSave(file, buff);

		pythonSave(file, buff);
*/
	}
	else if (mode == 2)
	{
	}

	DActuator::save(mode, file);

}
/*
void CMForceTorque::setSize(double val)
{
	size = val;
}

double CMForceTorque::getSize()
{
	return size;
}
*/



