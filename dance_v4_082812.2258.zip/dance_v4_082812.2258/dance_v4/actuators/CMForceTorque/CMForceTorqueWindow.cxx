#include "CMForceTorqueWindow.h"
#include "CMForceTorque.h"
#include "dance.h"
#include "ViewManager.h"

using namespace fltk;

CMForceTorqueWindow::CMForceTorqueWindow(CMForceTorque* f, int x, int y, int width, int height, const char* name) : Group(x, y, width, height, name)
{
    m_CMForceTorque = f;

	this->begin();
	int yOffset = 20;

	inputStartTime = new FloatInput( 80, yOffset, 60, 20, "Start Time" );
	inputStartTime->callback( StartTimeChangeCB, this );

	yOffset += 20;
	inputDuration = new FloatInput( 80, yOffset, 60, 20, "Duration" );
	inputDuration->callback( DurationChangeCB, this );

	yOffset += 20;
	for (int x = 0; x < 3; x++)
	{
		inputAcceleration[x] = new FloatInput(80, yOffset + 25 * x, 60, 20, "Acceleration" );
		inputAcceleration[x]->callback(AccelerationChangeCB, this);
		
		rollerAcceleration[x] = new ThumbWheel(160, yOffset + 25 * x, 60, 20, NULL);
		rollerAcceleration[x]->callback(AccelerationChangeRollerCB, this);
		rollerAcceleration[x]->range(-1000.0, 1000.0);
		rollerAcceleration[x]->value(0.0);
		rollerAcceleration[x]->step(0.1);
	}

	
/*
	for (int x = 0; x < 3; x++)
	{
		inputPosition[x] = new FloatInput(80, yOffset + 25 * x, 60, 20, x == 0 ? "ACC TIME" : x == 1 ? "FREQ" : "MAX ANGLE");
		inputPosition[x]->callback(PositionChangeCB, this);
		rollerPosition[x] = new ThumbWheel(160, yOffset + 25 * x, 60, 20, NULL);
		rollerPosition[x]->callback(PositionChangeRollerCB, this);
		rollerPosition[x]->range(-1000000.0, 1000000.0);
		rollerPosition[x]->value(0.0);
		rollerPosition[x]->step(0.01);
	}
	yOffset += 120;
	for (int x = 0; x < 3; x++)
	{
		inputDirection[x] = new FloatInput(80, yOffset + 25 * x, 60, 20,  x == 0 ? "Max Vel" : x == 1 ? "Delay" : "Dummy");
		inputDirection[x]->callback(DirectionChangeCB, this);

		rollerDirection[x] = new ThumbWheel(160, yOffset + 25 * x, 60, 20, NULL);
		rollerDirection[x]->callback(DirectionChangeRollerCB, this);
		rollerDirection[x]->range(-1000000.0, 1000000.0);
		rollerDirection[x]->value(0.0);
		rollerDirection[x]->step(0.01);
	}
	yOffset += 120;

	for (int x = 0; x < 3; x++)
	{
		inputImpulse[x] = new FloatInput(80, yOffset + 25 * x, 60, 20, "Impulse" );
		inputImpulse[x]->callback(ImpulseChangeCB, this);

		rollerImpulse[x] = new ThumbWheel(160, yOffset + 25 * x, 60, 20, NULL);
		rollerImpulse[x]->callback(ImpulseChangeRollerCB, this);
		rollerImpulse[x]->range(-1000000.0, 1000000.0);
		rollerImpulse[x]->value(0.0);
		rollerImpulse[x]->step(10.0);
	}
	yOffset += 85;
	inputImpulseTime = new FloatInput( 80, yOffset, 60, 20, "Impulse Time" );
	inputImpulseTime->callback( ImpulseTimeChangeCB, this );

	yOffset += 35;

	inputMagnitude  = new FloatInput(80, yOffset, 40, 20, "Magnitude");
	inputMagnitude->callback(MagnitudeChangeCB, this);
	rollerMagnitude = new ThumbWheel(160, yOffset, 60, 20, NULL);
	rollerMagnitude->callback(MagnitudeChangeRollerCB, this);
	rollerMagnitude->range(-1000000.0, 1000000.0);
	rollerMagnitude->value(0.0);
	rollerMagnitude->step(0.01);

	yOffset += 25;
	inputSize  = new FloatInput(80, yOffset, 40, 20, "Size");
	inputSize->callback(SizeChangeCB, this);
	rollerSize = new ThumbWheel(160, yOffset, 60, 20, NULL);
	rollerSize->callback(SizeChangeRollerCB, this);
	rollerSize->range(-1000000.0, 1000000.0);
	rollerSize->value(0.0);
	rollerSize->step(0.01);

	// 285

	yOffset += 25;
	checkShowForce = new CheckButton(20, yOffset, 80, 20, "Show");
	checkShowForce->callback(ShowChangeCB, this);

	yOffset += 20;
	checkApplyAll = new CheckButton(100, yOffset, 80, 30, "Apply All");
	checkApplyAll->callback(ApplyAllCB, this);
*/
	this->end();

	this->updateGUI();
}

void CMForceTorqueWindow::updateGUI()
{
//	Vector p;

	for (int x = 0; x < 3; x++)
	{
		inputAcceleration[x]->value(m_CMForceTorque->m_acceleration[x]);
		rollerAcceleration[x]->value(m_CMForceTorque->m_acceleration[x]);
	}
	inputStartTime->value( m_CMForceTorque->m_startTime );
	inputDuration->value( m_CMForceTorque->m_duration );


/*
	m_CMForceTorque->getPosition(p);
	for (int x = 0; x < 3; x++)
	{
		inputPosition[x]->value(p[x]);
		rollerPosition[x]->value(p[x]);
	}

	m_CMForceTorque->getDirection(p);
	for (int x = 0; x < 3; x++)
	{
		inputDirection[x]->value(p[x]);
		rollerDirection[x]->value(p[x]);
	}

	Vector imp = {0,0,0};
	m_CMForceTorque->getImpulse(imp);
	for (int x = 0; x < 3; x++)
	{
		inputImpulse[x]->value(imp[x]);
		rollerImpulse[x]->value(imp[x]);
	}
	inputImpulseTime->value( m_CMForceTorque->getImpulseTime() );

	inputMagnitude->value(this->m_CMForceTorque->getMagnitude());
	rollerMagnitude->value(this->m_CMForceTorque->getMagnitude());

	inputSize->value(this->m_CMForceTorque->getSize());
	rollerSize->value(this->m_CMForceTorque->getSize());

	checkShowForce->value(this->m_CMForceTorque->isVisible());
	checkApplyAll->value(m_CMForceTorque->isAppliedAllObjects());
*/
}

void CMForceTorqueWindow::AccelerationChangeCB(Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

//	Vector pos;
	for (int x = 0; x < 3; x++)
	{
		win->m_CMForceTorque->m_acceleration[x] = win->inputAcceleration[x]->fvalue();
	}

	for (int x = 0; x < 3; x++)
	{
		win->rollerAcceleration[x]->value( win->m_CMForceTorque->m_acceleration[x] );
	}

	win->updateGUI();
	dance::Refresh();
}


void CMForceTorqueWindow::AccelerationChangeRollerCB(Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

//	Vector pos;
	for (int x = 0; x < 3; x++)
	{
		win->m_CMForceTorque->m_acceleration[x] = win->rollerAcceleration[x]->value();
	}

	for (int x = 0; x < 3; x++)
	{
		win->inputAcceleration[x]->value( win->m_CMForceTorque->m_acceleration[x]);
	}

	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::StartTimeChangeCB(Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;
	double t = win->inputStartTime->fvalue();
	win->m_CMForceTorque->m_startTime = t;
	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::DurationChangeCB(Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;
	double t = win->inputDuration->fvalue();
	win->m_CMForceTorque->m_duration = t ;
	win->updateGUI();
	dance::Refresh();
}

/*

void CMForceTorqueWindow::PositionChangeCB(Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

	Vector pos;
	for (int x = 0; x < 3; x++)
	{
		pos[x] = win->inputPosition[x]->fvalue();
	}

	for (int x = 0; x < 3; x++)
	{
		win->rollerPosition[x]->value(pos[x]);
	}

	win->m_CMForceTorque->setPosition(pos);
	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::PositionChangeRollerCB(Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

	Vector pos;
	for (int x = 0; x < 3; x++)
	{
		pos[x] = win->rollerPosition[x]->value();
	}

	for (int x = 0; x < 3; x++)
	{
		win->inputPosition[x]->value(pos[x]);
	}

	win->m_CMForceTorque->setPosition(pos);
	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::ImpulseChangeCB(Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;
	Vector imp;
	for (int x = 0; x < 3; x++)
	{
		imp[x] = win->inputImpulse[x]->fvalue();
		win->rollerImpulse[x]->value(imp[x]);
	}
	win->m_CMForceTorque->setImpulse( imp );
	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::ImpulseChangeRollerCB(Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

	Vector imp;
	for (int x = 0; x < 3; x++)
	{
		imp[x] = win->rollerImpulse[x]->value();
		win->rollerImpulse[x]->value(imp[x]);
	}

	win->m_CMForceTorque->setImpulse(imp);
	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::ImpulseTimeChangeCB(Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;
	double t = win->inputImpulseTime->fvalue();
	win->m_CMForceTorque->setImpulseTime( t );
	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::DirectionChangeCB(Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

	Vector dir;
	for (int x = 0; x < 3; x++)
	{
		dir[x] = win->inputDirection[x]->fvalue();
	}

	for (int x = 0; x < 3; x++)
	{
		win->rollerDirection[x]->value(dir[x]);
	}

	win->m_CMForceTorque->setDirection(dir);
	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::DirectionChangeRollerCB(Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

	Vector dir;
	for (int x = 0; x < 3; x++)
	{
		dir[x] = win->rollerDirection[x]->value();
	}

	for (int x = 0; x < 3; x++)
	{
		win->inputDirection[x]->value(dir[x]);
	}

	win->m_CMForceTorque->setDirection(dir);
	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::MagnitudeChangeCB(fltk::Widget* w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

	win->m_CMForceTorque->setMagnitude(win->inputMagnitude->fvalue());
	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::MagnitudeChangeRollerCB(fltk::Widget* w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

	win->m_CMForceTorque->setMagnitude(win->rollerMagnitude->value());
	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::ShowChangeCB(fltk::Widget* w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

	win->m_CMForceTorque->setVisible(win->checkShowForce->value());
	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::ApplyAllCB(fltk::Widget* w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

	win->m_CMForceTorque->setAppliedAllObjects(win->checkApplyAll->value());
	win->updateGUI();
	dance::Refresh();
}

void CMForceTorqueWindow::SizeChangeCB(fltk::Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

	win->m_CMForceTorque->setSize(win->inputSize->fvalue());

	win->updateGUI();
	dance::Refresh();

}

void CMForceTorqueWindow::SizeChangeRollerCB(fltk::Widget *w, void *data)
{
	CMForceTorqueWindow* win = (CMForceTorqueWindow*) data;

	win->m_CMForceTorque->setSize(win->rollerSize->value());

	win->updateGUI();
	dance::Refresh();
}
*/
