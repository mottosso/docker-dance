#ifndef	CMForceTorque_H
#define	CMForceTorque_H	

#include "DActuator.h"


class CMForceTorqueWindow;

#define MAXIMPACTS 50

struct ImpactLocation
{
	Vector point;
	int linkID;
};

class CMForceTorqueWindow;

class CMForceTorque : public DActuator
{

	public:
		CMForceTorque();
		~CMForceTorque();

		PlugIn* create(int argc, char **argv) ;
		void output(int mode);
		void ExertLoad(DSystem *ao, DSimulator* sim, double time, double dt, double *state, double *dstate);
		int commandPlugIn(int argc, char	**argv);
  
		void getPosition(Vector pos);
		void setPosition(Vector pos);
		void getDirection(Vector dir);
		void setDirection(Vector dir);
		double getMagnitude();
		void setMagnitude(double mag);
		void setImpulse( Vector arg );
		void getImpulse( Vector out );
		void setImpulseTime( double argSecs );
		double getImpulseTime( void );
		void setIsCollide(bool val);
		bool getIsCollide();

		void setSize(double val);
		double getSize();

		void save(int mode, std::ofstream& file);
		fltk::Widget* getInterface();

		int getNumPluginDependents();
		const char* getPluginDependent(int num);

		void SetStartTime(double t) { m_startTime = t;} ;
		double GetStartTime(void) { return m_startTime;} ;

		friend class CMForceTorqueWindow;
	private:

		double m_startTime;
		double m_duration;
		Vector m_acceleration;
		
		CMForceTorqueWindow* m_CMForceTorqueWindow;
		
		// DEPRECATED 
		/*double position[3];
		double direction[3];
		double magnitude;
		int link ;
		DSystem *artObj ;
		bool m_show;

		double size;
		bool hasStarted;
		double m_acc_time ;
		double m_maxAngle ;
		double m_delay ;
		double m_frequency ;
		double m_maxVel ;
		*/
};


#endif
