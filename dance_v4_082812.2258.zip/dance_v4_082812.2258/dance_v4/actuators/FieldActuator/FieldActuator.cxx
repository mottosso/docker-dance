/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "opengl.h"
#include "dance.h"
#include "danceInterp.h"
#include "DObjectList.h"
#include "FieldActuator.h"
#include "DSystem.h"
#include "DSimulator.h"
#include "FieldActuatorWindow.h"

#include "noise.h"

#ifndef EPS
#define EPS 0.00000001
#endif

using namespace fltk;

PlugIn *Proxy() { return (new FieldActuator); } ;

void displayVector(double point[3], double direction[3], double magnitude)
{
    double vector[3] ;
    for	(int i = 0; i <	3; i++)
	    vector[i] =	direction[i]*magnitude;

    // if a zero vector is given do not draw to avoid segmentation fault
    if( (fabs(vector[0]) < EPS) && (fabs(vector[1]) < EPS) && (fabs(vector[2]) < EPS))
	return ;

    glPushMatrix();
	      glTranslated(point[0],point[1],point[2]);
	      // Draw vector line.
	      glBegin(GL_LINES);
	      glVertex3d(0.0,0.0,0.0);
	      glVertex3dv(vector);
	      glEnd();

	      // Rotate	Z-axis of original cone	to line	up with	arrow
	      // compute dot product and angle between vectors.
	      double length = sqrt(vector[0]*vector[0] +
			vector[1]*vector[1] + vector[2]*vector[2]);
	      double angle = acos(vector[2]/length)*180.0/M_PI;

	      glTranslated(vector[0],vector[1],vector[2]);

	      // Calculate cross product of Z-axis and joint axis to
	      // produce axis of rotation.
	      glRotated(angle,-1.0*vector[1],vector[0],0.0);

	      // Draw arrow-head, translate apex of cone to origin.
	      glTranslated(0.0,0.0,-0.3*length);
	      glutWireCone(0.1*length,0.3*length, 3, 3);
    glPopMatrix();
}

FieldActuator::FieldActuator() : DActuator() {

	m_directionAttr = this->createVec3Attribute("direction", 0, 1.0, 0, true, "Parameters", 60);
	m_magnitudeAttr = this->createDoubleAttribute("magnitude", -9.8, true, "Parameters", 70);
	m_randomDirAttr = this->createBoolAttribute("randomdirection", false, true, "Parameters", 80);

	BoolAttribute* displayAttr = dynamic_cast<BoolAttribute*>(this->getAttribute("visible"));
	if (displayAttr)
		displayAttr->setValue(false);

	setType("field");
	
	m_fieldActuatorWindow = NULL;
}

FieldActuator::~FieldActuator()
{
	if (m_fieldActuatorWindow)
		delete m_fieldActuatorWindow;
}


void FieldActuator::output(int mode)
{
	if (m_show)
	{
		if (mode)
		{
			GLboolean	prevL =	glIsEnabled(GL_LIGHTING) ;
			if (prevL)
				glDisable(GL_LIGHTING) ;
			glColor4f(1.0,1.0,0.0,1.0);
			Vector zero = {0, 0, 0};
			displayVector(zero, m_directionAttr->getValue(), m_magnitudeAttr->getValue() * 0.025);
			if (prevL)
				glEnable(GL_LIGHTING) ;
		}
	}
}

/*
int FieldActuator::Interact(Event *event)
{
    int	x,  y ;
    int	width, height, diffx, diffy ;

    diffx = event->winDiffX ;
    diffy = event->winDiffY ;
    width = event->winWidth ;
    height = event->winHeight ;
    x =	event->winX ;
    y =	event->winY ;


    if (interactionMode	== pDirection) {
	    HVect coords;
	    coords.x = float(2.0)*(float)x/(float)width-float(1.0);
	    coords.y = -float(2.0)*(float)y/(float)height+float(1.0);

	    Ball_Mouse(arcball,coords);
	    Ball_Update(arcball);

	    HMatrix arcball_rot;
	    Ball_Value(arcball,arcball_rot);

	    // Transform startVector to	world coordinates
	    int	i;
	    double viewStart[3]={0.0,0.0,0.0};
	    for	(i = 0;	i < 3; i++) {
		viewStart[0] +=	event->winBasisX[i]*startVector[i];
		viewStart[1] +=	event->winBasisY[i]*startVector[i];
		viewStart[2] +=	event->winBasisZ[i]*startVector[i];
	    }

	    double viewDirection[3];
	    for	(i = 0;	i < 3; i++) {
		viewDirection[i] = arcball_rot[0][i] * viewStart[0]
			   + arcball_rot[1][i] * viewStart[1]
			   + arcball_rot[2][i] * viewStart[2];
	    }

	    // Back to original	world space.
	    for	(i = 0;	i < 3; i++) {
		direction[i] = event->winBasisX[i]*viewDirection[0]
			     + event->winBasisY[i]*viewDirection[1]
			     + event->winBasisZ[i]*viewDirection[2];
	    }
	}
	else if	(interactionMode == pPosition) {
	    for	(int i = 0 ; i < 3; i++)
		position[i] += event->winBasisX[i]*0.01*(double)diffx -
		  event->winBasisY[i]*0.01*(double)diffy;
	}
	else if	(interactionMode == pMagnitude)	{
	    if (diffx +	diffy >	0)
		magnitude *= 1.10;
	    else
		magnitude *= 0.90;
	}

	return 0;
}

int FieldActuator::InteractEnd()
{
	if (interactionMode == pDirection)
	    Ball_EndDrag(arcball);
	return 0 ;
}

int FieldActuator::InteractStart(Event	*event)
{

    switch(event->buttonID) {
	    case GLUT_LEFT_BUTTON:
		{
		interactionMode	= pDirection;
		memcpy(startVector,direction,3*sizeof(double));
		HVect coords;
		coords.x = float(2.0)*(float)event->winX/(float)event->winWidth-float(1.0);
		coords.y = -float(2.0)*(float)event->winY/(float)event->winHeight+float(1.0);
		Ball_Mouse(arcball,coords);
		Ball_BeginDragReset(arcball);
		}
		break;
	    case GLUT_MIDDLE_BUTTON:
		interactionMode	= pPosition;
		break;
	    case GLUT_RIGHT_BUTTON:
		interactionMode	= pMagnitude;
		break;
	}
    return 1 ;
}
*/

void FieldActuator::ExertLoad(DSystem *ao, DSimulator* sim, double time, double dt,
			      double *state, double *dstate)
{
	if (!this->isAppliedAllObjects() && !this->isInApplyList(ao))
		return;

    double force[3];

    if (m_randomDirAttr->getValue()) {
		double dir[3], v;
		
		v = 1.0;
		dir[0] = danceNoise::noise3(v*time, 0.5, 0.5);
		dir[1] = danceNoise::noise3(0.5, v*time, 1.5);
		dir[2] = danceNoise::noise3(0.5, 2.5, v*time);
		
		force[0] = m_magnitudeAttr->getValue() * dir[0];
		force[1] = m_magnitudeAttr->getValue() * dir[1];
		force[2] = m_magnitudeAttr->getValue() * dir[2];
	} else {
		force[0] = m_magnitudeAttr->getValue() * m_directionAttr->getValue()[0] ;
		force[1] = m_magnitudeAttr->getValue() * m_directionAttr->getValue()[1] ;
		force[2] = m_magnitudeAttr->getValue() * m_directionAttr->getValue()[2] ;
    }

	sim->FieldForce(force) ;
}

PlugIn *FieldActuator::create(int argc, char **argv)
{
    FieldActuator *f = new FieldActuator ;

    if(	f == NULL )
    {
	danceInterp::OutputMessage("Cannot allocate memory!\n") ;
	return NULL ;
    }

    

    return f ;
}

int FieldActuator::commandPlugIn( int argc, char **argv)
{
    int ret = DActuator::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

	if (strcmp(argv[0],"type") == 0)
	{
		danceInterp::OutputResult("%s", getType());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "show") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: show [on|off]");
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "on") == 0)
		{
			m_show = true;
			danceInterp::OutputMessage("Field vector will be shown.");
		}
		else if (strcmp(argv[1], "off") == 0)
		{
			m_show = false;
			danceInterp::OutputMessage("Field vector will not be shown.");
		}
		else
		{
			danceInterp::OutputMessage("Usage: show [on|off]");
			return DANCE_ERROR;
		}
		return DANCE_OK;
	}
    else if (strcmp(argv[0],	"magnitude") ==	0 )
    {
		if (argc != 2)
		{
			danceInterp::OutputMessage("Usage: actuator %s magnitude <value>", this->getName());
			return DANCE_ERROR ;
		}
		m_magnitudeAttr->setValue(atof(argv[1]));
		danceInterp::OutputMessage("Magnitude for FieldActuator %s is now %f", this->getName(), this->m_magnitudeAttr->getValue());
		return DANCE_OK;
    }
	else if ( strcmp(argv[0], "direction") == 0	)
    {
		if( argc != 4 )
		{
			danceInterp::OutputMessage("Usage: actuator %s direction <x> <y> <z>", this->getName());
			return DANCE_ERROR ;
		}

		Vector direction;
		direction[0] = atof(argv[1]);
		direction[1] = atof(argv[2]);
		direction[2] = atof(argv[3]);
		m_directionAttr->setValue(direction);

		// normalize it
		double m = sqrt(direction[0]*direction[0] + direction[1]*direction[1] + direction[2]*direction[2]) ;

		if( m >	0.000001 )
		{
			direction[0] /= m ;
			direction[1] /= m ;
			direction[2] /= m ;
		}
		danceInterp::OutputMessage("Direction for FieldActuator %s is now %f %f %f", this->getName(), direction[0], direction[1], direction[2]);
		return DANCE_OK;
    }
	else if( strcmp(argv[0], "field") == 0 )
    {
		if( argc != 4 )
		{
			danceInterp::OutputMessage("Usage: actuator %s field <x> <y> <z>", this->getName());
			return DANCE_ERROR ;
		}
		Vector direction;
		direction[0] = atof(argv[1]);
		direction[1] = atof(argv[2]);
		direction[2] = atof(argv[3]);
		m_directionAttr->setValue(direction);

		// normalize it
		m_magnitudeAttr->setValue(sqrt(direction[0]*direction[0] + direction[1]*direction[1] + direction[2]*direction[2]));

		if( m_magnitudeAttr->getValue() > 0.000001 )
		{
			direction[0] /= m_magnitudeAttr->getValue();
			direction[1] /= m_magnitudeAttr->getValue();
			direction[2] /= m_magnitudeAttr->getValue();
			m_directionAttr->setValue(direction);
		}
		danceInterp::OutputMessage("Direction for FieldActuator %s is now %f %f %f, magnitude is now %f", this->getName(), this->m_directionAttr->getValue()[0], this->m_directionAttr->getValue()[1], this->m_directionAttr->getValue()[2], this->m_magnitudeAttr->getValue());

    }
	return DANCE_CONTINUE;
	
}

void FieldActuator::getDirection(Vector dir)
{
	for (int x = 0; x < 3; x++)
		dir[x] = m_directionAttr->getValue()[x];
}

void FieldActuator::setDirection(Vector dir)
{
	Vector direction;
	for (int x = 0; x < 3; x++)
		direction[x] = dir[x];
	m_directionAttr->setValue(direction);
}

double FieldActuator::getMagnitude()
{
	return m_magnitudeAttr->getValue();
}

void FieldActuator::setMagnitude(double mag)
{
	m_magnitudeAttr->setValue(mag);
}

Widget* FieldActuator::getInterface()
{
	if (m_fieldActuatorWindow == NULL)
	{
		m_fieldActuatorWindow = new FieldActuatorWindow(this, 0, 0, 330, 500, this->getName());
	}

	return m_fieldActuatorWindow;
}

bool FieldActuator::isShow()
{
	return m_show;
}

void FieldActuator::setShow(bool val)
{
	m_show = val;
}

void FieldActuator::save(int mode, std::ofstream& file)
{
	if (mode == 0)
	{
		file << "dance.instance(\"FieldActuator\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
	}

	DActuator::save(mode, file);

}

void FieldActuator::notify(DSubject* subject)
{
}
