/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_FIELDACTUATOR_H_
#define	_FIELDACTUATOR_H_ 

#include <cstdlib>
#include "DActuator.h"

class FieldActuatorWindow;

class FieldActuator : public DActuator {
	
	public:
		FieldActuator();
		~FieldActuator();

		PlugIn* create(int argc, char **argv) ;
		void output(int	mode);
		void ExertLoad(DSystem *ao, DSimulator* sim, double time, double dt,
			       double *state, double *dstate);
		int commandPlugIn(int argc, char	**argv);

		void getDirection(Vector dir);
		void setDirection(Vector dir);
		double getMagnitude();
		void setMagnitude(double mag);
		bool isShow();
		void setShow(bool val);

		void save(int mode, std::ofstream& file);

		void notify(DSubject* subject);

		fltk::Widget* getInterface();

private:
		Vec3Attribute* m_directionAttr;
		DoubleAttribute* m_magnitudeAttr;
		BoolAttribute* m_randomDirAttr;
		double startVector[3];
		double position[3];
		int interactionMode;

		double damping[3];
		bool doDamping;
		bool m_show;

		FieldActuatorWindow* m_fieldActuatorWindow;


};


#endif
