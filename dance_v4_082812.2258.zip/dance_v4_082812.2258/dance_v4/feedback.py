import webbrowser

url = 'http://www.arishapiro.com/dance/feedback.html?version=%s' % (dance.version())
webbrowser.open_new(url)



