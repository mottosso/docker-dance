/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef __SKINTABLE_H__
#define __SKINTABLE_H__

#include <fltk/FloatInput.h>
#include "Table.h"

#include <cstdio>
#include <string>

#include "LinearSkinning.h"

class SkinTable : public Table
{
	protected:
		void draw_cell(TableContext context, int R=0, int C=0, fltk::Rectangle *cell=0);

	public:
		SkinTable(int x, int y, int w, int h, const char *l=0) : Table(x, y, w, h, l)
		{
			skin = NULL;
			m_selectedCol = -1;

			this->callback(event_callback, this);
			this->begin();
			inputField = new fltk::FloatInput(w/2, h/2, 0, 0);
			inputField->hide();
			inputField->color(fltk::GRAY95);
			inputField->box(fltk::THIN_DOWN_BOX);
			inputField->callback(input_cb, this);
			inputField->when(fltk::WHEN_ENTER_KEY_ALWAYS);
			this->end();
		};

		~SkinTable() { };

		fltk::FloatInput* inputField;

		void setSkin(LinearSkinning *ls);
		void getSkinInfo(int R, int C, char *link, float *weight);
		bool rowSelected(int R);
		void selectCurrentRow(int R);
		void deselectCurrentRow(int R);
		void deselectAllRows();

		bool colSelected(int C);
		void selectCurrentCol(int C);
		void deselectCurrentCol(int C);

	private:
		LinearSkinning *skin;
		int row_edit, col_edit;
		std::vector<int> m_selectedRows;
		int m_selectedCol;

		static void input_cb(fltk::Widget*, void* v);
		static void event_callback(fltk::Widget*, void *data);
		void event_callback2();
		void set_weight_value();
};

#endif
