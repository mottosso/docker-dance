/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "SkinningWindow.h"
#include "SkinTableWindow.h"

#include "dance.h"
#include "DObjectList.h"
#include "DObject.h"
#include "ViewManager.h"
#include "Link.h"

using namespace fltk;

SkinningWindow::SkinningWindow(LinearSkinning* s, int x, int y, int w, int h, const char* name)
	: ScrollGroup(x, y, w, h, name)
{
	int i;
	skin = s;

	this->begin();
	m_geoSelected = false;
	m_sysSelected = false;

	Group* groupSystem = new Group(5, 10, 210, 150, "Skinning System");
	groupSystem->box(fltk::BORDER_BOX);
	groupSystem->align(ALIGN_INSIDE_TOPLEFT);

	groupSystem->begin();
		allSystemList = new Choice(60, 20, 145, 20, "System:");
		allSystemList->callback(allSystemList_choice_cb, this);

		allGeoList = new Choice(60, 45, 145, 20, "Geometry:");
		allGeoList->callback(allGeoList_choice_cb, this);

		displayChoice = new Choice(75, 70, 130, 20, "Display Mode:");
		displayChoice->callback(displayChoice_choice_cb, this);
		displayChoice->value(0);
		displayChoice->deactivate();

		tableChoice = new Choice(75, 95, 130, 20, "Table Type:");
		tableChoice->callback(tableChoice_choice_cb, this);
		tableChoice->add("Complete Skin");
		tableChoice->add("Selected Skin");
		tableChoice->deactivate();

		skinPointSizeValue = new ValueInput(75, 120, 63, 20, "Point Size:");
		skinPointSizeValue->callback(skinPointSize_input_cb, this);
		skinPointSizeValue->deactivate();
		skinPointSizeValue->range(0.0, 36.0);
	groupSystem->end();

	Group* groupSkinOps = new Group(225, 10, 130, 150, "Skinning Operations");
	groupSkinOps->box(fltk::BORDER_BOX);
	groupSkinOps->align(ALIGN_INSIDE_TOPLEFT);

	groupSkinOps->begin();
		skinLoader = new Button(15, 19, 100, 17, "Load Skin");
		skinLoader->callback(skinLoader_button_cb, this);
		skinLoader->deactivate();

		skinSaver = new Button(15, 41, 100, 17, "Save Skin");
		skinSaver->callback(skinSaver_button_cb, this);
		skinSaver->deactivate();

		skinDetach = new Button(15, 63, 100, 17, "Detach Skin");
		skinDetach->callback(skinDetach_button_cb, this);
		skinDetach->deactivate();

		setBindingState = new Button(15, 85, 100, 17, "Set Binding State");
		setBindingState->callback(setBindingState_button_cb, this);
		setBindingState->deactivate();

		toBindingState = new Button(15, 107, 100, 17, "To Binding State");
		toBindingState->callback(toBindingState_button_cb, this);
		toBindingState->deactivate();

		automaticButton = new Button(15, 129, 100, 17, "Automatic map");
		automaticButton->callback(automaticAssign_cb, this);
		automaticButton->deactivate();
	groupSkinOps->end();

	Group* groupOperationMode = new Group(5, 170, 145, 105, "Operation Modes");
	groupOperationMode->box(fltk::BORDER_BOX);
	groupOperationMode->align(ALIGN_INSIDE_TOPLEFT);

	groupOperationMode->begin();
		cameraModeButton = new RadioButton(5, 20, 100, 15, "Default camera");
		cameraModeButton->callback(cameraModeButton_radio_button_cb, this);
		cameraModeButton->value(true);

		ellipseModeButton = new RadioButton(5, 40, 100, 15, "Select Ellipses");
		ellipseModeButton->callback(ellipseModeButton_radio_button_cb, this);
		ellipseModeButton->value(false);
		
		skinModeButton = new RadioButton(5, 60, 100, 15, "Select Skin");
		skinModeButton->callback(skinModeButton_radio_button_cb, this);
		skinModeButton->value(false);

		clearSelectedSkinButton = new Button(20, 80, 105, 20, "Clear Skin Selection");
		clearSelectedSkinButton->callback(clearSelectedSkinButton_button_cb, this);
		clearSelectedSkinButton->deactivate();
	groupOperationMode->end();

	Group* groupEllipseOp = new Group(160, 170, 195, 105, "Ellipsoid Operations");
	groupEllipseOp->box(fltk::BORDER_BOX);
	groupEllipseOp->align(ALIGN_INSIDE_TOPLEFT);

	groupEllipseOp->begin();
		ellipseCreator = new Button(5, 20, 90, 20, "Create Ellipse");
		ellipseCreator->callback(ellipseCreator_button_cb, this);
		ellipseCreator->deactivate();

		applyEllipse = new Button(5, 45, 90, 20, "Apply Ellipse");
		applyEllipse->callback(applyEllipse_button_cb, this);
		applyEllipse->deactivate();

		ellipseLoader = new Button(100, 20, 90, 20, "Load Ellipse");
		ellipseLoader->callback(ellipseLoader_button_cb, this);
		ellipseLoader->deactivate();

		ellipseSaver  = new Button(100, 45, 90, 20, "Save Ellipse");
		ellipseSaver->callback(ellipseSaver_button_cb, this);
		ellipseSaver->deactivate();

		ellipseFraction = new FloatInput(120, 75, 50, 20, "Small/Large Ratio:");
		ellipseFraction->callback(ellipseFraction_input_cb, this);
		ellipseFraction->type(FloatInput::FLOAT);
		ellipseFraction->deactivate();
	groupEllipseOp->end();

	Group* groupEllipseDisplay = new Group(5, 285, 350, 125, "Ellipsoid Display");
	groupEllipseDisplay->box(fltk::BORDER_BOX);
	groupEllipseDisplay->align(ALIGN_INSIDE_TOPLEFT);

	groupEllipseDisplay->begin();
		showAllEllipses = new CheckButton(250, 5, 100, 20, "Show All Ellipses");
		showAllEllipses->callback(showAllEllipses_check_button_cb, this);
		showAllEllipses->deactivate();

		hideEllipses = new CheckButton(250, 20, 100, 20, "Hide All Ellipses");
		hideEllipses->callback(hideEllipses_check_button_cb, this);
		hideEllipses->deactivate();

		Group* groupDisplayType = new Group(5, 45, 165, 75, "Display Type");
		groupDisplayType->box(fltk::BORDER_BOX);
		groupDisplayType->align(ALIGN_INSIDE_TOPLEFT);

		groupDisplayType->begin();
			ellipseTypeShowSmall = new RadioButton(5, 15, 100, 20, "Small Ellipse");
			ellipseTypeShowSmall->callback(ellipseTypeShowSmall_radio_button_cb, this);
			ellipseTypeShowSmall->deactivate();

			ellipseTypeShowLarge = new RadioButton(5, 35, 100, 20, "Large Ellipse");
			ellipseTypeShowLarge->callback(ellipseTypeShowLarge_radio_button_cb, this);
			ellipseTypeShowLarge->deactivate();

			ellipseTypeShowBoth = new RadioButton(5, 55, 100, 20, "Both Ellipses");
			ellipseTypeShowBoth->callback(ellipseTypeShowBoth_radio_button_cb, this);
			ellipseTypeShowBoth->deactivate();
		groupDisplayType->end();

		Group* groupShowType = new Group(180, 45, 165, 75, "Show Type");
		groupShowType->box(fltk::BORDER_BOX);
		groupShowType->align(ALIGN_INSIDE_TOPLEFT);

		groupShowType->begin();
			ellipseLookShowVertices = new RadioButton(5, 15, 100, 20, "Vertices");
			ellipseLookShowVertices->callback(ellipseLookShowVertices_radio_button_cb, this);
			ellipseLookShowVertices->deactivate();

			ellipseLookShowMesh = new RadioButton(5, 35, 100, 20, "Mesh");
			ellipseLookShowMesh->callback(ellipseLookShowMesh_radio_button_cb, this);
			ellipseLookShowMesh->deactivate();

			ellipseLookShowSolid = new RadioButton(5, 55, 100, 20, "Solid");
			ellipseLookShowSolid->callback(ellipseLookShowSolid_radio_button_cb, this);
		ellipseLookShowSolid->deactivate();
		groupShowType->end();
	groupEllipseDisplay->end();

	Group* groupEllipseMod = new Group(5, 420, 350, 160, "Ellipsoid Modification");
	groupEllipseMod->box(fltk::BORDER_BOX);
	groupEllipseMod->align(ALIGN_INSIDE_TOPLEFT);

	groupEllipseMod->begin();
		ellipseLinkChoice = new Choice(35, 20, 305, 20, "Link:");
		ellipseLinkChoice->callback(ellipseLinkChoice_choice_cb, this);
		ellipseLinkChoice->deactivate();

		Group* smallEllipse = new Group(5, 55, 165, 100, "Small Ellipse");
		smallEllipse->box(fltk::BORDER_BOX);
		smallEllipse->align(ALIGN_INSIDE_TOPLEFT);
		smallEllipse->begin();
			smallEllipseValue[0] = new FloatInput(21, 15, 64, 20, "x:");
			smallEllipseValue[0]->callback(smallEllipseValue_input_cb, this);
			smallEllipseValue[0]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
			smallEllipseValue[0]->type(FloatInput::FLOAT);
			smallEllipseValue[0]->value(0.0);
			smallEllipseValue[0]->deactivate();

			smallEllipseValue[1] = new FloatInput(21, 35, 64, 20, "y:");
			smallEllipseValue[1]->callback(smallEllipseValue_input_cb, this);
			smallEllipseValue[1]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
			smallEllipseValue[1]->type(FloatInput::FLOAT);
			smallEllipseValue[1]->value(0.0);
			smallEllipseValue[1]->deactivate();

			smallEllipseValue[2] = new FloatInput(21, 55, 64, 20, "z:");
			smallEllipseValue[2]->callback(smallEllipseValue_input_cb, this);
			smallEllipseValue[2]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
			smallEllipseValue[2]->type(FloatInput::FLOAT);
			smallEllipseValue[2]->value(0.0);
			smallEllipseValue[2]->deactivate();

			smallEllipseValue[3] = new FloatInput(21, 75, 64, 20, "all:");
			smallEllipseValue[3]->callback(smallEllipseValue_input_cb, this);
			smallEllipseValue[3]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
			smallEllipseValue[3]->type(FloatInput::FLOAT);
			smallEllipseValue[3]->value(0.0);
			smallEllipseValue[3]->deactivate();

			for(i = 0; i < 4; i++)
			{
				smallEllipseWeightWheel[i] = new ThumbWheel(93, 15 + 20 * i, 64, 20);
				smallEllipseWeightWheel[i]->callback(smallEllipseValue_wheel_cb, this);
				smallEllipseWeightWheel[i]->range(0, MAXFLOAT);
				smallEllipseWeightWheel[i]->value(0.0);
				smallEllipseWeightWheel[i]->deactivate();
			}
		smallEllipse->end();

		Group* largeEllipse = new Group(180, 55, 165, 100, "Large Ellipse");
		largeEllipse->box(fltk::BORDER_BOX);
		largeEllipse->align(ALIGN_INSIDE_TOPLEFT);
		largeEllipse->begin();
			largeEllipseValue[0] = new FloatInput(21, 15, 64, 20, "x:");
			largeEllipseValue[0]->callback(largeEllipseValue_input_cb, this);
			largeEllipseValue[0]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
			largeEllipseValue[0]->type(FloatInput::FLOAT);
			largeEllipseValue[0]->value(0.0);
			largeEllipseValue[0]->deactivate();

			largeEllipseValue[1] = new FloatInput(21, 35, 64, 20, "y:");
			largeEllipseValue[1]->callback(largeEllipseValue_input_cb, this);
			largeEllipseValue[1]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
			largeEllipseValue[1]->type(FloatInput::FLOAT);
			largeEllipseValue[1]->value(0.0);
			largeEllipseValue[1]->deactivate();

			largeEllipseValue[2] = new FloatInput(21, 55, 64, 20, "z:");
			largeEllipseValue[2]->callback(largeEllipseValue_input_cb, this);
			largeEllipseValue[2]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
			largeEllipseValue[2]->type(FloatInput::FLOAT);
			largeEllipseValue[2]->value(0.0);
			largeEllipseValue[2]->deactivate();

			largeEllipseValue[3] = new FloatInput(21, 75, 64, 20, "all:");
			largeEllipseValue[3]->callback(largeEllipseValue_input_cb, this);
			largeEllipseValue[3]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
			largeEllipseValue[3]->type(FloatInput::FLOAT);
			largeEllipseValue[3]->value(0.0);
			largeEllipseValue[3]->deactivate();

			for(i = 0; i < 4; i++)
			{
				largeEllipseWeightWheel[i] = new ThumbWheel(93, 15 + 20 * i, 64, 20);
				largeEllipseWeightWheel[i]->callback(largeEllipseValue_wheel_cb, this);
				largeEllipseWeightWheel[i]->range(0, MAXFLOAT);
				largeEllipseWeightWheel[i]->value(0.0);
				largeEllipseWeightWheel[i]->deactivate();
			}
		largeEllipse->end();
	groupEllipseMod->end();

	this->end();

	tableWindow = new SkinTableWindow(this, 50, 50, 730, 500, "Skin Table");
	tableWindow->hide();
	
	this->initSysGeoChoices();
	this->updateGUI();
}

void SkinningWindow::updateGUI()
{
	this->updateSkinWidgets();
	this->updateEllipseWidgets();
}

void SkinningWindow::updateSkinWidgets()
{
	if((m_sysSelected == true && m_geoSelected == true) || skin->m_skinLoaded == true)
		skinLoader->activate();
	else
        skinLoader->deactivate();

	if(skin->getSkin() != NULL && skin->getInfluence() != NULL)
	{
		allSystemList->clear();
		allSystemList->add("nothing");
		allSystemList->add(skin->m_influence->getName());
		allSystemList->value(1);
		allSystemList->deactivate();

		allGeoList->clear();
		allGeoList->add("nothing");
		allGeoList->add(skin->m_skin->getName());
		allGeoList->value(1);
		allGeoList->deactivate();
	}
	else if(allSystemList->active() == false && allGeoList->active() == false)
	{
		initSysGeoChoices();
		allSystemList->activate();
		allGeoList->activate();
	}

	if(skin->getSkin() == NULL)
	{
		skinSaver->deactivate();
		skinDetach->deactivate();
		setBindingState->deactivate();
		toBindingState->deactivate();

		// clear is called, then deactivate, then hide
		// hide must be called or else draw_cell will crash the system
		if (tableWindow->visible())
			tableWindow->hide();
		
		tableWindow->weightTable->deactivate();
		tableWindow->weightTable->hide();
		tableWindow->selectedTable->deactivate();
		tableWindow->selectedTable->hide();

		displayChoice->deactivate();

		tableChoice->value(0);
		tableChoice->deactivate();

		skinPointSizeValue->deactivate();

		if(allSystemList->active() == false && allGeoList->active() == false)
		{
			allSystemList->activate();
			allGeoList->activate();
			initSysGeoChoices();
		}

		automaticButton->deactivate();
	}
	else if(skin->getSkin() != NULL || (m_sysSelected == true && m_geoSelected == true) || skin->m_skinLoaded == true)
	{
		// Activate Skin Widgets
		// Activate Skinning System Widgets
		if(skin->m_skinAttached == true || skin->m_skinLoaded == true)
		{
			if(!displayChoice->active())
			{
				displayChoice->activate();
				setDisplayChoices();
				skin->setDisplayMode("normal");
				displayChoice->value(0);
			}
			if(!tableChoice->active())
			{
				tableChoice->activate();
				tableChoice->value(0);
			}
			if(!skinPointSizeValue->active())
			{
				skinPointSizeValue->activate();
				skinPointSizeValue->value(skin->m_vertexSize);
			}
			skinPointSizeValue->value(skin->m_vertexSize);
			if(skin->m_skinDisplayMode == LinearSkinning::SKIN_DISPLAY_NORMAL)
			{
				skinPointSizeValue->deactivate();
			}

			// Activate Skinning Operations Widgets
			skinSaver->activate();
			skinDetach->activate();
			setBindingState->activate();
			toBindingState->activate();
			automaticButton->activate();
		}

		// Update Operation Modes Widgets
		switch(skin->getSkinAppMode())
		{
			case LinearSkinning::MODE_ELLIPSE_SELECTION:
			{
				cameraModeButton->value(false);
				ellipseModeButton->value(true);
				skinModeButton->value(false);
				clearSelectedSkinButton->deactivate();
			}
			break;

			case LinearSkinning::MODE_SKIN_SELECTION:
			{
				cameraModeButton->value(false);
				ellipseModeButton->value(false);
				skinModeButton->value(true);
				clearSelectedSkinButton->activate();
				break;
			}

			case LinearSkinning::MODE_SKIN_VIEW:
			{
				cameraModeButton->value(true);
				ellipseModeButton->value(false);
				skinModeButton->value(false);
				clearSelectedSkinButton->deactivate();
				break;
			}
		}
	}
	else
	{
		// Deactivate Skin Widgets
		// Deactivate Skinning System Widgets
		displayChoice->deactivate();
		tableChoice->deactivate();
		skinPointSizeValue->deactivate();
	
		// Deactivate Skinning Operations Widgets
		skinSaver->deactivate();
		skinDetach->deactivate();
		setBindingState->deactivate();
		toBindingState->deactivate();
		automaticButton->deactivate();
	}
}
void SkinningWindow::updateEllipseWidgets()
{
	int i;
	float x, y, z;

	if(m_sysSelected == true || skin->m_ellipseLoaded == true || skin->m_skinLoaded == true)
	{
		ellipseCreator->activate();
		ellipseLoader->activate();

		if((m_geoSelected == true && skin->m_ellipse == true) || skin->m_ellipseLoaded == true)
			applyEllipse->activate();
	}
	else
	{
		ellipseCreator->deactivate();
		ellipseLoader->deactivate();
		applyEllipse->deactivate();
	}

	if(skin->m_ellipse == true)
		ellipseSaver->activate();
	else
		ellipseSaver->deactivate();

	// Update Ellipsoid Display widgets
	if(skin != NULL && skin->m_ellipse != NULL)
	{
		// Activate Ellipsoid Widgets
		// Activate Ellipsoid Operations
		ellipseFraction->activate();

		// Activate Ellipsoid Display
		showAllEllipses->activate();
		hideEllipses->activate();
		ellipseTypeShowSmall->activate();
		ellipseTypeShowLarge->activate();
		ellipseTypeShowBoth->activate();

		ellipseLookShowVertices->activate();
		ellipseLookShowMesh->activate();
		ellipseLookShowSolid->activate();

		// Activate Ellipsoid Modification
		if(!ellipseLinkChoice->active())
		{
			ellipseLinkChoice->activate();
			setEllipseLinkChoices();
		}
		for(i = 0; i < 4; i++)
		{
			smallEllipseValue[i]->activate();
			smallEllipseWeightWheel[i]->activate();
		}
		for(i = 0; i < 4; i++)
		{
			largeEllipseValue[i]->activate();
			largeEllipseWeightWheel[i]->activate();
		}

		// Update widget values
		// Update small/large ratio
		ellipseFraction->value(skin->getEllipseFraction());

		// Update Show All Ellipses check button
		if(skin->m_showingAllEllipses)
		{
			showAllEllipses->value(1);
		}
		else
		{
			showAllEllipses->value(0);
		}
		// Update Hide Ellipse check button
		if(skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_NEITHER)
		{
			hideEllipses->value(1);
		}
		else
		{
			hideEllipses->value(0);
		}

		// Update Type Show radio buttons
		if(skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_SMALL_ONLY)
		{
			ellipseTypeShowSmall->value(1);
			ellipseTypeShowLarge->value(0);
			ellipseTypeShowBoth->value(0);
		}
		else if(skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_LARGE_ONLY)
		{
			ellipseTypeShowSmall->value(0);
			ellipseTypeShowLarge->value(1);
			ellipseTypeShowBoth->value(0);
		}
		else if(skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_BOTH)
		{
			ellipseTypeShowSmall->value(0);
			ellipseTypeShowLarge->value(0);
			ellipseTypeShowBoth->value(1);
		}
		else
		{
			ellipseTypeShowSmall->value(0);
			ellipseTypeShowLarge->value(0);
			ellipseTypeShowBoth->value(0);
		}

		// Update Look Show radio buttons
		if(skin->getEllipseLookShow() == LinearSkinning::ELLIPSE_DISPLAY_VERTICES)
		{
			ellipseLookShowVertices->value(1);
			ellipseLookShowMesh->value(0);
			ellipseLookShowSolid->value(0);
		}
		else if(skin->getEllipseLookShow() == LinearSkinning::ELLIPSE_DISPLAY_MESH)
		{
			ellipseLookShowVertices->value(0);
			ellipseLookShowMesh->value(1);
			ellipseLookShowSolid->value(0);
		}
		else if(skin->getEllipseLookShow() == LinearSkinning::ELLIPSE_DISPLAY_SOLID)
		{
			ellipseLookShowVertices->value(0);
			ellipseLookShowMesh->value(0);
			ellipseLookShowSolid->value(1);
		}
		else
		{
			ellipseLookShowVertices->value(0);
			ellipseLookShowMesh->value(0);
			ellipseLookShowSolid->value(0);
		}

		// Update Modify buttons
		ellipseLinkChoice->value(skin->getShowOneEllipse() + 1);

		skin->getEllipseAttrib(LinearSkinning::ELLIPSE_SMALL_ONLY, skin->getShowOneEllipse(), &x, &y, &z);
		smallEllipseValue[0]->value(x);
		smallEllipseValue[1]->value(y);
		smallEllipseValue[2]->value(z);
		smallEllipseWeightWheel[0]->value(x);
		smallEllipseWeightWheel[1]->value(y);
		smallEllipseWeightWheel[2]->value(z);
		if(x >= y && x >= z)
		{
			smallEllipseValue[3]->value(x);
			smallEllipseWeightWheel[3]->value(x);
		}
		else if(y >= x && y >= z)
		{
			smallEllipseValue[3]->value(y);
			smallEllipseWeightWheel[3]->value(y);
		}
		else
		{
			smallEllipseValue[3]->value(z);
			smallEllipseWeightWheel[3]->value(z);
		}

		skin->getEllipseAttrib(LinearSkinning::ELLIPSE_LARGE_ONLY, skin->getShowOneEllipse(), &x, &y, &z);
		largeEllipseValue[0]->value(x);
		largeEllipseValue[1]->value(y);
		largeEllipseValue[2]->value(z);
		largeEllipseWeightWheel[0]->value(x);
		largeEllipseWeightWheel[1]->value(y);
		largeEllipseWeightWheel[2]->value(z);
		if(x >= y && x >= z)
		{
			largeEllipseValue[3]->value(x);
			largeEllipseWeightWheel[3]->value(x);
		}
		else if(y >= x && y >= z)
		{
			largeEllipseValue[3]->value(y);
			largeEllipseWeightWheel[3]->value(y);
		}
		else
		{
			largeEllipseValue[3]->value(z);
			largeEllipseWeightWheel[3]->value(z);
		}
	}
	else
	{
		// Deactivate Ellipsoid Widgets
		// Deactivate Ellipsoid Operations
		ellipseFraction->deactivate();

		// Deactivate Ellipsoid Display
		showAllEllipses->deactivate();
		hideEllipses->deactivate();
		ellipseTypeShowSmall->deactivate();
		ellipseTypeShowLarge->deactivate();
		ellipseTypeShowBoth->deactivate();

		ellipseLookShowVertices->deactivate();
		ellipseLookShowMesh->deactivate();
		ellipseLookShowSolid->deactivate();

		// Deactivate Ellipsoid Modification
		ellipseLinkChoice->deactivate();

		for(i = 0; i < 4; i++)
		{
			smallEllipseValue[i]->deactivate();
			smallEllipseWeightWheel[i]->deactivate();
		}
		for(i = 0; i < 4; i++)
		{
			largeEllipseValue[i]->deactivate();
			largeEllipseWeightWheel[i]->deactivate();
		}
	}
}
void SkinningWindow::show()
{
	this->updateGUI();
	ScrollGroup::show();
}
void SkinningWindow::initSysGeoChoices()
{
	int selected = 0;

	allSystemList->clear();
	allSystemList->add("Choose a system");
	
	for (int i = 0; i < dance::AllSystems->size(); i++)
	{
		DObject* obj = dance::AllSystems->get(i);
		const char* sysName = obj->getName();
		allSystemList->add(sysName);
		if (this->skin->getInfluence() == obj)
			selected = i + 1;
	}
	allSystemList->value(selected);

	allGeoList->clear();
	selected = 0;
	allGeoList->add("Choose a geometry");
	for (int i = 0; i < dance::AllGeometry->size(); i++)
	{
		DObject* obj = dance::AllGeometry->get(i);
		const char* sysName = obj->getName();
		allGeoList->add(sysName);
		if (this->skin->getSkin() == obj)
			selected = i + 1;
	}
	allGeoList->value(selected);
}


void SkinningWindow::setDisplayChoices()
{
	char labelA[128];
	char labelB[128];

	if (skin == NULL)
	{
		return;
	}

	displayChoice->clear();
	displayChoice->add("Normal");
	displayChoice->add("Unassigned skin");

	strcpy (labelA, "Skinmap ");

	Link **links = skin->m_influence->getLinks();
	int numLinks = skin->m_influence->m_numLinks;

	for (int l = 0; l < numLinks; l++)
	{
		strcpy (labelB, labelA);
		strcat (labelB, links[l]->getName());

		displayChoice->add(labelB);
	}
}

void SkinningWindow::setEllipseLinkChoices()
{
	char label[128];

	if ((skin == NULL) || (skin->m_influence == NULL))
	{
		return;
	}

	ellipseLinkChoice->clear();
	ellipseLinkChoice->add("All");

	Link **links = skin->m_influence->getLinks();
	int numLinks = skin->m_influence->m_numLinks;

	for (int l = 0; l < numLinks; l++)
	{
		strcpy (label, links[l]->getName());
		ellipseLinkChoice->add(label);
	}

	ellipseLinkChoice->value(skin->getShowOneEllipse() + 1);
	skin->setEllipseDisplayMode(skin->getEllipseTypeShow(), skin->getEllipseLookShow(), skin->getShowOneEllipse());
}

void SkinningWindow::allSystemList_choice_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	const char* sysName = sWin->allSystemList->child(sWin->allSystemList->value())->label();

	if(sWin->skin != NULL)
	{
		if(strcmp(sysName, "Choose a system") == 0)
		{
			sWin->m_sysSelected = false;
			sWin->skin->unassignFromSystem();
		}
		else
		{
			sWin->m_sysSelected = true;
			sWin->skin->assignToSystem((char *) sysName);
		}
	}

	sWin->updateGUI();
}

void SkinningWindow::allGeoList_choice_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	int geoValue = sWin->allGeoList->value();

	// if an actual geo was picked
	if(geoValue != 0)
	{
		sWin->m_geoSelected = true;
	}
	else
	{
		sWin->m_geoSelected = false;
	}

	sWin->updateGUI();
}

void SkinningWindow::displayChoice_choice_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;
	//int item = sWin->displayChoice->value();
	const char * item = sWin->displayChoice->child(sWin->displayChoice->value())->label();
	char string[128];

	if ((strcmp (item, "Normal")) == 0)
	{
		sWin->skin->setDisplayMode("normal");
	}
	else if ((strcmp (item, "Unassigned skin")) == 0)
	{
		sWin->skin->setDisplayMode("unassignedSkin");
	}
	else
	{
		strcpy (string, item);
		strncpy (string, "mapskin", 7);
		sWin->skin->setDisplayMode(string);
	}

	/*
	int s;
	int l;
	int numLinks = sWin->skin->m_influence->m_numLinks;
	item -= 2;
	s = item / numLinks;
	l = item - (s * numLinks);
	*/

	if (sWin->tableWindow->visible())
		sWin->tableWindow->redraw();

	sWin->updateGUI();
}

void SkinningWindow::tableChoice_choice_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;
	int type;

	if(sWin->skin != NULL)
	{
		type = sWin->tableChoice->value();

		switch(type)
		{
			case 0:
				sWin->tableWindow->show();
				sWin->tableWindow->setTableType(SkinTableWindow::COMPLETE_TABLE);
				sWin->tableWindow->updateGUI();
				break;

			case 1:
				sWin->tableWindow->show();
				sWin->tableWindow->setTableType(SkinTableWindow::PICKED_TABLE);
				sWin->tableWindow->updateGUI();
				break;

			default:
				break;
		}
	}

	sWin->updateGUI();
}

void SkinningWindow::skinPointSize_input_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	sWin->skin->m_vertexSize = sWin->skinPointSizeValue->value();

	sWin->updateGUI();
}

void SkinningWindow::skinLoader_button_cb(fltk::Widget* o, void* p)
{ 
	SkinningWindow* sWin = (SkinningWindow*) p;
	const char *filename = fltk::file_chooser("Load Skin",
					"*.skin",
					NULL,
					true);

	if (filename == NULL)
		return;

	int length = strlen(filename);

	if (length > 5)
	{
		if (strncmp((const char*) (filename + length - 5), ".skin", 5) != 0)
		{
			fltk::message("Invalid filename.  Must have '.skin' extension.");
			return;
		}
	}
	else
	{
		fltk::message("Invalid filename.  Must have '.skin' extension.");
		return;
	}

	int skinChoice = sWin->allGeoList->value();

	if (skinChoice == 0)
		return;
	
	const char* skinName = sWin->allGeoList->child(skinChoice)->label();

	if (sWin->skin != NULL)
	{
		if (sWin->skin->loadSkin((char*) filename, (char *) skinName) == false)
		{
			fltk::message("An error occured while loading the skin file %s", filename);
			return;
		}
	}

	if (sWin->tableWindow->visible())
		sWin->tableWindow->redraw();

	sWin->updateGUI();
}

void SkinningWindow::skinSaver_button_cb(fltk::Widget* o, void* p)
{ 
	SkinningWindow* sWin = (SkinningWindow*) p;
	const char *filename = fltk::file_chooser("Save Skin",
					"*.skin",
					NULL,
					true);

	if (filename == NULL)
		return;

	int length = strlen(filename);
	
	if (length > 5)
	{
		if (strncmp((const char*) (filename + length - 5), ".skin", 5) != 0)
		{
			fltk::message("Invalid filename.  Must have '.skin' extension.");
			return;
		}
	}
	else
	{
		fltk::message("Invalid filename.  Must have '.skin' extension.");
		return;
	}

	char *ellFilename = new char[length];
	strcpy(ellFilename, filename);

	ellFilename[length - 1] = '\0';
	ellFilename[length - 2] = 'l';
	ellFilename[length - 3] = 'l';
	ellFilename[length - 4] = 'e';

	if (sWin->skin->m_ellipse)
	{
		sWin->skin->saveEllipse(ellFilename);
	}

	if (sWin->skin != NULL)
	{
		sWin->skin->saveSkin((char*) filename);
	}

	sWin->updateGUI();
}

void SkinningWindow::skinDetach_button_cb(fltk::Widget* o, void* p)
{ 
	SkinningWindow* sWin = (SkinningWindow*) p;

	sWin->skin->m_skinAttached = false;

	if(sWin->skin != NULL)
	{
		sWin->skin->detachSkin();
		sWin->skin->m_skinAttached = false;
	}

	sWin->updateGUI();
}

void SkinningWindow::setBindingState_button_cb(fltk::Widget* o, void* p)
{ 
	SkinningWindow* sWin = (SkinningWindow*) p;

	sWin->skin->setBindingPoseState();
}

void SkinningWindow::toBindingState_button_cb(fltk::Widget* o, void* p)
{ 
	SkinningWindow* sWin = (SkinningWindow*) p;

	if(sWin->skin != NULL)
	{
		sWin->skin->toBindingPoseState();
		dance::AllViews->postRedisplay();
	}

	sWin->updateGUI();
}

void SkinningWindow::automaticAssign_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	if(sWin->skin != NULL)
	{
		sWin->skin->assignSkinAutomatically();
		
		if (sWin->tableWindow->visible())
			sWin->tableWindow->redraw();
	}

	sWin->updateGUI();
}


void SkinningWindow::cameraModeButton_radio_button_cb(fltk::Widget* o, void *p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;
	
	if (sWin->skin != NULL)
	{
		sWin->skin->setSkinAppMode(LinearSkinning::MODE_SKIN_VIEW);
		sWin->clearSelectedSkinButton->deactivate();
		danceInterp::OutputMessage("Entering camera mode...\n");
		dance::removeInteraction(sWin->skin);
	}

	sWin->updateGUI();
}

void SkinningWindow::ellipseModeButton_radio_button_cb(fltk::Widget* o, void *p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;
	
	if (sWin->skin != NULL)
	{
		sWin->skin->setSkinAppMode(LinearSkinning::MODE_ELLIPSE_SELECTION);
		sWin->clearSelectedSkinButton->deactivate();
		danceInterp::OutputMessage("Entering ellipse selection mode...\n");
		dance::addInteraction(sWin->skin);
	}

	sWin->updateGUI();
}

void SkinningWindow::skinModeButton_radio_button_cb(fltk::Widget* o, void *p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;
	
	if (sWin->skin != NULL)
	{
		sWin->skin->setSkinAppMode(LinearSkinning::MODE_SKIN_SELECTION);
		sWin->clearSelectedSkinButton->activate();
		danceInterp::OutputMessage("Entering skin selection mode...\n");
		dance::addInteraction(sWin->skin);
	}

	sWin->updateGUI();
}

void SkinningWindow::clearSelectedSkinButton_button_cb(fltk::Widget* o, void *p)
{
	SkinningWindow* sWin = (SkinningWindow*)p;

	if (sWin->skin != NULL)
	{
		sWin->tableWindow->clearSelectedVertices();
		sWin->skin->clearSkinSelection();
		dance::AllViews->postRedisplay();
	}

	sWin->updateGUI();
}


void SkinningWindow::applyEllipse_button_cb(fltk::Widget* o, void* p)
{ 
	SkinningWindow* sWin = (SkinningWindow*) p;

	int skinChoice = sWin->allGeoList->value();

	if (skinChoice == 0)
		return;
	
	const char* skinName = sWin->allGeoList->child(skinChoice)->label();

	if (sWin->skin != NULL)
	{
		if (sWin->skin->m_skin)
		{
			fltk::message("The previous skin assignments will be completely overwritten.");
		}

		if(sWin->skin->attachSkinViaEllipses((char *) skinName) == false)
			return;
		else
			sWin->skin->m_skinAttached = true;
	}

	if (sWin->tableWindow->visible())
		sWin->tableWindow->redraw();

	sWin->updateGUI();
}

void SkinningWindow::ellipseCreator_button_cb(fltk::Widget* o, void* p)
{ 
	SkinningWindow* sWin = (SkinningWindow*) p;

	if (sWin->skin != NULL)
	{
		if(sWin->skin->createEllipse() == false)
			return;
	}

	sWin->updateGUI();
}

void SkinningWindow::ellipseLoader_button_cb(fltk::Widget* o, void* p)
{ 
	SkinningWindow* sWin = (SkinningWindow*) p;
	const char *filename = fltk::file_chooser("Load Ellipse",
					"*.ell",
					NULL,
					true);

	if (filename == NULL)
		return;
		
	if (sWin->skin != NULL)
	{
		if (sWin->skin->loadEllipse((char*) filename) == false)
			return;
	}

	sWin->updateGUI();
}

void SkinningWindow::ellipseSaver_button_cb(fltk::Widget* o, void* p)
{ 
	SkinningWindow* sWin = (SkinningWindow*) p;
	const char *filename = fltk::file_chooser("Save Ellipse",
					"*.ell",
					NULL,
					true);

	if (filename == NULL)
		return;

	if (sWin->skin != NULL)
	{
		sWin->skin->saveEllipse((char*) filename);
	}

	sWin->updateGUI();
}

void SkinningWindow::ellipseFraction_input_cb(fltk::Widget* o, void* p)
{	
	SkinningWindow* sWin = (SkinningWindow*) p;

	if(sWin->skin != NULL)
	{
		float new_fraction = (float)sWin->ellipseFraction->fvalue();
		if ((new_fraction >= 0) && (new_fraction <= 1))
		{
			sWin->skin->setEllipseFraction(new_fraction);
		}
		else
		{
			sWin->ellipseFraction->value(sWin->skin->getEllipseFraction());
		}
	}

	sWin->updateGUI();
}


void SkinningWindow::showAllEllipses_check_button_cb(fltk::Widget* o, void *p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	if(sWin->skin != NULL)
	{
		if(sWin->skin->m_showingAllEllipses == true)
			sWin->skin->m_showingAllEllipses = false;
		else
			sWin->skin->m_showingAllEllipses = true;
	}

	sWin->updateGUI();
}

void SkinningWindow::hideEllipses_check_button_cb(fltk::Widget* o, void *p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	// Make sure ellipses are not already hidden
	if(sWin->skin != NULL)
	{
		// Hide is being unchecked
		if(sWin->skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_NEITHER)
		{
			sWin->skin->setEllipseDisplayMode(sWin->skin->m_savedType, sWin->skin->m_savedLook, sWin->skin->m_savedLink);
		}
		else // Hide is being checked
		{
			sWin->skin->m_savedType = sWin->skin->getEllipseTypeShow();
			sWin->skin->m_savedLook = sWin->skin->getEllipseLookShow();
			sWin->skin->m_savedLink = sWin->skin->getShowOneEllipse();

			sWin->skin->setEllipseDisplayMode(LinearSkinning::ELLIPSE_NEITHER, sWin->skin->getEllipseLookShow(), sWin->skin->getShowOneEllipse());
		}
	}

	sWin->updateGUI();
}

void SkinningWindow::ellipseTypeShowSmall_radio_button_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	if(sWin->skin != NULL)
	{
		sWin->skin->setEllipseDisplayMode(LinearSkinning::ELLIPSE_SMALL_ONLY, sWin->skin->getEllipseLookShow(), sWin->skin->getShowOneEllipse());
	}

	sWin->updateGUI();
}
void SkinningWindow::ellipseTypeShowLarge_radio_button_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	if(sWin->skin != NULL)
	{
		sWin->skin->setEllipseDisplayMode(LinearSkinning::ELLIPSE_LARGE_ONLY, sWin->skin->getEllipseLookShow(), sWin->skin->getShowOneEllipse());
	}

	sWin->updateGUI();
}
void SkinningWindow::ellipseTypeShowBoth_radio_button_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	if(sWin->skin != NULL)
	{
		sWin->skin->setEllipseDisplayMode(LinearSkinning::ELLIPSE_BOTH, sWin->skin->getEllipseLookShow(), sWin->skin->getShowOneEllipse());
	}

	sWin->updateGUI();
}

void SkinningWindow::ellipseLookShowVertices_radio_button_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	if(sWin->skin != NULL)
	{
		sWin->skin->setEllipseDisplayMode(sWin->skin->getEllipseTypeShow(), LinearSkinning::ELLIPSE_DISPLAY_VERTICES, sWin->skin->getShowOneEllipse());
	}

	sWin->updateGUI();
}
void SkinningWindow::ellipseLookShowMesh_radio_button_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	if(sWin->skin != NULL)
	{
		sWin->skin->setEllipseDisplayMode(sWin->skin->getEllipseTypeShow(), LinearSkinning::ELLIPSE_DISPLAY_MESH, sWin->skin->getShowOneEllipse());
	}

	sWin->updateGUI();
}
void SkinningWindow::ellipseLookShowSolid_radio_button_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	if(sWin->skin != NULL)
	{
		sWin->skin->setEllipseDisplayMode(sWin->skin->getEllipseTypeShow(), LinearSkinning::ELLIPSE_DISPLAY_SOLID, sWin->skin->getShowOneEllipse());
	}

	sWin->updateGUI();
}


void SkinningWindow::ellipseLinkChoice_choice_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;
	int type, look, link;

	if(sWin->skin != NULL)
	{
		type = sWin->skin->getEllipseTypeShow();
		look = sWin->skin->getEllipseLookShow();
		link = (sWin->ellipseLinkChoice->value() - 1);

		sWin->skin->setEllipseDisplayMode(type, look, link);
	}

	sWin->updateGUI();
}

void SkinningWindow::smallEllipseValue_input_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	if(o != sWin->smallEllipseValue[3])
	{
		sWin->skin->setEllipse(LinearSkinning::ELLIPSE_SMALL_ONLY, sWin->skin->getShowOneEllipse(),
							   sWin->smallEllipseValue[0]->fvalue(), sWin->smallEllipseValue[1]->fvalue(), sWin->smallEllipseValue[2]->fvalue());
	}
	else
	{
		sWin->skin->setEllipse(LinearSkinning::ELLIPSE_SMALL_ONLY, sWin->skin->getShowOneEllipse(),
							   sWin->smallEllipseValue[3]->fvalue(), sWin->smallEllipseValue[3]->fvalue(), sWin->smallEllipseValue[3]->fvalue());
	}

	if(sWin->skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_NEITHER || sWin->skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_LARGE_ONLY)
		sWin->skin->setEllipseDisplayMode(LinearSkinning::ELLIPSE_SMALL_ONLY, sWin->skin->getEllipseLookShow(), sWin->skin->getShowOneEllipse());
	else
		sWin->skin->setEllipseDisplayMode(sWin->skin->getEllipseTypeShow(), sWin->skin->getEllipseLookShow(), sWin->skin->getShowOneEllipse());

	sWin->updateGUI();
}

void SkinningWindow::smallEllipseValue_wheel_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;
	int link;

	if (sWin->skin != NULL)
	{
		link = sWin->skin->getShowOneEllipse();

		if(link == -1)
		{
			if(o == sWin->smallEllipseWeightWheel[0])
			{
				sWin->skin->setAllEllipse(LinearSkinning::ELLIPSE_SMALL_ONLY, sWin->smallEllipseWeightWheel[0]->value(), -1.0, -1.0);
			}
			else if(o == sWin->smallEllipseWeightWheel[1])
			{
				sWin->skin->setAllEllipse(LinearSkinning::ELLIPSE_SMALL_ONLY, -1.0, sWin->smallEllipseWeightWheel[1]->value(), -1.0);
			}
			else if(o == sWin->smallEllipseWeightWheel[2])
			{
				sWin->skin->setAllEllipse(LinearSkinning::ELLIPSE_SMALL_ONLY, -1.0, -1.0, sWin->smallEllipseWeightWheel[2]->value());
			}
			else if(o == sWin->smallEllipseWeightWheel[3])
			{
				sWin->skin->setAllEllipse(LinearSkinning::ELLIPSE_SMALL_ONLY, sWin->smallEllipseWeightWheel[3]->value(), 
										  sWin->smallEllipseWeightWheel[3]->value(), sWin->smallEllipseWeightWheel[3]->value());
			}
		}
		else
		{
			if(o == sWin->smallEllipseWeightWheel[0])
			{
				sWin->skin->setEllipse(LinearSkinning::ELLIPSE_SMALL_ONLY, link, sWin->smallEllipseWeightWheel[0]->value(), -1.0, -1.0);
			}
			else if(o == sWin->smallEllipseWeightWheel[1])
			{
				sWin->skin->setEllipse(LinearSkinning::ELLIPSE_SMALL_ONLY, link, -1.0, sWin->smallEllipseWeightWheel[1]->value(), -1.0);
			}
			else if(o == sWin->smallEllipseWeightWheel[2])
			{
				sWin->skin->setEllipse(LinearSkinning::ELLIPSE_SMALL_ONLY, link, -1.0, -1.0, sWin->smallEllipseWeightWheel[2]->value());
			}
			else if(o == sWin->smallEllipseWeightWheel[3])
			{
				sWin->skin->setEllipse(LinearSkinning::ELLIPSE_SMALL_ONLY, link, sWin->smallEllipseWeightWheel[3]->value(), 
									   sWin->smallEllipseWeightWheel[3]->value(), sWin->smallEllipseWeightWheel[3]->value());
			}
		}
	}

	if(sWin->skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_NEITHER || sWin->skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_LARGE_ONLY)
		sWin->skin->setEllipseDisplayMode(LinearSkinning::ELLIPSE_SMALL_ONLY, sWin->skin->getEllipseLookShow(), sWin->skin->getShowOneEllipse());
	else
		sWin->skin->setEllipseDisplayMode(sWin->skin->getEllipseTypeShow(), sWin->skin->getEllipseLookShow(), sWin->skin->getShowOneEllipse());

	sWin->updateGUI();
}

void SkinningWindow::largeEllipseValue_input_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;

	if(o != sWin->largeEllipseValue[3])
	{
		sWin->skin->setEllipse(LinearSkinning::ELLIPSE_LARGE_ONLY, sWin->skin->getShowOneEllipse(),
							   sWin->largeEllipseValue[0]->fvalue(), sWin->largeEllipseValue[1]->fvalue(), sWin->largeEllipseValue[2]->fvalue());
	}
	else
	{
		sWin->skin->setEllipse(LinearSkinning::ELLIPSE_LARGE_ONLY, sWin->skin->getShowOneEllipse(),
							   sWin->largeEllipseValue[3]->fvalue(), sWin->largeEllipseValue[3]->fvalue(), sWin->largeEllipseValue[3]->fvalue());
	}

	if(sWin->skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_NEITHER || sWin->skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_SMALL_ONLY)
		sWin->skin->setEllipseDisplayMode(LinearSkinning::ELLIPSE_LARGE_ONLY, sWin->skin->getEllipseLookShow(), sWin->skin->getShowOneEllipse());
	else
		sWin->skin->setEllipseDisplayMode(sWin->skin->getEllipseTypeShow(), sWin->skin->getEllipseLookShow(), sWin->skin->getShowOneEllipse());

	sWin->updateGUI();
}

void SkinningWindow::largeEllipseValue_wheel_cb(fltk::Widget* o, void* p)
{
	SkinningWindow* sWin = (SkinningWindow*) p;
	int link;

	if (sWin->skin != NULL)
	{
		link = sWin->skin->getShowOneEllipse();

		if(link == -1)
		{
			if(o == sWin->largeEllipseWeightWheel[0])
			{
				sWin->skin->setAllEllipse(LinearSkinning::ELLIPSE_LARGE_ONLY, sWin->largeEllipseWeightWheel[0]->value(), -1.0, -1.0);
			}
			else if(o == sWin->largeEllipseWeightWheel[1])
			{
				sWin->skin->setAllEllipse(LinearSkinning::ELLIPSE_LARGE_ONLY, -1.0, sWin->largeEllipseWeightWheel[1]->value(), -1.0);
			}
			else if(o == sWin->largeEllipseWeightWheel[2])
			{
				sWin->skin->setAllEllipse(LinearSkinning::ELLIPSE_LARGE_ONLY, -1.0, -1.0, sWin->largeEllipseWeightWheel[2]->value());
			}
			else if(o == sWin->largeEllipseWeightWheel[3])
			{
				sWin->skin->setAllEllipse(LinearSkinning::ELLIPSE_LARGE_ONLY, sWin->largeEllipseWeightWheel[3]->value(), 
										  sWin->largeEllipseWeightWheel[3]->value(), sWin->largeEllipseWeightWheel[3]->value());
			}
		}
		else
		{
			if(o == sWin->largeEllipseWeightWheel[0])
			{
				sWin->skin->setEllipse(LinearSkinning::ELLIPSE_LARGE_ONLY, link, sWin->largeEllipseWeightWheel[0]->value(), -1.0, -1.0);
			}
			else if(o == sWin->largeEllipseWeightWheel[1])
			{
				sWin->skin->setEllipse(LinearSkinning::ELLIPSE_LARGE_ONLY, link, -1.0, sWin->largeEllipseWeightWheel[1]->value(), -1.0);
			}
			else if(o == sWin->largeEllipseWeightWheel[2])
			{
				sWin->skin->setEllipse(LinearSkinning::ELLIPSE_LARGE_ONLY, link, -1.0, -1.0, sWin->largeEllipseWeightWheel[2]->value());
			}
			else if(o == sWin->largeEllipseWeightWheel[3])
			{
				sWin->skin->setEllipse(LinearSkinning::ELLIPSE_LARGE_ONLY, link, sWin->largeEllipseWeightWheel[3]->value(), 
									   sWin->largeEllipseWeightWheel[3]->value(), sWin->largeEllipseWeightWheel[3]->value());
			}
		}
	}

	if(sWin->skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_NEITHER || sWin->skin->getEllipseTypeShow() == LinearSkinning::ELLIPSE_SMALL_ONLY)
		sWin->skin->setEllipseDisplayMode(LinearSkinning::ELLIPSE_LARGE_ONLY, sWin->skin->getEllipseLookShow(), sWin->skin->getShowOneEllipse());
	else
		sWin->skin->setEllipseDisplayMode(sWin->skin->getEllipseTypeShow(), sWin->skin->getEllipseLookShow(), sWin->skin->getShowOneEllipse());

	sWin->updateGUI();
}
