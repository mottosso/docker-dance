/**************************************************

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:

	Copyright 2005 by Ari Shapiro and Petros Faloutsos
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include <ctype.h>
#include "defs.h"
#include "dance.h"
#include "danceInterp.h"
#include "GLutilities.h"
#include "DSystem.h"
#include "LinearSkinning.h"
#include "ViewManager.h"
#include "DView.h"
#include "DSimulator.h"
#include "LinkStack.h"
#include "Link.h"
#include "Joint.h"
#include "SkinningWindow.h"
#include "SkinTableWindow.h"
#include <vector>

#define MAX(a, b) (((a) > (b)) ? (a) : (b))

#ifdef macintosh
#ifdef __cplusplus
extern "C" {
#endif
#include <assert.h>
#ifdef __cplusplus
}
#endif
#else
#include <assert.h>
#endif

using namespace std;
using namespace fltk;

//static char Sep[2] = {(char) 32, '\t'} ;
//static int SelectedItem = -1 ;



PlugIn *
Proxy() { return (new LinearSkinning) ;}

PlugIn *LinearSkinning::create(int argc, char **argv)
{
    LinearSkinning *f = new LinearSkinning;

    if(f == NULL)
    {
		danceInterp::OutputMessage("Cannot allocate memory!\n");
		return NULL;
    }

    return f;
}

void LinearSkinning::setName(const char* name)
{
	danceInterp::OutputMessage("Setting name to '%s'\n", name);
	DObject* d = (DObject*) this;
	d->setName(name);
}


LinearSkinning::LinearSkinning()
{
	LinSkinAppMode = this->MODE_SKIN_VIEW;
    	setName("DummyLinearSkinning");
	m_prevWinX = 0;
	m_prevWinY = 0;
	m_vertexSize = 1;

	m_influence = NULL;
	m_skin = NULL;

	m_selectedEllipse = -1;
	m_selectedEllipseType = -1;
	m_selectedEllipseAxis = -1;
	m_showOneEllipse = -1;

	m_ellipseFraction = 0.95f;
	m_showLinkSkinMappings = 0;

	m_skinVertices = NULL;
	m_originalVertCoord = NULL;
	m_bindingPoseState = NULL;
	m_currentState = NULL;

	m_showSkin = true;

	m_ellipse = false;
	m_skinAttached = false;
	m_skinLoaded = false;
	m_ellipseLoaded = false;
	m_showSmallEllipse = false;
	m_showLargeEllipse = false;
	m_showingAllEllipses = false;
	m_ellipseTypeShow = LinearSkinning::ELLIPSE_BOTH;
	m_ellipseLookShow = LinearSkinning::ELLIPSE_DISPLAY_MESH;
	m_skinDisplayMode = this->SKIN_DISPLAY_NORMAL;
	m_showDragBox = false;

	m_savedType = m_savedLook = m_savedLink = -1;
	m_boxX1 = m_boxY1 = m_boxX2 = m_boxY2 = 0;

	m_skinWindow = NULL;
}

LinearSkinning::~LinearSkinning()
{
	if (m_skinVertices != NULL)
		delete []m_skinVertices;

	if (m_originalVertCoord != NULL)
		delete []m_originalVertCoord;

	if (m_bindingPoseState != NULL)
		delete [] m_bindingPoseState;

	if(m_currentState != NULL)
		delete [] m_currentState;
}

void LinearSkinning::modify()
{
	this->adjustSkin();
	return;
}

// display:
//	Displays the skin object.
//
void LinearSkinning::output(int mode)
{
	glPushAttrib(GL_ENABLE_BIT);
	glEnable(GL_LIGHTING);

	// show the skins
	if (m_showSkin && (m_skin != NULL))
	{
		if (m_skinDisplayMode == this->SKIN_DISPLAY_UNASSIGNED)
		{
			displayUnassignedSkin(GL_RENDER);
		}
		else if (m_skinDisplayMode == this->SKIN_DISPLAY_MAPPED)
		{
			displayLinkSkinMap();
		}
	}

	// draw the ellipses
	if (m_showSmallEllipse && m_ellipse && m_influence != NULL)
	{
		int numLinks = m_influence->m_numLinks;

		if (m_showOneEllipse == -1 || m_showingAllEllipses == true)
		{
			for (int l = 0; l < numLinks; l++)
			{
				Link* link = m_influence->getLink(l);
				double WTransMatrix[4][4];
				link->getWTransMat(WTransMatrix);
				float a, b, c;
				a = m_smallEllipseAttr[(3 * l)];
				b = m_smallEllipseAttr[(3 * l) + 1];
				c = m_smallEllipseAttr[(3 * l) + 2];

				if (m_selectedEllipse == l)
					drawEllipse(ELLIPSE_SELECTED, a, b, c, WTransMatrix);
				else
					drawEllipse(ELLIPSE_SMALL_ONLY, a, b, c, WTransMatrix);
			}
		}
		else		// only show one ellipse
		{
			// m_showOneEllipse is the link of the ellipse to be shown
			int l = m_showOneEllipse;

			Link* link = m_influence->getLink(l);
			double WTransMatrix[4][4];
			link->getWTransMat(WTransMatrix);
			float a, b, c;
			a = m_smallEllipseAttr[(3 * l)];
			b = m_smallEllipseAttr[(3 * l) + 1];
			c = m_smallEllipseAttr[(3 * l) + 2];

			if (m_selectedEllipse == l)
				drawEllipse(ELLIPSE_SELECTED, a, b, c, WTransMatrix);
			else
				drawEllipse(ELLIPSE_SMALL_ONLY, a, b, c, WTransMatrix);
		}
	}

	// draw the ellipses
	if (m_showLargeEllipse && m_ellipse && m_influence != NULL)
	{
		int numLinks = m_influence->m_numLinks;

		if (m_showOneEllipse == -1 || m_showingAllEllipses == true)
		{
			for (int l = 0; l < numLinks; l++)
			{
				Link* link = m_influence->getLink(l);
				double WTransMatrix[4][4];
				link->getWTransMat(WTransMatrix);
				float a, b, c;
				a = m_largeEllipseAttr[(3 * l)];
				b = m_largeEllipseAttr[(3 * l) + 1];
				c = m_largeEllipseAttr[(3 * l) + 2];

				if (m_selectedEllipse == l)
					drawEllipse(ELLIPSE_SELECTED, a, b, c, WTransMatrix);
				else
					drawEllipse(ELLIPSE_LARGE_ONLY, a, b, c, WTransMatrix);
			}
		}
		else		// only show one ellipse
		{
			// m_showOneEllipse is the link of the ellipse to be shown
			int l = m_showOneEllipse;

			Link* link = m_influence->getLink(l);
			double WTransMatrix[4][4];
			link->getWTransMat(WTransMatrix);
			float a, b, c;
			a = m_largeEllipseAttr[(3 * l)];
			b = m_largeEllipseAttr[(3 * l) + 1];
			c = m_largeEllipseAttr[(3 * l) + 2];

			if (m_selectedEllipse == l)
				drawEllipse(ELLIPSE_SELECTED, a, b, c, WTransMatrix);
			else
				drawEllipse(ELLIPSE_LARGE_ONLY, a, b, c, WTransMatrix);
		}
	}

	if (m_showDragBox)
	{
		int winWidth = dance::AllViews->currentView->getWidth();
		int winHeight = dance::AllViews->currentView->getHeight();
		
		glViewport(0, 0, winWidth, winHeight);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluOrtho2D(0, winWidth, 0, winHeight);

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
				
		glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT | GL_LIGHTING_BIT);
		glDisable(GL_LIGHTING);
		// draw the box
		glColor3f(1.0, 1.0, 1.0);
		
		glBegin(GL_LINE_STRIP);
		glVertex2i(m_boxX1, winHeight - m_boxY1);
		glVertex2i(m_boxX2, winHeight - m_boxY1);
		glVertex2i(m_boxX2, winHeight - m_boxY2);
		glVertex2i(m_boxX1, winHeight - m_boxY2);
		glVertex2i(m_boxX1, winHeight - m_boxY1);
		glEnd();
		
		glPopAttrib();

		// reset the projection
		dance::AllViews->currentView->setProjection();
	}

	glPopAttrib();
}   


void LinearSkinning::setSkinAppMode(LinSkinAppModeEnum mode)
{
	LinSkinAppMode = mode;
}

int LinearSkinning::getSkinAppMode()
{
	return LinSkinAppMode;
}

int LinearSkinning::getSelectedEllipse()
{
	return m_selectedEllipse;
}

int LinearSkinning::getSelectedEllipseType()
{
	return m_selectedEllipseType;
}

// added by achu: draw ellipse function
void LinearSkinning::displayUnassignedSkin(GLenum mode)
{
	// MODIFIED: Model implementation by Jonathan Garcia
	double* vertices = m_skin->vertices;
	int numVertices = m_skin->numvertices;

	glPushAttrib(GL_ENABLE_BIT|GL_DEPTH_BUFFER_BIT|GL_LIGHTING_BIT|GL_CURRENT_BIT);
	glDisable(GL_LIGHTING);
	glPointSize(m_vertexSize);

	glBegin(GL_POINTS);

	// MODIFIED: Model implementation by Jonathan Garcia
	for (int v = 0; v < numVertices; v++)
	{
		glColor4f(0.5f, 0.5f, 0.5f, 1.0f);
		if ((m_skinSelectFlag[v] == true)  && (mode == GL_RENDER))
		{
			glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
			glVertex3d(vertices[v*3], vertices[v*3+1], vertices[v*3+2]);
		}
		else if (m_skinTotalLinks[v] == 0)
		{
			glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
			glVertex3d(vertices[v*3], vertices[v*3+1], vertices[v*3+2]);
		}
		else
		{
			glVertex3d(vertices[v*3], vertices[v*3+1], vertices[v*3+2]);
		}
	}
	glEnd();

	glPopAttrib();
}

void LinearSkinning::displayLinkSkinMap()
{
	glPushAttrib(GL_ENABLE_BIT|GL_DEPTH_BUFFER_BIT|GL_LIGHTING_BIT|GL_CURRENT_BIT);
	glDisable(GL_LIGHTING);
	glPointSize(m_vertexSize);

	// MODIFIED: Model implementation by Jonathan Garcia
	double* vertices = m_skin->vertices;
	int numVertices = m_skin->numvertices;

	for (int v = 0; v < numVertices; v++)
	{
		if (m_skinSelectFlag[v] == true)
		{
			glColor4f(1.0, 0.0, 0.0, 1.0);
			glBegin(GL_POINTS);
			glVertex3d(vertices[v*3], vertices[v*3+1], vertices[v*3+2]);
			glEnd();

			continue;
		}

		bool drawn = false;

		for (int i = 0; i < 5; i++)
		{
			if (m_skinWeightLinks[(5 * v) + i] == m_showLinkSkinMappings)
			{	

				// get the inverse transformation index
				double weight = m_skinWeights[(5 * v) + i];

				glColor3d(weight, 1.0, 0.0);
				glBegin(GL_POINTS);
				glVertex3d(vertices[v*3], vertices[v*3+1], vertices[v*3+2]);
				glEnd();

				drawn = true;
			}
		}

		if (!drawn)
		{
			glColor3f(0.5, 0.5, 0.5);
			glBegin(GL_POINTS);
			glVertex3d(vertices[v*3], vertices[v*3+1], vertices[v*3+2]);
			glEnd();
		}
	}
	
/* is this method of drawing any faster? Might be if constant color changes thrash video card.

	// draw all selected skin
	glColor4f(1.0, 0.0, 0.0, 1.0);
	glBegin(GL_POINTS);
	for (int v = 0; v < numVertices; v++)
	{
		if (m_skinSelectFlag[v] == true)
			glVertex3f(vertices[v][0], vertices[v][1], vertices[v][2]);
	}
	glEnd();

	// draw all skin mapped skin
	glColor3f(1.0, 1.0, 0.0);
	glBegin(GL_POINTS);
	for (int v = 0; v < numVertices; v++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (m_skinWeightLinks[(5 * v) + i] == m_showLinkSkinMappings)
			{
				glVertex3f(vertices[v][0], vertices[v][1], vertices[v][2]);
				break;
			}
		}
	}
	glEnd();

	// draw all remaining skin
	glColor3f(0.5, 0.5, 0.5);
	glBegin(GL_POINTS);
	for (int v = 0; v < numVertices; v++)
	{
		bool found = false;
		for (int i = 0; i < 5; i++)
		{
			if (m_skinWeightLinks[(5 * v) + i] == m_showLinkSkinMappings)
			{
				found = true;
				break;
			}
		}
		if (!found)
			glVertex3f(vertices[v][0], vertices[v][1], vertices[v][2]);
	}
	glEnd();
*/

	glPopAttrib();
}

void LinearSkinning::drawEllipse(int type, float a, float b, float c, double WTransMatrix[][4])
{
	float PI = 3.141593f; 
	float z2 = 0.0f;
	float d2 = 0.0f; 
	float z1 = 0.0f;
	float d1 = 0.0f; 
	int step = 2; 
	int slice = 20; 
	float phi = PI/slice; 
//	GLfloat mat_specular[4];

	z1 = c; 
	d1 = 0; 

	glPushAttrib(GL_ENABLE_BIT | GL_DEPTH_BUFFER_BIT | GL_LIGHTING_BIT | GL_CURRENT_BIT);
	glEnable(GL_LIGHTING);
	glShadeModel(GL_SMOOTH);
//	glClearColor(0.0, 0.0, 0.0, 0.0);
//	glDisable(GL_LIGHTING);
//	glDisable(GL_DEPTH_TEST);
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);

	for(int i=step; i<=slice; i+=step) 
	{ 
		z2 = c*cos(i*phi); 
		d2 = sqrt(1-pow(z2/c,2)); 

		switch (type)
		{
		case ELLIPSE_SMALL_ONLY:
			glColor4f(1.0, 1.0, 0.0, 1.0);
			break;
		case ELLIPSE_LARGE_ONLY:
			glColor4f(1.0, 0.0, 1.0, 1.0);
			break;
		case ELLIPSE_SELECTED:
			glColor4f(1.0, 0.0, 0.0, 1.0);
			break;
		}

		glPointSize(1.0);
		if (m_ellipseLookShow == ELLIPSE_DISPLAY_VERTICES)
		{
			glBegin(GL_POINTS); 
		}
		else if (m_ellipseLookShow == ELLIPSE_DISPLAY_MESH)
		{
			glBegin(GL_LINE_STRIP); 
		}
		else
		{
			glBegin(GL_QUAD_STRIP); 
		}

		for(int j=2*slice; j>=0; j-=step) 
		{ 
			Vector normal_1 = { cos(phi*j)*sin(phi*i), sin(phi*j)*sin(phi*i), cos(phi*i) };
			transformPoint_mat(normal_1, WTransMatrix);
			glNormal3d(normal_1[0], normal_1[1], normal_1[2]); 

			Vector point_1 = { a*d2*cos(phi*j), b*d2*sin(phi*j), z2 };
			transformPoint_mat(point_1, WTransMatrix);
			glVertex3d(point_1[0], point_1[1], point_1[2]); 
    
			Vector normal_2 = { cos(phi*j)*sin((i-step)*phi), sin(phi*j)*sin((i-step)*phi), cos((i-step)*phi)};
			transformPoint_mat(normal_2, WTransMatrix);
			glNormal3d(normal_2[0], normal_2[1], normal_2[2]);

			Vector point_2 = { a*d1*cos(phi*j), b*d1*sin(phi*j), z1 };
			transformPoint_mat(point_2, WTransMatrix);
			glVertex3d(point_2[0], point_2[1], point_2[2]); 
		} 
		glEnd(); 

		z1 = z2; 
		d1 = d2; 
	}

	if (type == ELLIPSE_SELECTED)
	{
		drawAxisOfEllipse(0, a, b, c, WTransMatrix);		// draw the X axis
		drawAxisOfEllipse(1, a, b, c, WTransMatrix);		// draw the Y axis
		drawAxisOfEllipse(2, a, b, c, WTransMatrix);		// draw the Z axis
	}

	glPopAttrib();
}

void normalize(double vector[3])
{
	double magnitude = sqrt((vector[0])*(vector[0])
						+ (vector[1])*(vector[1])
						+ (vector[2])*(vector[2]));

	vector[0] /= magnitude;
	vector[1] /= magnitude;
	vector[2] /= magnitude;
}

// draws an arrow on one of the axis of the defined ellipse.
// type:  0 is X, 1 is Y, 2 is Z
void LinearSkinning::drawAxisOfEllipse(int type, float a, float b, float c, double WTransMatrix[][4])
{
		double axis[3];
		double point[3];

		// Calculate suitable arrow	lengths	for inboard and	outboard vectors.
		// Scale these arrows as a percentage of the View Volume dimensions.
		double arrowLength = 1.0;
		DView *wview = dance::AllViews->getViewFocus();
		if (wview) {	
			double win[3]; wview->getWindowCoords(point,win);
			double worldwidth = wview->getFrustumWidth(win[2]);
			arrowLength = 0.05*worldwidth;
		}
		
		if (type == 0)
		{
			// arrow in the X axis
			point[0] = (double) a;
			point[1] = 0;
			point[2] = 0;
			axis[0] = 1.0;
			axis[1] = 0;
			axis[2] = 0;
		}
		else if (type == 1)
		{
			// arrow in the Y axis
			point[0] = 0;
			point[1] = (double) b;
			point[2] = 0;
			axis[0] = 0;
			axis[1] = 1.0;
			axis[2] = 0;
		}
		else
		{
			// arrow in the Z axis
			point[0] = 0;
			point[1] = 0;
			point[2] = (double) c;
			axis[0] = 0;
			axis[1] = 0;
			axis[2] = 1.0;
		}

		transformPoint_mat(point, WTransMatrix);
		transformPoint_mat(axis, WTransMatrix);

		// calculate the vector in correct vector in the world space
		axis[0] -= point[0];
		axis[1] -= point[1];
		axis[2] -= point[2];

		// normalize the axis vector so that the arrow size is constant.
		normalize(axis);

		// draw the arrow
		GLdrawVector(point, axis, arrowLength);
}

int LinearSkinning::commandPlugIn(int argc, char **argv)
{
	int result = DANCE_ERROR;

    if(strcmp(argv[0],"save") == 0) 
	{
		if(argc < 3) 
		{
			danceInterp::OutputMessage("USAGE: save <format> <filename>\n",(char *)NULL);
			result = DANCE_ERROR;
		}
		else
		{
			char *filename = NULL;

			if(argc == 3)
				filename = argv[2];

			// added by achu
			if(strcmp(argv[1],"ellipse") == 0)
			{
				saveEllipse(filename);
				result = DANCE_OK;
			}
			else if(strcmp(argv[1],"skinMap") == 0)
			{
				int length = strlen(filename);

				if(length > 5)
				{
					if(strncmp((const char*) (filename + length - 5), ".skin", 5) != 0)
					{
						danceInterp::OutputMessage("ERROR: Invalid filename.  Must have '.skin' extension.");
						result = DANCE_ERROR;
					}
					else
					{
						saveSkin(filename);
						result = DANCE_OK;
					}
				}
				else
				{
					danceInterp::OutputMessage("ERROR: Invalid filename.  Must have '.skin' extension.");
					result = DANCE_ERROR;
				}
			}
			else
			{
				danceInterp::OutputMessage("ERROR: Save format not recognized.\n",(char *)NULL);
				result = DANCE_ERROR;
			}
		}
    }
    else if(strcmp(argv[0],"load") == 0) 
	{
		if(argc < 2) 
		{
			danceInterp::OutputMessage("USAGE: load <format> <filename> [<skin_name>]\n");
			result = DANCE_ERROR;
		}
		else
		{
			char *file ;

			if(argc == 2) 
				file = NULL;
			else 
				file = argv[2];

			if(strcmp(argv[1], "ellipse") == 0)
			{
				loadEllipse(file);
				result = DANCE_OK;
			}
			else if(strcmp(argv[1], "skinMap") == 0)
			{
				if(argc < 4)
				{
					danceInterp::OutputMessage("USAGE: load skinMap <filename> <skin_name>\n");
					result = DANCE_ERROR;
				}
				else
				{
					int length = strlen(file);

					if(length > 5)
					{
						if(strncmp((const char*) (file + length - 5), ".skin", 5) != 0)
						{
							danceInterp::OutputMessage("ERROR: Invalid filename.  Must have '.skin' extension.");
							result = DANCE_ERROR;
						}
						else
						{
							char *skinName = argv[3];
							if(loadSkin(file, skinName))
								result = DANCE_OK;
						}
					}
					else
					{
						danceInterp::OutputMessage("ERROR: Invalid filename.  Must have '.skin' extension.");
						result = DANCE_ERROR;
					}
				}
			}
		}
	}
	else if(strcmp(argv[0],"assignToSystem") == 0) 
	{
		if(argc < 2) 
		{
			danceInterp::OutputMessage("USAGE: assignTo <system_name>\n");
			result = DANCE_ERROR;
		}
		else
		{
			if(this->assignToSystem(argv[1]))
				result = DANCE_OK;
			else
				result = DANCE_ERROR;
		}
	}
	else if(strcmp(argv[0],"unassignSystem") == 0) 
	{
		if (argc < 1)
		{
			danceInterp::OutputMessage("USAGE: unassignSystem\n");
			result = DANCE_ERROR;
		}
		else
		{
			if(this->unassignFromSystem())
				result = DANCE_OK;
			else
				result = DANCE_ERROR;
		}
	}
	else if(strcmp(argv[0],"set_articulatedobject") == 0)
	{
		if(argc < 2)
		{
			danceInterp::OutputMessage("USAGE: articulatedobject <aoname>\n");
			result = DANCE_ERROR;
		}
		else
		{
			ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get(argv[1]));

			if(ao == NULL)
			{
				danceInterp::OutputMessage("ERROR: No ArticulatedObject named %s found.", argv[1]);
				result = DANCE_ERROR;
			}
			else
			{
				this->setInfluence(ao);
				result = DANCE_OK;
			}
		}
	}
	else if(strcmp(argv[0],"remove_articulatedobject") == 0)
	{
		if(argc < 1)
		{
			danceInterp::OutputMessage("USAGE: remove_articulatedobject\n");
			result = DANCE_ERROR;
		}
		else
		{
			this->setInfluence(NULL);
			result = DANCE_OK;
		}
	}
	else if(strcmp(argv[0],"set_skin") == 0)
	{
		if(argc < 2)
		{
			danceInterp::OutputMessage("USAGE: set_skin <model>\n");
			result = DANCE_ERROR;
		}
		else
		{
			Model* model = dynamic_cast<Model*>(dance::AllGeometry->get(argv[1]));

			if(model == NULL)
			{
				danceInterp::OutputMessage("ERROR: No model named %s found.", argv[1]);
				result = DANCE_ERROR;
			}
			else
			{
				this->setSkin(model);
				result = DANCE_OK;
			}
		}
	}
	else if(strcmp(argv[0],"remove_skin") == 0)
	{
		if(argc < 1)
		{
			danceInterp::OutputMessage("USAGE: remove_skin\n");
			result = DANCE_ERROR;
		}
		else
		{
			this->setSkin(NULL);
			result = DANCE_OK;
		}
	}
	else if(strcmp(argv[0], "applyEllipses") == 0)
	{
		if(argc < 2)
		{
			danceInterp::OutputMessage("USAGE: applyEllipses <geometry_name>");
			result = DANCE_ERROR;
		}
		else
		{
			if(this->attachSkinViaEllipses(argv[1]))
				result = DANCE_OK;
			else
				result = DANCE_ERROR;
		}
	}
	else if(strcmp(argv[0], "detachSkin") == 0)
	{
		if(argc < 1)
		{
			danceInterp::OutputMessage("USAGE: detachSkin");
			result = DANCE_ERROR;
		}
		else
		{
			this->detachSkin();
            result = DANCE_OK;
		}
	}
	else if(strcmp(argv[0], "displaySkin") == 0)
	{
		if(argc < 2)
		{
			danceInterp::OutputMessage("USAGE: displaySkin <normal|mapskin|unassignedSkin>");
			result = DANCE_ERROR;
		}
		else
		{
			char commandString[1024];
			strcpy(commandString, argv[1]);

			if(strcmp(argv[1], "mapskin") == 0)
			{
				if(argc < 3)
				{
					danceInterp::OutputMessage("USAGE: displaySkin mapskin <link>");
					result = DANCE_ERROR;
				}
				else
				{
					strcat(commandString, " ");
					strcat(commandString, argv[2]);
					
					if(setDisplayMode(commandString))
						result = DANCE_OK;
					else
						result = DANCE_ERROR;
				}
			}
			else if (strcmp(argv[1], "normal") == 0)
			{
				if(argc < 2)
				{
					danceInterp::OutputMessage("USAGE: displaySkin normal");
					result = DANCE_ERROR;
				}
				else
				{
					if(setDisplayMode(commandString))
						result = DANCE_OK;
					else
						result = DANCE_ERROR;
				}
			}
			else if(strcmp(argv[1], "unassignedSkin") == 0)
			{
				if(argc < 2)
				{
					danceInterp::OutputMessage("USAGE: displaySkin unassignedSkin");
					result = DANCE_ERROR;
				}
				else
				{
					if(setDisplayMode(commandString))
						result = DANCE_OK;
					else
						result = DANCE_ERROR;
				}
			}
			else
			{
				danceInterp::OutputMessage("USAGE: displaySkin <normal|mapskin|unassignedSkin>");
				result = DANCE_ERROR;
			}

		}
	}
	else if(strcmp(argv[0], "createEllipse") == 0) // added by achu
	{
		if(argc < 1)
		{
			danceInterp::OutputMessage("USAGE: createEllipse");
			result = DANCE_ERROR;
		}
		else
		{
			if(createEllipse())
				result = DANCE_OK;
			else
				result = DANCE_ERROR;
		}
	}
	else if(strcmp(argv[0], "hideEllipses") == 0)
	{
		setEllipseDisplayMode(LinearSkinning::ELLIPSE_NEITHER, m_ellipseLookShow, m_showOneEllipse);
		result = DANCE_OK;
	}
	else if(strcmp(argv[0], "showEllipse") == 0)
	{
		if(argc < 3)
		{
			danceInterp::OutputMessage("USAGE: showEllipse <link> <type> [<vertices|mesh|solid>]");
			result = DANCE_ERROR;
		}
		else if(m_influence != NULL)
		{
			int link = atoi(argv[1]);
			int type = ELLIPSE_BOTH;
			int look = ELLIPSE_DISPLAY_MESH;

			if(link >= m_influence->getNumLinks())
				link = m_influence->getNumLinks()-1;
			if(link < 0)
				link = -1;

			if(strcmp(argv[2], "small") == 0)
			{
				type = ELLIPSE_SMALL_ONLY;
			}
			else if(strcmp(argv[2], "large") == 0)
			{
				type = ELLIPSE_LARGE_ONLY;
			}
			else if(strcmp(argv[2], "both") == 0)
			{
				type = ELLIPSE_BOTH;
			}
			else if(strcmp(argv[2], "neither") == 0)
			{
				type = ELLIPSE_NEITHER;
			}

			if(argc >= 4)
			{
				if(strcmp(argv[3], "vertices") == 0)
				{
					look = ELLIPSE_DISPLAY_VERTICES;
				}
				else if(strcmp(argv[3], "mesh") == 0)
				{
					look = ELLIPSE_DISPLAY_MESH;
				}
				else if(strcmp(argv[3], "solid") == 0)
				{
					look = ELLIPSE_DISPLAY_SOLID;
				}
			}

			if(setEllipseDisplayMode(type, look, link))
				result = DANCE_OK;
			else
				result = DANCE_ERROR;
		}
		else
		{
			danceInterp::OutputMessage("ERROR: Ellipses must exist to be shown.");
			result = DANCE_ERROR;
		}
	}
	else if(strcmp(argv[0], "modifyEllipse") == 0)
	{
		if(argc < 6)
		{
			danceInterp::OutputMessage("USAGE: modifyEllipse <link> <type> <a> <b> <c>");
			result = DANCE_ERROR;
		}
		else
		{
			int linkNum = atoi(argv[1]);
			float a = (float)atof(argv[3]);
			float b = (float)atof(argv[4]);
			float c = (float)atof(argv[5]);

			if(strcmp(argv[2], "small") == 0)
			{
				if(setEllipse(ELLIPSE_SMALL_ONLY, linkNum, a, b, c))
					result = DANCE_OK;
			}
			else if(strcmp(argv[2], "large") == 0)
			{
				if(setEllipse(ELLIPSE_LARGE_ONLY, linkNum, a, b, c))
					result = DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("ERROR: Type not recognized.");
				result = DANCE_ERROR;
			}
		}
	}
	else if(strcmp(argv[0], "skinWeights") == 0)
	{
		if(argc < 3)
		{
			danceInterp::OutputMessage("USAGE: skinWeights <link> <weight> [<link> <weight>]");
			result = DANCE_ERROR;
		}		
		else if(argc > 11)
		{
			danceInterp::OutputMessage("ERROR: Can only support up to 5 links.");
			result = DANCE_ERROR;
		}
		else if(m_selectSkinVertices.empty())
		{
			danceInterp::OutputMessage("Please first select vertices.");
			result = DANCE_ERROR;
		}
		else
		{
			int currentArgc = 1;
			float totalWeight = 0;
			int currentLink = 0;

			while(currentArgc < argc)
			{
				// Get link number
				int link; 
				int isNumber = sscanf(argv[currentArgc],"%d",&link);

				Link **linkList	= m_influence->getLinks();
				if (linkList ==	NULL)
				{
					danceInterp::OutputMessage("ERROR: No links existing for this object.\n");
					return DANCE_ERROR;
				}

				// Get the link.
				Link *wlink = NULL;
				if(isNumber != 1)
				{ // Could be a name string.
					wlink = m_influence->getLink(argv[currentArgc]);
					if (wlink == NULL)
					{
						danceInterp::OutputMessage("ERROR: No link exists with the given name.");
						return DANCE_ERROR;
					}

					link = wlink->getNumber();
				}
				else
				{
					// check if the	object has such	a link
					if(link >= m_influence->getNumLinks() || link < 0)
					{	
	    				danceInterp::OutputMessage("ERROR: Link index does not exist.\n");
	    				return DANCE_ERROR;
					}

					wlink = linkList[link];
				}

				currentArgc++;
				float weight = (float)atof(argv[currentArgc]);
				if((weight < 0) || (weight > 1))
				{
	    			danceInterp::OutputMessage("ERROR: Illegal weight.  Must be between 0 and 1.\n");
	    			return DANCE_ERROR;
				}

				if((totalWeight + weight) > 1.0)
				{
					weight = 1.0f - totalWeight;
				}
				totalWeight += weight;

				// MODIFIED: Model implementation by Jonathan Garcia
				for(unsigned int i = 0; i < m_selectSkinVertices.size(); i++)
				{
					int v = m_selectSkinVertices[i];
					double *vertices = m_skin->GetVertices();

					Vector currVertex;
					setVector(currVertex, vertices[v], vertices[v+1], vertices[v+2]);

					Vector localSkinVertex;
					wlink->getLocalCoord(localSkinVertex, currVertex);

					m_skinWeightLinks[(5 * v) + currentLink] = link;
					m_skinWeights[(5 * v) + currentLink] = weight;
					m_skinTotalLinks[v] = currentLink + 1;
					VecCopy(m_skinVertices[(5 * v) + currentLink], localSkinVertex);
				}

				currentLink++;
				currentArgc++;
			}

			for(; currentLink < 5; currentLink++)
			{
				for (unsigned int i = 0; i < m_selectSkinVertices.size(); i++)
				{
					int v = m_selectSkinVertices[i];

					m_skinWeightLinks[(5 * v) + currentLink] = -1;
					m_skinWeights[(5 * v) + currentLink] = 0;
				}
			}

			for(unsigned int i = 0; i < m_selectSkinVertices.size(); i++)
			{
				int v = m_selectSkinVertices[i];
				m_skinSelectFlag[v] = false;
			}

			m_selectSkinVertices.clear();
			dance::AllViews->postRedisplay();
			result = DANCE_OK;
		}
	}

	if(this->m_skinWindow != NULL)
		this->m_skinWindow->updateGUI();

	return result;
}

void LinearSkinning::setBindingPoseState()
{
	if(m_bindingPoseState != NULL)
	{
		delete [] m_bindingPoseState;
	}

	m_bindingPoseState = new double[m_influence->getStateSize()];
	m_influence->getState(m_bindingPoseState);

	danceInterp::OutputMessage("Binding Pose State Set\n");
}

void LinearSkinning::toBindingPoseState()
{
	// revert back to the binding pose state
	if (m_bindingPoseState != NULL)
	{
		if (m_currentState != NULL)
		{
			delete [] m_currentState;
			m_currentState = NULL;
		}

		m_currentState = new double[m_influence->getStateSize()];
		m_influence->getState(m_currentState);
		m_influence->UpdateState(m_bindingPoseState);

		danceInterp::OutputMessage("Binding Pose State Restored\n");
	}
}

void LinearSkinning::toLastCurrentState()
{
	// convert back to the current state
	if (m_currentState != NULL)
	{
		m_influence->UpdateState(m_currentState);
		delete m_currentState;
		m_currentState = NULL;
	}
}

void LinearSkinning::commitWeightChange(int vertex, int link, float weight)
{
	if (m_skin == NULL)
	{
		danceInterp::OutputMessage("Error: No skins are attached yet");
		return;
	}

	// weight must be <= 1
	if (weight > 1.0)
	{
		return;
	}

	int linkIndex = -1;
	float prevWeight = 0.0;

	// check to see if such a link already influences the vertex.
	// if so, also record the old weight of the link
	for (int i = 0; i < 5; i++)
	{
		if (m_skinWeightLinks[(5 * vertex) + i] == link)
		{		
			linkIndex = i;
			prevWeight = m_skinWeights[(5 * vertex) + i];
			break;
		}
	}

	if (linkIndex != -1)		// such a link already exist in the weight list
	{
		// the link will no longer influence the vertex
		if (weight == 0)
		{
			m_skinTotalLinks[vertex] -= 1;

			float spareWeight = prevWeight;
			float weightOfOtherLinks = 1.0f - prevWeight;

			m_skinWeightLinks[(5 * vertex) + linkIndex] = -1;
			m_skinWeights[(5 * vertex) + linkIndex] = 0;

			for (int i = 0; i < 5; i++)
			{
				if (m_skinWeightLinks[(5 * vertex) + i] != -1)
				{
					float additionalWeight = (m_skinWeights[(5 * vertex) + i] / weightOfOtherLinks) * spareWeight;
					m_skinWeights[(5 * vertex) + i] += additionalWeight;
				}
			}
		}
		// new weight is smaller.  redistribute the extra weights
		else if (weight < prevWeight)
		{
			float spareWeight = prevWeight - weight;
			float weightOfOtherLinks = 1.0f - prevWeight;

			m_skinWeights[(5 * vertex) + linkIndex] = weight;

			for (int i = 0; i < 5; i++)
			{
				if ((m_skinWeightLinks[(5 * vertex) + i] != -1) && (i != linkIndex))
				{
					float additionalWeight = (m_skinWeights[(5 * vertex) + i] / weightOfOtherLinks) * spareWeight;
					m_skinWeights[(5 * vertex) + i] += additionalWeight;
				}
			}
		}
		// new weight is bigger.  take some weight from each other link
		else if (weight > prevWeight)
		{
			float newWeightDifference = weight - prevWeight;
			float weightOfOtherLinks = 1.0f - prevWeight;

			m_skinWeights[(5 * vertex) + linkIndex] = weight;

			for (int i = 0; i < 5; i++)
			{
				if ((m_skinWeightLinks[(5 * vertex) + i] != -1) && (i != linkIndex))
				{
					float deductedWeight = (m_skinWeights[(5 * vertex) + i] / weightOfOtherLinks) * newWeightDifference;
					m_skinWeights[(5 * vertex) + i] -= deductedWeight;
				
					if (m_skinWeights[(5 * vertex) + i] == 0)
					{
						m_skinWeightLinks[(5 * vertex) + i] = -1;
						m_skinTotalLinks[vertex] -= 1;
					}
				}
			}
		}
	}
	// a new influence is added to a vertex with no influences.  Weight must be 1.0
	else if ((m_skinTotalLinks[vertex] == 0) && (weight == 1.0))
	{
		//Vector* vertices = m_skin->getVertices();
		Link **linkList	= m_influence->getLinks();
		Link *wlink = linkList[link];
		
		// find the original position of this vertex in the geometry's world space
		Vector localSkinVertex;
		wlink->getLocalCoord(localSkinVertex, m_originalVertCoord[vertex]);

		m_skinWeightLinks[5 * vertex] = link;
		m_skinWeights[5 * vertex] = weight;
		m_skinTotalLinks[vertex] += 1;
		VecCopy(m_skinVertices[5 * vertex], localSkinVertex);
	}
	// a new influential link is added
	else if ((m_skinTotalLinks[vertex] < 5) && (weight != 0))
	{
		//Vector* vertices = m_skin->getVertices();
		Link **linkList	= m_influence->getLinks();
		Link *wlink = linkList[link];
		
		// find the original position of this vertex in the geometry's world space
		Vector localSkinVertex;
		wlink->getLocalCoord(localSkinVertex, m_originalVertCoord[vertex]);

		bool newLinkPlaced = false;

		for (int i = 0; i < 5; i++)
		{
			if (m_skinWeightLinks[(5 * vertex) + i] == -1)
			{	
				if (!newLinkPlaced)
				{
					m_skinWeightLinks[(5 * vertex) + i] = link;
					m_skinWeights[(5 * vertex) + i] = weight;
					m_skinTotalLinks[vertex] += 1;
					VecCopy(m_skinVertices[(5 * vertex) + i], localSkinVertex);
					newLinkPlaced = true;
				}
			}
			else
			{
				float deductedWeight = m_skinWeights[(5 * vertex) + i] * weight;
				m_skinWeights[(5 * vertex) + i] -= deductedWeight;

				if (m_skinWeights[(5 * vertex) + i] == 0)
				{
					m_skinWeightLinks[(5 * vertex) + i] = -1;
					m_skinTotalLinks[vertex] -= 1;
				}
			}
		}
	}
}

void LinearSkinning::changeWeight(int vertex, int link, float weight)
{
	// change the skeleton state to teh binding pose state
	toBindingPoseState();

	commitWeightChange(vertex, link, weight);

	// revert back to the last current state
	toLastCurrentState();
}

void LinearSkinning::changeWeightInSelectList(int link, float weight)
{
	std::vector<int>::iterator vertIter;

	// change the skeleton state to teh binding pose state
	toBindingPoseState();

	vertIter = m_selectSkinVertices.begin();
	for (; vertIter != m_selectSkinVertices.end(); vertIter++)
	{
		commitWeightChange((*vertIter), link, weight);
	}

	// revert back to the last current state
	toLastCurrentState();
}

bool LinearSkinning::assignToSystem(const char *sysName)
{
	if (m_influence != NULL)
	{
		this->unassignFromSystem();
	}

	m_influence = (ArticulatedObject*)dance::AllSystems->get(sysName);
	if (m_influence == NULL)
	{
		danceInterp::OutputMessage("System %s not found in system list...\n", sysName);
		return false;
	}

	m_influence->assignModifier(this);
	danceInterp::OutputMessage("Modifier assigned to system %s...\n", sysName);

	return true;
}

bool LinearSkinning::unassignFromSystem()
{
	if (m_influence == NULL)
	{
		danceInterp::OutputMessage("Modifier %s is not assigned to any system\n", this->getName());
		return false;
	}
	
	m_influence->removeModifier(this);
	m_influence = NULL;
	danceInterp::OutputMessage("Modifier %s no longer assigned to any system\n", this->getName());	
	return true;
}

bool LinearSkinning::createEllipse()
{
	if (m_influence == NULL)
	{
		danceInterp::OutputMessage("Error: modifier %s is not currently assigned to any influence", this->getName());
		return false;
	}

	int numLinks = m_influence->m_numLinks;

	// erase old instance of the ellipse
	m_smallEllipseAttr.clear();
	m_largeEllipseAttr.clear();

	for (int l = 0; l < numLinks; l++)
	{
		Link* link = m_influence->getLink(l);
		Joint* parent_joint = link->getParentJoint();

		double link_pos[3];
		double joint_pos[3];

		link->getPosition(link_pos);
		parent_joint->getPosition(joint_pos);

		double distance = sqrt(((link_pos[0] - joint_pos[0])*(link_pos[0] - joint_pos[0])) +
							((link_pos[1] - joint_pos[1])*(link_pos[1] - joint_pos[1])) +
							((link_pos[2] - joint_pos[2])*(link_pos[2] - joint_pos[2])));

		// hack so that all ellipse will appear.
		if (distance == 0)
		{
			distance = 0.05;
		}

		// new code, set the size of the ellipse based on the length between the center of the link and the parent joint.
		m_smallEllipseAttr.push_back(((float) distance) / 2);
		m_smallEllipseAttr.push_back(((float) distance) / 2);
		m_smallEllipseAttr.push_back(((float) distance) / 2);

		m_largeEllipseAttr.push_back((float) distance);
		m_largeEllipseAttr.push_back((float) distance);
		m_largeEllipseAttr.push_back((float) distance);

		/*
		// old code: set to hard coded values because bounding box don't work without skeleton bones.
		m_smallEllipseAttr.push_back(0.1);
		m_smallEllipseAttr.push_back(0.1);
		m_smallEllipseAttr.push_back(0.1);

		m_largeEllipseAttr.push_back(0.2);
		m_largeEllipseAttr.push_back(0.2);
		m_largeEllipseAttr.push_back(0.2);
		*/

		/*
		// bad code: uses bones and bounding boxes to make ellipses...better effects.
		Link* link = m_influence->getLink(l);
		link->calcBoundingBox(&(link->boundingBox));
		double WmaxLinkEnd[3] = { (link->boundingBox).xMax, (link->boundingBox).yMax, (link->boundingBox).zMax };
		double LmaxLinkEnd[3];
		double WminLinkEnd[3] = { (link->boundingBox).xMin, (link->boundingBox).yMin, (link->boundingBox).zMin };
		double LminLinkEnd[3];
		link->getLocalCoord(LmaxLinkEnd, WmaxLinkEnd);
		link->getLocalCoord(LminLinkEnd, WminLinkEnd);

		m_smallEllipseAttr.push_back((LmaxLinkEnd[0] - LminLinkEnd[0]) / 2);
		m_smallEllipseAttr.push_back((LmaxLinkEnd[1] - LminLinkEnd[1]) / 2);
		m_smallEllipseAttr.push_back((LmaxLinkEnd[2] - LminLinkEnd[2]) / 2);

		m_largeEllipseAttr.push_back(((LmaxLinkEnd[0] - LminLinkEnd[0]) / 2) * 1.5);
		m_largeEllipseAttr.push_back(((LmaxLinkEnd[1] - LminLinkEnd[1]) / 2) * 1.5);
		m_largeEllipseAttr.push_back(((LmaxLinkEnd[2] - LminLinkEnd[2]) / 2) * 1.5);
		*/
	}

	m_ellipse = true;
	setEllipseDisplayMode(LinearSkinning::ELLIPSE_BOTH, LinearSkinning::ELLIPSE_DISPLAY_MESH, -1);

	dance::AllViews->postRedisplay();

	return true;
}

bool LinearSkinning::modifyEllipse(int type, int link, float scale_x, float scale_y, float scale_z)
{
	if (m_ellipse == false)
	{
		danceInterp::OutputMessage("Error: create the ellipses first");
		return false;
	}

	// make sure you can only scale with a positive number
	scale_x = (scale_x <= 0.0f ? 1.0f : scale_x);
	scale_y = (scale_y <= 0.0f ? 1.0f : scale_y);
	scale_z = (scale_z <= 0.0f ? 1.0f : scale_z);

	if (type == ELLIPSE_SMALL_ONLY)
	{
		m_smallEllipseAttr[(3 * link)] *= scale_x;
		m_smallEllipseAttr[(3 * link) + 1] *= scale_y;
		m_smallEllipseAttr[(3 * link) + 2] *= scale_z;
	}

	if (type == ELLIPSE_LARGE_ONLY)
	{
		m_largeEllipseAttr[(3 * link)] *= scale_x;
		m_largeEllipseAttr[(3 * link) + 1] *= scale_y;
		m_largeEllipseAttr[(3 * link) + 2] *= scale_z;
	}

	dance::AllViews->postRedisplay();

	return true;
}

// sets the abc attributes for an ellipse.  If any value is negative, don't change that value
bool LinearSkinning::setEllipse(int type, int link, float a, float b, float c)
{
	if (m_ellipse == false)
	{
		danceInterp::OutputMessage("Error: create the ellipses first");
		return false;
	}

	if (type == ELLIPSE_SMALL_ONLY)
	{
		m_smallEllipseAttr[(3 * link)] = (a < 0.0 ? m_smallEllipseAttr[(3 * link)] : a);
		m_smallEllipseAttr[(3 * link) + 1] = (b < 0.0 ? m_smallEllipseAttr[(3 * link) + 1] : b);
		m_smallEllipseAttr[(3 * link) + 2] = (c < 0.0 ? m_smallEllipseAttr[(3 * link) + 2] : c);
	}

	if (type == ELLIPSE_LARGE_ONLY)
	{
		m_largeEllipseAttr[(3 * link)] = (a < 0.0 ? m_largeEllipseAttr[(3 * link)] : a);
		m_largeEllipseAttr[(3 * link) + 1] = (b < 0.0 ? m_largeEllipseAttr[(3 * link) + 1] : b);
		m_largeEllipseAttr[(3 * link) + 2] = (c < 0.0 ? m_largeEllipseAttr[(3 * link) + 2] : c);
	}

	dance::AllViews->postRedisplay();

	return true;
}

// sets the abc attributes for all ellipses.  If any value is negative, don't change that value
bool LinearSkinning::setAllEllipse(int type, float a, float b, float c)
{
	int i;

	if(m_ellipse == false)
	{
		danceInterp::OutputMessage("Error: create the ellipses first");
		return false;
	}

	if(type == ELLIPSE_SMALL_ONLY)
	{
		for(i = 0; i < (int)(m_smallEllipseAttr.size() / 3); i++)
		{
			m_smallEllipseAttr[(3 * i)] = (a < 0.0 ? m_smallEllipseAttr[(3 * i)] : a);
			m_smallEllipseAttr[(3 * i) + 1] = (b < 0.0 ? m_smallEllipseAttr[(3 * i) + 1] : b);
			m_smallEllipseAttr[(3 * i) + 2] = (c < 0.0 ? m_smallEllipseAttr[(3 * i) + 2] : c);
		}
	}

	if(type == ELLIPSE_LARGE_ONLY)
	{
		for(i = 0; i < (int)(m_largeEllipseAttr.size() / 3); i++)
		{
			m_largeEllipseAttr[(3 * i)] = (a < 0.0 ? m_largeEllipseAttr[(3 * i)] : a);
			m_largeEllipseAttr[(3 * i) + 1] = (b < 0.0 ? m_largeEllipseAttr[(3 * i) + 1] : b);
			m_largeEllipseAttr[(3 * i) + 2] = (c < 0.0 ? m_largeEllipseAttr[(3 * i) + 2] : c);
		}
	}

	dance::AllViews->postRedisplay();

	return true;
}

bool LinearSkinning::getEllipseAttrib(int type, int link, float* a, float* b, float* c)
{
	if(m_ellipse == false)
	{
		danceInterp::OutputMessage("Error: create the ellipses first");
		return false;
	}

	// get attribute for all ellipses
	if(link < 0)
	{
		// pick the first ellipse to use as value for all ellipses
		if(type == ELLIPSE_SMALL_ONLY)
		{
			*a = m_smallEllipseAttr[(3 * 0)];
			*b = m_smallEllipseAttr[(3 * 0) + 1];
			*c = m_smallEllipseAttr[(3 * 0) + 2];
		}

		if(type == ELLIPSE_LARGE_ONLY)
		{
			*a = m_largeEllipseAttr[(3 * 0)];
			*b = m_largeEllipseAttr[(3 * 0) + 1];
			*c = m_largeEllipseAttr[(3 * 0) + 2];
		}
	}
	else
	{
		if(type == ELLIPSE_SMALL_ONLY)
		{
			*a = m_smallEllipseAttr[(3 * link)];
			*b = m_smallEllipseAttr[(3 * link) + 1];
			*c = m_smallEllipseAttr[(3 * link) + 2];
		}

		if(type == ELLIPSE_LARGE_ONLY)
		{
			*a = m_largeEllipseAttr[(3 * link)];
			*b = m_largeEllipseAttr[(3 * link) + 1];
			*c = m_largeEllipseAttr[(3 * link) + 2];
		}
	}

	return true;
}

bool LinearSkinning::setDisplayMode(const char *modeString)
{
	if (strncmp(modeString, "mapskin", 7) == 0)
	{
		char command[10];
		char linkName[128];

		sscanf(modeString, "%s %s", command, linkName);

		if (m_influence == NULL)
		{
			danceInterp::OutputMessage("Error: modifier %s is not currently assigned to any influence", this->getName());
			return false;
		}

		// Get link number
		int link; 
		int isNumber = sscanf(linkName,"%d",&link);

		Link **linkList	= m_influence->getLinks();
		if (linkList ==	NULL)
		{
			danceInterp::OutputMessage("ERROR: No links existing for this object.\n");
			return false;
		}

		// Get the link.
		Link *wlink = NULL;
		if (isNumber != 1)
		{ // Could be a name string.
			wlink = m_influence->getLink(linkName);
			if (wlink == NULL) {
				danceInterp::OutputMessage("ERROR: No link exists with the given name.");
				return false;
			}

			link = wlink->getNumber();
		}
		else {
			// check if the	object has such	a link
			if (link >= m_influence->getNumLinks() || link < 0)
			{	
    			danceInterp::OutputMessage("ERROR: Link index does not exist.\n");
				return false;
			}

			wlink = linkList[link];
		}

		m_showLinkSkinMappings = link;
		m_skinDisplayMode = this->SKIN_DISPLAY_MAPPED;

//		m_skin->disableAutoShow();

		danceInterp::OutputMessage("Now showing skin mappings to link %s", wlink->getName());
	}
	else if (strcmp(modeString, "unassignedSkin") == 0)
	{
		m_skinDisplayMode = this->SKIN_DISPLAY_UNASSIGNED;

//		m_skin->disableAutoShow();

		danceInterp::OutputMessage("Now showing unassigned vertices of skins");
	}
	else if (strcmp(modeString, "normal") == 0)
	{
		m_skinDisplayMode = this->SKIN_DISPLAY_NORMAL;

//		m_skin->enableAutoShow();

		if ((m_skin != NULL) && (m_selectSkinVertices.size() > 0))
		{
			for (unsigned int i = 0; i < m_selectSkinVertices.size(); i++)
			{
				int v = m_selectSkinVertices[i];
				m_skinSelectFlag[v] = false;

				// a window is made
				if (m_skinWindow)
				{
					((SkinningWindow *) m_skinWindow)->tableWindow->removeSelectedVertex(v);
				}
			}

			m_selectSkinVertices.clear();
		}
	}
	else
	{
		danceInterp::OutputMessage("Usage: displaySkin <normal|mapskin|unassignedSkin>");
	}

	dance::AllViews->postRedisplay();

	return true;
}

bool LinearSkinning::setEllipseDisplayMode(int type, int look, int link)
{
	if (m_ellipse == false)
	{
		danceInterp::OutputMessage("Error: no ellipsoids are loaded or created");
		return false;
	}

	if (m_influence == NULL)
	{
		danceInterp::OutputMessage("Error: modifier %s is not currently assigned to any influence", this->getName());
		return false;
	}

	if (link >= m_influence->m_numLinks)
	{
		danceInterp::OutputMessage("Error: Invalid link number");
		return false;
	}

	if (link < -1)
		link = -1;

	if (type == ELLIPSE_SMALL_ONLY)
	{
		m_showSmallEllipse = true;
		m_showLargeEllipse = false;
	}
	else if (type == ELLIPSE_LARGE_ONLY)
	{
		m_showSmallEllipse = false;
		m_showLargeEllipse = true;
	}
	else if (type == ELLIPSE_BOTH)
	{
		m_showSmallEllipse = true;
		m_showLargeEllipse = true;
	}
	else if (type == ELLIPSE_NEITHER)
	{
		m_showSmallEllipse = false;
		m_showLargeEllipse = false;
	}

	m_ellipseTypeShow = type;
	m_ellipseLookShow = look;
	m_showOneEllipse = link;
	m_selectedEllipse = -1;
	m_selectedEllipseType = -1;
	m_selectedEllipseAxis = -1;

	dance::AllViews->postRedisplay();
	return true;
}

void LinearSkinning::setEllipseFraction(float fraction)
{
	m_ellipseFraction = fraction;
}
float LinearSkinning::getEllipseFraction()
{
	return m_ellipseFraction;
}
int  LinearSkinning::getEllipseTypeShow()
{
	return m_ellipseTypeShow;
}

int  LinearSkinning::getEllipseLookShow()
{
	return m_ellipseLookShow;
}

int  LinearSkinning::getShowOneEllipse()
{
	return m_showOneEllipse;
}

void LinearSkinning::clearSkinSelection()
{
	if (m_skin != NULL)
	{
		for (unsigned int i = 0; i < m_selectSkinVertices.size(); i++)
		{
			int v = m_selectSkinVertices[i];
			m_skinSelectFlag[v] = false;
		}

		m_selectSkinVertices.clear();
	}
}

//  Handle skeleton motions.
int LinearSkinning::PassiveMotionCB(DView *focus, int x, int y)
{
    return 1 ;
}

// handles keyboard key presses
int LinearSkinning::KeyboardCB( unsigned char key, int x, int y )
{ 
	int matched = 0;

	if (m_selectedEllipse != -1)
	{
		int l = m_selectedEllipse;

		Link* link = m_influence->getLink(l);
		Joint* parent_joint = link->getParentJoint();

		double link_pos[3];
		double joint_pos[3];

		link->getPosition(link_pos);
		parent_joint->getPosition(joint_pos);

		double distance = sqrt(((link_pos[0] - joint_pos[0])*(link_pos[0] - joint_pos[0])) +
							((link_pos[1] - joint_pos[1])*(link_pos[1] - joint_pos[1])) +
							((link_pos[2] - joint_pos[2])*(link_pos[2] - joint_pos[2])));

		// hack.  if distance is 0, use some value
		if (distance == 0)
			distance = 0.05;


		// TODO: fix this to do something useful
		/*
		// new code, change the ellipse by the 10% of the distance between the center of link and parent joint.
		switch((unsigned short) key)
		{
		case 185:		// num9
			if (m_selectedEllipseType == ELLIPSE_SMALL_ONLY)
				m_smallEllipseAttr[(3 * l)] += distance * 0.1;
			else
				m_largeEllipseAttr[(3 * l)] += distance * 0.1;

			attribChanged = true;
			break;
		case 184:		// num8
			if (m_selectedEllipseType == ELLIPSE_SMALL_ONLY)
				m_smallEllipseAttr[(3 * l)] -= distance * 0.1;
			else
				m_largeEllipseAttr[(3 * l)] -= distance * 0.1;

			attribChanged = true;
			break;
		case 182:		// num6
			if (m_selectedEllipseType == ELLIPSE_SMALL_ONLY)
				m_smallEllipseAttr[(3 * l) + 1] += distance * 0.1;
			else
				m_largeEllipseAttr[(3 * l) + 1] += distance * 0.1;

			attribChanged = true;
			break;
		case 181:		// num5
			if (m_selectedEllipseType == ELLIPSE_SMALL_ONLY)
				m_smallEllipseAttr[(3 * l) + 1] -= distance * 0.1;
			else
				m_largeEllipseAttr[(3 * l) + 1] -= distance * 0.1;

			attribChanged = true;
			break;
		case 179:		// num3
			if (m_selectedEllipseType == ELLIPSE_SMALL_ONLY)
				m_smallEllipseAttr[(3 * l) + 2] += distance * 0.1;
			else
				m_largeEllipseAttr[(3 * l) + 2] += distance * 0.1;

			attribChanged = true;
			break;
		case 178:		// num2
			if (m_selectedEllipseType == ELLIPSE_SMALL_ONLY)
				m_smallEllipseAttr[(3 * l) + 2] -= distance * 0.1;
			else
				m_largeEllipseAttr[(3 * l) + 2] -= distance * 0.1;

			attribChanged = true;
			break;
		}

		if (attribChanged && (m_skinWindow != NULL))
		{
			if (m_selectedEllipseType == ELLIPSE_SMALL_ONLY)
			{
				m_skinWindow->updateSelectedSmallEllipseAttrib(m_smallEllipseAttr[(3 * l)],
															m_smallEllipseAttr[(3 * l) + 1],
															m_smallEllipseAttr[(3 * l) + 2]);
			}
			else
			{
				m_skinWindow->updateSelectedLargeEllipseAttrib(m_largeEllipseAttr[(3 * l)],
															m_largeEllipseAttr[(3 * l) + 1],
															m_largeEllipseAttr[(3 * l) + 2]);
			}
		}
		*/
		dance::AllViews->postRedisplay();
	
	}

    switch((char) key)
    {
		case 'k':		// added by achu
			LinSkinAppMode = LinearSkinning::MODE_SKIN_SELECTION;
			matched = 1;
			danceInterp::OutputMessage("Entering skin selection mode...\n") ;
		break;

		case 'e':
			LinSkinAppMode = LinearSkinning::MODE_ELLIPSE_SELECTION;
			matched = 1;
			danceInterp::OutputMessage("Entering ellipse selection mode...\n") ;
		break;

		case 'c':
			LinSkinAppMode = LinearSkinning::MODE_SKIN_VIEW;
			matched = 1;
			danceInterp::OutputMessage("Entering camera mode...\n") ;
		break;

		default:
			return -1;
	}
    
	m_skinWindow->updateEllipseWidgets();

	// Update display.
	DView *view = dance::AllViews->getViewFocus();
	if (view) view->postRedisplay();

	return matched;
}	    


void LinearSkinning::MouseCB(Event *event, bool released)
{
//	double depth = event->Window->getDepth(event->winX,event->winY);
//	if (depth == 1.0) {
//		depth = 0.5; // half way point in viewing volume
//	}
//	else {// Selected something in the depth buffer. 
//		// Choose point in depth buffer.
//		depth = -1.0;
//	}
//
//	event->Window->getWorldCoords(dance::CursorPosn,event->winX,event->winY, depth);
    

	if (LinSkinAppMode == LinearSkinning::MODE_SKIN_SELECTION || LinSkinAppMode == LinearSkinning::MODE_ELLIPSE_SELECTION)
	{
		int button = fltk::event_button();
		//int state = fltk::event_key();
		int winX = fltk::event_x();
		int winY = fltk::event_y();
		DView *view = event->getView();

		// store the window coordinates of the current click
		m_prevWinX = winX;
		m_prevWinY = winY;

		switch( LinSkinAppMode )
		{
		case LinearSkinning::MODE_SKIN_SELECTION:
			if (released == false)			// a button down
			{
				if ((button == 1) || (button == 3))		// left or right mouse button
				{
					// saves the starting point so a box can be drawn when dragged
					m_boxX1 = winX;
					m_boxY1 = winY;

					doSkinSelection(view, winX, winY, 7.0, 7.0, button, 0);
				}
				else if ((button == 2) && (m_skin != NULL))		// middle mouse button and skin exist
				{
					clearSkinSelection();

					// a window is made
					if (m_skinWindow)
					{
						((SkinningWindow *) m_skinWindow)->tableWindow->clearSelectedVertices();
					}
				}
			}
			else
			{
				if ((button == 1) || (button == 3))		// left or right mouse button
				{
					// stop showing box
					m_showDragBox = false;
				}

				if (m_skinWindow != NULL)
					if (m_skinWindow->tableWindow->visible())
						m_skinWindow->tableWindow->updateGUI();
			}

			dance::AllViews->postRedisplay();
			break;
		case LinearSkinning::MODE_ELLIPSE_SELECTION:
			if (released == false)			// a button down
			{
				// only the right mouse button and only one type of ellipse can be shown
				if ((button == 1) && (m_showSmallEllipse ^ m_showLargeEllipse))	
				{
					// Set up selection buffer.
					static GLuint SelectBuffer[512];
					glSelectBuffer(512,SelectBuffer);

					// Begin selecting.
					glRenderMode(GL_SELECT);
					glInitNames();

					view->pickProjection(winX,winY,7.0,7.0);
					view->PositionCamera();

					glPushName((GLuint) -1);

					// draw the small ellipses
					if (m_showSmallEllipse)
					{
						int numLinks = m_influence->m_numLinks;

						if (m_showOneEllipse == -1 || m_showingAllEllipses == true)
						{
							for (int l = 0; l < numLinks; l++)
							{
								Link* link = m_influence->getLink(l);
								double WTransMatrix[4][4];
								link->getWTransMat(WTransMatrix);
								float a, b, c;
								a = m_smallEllipseAttr[(3 * l)];
								b = m_smallEllipseAttr[(3 * l) + 1];
								c = m_smallEllipseAttr[(3 * l) + 2];

								glLoadName(l);
								drawEllipse(ELLIPSE_SMALL_ONLY, a, b, c, WTransMatrix);
							}
						}
						else		// only draw one ellipse
						{
							int l = m_showOneEllipse;

							Link* link = m_influence->getLink(l);
							double WTransMatrix[4][4];
							link->getWTransMat(WTransMatrix);
							float a, b, c;
							a = m_smallEllipseAttr[(3 * l)];
							b = m_smallEllipseAttr[(3 * l) + 1];
							c = m_smallEllipseAttr[(3 * l) + 2];

							glLoadName(l);
							drawEllipse(ELLIPSE_SMALL_ONLY, a, b, c, WTransMatrix);
						}
					}

					// draw the large ellipses
					else
					{
						int numLinks = m_influence->m_numLinks;

						if (m_showOneEllipse == -1 || m_showingAllEllipses == true)
						{
							for (int l = 0; l < numLinks; l++)
							{
								Link* link = m_influence->getLink(l);
								double WTransMatrix[4][4];
								link->getWTransMat(WTransMatrix);
								float a, b, c;
								a = m_largeEllipseAttr[(3 * l)];
								b = m_largeEllipseAttr[(3 * l) + 1];
								c = m_largeEllipseAttr[(3 * l) + 2];

								glLoadName(l);
								drawEllipse(ELLIPSE_LARGE_ONLY, a, b, c, WTransMatrix);
							}

						}
						else		// only draw one ellipse
						{
							int l = m_showOneEllipse;

							Link* link = m_influence->getLink(l);
							double WTransMatrix[4][4];
							link->getWTransMat(WTransMatrix);
							float a, b, c;
							a = m_largeEllipseAttr[(3 * l)];
							b = m_largeEllipseAttr[(3 * l) + 1];
							c = m_largeEllipseAttr[(3 * l) + 2];

							glLoadName(l);
							drawEllipse(ELLIPSE_LARGE_ONLY, a, b, c, WTransMatrix);
						}
					}

					glPopName();
					glFlush() ;

					// Process hits.
					int hits = glRenderMode(GL_RENDER);

					view->setProjection();

					int hp = 0;
					if (hits > 0 )
					{
						hp += 3;
						m_selectedEllipse = SelectBuffer[hp];
						m_selectedEllipseType = (m_showSmallEllipse ? ELLIPSE_SMALL_ONLY : ELLIPSE_LARGE_ONLY);

						if (m_skinWindow != NULL)
						{
							m_skinWindow->skin->setSelectedEllipse(m_selectedEllipseType, m_selectedEllipse);
						}
					} // if there are hits

					// if no ellipses are hit and some ellipse was already picked, pick arrows.
					if ((hits == 0) && (m_selectedEllipse != -1))
					{
						// Begin selecting.
						glSelectBuffer(512,SelectBuffer);

						glRenderMode(GL_SELECT);
						glInitNames();

						view->pickProjection(winX,winY,7.0,7.0);
						view->PositionCamera();

						glPushName((GLuint) -1);

						// draw the small ellipses
						if (m_showSmallEllipse)
						{
							int l = m_selectedEllipse;

							Link* link = m_influence->getLink(l);
							double WTransMatrix[4][4];
							link->getWTransMat(WTransMatrix);
							float a, b, c;
							a = m_smallEllipseAttr[(3 * l)];
							b = m_smallEllipseAttr[(3 * l) + 1];
							c = m_smallEllipseAttr[(3 * l) + 2];
						
							glLoadName(0);
							drawAxisOfEllipse(0, a, b, c, WTransMatrix);		// draw the X axis

							glLoadName(1);
							drawAxisOfEllipse(1, a, b, c, WTransMatrix);		// draw the Y axis

							glLoadName(2);
							drawAxisOfEllipse(2, a, b, c, WTransMatrix);		// draw the Z axis
						}
						else
						{
							int l = m_selectedEllipse;

							Link* link = m_influence->getLink(l);
							double WTransMatrix[4][4];
							link->getWTransMat(WTransMatrix);
							float a, b, c;
							a = m_largeEllipseAttr[(3 * l)];
							b = m_largeEllipseAttr[(3 * l) + 1];
							c = m_largeEllipseAttr[(3 * l) + 2];
						
							glLoadName(0);
							drawAxisOfEllipse(0, a, b, c, WTransMatrix);		// draw the X axis

							glLoadName(1);
							drawAxisOfEllipse(1, a, b, c, WTransMatrix);		// draw the Y axis

							glLoadName(2);
							drawAxisOfEllipse(2, a, b, c, WTransMatrix);		// draw the Z axis
						}

						glPopName();
						glFlush() ;

						// Process hits.
						int hits = glRenderMode(GL_RENDER);

						view->setProjection();

						int hp = 0;
						if (hits > 0 )
						{
							hp += 3;
							m_selectedEllipseAxis = SelectBuffer[hp];
						} // if there are hits
					}
				}
			}
			else	// mouse was released
			{
				m_selectedEllipseAxis = -1;
			}
			dance::AllViews->postRedisplay();

			break;
		}
	}

	return;
}

double double_abs(double value)
{
	return ((value > 0) ? value : (-1 * value));
}

int int_abs(int value)
{
	return ((value > 0) ? value : (-1 * value));
}

void LinearSkinning::MotionCB(Event *event)
{
	if (LinSkinAppMode == this->MODE_SKIN_SELECTION || LinSkinAppMode == this->MODE_ELLIPSE_SELECTION)
	{
		int button = fltk::event_button();
		int winX = fltk::event_x();
		int winY = fltk::event_y();
		DView *view = event->getView();

		double cursorPosn[3];
		double prevCursorPosn[3];

		double a_b_c[3];
		double ellWorld[3];
		double ellLocal[3];

		switch( LinSkinAppMode )
		{
		case MODE_SKIN_SELECTION:
			if ((button == 1) || (button == 3))		// left or right mouse button
			{
				int squareCenterX = int_abs((int) (winX + m_prevWinX)/2);
				int squareCenterY = int_abs((int) (winY + m_prevWinY)/2);
				int width = int_abs(winX - m_prevWinX);
				int height = int_abs(winY - m_prevWinY);

				doSkinSelection(view, squareCenterX, squareCenterY, width, height, button, 1);

				// draw the mouse drag box
				m_showDragBox = true;
				m_boxX2 = winX;
				m_boxY2 = winY;
				dance::AllViews->postRedisplay();
			}
			break;
		case MODE_ELLIPSE_SELECTION:
			// must be left mouse and must be in ellipse selecting mode and must have a ellipse already picked
			if ((button == 1) && (m_selectedEllipse != -1) && (m_selectedEllipseAxis != -1))
			{
				view->getWorldCoords(prevCursorPosn,m_prevWinX, m_prevWinY, -1.0);
				view->getWorldCoords(cursorPosn,winX,winY, -1.0);

				int l = m_selectedEllipse;			// indicates the link of the ellipse in question
				Link* link = m_influence->getLink(l);

				if (m_selectedEllipseType == ELLIPSE_SMALL_ONLY)
				{
					a_b_c[0] = m_smallEllipseAttr[(3 * l)];
					a_b_c[1] = m_smallEllipseAttr[(3 * l) + 1];
					a_b_c[2] = m_smallEllipseAttr[(3 * l) + 2];
				}
				else
				{
					a_b_c[0] = m_largeEllipseAttr[(3 * l)];
					a_b_c[1] = m_largeEllipseAttr[(3 * l) + 1];
					a_b_c[2] = m_largeEllipseAttr[(3 * l) + 2];
				}

				link->getWorldCoord(ellWorld, a_b_c);
								
				double mouse_vector[3];
				mouse_vector[0] = cursorPosn[0] - prevCursorPosn[0];
				mouse_vector[1] = cursorPosn[1] - prevCursorPosn[1];
				mouse_vector[2] = cursorPosn[2] - prevCursorPosn[2];

				// a hacked suggested by yml
				if ((m_selectedEllipseAxis == 0) && (fabs(mouse_vector[0]) >= MAX(2*fabs(ellWorld[0]), 2)))
				{
					m_prevWinX = winX;
					m_prevWinY = winY;
					return;
				}
				if ((m_selectedEllipseAxis == 1) && (fabs(mouse_vector[1]) >= MAX(2*fabs(ellWorld[1]), 2)))
				{
					m_prevWinX = winX;
					m_prevWinY = winY;
					return;
				}
				if ((m_selectedEllipseAxis == 2) && (fabs(mouse_vector[2]) >= MAX(2*fabs(ellWorld[2]), 2)))
				{
					m_prevWinX = winX;
					m_prevWinY = winY;
					return;
				}

				if (m_selectedEllipseAxis == 0)
					ellWorld[0] += mouse_vector[0];
				else if (m_selectedEllipseAxis == 1)
					ellWorld[1] += mouse_vector[1];
				else
					ellWorld[2] += mouse_vector[2];

				link->getLocalCoord(ellLocal, ellWorld);

				if (m_selectedEllipseType == ELLIPSE_SMALL_ONLY)
				{
					if ((ellLocal[0] > 0) && (m_selectedEllipseAxis == 0))
						m_smallEllipseAttr[(3 * l)] = ellLocal[0];
					if ((ellLocal[1] > 0) && (m_selectedEllipseAxis == 1))
						m_smallEllipseAttr[(3 * l) + 1] = ellLocal[1];
					if ((ellLocal[2] > 0) && (m_selectedEllipseAxis == 2))
						m_smallEllipseAttr[(3 * l) + 2] = ellLocal[2];

					if (m_skinWindow != NULL)
					{
						/* TODO: Restore this functionality
						m_skinWindow->updateSelectedSmallEllipseAttrib(m_smallEllipseAttr[(3 * l)],
																	m_smallEllipseAttr[(3 * l) + 1],
																	m_smallEllipseAttr[(3 * l) + 2]);
						*/
					}
				}
				else
				{
					if ((ellLocal[0] > 0) && (m_selectedEllipseAxis == 0))
						m_largeEllipseAttr[(3 * l)] = ellLocal[0];
					if ((ellLocal[1] > 0) && (m_selectedEllipseAxis == 1))
						m_largeEllipseAttr[(3 * l) + 1] = ellLocal[1];
					if ((ellLocal[2] > 0) && (m_selectedEllipseAxis == 2))
						m_largeEllipseAttr[(3 * l) + 2] = ellLocal[2];

					if (m_skinWindow != NULL)
					{
						/* TODO: Restore this functionality
						m_skinWindow->updateSelectedLargeEllipseAttrib(m_largeEllipseAttr[(3 * l)],
																	m_largeEllipseAttr[(3 * l) + 1],
																	m_largeEllipseAttr[(3 * l) + 2]);
						*/
					}
				}
			}

			m_prevWinX = winX;
			m_prevWinY = winY;
			dance::AllViews->postRedisplay();
		break;
		}
	}
}


// Start the interaction and set the local mode.
// If the interaction finishes here we return 0
// else we return 1
int LinearSkinning::interactStart(Event *event)
{
//	return 0;

    	//int *item = event->pickItem ;
	double depth = event->Window->getDepth(event->winX,event->winY);
	if (depth == 1.0) {
		depth = 0.5; // half way point in viewing volume
	}
	else {// Selected something in the depth buffer. 
		// Choose point in depth buffer.
		depth = -1.0;
	}

	event->Window->getWorldCoords(dance::CursorPosn,event->winX,event->winY, depth);

	switch( LinSkinAppMode )
    {
	case MODE_SKIN_SELECTION:				// added by achu
		if (event->getEventType() == fltk::PUSH)
		{
			if (fltk::event_button() == 1 || fltk::event_button() == 3)
			{
				doSkinSelection(event->Window, event->winX, event->winY, 7.0, 7.0, fltk::event_button(), 0);
			}
			else if (fltk::event_button() == 2 && m_skin != NULL)
			{
				for (unsigned int i = 0; i < m_selectSkinVertices.size(); i++)
				{
					int v = m_selectSkinVertices[i];

					m_skinSelectFlag[v] = false;
				}

				m_selectSkinVertices.clear();
			}
		}
		break;
    }

    return 1 ;
}


// return 0 means that the other interact on the stack can continue
// return -1 means that the other interacts will be stalled
int LinearSkinning::interact(Event *event)
{
	int eventType = event->getEventType();
	int continueFlag = 0;

	switch (eventType)
	{
		case KEY:
			KeyboardCB(fltk::event_key(), 0, 0);
			break;
		case DRAG:
			MotionCB(event);
			break;
		case PUSH:
			MouseCB(event, false);
			break;
	//	case MOVE:
	//		PassiveMotionCB(Fl::event_x(),Fl::event_y());
	//		break;
		case RELEASE:
 			MouseCB(event, true);
			break;
	}

	//dance::AllViews->postRedisplay();

	if ((LinSkinAppMode == this->MODE_SKIN_SELECTION) || (LinSkinAppMode == this->MODE_ELLIPSE_SELECTION))
		continueFlag = -1;

	return continueFlag;
}

int LinearSkinning::interactEnd(Event *event)
{
    return 1 ;
}

// mode: 0 for clicking, 1 for click and drag
void LinearSkinning::doSkinSelection(DView *view, int x, int y, double delX, double delY, int button, int mode)
{
	if (m_showSkin && (m_skin != NULL))
	{
		int shortestVertex;
		double closest;
		double distance;

		if ((m_skinDisplayMode == this->SKIN_DISPLAY_UNASSIGNED) || (m_skinDisplayMode == this->SKIN_DISPLAY_MAPPED))
		{
			// Set up selection buffer.
			GLuint SelectBuffer[512];
			glSelectBuffer(512,SelectBuffer);

			// Begin selecting.
			glRenderMode(GL_SELECT);
			glInitNames();

			//make sure delX and delY are above 0.0
			delX = (delX == 0.0 ? 1.0 : delX);
			delY = (delY == 0.0 ? 1.0 : delY);

			view->pickProjection(x,y,delX,delY);
			view->PositionCamera();

			//displayUnassignedSkin(s, GL_SELECT);

			// MODIFIED: Model Implementation by Jonathan Garcia
			//display all the vertices in selecting mode
			double* vertices = m_skin->vertices;
			int numVertices = m_skin->numvertices;

			glPushName((GLuint) -1);

			// left button
			if (button == 1)
			{
				for (int v = 0; v < numVertices; v++)
				{
					if (m_skinSelectFlag[v] == false)
					{
						glLoadName(v);
						glBegin(GL_POINTS);
						glVertex3d(vertices[v*3], vertices[v*3+1], vertices[v*3+2]);
						glEnd();
					}
				}
			}
			else	// right button
			{
				for (int v = 0; v < numVertices; v++)
				{
					if (m_skinSelectFlag[v] == true)
					{
						glLoadName(v);
						glBegin(GL_POINTS);
						glVertex3d(vertices[v*3], vertices[v*3+1], vertices[v*3+2]);
						glEnd();
					}
				}
			}
			glPopName();
			glFlush() ;

			// Process hits.
			int hits = glRenderMode(GL_RENDER);

			view->setProjection();

			switch (mode)
			{
			// first time a button is clicked
			case 0:
				if (hits > 0 )
				{
					double* vertices = m_skin->GetVertices();
					Vector viewCoord = { 0, 0, 0 };
					int v;
					int hp = 0;
					bool found = false;

					for (int j = 0; j < hits; j++)
					{
						hp += 3;
						v = SelectBuffer[hp];
						Vector currVert;
						setVector(currVert, vertices[v*3], vertices[v*3+1], vertices[v*3+2]);
						view->getWindowCoords(currVert, viewCoord);
						distance = abs(((viewCoord[0] - x)*(viewCoord[0] - x)) + ((viewCoord[1] - y)*(viewCoord[1] - y)));

						if (j == 0)
						{
							closest = distance;
							shortestVertex = v;
							found = true;
						}
						else if (distance < closest)
						{
							closest = distance;
							shortestVertex = v;
						}
						hp++;
					}

					if (found)
					{
						// left button
						if (button == 1)
						{
							m_selectSkinVertices.push_back(shortestVertex);
							m_skinSelectFlag[shortestVertex] = true;	// mark the vertex as currently selected

							// a window is made
							if (m_skinWindow)
							{
								((SkinningWindow *) m_skinWindow)->tableWindow->addSelectedVertex(shortestVertex);
							}
						}
						// right button
						else
						{
							std::vector<int>::iterator vertIter;

							vertIter = m_selectSkinVertices.begin();
							for (; vertIter != m_selectSkinVertices.end(); vertIter++)
							{
								if ((*vertIter) == shortestVertex)
									break;
							}

							m_selectSkinVertices.erase(vertIter);
 							m_skinSelectFlag[shortestVertex] = false; // mark the vertex as currently not selected

							// a window is made
							if (m_skinWindow)
							{
								((SkinningWindow *) m_skinWindow)->tableWindow->removeSelectedVertex(shortestVertex);
							}
						}
					} // if found
				} // if there are hits
				break;

			// the button is being dragged.
			case 1:
				if (hits > 0 )
				{
					int v;
					int hp = 0;

					for (int j = 0; j < hits; j++)
					{
						bool found = false;
						hp += 3;
						v = SelectBuffer[hp];

						std::vector<int>::iterator vertIter;

						vertIter = m_selectSkinVertices.begin();
						for (; vertIter != m_selectSkinVertices.end(); vertIter++)
						{
							if ((*vertIter) == v)
							{
								found = true;
								break;
							}
						}

						// if the vertex was already selected and the button is left mouse
						if ((!found) && (button == 1))
						{
							m_selectSkinVertices.push_back(v);
							m_skinSelectFlag[v] = true;	// mark the vertex as currently selected

							// a window is made
//							if (m_skinWindow)
//							{
//								((SkinningWindow *) m_skinWindow)->addSelectedVertex(v);
//							}
						}
						// else if the vertex was not selected and the button is right mouse
						else if (found && (button == 3))
						{
							m_selectSkinVertices.erase(vertIter);
 							m_skinSelectFlag[v] = false; // mark the vertex as currently not selected

							// a window is made
//							if (m_skinWindow)
//							{
//								((SkinningWindow *) m_skinWindow)->removeSelectedVertex(v);
//							}
						}

						hp++;
					}
				} // if there are hits
				break;
			} // switch on mode
		} // if unassigned skins are shown
	} // if skins exist
}

void LinearSkinning::detachSkin()
{
	if (m_skin != NULL)
	{
		// make the skin geometry not mutable
		m_skin->setMutable(false);
		setDisplayMode("normal");
	}

	m_skinWeights.clear();
	m_skinWeightLinks.clear();
	m_skinTotalLinks.clear();
	m_skinSelectFlag.clear();

	if (m_skinVertices != NULL)
	{
		delete 	[] m_skinVertices;
		m_skinVertices = NULL;
	}

	if (m_originalVertCoord != NULL)
	{
		delete 	[] m_originalVertCoord;
		m_originalVertCoord = NULL;
	}

	if (m_bindingPoseState != NULL)
	{
		delete 	[] m_bindingPoseState;
		m_bindingPoseState = NULL;
	}

	if (m_currentState != NULL)
	{
		delete [] m_currentState;
		m_currentState = NULL;
	}

	m_skin = NULL;
	danceInterp::OutputMessage("Skin Detached\n");
}

// basic skinning algo.  assigns skin via ellipses
bool LinearSkinning::attachSkinViaEllipses(const char* skinName)
{
	// clear old instance of skin if exists
	detachSkin();

//	IndexedFaceSet* skin = (IndexedFaceSet*)dance::AllGeometry->get(skinName);
	Model* skin = (Model*)dance::AllGeometry->get(skinName);
	if (skin == NULL)
	{
		danceInterp::OutputMessage("Skin %s not found in geometry list...\n", skinName);
		return false;
	}

	if (m_influence == NULL)
	{
		danceInterp::OutputMessage("Skin %s not found in geometry list...\n", skinName);
		return false;
	}

	danceInterp::OutputMessage("Binding skin...");

	// MODIFIED: Model implementation by Jonathan Garcia
	double* vertices = skin->GetVertices();
	int numVertices = skin->numvertices;

	m_skin = skin;
	skin->applyTransMatrix();
	
	// make the skin geometry mutable
	m_skin->setMutable(true);

	m_skinWeights.reserve(5 * numVertices); // each skin vertex is influenced by up to 5 joints
	m_skinWeights.resize(5 * numVertices);
	m_skinWeightLinks.reserve(5 * numVertices);
	m_skinWeightLinks.resize(5 * numVertices);
	m_skinTotalLinks.reserve(numVertices);
	m_skinTotalLinks.resize(numVertices);
	m_skinSelectFlag.reserve(numVertices);
	m_skinSelectFlag.resize(numVertices);
	m_skinVertices = new Vector[5 * numVertices]; // vertices in the link's coordinate frame
	m_originalVertCoord = new Vector[numVertices]; // original postion of vertices

	// save the binding pose state of the influencing articulated object
	setBindingPoseState();

	int numLinks = m_influence->m_numLinks;

	for (int v = 0; v < numVertices; v++)
	{
		// remember the original position of the vertex
		// MODIFIED: Model implementation by Jonathan Garcia
		setVector(m_originalVertCoord[v], vertices[v*3], vertices[v*3+1], vertices[v*3+2]);

		m_skinTotalLinks[v] = 0;
		m_skinSelectFlag[v] = false;

		// initialize.  set all links to -1 and all weights to 0
		for (int j = 0; j < 5; j++)
		{
			m_skinWeightLinks[(5*v)+j] = -1;
			m_skinWeights[(5*v)+j] = 0;
		}

		Vector s1;
		setVector(s1, vertices[v*3], vertices[v*3+1], vertices[v*3+2]);
		for (int l = 0; l < numLinks; l++)
		{
			Link* link = m_influence->getLink(l);
//			double invMatrix[4][4];
//			link->getInvTransMat(invMatrix);
//			transformPoint_mat(s1, invMatrix);

			float a = m_smallEllipseAttr[3*l];
			float b = m_smallEllipseAttr[(3*l)+1];
			float c = m_smallEllipseAttr[(3*l)+2];
			Vector localSkinVertex;
			link->getLocalCoord(localSkinVertex, s1);

			float x = (float)localSkinVertex[0];
			float y = (float)localSkinVertex[1];
			float z = (float)localSkinVertex[2];

			/*
			// hack to setup a clipping plane at x = 0
			Vector pp;
			link->getPosition(pp);
			if ((pp[0] * s1[0]) < 0)
			{
				continue;
			}
			*/

			if (checkEllipse(a, b, c, x, y, z))
			{
				m_skinWeightLinks[5 * v] = l;
				m_skinTotalLinks[v] += 1;
				m_skinWeights[5 * v] = 1.0;
				VecCopy(m_skinVertices[5 * v], localSkinVertex);
				break;
			}
		}

		setVector(s1, vertices[v*3], vertices[v*3+1], vertices[v*3+2]);
		for (int l = 0; l < numLinks; l++)
		{
			if (m_skinTotalLinks[v] == 5)
			{
				break;
			}

			Link* link = m_influence->getLink(l);

			float a = m_largeEllipseAttr[3*l];
			float b = m_largeEllipseAttr[(3*l)+1];
			float c = m_largeEllipseAttr[(3*l)+2];
			Vector localSkinVertex;
			link->getLocalCoord(localSkinVertex, s1);

			float x = (float)localSkinVertex[0];
			float y = (float)localSkinVertex[1];
			float z = (float)localSkinVertex[2];

			/*
			// hack to setup a clipping plane at x = 0
			Vector pp;
			link->getPosition(pp);
			if ((pp[0] * s1[0]) < 0)
			{
				continue;
			}
			*/

			if (checkEllipse(a, b, c, x, y, z))
			{
				if (m_skinWeightLinks[5 * v] == -1)			// no small ellipse was found
				{
					if (m_skinWeightLinks[(5 * v) + 1] == -1)	// no large ellipse so far too
					{
						m_skinWeightLinks[(5 * v) + 1] = l;
						m_skinTotalLinks[v] += 1;
						m_skinWeights[(5 * v) + 1] = 1.0;
						VecCopy(m_skinVertices[(5 * v) + 1], localSkinVertex);
					}
					else
					{
						int newLinkIndex = m_skinTotalLinks[v] + 1;
						m_skinWeightLinks[(5 * v) + newLinkIndex] = l;
						m_skinTotalLinks[v] += 1;
						float weight = 1.0f / (m_skinTotalLinks[v]);
						
						for (int j = 1; j <= newLinkIndex; j++)
						{
							m_skinWeights[(5 * v) + j] = weight;
						}

						VecCopy(m_skinVertices[(5 * v) + newLinkIndex], localSkinVertex);
					}
				}
				else
				{
					if (m_skinWeightLinks[5 * v] == l)
					{
						continue;
					}

					if (m_skinWeightLinks[(5 * v) + 1] == -1)
					{
						m_skinWeights[(5 * v)] = m_ellipseFraction;

						m_skinWeightLinks[(5 * v) + 1] = l;
						m_skinTotalLinks[v] += 1;
						m_skinWeights[(5 * v) + 1] = (1 - m_ellipseFraction);
						VecCopy(m_skinVertices[(5 * v) + 1], localSkinVertex);
					}
					else
					{
						int newLinkIndex = m_skinTotalLinks[v];
						m_skinWeightLinks[(5 * v) + newLinkIndex] = l;
						m_skinTotalLinks[v] += 1;

						m_skinWeights[(5 * v)] *= m_ellipseFraction;
						float weight = (1.0f - m_skinWeights[(5 * v)]) / (m_skinTotalLinks[v] - 1);
						
						for (int j = 1; j <= newLinkIndex; j++)
						{
							m_skinWeights[(5 * v) + j] = weight;
						}

						VecCopy(m_skinVertices[(5 * v) + newLinkIndex], localSkinVertex);
					}
				} //else
			} //if
		} //links for

	} //vertices for

	// make the skin geometry mutable
	m_skin->setMutable(true);

	dance::AllViews->postRedisplay();
	return true;
}

bool LinearSkinning::checkEllipse(float a, float b, float c, float x, float y, float z)
{
	float result;
	result = ((x*x)/(a*a)) + ((y*y)/(b*b)) + ((z*z)/(c*c));

	return ((result <= 1) ? true : false);
}

void LinearSkinning::adjustSkin()
{
	if (m_skin == NULL)
	{
		danceInterp::OutputMessage("Error: No skins are attached yet");
		return;
	}

	// MODIFIED: Model implementation by Jonathan Garcia
	// for each vertex, adjust the location based on the weighted matrix of the corresponding joint
	double* vertices = m_skin->vertices;
	int numVertices = m_skin->numvertices;
	int numLinks = m_influence->getNumLinks();

	// get the transformation matrices of all the the links
	//int numJoints = m_influence->getNumJoints();
		/*	double** m = new double*[numJoints];
		for (int j = 0; j < numJoints; j++)
		{
			double temp[4][4];
			//getJoint(j)->getOutboardLink()->getWTransMat(temp);
			getJoint(j)->getOrientation(temp);
			m[j] = new double[16];
			for (int r = 0; r < 4; r++)
				for (int c = 0; c < 4; c++)
					m[j][r * 4 + c] = temp[r][c];
		}
		*/

	Link **links =m_influence->getLinks();
	for (int l = 0; l < numLinks; l++)
	{
		links[l]->getWTransMat(tempMatrix[l]);
	}

	for (int i = 0; i < numVertices; i++)
	{
		int x = i*3;
		int y = i*3 + 1;
		int z = i*3 + 2;
		
		vertices[x] = 0.0;
		vertices[y] = 0.0;
		vertices[z] = 0.0;

		for (int j = 0; j < 5; j++)
		{
			int index = (5 * i) + j;
			
			int li = m_skinWeightLinks[index];
			if (li == -1)
				continue;

			float we = m_skinWeights[index];
			if (we == 0)
				continue;

			// determine the vertices
			Vector po;
			VecCopy(po, m_skinVertices[index]);
			
			transformPoint_mat(po, tempMatrix[li]);

			// determine the transformation matrix as a weighted sum of the appropriate joint transformation matrices
			vertices[x] += we * po[0];
			vertices[y] += we * po[1];
			vertices[z] += we * po[2];
		}
	}
}

bool LinearSkinning::loadEllipse (const char *filename)
{
	if (m_influence == NULL)
	{
		danceInterp::OutputMessage("Error: Modifier is not yet attached to any system");
		return false;
	}

	if (!filename)
	{
		danceInterp::OutputMessage("Error: please specify a filename");
		return false;
	}
	
	FILE *fpFileStream;
	int numLinks = m_influence->m_numLinks;
	int currLink;
	float small_x, small_y, small_z;
	float large_x, large_y, large_z;

	fpFileStream = fopen (filename, "r");

	if (fpFileStream == NULL)
	{
		danceInterp::OutputMessage("Error: opening ellipse file");
		return false;
	}

	int linksInFile = 0;
	fscanf(fpFileStream, "%f\n", &m_ellipseFraction);
	fscanf(fpFileStream, "%d\n", &linksInFile);
	m_smallEllipseAttr.clear();
	m_largeEllipseAttr.clear();

	for (int l = 0; l < numLinks; l++)
	{
		fscanf(fpFileStream, "%d", &currLink);
		fscanf(fpFileStream, "%f %f %f %f %f %f\n", &small_x, &small_y, &small_z, &large_x, &large_y, &large_z);
		
//		fscanf(fpFileStream, "%f %f %f %f %f %f\n",
//			&(m_smallEllipseAttr[(3 * currLink)]), &(m_smallEllipseAttr[(3 * currLink) + 1]), &(m_smallEllipseAttr[(3 * currLink) + 2]),
//			&(m_largeEllipseAttr[(3 * currLink)]), &(m_largeEllipseAttr[(3 * currLink) + 1]), &(m_largeEllipseAttr[(3 * currLink) + 2]));

		m_smallEllipseAttr.push_back(small_x);
		m_smallEllipseAttr.push_back(small_y);
		m_smallEllipseAttr.push_back(small_z);

		m_largeEllipseAttr.push_back(large_x);
		m_largeEllipseAttr.push_back(large_y);
		m_largeEllipseAttr.push_back(large_z);
	}

	fclose(fpFileStream);

	m_ellipse = true;
	setEllipseDisplayMode(LinearSkinning::ELLIPSE_BOTH, LinearSkinning::ELLIPSE_DISPLAY_MESH, -1);
	dance::AllViews->postRedisplay();

	m_ellipseLoaded = true;
	return true;
}

void LinearSkinning::saveEllipse (const char *filename)
{
	if (m_ellipse == false)
	{
		danceInterp::OutputMessage("Error: call ellipse to create first");
		return;
	}

	if (!filename)
	{
		danceInterp::OutputMessage("Error: please specify a filename");
		return;
	}
	
	FILE *fpFileStream;
	int numLinks = m_influence->m_numLinks;

	fpFileStream = fopen (filename, "w+");
	fprintf(fpFileStream, "%f\n%d\n", m_ellipseFraction, numLinks);
	
	for (int l = 0; l < numLinks; l++)
	{
		fprintf(fpFileStream, "%d %f %f %f %f %f %f\n", l,
			m_smallEllipseAttr[(3 * l)], m_smallEllipseAttr[(3 * l) + 1], m_smallEllipseAttr[(3 * l) + 2],
			m_largeEllipseAttr[(3 * l)], m_largeEllipseAttr[(3 * l) + 1], m_largeEllipseAttr[(3 * l) + 2]);
	}

	fflush(fpFileStream);
	fclose(fpFileStream);
}

void LinearSkinning::saveSkin (const char *filename)
{
	if (m_skin == NULL)
	{
		danceInterp::OutputMessage("Error: No skins are attached yet");
		return;
	}

	if (!filename)
	{
		danceInterp::OutputMessage("Error: please specify a filename");
		return;
	}

	FILE *fpFileStream;
	fpFileStream = fopen (filename, "w+");

	int numVertices = m_skin->numvertices;
	int numLinks = m_influence->m_numLinks;

	// make sure that the skin has the same number of vertices thoughout uses
	fprintf(fpFileStream,"TOTAL_LINKS: %d\n\n", numLinks);
	fprintf(fpFileStream, "TOTAL_VERTS: %d\n\n", numVertices);
	
	for (int v = 0; v < numVertices; v++)
	{
		int numAttachedLinks = m_skinTotalLinks[v];
		fprintf(fpFileStream, "CURR_VERT: %d\n", v);
		fprintf(fpFileStream, "TOTAL_INFLUENCES: %d\n", numAttachedLinks);
		for (int i = 0; i < 5; i++)
		{
			int link = m_skinWeightLinks[(5 * v) + i];
			if (link != -1)
			{
				float weight = m_skinWeights[(5 * v) + i];
				Vector localCoord;
				VecCopy(localCoord, m_skinVertices[(5 * v) + i]);
				fprintf(fpFileStream, "\tLINK: %d WEIGHT: %f LOCAL_COORD: %lf %lf %lf\n", link, weight, localCoord[0], localCoord[1], localCoord[2]);
			}
		}
	}

	fflush(fpFileStream);
	fclose(fpFileStream);
}

bool LinearSkinning::loadSkin (const char *filename, const char* skinName)
{
	if (!filename)
	{
		danceInterp::OutputMessage("Error: please specify a filename");
		return false;
	}

	if (m_influence == NULL)
	{
		danceInterp::OutputMessage("Error: Modifier is not yet attached to any system");
		return false;
	}

	char tempStr[20];
	int tempNumber;
	FILE *fpFileStream;


	fpFileStream = fopen (filename, "r");

	if (fpFileStream == NULL)
	{
		danceInterp::OutputMessage("Error: opening skin file");
		return false;
	}

	detachSkin();

	int numVertices;
//	int tempNumLinks;
//	int tempNumVertices;

	// MODIFIED: Model implementation by Jonathan Garcia
	Model *skin = (Model*)dance::AllGeometry->get(skinName);
	if (skin == NULL)
	{
			danceInterp::OutputMessage("Skin %s not found in geometry list...\n", skinName);
			return false;
	}

	// MODIFIED: Model implementation by Jonathan Garcia
	numVertices = skin->numvertices;
	//fscanf(fpFileStream, "%s %d", tempStr, &tempNumLinks);

/*	fscanf(fpFileStream, "%s %d", tempStr, &tempNumVertices);

	//if (tempNumLinks != m_influence->m_numLinks)
//	{
//		danceInterp::OutputMessage("Number of links for system % mismatch\n", m_influence->getName());
//		return false;
//	}

	if (tempNumVertices != numVertices)
	{
		danceInterp::OutputMessage("Number of vertices for skin % mismatch: desired = %d, found = %d\n", skinName, numVertices, tempNumVertices);
		return false;
	}
*/
	danceInterp::OutputMessage("Loading skin...");

	double* vertices = skin->vertices;

	m_skin = skin;
	skin->applyTransMatrix();
	// make the skin geometry mutable
	m_skin->setMutable(true);

	m_skinWeights.reserve(5 * numVertices); // each skin vertex is influenced by up to 3 joints
	m_skinWeights.resize(5 * numVertices); 
	m_skinWeightLinks.reserve(5 * numVertices);
	m_skinWeightLinks.resize(5 * numVertices);
	m_skinTotalLinks.reserve(numVertices);
	m_skinTotalLinks.resize(numVertices);
	m_skinSelectFlag.reserve(numVertices);
	m_skinSelectFlag.resize(numVertices);
	m_skinVertices = new Vector[5 * numVertices]; // vertices in the link's coordinate frame
	m_originalVertCoord = new Vector[numVertices]; // original postion of vertices

	// save the binding pose state of the influencing articulated object
	setBindingPoseState();

	// checksum: total links and vertices
	int totalLinks = 0;
	int totalVertices = 0;
	fscanf(fpFileStream, "%s %d", tempStr, &totalLinks);
	fscanf(fpFileStream, "%s %d", tempStr, &totalVertices);

	for (int v = 0; v < numVertices; v++)
	{
		// remember the original position of the vertex
		setVector(m_originalVertCoord[v], vertices[v*3], vertices[v*3+1], vertices[v*3+2]);

		m_skinTotalLinks[v] = 0;
		m_skinSelectFlag[v] = false;

		fscanf(fpFileStream, "%s %d", tempStr, &tempNumber);
		fscanf(fpFileStream, "%s %d", tempStr, &(m_skinTotalLinks[v]));

		int numWeights = 0;
		for (int i = 0; i < m_skinTotalLinks[v]; i++)
		{
			Vector localCoord;

			fscanf(fpFileStream, "%s %d", tempStr, &(m_skinWeightLinks[(5 * v) + i]));
			fscanf(fpFileStream, "%s %f", tempStr, &(m_skinWeights[(5 * v) + i]));
			fscanf(fpFileStream, "%s %lf %lf %lf", tempStr, &(localCoord[0]), &(localCoord[1]), &(localCoord[2]));
			VecCopy(m_skinVertices[(5 * v) + i], localCoord);
			numWeights++;
		}

		while (numWeights < 5) // fill the remaining values with default data
		{
			m_skinWeightLinks[(5 * v) + numWeights] = -1;
			m_skinWeights[(5 * v) + numWeights] = 0;
			numWeights++;
		}
	}

	danceInterp::OutputMessage("Skin %s loaded for modifier %s\n", skinName, this->getName());
	fclose(fpFileStream);

	m_skinLoaded = true;
	m_skinAttached = true;
	return true;
}

void LinearSkinning::setSelectedEllipse(int type, int link)
{
	if (LinSkinAppMode == this->MODE_ELLIPSE_SELECTION)
	{
		m_selectedEllipse = link;
		m_selectedEllipseType = type;
	
		dance::AllViews->postRedisplay();
	}
}

fltk::Widget*  LinearSkinning::getInterface()
{
	if (this->m_skinWindow == NULL)
	{
		m_skinWindow = new SkinningWindow(this, 0, 0, 740, 680, this->getName());
	}

	return m_skinWindow;
}

void LinearSkinning::AfterAllSimStep(double time, double step)
{
	modify();
}

void LinearSkinning::assignSkinAutomatically()
{
	if (this->m_skin == NULL)
	{
		danceInterp::OutputMessage("Cannot assign unmapped skin - no skin has been attached yet.");
		return;
	}
	else
	{
		// assigns all unmapped skin to the closest link
		double* vertices = m_skin->GetVertices();
		int numVertices = m_skin->numvertices;
		int numLinks = this->m_influence->getNumLinks();
		Link** links = this->m_influence->getLinks();
		int numAssigned = 0;
		for (int i = 0; i < numVertices; i++)
		{
			double distance = 999999999;
			int linkMap = 0;
			// is the skin unmapped?
			if (this->m_skinTotalLinks[i] == 0)
			{
				// calculate the distance from each link
				// map fully to the link closest to this vertex
				for (int l = 0; l < numLinks; l++)
				{
					Vector linkPos;
					Vector zero = {0.0, 0.0, 0.0};
					links[l]->getWorldCoord(linkPos, zero);
					double tempDistance = sqrt((linkPos[0] - vertices[i*3]) * (linkPos[0] - vertices[i*3]) + (linkPos[1] - vertices[i*3+1]) * (linkPos[1] - vertices[i*3+1]) + (linkPos[2] - vertices[i*3+2]) * (linkPos[2] - vertices[i*3+2]));
					if (tempDistance < distance)
					{
						distance = tempDistance;
						linkMap = l;
					}
				}
				// assign the vertex to that closest link
				m_skinTotalLinks[i] = 1;
				m_skinWeightLinks[i * 5] = linkMap;
				m_skinWeights[i * 5] = 1.0;
				Vector currVertex;
				setVector(currVertex, vertices[i*3], vertices[i*3+1], vertices[i*3+2]);
				Vector localSkinVertex;
				links[linkMap]->getLocalCoord(localSkinVertex, currVertex);
				VecCopy(m_skinVertices[i * 5], localSkinVertex);
				numAssigned++;
			}
		}
		danceInterp::OutputMessage("Assigned %d unmapped vertices to their closest link.", numAssigned);
	}
	dance::Refresh();
}

ArticulatedObject* LinearSkinning::getInfluence()
{
	return m_influence;
}

void LinearSkinning::setInfluence(ArticulatedObject* ao)
{
	if (m_influence != NULL)
	{
		m_influence->removeModifier(this);
		this->removeDependency(m_influence);
	}

	m_influence = ao;
	if (this->m_skinWindow != NULL)
		this->m_skinWindow->updateGUI();
}

void LinearSkinning::setSkin(Model* model)
{
	if (m_skin != NULL)
	{
		removeDependency(m_skin);
	}

	m_skin = model;

	this->addDependency(model);

	if (this->m_skinWindow != NULL)
		this->m_skinWindow->updateGUI();

}

Model* LinearSkinning::getSkin()
{
	return m_skin;
}

void LinearSkinning::onDependencyRemoval(DObject* obj)
{
	if (obj == m_influence)
	{
		this->m_influence = NULL;
	}
	else if (obj == m_skin)
	{
		m_skin = NULL;
	}
}

void LinearSkinning::save(int mode, std::ofstream& file)
{
	char buff[1024];

	if (mode == 0)
	{
		file << "dance.instance(\"LinearSkinning\", \"" << this->getName() << "\")" << std::endl;
	}
	else if (mode == 1)
	{
	}
	else if (mode == 2)
	{
		ArticulatedObject* ao = this->getInfluence();
		if (ao != NULL)
		{
			sprintf(buff, "\"assignToSystem\", \"%s\"", ao->getName());
			pythonSave(file, buff);
		}
		
		Model* model = this->getSkin();
		if (model != NULL)
		{
			sprintf(buff, "\"set_skin\", \"%s\"", model->getName());
			pythonSave(file, buff);
			
			// save the skin
			if(m_skin != NULL)
			{
				string skinname = this->getName();
				skinname.append(".skin");
				this->saveSkin((char*) skinname.c_str());
				sprintf(buff, "\"load\", \"skinMap\", \"%s\", \"%s\"", skinname.c_str(), m_skin->getName());
				pythonSave(file, buff);
			}
		}
		// save ellipse
		if(m_ellipse)
		{
			string ellipseName = this->getName();
			ellipseName.append(".ell");
			this->saveEllipse((char*) ellipseName.c_str());
			sprintf(buff, "\"load\", \"ellipse\", \"%s\"", ellipseName.c_str());
			pythonSave(file, buff);
		}
	}

	DModifier::save(mode, file);

}

int LinearSkinning::getNumPluginDependents()

{

        return 3;

}



const char* LinearSkinning::getPluginDependent(int num)

{

        if (num == 0)

                return "ArticulatedObject";

        else if (num == 1)

                return "Model";

        else if (num == 2)

                return "Capsule";
        else

                return NULL;
}


