/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "SkinTableWindow.h"
#include "dance.h"

using namespace fltk;

SkinTableWindow::SkinTableWindow(SkinningWindow *sWin, int x, int y, int w, int h, const char *l)
	: DoubleBufferWindow(x, y, w, h, l)
{
	m_skinWindow = sWin;
	m_tableType = COMPLETE_TABLE;

	this->begin();
	weightInput = new FloatInput(w - 170, 10, 50, 20, "Weight:");
	weightInput->value(0.0);
	weightInput->deactivate();

	updateColButton = new Button(w - 110, 10, 100, 20, "Update Column");
	updateColButton->callback(updateAllCol_button_cb, this);
	updateColButton->deactivate();

	weightTable = new SkinTable(10, 40, w - 20, h - 50, "Complete Skin Weight Table");
	weightTable->align(ALIGN_LEFT | ALIGN_TOP);
	weightTable->deactivate();
	weightTable->hide();
	weightTable->end();

	selectedTable = new SelectedSkinTable(10, 40, w - 20, h - 50, "Selected Skin Weight Table");
	selectedTable->align(ALIGN_LEFT | ALIGN_TOP);
	selectedTable->deactivate();
	selectedTable->hide();
	selectedTable->end();

	this->end();
	this->callback(onDestroyWindow_cb, this);
}

void SkinTableWindow::updateGUI()
{
	int numVertices = m_skinWindow->skin->m_skin->numvertices;
	int numLinks =  m_skinWindow->skin->m_influence->m_numLinks;
	int selectedVertices = m_skinWindow->skin->m_selectSkinVertices.size();

	// initialize the weight tables
	weightTable->setSkin(m_skinWindow->skin);
	weightTable->selection_color(fltk::YELLOW);
	weightTable->when(fltk::WHEN_RELEASE);
	weightTable->rows(numVertices);
	weightTable->cols(numLinks);
	weightTable->col_header(true);
	weightTable->col_resize(true);
	weightTable->row_header(true);
	weightTable->row_resize(true);
	weightTable->activate();
	weightTable->show();

	selectedTable->setSkin(m_skinWindow->skin);
	selectedTable->selection_color(fltk::YELLOW);
	selectedTable->when(fltk::WHEN_RELEASE);
	selectedTable->rows(selectedVertices);
	selectedTable->cols(numLinks);
	selectedTable->col_header(true);
	selectedTable->col_resize(true);
	selectedTable->row_header(true);
	selectedTable->row_resize(true);
	selectedTable->deactivate();
	selectedTable->hide();

	switch(m_tableType)
	{
		default:
		case COMPLETE_TABLE:
			weightTable->show();
			weightTable->activate();

			selectedTable->show();
			selectedTable->deactivate();
			selectedTable->hide();

			weightInput->deactivate();
			updateColButton->deactivate();
			break;

		case PICKED_TABLE:
			weightTable->show();
			weightTable->deactivate();
			weightTable->hide();

			selectedTable->show();
			selectedTable->activate();

			weightInput->activate();
			updateColButton->activate();
			break;
	}
}

void SkinTableWindow::addSelectedVertex(int vertex)
{
	int selectedVertices = m_skinWindow->skin->m_selectSkinVertices.size();

	weightTable->selectCurrentRow(vertex);
	selectedTable->rows(selectedVertices);

}

void SkinTableWindow::removeSelectedVertex(int vertex)
{
	int selectedVertices = m_skinWindow->skin->m_selectSkinVertices.size();

	weightTable->deselectCurrentRow(vertex);
	selectedTable->rows(selectedVertices);
}

void SkinTableWindow::clearSelectedVertices()
{
	weightTable->deselectAllRows();
	selectedTable->rows(0);
}

void SkinTableWindow::updateAllCol_button_cb(fltk::Widget* o, void* p)
{
	SkinTableWindow* sWin = (SkinTableWindow*) p;

	int link = sWin->selectedTable->getSelectedCol();
	if ((link == -1) || (sWin->m_skinWindow->skin->m_selectSkinVertices.size() == 0))
		return;

	float weight = (float)sWin->weightInput->fvalue();

	sWin->m_skinWindow->skin->changeWeightInSelectList(link, weight);

	sWin->selectedTable->redraw();

	sWin->m_skinWindow->skin->adjustSkin();
	dance::AllViews->postRedisplay();
}

void SkinTableWindow::onDestroyWindow_cb(fltk::Widget *o, void *p)
{
	SkinTableWindow *sWin = (SkinTableWindow *)p;

	sWin->weightTable->inputField->hide();
	sWin->selectedTable->inputField->hide();

	sWin->weightTable->clear();
	sWin->weightTable->deactivate();
	sWin->weightTable->hide();
	sWin->selectedTable->clear();
	sWin->selectedTable->deactivate();
	sWin->selectedTable->hide();

	sWin->m_skinWindow->tableChoice->value(0);
	sWin->hide();
}
