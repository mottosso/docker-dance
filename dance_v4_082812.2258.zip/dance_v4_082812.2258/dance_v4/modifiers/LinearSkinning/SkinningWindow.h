/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _SKINNINGWINDOW_
#define _SKINNINGWINDOW_

#include "LinearSkinning.h"
//#include "SelectedSkinTable.h"
#include <fltk/ScrollGroup.h>
#include <fltk/file_chooser.h>
#include <fltk/Choice.h>
#include <fltk/ask.h>
#include <fltk/Button.h>
#include <fltk/CheckButton.h>
#include <fltk/RadioButton.h>
#include <fltk/FloatInput.h>
#include <fltk/ThumbWheel.h>
#include <fltk/ValueInput.h>

class SkinTableWindow;

class SkinningWindow : public fltk::ScrollGroup
{
	public:
		SkinningWindow(LinearSkinning* s, int x, int y, int w, int h, const char* name);

		void updateGUI();
		void updateSkinWidgets();
		void updateEllipseWidgets();
		void show();
		void initSysGeoChoices();

		LinearSkinning *skin;
		SkinTableWindow *tableWindow;

		fltk::Choice* allSystemList;
		fltk::Choice* allGeoList;
		fltk::Choice* displayChoice;
		fltk::Button* refreshButton;
		fltk::Choice* tableChoice;
		fltk::ValueInput* skinPointSizeValue;

		fltk::Button* skinLoader;
		fltk::Button* skinSaver;
		fltk::Button* skinDetach;
		fltk::Button* setBindingState;
		fltk::Button* toBindingState;
		fltk::Button* automaticButton;

		fltk::RadioButton* cameraModeButton;
		fltk::RadioButton* ellipseModeButton;
		fltk::RadioButton* skinModeButton;
		fltk::Button* clearSelectedSkinButton;
		
		fltk::Button* ellipseCreator;
		fltk::Button* ellipseLoader;
		fltk::Button* applyEllipse;
		fltk::Button* ellipseSaver;
		fltk::FloatInput* ellipseFraction;

		fltk::CheckButton* showAllEllipses;
		fltk::CheckButton* hideEllipses;
		fltk::RadioButton* ellipseTypeShowSmall;
		fltk::RadioButton* ellipseTypeShowLarge;
		fltk::RadioButton* ellipseTypeShowBoth;
		fltk::RadioButton* ellipseLookShowVertices;
		fltk::RadioButton* ellipseLookShowMesh;
		fltk::RadioButton* ellipseLookShowSolid;
		
		fltk::Choice* ellipseLinkChoice;
		fltk::FloatInput* smallEllipseValue[4];
		fltk::ThumbWheel* smallEllipseWeightWheel[4];
		fltk::FloatInput* largeEllipseValue[4];
		fltk::ThumbWheel* largeEllipseWeightWheel[4];

	private:
		bool m_geoSelected;
		bool m_sysSelected;

		void setDisplayChoices();
		void setEllipseLinkChoices();
		
		static void allSystemList_choice_cb(fltk::Widget* o, void* p);
		static void allGeoList_choice_cb(fltk::Widget* o, void* p);
		static void displayChoice_choice_cb(fltk::Widget* o, void* p);
		static void tableChoice_choice_cb(fltk::Widget* o, void* p);
		static void skinPointSize_input_cb(fltk::Widget* o, void* p);

		static void skinLoader_button_cb(fltk::Widget* o, void* p);
		static void skinSaver_button_cb(fltk::Widget* o, void* p);
		static void skinDetach_button_cb(fltk::Widget* o, void* p);
		static void setBindingState_button_cb(fltk::Widget* o, void* p);
		static void toBindingState_button_cb(fltk::Widget* o, void* p);
		static void automaticAssign_cb(fltk::Widget* o, void* p);

		static void cameraModeButton_radio_button_cb(fltk::Widget* o, void *p);
		static void ellipseModeButton_radio_button_cb(fltk::Widget* o, void *p);
		static void skinModeButton_radio_button_cb(fltk::Widget* o, void *p);
		static void clearSelectedSkinButton_button_cb(fltk::Widget* o, void *p);
		
		static void applyEllipse_button_cb(fltk::Widget* o, void* p);
		static void ellipseCreator_button_cb(fltk::Widget* o, void* p);
		static void ellipseLoader_button_cb(fltk::Widget* o, void* p);
		static void ellipseSaver_button_cb(fltk::Widget* o, void* p);
		static void ellipseFraction_input_cb(fltk::Widget* o, void* p);

		static void showAllEllipses_check_button_cb(fltk::Widget* o, void *p);
		static void hideEllipses_check_button_cb(fltk::Widget* o, void *p);
		static void ellipseTypeShowSmall_radio_button_cb(fltk::Widget* o, void* p);
		static void ellipseTypeShowLarge_radio_button_cb(fltk::Widget* o, void* p);
		static void ellipseTypeShowBoth_radio_button_cb(fltk::Widget* o, void* p);
		static void ellipseLookShowVertices_radio_button_cb(fltk::Widget* o, void* p);
		static void ellipseLookShowMesh_radio_button_cb(fltk::Widget* o, void* p);
		static void ellipseLookShowSolid_radio_button_cb(fltk::Widget* o, void* p);
	
		static void ellipseLinkChoice_choice_cb(fltk::Widget* o, void* p);
		static void smallEllipseValue_input_cb(fltk::Widget* o, void* p);
		static void smallEllipseValue_wheel_cb(fltk::Widget* o, void* p);
		static void largeEllipseValue_input_cb(fltk::Widget* o, void* p);
		static void largeEllipseValue_wheel_cb(fltk::Widget* o, void* p);
};
#endif
