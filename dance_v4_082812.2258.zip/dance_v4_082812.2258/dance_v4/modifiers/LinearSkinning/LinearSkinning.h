/**************************************************
DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:

	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef	_LINEARSKINNING_H_
#define	_LINEARSKINNING_H_

//********************************************************
//----------- Linear skinning header file ----------------
//********************************************************

//#include <FL/Fl_Double_Window.H>
#include "defs.h"
#include "DModifier.h"
#include "ArticulatedObject.h"
#include "Model.h"
#include "Capsule.h"
#include <vector>


class DView;
class DSimulator;
class DSystem;
//class SimulatorEvents;
class BoundingBox;
class SkinningWindow;
class SkinTableWindow;

class LinearSkinning : public DModifier {
public:
	enum LinSkinAppModeEnum {
		MODE_SKIN_SELECTION,
		MODE_ELLIPSE_SELECTION,
		MODE_SKIN_VIEW
	};

	enum SkinDisplayMode {
		SKIN_DISPLAY_NORMAL,
		SKIN_DISPLAY_SELECTED,
		SKIN_DISPLAY_UNASSIGNED,
		SKIN_DISPLAY_MAPPED
	};

	enum EllipseTypeEnum {
		ELLIPSE_SMALL_ONLY,
		ELLIPSE_LARGE_ONLY,
		ELLIPSE_BOTH,
		ELLIPSE_NEITHER,
		ELLIPSE_SELECTED
	};

	enum EllipseLookEnum {
		ELLIPSE_DISPLAY_VERTICES,
		ELLIPSE_DISPLAY_MESH,
		ELLIPSE_DISPLAY_SOLID
	};

	LinearSkinning();
    ~LinearSkinning();

	PlugIn* create(int argc, char **argv) ;
	void setName(const char* name);
	void output(int mode);
	int commandPlugIn(int argc, char **argv);

	int interact(Event *event)  ;
	int interactStart(Event *event) ;
	int interactEnd(Event *event) ;

	void setSkinAppMode(LinSkinAppModeEnum mode);
	int getSkinAppMode();

	void setSelectedEllipse(int type, int link);
	int getSelectedEllipse();
	int getSelectedEllipseType();

	bool attachSkinViaEllipses(const char* skinName);
	void detachSkin();
	void doSkinSelection(DView *view, int x, int y, double delX, double delY, int buttonID, int mode);
	void displayUnassignedSkin(GLenum mode);
	void displayLinkSkinMap();
	void assignSkinAutomatically();
	void modify();
	void AfterAllSimStep(double time, double step);
	void clearSkinSelection();

	void drawEllipse(int type, float a, float b, float c, double WTransMatrix[][4]);
	bool checkEllipse(float a, float b, float c, float x, float y, float z);

	void setSkin(Model* model);
	Model* getSkin();

	ArticulatedObject* getInfluence();
	void setInfluence(ArticulatedObject* ao);

	int getNumPluginDependents();
        const char* getPluginDependent(int num);

	void save(int mode, std::ofstream& file);
	void onDependencyRemoval(DObject* obj);
	fltk::Widget* getInterface();

private:
	int PassiveMotionCB(DView *focus, int x, int y);
	int KeyboardCB(unsigned char key, int x, int y);
	void MouseCB(Event *event, bool released);
	void MotionCB(Event *event);
	void changeWeight(int vertex, int link, float weight);
	void changeWeightInSelectList(int link, float weight);
	void commitWeightChange(int vertex, int link, float weight);

	bool assignToSystem(const char *sysName);
	bool unassignFromSystem();
	bool createEllipse();
	bool modifyEllipse(int type, int link, float scale_x, float scale_y, float scale_z);
	bool setEllipse(int type, int link, float a, float b, float c);
	bool setAllEllipse(int type, float a, float b, float c);
	bool getEllipseAttrib(int type, int link, float* a, float* b, float* c);
	bool setDisplayMode(const char *modeString);
	bool setEllipseDisplayMode(int type, int look, int link);
	void setEllipseFraction(float fraction);
	float getEllipseFraction();
	int  getEllipseTypeShow();
	int  getEllipseLookShow();
	int  getShowOneEllipse();
	void drawAxisOfEllipse(int type, float a, float b, float c, double WTransMatrix[][4]);

	void saveEllipse(const char *filename);
	void saveSkin(const char *filename);
	bool loadEllipse(const char *filename);
	bool loadSkin(const char *filename, const char* skinName);

	void adjustSkin();

	void setBindingPoseState();
	void toBindingPoseState();
	void toLastCurrentState();


	friend class SkinningWindow;
	friend class SkinTableWindow;
	friend class SkinTable;
	friend class SelectedSkinTable;


	int LinSkinAppMode;
	int m_prevWinX;
	int m_prevWinY;
	float m_vertexSize;

	ArticulatedObject *m_influence;
	Model *m_skin;

	int m_selectedEllipse;
	int m_selectedEllipseType;
	int m_selectedEllipseAxis;
	int m_showOneEllipse;

	float m_ellipseFraction;
	int m_showLinkSkinMappings;

	std::vector<float> m_skinWeights;
	std::vector<int> m_skinWeightLinks;
	std::vector<int> m_skinTotalLinks;
	std::vector<bool> m_skinSelectFlag;
	Vector* m_skinVertices;
	Vector* m_originalVertCoord;
	double* m_bindingPoseState;
	double* m_currentState;

	bool m_showSkin;

	std::vector<float> m_smallEllipseAttr;
	std::vector<float> m_largeEllipseAttr;
	std::vector<int> m_selectSkinVertices;

	bool m_ellipse;
	bool m_skinAttached;
	bool m_skinLoaded;
	bool m_ellipseLoaded;
	bool m_showSmallEllipse;
	bool m_showLargeEllipse;
	bool m_showingAllEllipses;
	int m_ellipseTypeShow;
	int m_ellipseLookShow;
	int m_skinDisplayMode;
	bool m_showDragBox;
	
	int m_savedType;
	int m_savedLook;
	int m_savedLink;

	int m_boxX1, m_boxY1, m_boxX2, m_boxY2;

	
	SkinningWindow* m_skinWindow;
	double tempMatrix[100][4][4];
} ;

#endif

