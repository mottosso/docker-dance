//
// Table -- Fl_Table ported to FLTK 2.0.x
//
// 2005 by Jonathan Garcia.
//
// Please report all bugs and problems to jonathan.f.garcia@ucla.edu
//
// KNOWN BUGS:
//    o Resizing the parent window doesn't properly resize the table.
//    o The vertical scrollbar tab moves from the bottom to the top,
//      even though the table is scrolling properly.
//
//////////////////////////////////////////////////////////////////////////
//
// Fl_Table -- A table widget
//
// Copyright 2002 by Greg Ercolano.
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Library General Public
// License as published by the Free Software Foundation; either
// version 2 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Library General Public License for more details.
//
// You should have received a copy of the GNU Library General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
// USA.
//
// Please report all bugs and problems to "erco at seriss dot com".
//
// TODO:
//    o Auto scroll during dragged selection
//    o Keyboard navigation (up/down/left/right arrow)
//

#ifndef fltk_Table_h
#define fltk_Table_h

#include <vector>

#include <fltk/Cursor.h>
#include <fltk/damage.h>
#include <fltk/Window.h>
#include <fltk/Scrollbar.h>
#include <fltk/Group.h>
#include <fltk/draw.h>
#include <fltk/events.h>

class Table : public fltk::Group
{
	public:
		enum TableContext
		{
			CONTEXT_NONE = 0,	
			CONTEXT_STARTPAGE,	// before a page is redrawn
			CONTEXT_ENDPAGE,	// after a page is redrawn
			CONTEXT_ROW_HEADER,	// in the row header
			CONTEXT_COL_HEADER,	// in the col header
			CONTEXT_CELL,		// in one of the cells
			CONTEXT_TABLE,		// in the table
			CONTEXT_RC_RESIZE	// column or row being resized
		};

		Table(int x, int y, int w, int h, const char *l = 0);
		~Table();

		virtual void clear() { rows(0); cols(0); }

		virtual void rows(int val);
		inline int rows() { return _rows; };

		virtual void cols(int val);
		inline int cols() { return _cols; };

		inline bool row_resize()				// get/set row resizing
			{ return _row_resize; };
		void row_resize(bool flag)
			{ _row_resize = flag; };

		inline bool col_resize()				// get/set col resizing
			{ return _col_resize; };
		void col_resize(bool flag)
			{ _col_resize = flag; };

		inline int col_resize_min()				// column minimum resizing width
			{ return(_col_resize_min); }
		void col_resize_min(int val)
			{ _col_resize_min = ( val < 1 ) ? 1 : val; }

		inline int row_resize_min()				// column minimum resizing width
			{ return(_row_resize_min); }
		void row_resize_min(int val)
			{ _row_resize_min = ( val < 1 ) ? 1 : val; }

		inline bool row_header()				// get/set row header
			{ return _row_header; };
		void row_header(bool flag)
			{ _row_header = flag; table_resized(); redraw(); };

		inline bool col_header()				// get/set col header
			{ return _col_header; };
		void col_header(bool flag)
			{ _col_header = flag; table_resized(); redraw(); };

		inline void col_header_height(int height)	// set/get col header height
			{ _col_header_h = height; table_resized(); redraw(); };
		inline int col_header_height()
			{ return _col_header_h; };

		inline void row_header_width(int width)		// set/get row header width
			{ _row_header_w = width; table_resized(); redraw(); };
		inline int row_header_width()
			{ return _row_header_w; };

		inline void row_header_color(fltk::Color *val)	// set/get row header color
			{ _row_header_color = val; redraw(); }
		inline fltk::Color* row_header_color()
			{ return(_row_header_color); }

		inline void col_header_color(fltk::Color *val)	// set/get col header color
			{ _col_header_color = val; redraw(); }
		inline fltk::Color* col_header_color()
			{ return(_col_header_color); }
		
		
		void row_height(int row, int height);	// set/get row height
		inline int row_height(int row)
			{ return ((row < 0 || row >= _rowheights.size()) ? 0 : _rowheights[row]); };

		void col_width(int col, int width);		// set/get col width
		inline int col_width(int col)
			{ return ((col < 0 || col >= _colwidths.size()) ? 0 : _colwidths[col]); };

		void row_height_all(int height)			// set all row heights
			{ for (int r = 0; r < rows(); r++) row_height(r, height); };
		void col_width_all(int width)
			{ for (int c = 0; c < cols(); c++) col_width(c, width); };

		void row_position(int row);				// set/get table's current scroll position
		void col_position(int col);
		int row_position() { return _row_position; };	// current row position
		int col_position() { return _col_position; };	// current col position

		void scroll_size(int val)				// set/get scrollbar thickness
			{ _scroll_size = val; };
		inline int scroll_size()
			{ return _scroll_size; };

		void resize(int X, int Y, int W, int H);	// fltk resize() override
		void draw();								// fltk draw() override

		// CALLBACKS
		int callback_row() { return _callback_row; };
		int callback_col() { return _callback_col; };
		TableContext callback_context() { return _callback_context; };
		void do_callback(TableContext context, int row, int col)
		{
			_callback_context = context;
			_callback_row = row;
			_callback_col = col;
			Widget::do_callback();
		};

	protected:
		enum ResizeFlag
		{
			RESIZE_NONE		 = 0,
			RESIZE_COL_LEFT	 = 1,
			RESIZE_COL_RIGHT = 2,
            RESIZE_ROW_ABOVE = 3,
			RESIZE_ROW_BELOW = 4
		};

		int table_h, table_w;			// table's virtual size in pixels
		int toprow, botrow,				// four corners of viewable table
			leftcol, rightcol;

		// OPTIMIZATION: precomputed scroll positions for the toprow/leftcol
		int toprow_scrollpos,
			leftcol_scrollpos;

		// Dimensions
		fltk::Rectangle tableArea;		// table's drawing area (ie, Rectangle(0, 0, w(), h()))
		fltk::Rectangle visibleArea;	// visible drawing area (ie, not obstructed by scrollbars, etc.)

		fltk::Scrollbar *vscrollbar,	// vertical scrollbar
					    *hscrollbar;	// horizontal scrollbar

		// FLTK
		int handle(int event);			// fltk handle() override

		void recalc_dimensions();		// recalculates the drawing area
		void table_resized();			// table resized? if so, recalculate
		void table_scrolled();			// table scroled? if so, recalculate
		void get_bounds(TableContext context,	// return rectangle bounds for context
					    fltk::Rectangle *rectangle);
		TableContext cursor2rowcol(int &R, int &C, ResizeFlag &resizeflag);
		int find_cell(TableContext context, int R, int C, fltk::Rectangle *cell);
		int row_col_clamp(TableContext context, int &R, int &C);	// clamp row/col to known universe

		// called to draw cells (override with deriving class)
		virtual void draw_cell(TableContext context, int R=0, int C=0, fltk::Rectangle *cell=0);

		long row_scroll_position(int row);	// find scroll position of row in pixels
		long col_scroll_position(int col);	// find scroll position of col in pixels

		static void scroll_cb(fltk::Widget *w, void *v);		// horiz/vert scrollbar callback

		void redraw_range(int toprow, int botrow, int leftcol, int rightcol)
		{
			if (_redraw_toprow == -1)
			{
				// initialize redraw range
				_redraw_toprow = toprow;
				_redraw_botrow = botrow;
				_redraw_leftcol = leftcol;
				_redraw_rightcol = rightcol;
			}
			else
			{
				// extend redraw range
				if (toprow < _redraw_toprow) _redraw_toprow = toprow;
				if ( botrow > _redraw_botrow ) _redraw_botrow = botrow;
				if ( leftcol < _redraw_leftcol ) _redraw_leftcol = leftcol;
				if ( rightcol > _redraw_rightcol ) _redraw_rightcol = rightcol;
			}

			// indicate partial redraw needed for some cells
			set_damage(fltk::DAMAGE_CHILD);
		}

	private:
		int _rows, _cols,				// total number of rows/cols
			_row_header_w,				// width of row header
			_col_header_h,				// height of column header
			_row_position,				// last row_position set
			_col_position;				// last col_position set

		bool _row_header,				// row headers enabled?
			 _col_header,				// col headers enabled?
			 _row_resize,				// row resize enabled?
			 _col_resize;				// col resize enabled?

		int _row_resize_min,			// row minimum resizing height (default = 5)
			_col_resize_min;			// col minimum resizing width (default = 5)
		
		int _scroll_size;				// scrollbar thickness (default = 16)

		// OPTIMIZATION: partial row/column redraw varibles
		int _redraw_toprow, _redraw_botrow,
			_redraw_leftcol, _redraw_rightcol;

		fltk::Color *_row_header_color,
					*_col_header_color;

		std::vector<int> _colwidths,	// column widths in pixels
						 _rowheights;	// row heights in pixels

		// EVENT CALLBACK DATA
		TableContext _callback_context;		// event context
		int _callback_row, _callback_col;	// event row/col

		// handle() state variables.
	    //    Put here instead of local statics in handle(), so more
		//    than one Fl_Table can exist without crosstalk between them.
		int _resizing_col,				// column being dragged
			_resizing_row,				// row being dragged
			_dragging_x,				// starting x position for horiz drag
			_dragging_y,				// starting y position for vert drag
			_last_row;					// last row we PUSH'ed

		// Redraw a single cell
		void _redraw_cell(TableContext context, int R, int C);
};

#endif
