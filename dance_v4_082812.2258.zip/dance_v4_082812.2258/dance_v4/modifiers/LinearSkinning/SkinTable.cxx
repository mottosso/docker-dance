/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "SkinTable.h"
#include "Link.h"

using namespace fltk;
using namespace std;

void SkinTable::set_weight_value()
{
	float weight = inputField->fvalue();

	skin->changeWeight(row_edit, col_edit, weight);
	inputField->hide();
}

void SkinTable::input_cb(Widget *, void *v)
{
	((SkinTable*) v)->set_weight_value();
}

// callback whenever someone clicks on different parts of the table
void SkinTable::event_callback(Widget *, void *data)
{
	SkinTable *o = (SkinTable*) data;
	o->event_callback2();
}

void SkinTable::event_callback2()
{
	int R = callback_row();
	int C = callback_col();
	TableContext context = callback_context();

	char linkName[128];
	float weight;

	int ctrlstate = fltk::event_state(fltk::CTRL);

	switch (context)
	{
		case CONTEXT_COL_HEADER:
			selectCurrentCol(C);
		break;

		case CONTEXT_ROW_HEADER:
			if (ctrlstate)
				selectCurrentRow(R);
			else
			{
				m_selectedRows.clear();
				selectCurrentRow(R);
			}
		break;

		case CONTEXT_CELL:
		{
			if (inputField->visible())
				inputField->hide();

			row_edit = R;
			col_edit = C;
			Rectangle cell;
			find_cell(CONTEXT_CELL, R, C, &cell);
			inputField->resize(cell.x(), cell.y(), cell.w(), cell.h());
//			char s[30];
			getSkinInfo(R, C, linkName, &weight);
			//sprintf(s, "%0.3f", weight);
			inputField->value(weight);
			this->init_sizes();
			this->redraw();
			inputField->show();
			inputField->take_focus();
			return ;
		}
		break;

		default:
			return;
	}
}

// Handle drawing all cells in table
void SkinTable::draw_cell(TableContext context, int R, int C, Rectangle *cell)
{
	static char linkName[128];
	static float weight;

    static char colHead[40];
	static char rowHead[40];
	static char cellStr[40];

	if (skin == NULL)
		return;

	getSkinInfo(R, C, linkName, &weight);

    sprintf(colHead, "%s", linkName);		// text for each cell
	sprintf(rowHead, "%d", R);
	sprintf(cellStr, "%0.3f", weight);

	switch(context)
	{
		case CONTEXT_STARTPAGE:
			fltk::setfont(HELVETICA, 16);
			return;

		case CONTEXT_ROW_HEADER:
			if (cell == NULL)
				return ;

			fltk::push_clip(*cell);
			{
				// draw box
				fltk::setcolor(color());
				fltk::fillrect(*cell);

				// draw text
				fltk::setfont(HELVETICA_BOLD, 14);
				fltk::setcolor(BLACK);
				fltk::drawtext(rowHead, *cell, ALIGN_CENTER);

				// draw border
				fltk::setcolor(GRAY80);
				fltk::strokerect(*cell);
			}
			fltk::pop_clip();
			return ;

		case CONTEXT_COL_HEADER:
			if (cell == NULL)
				return ;

			fltk::push_clip(*cell);
			{
				// draw box
				fltk::setcolor(color());
				fltk::fillrect(*cell);

				// draw text
				fltk::setfont(HELVETICA_BOLD, 14);
				fltk::setcolor(BLACK);
				fltk::drawtext(colHead, *cell, ALIGN_CENTER);

				// draw border
				fltk::setcolor(GRAY80);
				fltk::strokerect(*cell);
			}
			fltk::pop_clip();
			return ;

		case CONTEXT_CELL:
			if (R == row_edit && C == col_edit && inputField->visible())
				return ;
			
			if (cell == NULL)
				return ;

			fltk::push_clip(*cell);
			{
				// draw box
				if (rowSelected(R) || colSelected(C))
					fltk::setcolor(selection_color());
				else
					fltk::setcolor(WHITE);
				fltk::fillrect(*cell);

				// draw text
				fltk::setfont(HELVETICA, 14);
				fltk::setcolor(BLACK);
				if (weight != 0.0)
					fltk::drawtext(cellStr, *cell, ALIGN_CENTER);
				else
					fltk::drawtext("-", *cell, ALIGN_CENTER);

				// draw border
				fltk::setcolor(GRAY80);
				fltk::strokerect(*cell);

			}
			fltk::pop_clip();
			return ;

		default:
			return ;
	}
}

void SkinTable::selectCurrentRow(int R)
{
	std::vector<int>::iterator rowIter;

	rowIter = m_selectedRows.begin();
	for(;rowIter != m_selectedRows.end(); rowIter++)
	{
		if ((*rowIter) == R)
			return;
	}

	m_selectedRows.push_back(R);
	redraw();
	return;
}

void SkinTable::deselectCurrentRow(int R)
{
	std::vector<int>::iterator rowIter;

	rowIter = m_selectedRows.begin();
	for(;rowIter != m_selectedRows.end(); rowIter++)
	{
		if ((*rowIter) == R)
		{
			m_selectedRows.erase(rowIter);
			break;
		}
	}

	redraw();
	return;
}

void SkinTable::deselectAllRows()
{
	m_selectedRows.clear();
	redraw();
	return;
}

bool SkinTable::rowSelected(int R)
{
	std::vector<int>::iterator rowIter;

	rowIter = m_selectedRows.begin();
	for(;rowIter != m_selectedRows.end(); rowIter++)
	{
		if ((*rowIter) == R)
			return true;
	}

	return false;
}

void SkinTable::selectCurrentCol(int C)
{
	m_selectedCol = C;
	redraw();
	return;
}

void SkinTable::deselectCurrentCol(int C)
{
	m_selectedCol = -1;
	redraw();
	return;
}

bool SkinTable::colSelected(int C)
{
	if (m_selectedCol == C)
		return true;

	return false;
}

// TODO: finish this function
void SkinTable::getSkinInfo(int R, int C, char* link, float* weight)
{
	// R is the vertex number
	// C is the link number

	Link **links = skin->m_influence->getLinks();

	strcpy(link, links[C]->getName());
	*weight = 0.0;

	for (int i = 0; i < 5; i++)
	{
		if (skin->m_skinWeightLinks[(5 * R) + i] == C)
		{
			*weight = skin->m_skinWeights[(5 * R) + i];
			break;
		}
	}
}

void SkinTable::setSkin(LinearSkinning *ls)
{
	skin = ls;

	std::vector<int>::iterator vertIter;

	vertIter = skin->m_selectSkinVertices.begin();
	for (; vertIter != skin->m_selectSkinVertices.end(); vertIter++)
	{
		selectCurrentRow(*vertIter);
	}

	return;
}