//
// Table -- Fl_Table ported to FLTK 2.0.x
//
// 2005 by Jonathan Garcia.
//
// Please report all bugs and problems to jonathan.f.garcia@ucla.edu
//
// KNOWN BUGS:
//    o Resizing the parent window doesn't properly resize the table.
//    o The vertical scrollbar tab moves from the bottom to the top,
//      even though the table is scrolling properly.
//
//////////////////////////////////////////////////////////////////////////
//
// Fl_Table -- A table widget
//
// Copyright 2002 by Greg Ercolano.
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Library General Public
// License as published by the Free Software Foundation; either
// version 2 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Library General Public License for more details.
//
// You should have received a copy of the GNU Library General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
// USA.
//
// Please report all bugs and problems to "erco at seriss dot com".
//
// TODO:
//    o Auto scroll during dragged selection
//    o Keyboard navigation (up/down/left/right arrow)
//

#include "Table.h"
#include <stdio.h>

using namespace std;
using namespace fltk;

// Constructor
Table::Table(int x, int y, int w, int h, const char *l)
	: Group(x, y, w, h, l)
{
	_rows			 = 0;
	_cols			 = 0;
	_row_header_w	 = 40;
	_col_header_h	 = 18;
	_row_header		 = false;
	_col_header		 = false;
	_row_resize		 = false;
	_col_resize		 = false;
	_row_resize_min	 = 5;
	_col_resize_min  = 5;
	_scroll_size	 = 16;
	_redraw_toprow   = -1;
	_redraw_botrow   = -1;
	_redraw_leftcol  = -1;
	_redraw_rightcol = -1;
	table_w			 = 0;
	table_h			 = 0;
	toprow			 = 0;
	botrow			 = 0;
	leftcol			 = 0;
	rightcol		 = 0;
    _resizing_col	 = -1;
	_resizing_row	 = -1;
	_dragging_x		 = -1;
	_dragging_y		 = -1;
	_last_row		 = -1;

	this->box(fltk::THIN_DOWN_BOX);

	this->begin();
	vscrollbar = new fltk::Scrollbar(w - _scroll_size, 0, _scroll_size, h - _scroll_size);
	vscrollbar->callback(scroll_cb, this);
	vscrollbar->set_vertical();
	vscrollbar->scrollbar_align(ALIGN_TOP);
	vscrollbar->hide();

	hscrollbar = new fltk::Scrollbar(0, h - _scroll_size, w - _scroll_size, _scroll_size);
	hscrollbar->callback(scroll_cb, this);
	hscrollbar->set_horizontal();
	hscrollbar->hide();

	this->end();

	table_resized();
	redraw();
}

// Destructor
Table::~Table()
{
	// The parent Group takes care of destroying scrollbars
}

// Set number of rows
void Table::rows(int val)
{
	int oldrows = _rows;
	_rows = val;

	{
		int default_h = (_rowheights.size() > 0) ? _rowheights[_rowheights.size() - 1] : 25;
		while (val > _rowheights.size())
			_rowheights.push_back(default_h);	// grow vector

		while (val < _rowheights.size())
			_rowheights.pop_back();				// shrink vector
	}

	table_resized();

	// OPTIMIZATION: redraw only if change is visible
	if (val < oldrows && oldrows <= botrow)
		redraw();
}

// Set number of cols
void Table::cols(int val)
{
	int oldcols = _cols;
	_cols = val;

	{
		int default_h = (_colwidths.size() > 0) ? _colwidths[_colwidths.size() - 1] : 80;
		while (val > _colwidths.size())
			_colwidths.push_back(default_h);	// grow vector

		while (val < _colwidths.size())
			_colwidths.pop_back();				// shrink vector
	}

	table_resized();
	
	// OPTIMIZATION: redraw only if change is visible
	if (val < oldcols && oldcols <= rightcol)
		redraw();
}

// Set height of a row
void Table::row_height(int row, int height)
{
	if (row < 0) return ;
	if (row < _rowheights.size() && _rowheights[row] == height)
		return ;	// OPTIMIZATION: no change? avoid redraw

	// add row heights, even if none yet
	while (row >= _rowheights.size())
		_rowheights.push_back(height);

	_rowheights[row] = height;
	table_resized();
	
	if (row <= botrow) // OPTIMIZATION: only redraw if onscreen or above screen
		redraw();

	// ROW RESIZE CALLBACK
	if (Widget::callback() && when() & fltk::WHEN_CHANGED)
		do_callback(CONTEXT_RC_RESIZE, row, 0);
}

// Set width of a col
void Table::col_width(int col, int width)
{
	if (col < 0) return ;
	if (col < _colwidths.size() && _colwidths[col] == width)
		return ;	// OPTIMIZATION: no change? avoid redraw

	// add column widths, even if none yet
	while (col >= _colwidths.size())
		_colwidths.push_back(width);

	_colwidths[col] = width;
	table_resized();

	if (col < rightcol)	// OPTIMIZATION: only redraw if onscreen or to the left
		redraw();

	// COLUMN RESIZE CALLBACK
	if (Widget::callback() && when() & fltk::WHEN_CHANGED)
		do_callback(CONTEXT_RC_RESIZE, 0, col);
}

// Scroll display so 'row' is at top
void Table::row_position(int row)
{
	if (_row_position == row) return ;	// OPTIMIZATION: no change? avoid redraw
	if (row < 0) row = 0;
	else if (row >= rows()) row = rows() - 1;
	if (table_h <= visibleArea.h()) return;	// don't scroll if table is smaller than window
	double newtop = row_scroll_position(row);
	if (newtop > vscrollbar->maximum())
		newtop = vscrollbar->maximum();
	vscrollbar->Slider::value(newtop);
	table_scrolled();
	redraw();
	_row_position = row;	// HACK: override what table_scrolled() came up with
}

// Scroll display so 'col' is at left
void Table::col_position(int col)
{
    if (_col_position == col) return;	// OPTIMIZATION: no change? avoid redraw
    if (col < 0) col = 0;
    else if (col >= cols()) col = cols() - 1;
    if (table_w <= visibleArea.w()) return;	// don't scroll if table smaller than window
    double newleft = col_scroll_position(col);
    if (newleft > hscrollbar->maximum()) 
		newleft = hscrollbar->maximum();
    hscrollbar->Slider::value(newleft);
    table_scrolled();
    redraw();
	_col_position = col;		// HACK: override what table_scrolled() came up with
}

// Resize FLTK override
//		handle resize events if user resizes parent window
void Table::resize(int X, int Y, int W, int H)
{
	// tell group to resize, and recalc our own widget as well
	Group::resize(X, Y, W, H);
	table_resized();
	redraw();
}

// Draw the entire Fl_Table
//    Override the draw() routine to draw the table.
//    Then tell the group to draw over us.
void Table::draw()
{
	// let user's drawing routine prep new page
	draw_cell(CONTEXT_STARTPAGE, 0, 0, &tableArea);

    // Let fltk widgets draw themselves first. Do this after
    // draw_cell(CONTEXT_STARTPAGE) in case user moves widgets around.
	fltk::push_clip(tableArea);
	{
		Group::draw();
	}
	fltk::pop_clip();
	
	// clip all further drawing to the table's dimensions
	fltk::push_clip(tableArea);
	{
		// only redraw a few cells?
		if (!(damage() & DAMAGE_ALL) && _redraw_leftcol != -1)
		{
			fltk::push_clip(visibleArea);
			for (int c = _redraw_leftcol; c <= _redraw_rightcol; c++)
			for (int r = _redraw_toprow; c <= _redraw_botrow; r++)
				_redraw_cell(CONTEXT_CELL, r, c);
			fltk::pop_clip();
		}

		if (damage() & DAMAGE_ALL)
		{
			Rectangle cell;

			// draw row headers, if any
			if (row_header())
			{
				get_bounds(CONTEXT_ROW_HEADER, &cell);
				fltk::push_clip(cell);
				for (int r = toprow; r <= botrow; r++)
					_redraw_cell(CONTEXT_ROW_HEADER, r, 0);
				fltk::pop_clip();
			}

			// draw col headers, if any
			if (col_header())
			{
				get_bounds(CONTEXT_COL_HEADER, &cell);
				fltk::push_clip(cell);
				for (int c = leftcol; c <= rightcol; c++)
					_redraw_cell(CONTEXT_COL_HEADER, 0, c);
				fltk::pop_clip();
			}

			// Draw all cells.
			//    This includes cells partially obscured off edges of table.
			//    No longer do this last; you might think it would be nice
			//    to draw over dead zones, but on redraws it flickers. Avoid
			//    drawing over deadzones; prevent deadzones by sizing columns.
			fltk::push_clip(visibleArea);
			{
				// draw all cells
				for (int r = toprow; r <= botrow; r++)
				{
					for (int c = leftcol; c <= rightcol; c++)
					{
						_redraw_cell(CONTEXT_CELL, r, c);
					}
				}
			}
			fltk::pop_clip();

			// draw litter rectangle in corner of headers
			if (row_header() && col_header())
			{
				Rectangle corner(tableArea.x()+1, tableArea.y()+1, row_header_width(), col_header_height());

				// draw box
				fltk::setcolor(color());
				fltk::fillrect(corner);

				// draw border
				fltk::setcolor(GRAY80);
				fltk::strokerect(corner);
			}
		}

		draw_cell(CONTEXT_ENDPAGE, 0, 0, &visibleArea);
		_redraw_leftcol = _redraw_rightcol = _redraw_toprow = _redraw_botrow = -1;
	}
	fltk::pop_clip();
}

// Handle FLTK events
int Table::handle(int event)
{
	int ret = Group::handle(event);	// let FLTK group handle events first

	// which row/col are we over?
	int R, C;
	ResizeFlag resizeflag;
	TableContext context = cursor2rowcol(R, C, resizeflag);

	switch(event)
	{
		case fltk::PUSH:
			// need this for eg. right click to pop up a menu
			if (Widget::callback() && resizeflag == RESIZE_NONE)
				do_callback(context, R, C);

			switch(context)
			{
				case CONTEXT_CELL:
					// PUSH on a cell?
					ret = 1;
				break;

				case CONTEXT_COL_HEADER:
					// PUSH on a column header?
					if (fltk::event_button() == 1 && resizeflag)
					{
						// Start resize if left click on column border.
						//    "ret=1" ensures we get drag events from now on.
						//    (C-1) is used if mouse is over the left hand side of the cell,
						//    so that we resize the next column over to the left.
						_resizing_col = (resizeflag & RESIZE_COL_LEFT) ? C-1 : C;
						_resizing_row = -1;
						_dragging_x = fltk::event_x();
						ret = 1;
					}
				break;

				case CONTEXT_ROW_HEADER:
					// PUSH on a row header?
					if (fltk::event_button() == 1 && resizeflag)
					{
						// Start resize if left mouse clicked on row border.
						//    "ret = 1" ensures we get drag events from now on.
						//    (R-1) is used if mouse is over the top of the cell,
						//    so that we resize the row above.
						_resizing_row = (resizeflag & RESIZE_ROW_ABOVE) ? R-1 : R;
						_resizing_col = -1;
						_dragging_y = fltk::event_y();
						ret = 1;
					}
				break;

				default:
					ret = 0;		// express disinterest
				break;
			}
			_last_row = R;
		break;

		case fltk::DRAG:
			if (_resizing_col > -1)
			{
				// Dragging column?
				//    Let user drag even /outside/ the row/col widget.
				//    Don't allow column width smaller than 1.
				//    Continue to show FL_CURSOR_WE at all times during drag.
				int offset = _dragging_x - fltk::event_x();
				int new_w = col_width(_resizing_col) - offset;
				if (new_w < _col_resize_min) new_w = _col_resize_min;
				col_width(_resizing_col, new_w);
				_dragging_x = fltk::event_x();
				table_resized();
				redraw();
				this->cursor(CURSOR_WE);
				ret = 1;

				if (Widget::callback() && when() & WHEN_CHANGED)
					do_callback(CONTEXT_RC_RESIZE, R, C);
			}
			else if (_resizing_row > -1)
			{
				// Dragging row?
				//
				//    Let user drag even /outside/ the row/col widget.
				//    Don't allow row width smaller than 1.
				//    Continue to show FL_CURSOR_NS at all times during drag.
				int offset = _dragging_y - fltk::event_y();
				int new_h = row_height(_resizing_row) - offset;
				if (new_h < _row_resize_min) new_h = _row_resize_min;
				row_height(_resizing_row, new_h);
				_dragging_y = fltk::event_y();
				table_resized();
				redraw();
				this->cursor(CURSOR_NS);
				ret = 1;

				if (Widget::callback() && when() & WHEN_CHANGED)
					do_callback(CONTEXT_RC_RESIZE, R, C);
			}
		break;

		case fltk::RELEASE:
			switch (context)
			{
				case CONTEXT_ROW_HEADER:	// release on row header
				case CONTEXT_COL_HEADER:	// release on col header
				case CONTEXT_CELL:			// release on a cell
				case CONTEXT_TABLE:			// relase on dead zone
					if (_resizing_col == -1 &&
						_resizing_row == -1 &&
						Widget::callback() &&
						when() & WHEN_RELEASE &&
						_last_row == R)
					{
						// need this for eg. left clicking on a cell to select it
						do_callback(context, R, C);
					}
				break;
			}

			if (fltk::event_button() == 1)
			{
				this->cursor(CURSOR_DEFAULT);
				_resizing_row = -1;
				_resizing_col = -1;
				ret = 1;
			}
		break;

		case fltk::MOVE:
			if (context == CONTEXT_COL_HEADER && resizeflag)
				this->cursor(CURSOR_WE);
			else if (context == CONTEXT_ROW_HEADER && resizeflag)
				this->cursor(CURSOR_NS);
			else
				this->cursor(CURSOR_DEFAULT);

			ret = 1;
		break;

		case fltk::ENTER:
		case fltk::LEAVE:
			if (resizeflag)
				ret = 1;

			if (event == fltk::LEAVE)
				this->cursor(CURSOR_DEFAULT);
		break;

		case fltk::FOCUS:
		case fltk::UNFOCUS:
	    // Currently no interest in keyboard focus. 
	    //     This will likely change when we implement keyboard navigation of cells.
	    //
	    // if (Fl::visible_focus()) 
	    //     { ret = 1; }
	    break;

		default:
			this->cursor(CURSOR_DEFAULT);
			break;
	}

	return ret;
}

// Recalculate the window dimensions
void Table::recalc_dimensions()
{
	int c = 0;
	tableArea.set(0, 0, w(), h());

	// do scrollbars need to be visible?
	{
		// FIRST PASS
		bool showh = (table_w > tableArea.w());		// show horizontal scrollbar?
		bool showv = (table_h > tableArea.h());		// show vertical scrollbar?

		// SECOND PASS
		if (showh && showv)
		{
			visibleArea.set(1, 1, w() - _scroll_size - 2, h() - _scroll_size - 2);
	        
			vscrollbar->resize(tableArea.w() - _scroll_size - 1, 1, _scroll_size, tableArea.h() - _scroll_size - 1);
			hscrollbar->resize(1, tableArea.h() - _scroll_size - 1, tableArea.w() - _scroll_size - 1, _scroll_size);
			vscrollbar->show();
			hscrollbar->show();
		}
		else if (showh && !showv)
		{
			visibleArea.set(1, 1, w() - 2, h() - _scroll_size - 2);

			hscrollbar->resize(1, tableArea.h() - _scroll_size - 1, tableArea.w() - 1, _scroll_size);
			vscrollbar->hide();
			hscrollbar->show();
		}
		else if (!showh && showv)
		{
			visibleArea.set(1, 1, w() - _scroll_size - 2, h() - 2);

			vscrollbar->resize(tableArea.w() - _scroll_size - 1, 1, _scroll_size, tableArea.h() - 1);
			vscrollbar->show();
			hscrollbar->hide();
		}
		else
		{
			visibleArea.set(1, 1, w() - 2, h() - 2);

			vscrollbar->hide();
			hscrollbar->hide();
		}
	}

	// row headers enabled?
	if (row_header())
	{
		visibleArea.x(visibleArea.x() + row_header_width());
		visibleArea.w(visibleArea.w() - row_header_width());
	}

	// column headers enabled?
	if (col_header())
	{
		visibleArea.y(visibleArea.y() + col_header_height());
		visibleArea.h(visibleArea.h() - col_header_height());
	}

	// resize the table
	this->init_sizes();
}

// Table resized: recalc internal data
//    Call this whenever the window is resized.
//    Recalculates the scrollbar sizes.
//    Makes no assumptions about any pre-initialized data.
void Table::table_resized()
{
	table_h = row_scroll_position(rows());
	table_w = col_scroll_position(cols());

	recalc_dimensions();

	// recalc scrollbar parameters
	{
		vscrollbar->range(0, table_h - visibleArea.h());
		vscrollbar->value(vscrollbar->value(), visibleArea.h(), 0, table_h);
		vscrollbar->linesize(rows()/3);

		hscrollbar->range(0, table_w - visibleArea.w());
		hscrollbar->value(hscrollbar->value(), visibleArea.w(), 0, table_w);
		hscrollbar->linesize(cols()/2);
	}

	// tell FLTK that child widgets were resized
	Group::init_sizes();

	// recalculate top/bot/left/right
	table_scrolled();

	// DO NOT REDRAW -- LEAVE THIS UP TO THE CALLER //
}

// Recalculate internals after a scroll.
//    Call this if table has been scrolled or resized.
//    Does not handle redraw().
//    TODO: Assumes ti[xywh] has already been recalculated.
void Table::table_scrolled()
{
	// top row
	int y, row, voff = vscrollbar->value();
	for (row = y = 0; row < _rows; row++)
	{
		y += row_height(row);
		if (y >= voff)
		{
			y -= row_height(row);
			break;
		}
	}
	_row_position = toprow = (row >= _rows) ? (row - 1) : row;
	toprow_scrollpos = y;		// OPTIMIZATION: save for later use

	// bottom row
	voff = vscrollbar->value() + visibleArea.h();
	for ( ; row < _rows; row++)
	{
		y += row_height(row);
		if (y >= voff)
			break;
	}
	botrow = (row >= _rows) ? (row - 1) : row;

	// left column
	int x, col, hoff = hscrollbar->value();
	for (col = x = 0; col < _cols; col++)
	{
		x += col_width(col);
		if (x >= hoff)
		{
			x -= col_width(col);
			break;
		}
	}
	_col_position = leftcol = (col >= _cols) ? (col - 1) : col;
	leftcol_scrollpos = x;		// OPTIMIZATION: save for later use

	// right column
	hoff = hscrollbar->value() + visibleArea.w();
	for ( ; col < _cols; col++)
	{
		x += col_width(col);
		if (x >= hoff)
			break;
	}
	rightcol = (col >= _cols) ? (col - 1) : col;

	// first tell children to scroll
	draw_cell(CONTEXT_RC_RESIZE, 0, 0, NULL);
}

// Return bounding region for given context
void Table::get_bounds(TableContext context, Rectangle *rectangle)
{
	switch (context)
	{
		case CONTEXT_COL_HEADER:
			// column header clipping
			rectangle->x(visibleArea.x());
			rectangle->y(tableArea.y());
			rectangle->w(visibleArea.w());
			rectangle->h(col_header_height());
		return ;

		case CONTEXT_ROW_HEADER:
			// row header clipping
			rectangle->x(tableArea.x());
			rectangle->y(visibleArea.y());
			rectangle->w(row_header_width());
			rectangle->h(visibleArea.h());
		return ;

		case CONTEXT_CELL:
			// visible area dimensions
			rectangle->x(visibleArea.x());
			rectangle->y(visibleArea.y());
			rectangle->w(visibleArea.w());
			rectangle->h(visibleArea.h());
		return;

		default:
			return ;
	}
	// NOT REACHED
}

// Find row/col beneath cursor
//    Returns R/C and context.
//    Also returns resizeflag, if mouse is hovered over a resize boundary.
Table::TableContext Table::cursor2rowcol(int &R, int &C, ResizeFlag &resizeflag)
{
	// return values
	R = C = 0;
	resizeflag = RESIZE_NONE;

	Rectangle cell;

	// row header?
	if (row_header())
	{
		// inside a row heading?
		get_bounds(CONTEXT_ROW_HEADER, &cell);
		if (fltk::event_inside(cell))
		{
			for (R = toprow; R <= botrow; R++)
			{
				find_cell(CONTEXT_ROW_HEADER, R, 0, &cell);
				if (fltk::event_y() >= cell.y() && fltk::event_y() <= (cell.y() + cell.h()))
				{
					// Found row?
					//     If cursor over resize boundary, and resize enabled,
					//     enable the appropriate resize flag.
					if (row_resize())
					{
						if (fltk::event_y() <= cell.y()+3) { resizeflag = RESIZE_ROW_ABOVE; }
						if (fltk::event_y() >= cell.y()+cell.h()-3) { resizeflag = RESIZE_ROW_BELOW; }
					}
					return CONTEXT_ROW_HEADER;
				}
			}
			// must be in row header dead zone
			return CONTEXT_NONE;
		}
	}

	// column header?
	if (col_header())
	{
		// inside a column heading?
		get_bounds(CONTEXT_COL_HEADER, &cell);
		if (fltk::event_inside(cell))
		{
			for (C = leftcol; C <= rightcol; C++)
			{
				find_cell(CONTEXT_COL_HEADER, 0, C, &cell);
				if (fltk::event_x() >= cell.x() && fltk::event_x() < (cell.x() + cell.w()))
				{
					// Found column?
					//     If cursor over resize boundary, and resize enabled,
					//     enable the appropriate resize flag.
					if (col_resize())
					{
						if (fltk::event_x() <= cell.x()+3) { resizeflag = RESIZE_COL_LEFT; }
						if (fltk::event_x() >= cell.x()+cell.w()-3) { resizeflag = RESIZE_COL_RIGHT; }
					}
					return CONTEXT_COL_HEADER;
				}
			}
			// must be in column header dead zone
			return CONTEXT_NONE;
		}
	}

	// mouse somewhere in table?
	//		scan visible rows/cols until we find it.
	if (fltk::event_inside(visibleArea))
	{
		for (R = toprow; R <= botrow; R++)
		{
			find_cell(CONTEXT_CELL, R, C, &cell);
			if (fltk::event_y() < cell.y()) break;
			if (fltk::event_y() >= cell.y() + cell.h()) continue;

			for (C = leftcol; C <= rightcol; C++)
			{
				find_cell(CONTEXT_CELL, R, C, &cell);
				if (fltk::event_inside(cell))
					return CONTEXT_CELL;	// found it!
			}
		}
		// must be in a dead zone of the table
		R = C = 0;
		return CONTEXT_TABLE;
	}

	// somewhere else
	return CONTEXT_NONE;
}

// Find bounding rectangle for cell at R/C
//     If R or C are out of range, returns -1 
//     with cell set to NULL.
int Table::find_cell(TableContext context, int R, int C, Rectangle *cell)
{
	cell->x(col_scroll_position(C) - hscrollbar->value() + visibleArea.x());
	cell->y(row_scroll_position(R) - vscrollbar->value() + visibleArea.y());
	cell->w(col_width(C));
	cell->h(row_height(R));

	switch (context)
	{
		case CONTEXT_COL_HEADER:
			cell->y(tableArea.y()+1);
			cell->h(col_header_height());
			return 0;

		case CONTEXT_ROW_HEADER:
			cell->x(tableArea.x()+1);
			cell->w(row_header_width());
			return 0;

		case CONTEXT_CELL:
			return 0;

		case CONTEXT_TABLE:
			return 0;

		default:
			cell = NULL;
			return -1;
	}
	// NOT REACHED
}

// Draws cells (override with deriving class)
void Table::draw_cell(TableContext context, int R, int C, Rectangle *cell)
{
	char colHead[40];
	char rowHead[40];

	sprintf(colHead, "%d", C);
	sprintf(rowHead, "%d", R);

	switch(context)
	{
		case CONTEXT_ROW_HEADER:
			if (cell == NULL)
				return ;

			fltk::push_clip(*cell);
			{
				// draw box
				fltk::setcolor(color());
				fltk::fillrect(*cell);

				// draw text
				fltk::setfont(HELVETICA_BOLD, 14);
				fltk::setcolor(BLACK);
				fltk::drawtext(rowHead, *cell, ALIGN_CENTER);

				// draw border
				fltk::setcolor(GRAY80);
				fltk::strokerect(*cell);
			}
			fltk::pop_clip();
			return ;

		case CONTEXT_COL_HEADER:
			if (cell == NULL)
				return ;

			fltk::push_clip(*cell);
			{
				// draw box
				fltk::setcolor(color());
				fltk::fillrect(*cell);

				// draw text
				fltk::setfont(HELVETICA_BOLD, 14);
				fltk::setcolor(BLACK);
				fltk::drawtext(colHead, *cell, ALIGN_CENTER);

				// draw border
				fltk::setcolor(GRAY80);
				fltk::strokerect(*cell);
			}
			fltk::pop_clip();
			return ;

		case CONTEXT_CELL:
			if (cell == NULL)
				return ;

			fltk::push_clip(*cell);
			{
				// draw box
				fltk::setcolor(WHITE);
				fltk::fillrect(*cell);

				// draw text
				fltk::setfont(HELVETICA, 14);
				fltk::setcolor(BLACK);
				fltk::drawtext("-", *cell, ALIGN_CENTER);

				// draw border
				fltk::setcolor(GRAY80);
				fltk::strokerect(*cell);

			}
			fltk::pop_clip();
			return ;

		default:
			return ;
	}
}

// Find scroll position of a row in pixels
long Table::row_scroll_position(int row)
{
	int startrow = 0;
	long scroll = 0;

	// OPTIMIZATION:
	//		Attempt to use precompute row scroll position
	if (toprow_scrollpos != -1 && row >= toprow)
	{
		scroll = toprow_scrollpos;
		startrow = toprow;
	}

	for (int t = startrow; t < row; t++)
		scroll += row_height(t);

	return scroll;
}

// Find scroll position of a column in pixels
long Table::col_scroll_position(int col)
{
	int startcol = 0;
	long scroll = 0;

	// OPTIMIZATION:
	//		Attempt to use precompute row scroll position
	if (leftcol_scrollpos != -1 && col >= leftcol)
	{
		scroll = leftcol_scrollpos;
		startcol = leftcol;
	}

	for (int t = startcol; t < col; t++)
		scroll += col_width(t);

	return scroll;
}

// Someone moved a scrollbar
void Table::scroll_cb(Widget *w, void *v)
{
	Table *t = (Table *)v;
	t->recalc_dimensions();
	t->table_scrolled();
	t->redraw();
}

// Draw a cell
void Table::_redraw_cell(TableContext context, int R, int C)
{
	if (R < 0 || C < 0) return ;
	Rectangle cell;
	find_cell(context, R, C, &cell);
	draw_cell(context, R, C, &cell);
}
