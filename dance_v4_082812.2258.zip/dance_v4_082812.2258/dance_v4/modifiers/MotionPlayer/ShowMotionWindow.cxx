/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "ShowMotionWindow.h"

#include "dance.h"
#include "CharJoint.h"

ShowMotionWindow::ShowMotionWindow(int x, int y, int width, int height, const char* name) : Window(x, y, width, height, name)
{
	this->begin();

	this->browserShowMotion = new Browser(0, 0, w() - 20, h() - 40, "Show Motion");

	buttonSelectAll = new Button(10, h() - 30, 80, 20, "Select All");
	buttonSelectAll->callback(selectall_cb, this);

	buttonSelectAll = new Button(100, h() - 30, 80, 20, "Select None");
	buttonSelectAll->callback(selectnone_cb, this);

	buttonOk = new Button(w() - 110, h() - 30, 80, 20, "Ok");
	buttonOk->callback(processmotions_cb, this);

	this->end();

	playerWindow = NULL;
}

void ShowMotionWindow::show()
{
	this->updateGUI();
	Window::show();
}


void ShowMotionWindow::updateGUI()
{
	// populate the browser with the motions available
	browserShowMotion->clear();

	int numCharacters = playerWindow->motionPlayer->getNumCharacters();
	for (int c = 0; c < numCharacters; c++)
	{
		bool val = true;//(int) this->playerWindow->motionPlayer->isShowCharacter(c);
		CheckButton* checkButton = new CheckButton(0, 0, browserShowMotion->w() - 20, 20, playerWindow->motionPlayer->getCharacter(c)->getName());
		checkButton->callback(this->processmotions_cb, this);
		checkButton->value(val);
		browserShowMotion->add(checkButton);
	}
}

void ShowMotionWindow::processmotions_cb(Widget* widget, void* data)
{
	ShowMotionWindow* showWin = (ShowMotionWindow*) data;
	Button* button = (Button*) widget;

	for (int i = 0; i < showWin->browserShowMotion->size(); i++)
	{
		CheckButton* checkButton = (CheckButton*) showWin->browserShowMotion->goto_index(i);
		//if (checkButton->value())
		//	showWin->playerWindow->motionPlayer->setShowCharacter(i, true);
		//else
		//	showWin->playerWindow->motionPlayer->setShowCharacter(i, false);
	}
	if (button == showWin->buttonOk)
		showWin->hide();
 
    dance::Refresh();
}

void ShowMotionWindow::selectnone_cb(Widget* widget, void* data)
{
	ShowMotionWindow* showWin = (ShowMotionWindow*) data;
	
	for (int i = 0; i < showWin->browserShowMotion->size(); i++)
	{
		CheckButton* checkButton = (CheckButton*) showWin->browserShowMotion->goto_index(i);
		checkButton->value(false);
//		showWin->playerWindow->motionPlayer->setShowCharacter(i, false);
	}
 
    dance::Refresh();
 
}

void ShowMotionWindow::selectall_cb(Widget* widget, void* data)
{
	ShowMotionWindow* showWin = (ShowMotionWindow*) data;

	for (int i = 0; i < showWin->browserShowMotion->size(); i++)
	{
		CheckButton* checkButton = (CheckButton*) showWin->browserShowMotion->goto_index(i);
		checkButton->value(true);
//		showWin->playerWindow->motionPlayer->setShowCharacter(i, true);
	}
 
    dance::Refresh();
}

