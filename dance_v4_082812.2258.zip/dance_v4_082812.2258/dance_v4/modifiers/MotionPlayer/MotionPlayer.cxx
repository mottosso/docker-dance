/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "dance.h"
#include "danceInterp.h"
#include "MotionPlayer.h"
#include "Character.h"
#include <fltk/glut.h>
#include <fltk/gl.h>
#include <fstream>
#include <iostream>
#include <algorithm>
//#include "lib3ds/file.h"
//#include "lib3ds/material.h"
//#include "lib3ds/matrix.h"
#include <vector>
#include <map>
#include "matrix3x3.h"
#include "arbMatrix.h"
#include "ViewManager.h"
#include "ParserBVH.h"
#include "ParserASFAMC.h"
#include "ParserPRT.h"
#include "ParserSKM.h"
#include "Joint.h"
#include "Link.h"
#include "DConnection.h"
#include "DConnectionManager.h"

//#define M_PI 3.1415f 

using namespace std;



PlugIn *Proxy() { return (new MotionPlayer);	} ;

MotionPlayer::MotionPlayer() : DSystem()
{
	setAnimate(false);
	setLooping(true);
	m_objectScale = 1.0;
	m_showMesh = false;
	m_animationFPS= 30;
	m_curTime = 0.0;
	m_animateFramesOnly = false;
	m_curFrame = 0;
	m_playerWindow = NULL;
#ifdef  USEMATLAB
	m_engine = NULL;
#endif
	this->setCurrentFrame(0);
	this->setSkipFrames(true);
	m_minTime = 0;
	m_maxTime = 0;

	dance::AllSimulators->addSimStepCB(this, 999999999, playStep);
}

MotionPlayer::~MotionPlayer()
{
//	for (int i = 0; i < m_objectFiles.size(); i++)
//		delete m_objectFiles[i];

#ifdef  USEMATLAB
	if (m_engine != NULL)
		engClose(m_engine);
#endif
	if (this->m_playerWindow != NULL)
		delete m_playerWindow;

	//fltk::remove_idle(MotionPlayer::IdleCB, this);
	
}

PlugIn *MotionPlayer::create(	int argc, char **argv)
{

    danceInterp::OutputMessage("Allocating MotionPlayer.") ;
    MotionPlayer	*g = new MotionPlayer ;

	if(	g == NULL )
	{
		danceInterp::OutputMessage("ERROR: out of memory.") ;
		return g ;
	}

    return g ;
}



void MotionPlayer::output(int mode)
{
   // glMatrixMode(GL_MODELVIEW) ;
	
	// characters are now first-class objects
	// and are displayed normally by the system
	/*// display the characters
	for (unsigned int c = 0; c < m_characters.size(); c++)
	{
		if (m_showCharacters[c] == true)
			m_characters[c]->draw(m_curTime, getInterpolation());
	}*/
}

int MotionPlayer::commandPlugIn(
	      int argc,	char **argv)
{

	int ret = PlugIn::commandPlugIn(argc, argv);
	if (ret != DANCE_CONTINUE)
		return ret;

	if (strcmp(argv[0], "parse") == 0)
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Usage: parse <bvh_file | prt_file> <name> or parse <asf_file> <amc_file> <name>");
			return DANCE_ERROR;
		}
		Character* c = NULL;
		std::ifstream file(argv[1], ios::in);
		if (!file.good())
		{
			danceInterp::OutputMessage("File '%s' is not valid.\n", argv[1]);
			return DANCE_ERROR;
		}
		if (argc == 3)
		{
			string filename = argv[1];
			if (filename.rfind(".prt") != string::npos || filename.rfind(".PRT") != string::npos)
				c = ParserPRT::parse(argv[2], file);
			else
				c = ParserBVH::parse(argv[2], file);

			if (c != NULL)
			{
				dance::AllGenericPlugins->add(c);
				dance::connectionManager->makeConnection(this, "plays", c);
		
				StringAttribute* fileAttr = dynamic_cast<StringAttribute*>(c->getAttribute("file"));
				if (fileAttr)
					fileAttr->setValue(argv[2]);
			}
		}

		if (argc == 4)
		{
			string filename = argv[1];
			string dataFilename = argv[2];
			
			if (filename.rfind(".sk") != string::npos  || filename.rfind(".SK") != string::npos)
			{
				std::ifstream datafile(argv[2], ios::in);
				if (!datafile.good())
				{
					danceInterp::OutputMessage("skm file '%s' is not valid.\n", argv[2]);
					return DANCE_ERROR;
				}
				
				c = ParserSKM::parse(argv[3], file, datafile);
				if (c)
				{
					StringAttribute* fileAttr = dynamic_cast<StringAttribute*>(c->getAttribute("file"));
					if (fileAttr)
						fileAttr->setValue(argv[1]);
					StringAttribute* file2Attr = dynamic_cast<StringAttribute*>(c->getAttribute("file"));
					if (file2Attr)
						file2Attr->setValue(argv[2]);
				}
			}
			else // assume it's in asf/amc format
			{
				std::ifstream datafile(argv[2], ios::in);
				if (!datafile.good())
				{
					danceInterp::OutputMessage("AMC file '%s' is not valid.\n", argv[2]);
					return DANCE_ERROR;
				}
				
				c = ParserASFAMC::parse(argv[3], file, datafile);
				if (c)
				{
					StringAttribute* fileAttr = dynamic_cast<StringAttribute*>(c->getAttribute("file"));
					if (fileAttr)
						fileAttr->setValue(argv[1]);
					StringAttribute* file2Attr = dynamic_cast<StringAttribute*>(c->getAttribute("file"));
					if (file2Attr)
						file2Attr->setValue(argv[2]);
				}
			}

			if (c != NULL) 
			{
				dance::AllGenericPlugins->add(c);
				dance::connectionManager->makeConnection(this, "plays", c);
			}
		}

		if (c == NULL)
			return DANCE_ERROR;

		this->addCharacter(c);
		if (this->getMotionPlayerWindow() != NULL)
			this->getMotionPlayerWindow()->updateGUI();
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "show") == 0)
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Usage: show <bones | joints | mesh> <on | off>\n");
			return DANCE_ERROR;
		}
		
		else if (strcmp(argv[1], "mesh") == 0)
		{
			if (strcmp(argv[2], "on") == 0)
			{
				danceInterp::OutputMessage("Mesh will be shown.\n");
				m_showMesh = true;
				return DANCE_OK;
			}
			else if (strcmp(argv[2], "off") == 0)
			{
				danceInterp::OutputMessage("Mesh will not be shown.\n");
				m_showMesh = false;
				return DANCE_OK;
			}
			else 
			{
				danceInterp::OutputMessage("Usage: show <bones | joints | mesh> <on | off>\n");
				return DANCE_ERROR;
			}
		}
	}
	else if (strcmp(argv[0], "animate") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: animate <on | off>\n");
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "on") == 0)
		{
			danceInterp::OutputMessage("Animation is now on.\n");
			setAnimate(true);
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "off") == 0)
		{
			danceInterp::OutputMessage("Animation is now off.\n");
			setAnimate(false);
			return DANCE_OK;
		}
		else 
		{
			danceInterp::OutputMessage("Usage: animate <on | off>\n");
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "loop") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: loop <on | off>\n");
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "on") == 0)
		{
			danceInterp::OutputMessage("Looping is now on.\n");
			setLooping(true);
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "off") == 0)
		{
			danceInterp::OutputMessage("Looping is now off.\n");
			setLooping(false);
			return DANCE_OK;
		}
		else 
		{
			danceInterp::OutputMessage("Usage: animate <on | off>\n");
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "animateFrames") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: animateFrames <on | off>\n");
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "on") == 0)
		{
			danceInterp::OutputMessage("Frame animation is now on.\n");
			m_animateFramesOnly = true;
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "off") == 0)
		{
			danceInterp::OutputMessage("Frame animation is now off.\n");
			m_animateFramesOnly = false;
			return DANCE_OK;
		}
		else 
		{
			danceInterp::OutputMessage("Usage: animateFrames <on | off>\n");
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "center_all") == 0)
	{
		std::vector<Character*>& characters = this->getCharacters();
		for (unsigned int c = 0; c < characters.size(); c++)
		{
			characters[c]->center();
			danceInterp::OutputMessage("Character %s has been centered...\n", characters[c]->getName());
		}
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "center") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: center <name>\n");
			return DANCE_ERROR;
		}
		Character* character = this->getCharacter(argv[1]);
		if (character != NULL)
		{
			character->center();
			danceInterp::OutputMessage("Character %s has been scaled...\n", character->getName());
			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Character %s was not found...\n", argv[1]);
			return DANCE_ERROR;
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "scale_characters") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: scale_characters <val>\n");
			return DANCE_ERROR;
		}
		double val = atof(argv[1]);
		std::vector<Character*>& characters = this->getCharacters();
		for (unsigned int c = 0; c < characters.size(); c++)
		{
			characters[c]->setScale(val);
			danceInterp::OutputMessage("Character %s has been scaled...\n", characters[c]->getName());
		}
		if (this->getMotionPlayerWindow() != NULL)
			this->getMotionPlayerWindow()->updateGUI();
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "scale_character") == 0)
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Usage: scale_character <name> <val>\n");
			return DANCE_ERROR;
		}
		double val = atof(argv[2]);
		Character* character = this->getCharacter(argv[1]);
		if (character != NULL)
		{
			character->setScale(val);
			if (this->getMotionPlayerWindow() != NULL)
				this->getMotionPlayerWindow()->updateGUI();
			danceInterp::OutputMessage("Character %s has been scaled...\n", character->getName());
			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Character %s was not found...\n", argv[1]);
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "offset_characters") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: offset_characters <x> <y> <z>\n");
			return DANCE_ERROR;
		}
		double x = atof(argv[1]);
		double y = atof(argv[2]);
		double z = atof(argv[3]);

		std::vector<Character*>& characters = this->getCharacters();
		for (unsigned int c = 0; c < characters.size(); c++)
		{
			characters[c]->setOffset(x, y, z);
			danceInterp::OutputMessage("Character %s has been offset by (%f %f %f)...\n", characters[c]->getName(), x, y, z);
		}
		if (this->getMotionPlayerWindow() != NULL)
			this->getMotionPlayerWindow()->updateGUI();
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "offset_character") == 0)
	{
		if (argc < 5)
		{
			danceInterp::OutputMessage("Usage: offset_character <name> <x> <y> <z>\n");
			return DANCE_ERROR;
		}
		double x = atof(argv[2]);
		double y = atof(argv[3]);
		double z = atof(argv[4]);
		Character* character = this->getCharacter(argv[1]);
		if (character != NULL)
		{
			character->setOffset(x, y, z);
			if (this->getMotionPlayerWindow() != NULL)
				this->getMotionPlayerWindow()->updateGUI();
			danceInterp::OutputMessage("Character %s has been offset by (%f %f %f)...\n", character->getName(), x, y, z);
			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Character %s was not found...\n", argv[1]);
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "rotate_characters") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: rotate_characters <x> <y> <z>\n");
			return DANCE_ERROR;
		}
		double x = atof(argv[1]);
		double y = atof(argv[2]);
		double z = atof(argv[3]);
		std::vector<Character*>& characters = this->getCharacters();
		for (unsigned int c = 0; c < characters.size(); c++)
		{
			characters[c]->setRotation(x, y, z);
			danceInterp::OutputMessage("Character %s has been rotated by (%f %f %f)...\n", characters[c]->getName(), x, y, z);
		}
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "rotate_character") == 0)
	{
		if (argc < 5)
		{
			danceInterp::OutputMessage("Usage: rotate_character <name> <x> <y> <z>\n");
			return DANCE_ERROR;
		}
		double x = atof(argv[2]);
		double y = atof(argv[3]);
		double z = atof(argv[4]);
		Character* character = this->getCharacter(argv[1]);
		if (character != NULL)
		{
			character->setRotation(x, y, z);
			danceInterp::OutputMessage("Character %s has been rotated by (%f %f %f)...\n", character->getName(), x, y, z);
			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Character %s was not found...\n", argv[1]);
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "combine") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: combine <motion1> <motion2> <combinedname>\n");
			return DANCE_ERROR;
		}
		int motion1 = -1;
		int motion2 = -1;
		std::vector<Character*>& characters = this->getCharacters();
		for (unsigned int c = 0; c < characters.size(); c++)
		{
			if (strcmp(argv[1], characters[c]->getName()) == 0)
				motion1 = c;
			else if (strcmp(argv[2], characters[c]->getName()) == 0)
				motion2 = c;
		}
		if (motion1 == -1)
		{
			danceInterp::OutputMessage("Could not find motion named '%s'", argv[1]);
			return DANCE_ERROR;
		}
		else if (motion2 == -1)
		{
			danceInterp::OutputMessage("Could not find motion named '%s'", argv[2]);
			return DANCE_ERROR;
		}
		// combine the motions: motion3 = motion1 + motion2
		Character* combined = characters[motion1]->copy(argv[3]);
		combined->addMotion(characters[motion2]);
		this->addCharacter(combined);
		if (this->getMotionPlayerWindow() != NULL)
			this->getMotionPlayerWindow()->updateGUI();
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "copy") == 0)
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Usage: copy <fromname> <toname>\n");
			return DANCE_ERROR;
		}
		Character* character = this->getCharacter(argv[1]);
		if (character != NULL)
		{
			Character* c = character->copy(argv[2]);
			this->addCharacter(c);
			if (this->getMotionPlayerWindow() != NULL)
				this->getMotionPlayerWindow()->updateGUI();
			danceInterp::OutputMessage("Character %s has been copied...\n", argv[1]);
			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Could not find character named %s...\n", argv[1]);
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "copy_partial") == 0)
	{
		if (argc < 5)
		{
			danceInterp::OutputMessage("Usage: copy <fromname> <toname> <startframe> <endframe>\n");
			return DANCE_ERROR;
		}
		Character* character = this->getCharacter(argv[1]);
		int startframe = atoi(argv[3]);
		int endframe = atoi(argv[4]);
		if (character != NULL)
		{
			Character* c = character->copy(argv[2], startframe, endframe);
			this->addCharacter(c);
			if (this->getMotionPlayerWindow() != NULL)
				this->getMotionPlayerWindow()->updateGUI();
			danceInterp::OutputMessage("Character %s has been copied...\n", argv[1]);
			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Could not find character named %s...\n", argv[1]);
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "set_time") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: set_time <val>\n");
			return DANCE_ERROR;
		}
		double val = atof(argv[1]);
		m_curTime = val;
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "set_fps") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: set_fps <val>\n");
			return DANCE_ERROR;
		}
		double val = atof(argv[1]);
		m_animationFPS = val;
		if (this->getMotionPlayerWindow() != NULL)
			this->getMotionPlayerWindow()->updateGUI();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "show_characters") == 0)
	{
		std::vector<Character*>& characters = this->getCharacters();
		for (unsigned int c = 0; c < characters.size(); c++)
		{
			danceInterp::OutputMessage("%s", characters[c]->getName());
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "delete_character") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: delete_character <character>\n");
			return DANCE_ERROR;
		}
		std::vector<Character*>& characters = this->getCharacters();
		// get the character
		vector<Character*>::iterator iter;
		int count = 0;
		for (iter = characters.begin(); iter != characters.end(); iter++)
		{
			if (strcmp((*iter)->getName(), argv[1]) == 0)
			{
				characters.erase(iter);

				if (this->getMotionPlayerWindow() != NULL)
					this->getMotionPlayerWindow()->updateGUI();
				danceInterp::OutputMessage("Character %s has been erased...", argv[1]);
				
				dance::AllViews->postRedisplay();
				return DANCE_OK;
			}
		}
		
		danceInterp::OutputMessage("No character named %s found...", argv[1]);
		return DANCE_ERROR;
	}
	else if (strcmp(argv[0], "set_bone_width") == 0)
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Usage: set_bone_width <character> <val>\n");
			return DANCE_ERROR;
		}
		Character* character = this->getCharacter(argv[1]);
		if (character != NULL)
		{
			double width = atof(argv[2]);
			character->setBoneWidth(width);
			danceInterp::OutputMessage("Bone width for character %s now set to %f...", character->getName(), width);
			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Could not find character named %s...\n", argv[1]);
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "set_bone_color") == 0)
	{
		if (argc < 5)
		{
			danceInterp::OutputMessage("Usage: set_bone_color <character> <r> <g> <b>\n");
			return DANCE_ERROR;
		}
		Character* character = this->getCharacter(argv[1]);
		if (character != NULL)
		{
			Vector color;
			color[0] = atof(argv[2]);
			color[1] = atof(argv[3]);
			color[2] = atof(argv[4]);
			character->setBoneColor(color);
			danceInterp::OutputMessage("Bone color for character %s now set to (%f, %f, %f)...", character->getName(), color[0], color[1], color[2]);
			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Could not find character named %s...\n", argv[1]);
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "set_joint_color") == 0)
	{
		if (argc < 5)
		{
			danceInterp::OutputMessage("Usage: set_joint_color <character> <r> <g> <b>\n");
			return DANCE_ERROR;
		}
		Character* character = this->getCharacter(argv[1]);
		if (character != NULL)
		{
			Vector color;
			color[0] = atof(argv[2]);
			color[1] = atof(argv[3]);
			color[2] = atof(argv[4]);
			character->setJointColor(color);
			danceInterp::OutputMessage("Joint color for character %s now set to (%f, %f, %f)...", character->getName(), color[0], color[1], color[2]);
			dance::AllViews->postRedisplay();
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Could not find character named %s...\n", argv[1]);
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "set_show_bones") == 0)
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Usage: set_show_bones <character> <on | off>\n");
			return DANCE_ERROR;
		}
		Character* character = this->getCharacter(argv[1]);
		if (character != NULL)
		{
			if (strcmp(argv[2], "on") == 0)
			{
				character->setShowBones(true);
				danceInterp::OutputMessage("Bones for character %s will now be shown...", character->getName());
				dance::AllViews->postRedisplay();
				return DANCE_OK;
			}
			else if (strcmp(argv[2], "off") == 0)
			{
				character->setShowBones(false);
				danceInterp::OutputMessage("Bones for character %s will not be shown...", character->getName());
				dance::AllViews->postRedisplay();
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Please use 'on' or 'off'...");
				return DANCE_ERROR;
			}
		}
		else
		{
			danceInterp::OutputMessage("Could not find character named %s...\n", argv[1]);
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "set_show_joints") == 0)
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Usage: set_show_joints <character> <on | off>\n");
			return DANCE_ERROR;
		}
		Character* character = this->getCharacter(argv[1]);
		if (character != NULL)
		{
			if (strcmp(argv[2], "on") == 0)
			{
				character->setShowJoints(true);
				danceInterp::OutputMessage("Joints for character %s will now be shown...", character->getName());
				dance::AllViews->postRedisplay();
				return DANCE_OK;
			}
			else if (strcmp(argv[2], "off") == 0)
			{
				character->setShowJoints(false);
				danceInterp::OutputMessage("Joints for character %s will not be shown...", character->getName());
				dance::AllViews->postRedisplay();
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Please use 'on' or 'off'...");
				return DANCE_ERROR;
			}
		}
		else
		{
			danceInterp::OutputMessage("Could not find character named %s...\n", argv[1]);
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "set_show_points") == 0)
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Usage: set_show_points <character> <on | off>\n");
			return DANCE_ERROR;
		}
		Character* character = this->getCharacter(argv[1]);
		if (character != NULL)
		{
			if (strcmp(argv[2], "on") == 0)
			{
				character->setShowPoints(true);
				danceInterp::OutputMessage("Points for character %s will now be shown...", character->getName());
				dance::AllViews->postRedisplay();
				return DANCE_OK;
			}
			else if (strcmp(argv[2], "off") == 0)
			{
				character->setShowPoints(false);
				danceInterp::OutputMessage("Points for character %s will not be shown...", character->getName());
				dance::AllViews->postRedisplay();
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Please use 'on' or 'off'...");
				return DANCE_ERROR;
			}
		}
		else
		{
			danceInterp::OutputMessage("Could not find character named %s...\n", argv[1]);
			return DANCE_ERROR;
		}
	}
	
	else if (strcmp(argv[0], "write_BVH") == 0)
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Usage: write_BVH <character> <filename>");
			return DANCE_ERROR;
		}

		Character* character = this->getCharacter(argv[1]);
		if (character != NULL)
		{
			std::string filename = argv[1];
			filename = filename + character->getName();
			filename = filename + ".bvh";
			danceInterp::OutputMessage("Now writing file %s", filename.c_str());
			character->saveBVH((char*) filename.c_str());
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Character with name %s was not found. No BVH file was written.");
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "write_ANI") == 0)
	{
		/*
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: write_ANI <filename> <character_name> <ArticulatedObject>");
			return DANCE_ERROR;
		}

		// get the character
		Character* character = this->getCharacter(argv[2]);
		if (character == NULL)
		{
			danceInterp::OutputMessage("No character named %s found...", argv[2]);
			return DANCE_ERROR;
		}
		// get the articulated object
		ArticulatedObject* skeleton = (ArticulatedObject*) dance::AllSystems->get(argv[3]);
		if (skeleton == NULL)
		{
			danceInterp::OutputMessage("Could not find a skeleton named %s...", argv[3]);
			return DANCE_ERROR;
		}

		std::string filename = argv[1];
		danceInterp::OutputMessage("Now writing file %s", filename.c_str());
		character->saveANI((char*) filename.c_str(), skeleton);
		*/
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "write_POVRAY") == 0)
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Usage: write_POVRAY <character> <filename prefix> |<start frame> <end frame> <fps>|");
			return DANCE_ERROR;
		}
		// get the character
		Character* character = this->getCharacter(argv[1]);
		if (character == NULL)
		{
			danceInterp::OutputMessage("Cannot find character %s...",argv[1]);
			return DANCE_ERROR;
		}
		int start = 0;
		int finish = 100000;
		if (argc > 3)
			start = (int) atof(argv[3]);
		if (argc > 4)
			finish = (int) atof(argv[4]);
		int skipframes = 1;
		if (argc > 5)
			skipframes = (int) atof(argv[5]);
	
		character->savePOVRay(argv[2], start, finish, skipframes);
		danceInterp::OutputMessage("Character %s has been saved to %s.txt", character->getName(), argv[2]);

		return DANCE_OK;
	}
	else if (strcmp(argv[0], "clear_motion") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: clear_motion <character_name>");
			return DANCE_ERROR;
		}

		Character* character = this->getCharacter(argv[1]);
		if (character == NULL)
		{
			danceInterp::OutputMessage("Character '%s' could not be found...", argv[1]);
			return DANCE_ERROR;
		}

		character->clearMotion();
		danceInterp::OutputMessage("Motion has been cleared from character '%s'...", argv[1]);

		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "retarget") == 0)
	{

		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: retarget <character_name> <skeleton_name> <retargeted_character_name> <optional: use 2nd pass (true/false)");
			return DANCE_ERROR;
		}

		bool use2ndPass = false;
		if (argc >= 5)
		{
			if (strcmp(argv[4], "true") == 0)
				use2ndPass = true;
		}
		this->retargetAnimation(argv[1], argv[2], argv[3], use2ndPass);
		dance::AllViews->postRedisplay();

		return DANCE_OK;
	}
	else if (strcmp(argv[0], "copy_translation") == 0)
	{
		if (argc < 3)
		{
			danceInterp::OutputMessage("Usage: copy_translation <from character name> <to character name>.");
			return DANCE_ERROR;
		}
		Character* from = this->getCharacter(argv[1]);
		Character* to = this->getCharacter(argv[2]);
		if (from == NULL)
		{
			danceInterp::OutputMessage("No character named '%s' found.", argv[1]);
			return DANCE_ERROR;
		}
		else if (to == NULL)
		{
			danceInterp::OutputMessage("No character named '%s' found.", argv[2]);
			return DANCE_ERROR;
		}
		this->copyTranslation(from, to);
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "fix_bone_lengths") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: fix_bone_lengths <character> <reference_character>");
			return DANCE_ERROR;
		}
		Character* character = this->getCharacter(argv[1]);
		if (character == NULL)
		{
			danceInterp::OutputMessage("No character named '%s' found.", argv[1]);
			return DANCE_ERROR;
		}
		Character* refCharacter = this->getCharacter(argv[2]);
		if (character == NULL)
		{
			danceInterp::OutputMessage("No reference character named '%s' found.", argv[2]);
			return DANCE_ERROR;
		}
		character->fixBoneLengths(refCharacter);
		danceInterp::OutputMessage("Bone lengths have been adjusted for character %s", character->getName());
		dance::AllViews->postRedisplay();

		return DANCE_OK;
	}
	else if (strcmp(argv[0], "test") == 0)
	{
		int numTestsSucceeded = 0;
		int numTestsFailed = 0;
		int problems[6][6];
		for (int i = 0; i < 6; i++)
		{
			for (int j = 0; j < 6; j++)
			{
				problems[i][j] = 0;
			}
		}
		Matrix3x3 m1;
		for (double origX = 0.0; origX < M_PI; origX += .1)
		{
			for (double origY = 0.0; origY < M_PI; origY += .1)
			{
				for (double origZ = 0.0; origZ < M_PI; origZ += .1)
				{
					for (int r = Matrix3x3::XYZ; r <= Matrix3x3::ZYX; r++)
					{
						for (int s = Matrix3x3::XYZ; s <= Matrix3x3::ZYX; s++)
						{
							VectorObj v(origX, origY, origZ);
							Matrix3x3 m;
							m.matFromEuler(r, v);
							VectorObj v2;
							m.matToEuler(s, v2);
							Matrix3x3 n;
							n.matFromEuler(s, v2);

							VectorObj p1(10, 10, 10);
							p1 *= m;

							VectorObj p2(10, 10, 10);
							p2 *= n;
					
							if (abs(p1.x() - p2.x()) > .01 || abs(p1.y() - p2.y()) > .01 || abs(p1.y() - p2.y()) > .01)
							{
							//	danceInterp::OutputMessage("Problem in conversion: %d %d (%f %f %f) -> (%f %f %f)", r, s, origX, origY, origZ, v.x(), v.y(), v.z());
								problems[r][s]++;
								numTestsFailed++;
							}
							else
							{
								numTestsSucceeded++;
								//danceInterp::OutputMessage("Conversion OK: %d %d (%f %f %f) -> (%f %f %f)", r, s, origX, origY, origZ, v.x(), v.y(), v.z());
							}
						}
					}
				}
			}
		}
		danceInterp::OutputMessage("Tests succeeded: %d, Tests failed: %d", numTestsSucceeded, numTestsFailed);
		for (int i = 0; i < 6; i++)
		{
			for (int j = 0; j < 6; j++)
			{
				danceInterp::OutputMessage("Problems in source/dest %d/%d: %d", i, j, problems[i][j]);
			}
		}
		return DANCE_OK;
	}

	return DANCE_ERROR;
}

void MotionPlayer::IdleCB(void* object)
{
	MotionPlayer* mplayer = (MotionPlayer*) object;
    if(mplayer->isAnimating())
    {
		
		double curFrameTiming = .033;
		int numCharacters = mplayer->getNumCharacters();
		if (numCharacters > 0)
		{
			Character* c = mplayer->getCharacter(0);
			if (c->getNumJoints() > 0)
			{
				curFrameTiming = c->getRoot()->getFrameTime();
			}
		}

#ifdef WIN32
		DWORD curTime = GetTickCount();
		DWORD timeDiff = curTime - mplayer->getSystemStartTime();
#else
		timeval curTime;
		gettimeofday(&curTime, NULL);
 
		long currentMillis = curTime.tv_sec * 1000 + curTime.tv_usec / 1000;
		long lastMillis = mplayer->getSystemStartTime().tv_sec * 1000 + mplayer->getSystemStartTime().tv_usec / 1000;
		long timeDiff = currentMillis - lastMillis;
#endif
		double t = mplayer->getFPS() * curFrameTiming * ((double) timeDiff) * .001;
		if (!mplayer->isSkipFrames())
			t = mplayer->getCurrentFrame() *  (1.0 / mplayer->getFPS());
		mplayer->setSystemStartTime(curTime);
		if (mplayer->isSkipFrames())
		{
			mplayer->setTime(mplayer->getTime() + t);
		}
		else
		{	
			mplayer->setTime(t);
		}

		double maxTime = 0;
		bool hasCycle = false;
		for (int x = 0; x < numCharacters; x++)
		{
			if (true)//mplayer->isShowCharacter(x))
			{
				Character* character = mplayer->getCharacter(x);
				double charMaxTime = character->getNumFrames() * character->getRoot()->getFrameTime();
				if (charMaxTime > maxTime)
						maxTime = charMaxTime;
				if (character->isCycle())
					hasCycle = true;
			}
		}


		if (mplayer->getTime() > mplayer->getMaxTime() && !hasCycle)
		{
			mplayer->setTime(mplayer->getMinTime());
			if (!mplayer->isSkipFrames())
			{
				mplayer->setCurrentFrame(int(mplayer->getMinTime() * 1.0 / curFrameTiming));
			}
		}
		else
		{
			if (!mplayer->isSkipFrames())
				mplayer->setCurrentFrame(mplayer->getCurrentFrame() + 1);
		}
		dance::Refresh();
    }
}

Character* MotionPlayer::retargetAnimation(const char* characterName, char* skeletonName, char* retargetedCharacterName, bool use2ndPass)
{
	// get the character associated with that name
	Character* character = NULL;
	
	std::vector<Character*>& characters = this->getCharacters();
	// get the character
	for (unsigned int x = 0; x < characters.size(); x++)
	{
		if (strcmp(characters[x]->getName(), characterName) == 0)
		{
			character = characters[x];
			break;
		}
	}
	if (character == NULL)
	{
		danceInterp::OutputMessage("No character with name %s found...", characterName);
		return NULL;
	}

	// get the skeleton associated with the skeleton name
	ArticulatedObject* skeleton = (ArticulatedObject*) dance::AllSystems->get(skeletonName);
	if (skeleton == NULL)
	{
		danceInterp::OutputMessage("No skeleton with name %s found...", skeletonName);
		return NULL;
	}

	// create another character based on the ArticulatedObject
	Character* freshchar = new Character();
	freshchar->setName(retargetedCharacterName);

	int numSkeletonJoints = skeleton->getNumJoints();
		
	// create a CharJoint on the new character for each Joint
	for (int k = 0; k < numSkeletonJoints; k++)
	{
		Joint* skeletonJoint = skeleton->getJoint(k);
		CharJoint* freshCharJoint = new CharJoint(skeletonJoint->getName()); // CharJoint name
		// set the channels
		int channels[6];
		int numChannels = skeletonJoint->getNumAxis();
		int channelStart = 0;
		if (k == 0) // root joint, add global translation, rotation
		{
			numChannels = 6;
			channels[0] = CharJoint::XPOSITION;
			channels[1] = CharJoint::YPOSITION;
			channels[2] = CharJoint::ZPOSITION;
			channelStart = 3;
		}
		// get the proper rotations and rotation orderings
		for (int a = channelStart; a < numChannels; a++)
		{
			double axis[3][3];
			skeletonJoint->getAxis(axis);
			if (axis[a - channelStart][0] == 1.0 && axis[a - channelStart][1] == 0.0 && axis[a - channelStart][2] == 0.0) // x-axis
			{
				channels[a] = CharJoint::XROTATION;
			}
			else if (axis[a - channelStart][0] == 0.0 && axis[a - channelStart][1] == 1.0 && axis[a - channelStart][2] == 0.0) // y-axis
			{
				channels[a] = CharJoint::YROTATION;
			}
			else if (axis[a - channelStart][0] == 0.0 && axis[a - channelStart][1] == 0.0 && axis[a - channelStart][2] == 1.0) // z-axis
			{
				channels[a] = CharJoint::ZROTATION;
			}
			else
			{
				danceInterp::OutputMessage("Unknown channel #%d during retargeting for %s: %d", a, freshCharJoint->getName(), channels[a]); 
			}
		}
                if (numChannels == 0 && skeletonJoint->getJointType() == J_BALL)
                {
                        numChannels = 3;
                        channels[0] = CharJoint::XROTATION;
                        channels[1] = CharJoint::YROTATION;
                        channels[2] = CharJoint::ZROTATION;
                }
		freshCharJoint->setChannels(numChannels, channels);
		if (k == 0) // set the root if this is the first joint
			freshchar->setRoot(freshCharJoint);
		// calculate the offsets of the joints
		if (k == 0)
		{
			Vector rootOffset;
			skeletonJoint->getInbToJoint(rootOffset);
			freshCharJoint->setOffset(rootOffset[0], rootOffset[1], rootOffset[2]);
		}
		else
		{
			// find the parent joint in the ArticulatedObject hierarchy 
                        // in order to determine the hierarchy and the offsets
			Joint* skeletonJointParent = NULL;
			bool foundParent = false;
			for (int p = 0; p < numSkeletonJoints; p++)
			{
				skeletonJointParent = skeleton->getJoint(p);
				Link* link = skeletonJointParent->getOutboardLink();
                                if (!link)
                                        continue;
				int numChildLinks = link->getNumChildLinks();
				Link** children = link->getChildLinks();
				for (int c = 0; c < numChildLinks; c++) // iterate through the children
				{
					Joint* childJoint = children[c]->getParentJoint();
                                        bool foundChild = false;
					if (childJoint == skeletonJoint)
					{
                                                foundChild = true;
						// found match, now find appropriate CharJoint
						for (int cj = 0; cj < freshchar->getNumJoints(); cj++)
						{
							CharJoint* charJointMatcher = freshchar->getJointByIndex(cj);

							if (strcmp(charJointMatcher->getName(),
skeletonJointParent->getName()) == 0)
							{
								charJointMatcher->addChild(freshCharJoint);
								freshCharJoint->setParent(charJointMatcher);
                                                                freshCharJoint->getCharacter()->recalculateJointList();

								foundParent = true;
								break;
							}
				                        if (foundParent)
					                 break;
						}
                                        }
				        if (foundChild)
				            break;
				}
			}
                        if (!foundParent)
                        {
                                        danceInterp::OutputMessage("Could not find parent in new hierarchy for joint %s...\n", freshCharJoint->getName());
                        }
                        else
                        {
                                // determine the offset of this joint from the parent joint
                                Vector vecIn;
                                skeletonJoint->getInbToJoint(vecIn);
                                // displace by the parent joint
                                Vector parentOut;
                                skeletonJointParent->getBodyToJoint(parentOut);
                                parentOut[0] *= -1.0; parentOut[1] *= -1.0; parentOut[2] *= -1.0; 
                                Vector vecSum;
                                VecAdd(vecSum, vecIn, parentOut);
                                freshCharJoint->setOffset(vecSum[0], vecSum[1], vecSum[2]);
                        }

		}

		// is this an end-effector?
		Link* link = skeletonJoint->getOutboardLink();
		if (link->getNumChildLinks() == 0)
		{
			freshCharJoint->isEndEffector();
			Vector endEffectorOffset;
			link->getEndEffector(endEffectorOffset);
			freshCharJoint->setEndEffector(true);
			freshCharJoint->setEndEffectorOffset(endEffectorOffset[0], endEffectorOffset[1], endEffectorOffset[2]);
			freshCharJoint->setEndSiteName("");
		}
	}
	
	// create a mapping from the old character to the new character
	int numSourceDOF = character->getNumDOF();
	int numTargetDOF = skeleton->getStateSize();
	int numCharJoints = character->getNumJoints();
	int* charToSkelJointMap = new int[numCharJoints];

	// find a mapping between the joints
	for (int j = 0; j < numCharJoints; j++)
	{
		charToSkelJointMap[j] = -1;
		CharJoint* charJoint = character->getJointByIndex(j);
		// find the matching joint and matching index on the target
		//int curDOF = 0;
		//bool found = false;
		for (int k = 0; k < freshchar->getNumJoints(); k++)
		{
			CharJoint* freshJoint = freshchar->getJointByIndex(k);
			if (jointMatch(charJoint->getName(), freshJoint->getName()))
			{
				danceInterp::OutputMessage("Found map from %s to %s", charJoint->getName(), freshJoint->getName());
				charToSkelJointMap[j] = k;
				break;
			}
		}
		if (charToSkelJointMap[j] == -1)
		{
			danceInterp::OutputMessage("No mapping for joint %s, joint's DOF will be ignored...", charJoint->getName());
		}
	}

	// verify that there aren't two mappings to the same target joint
	for (int g = 0; g < numCharJoints; g++)
	{
		int targetIndex = charToSkelJointMap[g];
		if (targetIndex == -1)
			continue;
		for (int h = g + 1; h < numCharJoints; h++)
		{
			if (charToSkelJointMap[h] == targetIndex)
			{
				CharJoint* multipleMatchJoint = character->getJointByIndex(g);
				danceInterp::OutputMessage("Multiple matches for joint %s, ignoring second and greater matches...", multipleMatchJoint->getName());
				charToSkelJointMap[h] = -1;
			}
		}
	}

	// create the reverse mapping, from target to source
	int* skelToCharJointMap = new int[freshchar->getNumJoints()];
	for (int a = 0; a < freshchar->getNumJoints(); a++)
	{
		skelToCharJointMap[a] = -1;
		for (int b = 0; b < numCharJoints; b++)
		{
			if (charToSkelJointMap[b] == a)
			{
				skelToCharJointMap[a] = b;
				break;
			}
		}
		if (skelToCharJointMap[a] == -1)
			danceInterp::OutputMessage("Problem developing reverse mapping from target character to original character, please check code...");
	}

	// now that we have two characters, scale the global translations according to their respective heights
	Vector srcMin, srcMax;
	character->getBoundingBox(-1, srcMin, srcMax);
	Vector targetMin, targetMax;
	freshchar->getBoundingBox(-1, targetMin, targetMax);
	// determine the scale as a ratio of their relative heights
	double scale = (targetMax[1] - targetMin[1]) / (srcMax[1] - srcMin[1]);

	// show the joint mapping from source to target
	//for (int jm = 0; jm < numCharJoints; jm++)
	//	danceInterp::OutputMessage("%d -> %d", jm, charToSkelJointMap[jm]);

	// first pass:
	// now that the joints have been mapped, convert each of the 
        // joint and frames according the axis translations
	for (int i = 0; i < numCharJoints; i++)
	{
		CharJoint* srcJoint = character->getJointByIndex(i);
		int targetIndex = charToSkelJointMap[i];
		if (targetIndex == -1)
		{
			danceInterp::OutputMessage("No mapping for %s found, skipping joint...\n", srcJoint->getName());
			continue;
		}
		CharJoint* targetJoint = freshchar->getJointByIndex(targetIndex);

		// set the frame time
		targetJoint->setFrameTime(srcJoint->getFrameTime());

		// determine the rotation order of the source joint
		int srcChannels[6];
		srcJoint->getChannels(srcChannels);
		int numSrcChannels = srcJoint->getNumChannels();
		int srcOrder = CharJoint::determineRotationOrder(srcChannels, numSrcChannels, srcJoint);

		// determine the rotation order of the target joint
		int destChannels[6];
		targetJoint->getChannels(destChannels);
		int numDestChannels = targetJoint->getNumChannels();
		int destOrder = CharJoint::determineRotationOrder(destChannels, numDestChannels, targetJoint);

		for (int f = 0; f < srcJoint->getNumFrames() ; f++)
		{
			double srcFrame[6] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
			srcJoint->getFrames(f, srcFrame);
if (i == 0) danceInterp::OutputMessage("Frame values: %f %f %f %f %f %f", srcFrame[0], srcFrame[1], srcFrame[2], srcFrame[3], srcFrame[4], srcFrame[5]);

			// map this frame to rotation order
			int srcIndex = 0;
			if (i == 0) // root joint
				srcIndex = 3;
			VectorObj v1;
			v1.clear();
			switch (srcOrder)
			{
			case Matrix3x3::XYZ:
				v1.assign(srcFrame[srcIndex + 0], srcFrame[srcIndex + 1], srcFrame[srcIndex + 2]);
				break;
			case Matrix3x3::XZY:
				v1.assign(srcFrame[srcIndex + 0], srcFrame[srcIndex + 2], srcFrame[srcIndex + 1]);
				break;
			case Matrix3x3::YXZ:
				v1.assign(srcFrame[srcIndex + 1], srcFrame[srcIndex + 0], srcFrame[srcIndex + 2]);
				break;
			case Matrix3x3::YZX:
				v1.assign(srcFrame[srcIndex + 2], srcFrame[srcIndex + 0], srcFrame[srcIndex + 1]);
				break;
			case Matrix3x3::ZXY:
std::cout << "USING ZXY!" << std::endl;
				v1.assign(srcFrame[srcIndex + 1], srcFrame[srcIndex + 2], srcFrame[srcIndex + 0]);
				break;
			case Matrix3x3::ZYX:
				v1.assign(srcFrame[srcIndex + 2], srcFrame[srcIndex + 1], srcFrame[srcIndex + 0]);
				break;
			default:
				danceInterp::OutputMessage("Unknown source ordering: %d for joint %s...", srcOrder, srcJoint->getName());
			}

//if (f < 3) danceInterp::OutputMessage("Value of retrieved frame %d is %4.4lf %4.4lf %4.4lf", f, v1.x(), v1.y(), v1.z());
			// convert to radians
			v1.assign((v1.x() / 180.0) * M_PI, (v1.y() / 180.0) * M_PI, (v1.z() / 180.0) * M_PI);

			Matrix3x3 m1;
			m1.identity();
			m1.matFromEuler(srcOrder, v1);
			
			VectorObj v2;
			m1.matToEuler(destOrder, v2, false);


			// convert back to degrees
			v2.assign((v2.x() / M_PI) * 180.0, (v2.y() / M_PI) * 180.0, (v2.z() / M_PI) * 180.0);


//if (f < 3) danceInterp::OutputMessage("Value after matrix conversion is %4.4lf %4.4lf %4.4lf", v2.x(), v2.y(), v2.z());
			
			double destFrame[6] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
			if (i == 0) // copy global position
			{
				destFrame[0] = srcFrame[0] * scale; 
				destFrame[1] = srcFrame[1] * scale;
				destFrame[2] = srcFrame[2] * scale;
			}
			switch (destOrder)
			{
			case Matrix3x3::XYZ:
				destFrame[srcIndex + 0] = v2.x();
				destFrame[srcIndex + 1] = v2.y();
				destFrame[srcIndex + 2] = v2.z();
				//v2.assign(destFrame[srcIndex + 0], destFrame[srcIndex + 1], destFrame[srcIndex + 2]);
				break;
			case Matrix3x3::XZY:
				destFrame[srcIndex + 0] = v2.x();
				destFrame[srcIndex + 1] = v2.z();
				destFrame[srcIndex + 2] = v2.y();
				//v2.assign(destFrame[srcIndex + 0], destFrame[srcIndex + 2], destFrame[srcIndex + 1]);
				break;
			case Matrix3x3::YXZ:
				destFrame[srcIndex + 0] = v2.y();
				destFrame[srcIndex + 1] = v2.x();
				destFrame[srcIndex + 2] = v2.z();
				//v2.assign(destFrame[srcIndex + 1], destFrame[srcIndex + 0], destFrame[srcIndex + 2]);
				break;
			case Matrix3x3::YZX:
				destFrame[srcIndex + 0] = v2.y();
				destFrame[srcIndex + 1] = v2.z();
				destFrame[srcIndex + 2] = v2.x();
				//v2.assign(destFrame[srcIndex + 1], destFrame[srcIndex + 2], destFrame[srcIndex + 1]);
				break;
			case Matrix3x3::ZXY:
				destFrame[srcIndex + 0] = v2.z();
				destFrame[srcIndex + 1] = v2.x();
				destFrame[srcIndex + 2] = v2.y();
				//v2.assign(destFrame[srcIndex + 2], destFrame[srcIndex + 0], destFrame[srcIndex + 1]);
				break;
			case Matrix3x3::ZYX:
				destFrame[srcIndex + 0] = v2.z();
				destFrame[srcIndex + 1] = v2.y();
				destFrame[srcIndex + 2] = v2.x();
				//v2.assign(destFrame[srcIndex + 2], destFrame[srcIndex + 1], destFrame[srcIndex + 0]);
				break;
			default:
				danceInterp::OutputMessage("Unknown target ordering: %d for joint %s...", destOrder, targetJoint->getName());
			}
if (true)//i == 0)
{
destFrame[0] = 0;
destFrame[1] = 0;
destFrame[2] = 0;
destFrame[3] = 0;
destFrame[4] = 0;
destFrame[5] = 0;
}
			// write this frame to the target joint
			targetJoint->addFrame(destFrame);
//if (f < 3) 			danceInterp::OutputMessage("Added frame for joint %s and at time %d: %f %f %f", targetJoint->getName(), f, destFrame[0], destFrame[1], destFrame[2]);
		}
	}


	if (use2ndPass)
	{
		// create the End User Master skeleton by locating matching joints of the End User Slave then using the positioning of the Body Master
		// taken from Monzani
		Character* endUserMaster = new Character();
		endUserMaster->setName("endUserMaster");

		// second pass:
		// compare the virtual bones' joint angles of the 'End User Master' skeleton with those of the 'End User Slave' skeleton
		// since we are traversing throught the jonts in order, we are also traversing from parent to child, thus no child will be evaluated before its parent
		for (int i = 0; i < freshchar->getNumJoints(); i++)
		{
			CharJoint* targetJoint = freshchar->getJointByIndex(i);
			int srcIndex = skelToCharJointMap[i];
			CharJoint* srcJoint = character->getJointByIndex(srcIndex);
			int targetIndex = charToSkelJointMap[i];
			CharJoint* endUserParentJoint = NULL;

			// copy this joint to the end user master skeleton
			CharJoint* endUserMasterJoint = targetJoint->copy(endUserMaster, NULL, 0, targetJoint->getNumFrames() - 1);
			if (endUserMaster->getNumJoints() == 0)
			{
				endUserMaster->setRoot(endUserMasterJoint);
				endUserMasterJoint->setParent(NULL);
				danceInterp::OutputMessage("Set root link to %s", endUserMasterJoint->getName());
			}
			else
			{
				bool foundParent = false;
				for (int x = 0; x < endUserMaster->getNumJoints(); x++)
				{
					CharJoint* masterParentJoint = endUserMaster->getJointByIndex(x);
					if (strcmp(masterParentJoint->getName(), targetJoint->getParent()->getName()) == 0)
					{
						endUserParentJoint = targetJoint->getParent();
						endUserMasterJoint->setParent(masterParentJoint);
						masterParentJoint->addChild(endUserMasterJoint);
						foundParent = true;
						//danceInterp::OutputMessage("Set parent of link %s to %s", endUserMasterJoint->getName(), masterParentJoint->getName());
						endUserMaster->recalculateJointList();
						break;
					}
				}
				if (!foundParent)
				{
					danceInterp::OutputMessage("Could not find parent of joint %s - this is a problem, please check the code...", endUserMasterJoint->getName());
				}
			}

			if (endUserMasterJoint->getParent() == NULL)
			{
				endUserMasterJoint->setOffset(0.0, 0.0, 0.0);
				//danceInterp::OutputMessage("Placed %s it at location (0, 0, 0)", endUserMasterJoint->getName());
			}
			else
			{
				// determine the location of this joint from the 'Body Master' skeleton
				Vector locA = {0.0, 0.0, 0.0};
				srcJoint->getWorldCoord(0.0, locA);
				// subtract the world coordinates of the parent to get the offset
				// obtain the Body Master source joint's parent
				Vector locB = {0.0, 0.0, 0.0};

				CharJoint* bodyMasterParentJoint = NULL;
				for (int x = 0; x < character->getNumJoints(); x++)
				{
					bodyMasterParentJoint = character->getJointByIndex(x);
					if (jointMatch(bodyMasterParentJoint->getName(), endUserParentJoint->getName()))
					{
						bodyMasterParentJoint->getWorldCoord(0.0, locB);
						break;
					}
				}

				endUserMasterJoint->setOffset(locA[0] - locB[0], locA[1] - locB[1], locA[2] - locB[2]);
				Vector offset;
				endUserMasterJoint->getOffset(offset);
				//danceInterp::OutputMessage("Placed %s at location (%f, %f, %f)", endUserMasterJoint->getName(), offset[0], offset[1], offset[2]);
			}	
		}

		// now that:
		// 1) the end user master skeleton has been created, and 
		// 2) the matrices  have been copied verbatim onto a matching joint, 
		// we compare the orientation of the the two skeletons and adjust the angle if necessary
		for (int j = 0; j < character->getNumJoints(); j++)
		{
			CharJoint* bodyMasterJoint = character->getJointByIndex(j);
			int endUserMasterJointIndex = charToSkelJointMap[j];
			if (endUserMasterJointIndex == -1) // ignore non-matching joints - we'll deal with them when we locate the child joints
				continue;
			CharJoint* endUserMasterJoint = endUserMaster->getJointByIndex(endUserMasterJointIndex);
			// is the parent of this joint the same as the parent of the body master's joint?
			if (endUserMasterJoint->getParent() == NULL)
				continue; // ignore the root joint for the end user master
			if (bodyMasterJoint->getParent() == NULL)
				continue; // ignore the root joint for the body master
			// compare the angle between the end user master and its parent with the body master and the parent's match
			CharJoint* endUserMasterParentJoint = endUserMasterJoint->getParent();
			CharJoint* bodyMasterParentJoint = NULL;
			// find the body master joint that matches the end user master parent joint
			for (int k = 0; k < character->getNumJoints(); k++)
			{
				bodyMasterParentJoint = character->getJointByIndex(k);
				if (jointMatch(bodyMasterParentJoint->getName(), endUserMasterParentJoint->getName()))
				{
					adjustAngles(j, bodyMasterParentJoint, bodyMasterJoint, endUserMasterParentJoint, endUserMasterJoint);
					break;
				}
			}
		}
		// now copy the transformation matrices of the end user master to the end user skeleton
		for (int j = 0; j < freshchar->getNumJoints(); j++)
		{
			CharJoint* endUserMasterJoint = endUserMaster->getJointByIndex(j);
			CharJoint* endUserJoint = freshchar->getJointByIndex(j);
			if (strcmp(endUserMasterJoint->getName(), endUserJoint->getName()) != 0)
				danceInterp::OutputMessage("Problem! End user joint %s does not match end user master joint %s!", endUserJoint->getName(), endUserMasterJoint->getName());
			for (int f = 0; f < endUserJoint->getNumFrames(); f++)
			{
				double frames[6];
				endUserMasterJoint->getFrames(f, frames);
				endUserJoint->setFrame(f, frames);
			}
		}


		if (endUserMaster->verify())
		{
			this->addCharacter(endUserMaster);
		}
		else
		{
			delete endUserMaster;
		}

//		delete endUserMaster;
	}
	
	delete[] charToSkelJointMap;
	delete[] skelToCharJointMap;



	// add empty frames for any joints not matched - this allows mapping to characters with greater degrees of freedom than the original
	int numFreshCharJoints = freshchar->getNumJoints();
	int totalFrames = character->getNumFrames();
	for (int fj = 0; fj < numFreshCharJoints; fj++)
	{
		CharJoint* j = freshchar->getJointByIndex(fj);
		int jframes = j->getNumFrames();
		if (jframes < totalFrames)
		{
			double frame[6] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
			for (int p = 0; p < totalFrames - jframes; p++)
			{
				j->addFrame(frame);
			}
		}
	}

	this->addCharacter(freshchar);
	danceInterp::OutputMessage("Retargeting to %s completed...", skeleton->getName());
	return freshchar;
}

void MotionPlayer::adjustAngles(int jointNum, CharJoint* srcParent, CharJoint* srcChild, CharJoint* targetParent, CharJoint* targetChild)
{
	for (int f = 0; f < srcChild->getNumFrames() ; f++)
	{
		double srcFrame[6] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
		double destFrame[6] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};

		int srcChannels[6];
		srcChild->getChannels(srcChannels);
		//int numChannels = srcChild->getNumChannels();
		//int srcOrder = CharJoint::determineRotationOrder(srcChannels, numChannels, srcChild);

		int destChannels[6];
		targetChild->getChannels(destChannels);
		int numTargetChannels = targetChild->getNumChannels();
		int destOrder = CharJoint::determineRotationOrder(destChannels, numTargetChannels, targetChild);

		srcChild->getFrames(f, srcFrame);
		targetChild->getFrames(f, destFrame);

		// get the relative postion of the source node
		Vector aVec;
		srcChild->getLocalCoordToJoint(srcChild->getFrameTime() * f, aVec, srcParent);
//		VecNormalize(aVec);
		

		// get the relative postion of the target node
		Vector bVec;
		targetChild->getLocalCoordToJoint(targetChild->getFrameTime() * f, bVec, targetParent);
//		VecNormalize(bVec);

		double denominator = VecLength(aVec) * VecLength(bVec);
		if (abs(denominator) < .00001) // avoid a divide-by zero problem00.

		{
			danceInterp::OutputMessage("Divide by zero problem avoided...");
			continue;
		}
		// calculate the angle between those two joints
		double rad = acos( VecDotProd(aVec, bVec) / denominator );
//danceInterp::OutputMessage("Angle difference between %s and %s is %f at frame %d", srcChild->getName(), srcParent->getName(), rad * 180 / M_PI, f);

		// apply a rotation around an axis normal to these two vectors
		// first, get the normal axis
		Vector normal;
		VecCrossProd(normal,  aVec, bVec);
		VecNormalize(normal);
		Vector origin = {0.0, 0.0, 0.0};
		// second, apply a rotation around this axis
		ArbMatrix adjustmentMatrix(4, 4);

		// generate rotation in the proper direction
		// if the z-coordinate of the normal is positive, apply a negative rotation 
		if (normal[2] < 0.0) // using RHS, we want to rotate aVec until it matches bVec
			rad = -rad;
//		if (normal[2] > 0.0) // using RHS, we want to rotate aVec until it matches bVec
//			rad = -rad;

//danceInterp::OutputMessage("Normal: %f %f %f", normal[0], normal[1], normal[2]);
		
		rotateArbitraryAxis(normal, origin, rad, adjustmentMatrix);

		// multiply this rotation matrix by the transformation matrix of the target joint
		// map this frame to rotation order
		int srcIndex = 0;
		if (jointNum == 0) // root joint
			srcIndex = 3;
		VectorObj v1;
		v1.clear();
		switch (destOrder)
		{
		case Matrix3x3::XYZ:
			v1.assign(destFrame[srcIndex + 0], destFrame[srcIndex + 1], destFrame[srcIndex + 2]);
			break;
		case Matrix3x3::XZY:
			v1.assign(destFrame[srcIndex + 0], destFrame[srcIndex + 2], destFrame[srcIndex + 1]);
			break;
		case Matrix3x3::YXZ:
			v1.assign(destFrame[srcIndex + 1], destFrame[srcIndex + 0], destFrame[srcIndex + 2]);
			break;
		case Matrix3x3::YZX:
			v1.assign(destFrame[srcIndex + 2], destFrame[srcIndex + 0], destFrame[srcIndex + 1]);
			break;
		case Matrix3x3::ZXY:
			v1.assign(destFrame[srcIndex + 1], destFrame[srcIndex + 2], destFrame[srcIndex + 0]);
			break;
		case Matrix3x3::ZYX:
			v1.assign(destFrame[srcIndex + 2], destFrame[srcIndex + 1], destFrame[srcIndex + 0]);
			break;
		default:
			danceInterp::OutputMessage("Unknown source ordering: %d for joint %s...", destOrder, targetChild->getName());
		}

		// convert values to radians from degrees
		v1.assign(v1.x() * M_PI / 180, v1.y() * M_PI / 180, v1.z() * M_PI / 180);

		Matrix3x3 m1;
		m1.matFromEuler(destOrder, v1);
		ArbMatrix dupMatrix(4, 4);
		dupMatrix.setIdentity();
		dupMatrix.elem(0, 0) = m1[0][0];
		dupMatrix.elem(0, 1) = m1[0][1];
		dupMatrix.elem(0, 2) = m1[0][2];
		dupMatrix.elem(1, 0) = m1[1][0];
		dupMatrix.elem(1, 1) = m1[1][1];
		dupMatrix.elem(1, 2) = m1[1][2];
		dupMatrix.elem(2, 0) = m1[2][0];
		dupMatrix.elem(2, 1) = m1[2][1];
		dupMatrix.elem(2, 2) = m1[2][2];

		ArbMatrix final(4, 4);
/*
danceInterp::OutputMessage("Adjustment matrix:");
for (r1 = 0; r1 < 4; r1++)
danceInterp::OutputMessage("%f %f %f %f\n", adjustmentMatrix.elem(r1,0), adjustmentMatrix.elem(r1,1), adjustmentMatrix.elem(r1,2), adjustmentMatrix.elem(r1,3));
danceInterp::OutputMessage("Converted matrix:");
for (r1 = 0; r1 < 3; r1++)
danceInterp::OutputMessage("%f %f %f \n", dupMatrix.elem(r1,0), dupMatrix.elem(r1,1), dupMatrix.elem(r1,2));
*/	
		dupMatrix.mult(final, adjustmentMatrix);

/*
danceInterp::OutputMessage("Result:");
for (r1 = 0; r1 < 3; r1++)
danceInterp::OutputMessage("%f %f %f\n", final.elem(r1,0), final.elem(r1,1), final.elem(r1,2));
*/				
		// copy back into a matrix and then convert into individual values. !! Problem: We're losing the translation - how can we preserve it?
		Matrix3x3 retMatrix;
		retMatrix.assignRow(0, VectorObj(final.elem(0, 0), final.elem(0, 1), final.elem(0, 2)));
		retMatrix.assignRow(1, VectorObj(final.elem(1, 0), final.elem(1, 1), final.elem(1, 2)));
		retMatrix.assignRow(2, VectorObj(final.elem(2, 0), final.elem(2, 1), final.elem(2, 2)));

		VectorObj v2;
		retMatrix.matToEuler(destOrder, v2, false);

		// convert values to degrees from radians
		v2.assign(v2.x() * 180 / M_PI, v2.y() * 180 / M_PI, v2.z() * 180 / M_PI);

	//	danceInterp::OutputMessage("Old values: %f, %f, %f, new values: %f %f %f", srcFrame[0], srcFrame[1], srcFrame[2], v2.x(), v2.y(), v2.z());

		// copy the rotations back to the joint
		switch (destOrder)
		{
		case Matrix3x3::XYZ:
			destFrame[srcIndex + 0] = v2.x();
			destFrame[srcIndex + 1] = v2.y();
			destFrame[srcIndex + 2] = v2.z();
			//v2.assign(destFrame[srcIndex + 0], destFrame[srcIndex + 1], destFrame[srcIndex + 2]);
			break;
		case Matrix3x3::XZY:
			destFrame[srcIndex + 0] = v2.x();
			destFrame[srcIndex + 1] = v2.z();
			destFrame[srcIndex + 2] = v2.y();
			//v2.assign(destFrame[srcIndex + 0], destFrame[srcIndex + 2], destFrame[srcIndex + 1]);
			break;
		case Matrix3x3::YXZ:
			destFrame[srcIndex + 0] = v2.y();
			destFrame[srcIndex + 1] = v2.x();
			destFrame[srcIndex + 2] = v2.z();
			//v2.assign(destFrame[srcIndex + 1], destFrame[srcIndex + 0], destFrame[srcIndex + 2]);
			break;
		case Matrix3x3::YZX:
			destFrame[srcIndex + 0] = v2.y();
			destFrame[srcIndex + 1] = v2.z();
			destFrame[srcIndex + 2] = v2.x();
			//v2.assign(destFrame[srcIndex + 1], destFrame[srcIndex + 2], destFrame[srcIndex + 1]);
			break;
		case Matrix3x3::ZXY:
			destFrame[srcIndex + 0] = v2.z();
			destFrame[srcIndex + 1] = v2.x();
			destFrame[srcIndex + 2] = v2.y();
			//v2.assign(destFrame[srcIndex + 2], destFrame[srcIndex + 0], destFrame[srcIndex + 1]);
			break;
		case Matrix3x3::ZYX:
			destFrame[srcIndex + 0] = v2.z();
			destFrame[srcIndex + 1] = v2.y();
			destFrame[srcIndex + 2] = v2.x();
			//v2.assign(destFrame[srcIndex + 2], destFrame[srcIndex + 1], destFrame[srcIndex + 0]);
			break;
		default:
			danceInterp::OutputMessage("Unknown target ordering: %d for joint %s...", destOrder, targetChild->getName());
		}
		// copy the new values back to the joint
		for (int c = 0; c < numTargetChannels; c++)
			targetChild->setFrame(f, destFrame[c], c);
	}
}

bool MotionPlayer::jointMatch(std::string s, std::string d)
{
	if (m_mapper.size() == 0)
	{ // initialize the mapper with mappings from the ArticulatedObject
          // to the Character
          // NOTE: This mapping should be assigned with a UI that allows
          //       the user to interactively choose the mapping or
          //       load a file that contains these mappings.
		m_mapper.insert(std::pair<std::string, std::string>("rootMOC","Hip"));
		m_mapper.insert(std::pair<std::string, std::string>("UpperTorsoMOC","Trunk_comp"));
		m_mapper.insert(std::pair<std::string, std::string>("NeckMOC","Neck"));
		m_mapper.insert(std::pair<std::string, std::string>("HeadMOC","Head_comp"));
		m_mapper.insert(std::pair<std::string,
std::string>("LeftShoulderMOC","Left_Shoulder"));
		m_mapper.insert(std::pair<std::string, std::string>("LeftElbowMOC","Left_Forearm"));
		m_mapper.insert(std::pair<std::string, std::string>("LeftHandMOC","Left_Hand"));
		m_mapper.insert(std::pair<std::string,
std::string>("RightShoulderMOC","Right_Shoulder"));
		m_mapper.insert(std::pair<std::string,
std::string>("RightElbowMOC","Right_Forearm"));
		m_mapper.insert(std::pair<std::string, std::string>("RightHandMOC","Right_Hand"));
		m_mapper.insert(std::pair<std::string, std::string>("LeftUpperLegMOC","Left_Thigh"));
		m_mapper.insert(std::pair<std::string, std::string>("LeftLowerLegMOC","Left_Shin"));
		m_mapper.insert(std::pair<std::string, std::string>("LeftHeelMOC","Left_Foot"));
		m_mapper.insert(std::pair<std::string,
std::string>("RightUpperLegMOC","Right_Thigh"));
		m_mapper.insert(std::pair<std::string,
std::string>("RightLowerLegMOC","Right_Shin"));
		m_mapper.insert(std::pair<std::string, std::string>("RightHeelMOC","Right_Foot"));

/*		// additional mappings for DANCE const character that has a collar
		vector<const char*>* t17 = new vector<const char*>;
		t17->push_back("Right_Collar");
		m_mapper["rCollar"] = t17;

		vector<const char*>* t18 = new vector<const char*>;
		t18->push_back("Left_Collar");
		m_mapper["lCollar"] = t18;

		// mappings for joints with spaces
		vector<const char*>* t20 = new vector<const char*>;
		t20->push_back("Right_Collar");
		m_mapper["Right Collar"] = t20;

		vector<const char*>* t21 = new vector<const char*>;
		t21->push_back("Left_Collar");
		m_mapper["Left Collar"] = t21;

		vector<const char*>* t22 = new vector<const char*>;
		t22->push_back("Right_Shoulder");
		m_mapper["Right Shoulder"] = t22;

		vector<const char*>* t23 = new vector<const char*>;
		t23->push_back("Left_Shoulder");
		m_mapper["Left Shoulder"] = t23;	

		vector<const char*>* t24 = new vector<const char*>;
		t24->push_back("Right_Forearm");
		m_mapper["Right Forearm"] = t24;	

		vector<const char*>* t25 = new vector<const char*>;
		t25->push_back("Left_Forearm");
		m_mapper["Left Forearm"] = t25;	

		vector<const char*>* t26 = new vector<const char*>;
		t26->push_back("Right_Hand");
		m_mapper["Right Hand"] = t26;	

		vector<const char*>* t27 = new vector<const char*>;
		t27->push_back("Left_Hand");
		m_mapper["Left Hand"] = t27;	

		vector<const char*>* t28 = new vector<const char*>;
		t28->push_back("Right_Thigh");
		m_mapper["Right Thigh"] = t28;	

		vector<const char*>* t29 = new vector<const char*>;
		t29->push_back("Left_Thigh");
		m_mapper["Left Thigh"] = t29;	

		vector<const char*>* t30 = new vector<const char*>;
		t30->push_back("Right_Shin");
		m_mapper["Right Shin"] = t30;	

		vector<const char*>* t31 = new vector<const char*>;
		t31->push_back("Left_Shin");
		m_mapper["Left Shin"] = t31;	

		vector<const char*>* t32 = new vector<const char*>;
		t32->push_back("Right_Foot");
		m_mapper["Right Foot"] = t32;	

		vector<const char*>* t33 = new vector<const char*>;
		t33->push_back("Left_Foot");
		m_mapper["Left Foot"] = t33;	

		vector<const char*>* t34 = new vector<const char*>;
		t34->push_back("Trunk_comp");
		m_mapper["Abdomen"] = t34;	

		vector<const char*>* t35 = new vector<const char*>;
		t35->push_back("Right_Toe");
		m_mapper["Right Toe"] = t35;	

		vector<const char*>* t36 = new vector<const char*>;
		t36->push_back("Left_Toe");
		m_mapper["Left Toe"] = t36;	

		// mappings for motion graph engine
		vector<const char*>* mg1 = new vector<const char*>;
		mg1->push_back("Hip");
		m_mapper["Center"] = mg1;

		vector<const char*>* mg2 = new vector<const char*>;
		mg2->push_back("Trunk_comp");
		m_mapper["Belly"] = mg2;

		vector<const char*>* mg3 = new vector<const char*>;
		mg3->push_back("Neck");
		m_mapper["Neck"] = mg3;
		
		vector<const char*>* mg4 = new vector<const char*>;
		mg4->push_back("Head_comp");
		m_mapper["Head"] = mg4;
		
		vector<const char*>* mg5 = new vector<const char*>;
		mg5->push_back("Left_Shoulder");
		m_mapper["LeftShoulder"] = mg5;

		vector<const char*>* mg6 = new vector<const char*>;
		mg6->push_back("Left_Forearm");
		m_mapper["LeftElbow"] = mg6;

		vector<const char*>* mg7 = new vector<const char*>;
		mg7->push_back("Left_Hand");
		m_mapper["LeftWrist"] = mg7;

		vector<const char*>* mg8 = new vector<const char*>;
		mg8->push_back("Right_Shoulder");
		m_mapper["RightShoulder"] = mg8;

		vector<const char*>* mg9 = new vector<const char*>;
		mg9->push_back("Right_Forearm");
		m_mapper["RightElbow"] = mg9;

		vector<const char*>* mg10 = new vector<const char*>;
		mg10->push_back("Right_Hand");
		m_mapper["RightWrist"] = mg10;

		vector<const char*>* mg11 = new vector<const char*>;
		mg11->push_back("Left_Thigh");
		m_mapper["LeftHip"] = mg11;

		vector<const char*>* mg12 = new vector<const char*>;
		mg12->push_back("Left_Shin");
		m_mapper["LeftKnee"] = mg12;

		vector<const char*>* mg13 = new vector<const char*>;
		mg13->push_back("Left_Foot");
		m_mapper["LeftAnkle"] = mg13;

		vector<const char*>* mg14 = new vector<const char*>;
		mg14->push_back("Right_Thigh");
		m_mapper["RightHip"] = mg14;

		vector<const char*>* mg15 = new vector<const char*>;
		mg15->push_back("Right_Shin");
		m_mapper["RightKnee"] = mg15;

		vector<const char*>* mg16 = new vector<const char*>;
		mg16->push_back("Right_Foot");
		m_mapper["RightAnkle"] = mg16;

		// additional mappings for DANCE const character that has a collar
		vector<const char*>* mg17 = new vector<const char*>;
		mg17->push_back("Right_Collar");
		m_mapper["RightCollar"] = mg17;

		vector<const char*>* mg18 = new vector<const char*>;
		mg18->push_back("Left_Collar");
		m_mapper["LeftCollar"] = mg18;
*/

	}
        std::map<std::string, std::string>::iterator iter = m_mapper.find(s);
        if (iter != m_mapper.end()) 
        {
                if ((*iter).second == d)
                {
                        return true;
                }
                else
                {
                        return false;
                }               
        }
        else
        {
                return false;
        }
/*
#ifdef WIN32
#define strcasecmp stricmp
#endif
	vector<const char*> *list = NULL;
	map<const char*, vector<const char*>* >::iterator iter;
	for (iter = m_mapper.begin(); iter != m_mapper.end(); iter++)
	{
		if (strcasecmp(s, iter->first) == 0)
		{
			list = iter->second;
			break;
		}
	}
	
	if (list != NULL)
	{
		for (unsigned int x = 0; x < list->size(); x++)
		{
			if (strcasecmp((*list)[x], d) == 0)
			{
				danceInterp::OutputMessage("Found match...");
				return true;
			}
		}
	}
	return false;
        */
}



void MotionPlayer::rotateArbitraryAxis(Vector lineEnd, Vector origin, double theta, ArbMatrix &out)
{
	Vector A;
	A[0] = origin[0];
	A[1] = origin[1];
	A[2] = origin[2];
	Vector B;
	B[0] = lineEnd[0];
	B[1] = lineEnd[1];
	B[2] = lineEnd[2];

	// 1. Create a copy of the line for manipulation.
	Vector A2;
	VecCopy(A2, A);
	Vector B2;
	VecCopy(B2, B);
	// 2. Translate L so one endpoint lies at the origin
	ArbMatrix T(4,4);
	T.elem(0, 0) = 1; 
	T.elem(0, 1) = 0;
	T.elem(0, 2) = 0;
	T.elem(0, 3) = 0;
	T.elem(1, 0) = 0; 
	T.elem(1, 1) = 1;
	T.elem(1, 2) = 0;
	T.elem(1, 3) = 0;
	T.elem(2, 0) = 0; 
	T.elem(2, 1) = 0;
	T.elem(2, 2) = 1;
	T.elem(2, 3) = 0;
	T.elem(3, 0) = -A[0]; 
	T.elem(3, 1) = -A[1];
	T.elem(3, 2) = -A[2];

	T.elem(3, 3) = 1;

/*
danceInterp::OutputMessage("T:");
for (int r1 = 0; r1 < 4; r1++)
	danceInterp::OutputMessage("%f %f %f %f\n", T.elem(r1,0), T.elem(r1,1), T.elem(r1,2), T.elem(r1,3));
*/
	// 3. Rotate around the Y-axis until L lies in the YZ plane.
	ArbMatrix R1(4,4);
  double len1 = sqrt(B2[0] * B2[0] + B2[2] * B2[2]);
  double costheta1, sintheta1;

  if (len1 > 0) {

    costheta1 = B2[2] / len1;
    sintheta1 = B2[0] / len1;

    // This, of course, is the matrix for rotation around the Y axis
	R1.elem(0, 0) = costheta1; 
	R1.elem(0, 1) = 0;
	R1.elem(0, 2) = sintheta1;
	R1.elem(0, 3) = 0;
	R1.elem(1, 0) = 0; 
	R1.elem(1, 1) = 1;
	R1.elem(1, 2) = 0;
	R1.elem(1, 3) = 0;
	R1.elem(2, 0) = -sintheta1; 
	R1.elem(2, 1) = 0;
	R1.elem(2, 2) = costheta1;
	R1.elem(2, 3) = 0;
	R1.elem(3, 0) = 0; 
	R1.elem(3, 1) = 0;
	R1.elem(3, 2) = 0;
	R1.elem(3, 3) = 1;

  } else {

    // Line is already parallel to Y-axis, and therefore already in
    // the YZ plane.  Make this rotation do nothing.  

    R1.setIdentity();
  }

/*
danceInterp::OutputMessage("R1:");
for (r1 = 0; r1 < 4; r1++)
	danceInterp::OutputMessage("%f %f %f %f\n", T.elem(r1,0), T.elem(r1,1), T.elem(r1,2), T.elem(r1,3));
*/
  
  // 4. Rotate around the X axis until L lies on the Z axis.
	ArbMatrix R2(4,4);
  double len2 = sqrt(B2[1] * B2[1] + B2[2] * B2[2]);
  double costheta2, sintheta2;

  if (len2 > 0) {

    costheta2 = B2[2] / len2;
    sintheta2 = B2[1] / len2;

    // This is the X-axis rotation matrix
	R2.elem(0, 0) = 1; 
	R2.elem(0, 1) = 0;
	R2.elem(0, 2) = 0;
	R2.elem(0, 3) = 0;
	R2.elem(1, 0) = 0; 
	R2.elem(1, 1) = costheta2;
	R2.elem(1, 2) = sintheta2;
	R2.elem(1, 3) = 0;
	R2.elem(2, 0) = 0; 
	R2.elem(2, 1) = -sintheta2;
	R2.elem(2, 2) = costheta2;
	R2.elem(2, 3) = 0;
	R2.elem(3, 0) = 0; 
	R2.elem(3, 1) = 0;
	R2.elem(3, 2) = 0;
	R2.elem(3, 3) = 1;
  } else {

    // Should never happen
    R2.setIdentity();
  }

/*
danceInterp::OutputMessage("R2:");
for (r1 = 0; r1 < 4; r1++)
	danceInterp::OutputMessage("%f %f %f %f\n", R2.elem(r1,0), R2.elem(r1,1), R2.elem(r1,2), R2.elem(r1,3));
*/

  // 5. Perform the rotation around the z-axis.
  ArbMatrix R3(4,4);
  	R3.elem(0, 0) =  cos(theta); 
	R3.elem(0, 1) = sin(theta);
	R3.elem(0, 2) = 0;
	R3.elem(0, 3) = 0;
	R3.elem(1, 0) = -sin(theta); 
	R3.elem(1, 1) = cos(theta);
	R3.elem(1, 2) = 0;
	R3.elem(1, 3) = 0;
	R3.elem(2, 0) = 0; 
	R3.elem(2, 1) = 0;
	R3.elem(2, 2) = 1;
	R3.elem(2, 3) = 0;
	R3.elem(3, 0) = 0; 
	R3.elem(3, 1) = 0;
	R3.elem(3, 2) = 0;
	R3.elem(3, 3) = 1;
  
	// 6. Undo Step 4.
    ArbMatrix R2_inv(4,4);

  if (len2 > 0) { 

	R2_inv.elem(0, 0) =  1; 
	R2_inv.elem(0, 1) = 0;
	R2_inv.elem(0, 2) = 0;
	R2_inv.elem(0, 3) = 0;
	R2_inv.elem(1, 0) = 0; 
	R2_inv.elem(1, 1) = costheta2;
	R2_inv.elem(1, 2) = -sintheta2;
	R2_inv.elem(1, 3) = 0;
	R2_inv.elem(2, 0) = 0; 
	R2_inv.elem(2, 1) = sintheta2;
	R2_inv.elem(2, 2) = costheta2;
	R2_inv.elem(2, 3) = 0;
	R2_inv.elem(3, 0) = 0; 
	R2_inv.elem(3, 1) = 0;
	R2_inv.elem(3, 2) = 0;
	R2_inv.elem(3, 3) = 1;

  } else {

    // Obviously, if we skipped this rotation, don't un-rotate.
    // However, as I stated before, this rotation should always
    // happen, so it would be bizarre indeed if control made it here.
    // Oh, well.
    R2_inv.setIdentity();

  }

/*
danceInterp::OutputMessage("R2_INV:");
for (r1 = 0; r1 < 4; r1++)
	danceInterp::OutputMessage("%f %f %f %f\n", R2_inv.elem(r1,0), R2_inv.elem(r1,1), R2_inv.elem(r1,2), R2_inv.elem(r1,3));
*/


  // 7. Undo Step 3.
	ArbMatrix R1_inv(4,4);

  if (len1 > 0) {

	R1_inv.elem(0, 0) =  costheta1; 
	R1_inv.elem(0, 1) = 0;
	R1_inv.elem(0, 2) = -sintheta1;
	R1_inv.elem(0, 3) = 0;
	R1_inv.elem(1, 0) = 0; 
	R1_inv.elem(1, 1) = 1;
	R1_inv.elem(1, 2) = 0;
	R1_inv.elem(1, 3) = 0;
	R1_inv.elem(2, 0) = sintheta1; 
	R1_inv.elem(2, 1) = 0;
	R1_inv.elem(2, 2) = costheta1;
	R1_inv.elem(2, 3) = 0;
	R1_inv.elem(3, 0) = 0; 
	R1_inv.elem(3, 1) = 0;
	R1_inv.elem(3, 2) = 0;
	R1_inv.elem(3, 3) = 1;
	;
  } else {

    R1_inv.setIdentity();

  }
/*
danceInterp::OutputMessage("R1_INV:");
for (r1 = 0; r1 < 4; r1++)
	danceInterp::OutputMessage("%f %f %f %f\n", R1_inv.elem(r1,0), R1_inv.elem(r1,1), R1_inv.elem(r1,2), R1_inv.elem(r1,3));
*/

  // 8. Undo Step 2.
	ArbMatrix T_inv(4,4);

	T_inv.elem(0, 0) =  1; 
	T_inv.elem(0, 1) = 0;
	T_inv.elem(0, 2) = 0;
	T_inv.elem(0, 3) = 0;
	T_inv.elem(1, 0) = 0; 
	T_inv.elem(1, 1) = 1;
	T_inv.elem(1, 2) = 0;
	T_inv.elem(1, 3) = 0;
	T_inv.elem(2, 0) = 0; 
	T_inv.elem(2, 1) = 0;
	T_inv.elem(2, 2) = 1;
	T_inv.elem(2, 3) = 0;
	T_inv.elem(3, 0) = A[0]; 
	T_inv.elem(3, 1) = A[1];
	T_inv.elem(3, 2) =  A[2];
	T_inv.elem(3, 3) = 1;

/*
	danceInterp::OutputMessage("T_INV:");
for (r1 = 0; r1 < 4; r1++)
	danceInterp::OutputMessage("%f %f %f %f\n", T_inv.elem(r1,0), T_inv.elem(r1,1), T_inv.elem(r1,2), T_inv.elem(r1,3));
*/
/*
	danceInterp::OutputMessage("T:");
	T.dump();
	danceInterp::OutputMessage("R1:");
	R1_inv.dump();
	danceInterp::OutputMessage("R2:");
	R2_inv.dump();
	danceInterp::OutputMessage("R3:");
	R3.dump();
	danceInterp::OutputMessage("R2_INV:");
	R2_inv.dump();
	danceInterp::OutputMessage("R1_INV:");
	R1_inv.dump();
	danceInterp::OutputMessage("T_INV:");
	T_inv.dump();
*/

  // Construct the final matrix...
//	out = T * R1 * R2 * R3 * R2_inv * R1_inv * T_inv;
	ArbMatrix temp1(4,4);
	R1_inv.mult(temp1, T_inv);

	ArbMatrix temp2(4,4);
	R2_inv.mult(temp2, temp1);

	ArbMatrix temp3(4,4);
	R3.mult(temp3, temp2);

	ArbMatrix temp4(4,4);
	R2.mult(temp4, temp3);

	ArbMatrix temp5(4,4);
	R1.mult(temp5, temp4);

	T.mult(out, temp5);


	// now transpose it...
	out.transpose();
		
}

fltk::Widget* MotionPlayer::getInterface()
{
	if (m_playerWindow == NULL)
	{
		m_playerWindow = new MotionPlayerWindow(this, 0, 0, 640, 520, this->getName());
		m_playerWindow->updateGUI();
	}

	return m_playerWindow;
}

bool MotionPlayer::isAnimating()
{
	return m_animate;
}

void MotionPlayer::setAnimate(bool val)
{
	m_animate = val;
	if (m_animate)
	{
		fltk::add_idle(MotionPlayer::IdleCB, this);
#ifdef WIN32
		m_sysStartTime = GetTickCount();
#else
		gettimeofday(&m_sysStartTime, NULL);
#endif
	}
	else
	{
		fltk::remove_idle(MotionPlayer::IdleCB, this);
	}
}

bool MotionPlayer::isLooping()
{
	return m_looping;
}

void MotionPlayer::setLooping(bool val)
{
	m_looping = val;
}

void MotionPlayer::setTime(double time)
{
	m_curTime = time;
	// set the time of all the characters
	std::vector<Character*>& characters = this->getCharacters();
	
	for (int c = 0; c < characters.size(); c++)
		characters[c]->setTime(time);

	if (m_playerWindow != NULL)
		m_playerWindow->setTimeSlider(time);
}

void MotionPlayer::setMaxTime(double maxTime)
{
	m_maxTime = maxTime;
	if (getTime() > m_maxTime)
		setTime(m_maxTime);
	if (m_maxTime < getMinTime())
		m_maxTime = getMinTime();

	this->setLastRecordTime(m_maxTime);
}

double MotionPlayer::getMaxTime()
{
	return m_maxTime;
}

void MotionPlayer::setMinTime(double minTime)
{
	m_minTime = minTime;
	if (getTime() < m_minTime)
		setTime(m_minTime);
	if (m_minTime > getMaxTime())
		m_minTime = getMaxTime();
}

double MotionPlayer::getMinTime()
{
	return m_minTime;
}

double MotionPlayer::getTime()
{
	return m_curTime;
}

void MotionPlayer::setFPS(double fps)
{
	m_animationFPS = fps;
}

double MotionPlayer::getFPS()
{
	return m_animationFPS;
}

void MotionPlayer::BeforeAllSimStep(double time, double dt)
{
	if  (isAnimating())
	{
		m_curTime = time;
	}
}

void MotionPlayer::addCharacter(Character* character)
{
		m_playerWindow->updateGUI();
		m_playerWindow->selectCharacter(character);
}

void MotionPlayer::modify()
{
}

void filter(Vector v)
{
	for (int i = 0; i < 3; i++)
		if (abs(v[i]) < .0000001)
			v[i] = 0.0;
}

int MotionPlayer::getNumCharacters()
{
	return getCharacters().size();
}

Character* MotionPlayer::getCharacter(int i)
{
	std::vector<Character*>& characters = this->getCharacters();
	if (i < characters.size())
		return characters[i];
	else
		return NULL;
}

Character* MotionPlayer::getCharacter(const char* name)
{
	std::vector<Character*>& characters = this->getCharacters();
	for (unsigned int i = 0; i < characters.size(); i++)
	{
		if (strcmp(characters[i]->getName(), name) == 0)
			return characters[i];
	}

	return NULL;
}

int MotionPlayer::getCharacterIndex(Character* c)
{
	std::vector<Character*>& characters = this->getCharacters();
	for (unsigned int i = 0; i < characters.size(); i++)
	{
		if (characters[i] == c)
			return i;
	}

	return -1;
}

int MotionPlayer::getCharacterIndex(const char* name)
{
	std::vector<Character*>& characters = this->getCharacters();
	for (unsigned int i = 0; i < characters.size(); i++)
	{
		if (strcmp(characters[i]->getName(), name) == 0)
			return i;
	}

	return -1;
}

void MotionPlayer::deleteCharacter(Character* c)
{
	std::vector<Character*>& characters = this->getCharacters();
	bool found = false;
	vector<Character*>::iterator iter;
	int count = 0;
	for (iter = characters.begin(); iter != characters.end(); iter++)
	{
		if (*iter  == c)
		{
			std::vector<DConnection*> list;
			dance::connectionManager->getFromConnections("joint", c, list);
			for (int i = 0; i < list.size(); i++)
				dance::AllGenericPlugins->remove(list[i]->getTo());
			dance::AllGenericPlugins->remove(*iter);
			found = true;
			break;
		}
		count++;
	}
	if (!found)
	{
		danceInterp::OutputMessage("Could not find character named %s in charater list. Character deleted manually.");
		delete c;
	}

	dance::AllViews->postRedisplay();
}

bool MotionPlayer::runMATLABCommand(const char* command)
{
#ifdef  USEMATLAB
	if (m_engine == NULL) // start the matlab engine
	{
		if (!(m_engine = engOpen("\0")))
		{
			danceInterp::OutputMessage("Cannot start MATLAB engine...%d", m_engine);
			m_engine = NULL;
			return false;
		}
		else
		{
			danceInterp::OutputMessage("MATLAB engine has been started...%d", m_engine);
			engOutputBuffer(m_engine, m_engineBuffer, 512);
		}
	}
	danceInterp::OutputMessage("MATLAB command: %s", command);
	engEvalString(m_engine, command);
	danceInterp::OutputMessage("MATLAB response: %s", m_engineBuffer);
#else
	danceInterp::OutputMessage("MATLAB is not supported in this build...");
#endif

	return true;
}

MotionPlayerWindow* MotionPlayer::getMotionPlayerWindow()
{
	return m_playerWindow;
}

#ifdef WIN32
DWORD MotionPlayer::getSystemStartTime()
#else
timeval MotionPlayer::getSystemStartTime()
#endif
{
	return m_sysStartTime;
}

#ifdef WIN32
void MotionPlayer::setSystemStartTime(DWORD time)
{
	m_sysStartTime = time;
}
#else
void MotionPlayer::setSystemStartTime(timeval time)
{
	m_sysStartTime.tv_sec = time.tv_sec;
	m_sysStartTime.tv_usec = time.tv_usec;
}
#endif

void MotionPlayer::copyTranslation(Character* from, Character* to)
{
	if (from->getRoot()->getNumFrames() != to->getRoot()->getNumFrames())
	{
		danceInterp::OutputMessage("Character '%s' has %d, character '%s' has %d frames. Number of frames needs to match.", from->getName(), from->getRoot()->getNumFrames(), to->getName(), to->getRoot()->getNumFrames());
		return;
	}
	CharJoint* fromRoot = from->getRoot();
	CharJoint* toRoot = to->getRoot();
	vector<CharJoint*> jointListFrom;
	vector<CharJoint*> jointListTo;
	int numJoints = to->getNumJoints();
	for (int j = 0; j < numJoints; j++)
	{
		jointListFrom.push_back(from->getJointByIndex(j));
		jointListTo.push_back(to->getJointByIndex(j));
	}
	for (int f = 0; f < fromRoot->getNumFrames(); f++)
	{
		if (to->isPoints())
		{
			Vector oldPoint;
			Vector newPoint;
			Vector diff;
			for (unsigned int j = 0; j < jointListFrom.size(); j++)
			{
				CharJoint* charJointFrom = jointListFrom[j];
				CharJoint* charJointTo = jointListTo[j];
				if (j == 0)
				{
					if (from->isPoints())
					{
						charJointFrom->getPoint(f, newPoint[0], newPoint[1], newPoint[2]);
						VecNumMul(newPoint, newPoint, charJointFrom->getCharacter()->getScale());
					}
					else
					{
						double frames[6];
						charJointFrom->getFrames(f, frames);
						VecCopy(newPoint, frames);
					}
					charJointTo->getPoint(f, oldPoint[0], oldPoint[1], oldPoint[2]);
					VecSubtract(diff, newPoint, oldPoint);
					charJointTo->setPoint(f, newPoint[0], newPoint[1], newPoint[2]);
				}
				else
				{
					Vector curPoint;
					charJointTo->getPoint(f, curPoint[0], curPoint[1], curPoint[2]);
					charJointTo->setPoint(f, curPoint[0] + diff[0], curPoint[1] + diff[1], curPoint[2] + diff[2]);
					if (charJointTo->isEndEffector())
					{
						Vector endEffPos;
						charJointTo->getEndEffectorPoint(f, endEffPos[0], endEffPos[1], endEffPos[2]);
						charJointTo->setEndEffectorPoint(f, endEffPos[0] + diff[0], endEffPos[1] + diff[1], endEffPos[2] + diff[2]);
						
					}
				}
			}
		}
		else
		{
			double fromFrame[6];
			fromRoot->getFrames(f, fromFrame);
			double toFrame[6];
			toRoot->getFrames(f, toFrame);
			toFrame[0] = fromFrame[0];
			toFrame[1] = fromFrame[1];
			toFrame[2] = fromFrame[2];
			toRoot->setFrame(f, toFrame);
		}
	}
	danceInterp::OutputMessage("Global translation has been copied from character '%s' to character '%s'...", from->getName(), to->getName());
}

void MotionPlayer::clipAnimation(Character* character, double startTime, double endTime)
{
	if (!character)
		return;

	int startFrame = int(startTime * this->getFPS());
	int endFrame = int(endTime * this->getFPS());

	double frames[6];
	for (int j = 0; j < character->getNumJoints(); j++)
	{
		int fromFrame = startFrame;
		int toFrame = 0;
		CharJoint* joint = character->getJointByIndex(j); 
		for (int f = startFrame; f <= endFrame; f++)
		{
			joint->getFrames(fromFrame, frames);
			joint->setFrame(toFrame, frames);
			fromFrame++;
			toFrame++;
		}
		joint->setNumFrames(endFrame - startFrame + 1);
	}
}


void MotionPlayer::render(int argc, char** argv, std::ofstream& file)
{
	if (argc > 0 && strcmp(argv[0],"povray") == 0)
	{
		int numFrames = 0;
		double frameTime = 0.0;

		int numCharacters = this->getNumCharacters();
		for (int c = 0; c < numCharacters; c++)
		{
			Character* character = this->getCharacter(c);
			CharJoint* root = character->getRoot();
			Vector boneColor;
			character->getBoneColor(boneColor);
			Vector jointColor;
			character->getJointColor(jointColor);
			double jointSize = character->getHeight() * character->getJointSize();
			double boneWidth = character->getBoneWidth() / 10.0;

			if (root != NULL)
			{
				numFrames = root->getNumFrames();
				frameTime = root->getFrameTime();
			}

			Vector offset;
			character->getOffset(offset);
//			Vector interpOffset;

			vector<CharJoint*> jointList;
			int numJoints = character->getNumJoints();
			for (int j = 0; j < numJoints; j++)
			{
				CharJoint* joint = character->getJointByIndex(j);
				jointList.push_back(joint);
			}

			double curTime = this->getTime();
			double frameTime = 1.0 / this->getFPS();
			int f = (int) (curTime * frameTime);
			// add any rotation
			Vector rotation;
			character->getRotation(rotation);

			// determine amount of interpolation if necessary
			for (int j = 0; j < numJoints; j++)
			{
				double jointMatrix[4][4];
				double parentMatrix[4][4];

				CharJoint* joint = jointList[j];
				CharJoint* parent = joint->getParent();
				Vector pos;

				// draw the bone
				if (character->isShowBones())
				{
					if (parent != NULL)
					{
						if (parent->getNumChannels() == 0)
							parent = parent->getParent();
						Vector parentPos;
						if (character->isPoints())
						{
							joint->getPoint(f, pos[0], pos[1], pos[2]);
							parent->getPoint(f, parentPos[0], parentPos[1], parentPos[2]);
							VecAdd(pos, pos, offset);
							VecAdd(parentPos, parentPos, offset);
						}
						else
						{
							joint->getWorldTransMatrix(curTime,jointMatrix);
							pos[0] = jointMatrix[3][0]; pos[1] = jointMatrix[3][1]; pos[2] = jointMatrix[3][2];
							parent->getWorldTransMatrix(curTime, parentMatrix);
							parentPos[0] = parentMatrix[3][0]; parentPos[1] = parentMatrix[3][1]; parentPos[2] = parentMatrix[3][2];
						}
						if (pos[0] == parentPos[0] && pos[1] == parentPos[1] && pos[2] == parentPos[2])
						{
							// no length, do not draw
						}
						else
						{
							file << "cylinder {\n";
							file << "<" << pos[0] << ", " << pos[1] << ", " << pos[2] << ">,\n";
							file << "<" << parentPos[0] << ", " << parentPos[1] << ", " << parentPos[2] << ">,\n";
							file << boneWidth << "\n";					
							file << "pigment { color rgb <" << boneColor[0] << ", " << boneColor[1] << ", " << boneColor[2] << ">}\n";
							file << "rotate <" << rotation[0] << ", " << rotation[1] << ", " << rotation[2] << ">\n";
							file << "}\n";
						}
					}
					if (joint->isEndEffector())
					{
						Vector endEffPos;
						if (character->isPoints())
						{
							joint->getEndEffectorPoint(f, endEffPos[0], endEffPos[1], endEffPos[2]);
							VecAdd(endEffPos, endEffPos, offset);
						}
						else
						{
							Vector endEffOffset;
							joint->getEndEffectorOffset(endEffOffset);
							transformPoint_mat(endEffOffset, jointMatrix);
							VecCopy(endEffPos, endEffOffset);
						}
						if (endEffPos[0] == pos[0] && endEffPos[1] == pos[1] && endEffPos[2] == pos[2])
						{
							// no length, do not draw
						}
						else
						{
							file << "cylinder {\n";
							file << "<" << endEffPos[0] << ", " << endEffPos[1] << ", " << endEffPos[2] << ">,\n";
							file << "<" << pos[0] << ", " << pos[1] << ", " << pos[2] << ">,\n";
							file << boneWidth << "\n";					
							file << "pigment { color rgb <" << boneColor[0] << ", " << boneColor[1] << ", " << boneColor[2] << ">}\n";
							file << "rotate <" << rotation[0] << ", " << rotation[1] << ", " << rotation[2] << ">\n";
							file << "}\n";
						}
					}
				}

				// show the joints
				if (character->isShowJoints())
				{
					if (character->isPoints())
					{
						joint->getPoint(f, pos[0], pos[1], pos[2]);
					}
					else
					{
						joint->getWorldTransMatrix(curTime,jointMatrix);
						pos[0] = jointMatrix[3][0]; pos[1] = jointMatrix[3][1]; pos[2] = jointMatrix[3][2];
					}
					file << "sphere {\n  <" << pos[0] << ", " << pos[1] << ", " << pos[2] << ">, " <<  jointSize << "\n";
					file << "pigment { color rgb <" << jointColor[0] << ", " << jointColor[1] << ", " << jointColor[2] << ">}\n";
					file << "rotate <" << rotation[0] << ", " << rotation[1] << ", " << rotation[2] << ">\n";
					file << "}\n";
				}
			}

			// draw the path if indicated
			if (0)//character->isShowTrajectories())
			{
				/*
				std::vector<VectorObj>& path = character->getPath();
				int numFrames = path.size();
				if (numFrames > 0)
				{
					file << "spline {\n";
					file << "linear_spline\n";
					file << path.size() << ",\n";

					for (int f = 0; f < numFrames - 1; f++)
					{
						file << <" << path[f][0] << ", " << path[f][1] << ", " << path[f][2] << ">,\n";	
					}

					file << "pigment { color rgb < 1.0, 1.0, 0.0 >}\n";
					file << "rotate <" << rotation[0] << ", " << rotation[1] << ", " << rotation[2] << ">\n";
					file << "}\n";	
				}
				*/

				// the size of the spline will be dependent on the size of the character
				double height = character->getHeight();
				double lineSize = height / 200.0;
				//std::vector<VectorObj>& path = character->getPath();
				/*if (0) //path.size() > 0)
				{
					int numFrames = path.size();
					for (int f = 0; f < numFrames - 1; f++)
					{
						// make sure that we are not adding a degenerate cylinder
						if (path[f][0] == path[f + 1][0] &&
						    path[f][1] == path[f + 1][1] &&
							path[f][2] == path[f + 1][2])
						{
						}
						else
						{
							file << "cylinder {\n";
							file << "<" << path[f][0] << ", " << path[f][1] << ", " << path[f][2] << ">,\n";
							file << "<" << path[f + 1][0] << ", " << path[f + 1][1] << ", " << path[f + 1][2] << ">,\n";
							file << lineSize << "\n";					
							file << "pigment { color rgb < 1.0, 1.0, 0.0 >}\n";
							file << "rotate <" << rotation[0] << ", " << rotation[1] << ", " << rotation[2] << ">\n";
							file << "}\n";
						}
					}
				}
				*/
				
			}

			file << "\n";
		}
	}
}

int MotionPlayer::getNumPluginDependents()
{
	return 1;
}

const char* MotionPlayer::getPluginDependent(int num)
{
	if (num == 0)
		return "ArticulatedObject";
	else
		return NULL;
}

void MotionPlayer::save(int mode, std::ofstream& file)
{
	char buff[512];

	if (mode == 0)
	{
		file << "dance.instance(\"MotionPlayer\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
		if (this->isAnimating())
		{
			sprintf(buff, "\"animate\", \"on\"");
			pythonSave(file, buff);
		}
		else
		{
			sprintf(buff, "\"animate\", \"off\"");
			pythonSave(file, buff);
		}

		if (this->isLooping())
		{
			sprintf(buff, "\"loop\", \"on\"");
			pythonSave(file, buff);
		}
		else
		{
			sprintf(buff, "\"loop\", \"off\"");
			pythonSave(file, buff);
		}

		// time
		sprintf(buff, "\"set_time\", \"%f\"", this->getTime());
		pythonSave(file, buff);

		// fps
		sprintf(buff, "\"set_fps\", \"%f\"", this->getFPS());
		pythonSave(file, buff);

	}
	else if (mode == 2)
	{
	}

	PlugIn::save(mode, file);

}

void MotionPlayer::setSkipFrames(bool val)
{
	m_skipFrames = val;
}

bool MotionPlayer::isSkipFrames()
{
	return m_skipFrames;
}

void MotionPlayer::setCurrentFrame(int num)
{
	m_curFrame = num;
}

int MotionPlayer::getCurrentFrame()
{
	return m_curFrame;
}

double MotionPlayer::getFrameTime()
{

	double curFrameTime = .033;
	std::vector<Character*>& characters = this->getCharacters();
	if (characters.size() > 0)
	{
		if (characters[0]->getRoot() != NULL)
			curFrameTime = characters[0]->getRoot()->getFrameTime();
	}
	return curFrameTime;
}

void MotionPlayer::playStep(DObject* object, double time)
{
	MotionPlayer* motionPlayer = (MotionPlayer*) object;

	// set the motion player time according to the simulator time
	motionPlayer->setTime(time);
}

void MotionPlayer::setState(double time)
{
	this->setTime(time);
}

std::vector<Character*>& MotionPlayer::getCharacters()
{
	return m_characters;
}


void MotionPlayer::onConnect(DConnection* connection)
{
	if (connection->getType() == "plays")
	{
		Character* c = dynamic_cast<Character*>(connection->getTo());
		if (!c)
		{
			return;
		}
		danceInterp::OutputMessage("Adding character %s", c->getName());
		std::vector<Character*>::iterator iter = std::find(m_characters.begin(), m_characters.end(), c);
		if (iter == m_characters.end())
			m_characters.push_back(c);
		// add a callback for the offset time attribute
		DoubleAttribute* offsetTimeAttribute = dynamic_cast<DoubleAttribute*>(c->getAttribute("offsettime"));
		if (offsetTimeAttribute)
			offsetTimeAttribute->registerObserver(this);
	}
}

void MotionPlayer::onDisconnect(DConnection* connection)
{
	if (connection->getType() == "plays")
	{
		Character* c = dynamic_cast<Character*>(connection->getTo());
		if (!c)
		{
			return;
		}
		danceInterp::OutputMessage("Removing character %s", c->getName());
		DoubleAttribute* offsetTimeAttribute = dynamic_cast<DoubleAttribute*>(c->getAttribute("offsettime"));
		if (offsetTimeAttribute)
			offsetTimeAttribute->unregisterObserver(this);
		std::vector<Character*>::iterator iter = std::find(m_characters.begin(), m_characters.end(), c);
		if (iter != m_characters.end())
			m_characters.erase(iter);

	}
}

void MotionPlayer::notify(DSubject* subject)
{
	DAttribute* attribute = dynamic_cast<DAttribute*>(subject);
	if (attribute)
	{
		DObject* object = attribute->getObject();
		Character* character = dynamic_cast<Character*>(object);
		if (character)
		{
			DoubleAttribute* offsetTimeAttribute = dynamic_cast<DoubleAttribute*>(character->getAttribute("offsettime"));
			if (offsetTimeAttribute == attribute)
			{
				// adjust the slider to allow for a greater number of frames
				double frameTiming = getFrameTime();
				double maxTime = 0;
				int maxFrames = 0;
				for (int i =0; i < (int) getCharacters().size(); i++)
				{
					int numFrames = getCharacters()[i]->getNumFrames();
					double offsetTime = getCharacters()[i]->getOffsetTime();
					if (frameTiming != 0.0)
						numFrames += offsetTime / getFrameTime();
					if (getCharacters()[i]->isCycle())
						numFrames *= 10; // some multiplier to indicatemultiple cycles
					if (numFrames > maxFrames) 
					{
						maxFrames = numFrames;
					}
				}
	
	
				maxTime = maxFrames * frameTiming;

				setMaxTime(maxTime);
				m_playerWindow->updateGUI();
			}
		}
	}
}

