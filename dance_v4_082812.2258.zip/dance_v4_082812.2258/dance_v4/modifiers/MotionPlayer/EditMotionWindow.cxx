/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "EditMotionWindow.h"
#include "opengl.h"

#include <fltk/PackedGroup.h>
#include "CharJoint.h"
#include "dance.h"
#include "danceInterp.h"

EditMotionWindow::EditMotionWindow(int x, int y, int width, int height, const char* name) : Window(x, y, width, height, name)
{

	this->begin();
	PackedGroup* pack = new PackedGroup(10, 10, w() - 40, h() - 150);
//	pack->type(HORIZONTAL);
	this->multiMotion1 = new Browser(0, 0, w() / 2 - 20, h() - 150, "Start Motion");
	this->multiMotion2 = new Browser(w() / 2, 0, w() / 2 - 20, h() - 150, "End Motion");
	pack->end();

	buttonCopyTranslation = new Button(20, h() - 40, 150, 20, "Copy Translation");
	buttonCopyTranslation->callback(copytranslation_cb, this);
	buttonCopyTranslation->deactivate();	

	buttonCombine = new Button(20, h() - 70, 150, 20, "Combine Motions");
	buttonCombine->callback(combinemotion_cb, this);
	buttonCombine->deactivate();

	buttonRemoveTranslation = new Button(20, h() - 100, 150, 20, "Remove Translation");
	buttonRemoveTranslation->callback(removetranslation_cb, this);
	buttonRemoveTranslation->deactivate();	

	buttonClipAnimation = new Button(200, h() - 40, 150, 20, "Clip Animation");
	buttonClipAnimation->callback(clipanimation_cb, this);
	buttonClipAnimation->deactivate();	
	
	this->end();
	playerWindow = NULL;
}

void EditMotionWindow::updateGUI()
{
	// populate the browser with the motions available
	multiMotion1->clear();
	multiMotion2->clear();
	int numCharacters = playerWindow->motionPlayer->getNumCharacters();
	if (numCharacters > 0)
	{
		buttonCombine->activate();
		buttonCopyTranslation->activate();
		buttonRemoveTranslation->activate();
		buttonClipAnimation->activate();
	}
	else
	{
		buttonCombine->deactivate();
		buttonCopyTranslation->deactivate();
		buttonRemoveTranslation->deactivate();
		buttonClipAnimation->deactivate();
	}
	for (int c = 0; c < numCharacters; c++)
	{
		multiMotion1->add(playerWindow->motionPlayer->getCharacter(c)->getName());
		multiMotion2->add(playerWindow->motionPlayer->getCharacter(c)->getName());
	}
}

void EditMotionWindow::combinemotion_cb(Widget* o, void* p)
{
	EditMotionWindow* eWin = (EditMotionWindow*) p;
	if (eWin->multiMotion1->value() >= 0 && eWin->multiMotion2->value() >= 0)
	{
		// combine two motions together
		int v1 = eWin->multiMotion1->value();
		Character* c1 = eWin->playerWindow->motionPlayer->getCharacter(v1);
		int v2 = eWin->multiMotion2->value();
		Character* c2 = eWin->playerWindow->motionPlayer->getCharacter(v2);

		char* name = new char[256];
		sprintf(name, "%s_%s", c1->getName(), c2->getName());

		Character* combined = c1->copy(name);
		combined->addMotion(c2);
		combined->setCombinedFrame(c1->getNumFrames() + 1);

		// integrity check on new motion
		int numJoints = combined->getNumJoints();
		int maxFrames = 0;
		for (int j = 0; j < numJoints; j++)
		{
			CharJoint* joint = combined->getJointByIndex(j);
			if (joint->getNumFrames() > maxFrames)
				maxFrames = joint->getNumFrames();
		}

		for (int j = 0; j < numJoints; j++)
		{
			CharJoint* joint = combined->getJointByIndex(j);
			if (joint->getNumFrames() < maxFrames)
			{
				// pad the frames
				int diff = maxFrames - joint->getNumFrames();
				danceInterp::OutputMessage("Padding joint %s with %d frames", joint->getName(), diff);
				Vector point;
				double frame[6];
				if (combined->isPoints())
				{
					joint->getPoint(joint->getNumFrames() - 1, point[0], point[1], point[2]);
				}
				else
				{
					joint->getFrames(joint->getNumFrames() - 1, frame);
				}
				for (int f = 0; f < diff; f++)
				{
					if (combined->isPoints())
						joint->addFrame(point[0], point[1], point[2]);
					else
						joint->addFrame(frame);
				}
			}
		}

/*
		// make sure that these two characters have identical topologies & DOFs
		// ...
		// ...
		// create a new character
		char* name = new char[256];
		sprintf(name, "%s_%s", c1->getName(), c2->getName());
		// first, make the new character a copy of the first character
		Character* combined = c1->copy(name);
		// second, copy the frames of the second character to the first one
		int numFrames = c2->getNumFrames();
		int numJoints = c2->getNumJoints();
		for (int j = 0; j < numJoints; j++)
		{
			CharJoint* joint = c2->getJointByIndex(j);
			CharJoint* jointCombined = combined->getJointByIndex(j);
			for (int f = 0; f < numFrames; f++)
			{
				double frames[6];
				joint->getFrames(f, frames);
				jointCombined->addFrame(frames);
			}
		}

		combined->setCombinedFrame(c1->getNumFrames() + 1);
*/
		eWin->playerWindow->motionPlayer->addCharacter(combined);
		eWin->playerWindow->selectCharacter(combined);
		eWin->playerWindow->updateGUI();
	}
}

void EditMotionWindow::copytranslation_cb(Widget* o, void* p)
{
	EditMotionWindow* eWin = (EditMotionWindow*) p;
	if (eWin->multiMotion1->value() >= 0 && eWin->multiMotion2->value() >= 0)
	{
		// copy the translation from one motion to another
		int v1 = eWin->multiMotion1->value();
		Character* c1 = eWin->playerWindow->motionPlayer->getCharacter(v1);
		int v2 = eWin->multiMotion2->value();
		Character* c2 = eWin->playerWindow->motionPlayer->getCharacter(v2);

		eWin->playerWindow->motionPlayer->copyTranslation(c1, c2);
		eWin->playerWindow->updateGUI();
	}
}

void EditMotionWindow::clipanimation_cb(Widget* o, void* p)
{
	EditMotionWindow* eWin = (EditMotionWindow*) p;
	if (eWin->multiMotion1->value() >= 0)
	{
		int val = eWin->multiMotion1->value();
		Character* character = eWin->playerWindow->motionPlayer->getCharacter(val);

		// shift the animation in time according to the start/end values
		double startTime = eWin->playerWindow->motionPlayer->getMinTime();
		double endTime = eWin->playerWindow->motionPlayer->getMaxTime();

		eWin->playerWindow->motionPlayer->clipAnimation(character, startTime, endTime);
		eWin->playerWindow->updateGUI();
	}
}

void EditMotionWindow::removetranslation_cb(Widget* o, void* p)
{
	EditMotionWindow* eWin = (EditMotionWindow*) p;
	int v1 = eWin->multiMotion1->value();
	int v2 = eWin->multiMotion2->value();
	if (eWin->multiMotion1->value() >= 0)
	{
		// copy the translation from one motion to another
		int v1 = eWin->multiMotion1->value();
		Character* c1 = eWin->playerWindow->motionPlayer->getCharacter(v1);

		CharJoint* joint = c1->getRoot();
		if (!joint)
			return;

		// find any translation channels on the root node
		int startTransChannel = joint->getFirstTranslationChannel();
		int endTransChannel = joint->getLastTranslationChannel();

		double frames[6];

		int numFrames = joint->getNumFrames();
		for (int f = 0; f < numFrames; f++)
		{
			joint->getFrames(f, frames);
			for (int c = startTransChannel; c <= endTransChannel; c++)
			{
				frames[c] = 0.0;
			}
			joint->setFrame(f, frames);
		}
		eWin->playerWindow->updateGUI();
		dance::AllViews->postRedisplay();;
	}
}
