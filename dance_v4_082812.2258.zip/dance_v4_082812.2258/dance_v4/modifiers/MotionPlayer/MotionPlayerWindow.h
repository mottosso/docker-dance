/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef MOTIONPLAYERWINDOW_H
#define MOTIONPLAYERWINDOW_H

#include "opengl.h"
#include <fltk/MenuBar.h>
#include <fltk/Button.h>
#include <fltk/CheckButton.h>
#include <fltk/Box.h>
#include <fltk/Slider.h>
#include <fltk/ValueSlider.h>
#include <fltk/Input.h>
#include <fltk/FloatInput.h>
#include <fltk/ThumbWheel.h>
#include <fltk/FileChooser.h>
#include <fltk/TextBuffer.h>
#include <fltk/TextDisplay.h>
#include <fltk/Choice.h>
#include <fltk/Window.h>
#include <fltk/Group.h>
#include <fltk/draw.h>
#include <fltk/Menu.h>
#include "MotionPlayer.h"
#include "Character.h"

using namespace fltk;

enum {RUNNING, NOT_RUNNING, PAUSED} ;

class MotionPlayer;
class EditMotionWindow;
class ShowMotionWindow;

class MotionPlayerWindow : public Group
{
public:
	MotionPlayerWindow(MotionPlayer* mp, int, int, int, int, const char*);
	void updateGUI();

	void selectCharacter(Character* c);	
	MotionPlayer* motionPlayer;

	void setTimeSlider(double time);

	//widgets
	Box *box;

	Button* buttonLoad;
	Button* buttonSave;
	Button* buttonPlay;
	Button* buttonStop;
	Button* buttonNext;
	Button* buttonPrev;
	ValueSlider* sliderAnimation;
	ValueSlider* sliderAnimationStart;
	ValueSlider* sliderAnimationEnd;
	CheckButton* checkSkipFrames;
	CheckButton* checkUseFrames;

	FloatInput* inputTimeStep;
	MenuBar* menubar;
	FileChooser* file_chooser;
	TextBuffer* DisplayTextBuffer;
	TextDisplay* textDisplay;

	Choice* choiceCharacter;

	Button *buttonConvert;
	Button *buttonDelete;
	Button* buttonMotionEditWindow;

	bool motionAdded;

	//callbacks
	static void skipframes_cb(Widget* o, void* p);
	static void useframes_cb(Widget* o, void* p);
	static void scale_cb(Widget* o, void* p);
	static void scale_roller_cb(Widget* o, void* p);
	static void play_cb(Widget* o, void* p);
	static void stop_cb(Widget* o, void* p);
	static void nextframe_cb(Widget* o, void* p);
	static void prevframe_cb(Widget* o, void* p);
	static void reset_cb(Widget* o, void* p);
	static void delete_cb(Widget* o, void* p);
	static void parse_found_file_cb(char* name, int parseType, char* metaname, void* p);
	static void load_cb(Widget* o, void* p);
	static void save_cb(Widget* o, void* p);
	static void character_chooser_cb(Widget* o, void* p);
	static void frame_cb(Widget* w, void* p); 
	static void animation_start_cb(Widget* w, void* p); 
	static void animation_end_cb(Widget* w, void* p); 

	static void convert_cb(Widget* w, void* p); 
	static void timestep_cb(Widget* w, void* p); 
	static void interpolate_cb(Widget* o, void* p);
	static void editmotionwindow_cb(Widget* o, void* p);

	//variables
	double orig_scale;
	Character* current_character;
	bool inMainWindow;
	int state;
	double charMaxTime;

	EditMotionWindow* editMotionWindow;

private:
}
;

#endif
