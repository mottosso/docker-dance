#include <cstdio>
#include <cmath>
#include "vector.h"
#include "arbMatrix.h"

/*
class RotAxisMatrix
{
public:
	RotAxisMatrix()
	{
		for (int r = 0; r < 4; r++)
			for (int c = 0; c < 4; c++)
				data[r][c] = 0.0;
	}
	RotAxisMatrix(	double x00, double x01, double x02, double x03,
				double x10, double x11, double x12, double x13,
				double x20, double x21, double x22, double x23,
				double x30, double x31, double x32, double x33)
	{
		data[0][0] = x00; data[0][1] = x01; data[0][2] = x02; data[0][3] = x03;
		data[1][0] = x10; data[1][1] = x11; data[1][2] = x12; data[1][3] = x13;
		data[2][0] = x20; data[2][1] = x21; data[2][2] = x22; data[2][3] = x23;
		data[3][0] = x30; data[3][1] = x31; data[3][2] = x32; data[3][3] = x33;
	}

	void setIdentity()
	{
		for (int r = 0; r < 4; r++)
			for (int c = 0; c < 4; c++)
				if (r == c)
					data[r][c] = 1.0;
				else
					data[r][c] = 0.0;
	}

	RotAxisMatrix & operator*(RotAxisMatrix m2)
	{
		data[0][0] = data[0][0] * m2[0][0] + data[0][1] * m2[1][0] + data[0][2] * m2[2][0] + data[0][3] * m2[3][0];
		data[0][1] = data[0][0] * m2[0][1] + data[0][1] * m2[1][1] + data[0][2] * m2[2][1] + data[0][3] * m2[3][1];
		data[0][2] = data[0][0] * m2[0][2] + data[0][1] * m2[1][2] + data[0][2] * m2[2][2] + data[0][3] * m2[3][2];
		data[0][3] = data[0][0] * m2[0][3] + data[0][1] * m2[1][3] + data[0][2] * m2[2][3] + data[0][3] * m2[3][3];
		data[1][0] = data[1][0] * m2[0][0] + data[1][1] * m2[1][0] + data[1][2] * m2[2][0] + data[1][3] * m2[3][0];
		data[1][1] = data[1][0] * m2[0][1] + data[1][1] * m2[1][1] + data[1][2] * m2[2][1] + data[1][3] * m2[3][1];
		data[1][2] = data[1][0] * m2[0][2] + data[1][1] * m2[1][2] + data[1][2] * m2[2][2] + data[1][3] * m2[3][2];
		data[1][3] = data[1][0] * m2[0][3] + data[1][1] * m2[1][3] + data[1][2] * m2[2][3] + data[1][3] * m2[3][3];
		data[2][0] = data[2][0] * m2[0][0] + data[2][1] * m2[1][0] + data[2][2] * m2[2][0] + data[2][3] * m2[3][0];
		data[2][1] = data[2][0] * m2[0][1] + data[2][1] * m2[1][1] + data[2][2] * m2[2][1] + data[2][3] * m2[3][1];
		data[2][2] = data[2][0] * m2[0][2] + data[2][1] * m2[1][2] + data[2][2] * m2[2][2] + data[2][3] * m2[3][2];
		data[2][3] = data[2][0] * m2[0][3] + data[2][1] * m2[1][3] + data[2][2] * m2[2][3] + data[2][3] * m2[3][3];
		data[3][0] = data[3][0] * m2[0][0] + data[3][1] * m2[1][0] + data[3][2] * m2[2][0] + data[3][3] * m2[3][0];
		data[3][1] = data[3][0] * m2[0][1] + data[3][1] * m2[1][1] + data[3][2] * m2[2][1] + data[3][3] * m2[3][1];
		data[3][2] = data[3][0] * m2[0][2] + data[3][1] * m2[1][2] + data[3][2] * m2[2][2] + data[3][3] * m2[3][2];
		data[3][3] = data[3][0] * m2[0][3] + data[3][1] * m2[1][3] + data[3][2] * m2[2][3] + data[3][3] * m2[3][3];

		return *this;
	}

	double* operator[](int r)
	{
		return data[r];
	}

	RotAxisMatrix& RotAxisMatrix::operator=(const RotAxisMatrix& a)
	{
		for (int r = 0; r < 4; r++)
			for (int c = 0; c < 4; c++)
				data[r][c] = a.data[r][c];

		return *this;

	}


	double data[4][4];

	void dump()
	{
		for (int r1 = 0; r1 < 4; r1++)
			danceTcl::OutputMessage("%f %f %f %f\n", data[r1][0], data[r1][1], data[r1][2], data[r1][3]);
	}
};
*/
void RetargetingActuator::rotateArbitraryAxis(Vector lineEnd, Vector origin, double theta, ArbMatrix &out)
{
	Vector A;
	A[0] = origin[0];
	A[1] = origin[1];
	A[2] = origin[2];
	Vector B;
	B[0] = lineEnd[0];
	B[1] = lineEnd[1];
	B[2] = lineEnd[2];

	// 1. Create a copy of the line for manipulation.
	Vector A2;
	VecCopy(A2, A);
	Vector B2;
	VecCopy(B2, B);
	// 2. Translate L so one endpoint lies at the origin
	ArbMatrix T = ArbMatrix(   1,     0,     0,  0,
                       0,     1,     0,  0,
                       0,     0,     1,  0,
                    -A[0],  -A[1],  -A[2],  1);

	// 3. Rotate around the Y-axis until L lies in the YZ plane.
	RotAxisMatrix R1;
  double len1 = sqrt(B2[0] * B2[0] + B2[2] * B2[2]);
  double costheta1, sintheta1;

  if (len1 > 0) {

    costheta1 = B2[2] / len1;
    sintheta1 = B2[0] / len1;

    // This, of course, is the matrix for rotation around the Y axis
    R1 = RotAxisMatrix( costheta1,  0, sintheta1,  0,
                         0,  1,         0,  0,
                -sintheta1,  0, costheta1,  0,
                         0,  0,         0,  1);
  } else {

    // Line is already parallel to Y-axis, and therefore already in
    // the YZ plane.  Make this rotation do nothing.  

    R1.setIdentity();
  }

  // 4. Rotate around the X axis until L lies on the Z axis.
	RotAxisMatrix R2;
  double len2 = sqrt(B2[1] * B2[1] + B2[2] * B2[2]);
  double costheta2, sintheta2;

  if (len2 > 0) {

    costheta2 = B2[2] / len2;
    sintheta2 = B2[1] / len2;

    // This is the X-axis rotation matrix
    R2 = RotAxisMatrix(1,          0,          0,  0,
                0,  costheta2,  sintheta2,  0,                
                0, -sintheta2,  costheta2,  0,
                0,          0,          0,  1);
  } else {

    // Should never happen
    R2.setIdentity();
  }

  // 5. Perform the rotation around the z-axis.
  RotAxisMatrix R3 = RotAxisMatrix( cos(theta), sin(theta), 0, 0,
                     -sin(theta), cos(theta), 0, 0,
                               0,          0, 1, 0,
                               0,          0, 0, 1);
	// 6. Undo Step 4.
    RotAxisMatrix R2_inv;

  if (len2 > 0) { 

    R2_inv = RotAxisMatrix(1,          0,          0,  0,
                    0,  costheta2, -sintheta2,  0,                
                    0,  sintheta2,  costheta2,  0,
                    0,          0,          0,  1);
  } else {

    // Obviously, if we skipped this rotation, don't un-rotate.
    // However, as I stated before, this rotation should always
    // happen, so it would be bizarre indeed if control made it here.
    // Oh, well.
    R2_inv.setIdentity();

  }

  // 7. Undo Step 3.
	RotAxisMatrix R1_inv;

  if (len1 > 0) {

    R1_inv = RotAxisMatrix(costheta1,  0, -sintheta1,  0,
                            0,  1,          0,  0,
                    sintheta1,  0,  costheta1,  0,
                            0,  0,          0,  1);
  } else {

    R1.setIdentity();

  }

  // 8. Undo Step 2.
	RotAxisMatrix T_inv = RotAxisMatrix(  1,   0,   0,  0,
                          0,   1,   0,  0,
                          0,   0,   1,  0,
                        A[0], A[1], A[2],  1);

/*
	danceTcl::OutputMessage("T:");
	T.dump();
	danceTcl::OutputMessage("R1:");
	R1_inv.dump();
	danceTcl::OutputMessage("R2:");
	R2_inv.dump();
	danceTcl::OutputMessage("R3:");
	R3.dump();
	danceTcl::OutputMessage("R2_INV:");
	R2_inv.dump();
	danceTcl::OutputMessage("R1_INV:");
	R1_inv.dump();
	danceTcl::OutputMessage("T_INV:");
	T_inv.dump();
*/

  // Construct the final matrix...
	RotAxisMatrix m;
	m = T * R1 * R2 * R3 * R2_inv * R1_inv * T_inv;

 // copy to the ArbMatrix & transpose
	out.set(0, 0, m.data[0][0]);
	out.set(0, 1, m.data[1][0]);
	out.set(0, 2, m.data[2][0]);
	out.set(0, 3, m.data[3][0]);

	out.set(1, 0, m.data[0][1]);
	out.set(1, 1, m.data[1][1]);
	out.set(1, 2, m.data[2][1]);
	out.set(1, 3, m.data[3][1]);

	out.set(2, 0, m.data[0][2]);
	out.set(2, 1, m.data[1][2]);
	out.set(2, 2, m.data[2][2]);
	out.set(2, 3, m.data[3][2]);

	out.set(3, 0, m.data[0][3]);
	out.set(3, 1, m.data[1][3]);
	out.set(3, 2, m.data[2][3]);
	out.set(3, 3, m.data[3][3]);
}
	
