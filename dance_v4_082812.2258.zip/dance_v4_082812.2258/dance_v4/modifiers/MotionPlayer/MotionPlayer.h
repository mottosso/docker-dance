/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	MOTIONPLAYER_H
#define	MOTIONPLAYER_H

#include "DModifier.h"
#include "Character.h"
#include <vector>
#include <map>
//#include "lib3ds/mesh.h"
#include "ArticulatedObject.h"
#include "arbMatrix.h"
#include <fltk/Window.h>
#include "MotionPlayerWindow.h"

#ifndef WIN32
#include <sys/time.h>
#endif

// uncomment the following line if the MATLAB libraries are present
//#define USEMATLAB 1

#ifdef USEMATLAB
#include "engine.h"
#endif

class MotionPlayerWindow;

class MotionPlayer : public DSystem
{
	public:

		MotionPlayer();
		~MotionPlayer();
		PlugIn* create(int argc, char **argv);
		int commandPlugIn(int argc, char	**argv);
		void output(int mode);
		void render(int argc, char** argv, std::ofstream& file);

		static void IdleCB(void* object);
		static void playStep(DObject* object, double time);

		Character* retargetAnimation(const char* characterName, char* skeletonName, char* retargetedCharacterName, bool use2ndPass);
		bool isAnimating();
		void setAnimate(bool val);
		bool isLooping();
		void setLooping(bool val);

		void addCharacter(Character* c);
		void deleteCharacter(Character* c);
		int getNumCharacters();
		Character* getCharacter(int i);
		Character* getCharacter(const char* name);
		int getCharacterIndex(Character* c);
		int getCharacterIndex(const char* name);

		//ArticulatedObject* convertCharacterToArticulatedObject(Character* character);

		void setTime(double time);
		double getTime();
		void setMaxTime(double maxTime);
		double getMaxTime();
		void setMinTime(double minTime);
		double getMinTime();
		void setFPS(double fps);
		double getFPS();

		#ifdef WIN32
		DWORD getSystemStartTime();
		void setSystemStartTime(DWORD time);
		#else
		timeval getSystemStartTime();
		void setSystemStartTime(timeval time);
		#endif

		fltk::Widget* getInterface();
		void BeforeAllSimStep(double time, double dt);

		void setSkipFrames(bool val);
		bool isSkipFrames();
		void setCurrentFrame(int f);
		int getCurrentFrame();
		double getFrameTime();

		void copyTranslation(Character* from, Character* to);
		void clipAnimation(Character* c, double fromTime, double toTime);

		MotionPlayerWindow* getMotionPlayerWindow();

		void modify();

		bool runMATLABCommand(const char* command);

		int getNumPluginDependents();
		const char* getPluginDependent(int num);

		void save(int mode, std::ofstream& file);

		void setState(double time);

		void onConnect(DConnection* connection);
		void onDisconnect(DConnection* connection);

		std::vector<Character*>& getCharacters();
		void notify(DSubject* subject);

	private:
		static void rotateArbitraryAxis(Vector lineEnd, Vector lineStart, double theta, ArbMatrix &out);
		bool jointMatch(std::string source, std::string dest);
		void adjustAngles(int jointNum, CharJoint* srcParent, CharJoint* srcChild, CharJoint* targetParent, CharJoint* targetChild);

		bool m_animate;
		bool m_looping;
		bool m_animateFramesOnly;
//		std::vector<Lib3dsFile*> m_objectFiles;
		double m_objectScale;
		bool m_showMesh;
		bool m_useQuaternions;
		double m_animationFPS;
		double m_curTime;
		double m_minTime;
		double m_maxTime;
		std::map<std::string, std::string> m_mapper;
		MotionPlayerWindow* m_playerWindow;
		double m_lastDisplayTime;
	#ifdef USEMATLAB
		Engine* m_engine; // MATLAB engine
		char m_engineBuffer[512];
	#endif
#ifdef WIN32
		DWORD m_sysStartTime;
#else
		timeval m_sysStartTime;
#endif
		int m_numFrames;
		bool m_skipFrames;
		int m_curFrame;
		std::vector<Character*> m_characters;

};

#endif

