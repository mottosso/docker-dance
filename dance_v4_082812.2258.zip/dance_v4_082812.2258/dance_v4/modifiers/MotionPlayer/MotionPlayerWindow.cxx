/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "MotionPlayerWindow.h"
#include "opengl.h"
#include "danceInterp.h"
#include "dance.h"
#include "ViewManager.h"
#include <fstream>
#include <fltk/ColorChooser.h>
#include "ParserBVH.h"
#include "ParserASFAMC.h"
#include "ParserPRT.h"
#include "ParserTXT.h"
#include "ParserSKM.h"
#include <string>
#include "EditMotionWindow.h"
#include "ShowMotionWindow.h"
#include <fltk/PackedGroup.h>
#include <fltk/file_chooser.h>
#include <fltk/ask.h>
#include "stuff.h"
#include "Preference.h"
#include "DConnectionManager.h"

//#include "CharacterMotionWindow.h"

using namespace fltk;
using namespace std;

const char* numbers[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };

MotionPlayerWindow::MotionPlayerWindow(MotionPlayer* mp, int x, int y, int w, int h, const char* s) : Group(x, y, w, h, s)
{
	motionPlayer = mp;
	orig_scale = 1.0;
	inMainWindow = true;
	state = NOT_RUNNING;
	editMotionWindow = NULL;

	this->begin();

	Group* groupMotion = new Group(10, 10, 330, 140, "Motion");
	groupMotion->box(fltk::BORDER_BOX);
	groupMotion->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupMotion->begin();

		buttonPrev = new Button(20, 15, 20, 20, "@|<");
		buttonPrev->callback(prevframe_cb, this);
		buttonPlay = new Button(45, 15, 20, 20, "@>");
		buttonPlay->callback(play_cb, this);
		buttonNext = new Button(70, 15, 20, 20, "@>|");
		buttonNext->callback(nextframe_cb, this);
		buttonStop = new Button(95, 15, 20, 20, "@square");
		buttonStop->callback(stop_cb, this);

		// time step
		inputTimeStep = new FloatInput(200, 15, 40, 20, "FPS");
		inputTimeStep->callback(timestep_cb, this);

		// slider display
		sliderAnimation = new ValueSlider(80, 40, 230, 20, "Frame Display");
		sliderAnimation->align(ALIGN_LEFT);
	//	sliderAnimation->type(HOR_NICE_SLIDER);
		sliderAnimation->step(.001);
		sliderAnimation->callback(frame_cb,this);
		sliderAnimation->range(0, 100);

		sliderAnimationStart = new ValueSlider(80, 65, 230, 20, "Start");
		sliderAnimationStart->align(ALIGN_LEFT);
	//	sliderAnimation->type(HOR_NICE_SLIDER);
		sliderAnimationStart->step(.001);
		sliderAnimationStart->callback(animation_start_cb,this);
		sliderAnimationStart->range(0, 100);
		sliderAnimationStart->value(0);

		sliderAnimationEnd = new ValueSlider(80, 90, 230, 20, "End");
		sliderAnimationEnd->align(ALIGN_LEFT);
	//	sliderAnimation->type(HOR_NICE_SLIDER);
		sliderAnimationEnd->step(.001);
		sliderAnimationEnd->callback(animation_end_cb,this);
		sliderAnimationEnd->range(0, 100);
		sliderAnimationEnd->value(0);

		checkUseFrames = new CheckButton(80, 115, 70, 20, "Use Frames");
		checkUseFrames->callback(useframes_cb, this);
		
		checkSkipFrames = new CheckButton(230, 115, 70, 20, "Skip Frames");
		checkSkipFrames->callback(skipframes_cb, this);
	
	groupMotion->end();

	Group* groupCharacter = new Group(10, 150, 330, 600, "Character");
	groupCharacter->box(fltk::BORDER_BOX);
	groupCharacter->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupCharacter->begin();

		choiceCharacter = new Choice(10, 15, 200, 20); 
		choiceCharacter->when(WHEN_RELEASE);

		buttonLoad = new Button(240, 15, 70, 20, "Load Motion");
		buttonLoad->callback(load_cb, this);

		buttonSave = new Button(240, 40, 70, 20, "Save Motion");
		buttonSave->callback(save_cb, this);

		buttonMotionEditWindow = new Button(80, 65, 100, 20, "Edit Motions");
		buttonMotionEditWindow->callback(editmotionwindow_cb, this);
		buttonMotionEditWindow->deactivate();

	//	packCharacters->type(VERTICAL);
		buttonConvert = new Button(20, 90, 200, 20, "Convert to Simulated Character");
		buttonConvert->callback(convert_cb, this);
		buttonDelete = new Button(20, 115, 200, 20, "Delete Character");
		buttonDelete->callback(delete_cb, this);


	groupCharacter->end();

	this->end();

	selectCharacter(NULL);
	motionAdded = true;
}

void MotionPlayerWindow::updateGUI()
{
	// set the animation FPS
	inputTimeStep->value(motionPlayer->getFPS());
	Character* cur = current_character;
	this->selectCharacter(cur);
	// reset the character choices
	// ...

	// add the characters
	int num = motionPlayer->getNumCharacters();
	if (num > 0)
	{
		this->buttonMotionEditWindow->activate();

		if (this->editMotionWindow != NULL)
		{
			this->editMotionWindow->updateGUI();
			this->editMotionWindow->redraw();
		}
	}
	else
	{
		this->buttonMotionEditWindow->deactivate();

		if (this->editMotionWindow != NULL)
			this->editMotionWindow->updateGUI();
	}

	choiceCharacter->clear();
	for (int i = 0; i < motionPlayer->getNumCharacters(); i++)
	{
		Character* c = motionPlayer->getCharacter(i);
		choiceCharacter->add(c->getName(), 0, MotionPlayerWindow::character_chooser_cb, this);
		if (c == cur)
		{
			current_character = c;
			choiceCharacter->value(i);
		}
	}
	if (current_character == NULL)
	{
		if (num > 0)
			this->selectCharacter(motionPlayer->getCharacter(0));
	}
	if (num == 0)
	{
		choiceCharacter->deactivate();
	}

	// adjust the slider to allow for a greater number of frames
	double frameTiming = this->motionPlayer->getFrameTime();
	double maxTime = 0;
	int maxFrames = 0;
	for (int i =0; i < (int) motionPlayer->getCharacters().size(); i++)
	{
		int numFrames = motionPlayer->getCharacters()[i]->getNumFrames();
		double offsetTime = motionPlayer->getCharacters()[i]->getOffsetTime();
		if (frameTiming != 0.0)
			numFrames += offsetTime / this->motionPlayer->getFrameTime();
		if (motionPlayer->getCharacters()[i]->isCycle())
			numFrames *= 10; // some multiplier to indicatemultiple cycles
		if (numFrames > maxFrames) 
		{
			maxFrames = numFrames;
		}
	}
	
	
	maxTime = maxFrames * frameTiming;

	if (motionAdded)
	{
		motionPlayer->setMaxTime(maxTime);
		motionAdded = false;
	}

	if (this->checkUseFrames->value()) // use frame numbers to drive timing
	{
		sliderAnimation->step(1.0);
		sliderAnimationStart->step(1.0);
		sliderAnimationEnd->step(1.0);
		
		sliderAnimationStart->range(0.0, maxFrames);
		sliderAnimationEnd->range(0.0, maxFrames);

		int minFrame = motionPlayer->getMinTime() * 1.0 / frameTiming;
		int maxFrame = motionPlayer->getMaxTime() * 1.0 / frameTiming;

		sliderAnimationStart->value(minFrame);
		sliderAnimationEnd->value(maxFrame);

		sliderAnimation->range(sliderAnimationStart->value(), sliderAnimationEnd->value());
		int curFrame = int(motionPlayer->getTime() * 1.0 /  frameTiming);
		sliderAnimation->value(curFrame);
	}
	else // use time instead of frame number
	{
		sliderAnimation->step(.01);
		sliderAnimationStart->step(.01);
		sliderAnimationEnd->step(.01);
		
		sliderAnimationStart->range(0.0, maxTime);
		sliderAnimationEnd->range(0.0, maxTime);

		sliderAnimationStart->value(motionPlayer->getMinTime());
		sliderAnimationEnd->value( motionPlayer->getMaxTime());

		sliderAnimation->range(sliderAnimationStart->value(), sliderAnimationEnd->value());
		sliderAnimation->value(motionPlayer->getTime());
	}

	checkSkipFrames->value(motionPlayer->isSkipFrames());


	if (this->current_character != NULL)
	{
		this->buttonSave->activate();
	}
	else
	{
		this->buttonSave->deactivate();
	}

	if (choiceCharacter->size() == 1)
		choiceCharacter->value(0);
}

void MotionPlayerWindow::play_cb(Widget* o, void *p)
{
	Button* button = (Button*) o;
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;
	if (mpWin->state == NOT_RUNNING)
	{
		//played
		mpWin->motionPlayer->setAnimate(true);
		mpWin->state= RUNNING;
		button->label("@||");
	} else {
		if (mpWin->state == RUNNING)
		{
			//paused
			mpWin->motionPlayer->setAnimate(false);
			mpWin->state = PAUSED;
			button->label("@>");
		} else {
			//continued
			mpWin->motionPlayer->setAnimate(true);
			mpWin->state = RUNNING;
			button->label("@||");
		}
	}
	mpWin->updateGUI();
	dance::Refresh();
}

void MotionPlayerWindow::nextframe_cb(Widget* o, void* p)
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;

	double curTime = mpWin->motionPlayer->getTime();
	// if we are at the end time, then the next click will loop
	if (curTime == mpWin->motionPlayer->getMaxTime())
	{
		curTime = mpWin->motionPlayer->getMinTime();
	}
	else
	{
		curTime += 1.0 / mpWin->motionPlayer->getFPS();
		if (curTime > mpWin->motionPlayer->getMaxTime())
			curTime = mpWin->motionPlayer->getMaxTime();
	}
	mpWin->motionPlayer->setTime(curTime);
	mpWin->updateGUI();
	dance::Refresh();
}

void MotionPlayerWindow::prevframe_cb(Widget* o, void* p)
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;

	double curTime = mpWin->motionPlayer->getTime();
	// if we are at the beginning time, then the next click will loop
	if (curTime == mpWin->motionPlayer->getMinTime())
	{
		curTime = mpWin->motionPlayer->getMaxTime();
	}
	else
	{
		curTime -= 1.0 / mpWin->motionPlayer->getFPS();
		if (curTime < mpWin->motionPlayer->getMinTime())
			curTime = mpWin->motionPlayer->getMinTime();
	}
	mpWin->motionPlayer->setTime(curTime);
	mpWin->updateGUI();
	dance::Refresh();
}


void MotionPlayerWindow::stop_cb(Widget* o, void* p)
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;
	mpWin->motionPlayer->setAnimate(false);
	mpWin->state = NOT_RUNNING;
	mpWin->buttonPlay->label("@>");
	mpWin->updateGUI();
	dance::Refresh();
}

void MotionPlayerWindow::reset_cb(Widget* o, void* p)
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;
	mpWin->motionPlayer->setAnimate(false);
	mpWin->state = NOT_RUNNING;
	mpWin->buttonPlay->label("@>");
	mpWin->motionPlayer->setTime(0.0);
	mpWin->updateGUI();
	dance::Refresh();
}

void MotionPlayerWindow::convert_cb(Widget* o, void* p)
{

	//Button* scale_button = (Button*) o;
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;
	// get the current character
	if (mpWin->current_character == NULL)
	{
		danceInterp::OutputMessage("Cannot convert motion to articulated object - no current character has been selected.");
		return;
	}
	else
	{
		std::string name = mpWin->current_character->getName();
		bool found = true;
		int num = 1;
		string tempName = name;
		while (found)
		{
			if (dance::AllSystems->get((char*) tempName.c_str()) == NULL)
			{
				found = false;
			}
			else
			{
				tempName = name;
				char buff[10];
				sprintf(buff, "%d", num);
				tempName.append(buff);
				num++;
			}
		}
		
		char* input = (char*) fltk::input("Name :", tempName.c_str());
		if (input == NULL)
		{
			return;
		}
		else
		{
			ArticulatedObject* artObj = ArticulatedObject::convertCharacterToArticulatedObject(mpWin->current_character, (char*) tempName.c_str());
			artObj->setName(input);
			danceInterp::OutputMessage("Created articulated object '%s'", input);
			string filename = artObj->getName();
			filename.append(".bvh");
			string absoluteFilname = dance::getTemporaryWorkDirectory();
			absoluteFilname.append("/");
			absoluteFilname.append((char*) filename.c_str());
			danceInterp::OutputMessage("Now writing file %s", absoluteFilname.c_str());
			// Note asf/amc files do not include a frame time. Instead, use the current frame rate in the motion player.
			int numJoints = mpWin->current_character->getNumJoints();
			for (int j = 0; j < numJoints; j++)
			{
				CharJoint* cjoint = mpWin->current_character->getJointByIndex(j);
				cjoint->setFrameTime(1.0 / mpWin->motionPlayer->getFPS());
			}

			mpWin->current_character->saveBVH((char*) absoluteFilname.c_str());
			artObj->setPlayback(true);
			artObj->getAnimationSequence()->load((char*) absoluteFilname.c_str());
			artObj->setLastRecordTime(artObj->getAnimationSequence()->getEndTime());
			artObj->setState(0.0);
			dance::AllSimulators->calculatePlaybackEndTime();

			dance::rootWindow->parameterWindow->addInterface(artObj->getInterface(), artObj->getName());
		}

	}
}

void MotionPlayerWindow::delete_cb(Widget* o, void* p)
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;
	if (mpWin->current_character != NULL)
	{
		danceInterp::OutputMessage("Character %s has been deleted...", mpWin->current_character->getName());
		mpWin->motionPlayer->deleteCharacter(mpWin->current_character);
		mpWin->selectCharacter(NULL);
		mpWin->updateGUI();
	}
}

void MotionPlayerWindow::character_chooser_cb(Widget* o, void* p)
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;
	int index = mpWin->choiceCharacter->value();
	mpWin->current_character = mpWin->motionPlayer->getCharacters()[index];
	danceInterp::OutputMessage("Current character is now %s", mpWin->current_character->getName());
	mpWin->selectCharacter(mpWin->current_character);
	mpWin->updateGUI();
	
}

void MotionPlayerWindow::timestep_cb(Widget* o, void* p)
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;
	FloatInput* input = (FloatInput*) o;
	mpWin->motionPlayer->setFPS(input->fvalue());
}

void MotionPlayerWindow::parse_found_file_cb(char* filename, int parseType, char* metaFilename, void* p)
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;
	string str = filename;
	// extract the file name to use as a default name for the motion capture character
	int dotpos = str.find_last_of(".");
	int slashPos = str.find_last_of("\\");
	int slash2Pos = str.find_last_of("/");
	if (slashPos > slash2Pos)
		slash2Pos = slashPos;
	bool found = true;
	int num = 1;
	string origName = str.substr(slash2Pos + 1, dotpos - (slash2Pos + 1)).c_str();
	string tempName = origName;
	while (found)
	{
		if (mpWin->motionPlayer->getCharacter((char*) tempName.c_str()) == NULL)
		{
			found = false;
		}
		else
		{
			tempName = origName;
			char buff[10];
			sprintf(buff, "%d", num);
			tempName.append(buff);
			num++;
		}
	}

	char* input = (char*) fltk::input("Name :", tempName.c_str());
	if (input == NULL) return;
	for (int i = 0; i < (int) mpWin->motionPlayer->getCharacters().size(); i++)
	{
		if ( strcmp(input, mpWin->motionPlayer->getCharacters()[i]->getName()) == 0)
		{
			danceInterp::OutputMessage("The name %s already exists!", input);
			return;
		}
	}
	danceInterp::OutputMessage("parsed file %s", filename);
	std::ifstream file(filename);
	Character* cur = NULL;

	if (parseType == 1) // BVH
	{
		cur = ParserBVH::parse(input, file);
		if (cur)
		{
			StringAttribute* fileAttr = dynamic_cast<StringAttribute*>(cur->getAttribute("file"));
			if (fileAttr)
				fileAttr->setValue(filename);
		}
	}
	else if (parseType == 2) // ASF/AMC
	{
		std::ifstream metafile(metaFilename);
		cur = ParserASFAMC::parse(input, metafile, file);
		if (cur)
		{
			StringAttribute* fileAttr = dynamic_cast<StringAttribute*>(cur->getAttribute("file"));
			if (fileAttr)
				fileAttr->setValue(filename);
			StringAttribute* file2Attr = dynamic_cast<StringAttribute*>(cur->getAttribute("file2"));
			if (file2Attr)
				file2Attr->setValue(metaFilename);

		}
	}
	else if (parseType == 3) // PRT 
	{
		cur = ParserPRT::parse(input, file);
		if (cur)
		{
			StringAttribute* fileAttr = dynamic_cast<StringAttribute*>(cur->getAttribute("file"));
			if (fileAttr)
				fileAttr->setValue(filename);
		}
	}
	else if (parseType == 4) // TXT
	{
		cur = ParserTXT::parse(input, file);
		cur = ParserPRT::parse(input, file);
		if (cur)
		{
			StringAttribute* fileAttr = dynamic_cast<StringAttribute*>(cur->getAttribute("file"));
			if (fileAttr)
				fileAttr->setValue(filename);
		}
	}
	else if (parseType == 5) // SKM
	{
		std::ifstream metafile(metaFilename);
		cur = ParserSKM::parse(input, metafile, file);
		if (cur)
		{
			StringAttribute* fileAttr = dynamic_cast<StringAttribute*>(cur->getAttribute("file"));
			if (fileAttr)
				fileAttr->setValue(filename);
			StringAttribute* file2Attr = dynamic_cast<StringAttribute*>(cur->getAttribute("file2"));
			if (file2Attr)
				file2Attr->setValue(metaFilename);

		}
	}

	if (cur == NULL)
	{
		danceInterp::OutputMessage("Could not parse animation.");
		return;
	}

	dance::AllGenericPlugins->add(cur);
	dance::connectionManager->makeConnection(mpWin->motionPlayer, "plays", cur);

	cur->calculateMatrices(0.0);
	mpWin->motionPlayer->addCharacter(cur);
//	for (int i = 0; i < mpWin->motionPlayer->m_characters.size(); i++) 
//			;
//	mpWin->textDisplay->insert_position(i);
	mpWin->selectCharacter(cur);
	mpWin->updateGUI();
//	mpWin->textDisplay->insert((const char*)input);
//	mpWin->textDisplay->insert("\n");
 
	dance::Refresh();
}

void MotionPlayerWindow::load_cb(Widget* o, void* p)
{
	MotionPlayerWindow* mPlayerWindow = (MotionPlayerWindow*) p;

/*	mpWin->file_chooser = new File_Chooser(dance::getDanceDir(), "BVH Files (*.bvh) \tAll Files (*)", SINGLE, "Parser File");
	mpWin->file_chooser->show();
//	mpWin->file_chooser->when(WHEN_ENTER_KEY);
	mpWin->file_chooser->callback(mpWin->parse_found_file_cb, mpWin);
*/
    	const char* last = Preference::getPreferenceValue("MotionPlayer.lastloadedmotion");
    
    const char* filename = fltk::file_chooser("Please choose a motion file:", "{*.bvh|*.asf|*.prt|*.sk}", (const char*) last, true);
	if (filename != NULL)
	{
     
        char absFileName[1024];
            // make sure that we are using the absolute path
#ifdef WIN32
		const char* fname = fltk_filename_normalize(absFileName, 1024, filename, NULL);
		if (strcmp(fname, filename) == 0)	
			strcpy(absFileName, filename);
#else
        filename_absolute(absFileName, 1024, filename, NULL);
#endif

        string f(absFileName);
		unsigned int asfLoc = f.rfind(".asf"); if (asfLoc == std::string::npos) asfLoc = f.rfind(".ASF");
		unsigned int bvhLoc = f.rfind(".bvh"); if (bvhLoc == std::string::npos) bvhLoc = f.rfind(".ASF");
		unsigned int skLoc = f.rfind(".sk");   if (skLoc == std::string::npos) skLoc = f.rfind(".SK");
		unsigned int prtLoc = f.rfind(".prt"); if (prtLoc == std::string::npos) prtLoc = f.rfind(".PRT");
		unsigned int txtLoc = f.rfind(".txt"); if (txtLoc == std::string::npos) txtLoc = f.rfind(".TXT");
		if (asfLoc >= 0 && asfLoc < f.size())
		{
			char filepath[1024];
            getPathName(filepath, (char*) absFileName);
			const char* motionFileName = fltk::file_chooser("Please choose the accompanying AMC motion file:", "{*.amc}", filepath, true);
			if (!motionFileName)
				return;
                char motionabsFileName[1024];
            // make sure that we are using the absolute path
#ifdef WIN32
		const char* motionfname = fltk_filename_normalize(motionabsFileName, 1024, motionFileName, NULL);
		if (strcmp(motionfname, motionFileName) == 0)
			strcpy(motionabsFileName, motionFileName);
#else
        filename_absolute(motionabsFileName, 1024, motionFileName, NULL);
#endif

			if (motionabsFileName != NULL)
			{
				parse_found_file_cb((char*)motionabsFileName, 2, (char*) f.c_str(), mPlayerWindow);
			}
		}
		else if (skLoc >= 0 && skLoc < f.size())
		{
			char filepath[1024];
            getPathName(filepath, (char*) absFileName);
			const char* motionFileName = fltk::file_chooser("Please choose the accompanying SKM motion file:", "{*.skm}", filepath, true);
			if (!motionFileName)
				return;
                char motionabsFileName[1024];
            // make sure that we are using the absolute path
#ifdef WIN32
		const char* motionfname = fltk_filename_normalize(motionabsFileName, 1024, motionFileName, NULL);
		if (strcmp(motionfname, motionFileName) == 0)
			strcpy(motionabsFileName, motionFileName);
#else
        filename_absolute(motionabsFileName, 1024, motionFileName, NULL);
#endif

			if (motionabsFileName != NULL)
			{
				parse_found_file_cb((char*)motionabsFileName, 5, (char*) f.c_str(), mPlayerWindow);
			}
		}
		else if (bvhLoc >= 0 && bvhLoc < f.size())
		{
			parse_found_file_cb((char*)absFileName, 1, NULL, mPlayerWindow);
		}
		else if (prtLoc >= 0 && prtLoc < f.size())
		{		
			parse_found_file_cb((char*)absFileName, 3, NULL, mPlayerWindow);
		}
		else if (txtLoc >= 0 && txtLoc < f.size())
		{		
			 parse_found_file_cb((char*)absFileName, 4, NULL, mPlayerWindow);
		}
		else
		{
		}
  
        char buff[2048];
        convertbackslashes((char*) absFileName, buff);
        Preference::replacePreference("MotionPlayer.lastloadedmotion", buff);
        dance::writePreferences();

		if ((int) mPlayerWindow->motionPlayer->getCharacters().size() == 1)
			mPlayerWindow->motionAdded = true;
		mPlayerWindow->updateGUI();
		dance::Refresh();
	}
}

void MotionPlayerWindow::save_cb(Widget* o, void* p)
{
	MotionPlayerWindow* win = (MotionPlayerWindow*) p;

	if (win->current_character == NULL)
	{
		danceInterp::OutputMessage("No character has been selected.");
		return;
	}
 
	const char* last = Preference::getPreferenceValue("MotionPlayer.lastsavedmotion");

    const char* filename = fltk::file_chooser("Please name the of file to save to:", "{*.bvh|*.amc|*.skm}", (const char*) last, true);
	if (filename != NULL)
	{
        char absFileName[1024];
        // make sure that we are using the absolute path
		#ifdef WIN32
			const char* f = fltk_filename_normalize(absFileName, 1024, filename, NULL);
			if (strcmp(f, filename) == 0)
				strcpy(absFileName, filename);
		#else
			filename_absolute(absFileName, 1024, filename, NULL);
		#endif
     
        if (strcmp(filename_ext(absFileName), ".amc") == 0)
		{
            string asffile = absFileName;
			// remove the .amc extension
			string base = asffile.substr(0, asffile.size() - 4);
			base.append(".asf");
            win->current_character->saveASFAMC((char*) base.c_str(), (char*) absFileName);
            fltk::alert("Saved to files '%s' and '%s'.", base.c_str(), absFileName);
            
            char buff[2048];
            convertbackslashes((char*) absFileName, buff);
            Preference::replacePreference("MotionPlayer.lastsavedmotion", buff);
            dance::writePreferences();

		}
		else if (strcmp(filename_ext(filename), ".bvh") == 0)
		{
            win->current_character->saveBVH((char*) absFileName);
		}
		else if (strcmp(filename_ext(absFileName), ".skm") == 0)
		{
            string asffile = absFileName;
			// remove the .amc extension
			string base = asffile.substr(0, asffile.size() - 4);
			base.append(".sk");
			float fps = win->motionPlayer->getFPS();
            win->current_character->saveSKSKM((char*) base.c_str(), (char*) absFileName, fps);
            fltk::alert("Saved to files '%s' and '%s'.", base.c_str(), absFileName);
            
            char buff[2048];
            convertbackslashes((char*) absFileName, buff);
            Preference::replacePreference("MotionPlayer.lastsavedmotion", buff);
            dance::writePreferences();
		}
		else 
		{ // add a .bvh extension
            string newfilename = absFileName;
			newfilename.append(".bvh");
            win->current_character->saveBVH((char*) absFileName);
            fltk::alert("Saved to file '%s'.", absFileName);
            
            char buff[2048];
            convertbackslashes((char*) absFileName, buff);
            Preference::replacePreference("MotionPlayer.lastsavedmotion", buff);
            dance::writePreferences();  
        }
        danceInterp::OutputMessage("Saved motion to file '%s'.", absFileName);
	}
}

void MotionPlayerWindow::frame_cb(Widget* w, void* p) 
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;

	double maxTime = 0;
	int maxFrames = 0;
	double curFrameTime = .033;
	for (int i =0; i < (int) (mpWin->motionPlayer->getCharacters().size()); i++)
	{
		Character* character = mpWin->motionPlayer->getCharacters()[i];
		if (character->getNumJoints() > 0)
			curFrameTime = character->getRoot()->getFrameTime();
		int numFrames = mpWin->motionPlayer->getCharacters()[i]->getNumFrames();
		if (mpWin->motionPlayer->getCharacters()[i]->isCycle())
			numFrames *= 10; // some multiplier to indicatemultiple cycles
		if (numFrames > maxFrames) 
		{
			maxFrames = numFrames;
		}

	}
	
	double time = mpWin->sliderAnimation->value();
	if (mpWin->checkUseFrames->value())
	{
		time = time * curFrameTime;
	}
	mpWin->motionPlayer->setTime(time);
	
	if (mpWin->motionPlayer->isAnimating())
	{
		mpWin->motionPlayer->setAnimate(false);
		mpWin->state = PAUSED;
		mpWin->buttonPlay->label("@>");
	}
	dance::Refresh();
}

void MotionPlayerWindow::animation_start_cb(Widget* w, void* p) 
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;

	if (mpWin->checkUseFrames->value())
	{
		double frameTiming = mpWin->motionPlayer->getFrameTime();
		int curFrame =  int(mpWin->motionPlayer->getTime() * frameTiming);

		mpWin->motionPlayer->setMinTime(mpWin->sliderAnimationStart->value() * frameTiming);

		if (mpWin->sliderAnimationStart->value() > curFrame)
		{
			mpWin->motionPlayer->setTime(mpWin->sliderAnimationStart->value() * frameTiming);
			mpWin->sliderAnimation->value(mpWin->sliderAnimationStart->value());
			mpWin->sliderAnimation->redraw();
		}

		if (mpWin->sliderAnimationStart->value() > mpWin->sliderAnimationEnd->value())
			mpWin->sliderAnimationEnd->value(mpWin->sliderAnimationStart->value());

	}
	else
	{
		mpWin->motionPlayer->setMinTime(mpWin->sliderAnimationStart->value());
		if (mpWin->sliderAnimationStart->value() > mpWin->motionPlayer->getTime())
		mpWin->motionPlayer->setTime(mpWin->sliderAnimationStart->value());

		if (mpWin->sliderAnimationStart->value() > mpWin->sliderAnimationEnd->value())
			mpWin->sliderAnimationStart->value(mpWin->sliderAnimationEnd->value());
	}
	
	mpWin->updateGUI();

	dance::Refresh();
}

void MotionPlayerWindow::animation_end_cb(Widget* w, void* p) 
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;

	if (mpWin->checkUseFrames->value())
	{
		double frameTiming = mpWin->motionPlayer->getFrameTime();
		int curFrame =  int(mpWin->motionPlayer->getTime() * frameTiming);

		mpWin->motionPlayer->setMaxTime(mpWin->sliderAnimationEnd->value() * frameTiming);

		if (mpWin->sliderAnimationEnd->value() < curFrame)
		{
			mpWin->motionPlayer->setTime(mpWin->sliderAnimationEnd->value() * frameTiming);
			mpWin->sliderAnimation->value(mpWin->sliderAnimationEnd->value());
			mpWin->sliderAnimation->redraw();
		}

		if (mpWin->sliderAnimationEnd->value() < mpWin->sliderAnimationStart->value())
			mpWin->sliderAnimationStart->value(mpWin->sliderAnimationEnd->value());
	}
	else
	{
		mpWin->motionPlayer->setMaxTime(mpWin->sliderAnimationEnd->value());
		if (mpWin->sliderAnimationEnd->value() < mpWin->motionPlayer->getTime())
		mpWin->motionPlayer->setTime(mpWin->sliderAnimationEnd->value());

		if (mpWin->sliderAnimationEnd->value() < mpWin->sliderAnimationStart->value())
			mpWin->sliderAnimationStart->value(mpWin->sliderAnimationEnd->value());
	}

	mpWin->updateGUI();

	dance::Refresh();
}

void MotionPlayerWindow::selectCharacter(Character* c)
{
	if (c == NULL)
	{
		this->current_character = NULL;
		this->buttonConvert->deactivate();
		this->buttonDelete->deactivate();
		// repopulate the drop-down list
		this->choiceCharacter->clear();
		if (motionPlayer == NULL)
			return;
        
		int numCharacters = motionPlayer->getNumCharacters();
		for (int n = 0; n < numCharacters; n++)
		{
			this->choiceCharacter->add(motionPlayer->getCharacter(n)->getName(), 0, MotionPlayerWindow::character_chooser_cb, this);
		}
		if (numCharacters > 0)
		{
			this->choiceCharacter->value(1);
		}

	}
	else
	{
		this->choiceCharacter->activate();
		this->current_character = c;
		this->buttonConvert->activate();
		this->buttonDelete->activate();
		int numCharacters = motionPlayer->getNumCharacters();
		for (int n = 0; n < numCharacters; n++)
		{
			Character* character = this->motionPlayer->getCharacter(n);
			if (strcmp(c->getName(), character->getName()) == 0)
			{
				this->choiceCharacter->value(n);
				break;
			}
		}
	}
}

void MotionPlayerWindow::editmotionwindow_cb(Widget* o, void* p)
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;
	if (mpWin->editMotionWindow == NULL)
	{
		mpWin->editMotionWindow = new EditMotionWindow(50, 50, 400, 300, "Edit Motions");
		mpWin->editMotionWindow->playerWindow = mpWin;
	}

	mpWin->editMotionWindow->updateGUI();
	mpWin->editMotionWindow->show();
}

void MotionPlayerWindow::skipframes_cb(Widget* o, void* p)
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;
	
	mpWin->motionPlayer->setSkipFrames(mpWin->checkSkipFrames->value());
	mpWin->updateGUI();
	dance::Refresh();
}

void MotionPlayerWindow::useframes_cb(Widget* o, void* p)
{
	MotionPlayerWindow* mpWin = (MotionPlayerWindow*) p;
	
	mpWin->updateGUI();
	dance::Refresh();
}

void MotionPlayerWindow::setTimeSlider(double time)
{
	if (this->checkUseFrames->value())
	{
		int frame = int(time * 1.0 / this->motionPlayer->getFrameTime());
		this->sliderAnimation->value(frame);
	}
	else
	{
		this->sliderAnimation->value(time);
	}
}
