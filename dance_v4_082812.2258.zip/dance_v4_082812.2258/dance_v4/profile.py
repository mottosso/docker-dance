print("DANCE environment")

dance.chdir(dance.dancedir() + "/run")

# create the views
dance.instance("view", "view_top", "top", 1, 1, 1, 1)
print("Created top view.")
dance.instance("view", "view_right", "right", 1, 1, 1, 1)
print("Created right view.")
dance.instance("view", "view_front", "front", 1, 1, 1, 1)
print("Created front view.")

dance.plugin("TrackView")
dance.instance("TrackView", "view_perspective", "persp")

#dance.instance("view", "view_perspective", "persp", 1, 1, 1, 1)
#dance.view("view_perspective", "background", .63, .63, .63, 1)
#dance.view("view_perspective", "projtype", "persp")
#dance.view("view_perspective", "orientation", 0.999675, 0.013048, 0.021886, 0.000000, -0.020146, 0.930635, 0.365395, 0.000000, -0.015601, -0.365717, 0.930595, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
#dance.view("view_perspective", "distance", 56.568542)
#dance.view("view_perspective", "target", 0.000000, 0.000000, 0.000000)
#dance.view("view_perspective", "pan", 0.000000, 0.000000)
#dance.view("view_perspective", "clipBounds", -19.591935, 19.591935, -18.000090, 18.000090, 28.0, 84.0)
print("Created perspective view.")
dance.viewmanager("viewfocus", "view_perspective")

# add the default renderer
dance.instance("BitmapRenderer", "image_renderer")
dance.renderer("image_renderer", "image_type", "png")
dance.renderer("image_renderer", "set_image_viewer_command", "C:\\WINDOWS\\system32\\rundll32.exe C:\\WINDOWS\\System32\\shimgvw.dll,ImageView_Fullscreen %1")
dance.renderer("image_renderer", "render_directory", dance.dancedir() + "/run")

# add the ray tracing renderer
dance.instance("POVRayRenderer", "pov")
dance.renderer("pov", "set_image_viewer_command", "C:\\Users\\shapiro\\AppData\\Roaming\\POV-Ray\\v3.6\\bin\\pvengine64.exe +W640 +H480 +A0.3 %1")
dance.renderer("pov", "render_directory", dance.dancedir() + "/run")

dance.viewmanager("renderer", "image_renderer")

dance.instance("light", "light1")
dance.light("light1", "position", 1, 3.5, 100, 1)
dance.light("light1", "ambient", .1, .1, .1, 1)
dance.light("light1", "diffuse",  .5, .5, .5, 1)
dance.light("light1", "specular", .1, .1, .1, 1)

dance.instance("light", "light2")
dance.light("light2", "position", 0, 100, 100, 1)
dance.light("light2", "ambient", .1, .1, .1, 1)
dance.light("light2", "diffuse",  .3, .3, .3, 1)
dance.light("light2", "specular", .1, .1, .1, 1)

os.chdir(dance.dancedir() + "/run")

dance.plugin("Cube")
dance.plugin("Sphere")
dance.plugin("Plane")
dance.plugin("Capsule")
dance.plugin("Model")
dance.plugin("CompositeGeometry")
dance.plugin("CRSpline3D")

dance.plugin("ArticulatedObject")
dance.plugin("Sensor")
dance.plugin("SensorSkeleton")
dance.plugin("ODESim")
dance.plugin("PDController")


