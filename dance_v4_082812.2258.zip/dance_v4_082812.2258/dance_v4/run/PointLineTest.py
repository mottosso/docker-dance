import PoseInterpreter as pi
import os

ddir = dance.dancedir()
execfile(ddir + "/bin/control.py")

class PointLineTest:
	def __init__(self, argPose):
		pi.setPythonController(argPose, self)
		pi.printString("Init...")

	def start(self, argPose):
		pi.printString("Start...")
		pi.clearGraphics(argPose);
		#pi.setControlUpdateFrequency(self, .016)

	def step(self, argPose):
		t = pi.getTime()

		############### center of mass ###########
		# get the center of mass
		com = pi.getCenterMass(argPose)
		# show the center of mass
		pi.addPoint(argPose, "com", com[0], com[1], com[2])
		# show the center of mass projected on flat ground
		pi.addPoint(argPose, "comprojground", com[0], 0.0, com[2])
		# draw a line to com ground projection
		pi.addLine(argPose, "comprojgroundline", com[0], com[1], com[2], com[0], 0.0, com[2], 1.0, 1.0, 0.0)
		
		############### center of mass velocity ###########
		comaccel = pi.getCMVelocity(argPose);
		scale = 1.0
		pi.addLine(argPose, "comvelocity", com[0], com[1], com[2], com[0] + scale * comaccel[0], scale * com[1] + scale * comaccel[1], com[2] + comaccel[2])

	def stop(self, argPose):
		pi.printString("Stop...")

	def success(self, argPose):
		pi.printString("Success...")


def newPointLineTest(argPose):
	return PointLineTest(argPose)

globals()['PointLineTest'] = PointLineTest
globals()['newPointLineTest'] = newPointLineTest




