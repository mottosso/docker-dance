import PoseInterpreter as pi
import os

ddir = dance.dancedir()
execfile(ddir + "/bin/control.py")

class DumpData:
	def __init__(self, argPose):
		pi.setPythonController(argPose, self)
		pi.printString("Init...")

	def start(self, argPose):
		pi.printString("Start...")
		pi.clearGraphics(argPose);

	def step(self, argPose):
		t = pi.getTime()
                pi.printValueDouble(t)
                numBodies = pi.getNumJoints(argPose)
                for i in (0, numBodies - 1):
                        pos = pi.getPosition(argPose, i)
        		vel = pi.getVelocity(argPose, i)
        		pi.printValueInt(i)
        		pi.printValueDouble(pos[0], pos[1], pos[2])
        		pi.printValueDouble(vel[0], vel[1], vel[2])		

	def stop(self, argPose):
		pi.printString("Stop...")

	def success(self, argPose):
		pi.printString("Success...")


def newDumpData(argPose):
	return DumpData(argPose)

globals()['DumpData'] = DumpData
globals()['newDumpData'] = newDumpData




