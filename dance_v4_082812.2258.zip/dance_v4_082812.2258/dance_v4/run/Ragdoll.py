import PoseInterpreter as pi
import os

ddir = dance.dancedir()
execfile(ddir + "/bin/control.py")

class Ragdoll:
        
	def __init__(self, argPose):
		pi.setPythonController(argPose, self)
		pi.printString("Init Ragdoll...")

	def start(self, argPose):
		pi.printString("Start Ragdoll...")

	def step(self, argPose):
                # make loose skeleton
                numJoints = pi.getNumJoints(argPose)
                for i in range(0, numJoints):
                        jointSize = pi.getJointStateSize(argPose, i)
                        for j in range(0, jointSize):
                                pi.setControlParam(argPose, i, j, 2, 0.0);
                                pi.setControlParam(argPose, i, j, 3, 0.0);

	def stop(self, argPose):
		pi.printString("Stop Ragdoll...")

	def success(self, argPose):
		pi.printString("Success Ragdoll...")


def newRagdoll(argPose):
	return Ragdoll(argPose)

globals()['Ragdoll'] = Ragdoll
globals()['newRagdoll'] = newRagdoll
