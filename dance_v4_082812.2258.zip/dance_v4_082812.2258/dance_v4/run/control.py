############################################
# ASSUMPTIONS
#
#   3 DOF joints are BALL joints.
#
############################################


from math import *
import numpy
import random, array
import PoseInterpreter as pi

class Character:
	"""A humanoid articulated character.

	constructor: Character( name )

	Supported characters are 'Jessica' and 'Skeleton'
	"""

	###################################################
	# Constants
	X = 0
	Y = 1
	Z = 2

	#  PDParams Enum
	DriveType= 0
	V = 1
	KS = 2
	KD = 3
	MaxTorque = 4

	# Drive Types
	PositionDrive = 0
	VelocityDrive = 1
	SpringDrive = 2
	TorqueDrive = 3
	TimeSpringDrive = 4

	###################################################
	# Skeleton definitions


	# "The" Skeleton (from tutorials)

	_jointsTypeSkeleton = 'PD'

	_jointsSkeleton = {
	'Hip':0, 'Trunk_comp':1, 'Neck':2, 'Head_comp':3,
	'Left_Shoulder':4, 'Left_Forearm':5, 'Left_Hand':6,
	'Right_Shoulder':7, 'Right_Forearm':8, 'Right_Hand':9,
	'Left_Thigh':10, 'Left_Shin':11, 'Left_Foot':12,
	'Right_Thigh':13, 'Right_Shin':14, 'Right_Foot':15 }

	_jointsSkeletonDoF = [
	3, 3, 3, 1,
	3, 2, 2,
	3, 2, 2,
	3, 1, 2,
	3, 1, 2 ]

	_jointsSkeletonNaturalMaxKs = [
	[1, 1, 1], 			# Hip
	[3000, 3000, 3000], # Trunk
	[150, 150, 150], 	# Neck
	[150], 				# Head
	[150, 150, 150], 	# LShoulder
	[150], 				# LForearm
	[10, 10],           # LHand
	[150, 150, 150], 	# RShoulder
	[150], 				# RForearm
	[10, 10],           # RHand
	[2000, 2000, 2000], # LThigh
	[300],    			# LShin
	[30, 30],    		# LFoot
	[2000, 2000, 2000], # RThigh
	[300],    			# RShin
	[30, 30]    		# RFoot
	]

	_jointsSkeletonNaturalMaxKd = map( lambda arg: [ 0.1*x for x in arg ], _jointsSkeletonNaturalMaxKs )

	assert len( _jointsSkeletonNaturalMaxKd ) == len( _jointsSkeleton )

	###################################################
	# Skeleton definitions
	# "The" Amotor-based Skeleton
	_jointsTypeSkeleton = 'AM'

	_jointsSkeletonAmotor = {
	'Hip':0, 'Trunk':1, 'Neck':2, 'Head':3,
	'LShoulder':4, 'LForearm':5, 'LHand':6,
	'RShoulder':7, 'RForearm':8, 'RHand':9,
	'LThigh':10, 'LShin':11, 'LFoot':12,
	'RThigh':13, 'RShin':14, 'RFoot':15 }

	# DoF now become 'virtual' degrees of freedom,
	_jointsSkeletonAmotorDoF = [
	3, 3, 3, 1,
	3, 2, 2,
	3, 2, 2,
	3, 1, 2,
	3, 1, 2 ]

	# PROBABLY NOT RIGHT __ HAVEN"T VERIFIED
	_jointsSkeletonDoFAxes =[
	[X,Y,Z], [X,Y,Z], [X,Y,Z], [X],
	[X,Y,Z], [X,Y], [Y,Z],
	[X,Y,Z], [X,Y], [Y,Z],
	[X,Y,Z], [X], [X,Z],
	[X,Y,Z], [X], [X,Z]
	]

	# 111 - ball

	_jointsSkeletonAmotorActuators = [
	[1,1,1], [1,1,1], [1,1,1], [1,0,0],  	# Hip to Head
	[1,1,1], [1,1,0], [0,1,1],              # LShoulder to LHand
	[1,1,1], [1,1,0], [0,1,1],              # RShoulder to RHand
	[1,1,1], [1,0,0], [1,0,1],              # LThigh to LFoot
	[1,1,1], [1,0,0], [1,0,1]               # RThigh to RFoot
	]

	_jointsSkeletonAmotorNaturalMaxKs = [
	[1, 1, 1], 			# Hip
	[3000, 3000, 3000], # Trunk
	[150, 150, 150], 	# Neck
	[150, 0, 0], 		# Head
	[150, 150, 150], 	# LShoulder
	[20, 150, 0], 		# LForearm
	[0, 10, 10],        # LHand
	[150, 150, 150], 	# RShoulder
	[150], 				# RForearm
	[10, 10],           # RHand
	[2000, 2000, 2000], # LThigh
	[300],    			# LShin
	[30, 30],    		# LFoot 12
	[2000, 2000, 2000], # RThigh
	[300],    			# RShin
	[30, 30]    		# RFoot 15
	]

	# Jessica
	# Any changes here must be reflected in SensorJessica.h, LinkAndJoint_indx
	_jointsJessica  = {
	'Hip':0, 'Abdomen':1, 'Chest':2, 'Neck':3, 'Head':4,
	'REye':5, 'LEye':6,
	'RCollar':7, 'RShoulder':8, 'RForearm':9, 'RHand':10, 'RFinger':11,
	'LCollar':12, 'LShoulder':13, 'LForearm':14, 'LHand':15, 'LFinger':16,
	'RThigh':17, 'RShin':18, 'RFoot':19, 'RToe':20,
	'LThigh':21, 'LShin':22, 'LFoot':23, 'LToe':24 }
	
	_jointsAllNames = [ 
		'Hip', 'Abdomen', 'Chest', 'Neck', 'Head', 
		'RCollar', 'RShoulder', 'RForearm', 'RHand', 'RFinger', 
		'LCollar', 'LShoulder', 'LForearm', 'LHand', 'LFinger', 
		'RThigh', 'RShin', 'RFoot', 'RToe',
		'LThigh', 'LShin', 'LFoot', 'LToe'
	]
	_jointsJessicaDoF = [
	3, 3, 3, 3, 1,  #  Hip, Abdomen, Chest, Neck, Head
	2, 2,           # Right Eye, Left Eye
	2, 3, 2, 2, 1,	# Right: Collar, Shoulder, Forearm, Hand, Finger
	2, 3, 2, 2, 1,	# Left: Collar, Shoulder, Forearm, Hand, Finger
	3, 2, 2, 1,     # Right: Thigh, Shin, Foot, Toe
	3, 2, 2, 1      # Left: : Thigh, Shin, Foot, Toe
	]
	
	
	# defines the amplitude of noise to apply to each joint
	# noise is turned on or off by setNoisyJoints()
	jointNoiseScale = [
	0.0, 0.01,  0.01, 0.02, 0.05,  #  Hip, Abdomen, Chest, Neck, Head
	0.1, 0.1,           # Right Eye, Left Eye
	0.04, 0.03, 0.05, 0.1, 0.1,	# Right: Collar, Shoulder, Forearm, Hand, Finger
	0.04, 0.03, 0.05, 0.1, 0.1,	# Left: Collar, Shoulder, Forearm, Hand, Finger
	0.005, 0.0, 0.0, 0.0,     # Right: Thigh, Shin, Foot, Toe
	0.005, 0.0, 0.0, 0.0     # Left: : Thigh, Shin, Foot, Toe
	]

	# defines the temporal scale of the noise per-joint
	jointNoiseTimeScale = [
		0.0,  0.05,  0.1,  0.75,  0.5,  #  Hip, Abdomen, Chest, Neck, Head
		10.0,  10.0,           # Right Eye, Left Eye
		0.1,  0.15, 0.15,  0.15,  0.1,	# Right: Collar, Shoulder, Forearm, Hand, Finger
		0.1,  0.15, 0.15,  0.15,  0.1,   # Left: Collar, Shoulder, Forearm, Hand, Finger
		0.05, 0.0001, 0.0001, 0.0001,     # Right: Thigh, Shin, Foot, Toe
		0.05, 0.0001, 0.0001, 0.0001      # Left: : Thigh, Shin, Foot, Toe
	]

	_jointsJessicaDoFAxes =[
	[X,Y,Z], [X,Y,Z], [X,Y,Z], [X,Y,Z], [X],
	[X,Y], [X,Y],
	[Y,Z], [X,Y,Z], [X,Y], [Y,Z], [Z],
	[Y,Z], [X,Y,Z], [X,Y], [Y,Z], [Z],
	[X,Y,Z], [X,Y], [X,Z], [X],
	[X,Y,Z], [X,Y], [X,Z], [X]
	]


	_jointsJessicaRelativeStrength = [
	]


	joints = []
	jointsDoF = []
	def __init__( self, argSkeletonName ):
		if 'Skeleton' == argSkeletonName:
			self.joints = self._jointsSkeleton
			self.jointsDoF = self._jointsSkeletonDoF
			self.jointsDoFAxes = self._jointsSkeletonDoFAxes
		if 'Jessica' == argSkeletonName:
			self.joints = self._jointsJessica
			self.jointsDoF = self._jointsJessicaDoF
			self.jointsDoFAxes = self._jointsJessicaDoFAxes
		self.totalDoF = len( self.joints )
	
	def setPose( self, argPose ):
		self.myPose = argPose
	
	def axisToDoF( self, argJointIdx, argAxis ):
		axes = self.jointsDoFAxes[argJointIdx]
		for i in range( len( axes ) ):
			if( axes[i] == argAxis ):
				return i
		return -1
	
	def getJointNoise( self, argJointName, argDeg ):
		idx = self.joints[argJointName]
		key =  float( 56.0 * argDeg ) + float(idx) + pi.getTime() * self.jointNoiseTimeScale[ idx ]
		x = pi.noise( key )
		#pi.printString( "\t " + str( key ) + " = " + str( x ) )
		val =  self.jointNoiseScale[ idx ] * pi.noise( key )
		return val
	
	def applyJointsNoise( self, argJointNameArray, argPoseIdx, argGlobalScale ):
		for jname in argJointNameArray:
			idx = self.joints[jname] 
			vs = pi.getJointFromPose(self.myPose, argPoseIdx, idx )
			noisy = vs
			for x in range( len( vs ) ):
				noisy[x] += self.getJointNoise( jname, x ) * argGlobalScale
			self.setJointVs( jname, noisy )
			##pi.printString( "noise ( " + jname + ", " + str( argPoseIdx ) + ") = " + str( noisy ) )
		return
	
	def joint( self, argJointName ):
		return self.joints[argJointName]
	
	def jointDoF( self, argJointName ):
		return self.jointsDoF[ self.joints[argJointName] ]
	
	def getState( self, argJointName, argAxis ):
		jointNum = self.joint( argJointName )
		dof = self.axisToDoF( jointNum, argAxis )
		stateIdx = pi.getSimIndex( self.myPose, jointNum , dof )
		return pi.getState( self.myPose, stateIdx )

	def getJointPosition(self, argJointName):
		jointNum = self.joint( argJointName )
		return pi.getJointPosition( self.myPose, jointNum)

	def getJointVs( self, argName ):
		jointNum = self.joint( argName )
		dof = self.jointDoF( argName )
		j = 0
		retval = []
		for i in range(dof):
			tmpV = pi.getControlParam( self.myPose, jointNum, i, self.V )
			retval.extend( [tmpV] )
			j += 1
		return retval

	def getJointV( self, argName, argAxis ):
		jointNum = self.joint( argName )
		dof = self.axisToDoF( jointNum, argAxis )
		return pi.getControlParam( self.myPose, jointNum, dof, self.V )

	def getJointParams( self, argName, argAxis ):
		jointNum = self.joint( argName )
		dof = self.axisToDoF( jointNum, argAxis )
		return pi.getControlParams( self.myPose, jointNum, dof )

	def getJointParamsAllDoFs( self, argName, argParam ):
	    """Returns an array of all of the joints' parameters for each DoF"""
	    jointNum = self.joint( argName )
	    out = []
	    for dof in range( self.jointsDoF[jointNum] ):
			param = pi.getControlParam( self.myPose, jointNum, dof, argParam )
			out.append( param )
	    return out
	
	def setAllDriveTypes( self, argDriveType ):
		"""Sets the DriveType of every joint in the Character to the argument.
		Remember that joints' DriveType's are only used if PosePDController's
		DriveType is set to "Per Joint".
		Legal DriveTypes are: PositionDrive, VelocityDrive, SpringDrive, TorqueDrive, TimeSpringDrive
		"""
		for name, j in self.joints.items():
			for dof in range(self.jointsDoF[j]):
				pi.setControlParam( self.myPose, j, dof, self.DriveType, argDriveType )
	
	def setJointV( self, argName, argAxis, argV ):
		"""Sets the target value for a single axis of a single joint.
		The meaning of the value is defined by the current DriveType for this Axis.
		Note that this is axis, e.g. X or Z, not degree-of-freedom.
		"""
		jointNum = self.joints[argName]
		if self.jointsDoF[jointNum] == 3:
			pi.printString("ERROR: Do not use setJointV for ball joints!!")
			return None
		
		dof = self.axisToDoF( jointNum, argAxis )
		if( dof > self.jointsDoF[jointNum] or dof < 0 ):
			printString( 'Error.  Incorrect axis parameter for setJointV on joint %s.' % argName )
			return None
		pi.setControlParam( self.myPose, jointNum, dof, self.V, argV )
		return None
	
	def setBallJointV( self, argName, argX,argY,argZ ):
		jointNum = self.joints[argName]
		if self.jointsDoF[jointNum] != 3:
			pi.printString("ERROR: must be a ball joint!!")
			return None
		pi.setJoint4Euler(self.myPose, jointNum, argX,argY,argZ)
		
	def setJointVs( self, argName, argVArray ):
		deg = len(argVArray)
		jointNum = self.joints[argName]
		if( (deg != self.jointsDoF[jointNum]) and  (deg != 4) ):  # We assume You Know What You Are Doing if applying a quaternion
			pi.printString( 'Error.  Incorrect number of parameters (' + str(deg) + ' supplied) for setJoint on joint %s.' % argName )
			return None
		dof = 0
		while( dof < deg ):
			pi.setControlParam( self.myPose, jointNum, dof, self.V, argVArray[dof] )
			dof += 1
		return None

	def setJointVsFromCurrentState(self, argName):
		jointNum = self.joints[argName]
		pi.setJointValuesFromCurrentState(self.myPose, jointNum)
	
	def setJointKsKd( self, argName, argKs, argKd ):
		degS = len(argKs)
		degD = len(argKd)
		if( degS != degD ):
			pi.printString( 'Error. Must provide same number of parameters for Ks and Kd for joint %s.' % argName )
			return None
		jointNum = self.joints[argName]
		if( degS != self.jointsDoF[jointNum] ):
			pi.printString( 'Error.  Incorrect number of parameters for setJointKsKd on joint %s.' % argName )
			return None
		i = 0
		while( i < degS ):
			pi.setControlParam( self.myPose, jointNum, i, self.KS, argKs[i] )
			pi.setControlParam( self.myPose, jointNum, i, self.KD, argKd[i] )
			i += 1
		return None

	def setJointAllKsKd( self, argName, argKs, argKd ):
		jointNum = self.joints[argName]
		deg = self.jointsDoF[jointNum]
		i = 0
		while( i < deg ):
			pi.setControlParam( self.myPose, jointNum, i, self.KS, argKs )
			pi.setControlParam( self.myPose, jointNum, i, self.KD, argKd )
			i += 1
		return None

	def setGlobalKsKd( self, argKs, argKd ):
		for joints, jointNum in self.joints.items():
#			pi.printString( 'setting joint %s' %joints)
			jointDOF = self.jointsDoF[jointNum]
			i = 0
			while ( i < jointDOF ):
				pi.setControlParam( self.myPose, jointNum, i, self.KS, argKs )
				pi.setControlParam( self.myPose, jointNum, i, self.KD, argKd )
				i += 1
		return None

	def setTimingKs( self, argTiming ):
#		pi.printString( 'setting the timing %f' % argTiming)
		for joints in self.joints:
			jointNum = self.joints[joints]
			jointDOF = self.jointsDoF[jointNum]
			i = 0
			while( i < jointDOF ):
				pi.setControlParam( self.myPose, jointNum, i, self.KS, argTiming )
				i += 1
		return None

	def setJointMaxTorque( self, argName, argMaxTorque ):
		jointNum = self.joints[argName]
		for i in range(self.jointsDoF[jointNum]):
			pi.setControlParam( self.myPose, jointNum, i, self.MaxTorque, argMaxTorque )
		return None

	def getJointMaxTorque( self, argName ):
		jointNum = self.joint( argName )
		return pi.getControlParam( self.myPose, jointNum, 0, self.MaxTorque )
	
	def setJointType( self, argName, argDriveType ):
		"""Sets the DriveType of a single joint in the Character to the argument.
		Remember that joints' DriveType's are only used if PosePDController's
		DriveType is set to "Per Joint".
		Legal DriveTypes are: PositionDrive, VelocityDrive, SpringDrive, TorqueDrive, TimeSpringDrive
		"""
		jointNum = self.joints[argName]
		for i in range(self.jointsDoF[jointNum]):
			pi.setControlParam( self.myPose, jointNum, i, self.DriveType, argDriveType )
		return None
	def raiseHead( self ):
		for jname in ['Neck']:
			angle = pi.getWorldZeroXYZAngles( self.myPose, self.joint(jname) )
			self.setBallJointV( jname, angle[X], angle[Y], angle[Z] )
		angleHead = pi.getWorldZeroXYZAngles( self.myPose, self.joint( 'Head' ) )
		self.setJointV( 'Head', X, angleHead[X] )
		return None

	def relativeToFacingXZ( self, argVectorXZ ):
		import numpy
		facingVector = numpy.array( pi.getFacing( self.myPose ) )
		#pi.printString( "raw facing vector = " + str( facingVector ) )
		facingVector[1] = 0
		facingVector = normalize( facingVector )
		front = numpy.array( [0, 0, 1] )
		d = numpy.dot( front, facingVector ) 
		if( d > 1.0 ):
			d = 1.0
		elif( d < -1.0 ):
			d = -1.0
		angle = numpy.arccos( d )
		if( facingVector[0] < 0 ):
			angle *= -1.0
		#pi.printString( "facing Vector = " + str( facingVector ) + ". angle = " + str( angle ) )
		return rotate2d( argVectorXZ, angle )

	def getCMRelativeDistance( self ):
		rawCmPos = pi.getCMRelativeDistance( self.myPose )
		retval = self.relativeToFacingXZ( rawCmPos )
		#pi.printString( "raw CoM: " + str( rawCmPos ) + ", rel CoM: " + str( retval ) )
		return retval
	
	def getCMVelocity( self ): 
		rawCMVel = pi.getCMVelocity( self.myPose )
		return self.relativeToFacingXZ( rawCMVel )


globals()["Character"] = Character

###################################################
# Utility Functions
###################################################

def setJointValue( argName, argDegreeVector ):
	deg = len(argDegreeVector)
	jointNum = self._joints[argName]
	if deg != self._jointsDoF[jointNum]:
		printString( 'Error.  Incorrect number of parameters for setJoint on joint %s.' % argName )
		return None
	radVec = toRadians( argDegreeVector )
	if 1 == deg:
		setJoint1( jointNum, radVec[0] )
	if 2 == deg:
		setJoint2( jointNum, radVec[0], radVec[1] )
	#if 3 == deg:
	#	setJoint3( jointNum, radVec[0], radVec[1], radVec[2] )
	if 3 == deg:
		setJoint4Euler( jointNum, radVec[0], radVec[1], radVec[2] )
	return None
globals()["setJointValue"] = setJointValue

def setJointKsKd( argJointName, argKs, argKd ):
	jointNum = self._joints[argJointName]
	deg = self._jointsDoF[jointNum]
	if 1 == deg:
		setJointKsKd1( jointNum, argKs, argKd )
	if 2 == deg:
		setJointKsKd2( jointNum, argKs, argKd, argKs, argKd )
	if 3 == deg:
		setJointKsKd3( jointNum, argKs, argKd, argKs, argKd, argKs, argKd )
	if 4 == deg:
		setJointKsKd3( jointNum, argKs, argKd, argKs, argKd, argKs, argKd )
	return None
globals()["setJointKsKd"] = setJointKsKd

def vecToStr( argVector ):
	return '%f, %f, %f' % (argVector[0], argVector[1], argVector[2])
globals()["vecToStr"] = vecToStr

def toRadians( *argDegreesVector ):
	if 1 == len( argDegreesVector ):
		return 0.0174532925*argDegreesVector[0]
	out = []
	for i in argDegreesVector:
		out.append( toRadians( i ) )
	return out
globals()["toRadians"] = toRadians

#def toRadiansVector( argDegreesVector ):
#	out = array.array( 'd' )
#	for i in argDegreesVector:
#		out.append( toRadians( i ) )
#	return out


def setJointParams( argName, argDegreeVector, argKs, argKd ):
	setJoint( argName, argDegreeVector )
	setJointKsKd( argName, argKs, argKd )
	return None
globals()["setJointParams"] = setJointParams


def normalize( argVector ):
	import numpy
	len = numpy.sqrt( numpy.sum( argVector * argVector ) )
	v = numpy.array([0,0,0], float)
	if( len == 0 ):
		return numpy.array( [0,0,1], float )
	elif len != 1:
		v = argVector / len
	return v
globals()['normalize'] = normalize

def rotate2d( argVector, argRadians ):
	import numpy
	from math import cos, sin 
	v = numpy.array( [0,0,0], float )
	v[0] = argVector[2] * sin( argRadians ) + argVector[0] * cos( argRadians)
	v[1] = 0
	v[2] = argVector[2] * cos( argRadians ) - argVector[0] * sin( argRadians )
	normalize( v )
	return v
globals()['rotate2d'] = rotate2d


def fromXYZR( x,y,z, r ):
	"""Create a new quaternion from a VRML-style rotation
	x,y,z are the axis of rotation
	r is the rotation in radians."""
	import numpy
	from math import sin, cos
	q = Quaternion( [cos(r/2.0), x*(sin(r/2.0)), y*(sin(r/2.0)), z*(sin(r/2.0)) ])
	q.normalize()
	return q

def fromEuler( x=0,y=0,z=0 ):
	"""Create a new quaternion from a 3-element euler-angle
	rotation q = qx*qy*qz
	"""
	if x:
		base = fromXYZR( 1,0,0,x)
		if y:
			base = base * fromXYZR( 0,1,0,y)
		if z:
			base = base * fromXYZR( 0,0,1,z)
		return base
	elif y:
		base = fromXYZR( 0,1,0,y)
		if z:
			base = base * fromXYZR( 0,0,1,z)
		return base
	else:
		return fromXYZR( 0,0,1,z)


def acosSafe(x):
	import math
	if x > 1:
		x = 1
	elif x < -1:
		x = -1
	return math.acos(x)

globals()['fromEuler'] = fromEuler
globals()['fromXYZR'] = fromXYZR
globals()['acosSafe'] = acosSafe


class Quaternion:
	"""Quaternion object implementing those methods required
	to be useful for OpenGL rendering (and not many others)"""
	import numpy
	internal = numpy.array([1,0,0,0], float)
	def __init__ (self, elements = [1,0,0,0] ):
		"""The initializer is a four-element array,
		
		w, x,y,z -- all elements should be doubles/floats
		the default values are those for a unit multiplication
		quaternion.
		"""
		import numpy
		self.internal = numpy.array( elements, float)
	def __mul__( self, other ):
		"""Multiply this quaternion by another quaternion,
		generating a new quaternion which is the combination of the
		rotations represented by the two source quaternions.

		Other is interpreted as taking place within the coordinate
		space defined by this quaternion.

		Alternately, if "other" is a matrix, return the dot-product
		of that matrix with our matrix (i.e. rotate the coordinate)
		"""
		import numpy
		w1,x1,y1,z1 = self.getWXYZ()
		w2,x2,y2,z2 = other.getWXYZ()
	
		w = w1*w2 - x1*x2 - y1*y2 - z1*z2
		x = w1*x2 + x1*w2 + y1*z2 - z1*y2
		y = w1*y2 + y1*w2 + z1*x2 - x1*z2
		z = w1*z2 + z1*w2 + x1*y2 - y1*x2
		return self.__class__( numpy.array([w,x,y,z],float))
	def XYZR( self ):
		"""Get a VRML-style axis plus rotation form of the rotation.
		Note that this is in radians, not degrees, and that the angle
		is the last, not the first item... (x,y,z,radians)
		"""
		w,x,y,z = self.getWXYZ()
		try:
			aw = acos(w)
		except ValueError:
			# catches errors where w == 1.00000000002
			aw = 0
		scale = sin(aw)
		if not scale:
			return (0,1,0,0)
		return (x / scale, y / scale, z / scale, 2 * aw )
	def matrix( self ):
		"""Get a rotation matrix representing this rotation"""
		w,x,y,z = self.getWXYZ()
		return numpy.array([
			[ 1-2*y*y-2*z*z, 2*x*y+2*w*z, 2*x*z-2*w*y, 0],
			[ 2*x*y-2*w*z, 1-2*x*x-2*z*z, 2*y*z+2*w*x, 0],
			[ 2*x*z+2*w*y, 2*y*z-2*w*x, 1-2*x*x-2*y*y, 0],
			[ 0,0,0,1],
		])
	def normalize(self):
		from math import sqrt, sin, cos
		import numpy
		length = sqrt( sum( self.internal * self.internal))
		if length == 0:
			self.internal = numpy.array([1,0,0,0], float)
		elif length != 1:
			self.internal = self.internal/length

	def getWXYZ(self):
		try:
			x = self.internal[0]
		except ValueError:
			pi.printString("PROBLEM")
		return [self.internal[0], self.internal[1], self.internal[2], self.internal[3]]
	def __getitem__( self, x ):
		return self.internal[x]
	def __len__( self ):
		return len( self.internal)
	def __repr__(self):
		return str(self.getWXYZ())
	def delta( self, other ):
		"""Return the angle in radians between this quaternion and another.

		Return value is a positive angle in the range 0-pi representing
		the minimum angle between the two quaternion rotations.
		
		From code by Halldor Fannar on the 3D game development algos list
		"""
		#first get the dot-product of the two vectors
		cosValue = sum(self.internal + other.internal)
		# now get the positive angle in range 0-pi
		return acos( cosValue )
	def slerp( self, other, fraction = 0, minimalStep= 0.0001):
		"""Perform fraction of spherical linear interpolation from this quaternion to other quaternion

		Algo is from: http://www.gamasutra.com/features/19980703/quaternions_01.htm
		"""
		from math import sqrt, sin, cos, acos, asin, atan
		cosValue = sum(self.internal + other.internal)
		# if the cosValue is negative, use negative target and cos values?
		# not sure why, it's just done this way in the sample code
		if cosValue < 0.0:
			cosValue = -cosValue
			target = -other.internal
		else:
			target = other.internal[:]
		if (1.0- cosValue) > minimalStep:
			# regular spherical linear interpolation
			angle = acos( cosValue )
			angleSin = sin( angle )
			sourceScale = sin( (1.0- fraction) * angle ) / angleSin
			targetScale = sin( fraction * angle ) / angleSin
		else:
			sourceScale = 1.0-fraction
			targetScale = fraction
		return self.__class__( (sourceScale * self.internal)+(targetScale * target) )
	def rotateVector(self, v):
		q = Quaternion([0,v[0], v[1], v[2]])
		res = self*q*self.invert()
		return [res[1], res[2], res[3]]
	def invert(self):
		lengthSqInv = 1.0 / sum( self.internal * self.internal)
		q = Quaternion([1,0,0,0])
		q.internal = -self.internal*lengthSqInv
		q.internal[0] = self.internal[0]
		return q
def test ():
	print 'fromEuler'
	print fromEuler( pi/2 ).XYZR()
	print fromEuler( y = pi/2 ).XYZR()
	print fromEuler( z = pi/2 ).XYZR()
	print fromEuler( y = pi/2, z = pi/2 ).matrix()
	rot = fromEuler( y = pi/2, z = pi/2 ).XYZR()
	print apply( fromXYZR, rot).matrix()
	print fromEuler( y = pi/2, z = pi/2 )
	first = fromXYZR( 0,1,0,0 )
	second = fromXYZR( 0,1,0,pi )
	for fraction in arange( 0.0, 1.0, .01 ):
		print first.slerp( second, fraction )
globals()['Quaternion'] = Quaternion

def easyInOut(t):
	""" Takes a take between 0 and 1 and computes the equivalen easyin easyout version """
	import math
	return (1.0 + math.sin(math.pi*(t - 0.5)))*0.5
globals()['easyInOut'] = easyInOut

class CRSpline:
	"""Implements a Hermite Spline class with uniform knots"""
	def __init__(self, p, t):
		self.assign(p,t)
	def assign(self, p,t):
		if len(p) == 0:
			return
		if len(p) != len(t):
			print "Error lengths do not match"
		if len(p) < 2:
			print "Error length should be at least two"
		self.p = p
		self.t = t
	def eval(self, tglobal):
		import numpy
		index = int(tglobal)
		if index > (len(self.p)-2):
			return self.p[len(self.p) -1]
		t = tglobal - index
		tt = t*t
		ttt = t*tt
		f1 = 2*ttt - 3*tt +1
		f2 = -2*ttt + 3*tt
		f3 = ttt -2*tt + t
		f4 = ttt - tt
		p1 = numpy.array(self.p[index], float)
		p2 = numpy.array(self.p[index+1], float)
		t1 = numpy.array(self.t[index], float)
		t2 = numpy.array(self.t[index+1], float)
		return  p1*f1 + p2*f2+t1*f3+t2*f4
	def rotate(self, quat):
		self.p = map(quat.rotateVector, self.p)
		self.t = map(quat.rotateVector, self.t)


def rotateVectorXZ (argVector, argTheta ):
	import math
	out = [((argVector[0] * math.cos( argTheta )) - (argVector[2] * math.sin( argTheta ))), 0, ((argVector[0] * math.sin( argTheta )) + (argVector[2] * math.cos( argTheta ))) ]
	return out
globals()['rotateVectorXZ'] = rotateVectorXZ
