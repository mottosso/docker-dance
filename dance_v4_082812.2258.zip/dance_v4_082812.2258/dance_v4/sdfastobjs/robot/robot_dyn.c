/*
Generated 19-Jul-2001 15:42:59 by SD/FAST, Order(N) formulation
Generated 19-Jul-2001 15:42:59 by SD/FAST, Order(N) formulation
(sdfast B.2.6 #70405) on machine ID 690a1b33
Copyright (c) 1990-1996 Symbolic Dynamics, Inc.
Copyright (c) 1990-1996 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041



Bodies             Inb
No  Name           body Joint type  Coords q
--- -------------- ---- ----------- ----------------
 -1 $ground                                         
  0 Hip             -1  Planar        0   1   2     
  1 Trunk_comp       0  Pin           3             
  2 Neck             1  Pin           4             
  3 Head_comp        2  Pin           5             
  4 Left_Shoulder    1  Pin           6             
  5 Left_Forearm     4  Pin           7             
  6 Left_Hand        5  Pin           8             
  7 Right_Shoulder   1  Pin           9             
  8 Right_Forearm    7  Pin          10             
  9 Right_Hand       8  Pin          11             
 10 Left_Thigh       0  Pin          12             
 11 Left_Shin       10  Pin          13             
 12 Left_Foot       11  Pin          14             
 13 Right_Thigh      0  Pin          15             
 14 Right_Shin      13  Pin          16             
 15 Right_Foot      14  Pin          17             

*/
#include <math.h>
#include "sdfast.h"
#include <stdio.h>

typedef struct {
    int ground_,nbod_,ndof_,ncons_,nloop_,nldof_,nloopc_,nball_,nlball_,npres_,
      nuser_;
    int jtype_[16],inb_[16],outb_[16],njntdof_[16],njntc_[16],njntp_[16],firstq_
      [16],ballq_[16],firstm_[16],firstp_[16];
    int trans_[18];
} robotgtopo_t;
#define ground (robotgtopo.ground_)
#define nbod (robotgtopo.nbod_)
#define ndof (robotgtopo.ndof_)
#define ncons (robotgtopo.ncons_)
#define nloop (robotgtopo.nloop_)
#define nldof (robotgtopo.nldof_)
#define nloopc (robotgtopo.nloopc_)
#define nball (robotgtopo.nball_)
#define nlball (robotgtopo.nlball_)
#define npres (robotgtopo.npres_)
#define nuser (robotgtopo.nuser_)
#define jtype (robotgtopo.jtype_)
#define inb (robotgtopo.inb_)
#define outb (robotgtopo.outb_)
#define njntdof (robotgtopo.njntdof_)
#define njntc (robotgtopo.njntc_)
#define njntp (robotgtopo.njntp_)
#define firstq (robotgtopo.firstq_)
#define ballq (robotgtopo.ballq_)
#define firstm (robotgtopo.firstm_)
#define firstp (robotgtopo.firstp_)
#define trans (robotgtopo.trans_)

typedef struct {
    double grav_[3],mk_[16],ik_[16][3][3],pin_[18][3];
    double rk_[16][3],ri_[16][3],pres_[18],stabvel_,stabpos_;
    int mfrcflg_,roustate_,vpkflg_,inerflg_,mmflg_,mmlduflg_,wwflg_,ltauflg_,
      fs0flg_,ii_,mmap_[18];
    int gravq_[3],mkq_[16],ikq_[16][3][3],pinq_[18][3],rkq_[16][3],riq_[16][3],
      presq_[18],stabvelq_,stabposq_;
    double mtot_,psmkg_,rhead_[16][3],rcom_[16][3],mkrcomt_[16][3][3],psikg_[3][
      3],psrcomg_[3],psrkg_[3],psrig_[3],psmk_[18],psik_[18][3][3],psrcom_[18][3
      ],psrk_[18][3],psri_[18][3];
} robotginput_t;
#define grav (robotginput.grav_)
#define mk (robotginput.mk_)
#define ik (robotginput.ik_)
#define pin (robotginput.pin_)
#define rk (robotginput.rk_)
#define ri (robotginput.ri_)
#define pres (robotginput.pres_)
#define stabvel (robotginput.stabvel_)
#define stabpos (robotginput.stabpos_)
#define rhead (robotginput.rhead_)
#define rcom (robotginput.rcom_)
#define psrcomg (robotginput.psrcomg_)
#define psrcom (robotginput.psrcom_)
#define mkrcomt (robotginput.mkrcomt_)
#define psmk (robotginput.psmk_)
#define psik (robotginput.psik_)
#define psrk (robotginput.psrk_)
#define psri (robotginput.psri_)
#define psmkg (robotginput.psmkg_)
#define psikg (robotginput.psikg_)
#define psrkg (robotginput.psrkg_)
#define psrig (robotginput.psrig_)
#define mtot (robotginput.mtot_)
#define mfrcflg (robotginput.mfrcflg_)
#define roustate (robotginput.roustate_)
#define vpkflg (robotginput.vpkflg_)
#define inerflg (robotginput.inerflg_)
#define mmflg (robotginput.mmflg_)
#define mmlduflg (robotginput.mmlduflg_)
#define wwflg (robotginput.wwflg_)
#define ltauflg (robotginput.ltauflg_)
#define fs0flg (robotginput.fs0flg_)
#define ii (robotginput.ii_)
#define mmap (robotginput.mmap_)
#define gravq (robotginput.gravq_)
#define mkq (robotginput.mkq_)
#define ikq (robotginput.ikq_)
#define pinq (robotginput.pinq_)
#define rkq (robotginput.rkq_)
#define riq (robotginput.riq_)
#define presq (robotginput.presq_)
#define stabvelq (robotginput.stabvelq_)
#define stabposq (robotginput.stabposq_)

typedef struct {
    double curtim_,q_[18],qn_[18],u_[18],cnk_[18][3][3],cnb_[16][3][3];
    double rnk_[18][3],vnk_[18][3],wk_[18][3],rnb_[16][3],vnb_[16][3],wb_[16][3]
      ,wbrcom_[16][3],com_[3],rnkg_[3];
    double Cik_[18][3][3],rikt_[18][3][3],Iko_[18][3][3],mkrk_[18][3][3],Cib_[16
      ][3][3];
    double Wkk_[18][3],Vkk_[18][3],dik_[18][3],rpp_[18][3],rpk_[18][3],rik_[18][
      3],rik2_[18][3];
    double rpri_[18][3],Wik_[18][3],Vik_[18][3],Wirk_[18][3],rkWkk_[18][3],
      Wkrpk_[18][3],VikWkr_[18][3];
    double perr_[1],verr_[1],aerr_[1],mult_[1],ufk_[16][3],utk_[16][3],mfk_[16][
      3],mtk_[16][3];
    double utau_[18],mtau_[18],uacc_[18],uvel_[18],upos_[18];
    double s2_,c2_,s3_,c3_,s4_,c4_,s5_,c5_,s6_,c6_,s7_,c7_,s8_,c8_,s9_,c9_,s10_,
      c10_,s11_,c11_,s12_,c12_,s13_,c13_,s14_,c14_,s15_,c15_,s16_,c16_,s17_,c17_
      ;
} robotgstate_t;
#define curtim (robotgstate.curtim_)
#define q (robotgstate.q_)
#define qn (robotgstate.qn_)
#define u (robotgstate.u_)
#define cnk (robotgstate.cnk_)
#define cnb (robotgstate.cnb_)
#define rnkg (robotgstate.rnkg_)
#define rnk (robotgstate.rnk_)
#define rnb (robotgstate.rnb_)
#define vnk (robotgstate.vnk_)
#define vnb (robotgstate.vnb_)
#define wk (robotgstate.wk_)
#define wb (robotgstate.wb_)
#define com (robotgstate.com_)
#define Cik (robotgstate.Cik_)
#define Cib (robotgstate.Cib_)
#define rikt (robotgstate.rikt_)
#define Iko (robotgstate.Iko_)
#define mkrk (robotgstate.mkrk_)
#define Wkk (robotgstate.Wkk_)
#define Vkk (robotgstate.Vkk_)
#define dik (robotgstate.dik_)
#define rpp (robotgstate.rpp_)
#define rpk (robotgstate.rpk_)
#define rik (robotgstate.rik_)
#define rik2 (robotgstate.rik2_)
#define rpri (robotgstate.rpri_)
#define Wik (robotgstate.Wik_)
#define Vik (robotgstate.Vik_)
#define Wirk (robotgstate.Wirk_)
#define rkWkk (robotgstate.rkWkk_)
#define Wkrpk (robotgstate.Wkrpk_)
#define VikWkr (robotgstate.VikWkr_)
#define wbrcom (robotgstate.wbrcom_)
#define perr (robotgstate.perr_)
#define verr (robotgstate.verr_)
#define aerr (robotgstate.aerr_)
#define mult (robotgstate.mult_)
#define ufk (robotgstate.ufk_)
#define utk (robotgstate.utk_)
#define utau (robotgstate.utau_)
#define mfk (robotgstate.mfk_)
#define mtk (robotgstate.mtk_)
#define mtau (robotgstate.mtau_)
#define uacc (robotgstate.uacc_)
#define uvel (robotgstate.uvel_)
#define upos (robotgstate.upos_)
#define s2 (robotgstate.s2_)
#define c2 (robotgstate.c2_)
#define s3 (robotgstate.s3_)
#define c3 (robotgstate.c3_)
#define s4 (robotgstate.s4_)
#define c4 (robotgstate.c4_)
#define s5 (robotgstate.s5_)
#define c5 (robotgstate.c5_)
#define s6 (robotgstate.s6_)
#define c6 (robotgstate.c6_)
#define s7 (robotgstate.s7_)
#define c7 (robotgstate.c7_)
#define s8 (robotgstate.s8_)
#define c8 (robotgstate.c8_)
#define s9 (robotgstate.s9_)
#define c9 (robotgstate.c9_)
#define s10 (robotgstate.s10_)
#define c10 (robotgstate.c10_)
#define s11 (robotgstate.s11_)
#define c11 (robotgstate.c11_)
#define s12 (robotgstate.s12_)
#define c12 (robotgstate.c12_)
#define s13 (robotgstate.s13_)
#define c13 (robotgstate.c13_)
#define s14 (robotgstate.s14_)
#define c14 (robotgstate.c14_)
#define s15 (robotgstate.s15_)
#define c15 (robotgstate.c15_)
#define s16 (robotgstate.s16_)
#define c16 (robotgstate.c16_)
#define s17 (robotgstate.s17_)
#define c17 (robotgstate.c17_)

typedef struct {
    double fs0_[18],qdot_[18],Otk_[18][3],Atk_[18][3],AiOiWi_[18][3],Fstar_[18][
      3];
    double Tstar_[18][3],Fstark_[18][3],Tstark_[18][3],IkWk_[18][3],WkIkWk_[18][
      3],gk_[18][3],IkbWk_[16][3],WkIkbWk_[16][3];
    double w0w0_[16],w1w1_[16],w2w2_[16],w0w1_[16],w0w2_[16],w1w2_[16];
    double w00w11_[16],w00w22_[16],w11w22_[16],ww_[1][1],qraux_[1];
    double DD_[18],PH1_[18][3],PH2_[18][3],HL1_[18][3],HL2_[18][3],G1_[18][3],
      G2_[18][3];
    double P11_[18][3][3],Pd_[18][3][3],P22_[18][3][3],L11_[18][3][3],L21_[18][3
      ][3],L22_[18][3][3],D11_[18][3][3],D22_[18][3][3];
    double N11_[18][3][3],N21_[18][3][3],N22_[18][3][3],psi11_[18][3][3],psi12_[
      18][3][3],psi21_[18][3][3],psi22_[18][3][3];
    double psiD11_[18][3][3],psiD12_[18][3][3],psiD21_[18][3][3],psiD22_[18][3][
      3];
    double sL11_[3][3],sL21_[3][3],sL22_[3][3],sD1_[3][3],sD2_[3][3];
    double sD1INV_[3][3],sD2INV_[3][3],sL11D1_[3][3],sL22D2_[3][3],sD1L21_[3][3]
      ;
    double ping_[18][3],hngpt_[18][3];
    int wmap_[1],multmap_[1],jpvt_[1],wsiz_,wrank_;
} robotglhs_t;
#define qdot (robotglhs.qdot_)
#define Otk (robotglhs.Otk_)
#define Atk (robotglhs.Atk_)
#define AiOiWi (robotglhs.AiOiWi_)
#define Fstar (robotglhs.Fstar_)
#define Tstar (robotglhs.Tstar_)
#define fs0 (robotglhs.fs0_)
#define Fstark (robotglhs.Fstark_)
#define Tstark (robotglhs.Tstark_)
#define IkWk (robotglhs.IkWk_)
#define IkbWk (robotglhs.IkbWk_)
#define WkIkWk (robotglhs.WkIkWk_)
#define WkIkbWk (robotglhs.WkIkbWk_)
#define gk (robotglhs.gk_)
#define w0w0 (robotglhs.w0w0_)
#define w1w1 (robotglhs.w1w1_)
#define w2w2 (robotglhs.w2w2_)
#define w0w1 (robotglhs.w0w1_)
#define w0w2 (robotglhs.w0w2_)
#define w1w2 (robotglhs.w1w2_)
#define w00w11 (robotglhs.w00w11_)
#define w00w22 (robotglhs.w00w22_)
#define w11w22 (robotglhs.w11w22_)
#define ww (robotglhs.ww_)
#define qraux (robotglhs.qraux_)
#define PH1 (robotglhs.PH1_)
#define PH2 (robotglhs.PH2_)
#define P11 (robotglhs.P11_)
#define Pd (robotglhs.Pd_)
#define P22 (robotglhs.P22_)
#define L11 (robotglhs.L11_)
#define L21 (robotglhs.L21_)
#define L22 (robotglhs.L22_)
#define D11 (robotglhs.D11_)
#define D22 (robotglhs.D22_)
#define N11 (robotglhs.N11_)
#define N21 (robotglhs.N21_)
#define N22 (robotglhs.N22_)
#define HL1 (robotglhs.HL1_)
#define HL2 (robotglhs.HL2_)
#define psi11 (robotglhs.psi11_)
#define psi12 (robotglhs.psi12_)
#define psi21 (robotglhs.psi21_)
#define psi22 (robotglhs.psi22_)
#define psiD11 (robotglhs.psiD11_)
#define psiD12 (robotglhs.psiD12_)
#define psiD21 (robotglhs.psiD21_)
#define psiD22 (robotglhs.psiD22_)
#define sL11 (robotglhs.sL11_)
#define sL21 (robotglhs.sL21_)
#define sL22 (robotglhs.sL22_)
#define sD1 (robotglhs.sD1_)
#define sD2 (robotglhs.sD2_)
#define sD1INV (robotglhs.sD1INV_)
#define sD2INV (robotglhs.sD2INV_)
#define sL11D1 (robotglhs.sL11D1_)
#define sL22D2 (robotglhs.sL22D2_)
#define sD1L21 (robotglhs.sD1L21_)
#define DD (robotglhs.DD_)
#define G1 (robotglhs.G1_)
#define G2 (robotglhs.G2_)
#define ping (robotglhs.ping_)
#define hngpt (robotglhs.hngpt_)
#define wmap (robotglhs.wmap_)
#define multmap (robotglhs.multmap_)
#define jpvt (robotglhs.jpvt_)
#define wsiz (robotglhs.wsiz_)
#define wrank (robotglhs.wrank_)

typedef struct {
    double fs_[18],udot_[18],tauc_[18],dyad_[16][3][3],fc_[18][3],tc_[18][3];
    double ank_[18][3],onk_[18][3],Onkb_[18][3],AOnkri_[18][3],Ankb_[18][3],
      AnkAtk_[18][3],anb_[16][3],onb_[16][3],dyrcom_[16][3];
    double ffk_[18][3],ttk_[18][3],fccikt_[18][3],ffkb_[16][3],ttkb_[16][3];
} robotgrhs_t;
#define fs (robotgrhs.fs_)
#define udot (robotgrhs.udot_)
#define ank (robotgrhs.ank_)
#define anb (robotgrhs.anb_)
#define onk (robotgrhs.onk_)
#define onb (robotgrhs.onb_)
#define Onkb (robotgrhs.Onkb_)
#define AOnkri (robotgrhs.AOnkri_)
#define Ankb (robotgrhs.Ankb_)
#define AnkAtk (robotgrhs.AnkAtk_)
#define dyrcom (robotgrhs.dyrcom_)
#define ffk (robotgrhs.ffk_)
#define ttk (robotgrhs.ttk_)
#define fccikt (robotgrhs.fccikt_)
#define ffkb (robotgrhs.ffkb_)
#define ttkb (robotgrhs.ttkb_)
#define dyad (robotgrhs.dyad_)
#define fc (robotgrhs.fc_)
#define tc (robotgrhs.tc_)
#define tauc (robotgrhs.tauc_)

typedef struct {
    double temp_[3000],tmat1_[3][3],tmat2_[3][3],tvec1_[3],tvec2_[3],tvec3_[3],
      tvec4_[3],tvec5_[3];
    double tsc1_,tsc2_,tsc3_;
} robotgtemp_t;
#define temp (robotgtemp.temp_)
#define tmat1 (robotgtemp.tmat1_)
#define tmat2 (robotgtemp.tmat2_)
#define tvec1 (robotgtemp.tvec1_)
#define tvec2 (robotgtemp.tvec2_)
#define tvec3 (robotgtemp.tvec3_)
#define tvec4 (robotgtemp.tvec4_)
#define tvec5 (robotgtemp.tvec5_)
#define tsc1 (robotgtemp.tsc1_)
#define tsc2 (robotgtemp.tsc2_)
#define tsc3 (robotgtemp.tsc3_)

robotgtopo_t robotgtopo = {
/*  Topological information
*/
    /* ground */ 1,
    /* nbod */ 16,
    /* ndof */ 18,
    /* ncons */ 0,
    /* nloop */ 0,
    /* nldof */ 0,
    /* nloopc */ 0,
    /* nball */ 0,
    /* nlball */ 0,
    /* npres */ 0,
    /* nuser */ 0,
    /* jtype[0] */ 8,
    /* jtype[1] */ 1,
    /* jtype[2] */ 1,
    /* jtype[3] */ 1,
    /* jtype[4] */ 1,
    /* jtype[5] */ 1,
    /* jtype[6] */ 1,
    /* jtype[7] */ 1,
    /* jtype[8] */ 1,
    /* jtype[9] */ 1,
    /* jtype[10] */ 1,
    /* jtype[11] */ 1,
    /* jtype[12] */ 1,
    /* jtype[13] */ 1,
    /* jtype[14] */ 1,
    /* jtype[15] */ 1,
    /* inb[0] */ -1,
    /* inb[1] */ 0,
    /* inb[2] */ 1,
    /* inb[3] */ 2,
    /* inb[4] */ 1,
    /* inb[5] */ 4,
    /* inb[6] */ 5,
    /* inb[7] */ 1,
    /* inb[8] */ 7,
    /* inb[9] */ 8,
    /* inb[10] */ 0,
    /* inb[11] */ 10,
    /* inb[12] */ 11,
    /* inb[13] */ 0,
    /* inb[14] */ 13,
    /* inb[15] */ 14,
    /* outb[0] */ 0,
    /* outb[1] */ 1,
    /* outb[2] */ 2,
    /* outb[3] */ 3,
    /* outb[4] */ 4,
    /* outb[5] */ 5,
    /* outb[6] */ 6,
    /* outb[7] */ 7,
    /* outb[8] */ 8,
    /* outb[9] */ 9,
    /* outb[10] */ 10,
    /* outb[11] */ 11,
    /* outb[12] */ 12,
    /* outb[13] */ 13,
    /* outb[14] */ 14,
    /* outb[15] */ 15,
    /* njntdof[0] */ 3,
    /* njntdof[1] */ 1,
    /* njntdof[2] */ 1,
    /* njntdof[3] */ 1,
    /* njntdof[4] */ 1,
    /* njntdof[5] */ 1,
    /* njntdof[6] */ 1,
    /* njntdof[7] */ 1,
    /* njntdof[8] */ 1,
    /* njntdof[9] */ 1,
    /* njntdof[10] */ 1,
    /* njntdof[11] */ 1,
    /* njntdof[12] */ 1,
    /* njntdof[13] */ 1,
    /* njntdof[14] */ 1,
    /* njntdof[15] */ 1,
    /* njntc[0] */ 0,
    /* njntc[1] */ 0,
    /* njntc[2] */ 0,
    /* njntc[3] */ 0,
    /* njntc[4] */ 0,
    /* njntc[5] */ 0,
    /* njntc[6] */ 0,
    /* njntc[7] */ 0,
    /* njntc[8] */ 0,
    /* njntc[9] */ 0,
    /* njntc[10] */ 0,
    /* njntc[11] */ 0,
    /* njntc[12] */ 0,
    /* njntc[13] */ 0,
    /* njntc[14] */ 0,
    /* njntc[15] */ 0,
    /* njntp[0] */ 0,
    /* njntp[1] */ 0,
    /* njntp[2] */ 0,
    /* njntp[3] */ 0,
    /* njntp[4] */ 0,
    /* njntp[5] */ 0,
    /* njntp[6] */ 0,
    /* njntp[7] */ 0,
    /* njntp[8] */ 0,
    /* njntp[9] */ 0,
    /* njntp[10] */ 0,
    /* njntp[11] */ 0,
    /* njntp[12] */ 0,
    /* njntp[13] */ 0,
    /* njntp[14] */ 0,
    /* njntp[15] */ 0,
    /* firstq[0] */ 0,
    /* firstq[1] */ 3,
    /* firstq[2] */ 4,
    /* firstq[3] */ 5,
    /* firstq[4] */ 6,
    /* firstq[5] */ 7,
    /* firstq[6] */ 8,
    /* firstq[7] */ 9,
    /* firstq[8] */ 10,
    /* firstq[9] */ 11,
    /* firstq[10] */ 12,
    /* firstq[11] */ 13,
    /* firstq[12] */ 14,
    /* firstq[13] */ 15,
    /* firstq[14] */ 16,
    /* firstq[15] */ 17,
    /* ballq[0] */ -104,
    /* ballq[1] */ -104,
    /* ballq[2] */ -104,
    /* ballq[3] */ -104,
    /* ballq[4] */ -104,
    /* ballq[5] */ -104,
    /* ballq[6] */ -104,
    /* ballq[7] */ -104,
    /* ballq[8] */ -104,
    /* ballq[9] */ -104,
    /* ballq[10] */ -104,
    /* ballq[11] */ -104,
    /* ballq[12] */ -104,
    /* ballq[13] */ -104,
    /* ballq[14] */ -104,
    /* ballq[15] */ -104,
    /* firstm[0] */ -1,
    /* firstm[1] */ -1,
    /* firstm[2] */ -1,
    /* firstm[3] */ -1,
    /* firstm[4] */ -1,
    /* firstm[5] */ -1,
    /* firstm[6] */ -1,
    /* firstm[7] */ -1,
    /* firstm[8] */ -1,
    /* firstm[9] */ -1,
    /* firstm[10] */ -1,
    /* firstm[11] */ -1,
    /* firstm[12] */ -1,
    /* firstm[13] */ -1,
    /* firstm[14] */ -1,
    /* firstm[15] */ -1,
    /* firstp[0] */ -1,
    /* firstp[1] */ -1,
    /* firstp[2] */ -1,
    /* firstp[3] */ -1,
    /* firstp[4] */ -1,
    /* firstp[5] */ -1,
    /* firstp[6] */ -1,
    /* firstp[7] */ -1,
    /* firstp[8] */ -1,
    /* firstp[9] */ -1,
    /* firstp[10] */ -1,
    /* firstp[11] */ -1,
    /* firstp[12] */ -1,
    /* firstp[13] */ -1,
    /* firstp[14] */ -1,
    /* firstp[15] */ -1,
    /* trans[0] */ 1,
    /* trans[1] */ 1,
    /* trans[2] */ 0,
    /* trans[3] */ 0,
    /* trans[4] */ 0,
    /* trans[5] */ 0,
    /* trans[6] */ 0,
    /* trans[7] */ 0,
    /* trans[8] */ 0,
    /* trans[9] */ 0,
    /* trans[10] */ 0,
    /* trans[11] */ 0,
    /* trans[12] */ 0,
    /* trans[13] */ 0,
    /* trans[14] */ 0,
    /* trans[15] */ 0,
    /* trans[16] */ 0,
    /* trans[17] */ 0,
};
robotginput_t robotginput = {
/* Model parameters from the input file */

/* gravity */
    /* grav[0] */ 0.,
    /* grav[1] */ 0.,
    /* grav[2] */ 0.,

/* mass */
    /* mk[0] */ 16.61,
    /* mk[1] */ 29.27,
    /* mk[2] */ 1.,
    /* mk[3] */ 5.89,
    /* mk[4] */ 2.79,
    /* mk[5] */ 1.21,
    /* mk[6] */ .55,
    /* mk[7] */ 2.79,
    /* mk[8] */ 1.21,
    /* mk[9] */ .55,
    /* mk[10] */ 8.35,
    /* mk[11] */ 4.16,
    /* mk[12] */ 1.34,
    /* mk[13] */ 8.35,
    /* mk[14] */ 4.16,
    /* mk[15] */ 1.34,

/* inertia */
    /* ik[0][0][0] */ .18,
    /* ik[0][0][1] */ 0.,
    /* ik[0][0][2] */ 0.,
    /* ik[0][1][0] */ 0.,
    /* ik[0][1][1] */ 0.,
    /* ik[0][1][2] */ 0.,
    /* ik[0][2][0] */ 0.,
    /* ik[0][2][1] */ 0.,
    /* ik[0][2][2] */ 0.,
    /* ik[1][0][0] */ .63,
    /* ik[1][0][1] */ 0.,
    /* ik[1][0][2] */ 0.,
    /* ik[1][1][0] */ 0.,
    /* ik[1][1][1] */ 0.,
    /* ik[1][1][2] */ 0.,
    /* ik[1][2][0] */ 0.,
    /* ik[1][2][1] */ 0.,
    /* ik[1][2][2] */ 0.,
    /* ik[2][0][0] */ .006,
    /* ik[2][0][1] */ 0.,
    /* ik[2][0][2] */ 0.,
    /* ik[2][1][0] */ 0.,
    /* ik[2][1][1] */ 0.,
    /* ik[2][1][2] */ 0.,
    /* ik[2][2][0] */ 0.,
    /* ik[2][2][1] */ 0.,
    /* ik[2][2][2] */ 0.,
    /* ik[3][0][0] */ .033,
    /* ik[3][0][1] */ 0.,
    /* ik[3][0][2] */ 0.,
    /* ik[3][1][0] */ 0.,
    /* ik[3][1][1] */ 0.,
    /* ik[3][1][2] */ 0.,
    /* ik[3][2][0] */ 0.,
    /* ik[3][2][1] */ 0.,
    /* ik[3][2][2] */ 0.,
    /* ik[4][0][0] */ .025,
    /* ik[4][0][1] */ 0.,
    /* ik[4][0][2] */ 0.,
    /* ik[4][1][0] */ 0.,
    /* ik[4][1][1] */ 0.,
    /* ik[4][1][2] */ 0.,
    /* ik[4][2][0] */ 0.,
    /* ik[4][2][1] */ 0.,
    /* ik[4][2][2] */ 0.,
    /* ik[5][0][0] */ .0054,
    /* ik[5][0][1] */ 0.,
    /* ik[5][0][2] */ 0.,
    /* ik[5][1][0] */ 0.,
    /* ik[5][1][1] */ 0.,
    /* ik[5][1][2] */ 0.,
    /* ik[5][2][0] */ 0.,
    /* ik[5][2][1] */ 0.,
    /* ik[5][2][2] */ 0.,
    /* ik[6][0][0] */ .0005,
    /* ik[6][0][1] */ 0.,
    /* ik[6][0][2] */ 0.,
    /* ik[6][1][0] */ 0.,
    /* ik[6][1][1] */ .002,
    /* ik[6][1][2] */ 0.,
    /* ik[6][2][0] */ 0.,
    /* ik[6][2][1] */ 0.,
    /* ik[6][2][2] */ .0016,
    /* ik[7][0][0] */ .025,
    /* ik[7][0][1] */ 0.,
    /* ik[7][0][2] */ 0.,
    /* ik[7][1][0] */ 0.,
    /* ik[7][1][1] */ 0.,
    /* ik[7][1][2] */ 0.,
    /* ik[7][2][0] */ 0.,
    /* ik[7][2][1] */ 0.,
    /* ik[7][2][2] */ 0.,
    /* ik[8][0][0] */ .0054,
    /* ik[8][0][1] */ 0.,
    /* ik[8][0][2] */ 0.,
    /* ik[8][1][0] */ 0.,
    /* ik[8][1][1] */ 0.,
    /* ik[8][1][2] */ 0.,
    /* ik[8][2][0] */ 0.,
    /* ik[8][2][1] */ 0.,
    /* ik[8][2][2] */ 0.,
    /* ik[9][0][0] */ .0005,
    /* ik[9][0][1] */ 0.,
    /* ik[9][0][2] */ 0.,
    /* ik[9][1][0] */ 0.,
    /* ik[9][1][1] */ .002,
    /* ik[9][1][2] */ 0.,
    /* ik[9][2][0] */ 0.,
    /* ik[9][2][1] */ 0.,
    /* ik[9][2][2] */ .0016,
    /* ik[10][0][0] */ .16,
    /* ik[10][0][1] */ 0.,
    /* ik[10][0][2] */ 0.,
    /* ik[10][1][0] */ 0.,
    /* ik[10][1][1] */ 0.,
    /* ik[10][1][2] */ 0.,
    /* ik[10][2][0] */ 0.,
    /* ik[10][2][1] */ 0.,
    /* ik[10][2][2] */ 0.,
    /* ik[11][0][0] */ .056,
    /* ik[11][0][1] */ 0.,
    /* ik[11][0][2] */ 0.,
    /* ik[11][1][0] */ 0.,
    /* ik[11][1][1] */ 0.,
    /* ik[11][1][2] */ 0.,
    /* ik[11][2][0] */ 0.,
    /* ik[11][2][1] */ 0.,
    /* ik[11][2][2] */ 0.,
    /* ik[12][0][0] */ .0075,
    /* ik[12][0][1] */ 0.,
    /* ik[12][0][2] */ 0.,
    /* ik[12][1][0] */ 0.,
    /* ik[12][1][1] */ 0.,
    /* ik[12][1][2] */ 0.,
    /* ik[12][2][0] */ 0.,
    /* ik[12][2][1] */ 0.,
    /* ik[12][2][2] */ 0.,
    /* ik[13][0][0] */ .16,
    /* ik[13][0][1] */ 0.,
    /* ik[13][0][2] */ 0.,
    /* ik[13][1][0] */ 0.,
    /* ik[13][1][1] */ 0.,
    /* ik[13][1][2] */ 0.,
    /* ik[13][2][0] */ 0.,
    /* ik[13][2][1] */ 0.,
    /* ik[13][2][2] */ 0.,
    /* ik[14][0][0] */ .056,
    /* ik[14][0][1] */ 0.,
    /* ik[14][0][2] */ 0.,
    /* ik[14][1][0] */ 0.,
    /* ik[14][1][1] */ 0.,
    /* ik[14][1][2] */ 0.,
    /* ik[14][2][0] */ 0.,
    /* ik[14][2][1] */ 0.,
    /* ik[14][2][2] */ 0.,
    /* ik[15][0][0] */ .0075,
    /* ik[15][0][1] */ 0.,
    /* ik[15][0][2] */ 0.,
    /* ik[15][1][0] */ 0.,
    /* ik[15][1][1] */ 0.,
    /* ik[15][1][2] */ 0.,
    /* ik[15][2][0] */ 0.,
    /* ik[15][2][1] */ 0.,
    /* ik[15][2][2] */ 0.,

/* tree hinge axis vectors */
    /* pin[0][0] */ 0.,
    /* pin[0][1] */ 1.,
    /* pin[0][2] */ 0.,
    /* pin[1][0] */ 0.,
    /* pin[1][1] */ 0.,
    /* pin[1][2] */ 1.,
    /* pin[2][0] */ 1.,
    /* pin[2][1] */ 0.,
    /* pin[2][2] */ 0.,
    /* pin[3][0] */ 1.,
    /* pin[3][1] */ 0.,
    /* pin[3][2] */ 0.,
    /* pin[4][0] */ 1.,
    /* pin[4][1] */ 0.,
    /* pin[4][2] */ 0.,
    /* pin[5][0] */ 1.,
    /* pin[5][1] */ 0.,
    /* pin[5][2] */ 0.,
    /* pin[6][0] */ 1.,
    /* pin[6][1] */ 0.,
    /* pin[6][2] */ 0.,
    /* pin[7][0] */ 1.,
    /* pin[7][1] */ 0.,
    /* pin[7][2] */ 0.,
    /* pin[8][0] */ 0.,
    /* pin[8][1] */ 0.,
    /* pin[8][2] */ 1.,
    /* pin[9][0] */ 1.,
    /* pin[9][1] */ 0.,
    /* pin[9][2] */ 0.,
    /* pin[10][0] */ 1.,
    /* pin[10][1] */ 0.,
    /* pin[10][2] */ 0.,
    /* pin[11][0] */ 0.,
    /* pin[11][1] */ 0.,
    /* pin[11][2] */ 1.,
    /* pin[12][0] */ 1.,
    /* pin[12][1] */ 0.,
    /* pin[12][2] */ 0.,
    /* pin[13][0] */ 1.,
    /* pin[13][1] */ 0.,
    /* pin[13][2] */ 0.,
    /* pin[14][0] */ 1.,
    /* pin[14][1] */ 0.,
    /* pin[14][2] */ 0.,
    /* pin[15][0] */ 1.,
    /* pin[15][1] */ 0.,
    /* pin[15][2] */ 0.,
    /* pin[16][0] */ 1.,
    /* pin[16][1] */ 0.,
    /* pin[16][2] */ 0.,
    /* pin[17][0] */ 1.,
    /* pin[17][1] */ 0.,
    /* pin[17][2] */ 0.,

/* tree bodytojoint vectors */
    /* rk[0][0] */ 0.,
    /* rk[0][1] */ .1206,
    /* rk[0][2] */ .05,
    /* rk[1][0] */ 0.,
    /* rk[1][1] */ -.14625,
    /* rk[1][2] */ .0351,
    /* rk[2][0] */ 0.,
    /* rk[2][1] */ -.0442,
    /* rk[2][2] */ -.0065,
    /* rk[3][0] */ 0.,
    /* rk[3][1] */ -.078,
    /* rk[3][2] */ -.0312,
    /* rk[4][0] */ 0.,
    /* rk[4][1] */ .1326,
    /* rk[4][2] */ -.0013,
    /* rk[5][0] */ .0039,
    /* rk[5][1] */ .1378,
    /* rk[5][2] */ 0.,
    /* rk[6][0] */ 0.,
    /* rk[6][1] */ .065,
    /* rk[6][2] */ 0.,
    /* rk[7][0] */ 0.,
    /* rk[7][1] */ .1326,
    /* rk[7][2] */ -.0013,
    /* rk[8][0] */ -.0039,
    /* rk[8][1] */ .1378,
    /* rk[8][2] */ 0.,
    /* rk[9][0] */ 0.,
    /* rk[9][1] */ .065,
    /* rk[9][2] */ 0.,
    /* rk[10][0] */ .0169,
    /* rk[10][1] */ .2379,
    /* rk[10][2] */ -.0143,
    /* rk[11][0] */ .0078,
    /* rk[11][1] */ .2158,
    /* rk[11][2] */ .0039,
    /* rk[12][0] */ 0.,
    /* rk[12][1] */ .0442,
    /* rk[12][2] */ -.039,
    /* rk[13][0] */ -.0169,
    /* rk[13][1] */ .2379,
    /* rk[13][2] */ -.0143,
    /* rk[14][0] */ -.0078,
    /* rk[14][1] */ .2158,
    /* rk[14][2] */ .0039,
    /* rk[15][0] */ 0.,
    /* rk[15][1] */ .0442,
    /* rk[15][2] */ -.039,

/* tree inbtojoint vectors */
    /* ri[0][0] */ 0.,
    /* ri[0][1] */ 1.131,
    /* ri[0][2] */ .0052,
    /* ri[1][0] */ 0.,
    /* ri[1][1] */ .1206,
    /* ri[1][2] */ .05,
    /* ri[2][0] */ 0.,
    /* ri[2][1] */ .24635,
    /* ri[2][2] */ -.0013,
    /* ri[3][0] */ 0.,
    /* ri[3][1] */ .0442,
    /* ri[3][2] */ .0065,
    /* ri[4][0] */ .1768,
    /* ri[4][1] */ .18915,
    /* ri[4][2] */ .0013,
    /* ri[5][0] */ 0.,
    /* ri[5][1] */ -.1326,
    /* ri[5][2] */ .0013,
    /* ri[6][0] */ .0039,
    /* ri[6][1] */ -.1378,
    /* ri[6][2] */ 0.,
    /* ri[7][0] */ -.1768,
    /* ri[7][1] */ .18915,
    /* ri[7][2] */ .0013,
    /* ri[8][0] */ 0.,
    /* ri[8][1] */ -.1326,
    /* ri[8][2] */ .0013,
    /* ri[9][0] */ -.0039,
    /* ri[9][1] */ -.1378,
    /* ri[9][2] */ 0.,
    /* ri[10][0] */ .1118,
    /* ri[10][1] */ -.0406,
    /* ri[10][2] */ .0058,
    /* ri[11][0] */ -.0169,
    /* ri[11][1] */ -.2379,
    /* ri[11][2] */ .0143,
    /* ri[12][0] */ -.0078,
    /* ri[12][1] */ -.2158,
    /* ri[12][2] */ -.0039,
    /* ri[13][0] */ -.1118,
    /* ri[13][1] */ -.0406,
    /* ri[13][2] */ .0058,
    /* ri[14][0] */ .0169,
    /* ri[14][1] */ -.2379,
    /* ri[14][2] */ .0143,
    /* ri[15][0] */ .0078,
    /* ri[15][1] */ -.2158,
    /* ri[15][2] */ -.0039,

/* tree prescribed motion */
    /* pres[0] */ 0.,
    /* pres[1] */ 0.,
    /* pres[2] */ 0.,
    /* pres[3] */ 0.,
    /* pres[4] */ 0.,
    /* pres[5] */ 0.,
    /* pres[6] */ 0.,
    /* pres[7] */ 0.,
    /* pres[8] */ 0.,
    /* pres[9] */ 0.,
    /* pres[10] */ 0.,
    /* pres[11] */ 0.,
    /* pres[12] */ 0.,
    /* pres[13] */ 0.,
    /* pres[14] */ 0.,
    /* pres[15] */ 0.,
    /* pres[16] */ 0.,
    /* pres[17] */ 0.,

/* stabilization parameters */
    /* stabvel */ 0.,
    /* stabpos */ 0.,

/* miscellaneous */
    /* mfrcflg */ 0,
    /* roustate */ 0,
    /* vpkflg */ 0,
    /* inerflg */ 0,
    /* mmflg */ 0,
    /* mmlduflg */ 0,
    /* wwflg */ 0,
    /* ltauflg */ 0,
    /* fs0flg */ 0,
    /* ii */ 0,
    /* mmap[0] */ 0,
    /* mmap[1] */ 1,
    /* mmap[2] */ 2,
    /* mmap[3] */ 3,
    /* mmap[4] */ 4,
    /* mmap[5] */ 5,
    /* mmap[6] */ 6,
    /* mmap[7] */ 7,
    /* mmap[8] */ 8,
    /* mmap[9] */ 9,
    /* mmap[10] */ 10,
    /* mmap[11] */ 11,
    /* mmap[12] */ 12,
    /* mmap[13] */ 13,
    /* mmap[14] */ 14,
    /* mmap[15] */ 15,
    /* mmap[16] */ 16,
    /* mmap[17] */ 17,

/* Which parameters were "?" (1) or "<nominal>?" (3) */
    /* gravq[0] */ 0,
    /* gravq[1] */ 0,
    /* gravq[2] */ 0,
    /* mkq[0] */ 0,
    /* mkq[1] */ 0,
    /* mkq[2] */ 0,
    /* mkq[3] */ 0,
    /* mkq[4] */ 0,
    /* mkq[5] */ 0,
    /* mkq[6] */ 0,
    /* mkq[7] */ 0,
    /* mkq[8] */ 0,
    /* mkq[9] */ 0,
    /* mkq[10] */ 0,
    /* mkq[11] */ 0,
    /* mkq[12] */ 0,
    /* mkq[13] */ 0,
    /* mkq[14] */ 0,
    /* mkq[15] */ 0,
    /* ikq[0][0][0] */ 0,
    /* ikq[0][0][1] */ 0,
    /* ikq[0][0][2] */ 0,
    /* ikq[0][1][0] */ 0,
    /* ikq[0][1][1] */ 0,
    /* ikq[0][1][2] */ 0,
    /* ikq[0][2][0] */ 0,
    /* ikq[0][2][1] */ 0,
    /* ikq[0][2][2] */ 0,
    /* ikq[1][0][0] */ 0,
    /* ikq[1][0][1] */ 0,
    /* ikq[1][0][2] */ 0,
    /* ikq[1][1][0] */ 0,
    /* ikq[1][1][1] */ 0,
    /* ikq[1][1][2] */ 0,
    /* ikq[1][2][0] */ 0,
    /* ikq[1][2][1] */ 0,
    /* ikq[1][2][2] */ 0,
    /* ikq[2][0][0] */ 0,
    /* ikq[2][0][1] */ 0,
    /* ikq[2][0][2] */ 0,
    /* ikq[2][1][0] */ 0,
    /* ikq[2][1][1] */ 0,
    /* ikq[2][1][2] */ 0,
    /* ikq[2][2][0] */ 0,
    /* ikq[2][2][1] */ 0,
    /* ikq[2][2][2] */ 0,
    /* ikq[3][0][0] */ 0,
    /* ikq[3][0][1] */ 0,
    /* ikq[3][0][2] */ 0,
    /* ikq[3][1][0] */ 0,
    /* ikq[3][1][1] */ 0,
    /* ikq[3][1][2] */ 0,
    /* ikq[3][2][0] */ 0,
    /* ikq[3][2][1] */ 0,
    /* ikq[3][2][2] */ 0,
    /* ikq[4][0][0] */ 0,
    /* ikq[4][0][1] */ 0,
    /* ikq[4][0][2] */ 0,
    /* ikq[4][1][0] */ 0,
    /* ikq[4][1][1] */ 0,
    /* ikq[4][1][2] */ 0,
    /* ikq[4][2][0] */ 0,
    /* ikq[4][2][1] */ 0,
    /* ikq[4][2][2] */ 0,
    /* ikq[5][0][0] */ 0,
    /* ikq[5][0][1] */ 0,
    /* ikq[5][0][2] */ 0,
    /* ikq[5][1][0] */ 0,
    /* ikq[5][1][1] */ 0,
    /* ikq[5][1][2] */ 0,
    /* ikq[5][2][0] */ 0,
    /* ikq[5][2][1] */ 0,
    /* ikq[5][2][2] */ 0,
    /* ikq[6][0][0] */ 0,
    /* ikq[6][0][1] */ 0,
    /* ikq[6][0][2] */ 0,
    /* ikq[6][1][0] */ 0,
    /* ikq[6][1][1] */ 0,
    /* ikq[6][1][2] */ 0,
    /* ikq[6][2][0] */ 0,
    /* ikq[6][2][1] */ 0,
    /* ikq[6][2][2] */ 0,
    /* ikq[7][0][0] */ 0,
    /* ikq[7][0][1] */ 0,
    /* ikq[7][0][2] */ 0,
    /* ikq[7][1][0] */ 0,
    /* ikq[7][1][1] */ 0,
    /* ikq[7][1][2] */ 0,
    /* ikq[7][2][0] */ 0,
    /* ikq[7][2][1] */ 0,
    /* ikq[7][2][2] */ 0,
    /* ikq[8][0][0] */ 0,
    /* ikq[8][0][1] */ 0,
    /* ikq[8][0][2] */ 0,
    /* ikq[8][1][0] */ 0,
    /* ikq[8][1][1] */ 0,
    /* ikq[8][1][2] */ 0,
    /* ikq[8][2][0] */ 0,
    /* ikq[8][2][1] */ 0,
    /* ikq[8][2][2] */ 0,
    /* ikq[9][0][0] */ 0,
    /* ikq[9][0][1] */ 0,
    /* ikq[9][0][2] */ 0,
    /* ikq[9][1][0] */ 0,
    /* ikq[9][1][1] */ 0,
    /* ikq[9][1][2] */ 0,
    /* ikq[9][2][0] */ 0,
    /* ikq[9][2][1] */ 0,
    /* ikq[9][2][2] */ 0,
    /* ikq[10][0][0] */ 0,
    /* ikq[10][0][1] */ 0,
    /* ikq[10][0][2] */ 0,
    /* ikq[10][1][0] */ 0,
    /* ikq[10][1][1] */ 0,
    /* ikq[10][1][2] */ 0,
    /* ikq[10][2][0] */ 0,
    /* ikq[10][2][1] */ 0,
    /* ikq[10][2][2] */ 0,
    /* ikq[11][0][0] */ 0,
    /* ikq[11][0][1] */ 0,
    /* ikq[11][0][2] */ 0,
    /* ikq[11][1][0] */ 0,
    /* ikq[11][1][1] */ 0,
    /* ikq[11][1][2] */ 0,
    /* ikq[11][2][0] */ 0,
    /* ikq[11][2][1] */ 0,
    /* ikq[11][2][2] */ 0,
    /* ikq[12][0][0] */ 0,
    /* ikq[12][0][1] */ 0,
    /* ikq[12][0][2] */ 0,
    /* ikq[12][1][0] */ 0,
    /* ikq[12][1][1] */ 0,
    /* ikq[12][1][2] */ 0,
    /* ikq[12][2][0] */ 0,
    /* ikq[12][2][1] */ 0,
    /* ikq[12][2][2] */ 0,
    /* ikq[13][0][0] */ 0,
    /* ikq[13][0][1] */ 0,
    /* ikq[13][0][2] */ 0,
    /* ikq[13][1][0] */ 0,
    /* ikq[13][1][1] */ 0,
    /* ikq[13][1][2] */ 0,
    /* ikq[13][2][0] */ 0,
    /* ikq[13][2][1] */ 0,
    /* ikq[13][2][2] */ 0,
    /* ikq[14][0][0] */ 0,
    /* ikq[14][0][1] */ 0,
    /* ikq[14][0][2] */ 0,
    /* ikq[14][1][0] */ 0,
    /* ikq[14][1][1] */ 0,
    /* ikq[14][1][2] */ 0,
    /* ikq[14][2][0] */ 0,
    /* ikq[14][2][1] */ 0,
    /* ikq[14][2][2] */ 0,
    /* ikq[15][0][0] */ 0,
    /* ikq[15][0][1] */ 0,
    /* ikq[15][0][2] */ 0,
    /* ikq[15][1][0] */ 0,
    /* ikq[15][1][1] */ 0,
    /* ikq[15][1][2] */ 0,
    /* ikq[15][2][0] */ 0,
    /* ikq[15][2][1] */ 0,
    /* ikq[15][2][2] */ 0,
    /* pinq[0][0] */ 0,
    /* pinq[0][1] */ 0,
    /* pinq[0][2] */ 0,
    /* pinq[1][0] */ 0,
    /* pinq[1][1] */ 0,
    /* pinq[1][2] */ 0,
    /* pinq[2][0] */ 0,
    /* pinq[2][1] */ 0,
    /* pinq[2][2] */ 0,
    /* pinq[3][0] */ 0,
    /* pinq[3][1] */ 0,
    /* pinq[3][2] */ 0,
    /* pinq[4][0] */ 0,
    /* pinq[4][1] */ 0,
    /* pinq[4][2] */ 0,
    /* pinq[5][0] */ 0,
    /* pinq[5][1] */ 0,
    /* pinq[5][2] */ 0,
    /* pinq[6][0] */ 0,
    /* pinq[6][1] */ 0,
    /* pinq[6][2] */ 0,
    /* pinq[7][0] */ 0,
    /* pinq[7][1] */ 0,
    /* pinq[7][2] */ 0,
    /* pinq[8][0] */ 0,
    /* pinq[8][1] */ 0,
    /* pinq[8][2] */ 0,
    /* pinq[9][0] */ 0,
    /* pinq[9][1] */ 0,
    /* pinq[9][2] */ 0,
    /* pinq[10][0] */ 0,
    /* pinq[10][1] */ 0,
    /* pinq[10][2] */ 0,
    /* pinq[11][0] */ 0,
    /* pinq[11][1] */ 0,
    /* pinq[11][2] */ 0,
    /* pinq[12][0] */ 0,
    /* pinq[12][1] */ 0,
    /* pinq[12][2] */ 0,
    /* pinq[13][0] */ 0,
    /* pinq[13][1] */ 0,
    /* pinq[13][2] */ 0,
    /* pinq[14][0] */ 0,
    /* pinq[14][1] */ 0,
    /* pinq[14][2] */ 0,
    /* pinq[15][0] */ 0,
    /* pinq[15][1] */ 0,
    /* pinq[15][2] */ 0,
    /* pinq[16][0] */ 0,
    /* pinq[16][1] */ 0,
    /* pinq[16][2] */ 0,
    /* pinq[17][0] */ 0,
    /* pinq[17][1] */ 0,
    /* pinq[17][2] */ 0,
    /* rkq[0][0] */ 0,
    /* rkq[0][1] */ 0,
    /* rkq[0][2] */ 0,
    /* rkq[1][0] */ 0,
    /* rkq[1][1] */ 0,
    /* rkq[1][2] */ 0,
    /* rkq[2][0] */ 0,
    /* rkq[2][1] */ 0,
    /* rkq[2][2] */ 0,
    /* rkq[3][0] */ 0,
    /* rkq[3][1] */ 0,
    /* rkq[3][2] */ 0,
    /* rkq[4][0] */ 0,
    /* rkq[4][1] */ 0,
    /* rkq[4][2] */ 0,
    /* rkq[5][0] */ 0,
    /* rkq[5][1] */ 0,
    /* rkq[5][2] */ 0,
    /* rkq[6][0] */ 0,
    /* rkq[6][1] */ 0,
    /* rkq[6][2] */ 0,
    /* rkq[7][0] */ 0,
    /* rkq[7][1] */ 0,
    /* rkq[7][2] */ 0,
    /* rkq[8][0] */ 0,
    /* rkq[8][1] */ 0,
    /* rkq[8][2] */ 0,
    /* rkq[9][0] */ 0,
    /* rkq[9][1] */ 0,
    /* rkq[9][2] */ 0,
    /* rkq[10][0] */ 0,
    /* rkq[10][1] */ 0,
    /* rkq[10][2] */ 0,
    /* rkq[11][0] */ 0,
    /* rkq[11][1] */ 0,
    /* rkq[11][2] */ 0,
    /* rkq[12][0] */ 0,
    /* rkq[12][1] */ 0,
    /* rkq[12][2] */ 0,
    /* rkq[13][0] */ 0,
    /* rkq[13][1] */ 0,
    /* rkq[13][2] */ 0,
    /* rkq[14][0] */ 0,
    /* rkq[14][1] */ 0,
    /* rkq[14][2] */ 0,
    /* rkq[15][0] */ 0,
    /* rkq[15][1] */ 0,
    /* rkq[15][2] */ 0,
    /* riq[0][0] */ 0,
    /* riq[0][1] */ 0,
    /* riq[0][2] */ 0,
    /* riq[1][0] */ 0,
    /* riq[1][1] */ 0,
    /* riq[1][2] */ 0,
    /* riq[2][0] */ 0,
    /* riq[2][1] */ 0,
    /* riq[2][2] */ 0,
    /* riq[3][0] */ 0,
    /* riq[3][1] */ 0,
    /* riq[3][2] */ 0,
    /* riq[4][0] */ 0,
    /* riq[4][1] */ 0,
    /* riq[4][2] */ 0,
    /* riq[5][0] */ 0,
    /* riq[5][1] */ 0,
    /* riq[5][2] */ 0,
    /* riq[6][0] */ 0,
    /* riq[6][1] */ 0,
    /* riq[6][2] */ 0,
    /* riq[7][0] */ 0,
    /* riq[7][1] */ 0,
    /* riq[7][2] */ 0,
    /* riq[8][0] */ 0,
    /* riq[8][1] */ 0,
    /* riq[8][2] */ 0,
    /* riq[9][0] */ 0,
    /* riq[9][1] */ 0,
    /* riq[9][2] */ 0,
    /* riq[10][0] */ 0,
    /* riq[10][1] */ 0,
    /* riq[10][2] */ 0,
    /* riq[11][0] */ 0,
    /* riq[11][1] */ 0,
    /* riq[11][2] */ 0,
    /* riq[12][0] */ 0,
    /* riq[12][1] */ 0,
    /* riq[12][2] */ 0,
    /* riq[13][0] */ 0,
    /* riq[13][1] */ 0,
    /* riq[13][2] */ 0,
    /* riq[14][0] */ 0,
    /* riq[14][1] */ 0,
    /* riq[14][2] */ 0,
    /* riq[15][0] */ 0,
    /* riq[15][1] */ 0,
    /* riq[15][2] */ 0,
    /* presq[0] */ 0,
    /* presq[1] */ 0,
    /* presq[2] */ 0,
    /* presq[3] */ 0,
    /* presq[4] */ 0,
    /* presq[5] */ 0,
    /* presq[6] */ 0,
    /* presq[7] */ 0,
    /* presq[8] */ 0,
    /* presq[9] */ 0,
    /* presq[10] */ 0,
    /* presq[11] */ 0,
    /* presq[12] */ 0,
    /* presq[13] */ 0,
    /* presq[14] */ 0,
    /* presq[15] */ 0,
    /* presq[16] */ 0,
    /* presq[17] */ 0,
    /* stabvelq */ 3,
    /* stabposq */ 3,

/* End of values from input file */

};
robotgstate_t robotgstate;
robotglhs_t robotglhs;
robotgrhs_t robotgrhs;
robotgtemp_t robotgtemp;


void robotinit(void)
{
/*
Initialization routine


 This routine must be called before the first call to sdstate(), after
 supplying values for any `?' parameters in the input.
*/
    double sumsq,norminv;
    int i,j,k;


/* Check that all `?' parameters have been assigned values */

    for (k = 0; k < 3; k++) {
        if (gravq[k] == 1) {
            robotseterr(7,25);
        }
    }
    for (k = 0; k < 16; k++) {
        if (mkq[k] == 1) {
            robotseterr(7,26);
        }
        for (i = 0; i < 3; i++) {
            if (rkq[k][i] == 1) {
                robotseterr(7,29);
            }
            if (riq[k][i] == 1) {
                robotseterr(7,30);
            }
            for (j = 0; j < 3; j++) {
                if (ikq[k][i][j] == 1) {
                    robotseterr(7,27);
                }
            }
        }
    }
    for (k = 0; k < 18; k++) {
        for (i = 0; i < 3; i++) {
            if (pinq[k][i] == 1) {
                robotseterr(7,28);
            }
        }
    }

/* Normalize pin vectors if necessary */


/* Zero out ping and hngpt */

    for (i = 0; i < 18; i++) {
        for (j = 0; j < 3; j++) {
            ping[i][j] = 0.;
            hngpt[i][j] = 0.;
        }
    }

/* Compute pseudobody-related constants */

    rcom[0][0] = 0.;
    rcom[0][1] = 0.;
    rcom[0][2] = 0.;
    rcom[1][0] = 0.;
    rcom[1][1] = 0.;
    rcom[1][2] = 0.;
    rcom[2][0] = 0.;
    rcom[2][1] = 0.;
    rcom[2][2] = 0.;
    rcom[3][0] = 0.;
    rcom[3][1] = 0.;
    rcom[3][2] = 0.;
    rcom[4][0] = 0.;
    rcom[4][1] = 0.;
    rcom[4][2] = 0.;
    rcom[5][0] = 0.;
    rcom[5][1] = 0.;
    rcom[5][2] = 0.;
    rcom[6][0] = 0.;
    rcom[6][1] = 0.;
    rcom[6][2] = 0.;
    rcom[7][0] = 0.;
    rcom[7][1] = 0.;
    rcom[7][2] = 0.;
    rcom[8][0] = 0.;
    rcom[8][1] = 0.;
    rcom[8][2] = 0.;
    rcom[9][0] = 0.;
    rcom[9][1] = 0.;
    rcom[9][2] = 0.;
    rcom[10][0] = 0.;
    rcom[10][1] = 0.;
    rcom[10][2] = 0.;
    rcom[11][0] = 0.;
    rcom[11][1] = 0.;
    rcom[11][2] = 0.;
    rcom[12][0] = 0.;
    rcom[12][1] = 0.;
    rcom[12][2] = 0.;
    rcom[13][0] = 0.;
    rcom[13][1] = 0.;
    rcom[13][2] = 0.;
    rcom[14][0] = 0.;
    rcom[14][1] = 0.;
    rcom[14][2] = 0.;
    rcom[15][0] = 0.;
    rcom[15][1] = 0.;
    rcom[15][2] = 0.;

/* Compute mass properties-related constants */

    mtot = 89.57;
    robotserialno(&i);
    if (i != 70405) {
        robotseterr(7,41);
    }
    roustate = 1;
}

void robotstate(double timein, double *qin, double *uin)
{
/*
Compute kinematic information and store it in sdgstate.

Generated 19-Jul-2001 15:42:59 by SD/FAST, Order(N) formulation
(sdfast B.2.6 #70405) on machine ID 690a1b33
Copyright (c) 1990-1996 Symbolic Dynamics, Inc.
Copyright (c) 1990-1996 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/
    int i,j,qchg,uchg;

    if ((roustate != 1) && (roustate != 2) && (roustate != 3)) {
        robotseterr(8,22);
        return;
    }
    if (roustate == 1) {
        for (i = 0; i < 18; i++) {
            if (presq[i] == 1) {
                robotseterr(8,31);
            }
        }
    }
/*
See if time or any qs have changed since last call
*/
    if ((roustate != 1) && (timein == curtim)) {
        qchg = 0;
        for (i = 0; i < 18; i++) {
            if (qin[i] != q[i]) {
                qchg = 1;
                break;
            }
        }
    } else {
        qchg = 1;
    }
/*
If time and qs are unchanged, check us
*/
    if (qchg == 0) {
        uchg = 0;
        for (i = 0; i < 18; i++) {
            if (uin[i] != u[i]) {
                uchg = 1;
                break;
            }
        }
    } else {
        uchg = 1;
    }
    curtim = timein;
    roustate = 2;
    if (qchg == 0) {
        goto skipqs;
    }
/*
Position-related variables need to be computed
*/
    vpkflg = 0;
    mmflg = 0;
    mmlduflg = 0;
    wwflg = 0;
    for (i = 0; i < 18; i++) {
        q[i] = qin[i];
    }
/*
Compute sines and cosines of q
*/
    s2 = sin(q[2]);
    c2 = cos(q[2]);
    s3 = sin(q[3]);
    c3 = cos(q[3]);
    s4 = sin(q[4]);
    c4 = cos(q[4]);
    s5 = sin(q[5]);
    c5 = cos(q[5]);
    s6 = sin(q[6]);
    c6 = cos(q[6]);
    s7 = sin(q[7]);
    c7 = cos(q[7]);
    s8 = sin(q[8]);
    c8 = cos(q[8]);
    s9 = sin(q[9]);
    c9 = cos(q[9]);
    s10 = sin(q[10]);
    c10 = cos(q[10]);
    s11 = sin(q[11]);
    c11 = cos(q[11]);
    s12 = sin(q[12]);
    c12 = cos(q[12]);
    s13 = sin(q[13]);
    c13 = cos(q[13]);
    s14 = sin(q[14]);
    c14 = cos(q[14]);
    s15 = sin(q[15]);
    c15 = cos(q[15]);
    s16 = sin(q[16]);
    c16 = cos(q[16]);
    s17 = sin(q[17]);
    c17 = cos(q[17]);
/*
Compute across-axis direction cosines Cik
*/
/*
Compute across-joint direction cosines Cib
*/
/*
Compute gravity
*/
/*
Compute cnk & cnb (direction cosines in N)
*/
    cnk[3][1][1] = ((c2*c3)-(s2*s3));
    cnk[3][1][2] = -((s2*c3)+(s3*c2));
    cnk[3][2][1] = ((s2*c3)+(s3*c2));
    cnk[3][2][2] = ((c2*c3)-(s2*s3));
    cnk[4][1][1] = ((cnk[3][1][1]*c4)+(cnk[3][1][2]*s4));
    cnk[4][1][2] = ((cnk[3][1][2]*c4)-(cnk[3][1][1]*s4));
    cnk[4][2][1] = ((cnk[3][2][1]*c4)+(cnk[3][2][2]*s4));
    cnk[4][2][2] = ((cnk[3][2][2]*c4)-(cnk[3][2][1]*s4));
    cnk[5][1][1] = ((cnk[4][1][1]*c5)+(cnk[4][1][2]*s5));
    cnk[5][1][2] = ((cnk[4][1][2]*c5)-(cnk[4][1][1]*s5));
    cnk[5][2][1] = ((cnk[4][2][1]*c5)+(cnk[4][2][2]*s5));
    cnk[5][2][2] = ((cnk[4][2][2]*c5)-(cnk[4][2][1]*s5));
    cnk[6][1][1] = ((cnk[3][1][1]*c6)+(cnk[3][1][2]*s6));
    cnk[6][1][2] = ((cnk[3][1][2]*c6)-(cnk[3][1][1]*s6));
    cnk[6][2][1] = ((cnk[3][2][1]*c6)+(cnk[3][2][2]*s6));
    cnk[6][2][2] = ((cnk[3][2][2]*c6)-(cnk[3][2][1]*s6));
    cnk[7][1][1] = ((cnk[6][1][1]*c7)+(cnk[6][1][2]*s7));
    cnk[7][1][2] = ((cnk[6][1][2]*c7)-(cnk[6][1][1]*s7));
    cnk[7][2][1] = ((cnk[6][2][1]*c7)+(cnk[6][2][2]*s7));
    cnk[7][2][2] = ((cnk[6][2][2]*c7)-(cnk[6][2][1]*s7));
    cnk[8][1][0] = (cnk[7][1][1]*s8);
    cnk[8][1][1] = (cnk[7][1][1]*c8);
    cnk[8][2][0] = (cnk[7][2][1]*s8);
    cnk[8][2][1] = (cnk[7][2][1]*c8);
    cnk[9][1][1] = ((cnk[3][1][1]*c9)+(cnk[3][1][2]*s9));
    cnk[9][1][2] = ((cnk[3][1][2]*c9)-(cnk[3][1][1]*s9));
    cnk[9][2][1] = ((cnk[3][2][1]*c9)+(cnk[3][2][2]*s9));
    cnk[9][2][2] = ((cnk[3][2][2]*c9)-(cnk[3][2][1]*s9));
    cnk[10][1][1] = ((cnk[9][1][1]*c10)+(cnk[9][1][2]*s10));
    cnk[10][1][2] = ((cnk[9][1][2]*c10)-(cnk[9][1][1]*s10));
    cnk[10][2][1] = ((cnk[9][2][1]*c10)+(cnk[9][2][2]*s10));
    cnk[10][2][2] = ((cnk[9][2][2]*c10)-(cnk[9][2][1]*s10));
    cnk[11][1][0] = (cnk[10][1][1]*s11);
    cnk[11][1][1] = (cnk[10][1][1]*c11);
    cnk[11][2][0] = (cnk[10][2][1]*s11);
    cnk[11][2][1] = (cnk[10][2][1]*c11);
    cnk[12][1][1] = ((c2*c12)-(s2*s12));
    cnk[12][1][2] = -((s2*c12)+(s12*c2));
    cnk[12][2][1] = ((s2*c12)+(s12*c2));
    cnk[12][2][2] = ((c2*c12)-(s2*s12));
    cnk[13][1][1] = ((cnk[12][1][1]*c13)+(cnk[12][1][2]*s13));
    cnk[13][1][2] = ((cnk[12][1][2]*c13)-(cnk[12][1][1]*s13));
    cnk[13][2][1] = ((cnk[12][2][1]*c13)+(cnk[12][2][2]*s13));
    cnk[13][2][2] = ((cnk[12][2][2]*c13)-(cnk[12][2][1]*s13));
    cnk[14][1][1] = ((cnk[13][1][1]*c14)+(cnk[13][1][2]*s14));
    cnk[14][1][2] = ((cnk[13][1][2]*c14)-(cnk[13][1][1]*s14));
    cnk[14][2][1] = ((cnk[13][2][1]*c14)+(cnk[13][2][2]*s14));
    cnk[14][2][2] = ((cnk[13][2][2]*c14)-(cnk[13][2][1]*s14));
    cnk[15][1][1] = ((c2*c15)-(s2*s15));
    cnk[15][1][2] = -((s2*c15)+(s15*c2));
    cnk[15][2][1] = ((s2*c15)+(s15*c2));
    cnk[15][2][2] = ((c2*c15)-(s2*s15));
    cnk[16][1][1] = ((cnk[15][1][1]*c16)+(cnk[15][1][2]*s16));
    cnk[16][1][2] = ((cnk[15][1][2]*c16)-(cnk[15][1][1]*s16));
    cnk[16][2][1] = ((cnk[15][2][1]*c16)+(cnk[15][2][2]*s16));
    cnk[16][2][2] = ((cnk[15][2][2]*c16)-(cnk[15][2][1]*s16));
    cnk[17][1][1] = ((cnk[16][1][1]*c17)+(cnk[16][1][2]*s17));
    cnk[17][1][2] = ((cnk[16][1][2]*c17)-(cnk[16][1][1]*s17));
    cnk[17][2][1] = ((cnk[16][2][1]*c17)+(cnk[16][2][2]*s17));
    cnk[17][2][2] = ((cnk[16][2][2]*c17)-(cnk[16][2][1]*s17));
    cnb[0][0][0] = 1.;
    cnb[0][0][1] = 0.;
    cnb[0][0][2] = 0.;
    cnb[0][1][0] = 0.;
    cnb[0][1][1] = c2;
    cnb[0][1][2] = -s2;
    cnb[0][2][0] = 0.;
    cnb[0][2][1] = s2;
    cnb[0][2][2] = c2;
    cnb[1][0][0] = 1.;
    cnb[1][0][1] = 0.;
    cnb[1][0][2] = 0.;
    cnb[1][1][0] = 0.;
    cnb[1][1][1] = cnk[3][1][1];
    cnb[1][1][2] = cnk[3][1][2];
    cnb[1][2][0] = 0.;
    cnb[1][2][1] = cnk[3][2][1];
    cnb[1][2][2] = cnk[3][2][2];
    cnb[2][0][0] = 1.;
    cnb[2][0][1] = 0.;
    cnb[2][0][2] = 0.;
    cnb[2][1][0] = 0.;
    cnb[2][1][1] = cnk[4][1][1];
    cnb[2][1][2] = cnk[4][1][2];
    cnb[2][2][0] = 0.;
    cnb[2][2][1] = cnk[4][2][1];
    cnb[2][2][2] = cnk[4][2][2];
    cnb[3][0][0] = 1.;
    cnb[3][0][1] = 0.;
    cnb[3][0][2] = 0.;
    cnb[3][1][0] = 0.;
    cnb[3][1][1] = cnk[5][1][1];
    cnb[3][1][2] = cnk[5][1][2];
    cnb[3][2][0] = 0.;
    cnb[3][2][1] = cnk[5][2][1];
    cnb[3][2][2] = cnk[5][2][2];
    cnb[4][0][0] = 1.;
    cnb[4][0][1] = 0.;
    cnb[4][0][2] = 0.;
    cnb[4][1][0] = 0.;
    cnb[4][1][1] = cnk[6][1][1];
    cnb[4][1][2] = cnk[6][1][2];
    cnb[4][2][0] = 0.;
    cnb[4][2][1] = cnk[6][2][1];
    cnb[4][2][2] = cnk[6][2][2];
    cnb[5][0][0] = 1.;
    cnb[5][0][1] = 0.;
    cnb[5][0][2] = 0.;
    cnb[5][1][0] = 0.;
    cnb[5][1][1] = cnk[7][1][1];
    cnb[5][1][2] = cnk[7][1][2];
    cnb[5][2][0] = 0.;
    cnb[5][2][1] = cnk[7][2][1];
    cnb[5][2][2] = cnk[7][2][2];
    cnb[6][0][0] = c8;
    cnb[6][0][1] = -s8;
    cnb[6][0][2] = 0.;
    cnb[6][1][0] = cnk[8][1][0];
    cnb[6][1][1] = cnk[8][1][1];
    cnb[6][1][2] = cnk[7][1][2];
    cnb[6][2][0] = cnk[8][2][0];
    cnb[6][2][1] = cnk[8][2][1];
    cnb[6][2][2] = cnk[7][2][2];
    cnb[7][0][0] = 1.;
    cnb[7][0][1] = 0.;
    cnb[7][0][2] = 0.;
    cnb[7][1][0] = 0.;
    cnb[7][1][1] = cnk[9][1][1];
    cnb[7][1][2] = cnk[9][1][2];
    cnb[7][2][0] = 0.;
    cnb[7][2][1] = cnk[9][2][1];
    cnb[7][2][2] = cnk[9][2][2];
    cnb[8][0][0] = 1.;
    cnb[8][0][1] = 0.;
    cnb[8][0][2] = 0.;
    cnb[8][1][0] = 0.;
    cnb[8][1][1] = cnk[10][1][1];
    cnb[8][1][2] = cnk[10][1][2];
    cnb[8][2][0] = 0.;
    cnb[8][2][1] = cnk[10][2][1];
    cnb[8][2][2] = cnk[10][2][2];
    cnb[9][0][0] = c11;
    cnb[9][0][1] = -s11;
    cnb[9][0][2] = 0.;
    cnb[9][1][0] = cnk[11][1][0];
    cnb[9][1][1] = cnk[11][1][1];
    cnb[9][1][2] = cnk[10][1][2];
    cnb[9][2][0] = cnk[11][2][0];
    cnb[9][2][1] = cnk[11][2][1];
    cnb[9][2][2] = cnk[10][2][2];
    cnb[10][0][0] = 1.;
    cnb[10][0][1] = 0.;
    cnb[10][0][2] = 0.;
    cnb[10][1][0] = 0.;
    cnb[10][1][1] = cnk[12][1][1];
    cnb[10][1][2] = cnk[12][1][2];
    cnb[10][2][0] = 0.;
    cnb[10][2][1] = cnk[12][2][1];
    cnb[10][2][2] = cnk[12][2][2];
    cnb[11][0][0] = 1.;
    cnb[11][0][1] = 0.;
    cnb[11][0][2] = 0.;
    cnb[11][1][0] = 0.;
    cnb[11][1][1] = cnk[13][1][1];
    cnb[11][1][2] = cnk[13][1][2];
    cnb[11][2][0] = 0.;
    cnb[11][2][1] = cnk[13][2][1];
    cnb[11][2][2] = cnk[13][2][2];
    cnb[12][0][0] = 1.;
    cnb[12][0][1] = 0.;
    cnb[12][0][2] = 0.;
    cnb[12][1][0] = 0.;
    cnb[12][1][1] = cnk[14][1][1];
    cnb[12][1][2] = cnk[14][1][2];
    cnb[12][2][0] = 0.;
    cnb[12][2][1] = cnk[14][2][1];
    cnb[12][2][2] = cnk[14][2][2];
    cnb[13][0][0] = 1.;
    cnb[13][0][1] = 0.;
    cnb[13][0][2] = 0.;
    cnb[13][1][0] = 0.;
    cnb[13][1][1] = cnk[15][1][1];
    cnb[13][1][2] = cnk[15][1][2];
    cnb[13][2][0] = 0.;
    cnb[13][2][1] = cnk[15][2][1];
    cnb[13][2][2] = cnk[15][2][2];
    cnb[14][0][0] = 1.;
    cnb[14][0][1] = 0.;
    cnb[14][0][2] = 0.;
    cnb[14][1][0] = 0.;
    cnb[14][1][1] = cnk[16][1][1];
    cnb[14][1][2] = cnk[16][1][2];
    cnb[14][2][0] = 0.;
    cnb[14][2][1] = cnk[16][2][1];
    cnb[14][2][2] = cnk[16][2][2];
    cnb[15][0][0] = 1.;
    cnb[15][0][1] = 0.;
    cnb[15][0][2] = 0.;
    cnb[15][1][0] = 0.;
    cnb[15][1][1] = cnk[17][1][1];
    cnb[15][1][2] = cnk[17][1][2];
    cnb[15][2][0] = 0.;
    cnb[15][2][1] = cnk[17][2][1];
    cnb[15][2][2] = cnk[17][2][2];
/*
Compute q-related auxiliary variables
*/
    rpri[0][1] = (1.131+q[0]);
    rik[0][1] = (1.131+q[0]);
    rik[3][1] = (.14625+((.05*s3)+(.1206*c3)));
    rik[3][2] = (((.05*c3)-(.1206*s3))-.0351);
    rik[4][1] = (.0442+((.24635*c4)-(.0013*s4)));
    rik[4][2] = (.0065-((.0013*c4)+(.24635*s4)));
    rik[5][1] = (.078+((.0065*s5)+(.0442*c5)));
    rik[5][2] = (.0312+((.0065*c5)-(.0442*s5)));
    rik[6][1] = (((.0013*s6)+(.18915*c6))-.1326);
    rik[6][2] = (.0013+((.0013*c6)-(.18915*s6)));
    rik[7][1] = (((.0013*s7)-(.1326*c7))-.1378);
    rik[7][2] = ((.0013*c7)+(.1326*s7));
    rik[8][0] = ((.0039*c8)-(.1378*s8));
    rik[8][1] = -(.065+((.0039*s8)+(.1378*c8)));
    rik[9][1] = (((.0013*s9)+(.18915*c9))-.1326);
    rik[9][2] = (.0013+((.0013*c9)-(.18915*s9)));
    rik[10][1] = (((.0013*s10)-(.1326*c10))-.1378);
    rik[10][2] = ((.0013*c10)+(.1326*s10));
    rik[11][0] = -((.0039*c11)+(.1378*s11));
    rik[11][1] = (((.0039*s11)-(.1378*c11))-.065);
    rik[12][1] = (((.0058*s12)-(.0406*c12))-.2379);
    rik[12][2] = (.0143+((.0058*c12)+(.0406*s12)));
    rik[13][1] = (((.0143*s13)-(.2379*c13))-.2158);
    rik[13][2] = (((.0143*c13)+(.2379*s13))-.0039);
    rik[14][1] = -(.0442+((.0039*s14)+(.2158*c14)));
    rik[14][2] = (.039+((.2158*s14)-(.0039*c14)));
    rik[15][1] = (((.0058*s15)-(.0406*c15))-.2379);
    rik[15][2] = (.0143+((.0058*c15)+(.0406*s15)));
    rik[16][1] = (((.0143*s16)-(.2379*c16))-.2158);
    rik[16][2] = (((.0143*c16)+(.2379*s16))-.0039);
    rik[17][1] = -(.0442+((.0039*s17)+(.2158*c17)));
    rik[17][2] = (.039+((.2158*s17)-(.0039*c17)));
    rik2[0][1] = (1.131+q[0]);
    rikt[4][0][1] = ((.0364*c4)+(.3926*s4));
    rikt[4][0][2] = ((.3926*c4)-(.0364*s4));
    rikt[5][0][1] = ((.0884*s5)-(.013*c5));
    rikt[5][0][2] = ((.013*s5)+(.0884*c5));
    rikt[6][0][1] = ((.0338*c6)+(.3354*s6));
    rikt[6][0][2] = ((.3354*c6)-(.0338*s6));
    rikt[7][0][1] = -((.0026*c7)+(.2652*s7));
    rikt[7][0][2] = ((.0026*s7)-(.2652*c7));
    rikt[9][0][1] = ((.0338*c9)+(.3354*s9));
    rikt[9][0][2] = ((.3354*c9)-(.0338*s9));
    rikt[10][0][1] = -((.0026*c10)+(.2652*s10));
    rikt[10][0][2] = ((.0026*s10)-(.2652*c10));
    rikt[12][0][1] = ((.0442*c12)-(.1612*s12));
    rikt[12][0][2] = -((.0442*s12)+(.1612*c12));
    rikt[13][0][1] = -((.0286*c13)+(.4758*s13));
    rikt[13][0][2] = ((.0286*s13)-(.4758*c13));
    rikt[14][0][1] = ((.0078*c14)-(.4316*s14));
    rikt[14][0][2] = -((.0078*s14)+(.4316*c14));
    rikt[15][0][1] = ((.0442*c15)-(.1612*s15));
    rikt[15][0][2] = -((.0442*s15)+(.1612*c15));
    rikt[16][0][1] = -((.0286*c16)+(.4758*s16));
    rikt[16][0][2] = ((.0286*s16)-(.4758*c16));
    rikt[17][0][1] = ((.0078*c17)-(.4316*s17));
    rikt[17][0][2] = -((.0078*s17)+(.4316*c17));
/*
Compute rnk & rnb (mass center locations in N)
*/
    rnk[0][1] = (1.131+q[0]);
    rnk[1][2] = (.0052+q[1]);
    rnk[2][1] = (rnk[0][1]+((.05*s2)-(.1206*c2)));
    rnk[2][2] = (rnk[1][2]-((.05*c2)+(.1206*s2)));
    rnk[3][1] = ((rnk[2][1]+((.1206*c2)-(.05*s2)))+((.14625*cnk[3][1][1])-(.0351
      *cnk[3][1][2])));
    rnk[3][2] = ((rnk[2][2]+((.05*c2)+(.1206*s2)))+((.14625*cnk[3][2][1])-(.0351
      *cnk[3][2][2])));
    rnk[4][1] = ((rnk[3][1]+((.24635*cnk[3][1][1])-(.0013*cnk[3][1][2])))+((
      .0065*cnk[4][1][2])+(.0442*cnk[4][1][1])));
    rnk[4][2] = ((rnk[3][2]+((.24635*cnk[3][2][1])-(.0013*cnk[3][2][2])))+((
      .0065*cnk[4][2][2])+(.0442*cnk[4][2][1])));
    rnk[5][1] = ((rnk[4][1]+((.0065*cnk[4][1][2])+(.0442*cnk[4][1][1])))+((.0312
      *cnk[5][1][2])+(.078*cnk[5][1][1])));
    rnk[5][2] = ((rnk[4][2]+((.0065*cnk[4][2][2])+(.0442*cnk[4][2][1])))+((.0312
      *cnk[5][2][2])+(.078*cnk[5][2][1])));
    rnk[6][1] = ((rnk[3][1]+((.0013*cnk[3][1][2])+(.18915*cnk[3][1][1])))+((
      .0013*cnk[6][1][2])-(.1326*cnk[6][1][1])));
    rnk[6][2] = ((rnk[3][2]+((.0013*cnk[3][2][2])+(.18915*cnk[3][2][1])))+((
      .0013*cnk[6][2][2])-(.1326*cnk[6][2][1])));
    rnk[7][1] = ((rnk[6][1]+((.0013*cnk[6][1][2])-(.1326*cnk[6][1][1])))-(.1378*
      cnk[7][1][1]));
    rnk[7][2] = ((rnk[6][2]+((.0013*cnk[6][2][2])-(.1326*cnk[6][2][1])))-(.1378*
      cnk[7][2][1]));
    rnk[8][0] = (.1768+(.065*s8));
    rnk[8][1] = ((rnk[7][1]-(.1378*cnk[7][1][1]))-(.065*cnk[8][1][1]));
    rnk[8][2] = ((rnk[7][2]-(.1378*cnk[7][2][1]))-(.065*cnk[8][2][1]));
    rnk[9][1] = ((rnk[3][1]+((.0013*cnk[3][1][2])+(.18915*cnk[3][1][1])))+((
      .0013*cnk[9][1][2])-(.1326*cnk[9][1][1])));
    rnk[9][2] = ((rnk[3][2]+((.0013*cnk[3][2][2])+(.18915*cnk[3][2][1])))+((
      .0013*cnk[9][2][2])-(.1326*cnk[9][2][1])));
    rnk[10][1] = ((rnk[9][1]+((.0013*cnk[9][1][2])-(.1326*cnk[9][1][1])))-(.1378
      *cnk[10][1][1]));
    rnk[10][2] = ((rnk[9][2]+((.0013*cnk[9][2][2])-(.1326*cnk[9][2][1])))-(.1378
      *cnk[10][2][1]));
    rnk[11][0] = ((.065*s11)-.1768);
    rnk[11][1] = ((rnk[10][1]-(.1378*cnk[10][1][1]))-(.065*cnk[11][1][1]));
    rnk[11][2] = ((rnk[10][2]-(.1378*cnk[10][2][1]))-(.065*cnk[11][2][1]));
    rnk[12][1] = ((rnk[2][1]-((.0058*s2)+(.0406*c2)))+((.0143*cnk[12][1][2])-(
      .2379*cnk[12][1][1])));
    rnk[12][2] = ((rnk[2][2]+((.0058*c2)-(.0406*s2)))+((.0143*cnk[12][2][2])-(
      .2379*cnk[12][2][1])));
    rnk[13][1] = ((rnk[12][1]+((.0143*cnk[12][1][2])-(.2379*cnk[12][1][1])))-((
      .0039*cnk[13][1][2])+(.2158*cnk[13][1][1])));
    rnk[13][2] = ((rnk[12][2]+((.0143*cnk[12][2][2])-(.2379*cnk[12][2][1])))-((
      .0039*cnk[13][2][2])+(.2158*cnk[13][2][1])));
    rnk[14][1] = ((rnk[13][1]-((.0039*cnk[13][1][2])+(.2158*cnk[13][1][1])))+((
      .039*cnk[14][1][2])-(.0442*cnk[14][1][1])));
    rnk[14][2] = ((rnk[13][2]-((.0039*cnk[13][2][2])+(.2158*cnk[13][2][1])))+((
      .039*cnk[14][2][2])-(.0442*cnk[14][2][1])));
    rnk[15][1] = ((rnk[2][1]-((.0058*s2)+(.0406*c2)))+((.0143*cnk[15][1][2])-(
      .2379*cnk[15][1][1])));
    rnk[15][2] = ((rnk[2][2]+((.0058*c2)-(.0406*s2)))+((.0143*cnk[15][2][2])-(
      .2379*cnk[15][2][1])));
    rnk[16][1] = ((rnk[15][1]+((.0143*cnk[15][1][2])-(.2379*cnk[15][1][1])))-((
      .0039*cnk[16][1][2])+(.2158*cnk[16][1][1])));
    rnk[16][2] = ((rnk[15][2]+((.0143*cnk[15][2][2])-(.2379*cnk[15][2][1])))-((
      .0039*cnk[16][2][2])+(.2158*cnk[16][2][1])));
    rnk[17][1] = ((rnk[16][1]-((.0039*cnk[16][1][2])+(.2158*cnk[16][1][1])))+((
      .039*cnk[17][1][2])-(.0442*cnk[17][1][1])));
    rnk[17][2] = ((rnk[16][2]-((.0039*cnk[16][2][2])+(.2158*cnk[16][2][1])))+((
      .039*cnk[17][2][2])-(.0442*cnk[17][2][1])));
    rnb[0][0] = 0.;
    rnb[0][1] = rnk[2][1];
    rnb[0][2] = rnk[2][2];
    rnb[1][0] = 0.;
    rnb[1][1] = rnk[3][1];
    rnb[1][2] = rnk[3][2];
    rnb[2][0] = 0.;
    rnb[2][1] = rnk[4][1];
    rnb[2][2] = rnk[4][2];
    rnb[3][0] = 0.;
    rnb[3][1] = rnk[5][1];
    rnb[3][2] = rnk[5][2];
    rnb[4][0] = .1768;
    rnb[4][1] = rnk[6][1];
    rnb[4][2] = rnk[6][2];
    rnb[5][0] = .1729;
    rnb[5][1] = rnk[7][1];
    rnb[5][2] = rnk[7][2];
    rnb[6][0] = rnk[8][0];
    rnb[6][1] = rnk[8][1];
    rnb[6][2] = rnk[8][2];
    rnb[7][0] = -.1768;
    rnb[7][1] = rnk[9][1];
    rnb[7][2] = rnk[9][2];
    rnb[8][0] = -.1729;
    rnb[8][1] = rnk[10][1];
    rnb[8][2] = rnk[10][2];
    rnb[9][0] = rnk[11][0];
    rnb[9][1] = rnk[11][1];
    rnb[9][2] = rnk[11][2];
    rnb[10][0] = .0949;
    rnb[10][1] = rnk[12][1];
    rnb[10][2] = rnk[12][2];
    rnb[11][0] = .0702;
    rnb[11][1] = rnk[13][1];
    rnb[11][2] = rnk[13][2];
    rnb[12][0] = .0624;
    rnb[12][1] = rnk[14][1];
    rnb[12][2] = rnk[14][2];
    rnb[13][0] = -.0949;
    rnb[13][1] = rnk[15][1];
    rnb[13][2] = rnk[15][2];
    rnb[14][0] = -.0702;
    rnb[14][1] = rnk[16][1];
    rnb[14][2] = rnk[16][2];
    rnb[15][0] = -.0624;
    rnb[15][1] = rnk[17][1];
    rnb[15][2] = rnk[17][2];
/*
Compute com (system mass center location in N)
*/
    com[0] = (.00614044881098582*(rnk[8][0]+rnk[11][0]));
    com[1] = (.0111644523836106*((1.34*rnk[17][1])+((4.16*rnk[16][1])+((8.35*
      rnk[15][1])+((1.34*rnk[14][1])+((4.16*rnk[13][1])+((8.35*rnk[12][1])+((.55
      *rnk[11][1])+((1.21*rnk[10][1])+((2.79*rnk[9][1])+((.55*rnk[8][1])+((1.21*
      rnk[7][1])+((2.79*rnk[6][1])+((5.89*rnk[5][1])+(rnk[4][1]+((16.61*
      rnk[2][1])+(29.27*rnk[3][1])))))))))))))))));
    com[2] = (.0111644523836106*((1.34*rnk[17][2])+((4.16*rnk[16][2])+((8.35*
      rnk[15][2])+((1.34*rnk[14][2])+((4.16*rnk[13][2])+((8.35*rnk[12][2])+((.55
      *rnk[11][2])+((1.21*rnk[10][2])+((2.79*rnk[9][2])+((.55*rnk[8][2])+((1.21*
      rnk[7][2])+((2.79*rnk[6][2])+((5.89*rnk[5][2])+(rnk[4][2]+((16.61*
      rnk[2][2])+(29.27*rnk[3][2])))))))))))))))));
    skipqs: ;
    if (uchg == 0) {
        goto skipus;
    }
/*
Velocity-related variables need to be computed
*/
    inerflg = 0;
    for (i = 0; i < 18; i++) {
        u[i] = uin[i];
    }
/*
Compute u-related auxiliary variables
*/
/*
Compute wk & wb (angular velocities)
*/
    wk[3][0] = (u[2]+u[3]);
    wk[4][0] = (u[4]+wk[3][0]);
    wk[5][0] = (u[5]+wk[4][0]);
    wk[6][0] = (u[6]+wk[3][0]);
    wk[7][0] = (u[7]+wk[6][0]);
    wk[8][0] = (wk[7][0]*c8);
    wk[8][1] = -(wk[7][0]*s8);
    wk[9][0] = (u[9]+wk[3][0]);
    wk[10][0] = (u[10]+wk[9][0]);
    wk[11][0] = (wk[10][0]*c11);
    wk[11][1] = -(wk[10][0]*s11);
    wk[12][0] = (u[2]+u[12]);
    wk[13][0] = (u[13]+wk[12][0]);
    wk[14][0] = (u[14]+wk[13][0]);
    wk[15][0] = (u[2]+u[15]);
    wk[16][0] = (u[16]+wk[15][0]);
    wk[17][0] = (u[17]+wk[16][0]);
    wb[0][0] = u[2];
    wb[0][1] = 0.;
    wb[0][2] = 0.;
    wb[1][0] = wk[3][0];
    wb[1][1] = 0.;
    wb[1][2] = 0.;
    wb[2][0] = wk[4][0];
    wb[2][1] = 0.;
    wb[2][2] = 0.;
    wb[3][0] = wk[5][0];
    wb[3][1] = 0.;
    wb[3][2] = 0.;
    wb[4][0] = wk[6][0];
    wb[4][1] = 0.;
    wb[4][2] = 0.;
    wb[5][0] = wk[7][0];
    wb[5][1] = 0.;
    wb[5][2] = 0.;
    wb[6][0] = wk[8][0];
    wb[6][1] = wk[8][1];
    wb[6][2] = u[8];
    wb[7][0] = wk[9][0];
    wb[7][1] = 0.;
    wb[7][2] = 0.;
    wb[8][0] = wk[10][0];
    wb[8][1] = 0.;
    wb[8][2] = 0.;
    wb[9][0] = wk[11][0];
    wb[9][1] = wk[11][1];
    wb[9][2] = u[11];
    wb[10][0] = wk[12][0];
    wb[10][1] = 0.;
    wb[10][2] = 0.;
    wb[11][0] = wk[13][0];
    wb[11][1] = 0.;
    wb[11][2] = 0.;
    wb[12][0] = wk[14][0];
    wb[12][1] = 0.;
    wb[12][2] = 0.;
    wb[13][0] = wk[15][0];
    wb[13][1] = 0.;
    wb[13][2] = 0.;
    wb[14][0] = wk[16][0];
    wb[14][1] = 0.;
    wb[14][2] = 0.;
    wb[15][0] = wk[17][0];
    wb[15][1] = 0.;
    wb[15][2] = 0.;
/*
Compute auxiliary variables involving wk
*/
    WkIkWk[8][0] = -(.0004*(u[8]*wk[8][1]));
    WkIkWk[8][1] = -(.0011*(u[8]*wk[8][0]));
    WkIkWk[8][2] = (.0015*(wk[8][0]*wk[8][1]));
    WkIkWk[11][0] = -(.0004*(u[11]*wk[11][1]));
    WkIkWk[11][1] = -(.0011*(u[11]*wk[11][0]));
    WkIkWk[11][2] = (.0015*(wk[11][0]*wk[11][1]));
/*
Compute temporaries for use in SDRHS
*/
    w0w0[0] = (u[2]*u[2]);
    w0w0[1] = (wk[3][0]*wk[3][0]);
    w0w0[2] = (wk[4][0]*wk[4][0]);
    w0w0[3] = (wk[5][0]*wk[5][0]);
    w0w0[4] = (wk[6][0]*wk[6][0]);
    w0w0[5] = (wk[7][0]*wk[7][0]);
    w0w0[6] = (wk[8][0]*wk[8][0]);
    w0w0[7] = (wk[9][0]*wk[9][0]);
    w0w0[8] = (wk[10][0]*wk[10][0]);
    w0w0[9] = (wk[11][0]*wk[11][0]);
    w0w0[10] = (wk[12][0]*wk[12][0]);
    w0w0[11] = (wk[13][0]*wk[13][0]);
    w0w0[12] = (wk[14][0]*wk[14][0]);
    w0w0[13] = (wk[15][0]*wk[15][0]);
    w0w0[14] = (wk[16][0]*wk[16][0]);
    w0w0[15] = (wk[17][0]*wk[17][0]);
    w1w1[6] = (wk[8][1]*wk[8][1]);
    w1w1[9] = (wk[11][1]*wk[11][1]);
    w2w2[6] = (u[8]*u[8]);
    w2w2[9] = (u[11]*u[11]);
    w0w1[6] = (wk[8][0]*wk[8][1]);
    w0w1[9] = (wk[11][0]*wk[11][1]);
    w0w2[6] = (u[8]*wk[8][0]);
    w0w2[9] = (u[11]*wk[11][0]);
    w1w2[6] = (u[8]*wk[8][1]);
    w1w2[9] = (u[11]*wk[11][1]);
    w00w11[6] = -(w0w0[6]+w1w1[6]);
    w00w11[9] = -(w0w0[9]+w1w1[9]);
    w00w22[6] = -(w0w0[6]+w2w2[6]);
    w00w22[9] = -(w0w0[9]+w2w2[9]);
    w11w22[6] = -(w1w1[6]+w2w2[6]);
    w11w22[9] = -(w1w1[9]+w2w2[9]);
/*
Compute vnk & vnb (mass center linear velocities in N)
*/
    vnk[2][1] = (u[0]+((.05*(u[2]*c2))+(.1206*(u[2]*s2))));
    vnk[2][2] = (u[1]+((.05*(u[2]*s2))-(.1206*(u[2]*c2))));
    vnk[3][1] = ((vnk[2][1]-((.05*(u[2]*c2))+(.1206*(u[2]*s2))))+((.0351*(
      cnk[3][1][1]*wk[3][0]))+(.14625*(cnk[3][1][2]*wk[3][0]))));
    vnk[3][2] = ((vnk[2][2]+((.1206*(u[2]*c2))-(.05*(u[2]*s2))))+((.0351*(
      cnk[3][2][1]*wk[3][0]))+(.14625*(cnk[3][2][2]*wk[3][0]))));
    vnk[4][1] = ((vnk[3][1]+((.0013*(cnk[3][1][1]*wk[3][0]))+(.24635*(
      cnk[3][1][2]*wk[3][0]))))+((.0442*(cnk[4][1][2]*wk[4][0]))-(.0065*(
      cnk[4][1][1]*wk[4][0]))));
    vnk[4][2] = ((vnk[3][2]+((.0013*(cnk[3][2][1]*wk[3][0]))+(.24635*(
      cnk[3][2][2]*wk[3][0]))))+((.0442*(cnk[4][2][2]*wk[4][0]))-(.0065*(
      cnk[4][2][1]*wk[4][0]))));
    vnk[5][1] = ((vnk[4][1]+((.0442*(cnk[4][1][2]*wk[4][0]))-(.0065*(
      cnk[4][1][1]*wk[4][0]))))+((.078*(cnk[5][1][2]*wk[5][0]))-(.0312*(
      cnk[5][1][1]*wk[5][0]))));
    vnk[5][2] = ((vnk[4][2]+((.0442*(cnk[4][2][2]*wk[4][0]))-(.0065*(
      cnk[4][2][1]*wk[4][0]))))+((.078*(cnk[5][2][2]*wk[5][0]))-(.0312*(
      cnk[5][2][1]*wk[5][0]))));
    vnk[6][1] = ((vnk[3][1]+((.18915*(cnk[3][1][2]*wk[3][0]))-(.0013*(
      cnk[3][1][1]*wk[3][0]))))-((.0013*(cnk[6][1][1]*wk[6][0]))+(.1326*(
      cnk[6][1][2]*wk[6][0]))));
    vnk[6][2] = ((vnk[3][2]+((.18915*(cnk[3][2][2]*wk[3][0]))-(.0013*(
      cnk[3][2][1]*wk[3][0]))))-((.0013*(cnk[6][2][1]*wk[6][0]))+(.1326*(
      cnk[6][2][2]*wk[6][0]))));
    vnk[7][1] = ((vnk[6][1]-((.0013*(cnk[6][1][1]*wk[6][0]))+(.1326*(
      cnk[6][1][2]*wk[6][0]))))-(.1378*(cnk[7][1][2]*wk[7][0])));
    vnk[7][2] = ((vnk[6][2]-((.0013*(cnk[6][2][1]*wk[6][0]))+(.1326*(
      cnk[6][2][2]*wk[6][0]))))-(.1378*(cnk[7][2][2]*wk[7][0])));
    vnk[8][0] = (.065*(u[8]*c8));
    vnk[8][1] = ((.065*((cnk[8][1][0]*u[8])-(cnk[7][1][2]*wk[8][0])))+(vnk[7][1]
      -(.1378*(cnk[7][1][2]*wk[7][0]))));
    vnk[8][2] = ((.065*((cnk[8][2][0]*u[8])-(cnk[7][2][2]*wk[8][0])))+(vnk[7][2]
      -(.1378*(cnk[7][2][2]*wk[7][0]))));
    vnk[9][1] = ((vnk[3][1]+((.18915*(cnk[3][1][2]*wk[3][0]))-(.0013*(
      cnk[3][1][1]*wk[3][0]))))-((.0013*(cnk[9][1][1]*wk[9][0]))+(.1326*(
      cnk[9][1][2]*wk[9][0]))));
    vnk[9][2] = ((vnk[3][2]+((.18915*(cnk[3][2][2]*wk[3][0]))-(.0013*(
      cnk[3][2][1]*wk[3][0]))))-((.0013*(cnk[9][2][1]*wk[9][0]))+(.1326*(
      cnk[9][2][2]*wk[9][0]))));
    vnk[10][1] = ((vnk[9][1]-((.0013*(cnk[9][1][1]*wk[9][0]))+(.1326*(
      cnk[9][1][2]*wk[9][0]))))-(.1378*(cnk[10][1][2]*wk[10][0])));
    vnk[10][2] = ((vnk[9][2]-((.0013*(cnk[9][2][1]*wk[9][0]))+(.1326*(
      cnk[9][2][2]*wk[9][0]))))-(.1378*(cnk[10][2][2]*wk[10][0])));
    vnk[11][0] = (.065*(u[11]*c11));
    vnk[11][1] = ((.065*((cnk[11][1][0]*u[11])-(cnk[10][1][2]*wk[11][0])))+(
      vnk[10][1]-(.1378*(cnk[10][1][2]*wk[10][0]))));
    vnk[11][2] = ((.065*((cnk[11][2][0]*u[11])-(cnk[10][2][2]*wk[11][0])))+(
      vnk[10][2]-(.1378*(cnk[10][2][2]*wk[10][0]))));
    vnk[12][1] = ((vnk[2][1]+((.0406*(u[2]*s2))-(.0058*(u[2]*c2))))-((.0143*(
      cnk[12][1][1]*wk[12][0]))+(.2379*(cnk[12][1][2]*wk[12][0]))));
    vnk[12][2] = ((vnk[2][2]-((.0058*(u[2]*s2))+(.0406*(u[2]*c2))))-((.0143*(
      cnk[12][2][1]*wk[12][0]))+(.2379*(cnk[12][2][2]*wk[12][0]))));
    vnk[13][1] = ((vnk[12][1]-((.0143*(cnk[12][1][1]*wk[12][0]))+(.2379*(
      cnk[12][1][2]*wk[12][0]))))+((.0039*(cnk[13][1][1]*wk[13][0]))-(.2158*(
      cnk[13][1][2]*wk[13][0]))));
    vnk[13][2] = ((vnk[12][2]-((.0143*(cnk[12][2][1]*wk[12][0]))+(.2379*(
      cnk[12][2][2]*wk[12][0]))))+((.0039*(cnk[13][2][1]*wk[13][0]))-(.2158*(
      cnk[13][2][2]*wk[13][0]))));
    vnk[14][1] = ((vnk[13][1]+((.0039*(cnk[13][1][1]*wk[13][0]))-(.2158*(
      cnk[13][1][2]*wk[13][0]))))-((.039*(cnk[14][1][1]*wk[14][0]))+(.0442*(
      cnk[14][1][2]*wk[14][0]))));
    vnk[14][2] = ((vnk[13][2]+((.0039*(cnk[13][2][1]*wk[13][0]))-(.2158*(
      cnk[13][2][2]*wk[13][0]))))-((.039*(cnk[14][2][1]*wk[14][0]))+(.0442*(
      cnk[14][2][2]*wk[14][0]))));
    vnk[15][1] = ((vnk[2][1]+((.0406*(u[2]*s2))-(.0058*(u[2]*c2))))-((.0143*(
      cnk[15][1][1]*wk[15][0]))+(.2379*(cnk[15][1][2]*wk[15][0]))));
    vnk[15][2] = ((vnk[2][2]-((.0058*(u[2]*s2))+(.0406*(u[2]*c2))))-((.0143*(
      cnk[15][2][1]*wk[15][0]))+(.2379*(cnk[15][2][2]*wk[15][0]))));
    vnk[16][1] = ((vnk[15][1]-((.0143*(cnk[15][1][1]*wk[15][0]))+(.2379*(
      cnk[15][1][2]*wk[15][0]))))+((.0039*(cnk[16][1][1]*wk[16][0]))-(.2158*(
      cnk[16][1][2]*wk[16][0]))));
    vnk[16][2] = ((vnk[15][2]-((.0143*(cnk[15][2][1]*wk[15][0]))+(.2379*(
      cnk[15][2][2]*wk[15][0]))))+((.0039*(cnk[16][2][1]*wk[16][0]))-(.2158*(
      cnk[16][2][2]*wk[16][0]))));
    vnk[17][1] = ((vnk[16][1]+((.0039*(cnk[16][1][1]*wk[16][0]))-(.2158*(
      cnk[16][1][2]*wk[16][0]))))-((.039*(cnk[17][1][1]*wk[17][0]))+(.0442*(
      cnk[17][1][2]*wk[17][0]))));
    vnk[17][2] = ((vnk[16][2]+((.0039*(cnk[16][2][1]*wk[16][0]))-(.2158*(
      cnk[16][2][2]*wk[16][0]))))-((.039*(cnk[17][2][1]*wk[17][0]))+(.0442*(
      cnk[17][2][2]*wk[17][0]))));
    vnb[0][0] = 0.;
    vnb[0][1] = vnk[2][1];
    vnb[0][2] = vnk[2][2];
    vnb[1][0] = 0.;
    vnb[1][1] = vnk[3][1];
    vnb[1][2] = vnk[3][2];
    vnb[2][0] = 0.;
    vnb[2][1] = vnk[4][1];
    vnb[2][2] = vnk[4][2];
    vnb[3][0] = 0.;
    vnb[3][1] = vnk[5][1];
    vnb[3][2] = vnk[5][2];
    vnb[4][0] = 0.;
    vnb[4][1] = vnk[6][1];
    vnb[4][2] = vnk[6][2];
    vnb[5][0] = 0.;
    vnb[5][1] = vnk[7][1];
    vnb[5][2] = vnk[7][2];
    vnb[6][0] = vnk[8][0];
    vnb[6][1] = vnk[8][1];
    vnb[6][2] = vnk[8][2];
    vnb[7][0] = 0.;
    vnb[7][1] = vnk[9][1];
    vnb[7][2] = vnk[9][2];
    vnb[8][0] = 0.;
    vnb[8][1] = vnk[10][1];
    vnb[8][2] = vnk[10][2];
    vnb[9][0] = vnk[11][0];
    vnb[9][1] = vnk[11][1];
    vnb[9][2] = vnk[11][2];
    vnb[10][0] = 0.;
    vnb[10][1] = vnk[12][1];
    vnb[10][2] = vnk[12][2];
    vnb[11][0] = 0.;
    vnb[11][1] = vnk[13][1];
    vnb[11][2] = vnk[13][2];
    vnb[12][0] = 0.;
    vnb[12][1] = vnk[14][1];
    vnb[12][2] = vnk[14][2];
    vnb[13][0] = 0.;
    vnb[13][1] = vnk[15][1];
    vnb[13][2] = vnk[15][2];
    vnb[14][0] = 0.;
    vnb[14][1] = vnk[16][1];
    vnb[14][2] = vnk[16][2];
    vnb[15][0] = 0.;
    vnb[15][1] = vnk[17][1];
    vnb[15][2] = vnk[17][2];
/*
Compute qdot (kinematical equations)
*/
    qdot[0] = u[0];
    qdot[1] = u[1];
    qdot[2] = u[2];
    qdot[3] = u[3];
    qdot[4] = u[4];
    qdot[5] = u[5];
    qdot[6] = u[6];
    qdot[7] = u[7];
    qdot[8] = u[8];
    qdot[9] = u[9];
    qdot[10] = u[10];
    qdot[11] = u[11];
    qdot[12] = u[12];
    qdot[13] = u[13];
    qdot[14] = u[14];
    qdot[15] = u[15];
    qdot[16] = u[16];
    qdot[17] = u[17];
    skipus: ;
/*
Initialize applied forces and torques to zero
*/
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 3; j++) {
            ufk[i][j] = 0.;
            utk[i][j] = 0.;
        }
    }
    for (i = 0; i < 18; i++) {
        utau[i] = 0.;
    }
    ltauflg = 0;
    fs0flg = 0;
/*
 Used 0.71 seconds CPU time,
 65536 additional bytes of memory.
 Equations contain  447 adds/subtracts/negates
                    641 multiplies
                      0 divides
                    701 assignments
*/
}

void robotqdot(double *oqdot)
{
/*
Return position coordinate derivatives for tree joints.
*/
    int i;

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(63,23);
        return;
    }
    for (i = 0; i <= 17; i++) {
        oqdot[i] = qdot[i];
    }
}

void robotu2qdot(double *uin, double *oqdot)
{
/*
Convert velocities to qdots.
*/
    int i;

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(64,23);
        return;
    }
    for (i = 0; i <= 17; i++) {
        oqdot[i] = uin[i];
    }
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     18 assignments
*/
}

void robotpsstate(double *lqin)
{

    if (roustate != 2) {
        robotseterr(9,23);
        return;
    }
}

void robotdoping(void)
{

    if (vpkflg == 0) {
/*
Compute ping (jt pins in ground frame)
*/
        ping[0][1] = 1.;
        ping[1][2] = 1.;
        ping[2][0] = 1.;
        ping[3][0] = 1.;
        ping[4][0] = 1.;
        ping[5][0] = 1.;
        ping[6][0] = 1.;
        ping[7][0] = 1.;
        ping[8][1] = cnk[7][1][2];
        ping[8][2] = cnk[7][2][2];
        ping[9][0] = 1.;
        ping[10][0] = 1.;
        ping[11][1] = cnk[10][1][2];
        ping[11][2] = cnk[10][2][2];
        ping[12][0] = 1.;
        ping[13][0] = 1.;
        ping[14][0] = 1.;
        ping[15][0] = 1.;
        ping[16][0] = 1.;
        ping[17][0] = 1.;
/*
Compute hngpt (hinge pts in ground frame)
*/
        hngpt[0][1] = rnk[0][1];
        hngpt[0][2] = .0052;
        hngpt[1][1] = rnk[0][1];
        hngpt[1][2] = rnk[1][2];
        hngpt[2][1] = (rnk[2][1]+((.1206*c2)-(.05*s2)));
        hngpt[2][2] = (rnk[2][2]+((.05*c2)+(.1206*s2)));
        hngpt[3][1] = (rnk[3][1]+((.0351*cnk[3][1][2])-(.14625*cnk[3][1][1])));
        hngpt[3][2] = (rnk[3][2]+((.0351*cnk[3][2][2])-(.14625*cnk[3][2][1])));
        hngpt[4][1] = (rnk[4][1]-((.0065*cnk[4][1][2])+(.0442*cnk[4][1][1])));
        hngpt[4][2] = (rnk[4][2]-((.0065*cnk[4][2][2])+(.0442*cnk[4][2][1])));
        hngpt[5][1] = (rnk[5][1]-((.0312*cnk[5][1][2])+(.078*cnk[5][1][1])));
        hngpt[5][2] = (rnk[5][2]-((.0312*cnk[5][2][2])+(.078*cnk[5][2][1])));
        hngpt[6][0] = .1768;
        hngpt[6][1] = (rnk[6][1]+((.1326*cnk[6][1][1])-(.0013*cnk[6][1][2])));
        hngpt[6][2] = (rnk[6][2]+((.1326*cnk[6][2][1])-(.0013*cnk[6][2][2])));
        hngpt[7][0] = .1768;
        hngpt[7][1] = (rnk[7][1]+(.1378*cnk[7][1][1]));
        hngpt[7][2] = (rnk[7][2]+(.1378*cnk[7][2][1]));
        hngpt[8][0] = (rnk[8][0]-(.065*s8));
        hngpt[8][1] = (rnk[8][1]+(.065*cnk[8][1][1]));
        hngpt[8][2] = (rnk[8][2]+(.065*cnk[8][2][1]));
        hngpt[9][0] = -.1768;
        hngpt[9][1] = (rnk[9][1]+((.1326*cnk[9][1][1])-(.0013*cnk[9][1][2])));
        hngpt[9][2] = (rnk[9][2]+((.1326*cnk[9][2][1])-(.0013*cnk[9][2][2])));
        hngpt[10][0] = -.1768;
        hngpt[10][1] = (rnk[10][1]+(.1378*cnk[10][1][1]));
        hngpt[10][2] = (rnk[10][2]+(.1378*cnk[10][2][1]));
        hngpt[11][0] = (rnk[11][0]-(.065*s11));
        hngpt[11][1] = (rnk[11][1]+(.065*cnk[11][1][1]));
        hngpt[11][2] = (rnk[11][2]+(.065*cnk[11][2][1]));
        hngpt[12][0] = .1118;
        hngpt[12][1] = (rnk[12][1]+((.2379*cnk[12][1][1])-(.0143*cnk[12][1][2]))
          );
        hngpt[12][2] = (rnk[12][2]+((.2379*cnk[12][2][1])-(.0143*cnk[12][2][2]))
          );
        hngpt[13][0] = .078;
        hngpt[13][1] = (rnk[13][1]+((.0039*cnk[13][1][2])+(.2158*cnk[13][1][1]))
          );
        hngpt[13][2] = (rnk[13][2]+((.0039*cnk[13][2][2])+(.2158*cnk[13][2][1]))
          );
        hngpt[14][0] = .0624;
        hngpt[14][1] = (rnk[14][1]+((.0442*cnk[14][1][1])-(.039*cnk[14][1][2])))
          ;
        hngpt[14][2] = (rnk[14][2]+((.0442*cnk[14][2][1])-(.039*cnk[14][2][2])))
          ;
        hngpt[15][0] = -.1118;
        hngpt[15][1] = (rnk[15][1]+((.2379*cnk[15][1][1])-(.0143*cnk[15][1][2]))
          );
        hngpt[15][2] = (rnk[15][2]+((.2379*cnk[15][2][1])-(.0143*cnk[15][2][2]))
          );
        hngpt[16][0] = -.078;
        hngpt[16][1] = (rnk[16][1]+((.0039*cnk[16][1][2])+(.2158*cnk[16][1][1]))
          );
        hngpt[16][2] = (rnk[16][2]+((.0039*cnk[16][2][2])+(.2158*cnk[16][2][1]))
          );
        hngpt[17][0] = -.0624;
        hngpt[17][1] = (rnk[17][1]+((.0442*cnk[17][1][1])-(.039*cnk[17][1][2])))
          ;
        hngpt[17][2] = (rnk[17][2]+((.0442*cnk[17][2][1])-(.039*cnk[17][2][2])))
          ;
        vpkflg = 1;
    }
/*
 Used 0.06 seconds CPU time,
 0 additional bytes of memory.
 Equations contain   58 adds/subtracts/negates
                     58 multiplies
                      0 divides
                     68 assignments
*/
}

void robotdoltau(void)
{

/*
Compute effect of loop hinge torques
*/
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                      0 assignments
*/
}

void robotdoiner(void)
{

/*
Compute inertial accelerations and related temps
*/
    if (inerflg == 0) {
/*
Compute Otk (inertial angular acceleration)
*/
        Otk[8][0] = (u[8]*wk[8][1]);
        Otk[8][1] = -(u[8]*wk[8][0]);
        Otk[11][0] = (u[11]*wk[11][1]);
        Otk[11][1] = -(u[11]*wk[11][0]);
/*
Compute Atk (inertial linear acceleration)
*/
        Atk[2][1] = (.1206*(u[2]*u[2]));
        Atk[2][2] = (.05*(u[2]*u[2]));
        AiOiWi[3][1] = (Atk[2][1]-(.1206*(u[2]*u[2])));
        AiOiWi[3][2] = (Atk[2][2]-(.05*(u[2]*u[2])));
        Atk[3][1] = (((AiOiWi[3][1]*c3)+(AiOiWi[3][2]*s3))-(.14625*(wk[3][0]*
          wk[3][0])));
        Atk[3][2] = ((.0351*(wk[3][0]*wk[3][0]))+((AiOiWi[3][2]*c3)-(
          AiOiWi[3][1]*s3)));
        AiOiWi[4][1] = (Atk[3][1]-(.24635*(wk[3][0]*wk[3][0])));
        AiOiWi[4][2] = (Atk[3][2]+(.0013*(wk[3][0]*wk[3][0])));
        Atk[4][1] = (((AiOiWi[4][1]*c4)+(AiOiWi[4][2]*s4))-(.0442*(wk[4][0]*
          wk[4][0])));
        Atk[4][2] = (((AiOiWi[4][2]*c4)-(AiOiWi[4][1]*s4))-(.0065*(wk[4][0]*
          wk[4][0])));
        AiOiWi[5][1] = (Atk[4][1]-(.0442*(wk[4][0]*wk[4][0])));
        AiOiWi[5][2] = (Atk[4][2]-(.0065*(wk[4][0]*wk[4][0])));
        Atk[5][1] = (((AiOiWi[5][1]*c5)+(AiOiWi[5][2]*s5))-(.078*(wk[5][0]*
          wk[5][0])));
        Atk[5][2] = (((AiOiWi[5][2]*c5)-(AiOiWi[5][1]*s5))-(.0312*(wk[5][0]*
          wk[5][0])));
        AiOiWi[6][1] = (Atk[3][1]-(.18915*(wk[3][0]*wk[3][0])));
        AiOiWi[6][2] = (Atk[3][2]-(.0013*(wk[3][0]*wk[3][0])));
        Atk[6][1] = ((.1326*(wk[6][0]*wk[6][0]))+((AiOiWi[6][1]*c6)+(
          AiOiWi[6][2]*s6)));
        Atk[6][2] = (((AiOiWi[6][2]*c6)-(AiOiWi[6][1]*s6))-(.0013*(wk[6][0]*
          wk[6][0])));
        AiOiWi[7][1] = (Atk[6][1]+(.1326*(wk[6][0]*wk[6][0])));
        AiOiWi[7][2] = (Atk[6][2]-(.0013*(wk[6][0]*wk[6][0])));
        Atk[7][1] = ((.1378*(wk[7][0]*wk[7][0]))+((AiOiWi[7][1]*c7)+(
          AiOiWi[7][2]*s7)));
        Atk[7][2] = ((AiOiWi[7][2]*c7)-(AiOiWi[7][1]*s7));
        AiOiWi[8][1] = (Atk[7][1]+(.1378*(wk[7][0]*wk[7][0])));
        Atk[8][0] = ((AiOiWi[8][1]*s8)-(.065*(wk[8][0]*wk[8][1])));
        Atk[8][1] = ((.065*((u[8]*u[8])+(wk[8][0]*wk[8][0])))+(AiOiWi[8][1]*c8))
          ;
        Atk[8][2] = (Atk[7][2]-(.065*(Otk[8][0]+(u[8]*wk[8][1]))));
        AiOiWi[9][1] = (Atk[3][1]-(.18915*(wk[3][0]*wk[3][0])));
        AiOiWi[9][2] = (Atk[3][2]-(.0013*(wk[3][0]*wk[3][0])));
        Atk[9][1] = ((.1326*(wk[9][0]*wk[9][0]))+((AiOiWi[9][1]*c9)+(
          AiOiWi[9][2]*s9)));
        Atk[9][2] = (((AiOiWi[9][2]*c9)-(AiOiWi[9][1]*s9))-(.0013*(wk[9][0]*
          wk[9][0])));
        AiOiWi[10][1] = (Atk[9][1]+(.1326*(wk[9][0]*wk[9][0])));
        AiOiWi[10][2] = (Atk[9][2]-(.0013*(wk[9][0]*wk[9][0])));
        Atk[10][1] = ((.1378*(wk[10][0]*wk[10][0]))+((AiOiWi[10][1]*c10)+(
          AiOiWi[10][2]*s10)));
        Atk[10][2] = ((AiOiWi[10][2]*c10)-(AiOiWi[10][1]*s10));
        AiOiWi[11][1] = (Atk[10][1]+(.1378*(wk[10][0]*wk[10][0])));
        Atk[11][0] = ((AiOiWi[11][1]*s11)-(.065*(wk[11][0]*wk[11][1])));
        Atk[11][1] = ((.065*((u[11]*u[11])+(wk[11][0]*wk[11][0])))+(
          AiOiWi[11][1]*c11));
        Atk[11][2] = (Atk[10][2]-(.065*(Otk[11][0]+(u[11]*wk[11][1]))));
        AiOiWi[12][1] = (Atk[2][1]+(.0406*(u[2]*u[2])));
        AiOiWi[12][2] = (Atk[2][2]-(.0058*(u[2]*u[2])));
        Atk[12][1] = ((.2379*(wk[12][0]*wk[12][0]))+((AiOiWi[12][1]*c12)+(
          AiOiWi[12][2]*s12)));
        Atk[12][2] = (((AiOiWi[12][2]*c12)-(AiOiWi[12][1]*s12))-(.0143*(
          wk[12][0]*wk[12][0])));
        AiOiWi[13][1] = (Atk[12][1]+(.2379*(wk[12][0]*wk[12][0])));
        AiOiWi[13][2] = (Atk[12][2]-(.0143*(wk[12][0]*wk[12][0])));
        Atk[13][1] = ((.2158*(wk[13][0]*wk[13][0]))+((AiOiWi[13][1]*c13)+(
          AiOiWi[13][2]*s13)));
        Atk[13][2] = ((.0039*(wk[13][0]*wk[13][0]))+((AiOiWi[13][2]*c13)-(
          AiOiWi[13][1]*s13)));
        AiOiWi[14][1] = (Atk[13][1]+(.2158*(wk[13][0]*wk[13][0])));
        AiOiWi[14][2] = (Atk[13][2]+(.0039*(wk[13][0]*wk[13][0])));
        Atk[14][1] = ((.0442*(wk[14][0]*wk[14][0]))+((AiOiWi[14][1]*c14)+(
          AiOiWi[14][2]*s14)));
        Atk[14][2] = (((AiOiWi[14][2]*c14)-(AiOiWi[14][1]*s14))-(.039*(wk[14][0]
          *wk[14][0])));
        AiOiWi[15][1] = (Atk[2][1]+(.0406*(u[2]*u[2])));
        AiOiWi[15][2] = (Atk[2][2]-(.0058*(u[2]*u[2])));
        Atk[15][1] = ((.2379*(wk[15][0]*wk[15][0]))+((AiOiWi[15][1]*c15)+(
          AiOiWi[15][2]*s15)));
        Atk[15][2] = (((AiOiWi[15][2]*c15)-(AiOiWi[15][1]*s15))-(.0143*(
          wk[15][0]*wk[15][0])));
        AiOiWi[16][1] = (Atk[15][1]+(.2379*(wk[15][0]*wk[15][0])));
        AiOiWi[16][2] = (Atk[15][2]-(.0143*(wk[15][0]*wk[15][0])));
        Atk[16][1] = ((.2158*(wk[16][0]*wk[16][0]))+((AiOiWi[16][1]*c16)+(
          AiOiWi[16][2]*s16)));
        Atk[16][2] = ((.0039*(wk[16][0]*wk[16][0]))+((AiOiWi[16][2]*c16)-(
          AiOiWi[16][1]*s16)));
        AiOiWi[17][1] = (Atk[16][1]+(.2158*(wk[16][0]*wk[16][0])));
        AiOiWi[17][2] = (Atk[16][2]+(.0039*(wk[16][0]*wk[16][0])));
        Atk[17][1] = ((.0442*(wk[17][0]*wk[17][0]))+((AiOiWi[17][1]*c17)+(
          AiOiWi[17][2]*s17)));
        Atk[17][2] = (((AiOiWi[17][2]*c17)-(AiOiWi[17][1]*s17))-(.039*(wk[17][0]
          *wk[17][0])));
        inerflg = 1;
    }
/*
 Used 0.14 seconds CPU time,
 8192 additional bytes of memory.
 Equations contain   90 adds/subtracts/negates
                    182 multiplies
                      0 divides
                     66 assignments
*/
}

void robotdofs0(void)
{

/*
Compute effect of all applied loads
*/
    if (fs0flg == 0) {
        robotdoltau();
        robotdoiner();
/*
Compute Fstar (forces)
*/
        Fstar[2][1] = ((16.61*Atk[2][1])-ufk[0][1]);
        Fstar[2][2] = ((16.61*Atk[2][2])-ufk[0][2]);
        Fstar[3][1] = ((29.27*Atk[3][1])-ufk[1][1]);
        Fstar[3][2] = ((29.27*Atk[3][2])-ufk[1][2]);
        Fstar[4][1] = (Atk[4][1]-ufk[2][1]);
        Fstar[4][2] = (Atk[4][2]-ufk[2][2]);
        Fstar[5][1] = ((5.89*Atk[5][1])-ufk[3][1]);
        Fstar[5][2] = ((5.89*Atk[5][2])-ufk[3][2]);
        Fstar[6][1] = ((2.79*Atk[6][1])-ufk[4][1]);
        Fstar[6][2] = ((2.79*Atk[6][2])-ufk[4][2]);
        Fstar[7][1] = ((1.21*Atk[7][1])-ufk[5][1]);
        Fstar[7][2] = ((1.21*Atk[7][2])-ufk[5][2]);
        Fstar[8][0] = ((.55*Atk[8][0])-ufk[6][0]);
        Fstar[8][1] = ((.55*Atk[8][1])-ufk[6][1]);
        Fstar[8][2] = ((.55*Atk[8][2])-ufk[6][2]);
        Fstar[9][1] = ((2.79*Atk[9][1])-ufk[7][1]);
        Fstar[9][2] = ((2.79*Atk[9][2])-ufk[7][2]);
        Fstar[10][1] = ((1.21*Atk[10][1])-ufk[8][1]);
        Fstar[10][2] = ((1.21*Atk[10][2])-ufk[8][2]);
        Fstar[11][0] = ((.55*Atk[11][0])-ufk[9][0]);
        Fstar[11][1] = ((.55*Atk[11][1])-ufk[9][1]);
        Fstar[11][2] = ((.55*Atk[11][2])-ufk[9][2]);
        Fstar[12][1] = ((8.35*Atk[12][1])-ufk[10][1]);
        Fstar[12][2] = ((8.35*Atk[12][2])-ufk[10][2]);
        Fstar[13][1] = ((4.16*Atk[13][1])-ufk[11][1]);
        Fstar[13][2] = ((4.16*Atk[13][2])-ufk[11][2]);
        Fstar[14][1] = ((1.34*Atk[14][1])-ufk[12][1]);
        Fstar[14][2] = ((1.34*Atk[14][2])-ufk[12][2]);
        Fstar[15][1] = ((8.35*Atk[15][1])-ufk[13][1]);
        Fstar[15][2] = ((8.35*Atk[15][2])-ufk[13][2]);
        Fstar[16][1] = ((4.16*Atk[16][1])-ufk[14][1]);
        Fstar[16][2] = ((4.16*Atk[16][2])-ufk[14][2]);
        Fstar[17][1] = ((1.34*Atk[17][1])-ufk[15][1]);
        Fstar[17][2] = ((1.34*Atk[17][2])-ufk[15][2]);
/*
Compute Tstar (torques)
*/
        Tstar[8][0] = ((WkIkWk[8][0]+(.0005*Otk[8][0]))-utk[6][0]);
        Tstar[8][1] = ((WkIkWk[8][1]+(.002*Otk[8][1]))-utk[6][1]);
        Tstar[8][2] = (WkIkWk[8][2]-utk[6][2]);
        Tstar[11][0] = ((WkIkWk[11][0]+(.0005*Otk[11][0]))-utk[9][0]);
        Tstar[11][1] = ((WkIkWk[11][1]+(.002*Otk[11][1]))-utk[9][1]);
        Tstar[11][2] = (WkIkWk[11][2]-utk[9][2]);
/*
Compute fs0 (RHS ignoring constraints)
*/
        fs0[17] = (utau[17]+(utk[15][0]+((.039*Fstar[17][1])+(.0442*Fstar[17][2]
          ))));
        Fstark[16][0] = -(ufk[14][0]+ufk[15][0]);
        Fstark[16][1] = (Fstar[16][1]+((Fstar[17][1]*c17)-(Fstar[17][2]*s17)));
        Fstark[16][2] = (Fstar[16][2]+((Fstar[17][1]*s17)+(Fstar[17][2]*c17)));
        tvec1[0] = (((Fstar[17][2]*rik[17][1])-(Fstar[17][1]*rik[17][2]))-
          utk[15][0]);
        tvec1[1] = -(utk[15][1]+((.0078*Fstar[17][2])+(rik[17][2]*ufk[15][0])));
        tvec1[2] = (((.0078*Fstar[17][1])+(rik[17][1]*ufk[15][0]))-utk[15][2]);
        Tstark[16][0] = (tvec1[0]-utk[14][0]);
        Tstark[16][1] = (((tvec1[1]*c17)-(tvec1[2]*s17))-utk[14][1]);
        Tstark[16][2] = (((tvec1[1]*s17)+(tvec1[2]*c17))-utk[14][2]);
        fs0[16] = (utau[16]-(Tstark[16][0]+((.0039*Fstark[16][1])-(.2158*
          Fstark[16][2]))));
        Fstark[15][0] = (Fstark[16][0]-ufk[13][0]);
        Fstark[15][1] = (Fstar[15][1]+((Fstark[16][1]*c16)-(Fstark[16][2]*s16)))
          ;
        Fstark[15][2] = (Fstar[15][2]+((Fstark[16][1]*s16)+(Fstark[16][2]*c16)))
          ;
        tvec1[0] = (Tstark[16][0]+((Fstark[16][2]*rik[16][1])-(Fstark[16][1]*
          rik[16][2])));
        tvec1[1] = (Tstark[16][1]+((Fstark[16][0]*rik[16][2])-(.0247*
          Fstark[16][2])));
        tvec1[2] = (Tstark[16][2]+((.0247*Fstark[16][1])-(Fstark[16][0]*
          rik[16][1])));
        Tstark[15][0] = (tvec1[0]-utk[13][0]);
        Tstark[15][1] = (((tvec1[1]*c16)-(tvec1[2]*s16))-utk[13][1]);
        Tstark[15][2] = (((tvec1[1]*s16)+(tvec1[2]*c16))-utk[13][2]);
        fs0[15] = (utau[15]-(Tstark[15][0]-((.0143*Fstark[15][1])+(.2379*
          Fstark[15][2]))));
        Fstark[2][0] = (Fstark[15][0]-ufk[0][0]);
        Fstark[2][1] = (Fstar[2][1]+((Fstark[15][1]*c15)-(Fstark[15][2]*s15)));
        Fstark[2][2] = (Fstar[2][2]+((Fstark[15][1]*s15)+(Fstark[15][2]*c15)));
        tvec1[0] = (Tstark[15][0]+((Fstark[15][2]*rik[15][1])-(Fstark[15][1]*
          rik[15][2])));
        tvec1[1] = (Tstark[15][1]+((.0949*Fstark[15][2])+(Fstark[15][0]*
          rik[15][2])));
        tvec1[2] = (Tstark[15][2]-((.0949*Fstark[15][1])+(Fstark[15][0]*
          rik[15][1])));
        Tstark[2][0] = (tvec1[0]-utk[0][0]);
        Tstark[2][1] = (((tvec1[1]*c15)-(tvec1[2]*s15))-utk[0][1]);
        Tstark[2][2] = (((tvec1[1]*s15)+(tvec1[2]*c15))-utk[0][2]);
        fs0[14] = (utau[14]+(utk[12][0]+((.039*Fstar[14][1])+(.0442*Fstar[14][2]
          ))));
        Fstark[13][0] = -(ufk[11][0]+ufk[12][0]);
        Fstark[13][1] = (Fstar[13][1]+((Fstar[14][1]*c14)-(Fstar[14][2]*s14)));
        Fstark[13][2] = (Fstar[13][2]+((Fstar[14][1]*s14)+(Fstar[14][2]*c14)));
        tvec1[0] = (((Fstar[14][2]*rik[14][1])-(Fstar[14][1]*rik[14][2]))-
          utk[12][0]);
        tvec1[1] = (((.0078*Fstar[14][2])-(rik[14][2]*ufk[12][0]))-utk[12][1]);
        tvec1[2] = (((rik[14][1]*ufk[12][0])-(.0078*Fstar[14][1]))-utk[12][2]);
        Tstark[13][0] = (tvec1[0]-utk[11][0]);
        Tstark[13][1] = (((tvec1[1]*c14)-(tvec1[2]*s14))-utk[11][1]);
        Tstark[13][2] = (((tvec1[1]*s14)+(tvec1[2]*c14))-utk[11][2]);
        fs0[13] = (utau[13]-(Tstark[13][0]+((.0039*Fstark[13][1])-(.2158*
          Fstark[13][2]))));
        Fstark[12][0] = (Fstark[13][0]-ufk[10][0]);
        Fstark[12][1] = (Fstar[12][1]+((Fstark[13][1]*c13)-(Fstark[13][2]*s13)))
          ;
        Fstark[12][2] = (Fstar[12][2]+((Fstark[13][1]*s13)+(Fstark[13][2]*c13)))
          ;
        tvec1[0] = (Tstark[13][0]+((Fstark[13][2]*rik[13][1])-(Fstark[13][1]*
          rik[13][2])));
        tvec1[1] = (Tstark[13][1]+((.0247*Fstark[13][2])+(Fstark[13][0]*
          rik[13][2])));
        tvec1[2] = (Tstark[13][2]-((.0247*Fstark[13][1])+(Fstark[13][0]*
          rik[13][1])));
        Tstark[12][0] = (tvec1[0]-utk[10][0]);
        Tstark[12][1] = (((tvec1[1]*c13)-(tvec1[2]*s13))-utk[10][1]);
        Tstark[12][2] = (((tvec1[1]*s13)+(tvec1[2]*c13))-utk[10][2]);
        fs0[12] = (utau[12]-(Tstark[12][0]-((.0143*Fstark[12][1])+(.2379*
          Fstark[12][2]))));
        Fstark[2][0] = (Fstark[2][0]+Fstark[12][0]);
        Fstark[2][1] = (Fstark[2][1]+((Fstark[12][1]*c12)-(Fstark[12][2]*s12)));
        Fstark[2][2] = (Fstark[2][2]+((Fstark[12][1]*s12)+(Fstark[12][2]*c12)));
        tvec1[0] = (Tstark[12][0]+((Fstark[12][2]*rik[12][1])-(Fstark[12][1]*
          rik[12][2])));
        tvec1[1] = (Tstark[12][1]+((Fstark[12][0]*rik[12][2])-(.0949*
          Fstark[12][2])));
        tvec1[2] = (Tstark[12][2]+((.0949*Fstark[12][1])-(Fstark[12][0]*
          rik[12][1])));
        Tstark[2][0] = (Tstark[2][0]+tvec1[0]);
        Tstark[2][1] = (Tstark[2][1]+((tvec1[1]*c12)-(tvec1[2]*s12)));
        Tstark[2][2] = (Tstark[2][2]+((tvec1[1]*s12)+(tvec1[2]*c12)));
        fs0[11] = (utau[11]-(Tstar[11][2]+(.065*Fstar[11][0])));
        Fstark[10][0] = (((Fstar[11][0]*c11)-(Fstar[11][1]*s11))-ufk[8][0]);
        Fstark[10][1] = (Fstar[10][1]+((Fstar[11][0]*s11)+(Fstar[11][1]*c11)));
        Fstark[10][2] = (Fstar[10][2]+Fstar[11][2]);
        tvec1[0] = (Tstar[11][0]+(Fstar[11][2]*rik[11][1]));
        tvec1[1] = (Tstar[11][1]-(Fstar[11][2]*rik[11][0]));
        tvec1[2] = (Tstar[11][2]+((Fstar[11][1]*rik[11][0])-(Fstar[11][0]*
          rik[11][1])));
        Tstark[10][0] = (((tvec1[0]*c11)-(tvec1[1]*s11))-utk[8][0]);
        Tstark[10][1] = (((tvec1[0]*s11)+(tvec1[1]*c11))-utk[8][1]);
        Tstark[10][2] = (tvec1[2]-utk[8][2]);
        fs0[10] = (utau[10]-(Tstark[10][0]-(.1378*Fstark[10][2])));
        Fstark[9][0] = (Fstark[10][0]-ufk[7][0]);
        Fstark[9][1] = (Fstar[9][1]+((Fstark[10][1]*c10)-(Fstark[10][2]*s10)));
        Fstark[9][2] = (Fstar[9][2]+((Fstark[10][1]*s10)+(Fstark[10][2]*c10)));
        tvec1[0] = (Tstark[10][0]+((Fstark[10][2]*rik[10][1])-(Fstark[10][1]*
          rik[10][2])));
        tvec1[1] = (Tstark[10][1]+((Fstark[10][0]*rik[10][2])-(.0039*
          Fstark[10][2])));
        tvec1[2] = (Tstark[10][2]+((.0039*Fstark[10][1])-(Fstark[10][0]*
          rik[10][1])));
        Tstark[9][0] = (tvec1[0]-utk[7][0]);
        Tstark[9][1] = (((tvec1[1]*c10)-(tvec1[2]*s10))-utk[7][1]);
        Tstark[9][2] = (((tvec1[1]*s10)+(tvec1[2]*c10))-utk[7][2]);
        fs0[9] = (utau[9]-(Tstark[9][0]-((.0013*Fstark[9][1])+(.1326*
          Fstark[9][2]))));
        Fstark[3][0] = (Fstark[9][0]-ufk[1][0]);
        Fstark[3][1] = (Fstar[3][1]+((Fstark[9][1]*c9)-(Fstark[9][2]*s9)));
        Fstark[3][2] = (Fstar[3][2]+((Fstark[9][1]*s9)+(Fstark[9][2]*c9)));
        tvec1[0] = (Tstark[9][0]+((Fstark[9][2]*rik[9][1])-(Fstark[9][1]*
          rik[9][2])));
        tvec1[1] = (Tstark[9][1]+((.1768*Fstark[9][2])+(Fstark[9][0]*rik[9][2]))
          );
        tvec1[2] = (Tstark[9][2]-((.1768*Fstark[9][1])+(Fstark[9][0]*rik[9][1]))
          );
        Tstark[3][0] = (tvec1[0]-utk[1][0]);
        Tstark[3][1] = (((tvec1[1]*c9)-(tvec1[2]*s9))-utk[1][1]);
        Tstark[3][2] = (((tvec1[1]*s9)+(tvec1[2]*c9))-utk[1][2]);
        fs0[8] = (utau[8]-(Tstar[8][2]+(.065*Fstar[8][0])));
        Fstark[7][0] = (((Fstar[8][0]*c8)-(Fstar[8][1]*s8))-ufk[5][0]);
        Fstark[7][1] = (Fstar[7][1]+((Fstar[8][0]*s8)+(Fstar[8][1]*c8)));
        Fstark[7][2] = (Fstar[7][2]+Fstar[8][2]);
        tvec1[0] = (Tstar[8][0]+(Fstar[8][2]*rik[8][1]));
        tvec1[1] = (Tstar[8][1]-(Fstar[8][2]*rik[8][0]));
        tvec1[2] = (Tstar[8][2]+((Fstar[8][1]*rik[8][0])-(Fstar[8][0]*rik[8][1])
          ));
        Tstark[7][0] = (((tvec1[0]*c8)-(tvec1[1]*s8))-utk[5][0]);
        Tstark[7][1] = (((tvec1[0]*s8)+(tvec1[1]*c8))-utk[5][1]);
        Tstark[7][2] = (tvec1[2]-utk[5][2]);
        fs0[7] = (utau[7]-(Tstark[7][0]-(.1378*Fstark[7][2])));
        Fstark[6][0] = (Fstark[7][0]-ufk[4][0]);
        Fstark[6][1] = (Fstar[6][1]+((Fstark[7][1]*c7)-(Fstark[7][2]*s7)));
        Fstark[6][2] = (Fstar[6][2]+((Fstark[7][1]*s7)+(Fstark[7][2]*c7)));
        tvec1[0] = (Tstark[7][0]+((Fstark[7][2]*rik[7][1])-(Fstark[7][1]*
          rik[7][2])));
        tvec1[1] = (Tstark[7][1]+((.0039*Fstark[7][2])+(Fstark[7][0]*rik[7][2]))
          );
        tvec1[2] = (Tstark[7][2]-((.0039*Fstark[7][1])+(Fstark[7][0]*rik[7][1]))
          );
        Tstark[6][0] = (tvec1[0]-utk[4][0]);
        Tstark[6][1] = (((tvec1[1]*c7)-(tvec1[2]*s7))-utk[4][1]);
        Tstark[6][2] = (((tvec1[1]*s7)+(tvec1[2]*c7))-utk[4][2]);
        fs0[6] = (utau[6]-(Tstark[6][0]-((.0013*Fstark[6][1])+(.1326*
          Fstark[6][2]))));
        Fstark[3][0] = (Fstark[3][0]+Fstark[6][0]);
        Fstark[3][1] = (Fstark[3][1]+((Fstark[6][1]*c6)-(Fstark[6][2]*s6)));
        Fstark[3][2] = (Fstark[3][2]+((Fstark[6][1]*s6)+(Fstark[6][2]*c6)));
        tvec1[0] = (Tstark[6][0]+((Fstark[6][2]*rik[6][1])-(Fstark[6][1]*
          rik[6][2])));
        tvec1[1] = (Tstark[6][1]+((Fstark[6][0]*rik[6][2])-(.1768*Fstark[6][2]))
          );
        tvec1[2] = (Tstark[6][2]+((.1768*Fstark[6][1])-(Fstark[6][0]*rik[6][1]))
          );
        Tstark[3][0] = (Tstark[3][0]+tvec1[0]);
        Tstark[3][1] = (Tstark[3][1]+((tvec1[1]*c6)-(tvec1[2]*s6)));
        Tstark[3][2] = (Tstark[3][2]+((tvec1[1]*s6)+(tvec1[2]*c6)));
        fs0[5] = (utau[5]-(((.078*Fstar[5][2])-(.0312*Fstar[5][1]))-utk[3][0]));
        Fstark[4][0] = -(ufk[2][0]+ufk[3][0]);
        Fstark[4][1] = (Fstar[4][1]+((Fstar[5][1]*c5)-(Fstar[5][2]*s5)));
        Fstark[4][2] = (Fstar[4][2]+((Fstar[5][1]*s5)+(Fstar[5][2]*c5)));
        tvec1[0] = (((Fstar[5][2]*rik[5][1])-(Fstar[5][1]*rik[5][2]))-utk[3][0])
          ;
        tvec1[1] = -(utk[3][1]+(rik[5][2]*ufk[3][0]));
        tvec1[2] = ((rik[5][1]*ufk[3][0])-utk[3][2]);
        Tstark[4][0] = (tvec1[0]-utk[2][0]);
        Tstark[4][1] = (((tvec1[1]*c5)-(tvec1[2]*s5))-utk[2][1]);
        Tstark[4][2] = (((tvec1[1]*s5)+(tvec1[2]*c5))-utk[2][2]);
        fs0[4] = (utau[4]-(Tstark[4][0]+((.0442*Fstark[4][2])-(.0065*
          Fstark[4][1]))));
        Fstark[3][0] = (Fstark[3][0]+Fstark[4][0]);
        Fstark[3][1] = (Fstark[3][1]+((Fstark[4][1]*c4)-(Fstark[4][2]*s4)));
        Fstark[3][2] = (Fstark[3][2]+((Fstark[4][1]*s4)+(Fstark[4][2]*c4)));
        tvec1[0] = (Tstark[4][0]+((Fstark[4][2]*rik[4][1])-(Fstark[4][1]*
          rik[4][2])));
        tvec1[1] = (Tstark[4][1]+(Fstark[4][0]*rik[4][2]));
        tvec1[2] = (Tstark[4][2]-(Fstark[4][0]*rik[4][1]));
        Tstark[3][0] = (Tstark[3][0]+tvec1[0]);
        Tstark[3][1] = (Tstark[3][1]+((tvec1[1]*c4)-(tvec1[2]*s4)));
        Tstark[3][2] = (Tstark[3][2]+((tvec1[1]*s4)+(tvec1[2]*c4)));
        fs0[3] = (utau[3]-(Tstark[3][0]+((.0351*Fstark[3][1])+(.14625*
          Fstark[3][2]))));
        Fstark[2][0] = (Fstark[2][0]+Fstark[3][0]);
        Fstark[2][1] = (Fstark[2][1]+((Fstark[3][1]*c3)-(Fstark[3][2]*s3)));
        Fstark[2][2] = (Fstark[2][2]+((Fstark[3][1]*s3)+(Fstark[3][2]*c3)));
        tvec1[0] = (Tstark[3][0]+((Fstark[3][2]*rik[3][1])-(Fstark[3][1]*
          rik[3][2])));
        tvec1[1] = (Tstark[3][1]+(Fstark[3][0]*rik[3][2]));
        tvec1[2] = (Tstark[3][2]-(Fstark[3][0]*rik[3][1]));
        Tstark[2][0] = (Tstark[2][0]+tvec1[0]);
        Tstark[2][1] = (Tstark[2][1]+((tvec1[1]*c3)-(tvec1[2]*s3)));
        Tstark[2][2] = (Tstark[2][2]+((tvec1[1]*s3)+(tvec1[2]*c3)));
        fs0[2] = (utau[2]-(Tstark[2][0]+((.05*Fstark[2][1])-(.1206*Fstark[2][2])
          )));
        Fstark[1][0] = Fstark[2][0];
        Fstark[1][1] = ((Fstark[2][1]*c2)-(Fstark[2][2]*s2));
        Fstark[1][2] = ((Fstark[2][1]*s2)+(Fstark[2][2]*c2));
        tvec1[0] = (Tstark[2][0]+((.05*Fstark[2][1])-(.1206*Fstark[2][2])));
        tvec1[1] = (Tstark[2][1]-(.05*Fstark[2][0]));
        tvec1[2] = (Tstark[2][2]+(.1206*Fstark[2][0]));
        Tstark[1][0] = tvec1[0];
        Tstark[1][1] = ((tvec1[1]*c2)-(tvec1[2]*s2));
        Tstark[1][2] = ((tvec1[1]*s2)+(tvec1[2]*c2));
        fs0[1] = (utau[1]-Fstark[1][2]);
        Fstark[0][0] = Fstark[1][0];
        Fstark[0][1] = Fstark[1][1];
        Fstark[0][2] = Fstark[1][2];
        tvec1[0] = (Tstark[1][0]-(Fstark[1][1]*q[1]));
        tvec1[1] = (Tstark[1][1]+(Fstark[1][0]*q[1]));
        Tstark[0][0] = tvec1[0];
        Tstark[0][1] = tvec1[1];
        Tstark[0][2] = Tstark[1][2];
        fs0[0] = (utau[0]-Fstark[0][1]);
        fs0flg = 1;
    }
/*
 Used 0.25 seconds CPU time,
 24576 additional bytes of memory.
 Equations contain  335 adds/subtracts/negates
                    278 multiplies
                      0 divides
                    210 assignments
*/
}

void robotdomm(int routine)
{

    if (mmflg == 0) {
/*
Compute gains (DD, G)
*/
        DD[17] = 82.2637834943576;
        N11[17][1][1] = (c17+(.228298077059165*s17));
        N11[17][2][1] = (s17-(.228298077059165*c17));
        N21[17][0][1] = (rikt[17][0][1]-(.228298077059165*rikt[17][0][2]));
        N21[17][1][0] = (((.039*c17)-(.0442*s17))-.0078);
        N21[17][1][1] = ((.00356145000212298*c17)-(.0156*s17));
        N21[17][2][0] = (.4316+((.039*s17)+(.0442*c17)));
        N21[17][2][1] = ((.00356145000212298*s17)+(.0156*c17));
        P11[16][1][1] = (4.16+((.993291320306148*(s17*s17))+(1.11532875569381*(
          N11[17][1][1]*N11[17][1][1]))));
        P11[16][1][2] = ((1.11532875569381*(N11[17][1][1]*N11[17][2][1]))-(
          .993291320306148*(s17*c17)));
        P11[16][2][1] = P11[16][1][2];
        P11[16][2][2] = (4.16+((.993291320306148*(c17*c17))+(1.11532875569381*(
          N11[17][2][1]*N11[17][2][1]))));
        Pd[16][0][1] = ((1.34*N21[17][1][0])-.016224);
        Pd[16][0][2] = (.897728+(1.34*N21[17][2][0]));
        Pd[16][1][0] = (.016224+((1.11532875569381*(N11[17][1][1]*N21[17][0][1])
          )-(.993291320306148*(rikt[17][0][2]*s17))));
        Pd[16][1][1] = ((.0154953445967759*(s17*c17))+(1.11532875569381*(
          N11[17][1][1]*N21[17][1][1])));
        Pd[16][1][2] = (.032448+((.0154953445967759*(s17*s17))+(1.11532875569381
          *(N11[17][1][1]*N21[17][2][1]))));
        Pd[16][2][0] = (((.993291320306148*(rikt[17][0][2]*c17))+(
          1.11532875569381*(N11[17][2][1]*N21[17][0][1])))-.897728);
        Pd[16][2][1] = (((1.11532875569381*(N11[17][2][1]*N21[17][1][1]))-(
          .0154953445967759*(c17*c17)))-.032448);
        Pd[16][2][2] = ((1.11532875569381*(N11[17][2][1]*N21[17][2][1]))-(
          .0154953445967759*(s17*c17)));
        P22[16][0][0] = (.249792976+((.993291320306148*(rikt[17][0][2]*
          rikt[17][0][2]))+(1.11532875569381*(N21[17][0][1]*N21[17][0][1]))));
        P22[16][0][1] = (.0070022784+((1.11532875569381*(N21[17][0][1]*
          N21[17][1][1]))-(.0154953445967759*(rikt[17][0][2]*c17))));
        P22[16][0][2] = (.0001265472+((1.11532875569381*(N21[17][0][1]*
          N21[17][2][1]))-(.0154953445967759*(rikt[17][0][2]*s17))));
        P22[16][1][0] = P22[16][0][1];
        P22[16][1][1] = (.000316368+((.000241727375709704*(c17*c17))+((
          1.11532875569381*(N21[17][1][1]*N21[17][1][1]))+(1.34*(N21[17][1][0]*
          N21[17][1][0])))));
        P22[16][1][2] = (((.000241727375709704*(s17*c17))+((1.11532875569381*(
          N21[17][1][1]*N21[17][2][1]))+(1.34*(N21[17][1][0]*N21[17][2][0]))))-
          .0035011392);
        P22[16][2][0] = P22[16][0][2];
        P22[16][2][1] = P22[16][1][2];
        P22[16][2][2] = (.1939827968+((.000241727375709704*(s17*s17))+((
          1.11532875569381*(N21[17][2][1]*N21[17][2][1]))+(1.34*(N21[17][2][0]*
          N21[17][2][0])))));
        if (P22[16][0][0] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[16] = (1./P22[16][0][0]);
        }
        G1[16][1] = (DD[16]*Pd[16][1][0]);
        G1[16][2] = (DD[16]*Pd[16][2][0]);
        G2[16][1] = (DD[16]*P22[16][1][0]);
        G2[16][2] = (DD[16]*P22[16][2][0]);
        P11[16][1][1] = (P11[16][1][1]-(G1[16][1]*Pd[16][1][0]));
        P11[16][1][2] = (P11[16][1][2]-(G1[16][2]*Pd[16][1][0]));
        P11[16][2][2] = (P11[16][2][2]-(G1[16][2]*Pd[16][2][0]));
        Pd[16][1][1] = (Pd[16][1][1]-(G2[16][1]*Pd[16][1][0]));
        Pd[16][1][2] = (Pd[16][1][2]-(G2[16][2]*Pd[16][1][0]));
        Pd[16][2][1] = (Pd[16][2][1]-(G2[16][1]*Pd[16][2][0]));
        Pd[16][2][2] = (Pd[16][2][2]-(G2[16][2]*Pd[16][2][0]));
        P22[16][0][1] = (P22[16][0][1]-P22[16][1][0]);
        P22[16][0][2] = (P22[16][0][2]-P22[16][2][0]);
        P22[16][1][1] = (P22[16][1][1]-(G2[16][1]*P22[16][1][0]));
        P22[16][1][2] = (P22[16][1][2]-(G2[16][2]*P22[16][1][0]));
        P22[16][2][2] = (P22[16][2][2]-(G2[16][2]*P22[16][2][0]));
        sD1INV[1][1] = 0.;
        if (P11[16][1][1] >= 1e-13) {
            sD1INV[1][1] = (1./P11[16][1][1]);
        }
        sL11[2][1] = (P11[16][1][2]*sD1INV[1][1]);
        sL11D1[2][2] = (P11[16][2][2]-(P11[16][1][2]*sL11[2][1]));
        sD1INV[2][2] = 0.;
        if (sL11D1[2][2] >= 1e-13) {
            sD1INV[2][2] = (1./sL11D1[2][2]);
        }
        sD1L21[2][1] = (Pd[16][2][1]-(Pd[16][1][1]*sL11[2][1]));
        sD1L21[2][2] = (Pd[16][2][2]-(Pd[16][1][2]*sL11[2][1]));
        sL21[1][1] = (Pd[16][1][1]*sD1INV[1][1]);
        sL21[1][2] = (sD1INV[2][2]*sD1L21[2][1]);
        sL21[2][1] = (Pd[16][1][2]*sD1INV[1][1]);
        sL21[2][2] = (sD1INV[2][2]*sD1L21[2][2]);
        sL22D2[1][1] = (P22[16][1][1]-((sD1L21[2][1]*sL21[1][2])+((
          .181818181818182*(Pd[16][0][1]*Pd[16][0][1]))+(Pd[16][1][1]*sL21[1][1]
          ))));
        sL22D2[2][1] = (P22[16][1][2]-((sD1L21[2][1]*sL21[2][2])+((
          .181818181818182*(Pd[16][0][1]*Pd[16][0][2]))+(Pd[16][1][1]*sL21[2][1]
          ))));
        sL22D2[2][2] = (P22[16][2][2]-((sD1L21[2][2]*sL21[2][2])+((
          .181818181818182*(Pd[16][0][2]*Pd[16][0][2]))+(Pd[16][1][2]*sL21[2][1]
          ))));
        sD2INV[1][1] = 0.;
        if (sL22D2[1][1] >= 1e-13) {
            sD2INV[1][1] = (1./sL22D2[1][1]);
        }
        sL22[2][1] = (sD2INV[1][1]*sL22D2[2][1]);
        sL22D2[2][2] = (sL22D2[2][2]-(sL22[2][1]*sL22D2[2][1]));
        N11[16][1][1] = (c16-(sL11[2][1]*s16));
        N11[16][2][1] = (s16+(sL11[2][1]*c16));
        N21[16][0][1] = (rikt[16][0][1]+(rikt[16][0][2]*sL11[2][1]));
        N21[16][1][0] = (.0286+(.181818181818182*((Pd[16][0][1]*c16)-(
          Pd[16][0][2]*s16))));
        N21[16][1][1] = (((sL21[1][1]*c16)-(sL21[2][1]*s16))-(.0338*(s16+(
          sL11[2][1]*c16))));
        N21[16][1][2] = (((sL21[1][2]*c16)-(sL21[2][2]*s16))-(.0338*c16));
        N21[16][2][0] = (.4758+(.181818181818182*((Pd[16][0][1]*s16)+(
          Pd[16][0][2]*c16))));
        N21[16][2][1] = ((.0338*(c16-(sL11[2][1]*s16)))+((sL21[1][1]*s16)+(
          sL21[2][1]*c16)));
        N21[16][2][2] = (((sL21[1][2]*s16)+(sL21[2][2]*c16))-(.0338*s16));
        N22[16][1][1] = (c16-(sL22[2][1]*s16));
        N22[16][2][1] = (s16+(sL22[2][1]*c16));
        psiD11[16][1][1] = (N11[16][1][1]*P11[16][1][1]);
        psiD11[16][1][2] = -(sL11D1[2][2]*s16);
        psiD11[16][2][1] = (N11[16][2][1]*P11[16][1][1]);
        psiD11[16][2][2] = (sL11D1[2][2]*c16);
        psiD21[16][0][1] = (N21[16][0][1]*P11[16][1][1]);
        psiD21[16][0][2] = (rikt[16][0][2]*sL11D1[2][2]);
        psiD21[16][1][1] = (N21[16][1][1]*P11[16][1][1]);
        psiD21[16][1][2] = (N21[16][1][2]*sL11D1[2][2]);
        psiD21[16][2][1] = (N21[16][2][1]*P11[16][1][1]);
        psiD21[16][2][2] = (N21[16][2][2]*sL11D1[2][2]);
        psiD22[16][1][1] = (N22[16][1][1]*sL22D2[1][1]);
        psiD22[16][1][2] = -(sL22D2[2][2]*s16);
        psiD22[16][2][1] = (N22[16][2][1]*sL22D2[1][1]);
        psiD22[16][2][2] = (sL22D2[2][2]*c16);
        P11[15][1][1] = (8.35+((N11[16][1][1]*psiD11[16][1][1])-(
          psiD11[16][1][2]*s16)));
        P11[15][1][2] = ((N11[16][2][1]*psiD11[16][1][1])+(psiD11[16][1][2]*c16)
          );
        P11[15][2][1] = P11[15][1][2];
        P11[15][2][2] = (8.35+((N11[16][2][1]*psiD11[16][2][1])+(
          psiD11[16][2][2]*c16)));
        Pd[15][0][1] = (.119405+(5.5*N21[16][1][0]));
        Pd[15][0][2] = (1.986465+(5.5*N21[16][2][0]));
        Pd[15][1][0] = (((N21[16][0][1]*psiD11[16][1][1])+(psiD11[16][1][2]*
          rikt[16][0][2]))-.119405);
        Pd[15][1][1] = ((N21[16][1][1]*psiD11[16][1][1])+(N21[16][1][2]*
          psiD11[16][1][2]));
        Pd[15][1][2] = (.141115+((N21[16][2][1]*psiD11[16][1][1])+(N21[16][2][2]
          *psiD11[16][1][2])));
        Pd[15][2][0] = (((N21[16][0][1]*psiD11[16][2][1])+(psiD11[16][2][2]*
          rikt[16][0][2]))-1.986465);
        Pd[15][2][1] = (((N21[16][1][1]*psiD11[16][2][1])+(N21[16][1][2]*
          psiD11[16][2][2]))-.141115);
        Pd[15][2][2] = ((N21[16][2][1]*psiD11[16][2][1])+(N21[16][2][2]*
          psiD11[16][2][2]));
        P22[15][0][0] = (.634287515+((N21[16][0][1]*psiD21[16][0][1])+(
          psiD21[16][0][2]*rikt[16][0][2])));
        P22[15][0][1] = (.0335712585+((N21[16][1][1]*psiD21[16][0][1])+(
          N21[16][1][2]*psiD21[16][0][2])));
        P22[15][0][2] = (((N21[16][2][1]*psiD21[16][0][1])+(N21[16][2][2]*
          psiD21[16][0][2]))-.0020179445);
        P22[15][1][0] = P22[15][0][1];
        P22[15][1][1] = (.004092335+(((N21[16][1][2]*psiD21[16][1][2])+((5.5*(
          N21[16][1][0]*N21[16][1][0]))+(N21[16][1][1]*psiD21[16][1][1])))+((
          N22[16][1][1]*psiD22[16][1][1])-(psiD22[16][1][2]*s16))));
        P22[15][1][2] = (.0284064495+(((N21[16][2][2]*psiD21[16][1][2])+((5.5*(
          N21[16][1][0]*N21[16][2][0]))+(N21[16][2][1]*psiD21[16][1][1])))+((
          N22[16][2][1]*psiD22[16][1][1])+(psiD22[16][1][2]*c16))));
        P22[15][2][0] = P22[15][0][2];
        P22[15][2][1] = P22[15][1][2];
        P22[15][2][2] = (.474964867+(((N21[16][2][2]*psiD21[16][2][2])+((5.5*(
          N21[16][2][0]*N21[16][2][0]))+(N21[16][2][1]*psiD21[16][2][1])))+((
          N22[16][2][1]*psiD22[16][2][1])+(psiD22[16][2][2]*c16))));
        if (P22[15][0][0] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[15] = (1./P22[15][0][0]);
        }
        G1[15][1] = (DD[15]*Pd[15][1][0]);
        G1[15][2] = (DD[15]*Pd[15][2][0]);
        G2[15][1] = (DD[15]*P22[15][1][0]);
        G2[15][2] = (DD[15]*P22[15][2][0]);
        P11[15][1][1] = (P11[15][1][1]-(G1[15][1]*Pd[15][1][0]));
        P11[15][1][2] = (P11[15][1][2]-(G1[15][2]*Pd[15][1][0]));
        P11[15][2][2] = (P11[15][2][2]-(G1[15][2]*Pd[15][2][0]));
        Pd[15][1][1] = (Pd[15][1][1]-(G2[15][1]*Pd[15][1][0]));
        Pd[15][1][2] = (Pd[15][1][2]-(G2[15][2]*Pd[15][1][0]));
        Pd[15][2][1] = (Pd[15][2][1]-(G2[15][1]*Pd[15][2][0]));
        Pd[15][2][2] = (Pd[15][2][2]-(G2[15][2]*Pd[15][2][0]));
        P22[15][0][1] = (P22[15][0][1]-P22[15][1][0]);
        P22[15][0][2] = (P22[15][0][2]-P22[15][2][0]);
        P22[15][1][1] = (P22[15][1][1]-(G2[15][1]*P22[15][1][0]));
        P22[15][1][2] = (P22[15][1][2]-(G2[15][2]*P22[15][1][0]));
        P22[15][2][2] = (P22[15][2][2]-(G2[15][2]*P22[15][2][0]));
        sD1INV[1][1] = 0.;
        if (P11[15][1][1] >= 1e-13) {
            sD1INV[1][1] = (1./P11[15][1][1]);
        }
        sL11[2][1] = (P11[15][1][2]*sD1INV[1][1]);
        sL11D1[2][2] = (P11[15][2][2]-(P11[15][1][2]*sL11[2][1]));
        sD1INV[2][2] = 0.;
        if (sL11D1[2][2] >= 1e-13) {
            sD1INV[2][2] = (1./sL11D1[2][2]);
        }
        sD1L21[2][1] = (Pd[15][2][1]-(Pd[15][1][1]*sL11[2][1]));
        sD1L21[2][2] = (Pd[15][2][2]-(Pd[15][1][2]*sL11[2][1]));
        sL21[1][1] = (Pd[15][1][1]*sD1INV[1][1]);
        sL21[1][2] = (sD1INV[2][2]*sD1L21[2][1]);
        sL21[2][1] = (Pd[15][1][2]*sD1INV[1][1]);
        sL21[2][2] = (sD1INV[2][2]*sD1L21[2][2]);
        sL22D2[1][1] = (P22[15][1][1]-((sD1L21[2][1]*sL21[1][2])+((
          .0722021660649819*(Pd[15][0][1]*Pd[15][0][1]))+(Pd[15][1][1]*
          sL21[1][1]))));
        sL22D2[2][1] = (P22[15][1][2]-((sD1L21[2][1]*sL21[2][2])+((
          .0722021660649819*(Pd[15][0][1]*Pd[15][0][2]))+(Pd[15][1][1]*
          sL21[2][1]))));
        sL22D2[2][2] = (P22[15][2][2]-((sD1L21[2][2]*sL21[2][2])+((
          .0722021660649819*(Pd[15][0][2]*Pd[15][0][2]))+(Pd[15][1][2]*
          sL21[2][1]))));
        sD2INV[1][1] = 0.;
        if (sL22D2[1][1] >= 1e-13) {
            sD2INV[1][1] = (1./sL22D2[1][1]);
        }
        sL22[2][1] = (sD2INV[1][1]*sL22D2[2][1]);
        sL22D2[2][2] = (sL22D2[2][2]-(sL22[2][1]*sL22D2[2][1]));
        N11[15][1][1] = (c15-(sL11[2][1]*s15));
        N11[15][2][1] = (s15+(sL11[2][1]*c15));
        N21[15][0][1] = (rikt[15][0][1]+(rikt[15][0][2]*sL11[2][1]));
        N21[15][1][0] = ((.0722021660649819*((Pd[15][0][1]*c15)-(Pd[15][0][2]*
          s15)))-.0442);
        N21[15][1][1] = ((.1118*(s15+(sL11[2][1]*c15)))+((sL21[1][1]*c15)-(
          sL21[2][1]*s15)));
        N21[15][1][2] = ((.1118*c15)+((sL21[1][2]*c15)-(sL21[2][2]*s15)));
        N21[15][2][0] = (.1612+(.0722021660649819*((Pd[15][0][1]*s15)+(
          Pd[15][0][2]*c15))));
        N21[15][2][1] = ((.1118*((sL11[2][1]*s15)-c15))+((sL21[1][1]*s15)+(
          sL21[2][1]*c15)));
        N21[15][2][2] = ((.1118*s15)+((sL21[1][2]*s15)+(sL21[2][2]*c15)));
        N22[15][1][1] = (c15-(sL22[2][1]*s15));
        N22[15][2][1] = (s15+(sL22[2][1]*c15));
        psiD11[15][1][1] = (N11[15][1][1]*P11[15][1][1]);
        psiD11[15][1][2] = -(sL11D1[2][2]*s15);
        psiD11[15][2][1] = (N11[15][2][1]*P11[15][1][1]);
        psiD11[15][2][2] = (sL11D1[2][2]*c15);
        psiD21[15][0][1] = (N21[15][0][1]*P11[15][1][1]);
        psiD21[15][0][2] = (rikt[15][0][2]*sL11D1[2][2]);
        psiD21[15][1][1] = (N21[15][1][1]*P11[15][1][1]);
        psiD21[15][1][2] = (N21[15][1][2]*sL11D1[2][2]);
        psiD21[15][2][1] = (N21[15][2][1]*P11[15][1][1]);
        psiD21[15][2][2] = (N21[15][2][2]*sL11D1[2][2]);
        psiD22[15][1][1] = (N22[15][1][1]*sL22D2[1][1]);
        psiD22[15][1][2] = -(sL22D2[2][2]*s15);
        psiD22[15][2][1] = (N22[15][2][1]*sL22D2[1][1]);
        psiD22[15][2][2] = (sL22D2[2][2]*c15);
        P11[2][1][1] = (16.61+((N11[15][1][1]*psiD11[15][1][1])-(
          psiD11[15][1][2]*s15)));
        P11[2][1][2] = ((N11[15][2][1]*psiD11[15][1][1])+(psiD11[15][1][2]*c15))
          ;
        P11[2][2][1] = P11[2][1][2];
        P11[2][2][2] = (16.61+((N11[15][2][1]*psiD11[15][2][1])+(
          psiD11[15][2][2]*c15)));
        Pd[2][0][1] = ((13.85*N21[15][1][0])-.8305);
        Pd[2][0][2] = (2.003166+(13.85*N21[15][2][0]));
        Pd[2][1][0] = (.8305+((N21[15][0][1]*psiD11[15][1][1])+(psiD11[15][1][2]
          *rikt[15][0][2])));
        Pd[2][1][1] = ((N21[15][1][1]*psiD11[15][1][1])+(N21[15][1][2]*
          psiD11[15][1][2]));
        Pd[2][1][2] = ((N21[15][2][1]*psiD11[15][1][1])+(N21[15][2][2]*
          psiD11[15][1][2]));
        Pd[2][2][0] = (((N21[15][0][1]*psiD11[15][2][1])+(psiD11[15][2][2]*
          rikt[15][0][2]))-2.003166);
        Pd[2][2][1] = ((N21[15][1][1]*psiD11[15][2][1])+(N21[15][1][2]*
          psiD11[15][2][2]));
        Pd[2][2][2] = ((N21[15][2][1]*psiD11[15][2][1])+(N21[15][2][2]*
          psiD11[15][2][2]));
        P22[2][0][0] = (.4631068196+((N21[15][0][1]*psiD21[15][0][1])+(
          psiD21[15][0][2]*rikt[15][0][2])));
        P22[2][0][1] = ((N21[15][1][1]*psiD21[15][0][1])+(N21[15][1][2]*
          psiD21[15][0][2]));
        P22[2][0][2] = ((N21[15][2][1]*psiD21[15][0][1])+(N21[15][2][2]*
          psiD21[15][0][2]));
        P22[2][1][0] = P22[2][0][1];
        P22[2][1][1] = (.041525+(((N21[15][1][2]*psiD21[15][1][2])+((13.85*(
          N21[15][1][0]*N21[15][1][0]))+(N21[15][1][1]*psiD21[15][1][1])))+((
          N22[15][1][1]*psiD22[15][1][1])-(psiD22[15][1][2]*s15))));
        P22[2][1][2] = ((((N21[15][2][2]*psiD21[15][1][2])+((13.85*(
          N21[15][1][0]*N21[15][2][0]))+(N21[15][2][1]*psiD21[15][1][1])))+((
          N22[15][2][1]*psiD22[15][1][1])+(psiD22[15][1][2]*c15)))-.1001583);
        P22[2][2][0] = P22[2][0][2];
        P22[2][2][1] = P22[2][1][2];
        P22[2][2][2] = (.2415818196+(((N21[15][2][2]*psiD21[15][2][2])+((13.85*(
          N21[15][2][0]*N21[15][2][0]))+(N21[15][2][1]*psiD21[15][2][1])))+((
          N22[15][2][1]*psiD22[15][2][1])+(psiD22[15][2][2]*c15))));
        DD[14] = 82.2637834943576;
        N11[14][1][1] = (c14+(.228298077059165*s14));
        N11[14][2][1] = (s14-(.228298077059165*c14));
        N21[14][0][1] = (rikt[14][0][1]-(.228298077059165*rikt[14][0][2]));
        N21[14][1][0] = (((.039*c14)-(.0442*s14))-.0078);
        N21[14][1][1] = ((.0156*s14)-(.00356145000212298*c14));
        N21[14][2][0] = (.4316+((.039*s14)+(.0442*c14)));
        N21[14][2][1] = -((.00356145000212298*s14)+(.0156*c14));
        P11[13][1][1] = (4.16+((.993291320306148*(s14*s14))+(1.11532875569381*(
          N11[14][1][1]*N11[14][1][1]))));
        P11[13][1][2] = ((1.11532875569381*(N11[14][1][1]*N11[14][2][1]))-(
          .993291320306148*(s14*c14)));
        P11[13][2][1] = P11[13][1][2];
        P11[13][2][2] = (4.16+((.993291320306148*(c14*c14))+(1.11532875569381*(
          N11[14][2][1]*N11[14][2][1]))));
        Pd[13][0][1] = ((1.34*N21[14][1][0])-.016224);
        Pd[13][0][2] = (.897728+(1.34*N21[14][2][0]));
        Pd[13][1][0] = (.016224+((1.11532875569381*(N11[14][1][1]*N21[14][0][1])
          )-(.993291320306148*(rikt[14][0][2]*s14))));
        Pd[13][1][1] = ((1.11532875569381*(N11[14][1][1]*N21[14][1][1]))-(
          .0154953445967759*(s14*c14)));
        Pd[13][1][2] = (((1.11532875569381*(N11[14][1][1]*N21[14][2][1]))-(
          .0154953445967759*(s14*s14)))-.032448);
        Pd[13][2][0] = (((.993291320306148*(rikt[14][0][2]*c14))+(
          1.11532875569381*(N11[14][2][1]*N21[14][0][1])))-.897728);
        Pd[13][2][1] = (.032448+((.0154953445967759*(c14*c14))+(1.11532875569381
          *(N11[14][2][1]*N21[14][1][1]))));
        Pd[13][2][2] = ((.0154953445967759*(s14*c14))+(1.11532875569381*(
          N11[14][2][1]*N21[14][2][1])));
        P22[13][0][0] = (.249792976+((.993291320306148*(rikt[14][0][2]*
          rikt[14][0][2]))+(1.11532875569381*(N21[14][0][1]*N21[14][0][1]))));
        P22[13][0][1] = (((.0154953445967759*(rikt[14][0][2]*c14))+(
          1.11532875569381*(N21[14][0][1]*N21[14][1][1])))-.0070022784);
        P22[13][0][2] = (((.0154953445967759*(rikt[14][0][2]*s14))+(
          1.11532875569381*(N21[14][0][1]*N21[14][2][1])))-.0001265472);
        P22[13][1][0] = P22[13][0][1];
        P22[13][1][1] = (.000316368+((.000241727375709704*(c14*c14))+((
          1.11532875569381*(N21[14][1][1]*N21[14][1][1]))+(1.34*(N21[14][1][0]*
          N21[14][1][0])))));
        P22[13][1][2] = (((.000241727375709704*(s14*c14))+((1.11532875569381*(
          N21[14][1][1]*N21[14][2][1]))+(1.34*(N21[14][1][0]*N21[14][2][0]))))-
          .0035011392);
        P22[13][2][0] = P22[13][0][2];
        P22[13][2][1] = P22[13][1][2];
        P22[13][2][2] = (.1939827968+((.000241727375709704*(s14*s14))+((
          1.11532875569381*(N21[14][2][1]*N21[14][2][1]))+(1.34*(N21[14][2][0]*
          N21[14][2][0])))));
        if (P22[13][0][0] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[13] = (1./P22[13][0][0]);
        }
        G1[13][1] = (DD[13]*Pd[13][1][0]);
        G1[13][2] = (DD[13]*Pd[13][2][0]);
        G2[13][1] = (DD[13]*P22[13][1][0]);
        G2[13][2] = (DD[13]*P22[13][2][0]);
        P11[13][1][1] = (P11[13][1][1]-(G1[13][1]*Pd[13][1][0]));
        P11[13][1][2] = (P11[13][1][2]-(G1[13][2]*Pd[13][1][0]));
        P11[13][2][2] = (P11[13][2][2]-(G1[13][2]*Pd[13][2][0]));
        Pd[13][1][1] = (Pd[13][1][1]-(G2[13][1]*Pd[13][1][0]));
        Pd[13][1][2] = (Pd[13][1][2]-(G2[13][2]*Pd[13][1][0]));
        Pd[13][2][1] = (Pd[13][2][1]-(G2[13][1]*Pd[13][2][0]));
        Pd[13][2][2] = (Pd[13][2][2]-(G2[13][2]*Pd[13][2][0]));
        P22[13][0][1] = (P22[13][0][1]-P22[13][1][0]);
        P22[13][0][2] = (P22[13][0][2]-P22[13][2][0]);
        P22[13][1][1] = (P22[13][1][1]-(G2[13][1]*P22[13][1][0]));
        P22[13][1][2] = (P22[13][1][2]-(G2[13][2]*P22[13][1][0]));
        P22[13][2][2] = (P22[13][2][2]-(G2[13][2]*P22[13][2][0]));
        sD1INV[1][1] = 0.;
        if (P11[13][1][1] >= 1e-13) {
            sD1INV[1][1] = (1./P11[13][1][1]);
        }
        sL11[2][1] = (P11[13][1][2]*sD1INV[1][1]);
        sL11D1[2][2] = (P11[13][2][2]-(P11[13][1][2]*sL11[2][1]));
        sD1INV[2][2] = 0.;
        if (sL11D1[2][2] >= 1e-13) {
            sD1INV[2][2] = (1./sL11D1[2][2]);
        }
        sD1L21[2][1] = (Pd[13][2][1]-(Pd[13][1][1]*sL11[2][1]));
        sD1L21[2][2] = (Pd[13][2][2]-(Pd[13][1][2]*sL11[2][1]));
        sL21[1][1] = (Pd[13][1][1]*sD1INV[1][1]);
        sL21[1][2] = (sD1INV[2][2]*sD1L21[2][1]);
        sL21[2][1] = (Pd[13][1][2]*sD1INV[1][1]);
        sL21[2][2] = (sD1INV[2][2]*sD1L21[2][2]);
        sL22D2[1][1] = (P22[13][1][1]-((sD1L21[2][1]*sL21[1][2])+((
          .181818181818182*(Pd[13][0][1]*Pd[13][0][1]))+(Pd[13][1][1]*sL21[1][1]
          ))));
        sL22D2[2][1] = (P22[13][1][2]-((sD1L21[2][1]*sL21[2][2])+((
          .181818181818182*(Pd[13][0][1]*Pd[13][0][2]))+(Pd[13][1][1]*sL21[2][1]
          ))));
        sL22D2[2][2] = (P22[13][2][2]-((sD1L21[2][2]*sL21[2][2])+((
          .181818181818182*(Pd[13][0][2]*Pd[13][0][2]))+(Pd[13][1][2]*sL21[2][1]
          ))));
        sD2INV[1][1] = 0.;
        if (sL22D2[1][1] >= 1e-13) {
            sD2INV[1][1] = (1./sL22D2[1][1]);
        }
        sL22[2][1] = (sD2INV[1][1]*sL22D2[2][1]);
        sL22D2[2][2] = (sL22D2[2][2]-(sL22[2][1]*sL22D2[2][1]));
        N11[13][1][1] = (c13-(sL11[2][1]*s13));
        N11[13][2][1] = (s13+(sL11[2][1]*c13));
        N21[13][0][1] = (rikt[13][0][1]+(rikt[13][0][2]*sL11[2][1]));
        N21[13][1][0] = (.0286+(.181818181818182*((Pd[13][0][1]*c13)-(
          Pd[13][0][2]*s13))));
        N21[13][1][1] = ((.0338*(s13+(sL11[2][1]*c13)))+((sL21[1][1]*c13)-(
          sL21[2][1]*s13)));
        N21[13][1][2] = ((.0338*c13)+((sL21[1][2]*c13)-(sL21[2][2]*s13)));
        N21[13][2][0] = (.4758+(.181818181818182*((Pd[13][0][1]*s13)+(
          Pd[13][0][2]*c13))));
        N21[13][2][1] = ((.0338*((sL11[2][1]*s13)-c13))+((sL21[1][1]*s13)+(
          sL21[2][1]*c13)));
        N21[13][2][2] = ((.0338*s13)+((sL21[1][2]*s13)+(sL21[2][2]*c13)));
        N22[13][1][1] = (c13-(sL22[2][1]*s13));
        N22[13][2][1] = (s13+(sL22[2][1]*c13));
        psiD11[13][1][1] = (N11[13][1][1]*P11[13][1][1]);
        psiD11[13][1][2] = -(sL11D1[2][2]*s13);
        psiD11[13][2][1] = (N11[13][2][1]*P11[13][1][1]);
        psiD11[13][2][2] = (sL11D1[2][2]*c13);
        psiD21[13][0][1] = (N21[13][0][1]*P11[13][1][1]);
        psiD21[13][0][2] = (rikt[13][0][2]*sL11D1[2][2]);
        psiD21[13][1][1] = (N21[13][1][1]*P11[13][1][1]);
        psiD21[13][1][2] = (N21[13][1][2]*sL11D1[2][2]);
        psiD21[13][2][1] = (N21[13][2][1]*P11[13][1][1]);
        psiD21[13][2][2] = (N21[13][2][2]*sL11D1[2][2]);
        psiD22[13][1][1] = (N22[13][1][1]*sL22D2[1][1]);
        psiD22[13][1][2] = -(sL22D2[2][2]*s13);
        psiD22[13][2][1] = (N22[13][2][1]*sL22D2[1][1]);
        psiD22[13][2][2] = (sL22D2[2][2]*c13);
        P11[12][1][1] = (8.35+((N11[13][1][1]*psiD11[13][1][1])-(
          psiD11[13][1][2]*s13)));
        P11[12][1][2] = ((N11[13][2][1]*psiD11[13][1][1])+(psiD11[13][1][2]*c13)
          );
        P11[12][2][1] = P11[12][1][2];
        P11[12][2][2] = (8.35+((N11[13][2][1]*psiD11[13][2][1])+(
          psiD11[13][2][2]*c13)));
        Pd[12][0][1] = (.119405+(5.5*N21[13][1][0]));
        Pd[12][0][2] = (1.986465+(5.5*N21[13][2][0]));
        Pd[12][1][0] = (((N21[13][0][1]*psiD11[13][1][1])+(psiD11[13][1][2]*
          rikt[13][0][2]))-.119405);
        Pd[12][1][1] = ((N21[13][1][1]*psiD11[13][1][1])+(N21[13][1][2]*
          psiD11[13][1][2]));
        Pd[12][1][2] = (((N21[13][2][1]*psiD11[13][1][1])+(N21[13][2][2]*
          psiD11[13][1][2]))-.141115);
        Pd[12][2][0] = (((N21[13][0][1]*psiD11[13][2][1])+(psiD11[13][2][2]*
          rikt[13][0][2]))-1.986465);
        Pd[12][2][1] = (.141115+((N21[13][1][1]*psiD11[13][2][1])+(N21[13][1][2]
          *psiD11[13][2][2])));
        Pd[12][2][2] = ((N21[13][2][1]*psiD11[13][2][1])+(N21[13][2][2]*
          psiD11[13][2][2]));
        P22[12][0][0] = (.634287515+((N21[13][0][1]*psiD21[13][0][1])+(
          psiD21[13][0][2]*rikt[13][0][2])));
        P22[12][0][1] = (((N21[13][1][1]*psiD21[13][0][1])+(N21[13][1][2]*
          psiD21[13][0][2]))-.0335712585);
        P22[12][0][2] = (.0020179445+((N21[13][2][1]*psiD21[13][0][1])+(
          N21[13][2][2]*psiD21[13][0][2])));
        P22[12][1][0] = P22[12][0][1];
        P22[12][1][1] = (.004092335+(((N21[13][1][2]*psiD21[13][1][2])+((5.5*(
          N21[13][1][0]*N21[13][1][0]))+(N21[13][1][1]*psiD21[13][1][1])))+((
          N22[13][1][1]*psiD22[13][1][1])-(psiD22[13][1][2]*s13))));
        P22[12][1][2] = (.0284064495+(((N21[13][2][2]*psiD21[13][1][2])+((5.5*(
          N21[13][1][0]*N21[13][2][0]))+(N21[13][2][1]*psiD21[13][1][1])))+((
          N22[13][2][1]*psiD22[13][1][1])+(psiD22[13][1][2]*c13))));
        P22[12][2][0] = P22[12][0][2];
        P22[12][2][1] = P22[12][1][2];
        P22[12][2][2] = (.474964867+(((N21[13][2][2]*psiD21[13][2][2])+((5.5*(
          N21[13][2][0]*N21[13][2][0]))+(N21[13][2][1]*psiD21[13][2][1])))+((
          N22[13][2][1]*psiD22[13][2][1])+(psiD22[13][2][2]*c13))));
        if (P22[12][0][0] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[12] = (1./P22[12][0][0]);
        }
        G1[12][1] = (DD[12]*Pd[12][1][0]);
        G1[12][2] = (DD[12]*Pd[12][2][0]);
        G2[12][1] = (DD[12]*P22[12][1][0]);
        G2[12][2] = (DD[12]*P22[12][2][0]);
        P11[12][1][1] = (P11[12][1][1]-(G1[12][1]*Pd[12][1][0]));
        P11[12][1][2] = (P11[12][1][2]-(G1[12][2]*Pd[12][1][0]));
        P11[12][2][2] = (P11[12][2][2]-(G1[12][2]*Pd[12][2][0]));
        Pd[12][1][1] = (Pd[12][1][1]-(G2[12][1]*Pd[12][1][0]));
        Pd[12][1][2] = (Pd[12][1][2]-(G2[12][2]*Pd[12][1][0]));
        Pd[12][2][1] = (Pd[12][2][1]-(G2[12][1]*Pd[12][2][0]));
        Pd[12][2][2] = (Pd[12][2][2]-(G2[12][2]*Pd[12][2][0]));
        P22[12][0][1] = (P22[12][0][1]-P22[12][1][0]);
        P22[12][0][2] = (P22[12][0][2]-P22[12][2][0]);
        P22[12][1][1] = (P22[12][1][1]-(G2[12][1]*P22[12][1][0]));
        P22[12][1][2] = (P22[12][1][2]-(G2[12][2]*P22[12][1][0]));
        P22[12][2][2] = (P22[12][2][2]-(G2[12][2]*P22[12][2][0]));
        sD1INV[1][1] = 0.;
        if (P11[12][1][1] >= 1e-13) {
            sD1INV[1][1] = (1./P11[12][1][1]);
        }
        sL11[2][1] = (P11[12][1][2]*sD1INV[1][1]);
        sL11D1[2][2] = (P11[12][2][2]-(P11[12][1][2]*sL11[2][1]));
        sD1INV[2][2] = 0.;
        if (sL11D1[2][2] >= 1e-13) {
            sD1INV[2][2] = (1./sL11D1[2][2]);
        }
        sD1L21[2][1] = (Pd[12][2][1]-(Pd[12][1][1]*sL11[2][1]));
        sD1L21[2][2] = (Pd[12][2][2]-(Pd[12][1][2]*sL11[2][1]));
        sL21[1][1] = (Pd[12][1][1]*sD1INV[1][1]);
        sL21[1][2] = (sD1INV[2][2]*sD1L21[2][1]);
        sL21[2][1] = (Pd[12][1][2]*sD1INV[1][1]);
        sL21[2][2] = (sD1INV[2][2]*sD1L21[2][2]);
        sL22D2[1][1] = (P22[12][1][1]-((sD1L21[2][1]*sL21[1][2])+((
          .0722021660649819*(Pd[12][0][1]*Pd[12][0][1]))+(Pd[12][1][1]*
          sL21[1][1]))));
        sL22D2[2][1] = (P22[12][1][2]-((sD1L21[2][1]*sL21[2][2])+((
          .0722021660649819*(Pd[12][0][1]*Pd[12][0][2]))+(Pd[12][1][1]*
          sL21[2][1]))));
        sL22D2[2][2] = (P22[12][2][2]-((sD1L21[2][2]*sL21[2][2])+((
          .0722021660649819*(Pd[12][0][2]*Pd[12][0][2]))+(Pd[12][1][2]*
          sL21[2][1]))));
        sD2INV[1][1] = 0.;
        if (sL22D2[1][1] >= 1e-13) {
            sD2INV[1][1] = (1./sL22D2[1][1]);
        }
        sL22[2][1] = (sD2INV[1][1]*sL22D2[2][1]);
        sL22D2[2][2] = (sL22D2[2][2]-(sL22[2][1]*sL22D2[2][1]));
        N11[12][1][1] = (c12-(sL11[2][1]*s12));
        N11[12][2][1] = (s12+(sL11[2][1]*c12));
        N21[12][0][1] = (rikt[12][0][1]+(rikt[12][0][2]*sL11[2][1]));
        N21[12][1][0] = ((.0722021660649819*((Pd[12][0][1]*c12)-(Pd[12][0][2]*
          s12)))-.0442);
        N21[12][1][1] = (((sL21[1][1]*c12)-(sL21[2][1]*s12))-(.1118*(s12+(
          sL11[2][1]*c12))));
        N21[12][1][2] = (((sL21[1][2]*c12)-(sL21[2][2]*s12))-(.1118*c12));
        N21[12][2][0] = (.1612+(.0722021660649819*((Pd[12][0][1]*s12)+(
          Pd[12][0][2]*c12))));
        N21[12][2][1] = ((.1118*(c12-(sL11[2][1]*s12)))+((sL21[1][1]*s12)+(
          sL21[2][1]*c12)));
        N21[12][2][2] = (((sL21[1][2]*s12)+(sL21[2][2]*c12))-(.1118*s12));
        N22[12][1][1] = (c12-(sL22[2][1]*s12));
        N22[12][2][1] = (s12+(sL22[2][1]*c12));
        psiD11[12][1][1] = (N11[12][1][1]*P11[12][1][1]);
        psiD11[12][1][2] = -(sL11D1[2][2]*s12);
        psiD11[12][2][1] = (N11[12][2][1]*P11[12][1][1]);
        psiD11[12][2][2] = (sL11D1[2][2]*c12);
        psiD21[12][0][1] = (N21[12][0][1]*P11[12][1][1]);
        psiD21[12][0][2] = (rikt[12][0][2]*sL11D1[2][2]);
        psiD21[12][1][1] = (N21[12][1][1]*P11[12][1][1]);
        psiD21[12][1][2] = (N21[12][1][2]*sL11D1[2][2]);
        psiD21[12][2][1] = (N21[12][2][1]*P11[12][1][1]);
        psiD21[12][2][2] = (N21[12][2][2]*sL11D1[2][2]);
        psiD22[12][1][1] = (N22[12][1][1]*sL22D2[1][1]);
        psiD22[12][1][2] = -(sL22D2[2][2]*s12);
        psiD22[12][2][1] = (N22[12][2][1]*sL22D2[1][1]);
        psiD22[12][2][2] = (sL22D2[2][2]*c12);
        P11[2][1][1] = (P11[2][1][1]+((N11[12][1][1]*psiD11[12][1][1])-(
          psiD11[12][1][2]*s12)));
        P11[2][1][2] = (P11[2][1][2]+((N11[12][2][1]*psiD11[12][1][1])+(
          psiD11[12][1][2]*c12)));
        P11[2][2][1] = P11[2][1][2];
        P11[2][2][2] = (P11[2][2][2]+((N11[12][2][1]*psiD11[12][2][1])+(
          psiD11[12][2][2]*c12)));
        Pd[2][0][1] = (Pd[2][0][1]+(13.85*N21[12][1][0]));
        Pd[2][0][2] = (Pd[2][0][2]+(13.85*N21[12][2][0]));
        Pd[2][1][0] = (Pd[2][1][0]+((N21[12][0][1]*psiD11[12][1][1])+(
          psiD11[12][1][2]*rikt[12][0][2])));
        Pd[2][1][1] = (Pd[2][1][1]+((N21[12][1][1]*psiD11[12][1][1])+(
          N21[12][1][2]*psiD11[12][1][2])));
        Pd[2][1][2] = (Pd[2][1][2]+((N21[12][2][1]*psiD11[12][1][1])+(
          N21[12][2][2]*psiD11[12][1][2])));
        Pd[2][2][0] = (Pd[2][2][0]+((N21[12][0][1]*psiD11[12][2][1])+(
          psiD11[12][2][2]*rikt[12][0][2])));
        Pd[2][2][1] = (Pd[2][2][1]+((N21[12][1][1]*psiD11[12][2][1])+(
          N21[12][1][2]*psiD11[12][2][2])));
        Pd[2][2][2] = (Pd[2][2][2]+((N21[12][2][1]*psiD11[12][2][1])+(
          N21[12][2][2]*psiD11[12][2][2])));
        P22[2][0][0] = (P22[2][0][0]+((N21[12][0][1]*psiD21[12][0][1])+(
          psiD21[12][0][2]*rikt[12][0][2])));
        P22[2][0][1] = (P22[2][0][1]+((N21[12][1][1]*psiD21[12][0][1])+(
          N21[12][1][2]*psiD21[12][0][2])));
        P22[2][0][2] = (P22[2][0][2]+((N21[12][2][1]*psiD21[12][0][1])+(
          N21[12][2][2]*psiD21[12][0][2])));
        P22[2][1][0] = P22[2][0][1];
        P22[2][1][1] = (P22[2][1][1]+(((N21[12][1][2]*psiD21[12][1][2])+((13.85*
          (N21[12][1][0]*N21[12][1][0]))+(N21[12][1][1]*psiD21[12][1][1])))+((
          N22[12][1][1]*psiD22[12][1][1])-(psiD22[12][1][2]*s12))));
        P22[2][1][2] = (P22[2][1][2]+(((N21[12][2][2]*psiD21[12][1][2])+((13.85*
          (N21[12][1][0]*N21[12][2][0]))+(N21[12][2][1]*psiD21[12][1][1])))+((
          N22[12][2][1]*psiD22[12][1][1])+(psiD22[12][1][2]*c12))));
        P22[2][2][0] = P22[2][0][2];
        P22[2][2][1] = P22[2][1][2];
        P22[2][2][2] = (P22[2][2][2]+(((N21[12][2][2]*psiD21[12][2][2])+((13.85*
          (N21[12][2][0]*N21[12][2][0]))+(N21[12][2][1]*psiD21[12][2][1])))+((
          N22[12][2][1]*psiD22[12][2][1])+(psiD22[12][2][2]*c12))));
        DD[11] = 254.858235106722;
        N21[11][0][2] = -(.2756+(.065*c11));
        P11[10][0][0] = (1.43427524689392+(.325724753106085*(s11*s11)));
        P11[10][0][1] = -(.325724753106085*(s11*c11));
        P11[10][1][0] = P11[10][0][1];
        P11[10][1][1] = (1.43427524689392+(.325724753106085*(c11*c11)));
        Pd[10][0][2] = (.228548258043963+(.089769741956037*(s11*s11)));
        Pd[10][1][2] = (.004719-(.089769741956037*(s11*c11)));
        Pd[10][2][0] = ((.55*N21[11][0][2])-.166738);
        Pd[10][2][1] = -(.004719+(.03575*s11));
        P22[10][0][0] = (.0288764964+((.0015*(s11*s11))+(.55*(N21[11][0][2]*
          N21[11][0][2]))));
        P22[10][0][1] = (.0006502782-((.0015*(s11*c11))+(.03575*(N21[11][0][2]*
          s11))));
        P22[10][1][0] = P22[10][0][1];
        P22[10][1][1] = (.0020184041+(.00082375*(s11*s11)));
        P22[10][2][2] = (.0400298076169162+(.0247405408830838*(s11*s11)));
        if (P22[10][0][0] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[10] = (1./P22[10][0][0]);
        }
        G1[10][2] = (DD[10]*Pd[10][2][0]);
        G2[10][1] = (DD[10]*P22[10][1][0]);
        P11[10][2][2] = (1.76-(G1[10][2]*Pd[10][2][0]));
        Pd[10][2][1] = (Pd[10][2][1]-(G2[10][1]*Pd[10][2][0]));
        P22[10][0][1] = (P22[10][0][1]-P22[10][1][0]);
        P22[10][1][1] = (P22[10][1][1]-(G2[10][1]*P22[10][1][0]));
        sD1INV[0][0] = 0.;
        if (P11[10][0][0] >= 1e-13) {
            sD1INV[0][0] = (1./P11[10][0][0]);
        }
        sL11[1][0] = (P11[10][0][1]*sD1INV[0][0]);
        sL11D1[1][1] = (P11[10][1][1]-(P11[10][0][1]*sL11[1][0]));
        sD1INV[1][1] = 0.;
        if (sL11D1[1][1] >= 1e-13) {
            sD1INV[1][1] = (1./sL11D1[1][1]);
        }
        sD1INV[2][2] = 0.;
        if (P11[10][2][2] >= 1e-13) {
            sD1INV[2][2] = (1./P11[10][2][2]);
        }
        sD1L21[1][2] = (Pd[10][1][2]-(Pd[10][0][2]*sL11[1][0]));
        sL21[1][2] = (Pd[10][2][1]*sD1INV[2][2]);
        sL21[2][0] = (Pd[10][0][2]*sD1INV[0][0]);
        sL21[2][1] = (sD1INV[1][1]*sD1L21[1][2]);
        sL22D2[1][1] = (P22[10][1][1]-(Pd[10][2][1]*sL21[1][2]));
        sL22D2[2][2] = (P22[10][2][2]-((Pd[10][0][2]*sL21[2][0])+(sD1L21[1][2]*
          sL21[2][1])));
        sD2INV[1][1] = 0.;
        if (sL22D2[1][1] >= 1e-13) {
            sD2INV[1][1] = (1./sL22D2[1][1]);
        }
        N11[10][1][0] = (sL11[1][0]*c10);
        N11[10][2][0] = (sL11[1][0]*s10);
        N21[10][0][0] = (rikt[10][0][1]*sL11[1][0]);
        N21[10][1][0] = (.0026-(sL21[2][0]*s10));
        N21[10][1][1] = -(sL21[2][1]*s10);
        N21[10][1][2] = (sL21[1][2]*c10);
        N21[10][2][0] = (.2652+(sL21[2][0]*c10));
        N21[10][2][1] = (sL21[2][1]*c10);
        N21[10][2][2] = (sL21[1][2]*s10);
        psiD11[10][1][0] = (N11[10][1][0]*P11[10][0][0]);
        psiD11[10][1][1] = (sL11D1[1][1]*c10);
        psiD11[10][1][2] = -(P11[10][2][2]*s10);
        psiD11[10][2][0] = (N11[10][2][0]*P11[10][0][0]);
        psiD11[10][2][1] = (sL11D1[1][1]*s10);
        psiD11[10][2][2] = (P11[10][2][2]*c10);
        psiD21[10][0][0] = (N21[10][0][0]*P11[10][0][0]);
        psiD21[10][0][1] = (rikt[10][0][1]*sL11D1[1][1]);
        psiD21[10][0][2] = (P11[10][2][2]*rikt[10][0][2]);
        psiD21[10][1][0] = (N21[10][1][0]*P11[10][0][0]);
        psiD21[10][1][1] = (N21[10][1][1]*sL11D1[1][1]);
        psiD21[10][1][2] = (N21[10][1][2]*P11[10][2][2]);
        psiD21[10][2][0] = (N21[10][2][0]*P11[10][0][0]);
        psiD21[10][2][1] = (N21[10][2][1]*sL11D1[1][1]);
        psiD21[10][2][2] = (N21[10][2][2]*P11[10][2][2]);
        psiD22[10][1][1] = (sL22D2[1][1]*c10);
        psiD22[10][1][2] = -(sL22D2[2][2]*s10);
        psiD22[10][2][1] = (sL22D2[1][1]*s10);
        psiD22[10][2][2] = (sL22D2[2][2]*c10);
        P11[9][0][0] = (2.79+P11[10][0][0]);
        P11[9][0][1] = (N11[10][1][0]*P11[10][0][0]);
        P11[9][0][2] = (N11[10][2][0]*P11[10][0][0]);
        P11[9][1][0] = P11[9][0][1];
        P11[9][1][1] = (2.79+(((N11[10][1][0]*psiD11[10][1][0])+(
          psiD11[10][1][1]*c10))-(psiD11[10][1][2]*s10)));
        P11[9][1][2] = ((psiD11[10][1][2]*c10)+((N11[10][2][0]*psiD11[10][1][0])
          +(psiD11[10][1][1]*s10)));
        P11[9][2][0] = P11[9][0][2];
        P11[9][2][1] = P11[9][1][2];
        P11[9][2][2] = (2.79+((psiD11[10][2][2]*c10)+((N11[10][2][0]*
          psiD11[10][2][0])+(psiD11[10][2][1]*s10))));
        Pd[9][0][0] = (N21[10][0][0]*P11[10][0][0]);
        Pd[9][0][1] = (.003627+(N21[10][1][0]*P11[10][0][0]));
        Pd[9][0][2] = (.369954+(N21[10][2][0]*P11[10][0][0]));
        Pd[9][1][0] = (((psiD11[10][1][2]*rikt[10][0][2])+((N21[10][0][0]*
          psiD11[10][1][0])+(psiD11[10][1][1]*rikt[10][0][1])))-.003627);
        Pd[9][1][1] = ((N21[10][1][2]*psiD11[10][1][2])+((N21[10][1][0]*
          psiD11[10][1][0])+(N21[10][1][1]*psiD11[10][1][1])));
        Pd[9][1][2] = ((N21[10][2][2]*psiD11[10][1][2])+((N21[10][2][0]*
          psiD11[10][1][0])+(N21[10][2][1]*psiD11[10][1][1])));
        Pd[9][2][0] = (((psiD11[10][2][2]*rikt[10][0][2])+((N21[10][0][0]*
          psiD11[10][2][0])+(psiD11[10][2][1]*rikt[10][0][1])))-.369954);
        Pd[9][2][1] = ((N21[10][1][2]*psiD11[10][2][2])+((N21[10][1][0]*
          psiD11[10][2][0])+(N21[10][1][1]*psiD11[10][2][1])));
        Pd[9][2][2] = ((N21[10][2][2]*psiD11[10][2][2])+((N21[10][2][0]*
          psiD11[10][2][0])+(N21[10][2][1]*psiD11[10][2][1])));
        P22[9][0][0] = (.0740606155+((psiD21[10][0][2]*rikt[10][0][2])+((
          N21[10][0][0]*psiD21[10][0][0])+(psiD21[10][0][1]*rikt[10][0][1]))));
        P22[9][0][1] = ((N21[10][1][2]*psiD21[10][0][2])+((N21[10][1][0]*
          psiD21[10][0][0])+(N21[10][1][1]*psiD21[10][0][1])));
        P22[9][0][2] = ((N21[10][2][2]*psiD21[10][0][2])+((N21[10][2][0]*
          psiD21[10][0][0])+(N21[10][2][1]*psiD21[10][0][1])));
        P22[9][1][0] = P22[9][0][1];
        P22[9][1][1] = (4.7151e-6+(((N21[10][1][2]*psiD21[10][1][2])+((
          N21[10][1][0]*psiD21[10][1][0])+(N21[10][1][1]*psiD21[10][1][1])))+((
          psiD22[10][1][1]*c10)-(psiD22[10][1][2]*s10))));
        P22[9][1][2] = (.0004809402+(((N21[10][2][2]*psiD21[10][1][2])+((
          N21[10][2][0]*psiD21[10][1][0])+(N21[10][2][1]*psiD21[10][1][1])))+((
          psiD22[10][1][1]*s10)+(psiD22[10][1][2]*c10))));
        P22[9][2][0] = P22[9][0][2];
        P22[9][2][1] = P22[9][1][2];
        P22[9][2][2] = (.0490559004+(((N21[10][2][2]*psiD21[10][2][2])+((
          N21[10][2][0]*psiD21[10][2][0])+(N21[10][2][1]*psiD21[10][2][1])))+((
          psiD22[10][2][1]*s10)+(psiD22[10][2][2]*c10))));
        if (P22[9][0][0] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[9] = (1./P22[9][0][0]);
        }
        G1[9][0] = (DD[9]*Pd[9][0][0]);
        G1[9][1] = (DD[9]*Pd[9][1][0]);
        G1[9][2] = (DD[9]*Pd[9][2][0]);
        G2[9][1] = (DD[9]*P22[9][1][0]);
        G2[9][2] = (DD[9]*P22[9][2][0]);
        P11[9][0][0] = (P11[9][0][0]-(G1[9][0]*Pd[9][0][0]));
        P11[9][0][1] = (P11[9][0][1]-(G1[9][1]*Pd[9][0][0]));
        P11[9][0][2] = (P11[9][0][2]-(G1[9][2]*Pd[9][0][0]));
        P11[9][1][1] = (P11[9][1][1]-(G1[9][1]*Pd[9][1][0]));
        P11[9][1][2] = (P11[9][1][2]-(G1[9][2]*Pd[9][1][0]));
        P11[9][2][2] = (P11[9][2][2]-(G1[9][2]*Pd[9][2][0]));
        Pd[9][0][1] = (Pd[9][0][1]-(G2[9][1]*Pd[9][0][0]));
        Pd[9][0][2] = (Pd[9][0][2]-(G2[9][2]*Pd[9][0][0]));
        Pd[9][1][1] = (Pd[9][1][1]-(G2[9][1]*Pd[9][1][0]));
        Pd[9][1][2] = (Pd[9][1][2]-(G2[9][2]*Pd[9][1][0]));
        Pd[9][2][1] = (Pd[9][2][1]-(G2[9][1]*Pd[9][2][0]));
        Pd[9][2][2] = (Pd[9][2][2]-(G2[9][2]*Pd[9][2][0]));
        P22[9][0][1] = (P22[9][0][1]-P22[9][1][0]);
        P22[9][0][2] = (P22[9][0][2]-P22[9][2][0]);
        P22[9][1][1] = (P22[9][1][1]-(G2[9][1]*P22[9][1][0]));
        P22[9][1][2] = (P22[9][1][2]-(G2[9][2]*P22[9][1][0]));
        P22[9][2][2] = (P22[9][2][2]-(G2[9][2]*P22[9][2][0]));
        sD1INV[0][0] = 0.;
        if (P11[9][0][0] >= 1e-13) {
            sD1INV[0][0] = (1./P11[9][0][0]);
        }
        sL11[1][0] = (P11[9][0][1]*sD1INV[0][0]);
        sL11[2][0] = (P11[9][0][2]*sD1INV[0][0]);
        sL11D1[1][1] = (P11[9][1][1]-(P11[9][0][1]*sL11[1][0]));
        sL11D1[2][1] = (P11[9][1][2]-(P11[9][0][2]*sL11[1][0]));
        sL11D1[2][2] = (P11[9][2][2]-(P11[9][0][2]*sL11[2][0]));
        sD1INV[1][1] = 0.;
        if (sL11D1[1][1] >= 1e-13) {
            sD1INV[1][1] = (1./sL11D1[1][1]);
        }
        sL11[2][1] = (sD1INV[1][1]*sL11D1[2][1]);
        sL11D1[2][2] = (sL11D1[2][2]-(sL11[2][1]*sL11D1[2][1]));
        sD1INV[2][2] = 0.;
        if (sL11D1[2][2] >= 1e-13) {
            sD1INV[2][2] = (1./sL11D1[2][2]);
        }
        sD1L21[1][1] = (Pd[9][1][1]-(Pd[9][0][1]*sL11[1][0]));
        sD1L21[1][2] = (Pd[9][1][2]-(Pd[9][0][2]*sL11[1][0]));
        sD1L21[2][1] = (Pd[9][2][1]-((Pd[9][0][1]*sL11[2][0])+(sD1L21[1][1]*
          sL11[2][1])));
        sD1L21[2][2] = (Pd[9][2][2]-((Pd[9][0][2]*sL11[2][0])+(sD1L21[1][2]*
          sL11[2][1])));
        sL21[1][0] = (Pd[9][0][1]*sD1INV[0][0]);
        sL21[1][1] = (sD1INV[1][1]*sD1L21[1][1]);
        sL21[1][2] = (sD1INV[2][2]*sD1L21[2][1]);
        sL21[2][0] = (Pd[9][0][2]*sD1INV[0][0]);
        sL21[2][1] = (sD1INV[1][1]*sD1L21[1][2]);
        sL21[2][2] = (sD1INV[2][2]*sD1L21[2][2]);
        sL22D2[1][1] = (P22[9][1][1]-((sD1L21[2][1]*sL21[1][2])+((Pd[9][0][1]*
          sL21[1][0])+(sD1L21[1][1]*sL21[1][1]))));
        sL22D2[2][1] = (P22[9][1][2]-((sD1L21[2][1]*sL21[2][2])+((Pd[9][0][1]*
          sL21[2][0])+(sD1L21[1][1]*sL21[2][1]))));
        sL22D2[2][2] = (P22[9][2][2]-((sD1L21[2][2]*sL21[2][2])+((Pd[9][0][2]*
          sL21[2][0])+(sD1L21[1][2]*sL21[2][1]))));
        sD2INV[1][1] = 0.;
        if (sL22D2[1][1] >= 1e-13) {
            sD2INV[1][1] = (1./sL22D2[1][1]);
        }
        sL22[2][1] = (sD2INV[1][1]*sL22D2[2][1]);
        sL22D2[2][2] = (sL22D2[2][2]-(sL22[2][1]*sL22D2[2][1]));
        N11[9][1][0] = ((sL11[1][0]*c9)-(sL11[2][0]*s9));
        N11[9][1][1] = (c9-(sL11[2][1]*s9));
        N11[9][2][0] = ((sL11[1][0]*s9)+(sL11[2][0]*c9));
        N11[9][2][1] = (s9+(sL11[2][1]*c9));
        N21[9][0][0] = ((rikt[9][0][1]*sL11[1][0])+(rikt[9][0][2]*sL11[2][0]));
        N21[9][0][1] = (rikt[9][0][1]+(rikt[9][0][2]*sL11[2][1]));
        N21[9][1][0] = (((.1768*(sL11[2][0]*c9))+((.1768*(sL11[1][0]*s9))-.0338)
          )+((sL21[1][0]*c9)-(sL21[2][0]*s9)));
        N21[9][1][1] = ((.1768*(s9+(sL11[2][1]*c9)))+((sL21[1][1]*c9)-(
          sL21[2][1]*s9)));
        N21[9][1][2] = ((.1768*c9)+((sL21[1][2]*c9)-(sL21[2][2]*s9)));
        N21[9][2][0] = (((.1768*(sL11[2][0]*s9))-(.3354+(.1768*(sL11[1][0]*c9)))
          )+((sL21[1][0]*s9)+(sL21[2][0]*c9)));
        N21[9][2][1] = ((.1768*((sL11[2][1]*s9)-c9))+((sL21[1][1]*s9)+(
          sL21[2][1]*c9)));
        N21[9][2][2] = ((.1768*s9)+((sL21[1][2]*s9)+(sL21[2][2]*c9)));
        N22[9][1][1] = (c9-(sL22[2][1]*s9));
        N22[9][2][1] = (s9+(sL22[2][1]*c9));
        psiD11[9][1][0] = (N11[9][1][0]*P11[9][0][0]);
        psiD11[9][1][1] = (N11[9][1][1]*sL11D1[1][1]);
        psiD11[9][1][2] = -(sL11D1[2][2]*s9);
        psiD11[9][2][0] = (N11[9][2][0]*P11[9][0][0]);
        psiD11[9][2][1] = (N11[9][2][1]*sL11D1[1][1]);
        psiD11[9][2][2] = (sL11D1[2][2]*c9);
        psiD21[9][0][0] = (N21[9][0][0]*P11[9][0][0]);
        psiD21[9][0][1] = (N21[9][0][1]*sL11D1[1][1]);
        psiD21[9][0][2] = (rikt[9][0][2]*sL11D1[2][2]);
        psiD21[9][1][0] = (N21[9][1][0]*P11[9][0][0]);
        psiD21[9][1][1] = (N21[9][1][1]*sL11D1[1][1]);
        psiD21[9][1][2] = (N21[9][1][2]*sL11D1[2][2]);
        psiD21[9][2][0] = (N21[9][2][0]*P11[9][0][0]);
        psiD21[9][2][1] = (N21[9][2][1]*sL11D1[1][1]);
        psiD21[9][2][2] = (N21[9][2][2]*sL11D1[2][2]);
        psiD22[9][1][1] = (N22[9][1][1]*sL22D2[1][1]);
        psiD22[9][1][2] = -(sL22D2[2][2]*s9);
        psiD22[9][2][1] = (N22[9][2][1]*sL22D2[1][1]);
        psiD22[9][2][2] = (sL22D2[2][2]*c9);
        P11[3][0][0] = (29.27+P11[9][0][0]);
        P11[3][0][1] = (N11[9][1][0]*P11[9][0][0]);
        P11[3][0][2] = (N11[9][2][0]*P11[9][0][0]);
        P11[3][1][0] = P11[3][0][1];
        P11[3][1][1] = (29.27+(((N11[9][1][0]*psiD11[9][1][0])+(N11[9][1][1]*
          psiD11[9][1][1]))-(psiD11[9][1][2]*s9)));
        P11[3][1][2] = ((psiD11[9][1][2]*c9)+((N11[9][2][0]*psiD11[9][1][0])+(
          N11[9][2][1]*psiD11[9][1][1])));
        P11[3][2][0] = P11[3][0][2];
        P11[3][2][1] = P11[3][1][2];
        P11[3][2][2] = (29.27+((psiD11[9][2][2]*c9)+((N11[9][2][0]*
          psiD11[9][2][0])+(N11[9][2][1]*psiD11[9][2][1]))));
        Pd[3][0][0] = (N21[9][0][0]*P11[9][0][0]);
        Pd[3][0][1] = ((N21[9][1][0]*P11[9][0][0])-1.027377);
        Pd[3][0][2] = ((N21[9][2][0]*P11[9][0][0])-4.2807375);
        Pd[3][1][0] = (1.027377+((psiD11[9][1][2]*rikt[9][0][2])+((N21[9][0][0]*
          psiD11[9][1][0])+(N21[9][0][1]*psiD11[9][1][1]))));
        Pd[3][1][1] = ((N21[9][1][2]*psiD11[9][1][2])+((N21[9][1][0]*
          psiD11[9][1][0])+(N21[9][1][1]*psiD11[9][1][1])));
        Pd[3][1][2] = ((N21[9][2][2]*psiD11[9][1][2])+((N21[9][2][0]*
          psiD11[9][1][0])+(N21[9][2][1]*psiD11[9][1][1])));
        Pd[3][2][0] = (4.2807375+((psiD11[9][2][2]*rikt[9][0][2])+((N21[9][0][0]
          *psiD11[9][2][0])+(N21[9][0][1]*psiD11[9][2][1]))));
        Pd[3][2][1] = ((N21[9][1][2]*psiD11[9][2][2])+((N21[9][1][0]*
          psiD11[9][2][0])+(N21[9][1][1]*psiD11[9][2][1])));
        Pd[3][2][2] = ((N21[9][2][2]*psiD11[9][2][2])+((N21[9][2][0]*
          psiD11[9][2][0])+(N21[9][2][1]*psiD11[9][2][1])));
        P22[3][0][0] = (1.292118792075+((psiD21[9][0][2]*rikt[9][0][2])+((
          N21[9][0][0]*psiD21[9][0][0])+(N21[9][0][1]*psiD21[9][0][1]))));
        P22[3][0][1] = ((N21[9][1][2]*psiD21[9][0][2])+((N21[9][1][0]*
          psiD21[9][0][0])+(N21[9][1][1]*psiD21[9][0][1])));
        P22[3][0][2] = ((N21[9][2][2]*psiD21[9][0][2])+((N21[9][2][0]*
          psiD21[9][0][0])+(N21[9][2][1]*psiD21[9][0][1])));
        P22[3][1][0] = P22[3][0][1];
        P22[3][1][1] = (.0360609327+(((N21[9][1][2]*psiD21[9][1][2])+((
          N21[9][1][0]*psiD21[9][1][0])+(N21[9][1][1]*psiD21[9][1][1])))+((
          N22[9][1][1]*psiD22[9][1][1])-(psiD22[9][1][2]*s9))));
        P22[3][1][2] = (.15025388625+(((N21[9][2][2]*psiD21[9][1][2])+((
          N21[9][2][0]*psiD21[9][1][0])+(N21[9][2][1]*psiD21[9][1][1])))+((
          N22[9][2][1]*psiD22[9][1][1])+(psiD22[9][1][2]*c9))));
        P22[3][2][0] = P22[3][0][2];
        P22[3][2][1] = P22[3][1][2];
        P22[3][2][2] = (.626057859375+(((N21[9][2][2]*psiD21[9][2][2])+((
          N21[9][2][0]*psiD21[9][2][0])+(N21[9][2][1]*psiD21[9][2][1])))+((
          N22[9][2][1]*psiD22[9][2][1])+(psiD22[9][2][2]*c9))));
        DD[8] = 254.858235106722;
        N21[8][0][2] = -(.2756+(.065*c8));
        P11[7][0][0] = (1.43427524689392+(.325724753106085*(s8*s8)));
        P11[7][0][1] = -(.325724753106085*(s8*c8));
        P11[7][1][0] = P11[7][0][1];
        P11[7][1][1] = (1.43427524689392+(.325724753106085*(c8*c8)));
        Pd[7][0][2] = (.228548258043963+(.089769741956037*(s8*s8)));
        Pd[7][1][2] = -(.004719+(.089769741956037*(s8*c8)));
        Pd[7][2][0] = ((.55*N21[8][0][2])-.166738);
        Pd[7][2][1] = (.004719-(.03575*s8));
        P22[7][0][0] = (.0288764964+((.0015*(s8*s8))+(.55*(N21[8][0][2]*
          N21[8][0][2]))));
        P22[7][0][1] = -(.0006502782+((.0015*(s8*c8))+(.03575*(N21[8][0][2]*s8))
          ));
        P22[7][1][0] = P22[7][0][1];
        P22[7][1][1] = (.0020184041+(.00082375*(s8*s8)));
        P22[7][2][2] = (.0400298076169162+(.0247405408830838*(s8*s8)));
        if (P22[7][0][0] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[7] = (1./P22[7][0][0]);
        }
        G1[7][2] = (DD[7]*Pd[7][2][0]);
        G2[7][1] = (DD[7]*P22[7][1][0]);
        P11[7][2][2] = (1.76-(G1[7][2]*Pd[7][2][0]));
        Pd[7][2][1] = (Pd[7][2][1]-(G2[7][1]*Pd[7][2][0]));
        P22[7][0][1] = (P22[7][0][1]-P22[7][1][0]);
        P22[7][1][1] = (P22[7][1][1]-(G2[7][1]*P22[7][1][0]));
        sD1INV[0][0] = 0.;
        if (P11[7][0][0] >= 1e-13) {
            sD1INV[0][0] = (1./P11[7][0][0]);
        }
        sL11[1][0] = (P11[7][0][1]*sD1INV[0][0]);
        sL11D1[1][1] = (P11[7][1][1]-(P11[7][0][1]*sL11[1][0]));
        sD1INV[1][1] = 0.;
        if (sL11D1[1][1] >= 1e-13) {
            sD1INV[1][1] = (1./sL11D1[1][1]);
        }
        sD1INV[2][2] = 0.;
        if (P11[7][2][2] >= 1e-13) {
            sD1INV[2][2] = (1./P11[7][2][2]);
        }
        sD1L21[1][2] = (Pd[7][1][2]-(Pd[7][0][2]*sL11[1][0]));
        sL21[1][2] = (Pd[7][2][1]*sD1INV[2][2]);
        sL21[2][0] = (Pd[7][0][2]*sD1INV[0][0]);
        sL21[2][1] = (sD1INV[1][1]*sD1L21[1][2]);
        sL22D2[1][1] = (P22[7][1][1]-(Pd[7][2][1]*sL21[1][2]));
        sL22D2[2][2] = (P22[7][2][2]-((Pd[7][0][2]*sL21[2][0])+(sD1L21[1][2]*
          sL21[2][1])));
        sD2INV[1][1] = 0.;
        if (sL22D2[1][1] >= 1e-13) {
            sD2INV[1][1] = (1./sL22D2[1][1]);
        }
        N11[7][1][0] = (sL11[1][0]*c7);
        N11[7][2][0] = (sL11[1][0]*s7);
        N21[7][0][0] = (rikt[7][0][1]*sL11[1][0]);
        N21[7][1][0] = (.0026-(sL21[2][0]*s7));
        N21[7][1][1] = -(sL21[2][1]*s7);
        N21[7][1][2] = (sL21[1][2]*c7);
        N21[7][2][0] = (.2652+(sL21[2][0]*c7));
        N21[7][2][1] = (sL21[2][1]*c7);
        N21[7][2][2] = (sL21[1][2]*s7);
        psiD11[7][1][0] = (N11[7][1][0]*P11[7][0][0]);
        psiD11[7][1][1] = (sL11D1[1][1]*c7);
        psiD11[7][1][2] = -(P11[7][2][2]*s7);
        psiD11[7][2][0] = (N11[7][2][0]*P11[7][0][0]);
        psiD11[7][2][1] = (sL11D1[1][1]*s7);
        psiD11[7][2][2] = (P11[7][2][2]*c7);
        psiD21[7][0][0] = (N21[7][0][0]*P11[7][0][0]);
        psiD21[7][0][1] = (rikt[7][0][1]*sL11D1[1][1]);
        psiD21[7][0][2] = (P11[7][2][2]*rikt[7][0][2]);
        psiD21[7][1][0] = (N21[7][1][0]*P11[7][0][0]);
        psiD21[7][1][1] = (N21[7][1][1]*sL11D1[1][1]);
        psiD21[7][1][2] = (N21[7][1][2]*P11[7][2][2]);
        psiD21[7][2][0] = (N21[7][2][0]*P11[7][0][0]);
        psiD21[7][2][1] = (N21[7][2][1]*sL11D1[1][1]);
        psiD21[7][2][2] = (N21[7][2][2]*P11[7][2][2]);
        psiD22[7][1][1] = (sL22D2[1][1]*c7);
        psiD22[7][1][2] = -(sL22D2[2][2]*s7);
        psiD22[7][2][1] = (sL22D2[1][1]*s7);
        psiD22[7][2][2] = (sL22D2[2][2]*c7);
        P11[6][0][0] = (2.79+P11[7][0][0]);
        P11[6][0][1] = (N11[7][1][0]*P11[7][0][0]);
        P11[6][0][2] = (N11[7][2][0]*P11[7][0][0]);
        P11[6][1][0] = P11[6][0][1];
        P11[6][1][1] = (2.79+(((N11[7][1][0]*psiD11[7][1][0])+(psiD11[7][1][1]*
          c7))-(psiD11[7][1][2]*s7)));
        P11[6][1][2] = ((psiD11[7][1][2]*c7)+((N11[7][2][0]*psiD11[7][1][0])+(
          psiD11[7][1][1]*s7)));
        P11[6][2][0] = P11[6][0][2];
        P11[6][2][1] = P11[6][1][2];
        P11[6][2][2] = (2.79+((psiD11[7][2][2]*c7)+((N11[7][2][0]*
          psiD11[7][2][0])+(psiD11[7][2][1]*s7))));
        Pd[6][0][0] = (N21[7][0][0]*P11[7][0][0]);
        Pd[6][0][1] = (.003627+(N21[7][1][0]*P11[7][0][0]));
        Pd[6][0][2] = (.369954+(N21[7][2][0]*P11[7][0][0]));
        Pd[6][1][0] = (((psiD11[7][1][2]*rikt[7][0][2])+((N21[7][0][0]*
          psiD11[7][1][0])+(psiD11[7][1][1]*rikt[7][0][1])))-.003627);
        Pd[6][1][1] = ((N21[7][1][2]*psiD11[7][1][2])+((N21[7][1][0]*
          psiD11[7][1][0])+(N21[7][1][1]*psiD11[7][1][1])));
        Pd[6][1][2] = ((N21[7][2][2]*psiD11[7][1][2])+((N21[7][2][0]*
          psiD11[7][1][0])+(N21[7][2][1]*psiD11[7][1][1])));
        Pd[6][2][0] = (((psiD11[7][2][2]*rikt[7][0][2])+((N21[7][0][0]*
          psiD11[7][2][0])+(psiD11[7][2][1]*rikt[7][0][1])))-.369954);
        Pd[6][2][1] = ((N21[7][1][2]*psiD11[7][2][2])+((N21[7][1][0]*
          psiD11[7][2][0])+(N21[7][1][1]*psiD11[7][2][1])));
        Pd[6][2][2] = ((N21[7][2][2]*psiD11[7][2][2])+((N21[7][2][0]*
          psiD11[7][2][0])+(N21[7][2][1]*psiD11[7][2][1])));
        P22[6][0][0] = (.0740606155+((psiD21[7][0][2]*rikt[7][0][2])+((
          N21[7][0][0]*psiD21[7][0][0])+(psiD21[7][0][1]*rikt[7][0][1]))));
        P22[6][0][1] = ((N21[7][1][2]*psiD21[7][0][2])+((N21[7][1][0]*
          psiD21[7][0][0])+(N21[7][1][1]*psiD21[7][0][1])));
        P22[6][0][2] = ((N21[7][2][2]*psiD21[7][0][2])+((N21[7][2][0]*
          psiD21[7][0][0])+(N21[7][2][1]*psiD21[7][0][1])));
        P22[6][1][0] = P22[6][0][1];
        P22[6][1][1] = (4.7151e-6+(((N21[7][1][2]*psiD21[7][1][2])+((
          N21[7][1][0]*psiD21[7][1][0])+(N21[7][1][1]*psiD21[7][1][1])))+((
          psiD22[7][1][1]*c7)-(psiD22[7][1][2]*s7))));
        P22[6][1][2] = (.0004809402+(((N21[7][2][2]*psiD21[7][1][2])+((
          N21[7][2][0]*psiD21[7][1][0])+(N21[7][2][1]*psiD21[7][1][1])))+((
          psiD22[7][1][1]*s7)+(psiD22[7][1][2]*c7))));
        P22[6][2][0] = P22[6][0][2];
        P22[6][2][1] = P22[6][1][2];
        P22[6][2][2] = (.0490559004+(((N21[7][2][2]*psiD21[7][2][2])+((
          N21[7][2][0]*psiD21[7][2][0])+(N21[7][2][1]*psiD21[7][2][1])))+((
          psiD22[7][2][1]*s7)+(psiD22[7][2][2]*c7))));
        if (P22[6][0][0] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[6] = (1./P22[6][0][0]);
        }
        G1[6][0] = (DD[6]*Pd[6][0][0]);
        G1[6][1] = (DD[6]*Pd[6][1][0]);
        G1[6][2] = (DD[6]*Pd[6][2][0]);
        G2[6][1] = (DD[6]*P22[6][1][0]);
        G2[6][2] = (DD[6]*P22[6][2][0]);
        P11[6][0][0] = (P11[6][0][0]-(G1[6][0]*Pd[6][0][0]));
        P11[6][0][1] = (P11[6][0][1]-(G1[6][1]*Pd[6][0][0]));
        P11[6][0][2] = (P11[6][0][2]-(G1[6][2]*Pd[6][0][0]));
        P11[6][1][1] = (P11[6][1][1]-(G1[6][1]*Pd[6][1][0]));
        P11[6][1][2] = (P11[6][1][2]-(G1[6][2]*Pd[6][1][0]));
        P11[6][2][2] = (P11[6][2][2]-(G1[6][2]*Pd[6][2][0]));
        Pd[6][0][1] = (Pd[6][0][1]-(G2[6][1]*Pd[6][0][0]));
        Pd[6][0][2] = (Pd[6][0][2]-(G2[6][2]*Pd[6][0][0]));
        Pd[6][1][1] = (Pd[6][1][1]-(G2[6][1]*Pd[6][1][0]));
        Pd[6][1][2] = (Pd[6][1][2]-(G2[6][2]*Pd[6][1][0]));
        Pd[6][2][1] = (Pd[6][2][1]-(G2[6][1]*Pd[6][2][0]));
        Pd[6][2][2] = (Pd[6][2][2]-(G2[6][2]*Pd[6][2][0]));
        P22[6][0][1] = (P22[6][0][1]-P22[6][1][0]);
        P22[6][0][2] = (P22[6][0][2]-P22[6][2][0]);
        P22[6][1][1] = (P22[6][1][1]-(G2[6][1]*P22[6][1][0]));
        P22[6][1][2] = (P22[6][1][2]-(G2[6][2]*P22[6][1][0]));
        P22[6][2][2] = (P22[6][2][2]-(G2[6][2]*P22[6][2][0]));
        sD1INV[0][0] = 0.;
        if (P11[6][0][0] >= 1e-13) {
            sD1INV[0][0] = (1./P11[6][0][0]);
        }
        sL11[1][0] = (P11[6][0][1]*sD1INV[0][0]);
        sL11[2][0] = (P11[6][0][2]*sD1INV[0][0]);
        sL11D1[1][1] = (P11[6][1][1]-(P11[6][0][1]*sL11[1][0]));
        sL11D1[2][1] = (P11[6][1][2]-(P11[6][0][2]*sL11[1][0]));
        sL11D1[2][2] = (P11[6][2][2]-(P11[6][0][2]*sL11[2][0]));
        sD1INV[1][1] = 0.;
        if (sL11D1[1][1] >= 1e-13) {
            sD1INV[1][1] = (1./sL11D1[1][1]);
        }
        sL11[2][1] = (sD1INV[1][1]*sL11D1[2][1]);
        sL11D1[2][2] = (sL11D1[2][2]-(sL11[2][1]*sL11D1[2][1]));
        sD1INV[2][2] = 0.;
        if (sL11D1[2][2] >= 1e-13) {
            sD1INV[2][2] = (1./sL11D1[2][2]);
        }
        sD1L21[1][1] = (Pd[6][1][1]-(Pd[6][0][1]*sL11[1][0]));
        sD1L21[1][2] = (Pd[6][1][2]-(Pd[6][0][2]*sL11[1][0]));
        sD1L21[2][1] = (Pd[6][2][1]-((Pd[6][0][1]*sL11[2][0])+(sD1L21[1][1]*
          sL11[2][1])));
        sD1L21[2][2] = (Pd[6][2][2]-((Pd[6][0][2]*sL11[2][0])+(sD1L21[1][2]*
          sL11[2][1])));
        sL21[1][0] = (Pd[6][0][1]*sD1INV[0][0]);
        sL21[1][1] = (sD1INV[1][1]*sD1L21[1][1]);
        sL21[1][2] = (sD1INV[2][2]*sD1L21[2][1]);
        sL21[2][0] = (Pd[6][0][2]*sD1INV[0][0]);
        sL21[2][1] = (sD1INV[1][1]*sD1L21[1][2]);
        sL21[2][2] = (sD1INV[2][2]*sD1L21[2][2]);
        sL22D2[1][1] = (P22[6][1][1]-((sD1L21[2][1]*sL21[1][2])+((Pd[6][0][1]*
          sL21[1][0])+(sD1L21[1][1]*sL21[1][1]))));
        sL22D2[2][1] = (P22[6][1][2]-((sD1L21[2][1]*sL21[2][2])+((Pd[6][0][1]*
          sL21[2][0])+(sD1L21[1][1]*sL21[2][1]))));
        sL22D2[2][2] = (P22[6][2][2]-((sD1L21[2][2]*sL21[2][2])+((Pd[6][0][2]*
          sL21[2][0])+(sD1L21[1][2]*sL21[2][1]))));
        sD2INV[1][1] = 0.;
        if (sL22D2[1][1] >= 1e-13) {
            sD2INV[1][1] = (1./sL22D2[1][1]);
        }
        sL22[2][1] = (sD2INV[1][1]*sL22D2[2][1]);
        sL22D2[2][2] = (sL22D2[2][2]-(sL22[2][1]*sL22D2[2][1]));
        N11[6][1][0] = ((sL11[1][0]*c6)-(sL11[2][0]*s6));
        N11[6][1][1] = (c6-(sL11[2][1]*s6));
        N11[6][2][0] = ((sL11[1][0]*s6)+(sL11[2][0]*c6));
        N11[6][2][1] = (s6+(sL11[2][1]*c6));
        N21[6][0][0] = ((rikt[6][0][1]*sL11[1][0])+(rikt[6][0][2]*sL11[2][0]));
        N21[6][0][1] = (rikt[6][0][1]+(rikt[6][0][2]*sL11[2][1]));
        N21[6][1][0] = (((sL21[1][0]*c6)-(sL21[2][0]*s6))-(.0338+(.1768*((
          sL11[1][0]*s6)+(sL11[2][0]*c6)))));
        N21[6][1][1] = (((sL21[1][1]*c6)-(sL21[2][1]*s6))-(.1768*(s6+(sL11[2][1]
          *c6))));
        N21[6][1][2] = (((sL21[1][2]*c6)-(sL21[2][2]*s6))-(.1768*c6));
        N21[6][2][0] = (((sL21[1][0]*s6)+(sL21[2][0]*c6))+(((.1768*(sL11[1][0]*
          c6))-.3354)-(.1768*(sL11[2][0]*s6))));
        N21[6][2][1] = ((.1768*(c6-(sL11[2][1]*s6)))+((sL21[1][1]*s6)+(
          sL21[2][1]*c6)));
        N21[6][2][2] = (((sL21[1][2]*s6)+(sL21[2][2]*c6))-(.1768*s6));
        N22[6][1][1] = (c6-(sL22[2][1]*s6));
        N22[6][2][1] = (s6+(sL22[2][1]*c6));
        psiD11[6][1][0] = (N11[6][1][0]*P11[6][0][0]);
        psiD11[6][1][1] = (N11[6][1][1]*sL11D1[1][1]);
        psiD11[6][1][2] = -(sL11D1[2][2]*s6);
        psiD11[6][2][0] = (N11[6][2][0]*P11[6][0][0]);
        psiD11[6][2][1] = (N11[6][2][1]*sL11D1[1][1]);
        psiD11[6][2][2] = (sL11D1[2][2]*c6);
        psiD21[6][0][0] = (N21[6][0][0]*P11[6][0][0]);
        psiD21[6][0][1] = (N21[6][0][1]*sL11D1[1][1]);
        psiD21[6][0][2] = (rikt[6][0][2]*sL11D1[2][2]);
        psiD21[6][1][0] = (N21[6][1][0]*P11[6][0][0]);
        psiD21[6][1][1] = (N21[6][1][1]*sL11D1[1][1]);
        psiD21[6][1][2] = (N21[6][1][2]*sL11D1[2][2]);
        psiD21[6][2][0] = (N21[6][2][0]*P11[6][0][0]);
        psiD21[6][2][1] = (N21[6][2][1]*sL11D1[1][1]);
        psiD21[6][2][2] = (N21[6][2][2]*sL11D1[2][2]);
        psiD22[6][1][1] = (N22[6][1][1]*sL22D2[1][1]);
        psiD22[6][1][2] = -(sL22D2[2][2]*s6);
        psiD22[6][2][1] = (N22[6][2][1]*sL22D2[1][1]);
        psiD22[6][2][2] = (sL22D2[2][2]*c6);
        P11[3][0][0] = (P11[3][0][0]+P11[6][0][0]);
        P11[3][0][1] = (P11[3][0][1]+(N11[6][1][0]*P11[6][0][0]));
        P11[3][0][2] = (P11[3][0][2]+(N11[6][2][0]*P11[6][0][0]));
        P11[3][1][0] = P11[3][0][1];
        P11[3][1][1] = (P11[3][1][1]+(((N11[6][1][0]*psiD11[6][1][0])+(
          N11[6][1][1]*psiD11[6][1][1]))-(psiD11[6][1][2]*s6)));
        P11[3][1][2] = (P11[3][1][2]+((psiD11[6][1][2]*c6)+((N11[6][2][0]*
          psiD11[6][1][0])+(N11[6][2][1]*psiD11[6][1][1]))));
        P11[3][2][0] = P11[3][0][2];
        P11[3][2][1] = P11[3][1][2];
        P11[3][2][2] = (P11[3][2][2]+((psiD11[6][2][2]*c6)+((N11[6][2][0]*
          psiD11[6][2][0])+(N11[6][2][1]*psiD11[6][2][1]))));
        Pd[3][0][0] = (Pd[3][0][0]+(N21[6][0][0]*P11[6][0][0]));
        Pd[3][0][1] = (Pd[3][0][1]+(N21[6][1][0]*P11[6][0][0]));
        Pd[3][0][2] = (Pd[3][0][2]+(N21[6][2][0]*P11[6][0][0]));
        Pd[3][1][0] = (Pd[3][1][0]+((psiD11[6][1][2]*rikt[6][0][2])+((
          N21[6][0][0]*psiD11[6][1][0])+(N21[6][0][1]*psiD11[6][1][1]))));
        Pd[3][1][1] = (Pd[3][1][1]+((N21[6][1][2]*psiD11[6][1][2])+((
          N21[6][1][0]*psiD11[6][1][0])+(N21[6][1][1]*psiD11[6][1][1]))));
        Pd[3][1][2] = (Pd[3][1][2]+((N21[6][2][2]*psiD11[6][1][2])+((
          N21[6][2][0]*psiD11[6][1][0])+(N21[6][2][1]*psiD11[6][1][1]))));
        Pd[3][2][0] = (Pd[3][2][0]+((psiD11[6][2][2]*rikt[6][0][2])+((
          N21[6][0][0]*psiD11[6][2][0])+(N21[6][0][1]*psiD11[6][2][1]))));
        Pd[3][2][1] = (Pd[3][2][1]+((N21[6][1][2]*psiD11[6][2][2])+((
          N21[6][1][0]*psiD11[6][2][0])+(N21[6][1][1]*psiD11[6][2][1]))));
        Pd[3][2][2] = (Pd[3][2][2]+((N21[6][2][2]*psiD11[6][2][2])+((
          N21[6][2][0]*psiD11[6][2][0])+(N21[6][2][1]*psiD11[6][2][1]))));
        P22[3][0][0] = (P22[3][0][0]+((psiD21[6][0][2]*rikt[6][0][2])+((
          N21[6][0][0]*psiD21[6][0][0])+(N21[6][0][1]*psiD21[6][0][1]))));
        P22[3][0][1] = (P22[3][0][1]+((N21[6][1][2]*psiD21[6][0][2])+((
          N21[6][1][0]*psiD21[6][0][0])+(N21[6][1][1]*psiD21[6][0][1]))));
        P22[3][0][2] = (P22[3][0][2]+((N21[6][2][2]*psiD21[6][0][2])+((
          N21[6][2][0]*psiD21[6][0][0])+(N21[6][2][1]*psiD21[6][0][1]))));
        P22[3][1][0] = P22[3][0][1];
        P22[3][1][1] = (P22[3][1][1]+(((N21[6][1][2]*psiD21[6][1][2])+((
          N21[6][1][0]*psiD21[6][1][0])+(N21[6][1][1]*psiD21[6][1][1])))+((
          N22[6][1][1]*psiD22[6][1][1])-(psiD22[6][1][2]*s6))));
        P22[3][1][2] = (P22[3][1][2]+(((N21[6][2][2]*psiD21[6][1][2])+((
          N21[6][2][0]*psiD21[6][1][0])+(N21[6][2][1]*psiD21[6][1][1])))+((
          N22[6][2][1]*psiD22[6][1][1])+(psiD22[6][1][2]*c6))));
        P22[3][2][0] = P22[3][0][2];
        P22[3][2][1] = P22[3][1][2];
        P22[3][2][2] = (P22[3][2][2]+(((N21[6][2][2]*psiD21[6][2][2])+((
          N21[6][2][0]*psiD21[6][2][0])+(N21[6][2][1]*psiD21[6][2][1])))+((
          N22[6][2][1]*psiD22[6][2][1])+(psiD22[6][2][2]*c6))));
        DD[5] = 13.4105204266794;
        N11[5][1][1] = (c5-(.208236420087758*s5));
        N11[5][2][1] = (s5+(.208236420087758*c5));
        N21[5][0][1] = (rikt[5][0][1]+(.208236420087758*rikt[5][0][2]));
        N21[5][1][0] = (.013+((.0312*c5)+(.078*s5)));
        N21[5][2][0] = (((.0312*s5)-(.078*c5))-.0884);
        P11[4][1][1] = (1.+((2.82371871420776*(s5*s5))+(5.43711763521844*(
          N11[5][1][1]*N11[5][1][1]))));
        P11[4][1][2] = ((5.43711763521844*(N11[5][1][1]*N11[5][2][1]))-(
          2.82371871420776*(s5*c5)));
        P11[4][2][1] = P11[4][1][2];
        P11[4][2][2] = (1.+((2.82371871420776*(c5*c5))+(5.43711763521844*(
          N11[5][2][1]*N11[5][2][1]))));
        Pd[4][0][1] = (.0065+(5.89*N21[5][1][0]));
        Pd[4][0][2] = ((5.89*N21[5][2][0])-.0442);
        Pd[4][1][0] = (((5.43711763521844*(N11[5][1][1]*N21[5][0][1]))-(
          2.82371871420776*(rikt[5][0][2]*s5)))-.0065);
        Pd[4][2][0] = (.0442+((2.82371871420776*(rikt[5][0][2]*c5))+(
          5.43711763521844*(N11[5][2][1]*N21[5][0][1]))));
        P22[4][0][0] = (.00799589+((2.82371871420776*(rikt[5][0][2]*
          rikt[5][0][2]))+(5.43711763521844*(N21[5][0][1]*N21[5][0][1]))));
        P22[4][1][1] = (4.225e-5+(5.89*(N21[5][1][0]*N21[5][1][0])));
        P22[4][1][2] = ((5.89*(N21[5][1][0]*N21[5][2][0]))-.0002873);
        P22[4][2][1] = P22[4][1][2];
        P22[4][2][2] = (.00195364+(5.89*(N21[5][2][0]*N21[5][2][0])));
        if (P22[4][0][0] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[4] = (1./P22[4][0][0]);
        }
        G1[4][1] = (DD[4]*Pd[4][1][0]);
        G1[4][2] = (DD[4]*Pd[4][2][0]);
        P11[4][1][1] = (P11[4][1][1]-(G1[4][1]*Pd[4][1][0]));
        P11[4][1][2] = (P11[4][1][2]-(G1[4][2]*Pd[4][1][0]));
        P11[4][2][2] = (P11[4][2][2]-(G1[4][2]*Pd[4][2][0]));
        sD1INV[1][1] = 0.;
        if (P11[4][1][1] >= 1e-13) {
            sD1INV[1][1] = (1./P11[4][1][1]);
        }
        sL11[2][1] = (P11[4][1][2]*sD1INV[1][1]);
        sL11D1[2][2] = (P11[4][2][2]-(P11[4][1][2]*sL11[2][1]));
        sD1INV[2][2] = 0.;
        if (sL11D1[2][2] >= 1e-13) {
            sD1INV[2][2] = (1./sL11D1[2][2]);
        }
        sL22D2[1][1] = (P22[4][1][1]-(.145137880986938*(Pd[4][0][1]*Pd[4][0][1])
          ));
        sL22D2[2][1] = (P22[4][1][2]-(.145137880986938*(Pd[4][0][1]*Pd[4][0][2])
          ));
        sL22D2[2][2] = (P22[4][2][2]-(.145137880986938*(Pd[4][0][2]*Pd[4][0][2])
          ));
        sD2INV[1][1] = 0.;
        if (sL22D2[1][1] >= 1e-13) {
            sD2INV[1][1] = (1./sL22D2[1][1]);
        }
        sL22[2][1] = (sD2INV[1][1]*sL22D2[2][1]);
        sL22D2[2][2] = (sL22D2[2][2]-(sL22[2][1]*sL22D2[2][1]));
        N11[4][1][1] = (c4-(sL11[2][1]*s4));
        N11[4][2][1] = (s4+(sL11[2][1]*c4));
        N21[4][0][1] = (rikt[4][0][1]+(rikt[4][0][2]*sL11[2][1]));
        N21[4][1][0] = ((.145137880986938*((Pd[4][0][1]*c4)-(Pd[4][0][2]*s4)))-
          .0364);
        N21[4][2][0] = ((.145137880986938*((Pd[4][0][1]*s4)+(Pd[4][0][2]*c4)))-
          .3926);
        N22[4][1][1] = (c4-(sL22[2][1]*s4));
        N22[4][2][1] = (s4+(sL22[2][1]*c4));
        psiD11[4][1][1] = (N11[4][1][1]*P11[4][1][1]);
        psiD11[4][1][2] = -(sL11D1[2][2]*s4);
        psiD11[4][2][1] = (N11[4][2][1]*P11[4][1][1]);
        psiD11[4][2][2] = (sL11D1[2][2]*c4);
        psiD21[4][0][1] = (N21[4][0][1]*P11[4][1][1]);
        psiD21[4][0][2] = (rikt[4][0][2]*sL11D1[2][2]);
        psiD22[4][1][1] = (N22[4][1][1]*sL22D2[1][1]);
        psiD22[4][1][2] = -(sL22D2[2][2]*s4);
        psiD22[4][2][1] = (N22[4][2][1]*sL22D2[1][1]);
        psiD22[4][2][2] = (sL22D2[2][2]*c4);
        P11[3][0][0] = (6.89+P11[3][0][0]);
        P11[3][1][0] = P11[3][0][1];
        P11[3][1][1] = (P11[3][1][1]+((N11[4][1][1]*psiD11[4][1][1])-(
          psiD11[4][1][2]*s4)));
        P11[3][1][2] = (P11[3][1][2]+((N11[4][2][1]*psiD11[4][1][1])+(
          psiD11[4][1][2]*c4)));
        P11[3][2][0] = P11[3][0][2];
        P11[3][2][1] = P11[3][1][2];
        P11[3][2][2] = (P11[3][2][2]+((N11[4][2][1]*psiD11[4][2][1])+(
          psiD11[4][2][2]*c4)));
        Pd[3][0][1] = (Pd[3][0][1]+(6.89*N21[4][1][0]));
        Pd[3][0][2] = (Pd[3][0][2]+(6.89*N21[4][2][0]));
        Pd[3][1][0] = (Pd[3][1][0]+((N21[4][0][1]*psiD11[4][1][1])+(
          psiD11[4][1][2]*rikt[4][0][2])));
        Pd[3][2][0] = (Pd[3][2][0]+((N21[4][0][1]*psiD11[4][2][1])+(
          psiD11[4][2][2]*rikt[4][0][2])));
        P22[3][0][0] = (P22[3][0][0]+((N21[4][0][1]*psiD21[4][0][1])+(
          psiD21[4][0][2]*rikt[4][0][2])));
        P22[3][1][0] = P22[3][0][1];
        P22[3][1][1] = (P22[3][1][1]+((6.89*(N21[4][1][0]*N21[4][1][0]))+((
          N22[4][1][1]*psiD22[4][1][1])-(psiD22[4][1][2]*s4))));
        P22[3][1][2] = (P22[3][1][2]+((6.89*(N21[4][1][0]*N21[4][2][0]))+((
          N22[4][2][1]*psiD22[4][1][1])+(psiD22[4][1][2]*c4))));
        P22[3][2][0] = P22[3][0][2];
        P22[3][2][1] = P22[3][1][2];
        P22[3][2][2] = (P22[3][2][2]+((6.89*(N21[4][2][0]*N21[4][2][0]))+((
          N22[4][2][1]*psiD22[4][2][1])+(psiD22[4][2][2]*c4))));
        if (P22[3][0][0] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[3] = (1./P22[3][0][0]);
        }
        G1[3][0] = (DD[3]*Pd[3][0][0]);
        G1[3][1] = (DD[3]*Pd[3][1][0]);
        G1[3][2] = (DD[3]*Pd[3][2][0]);
        G2[3][1] = (DD[3]*P22[3][1][0]);
        G2[3][2] = (DD[3]*P22[3][2][0]);
        P11[3][0][0] = (P11[3][0][0]-(G1[3][0]*Pd[3][0][0]));
        P11[3][0][1] = (P11[3][0][1]-(G1[3][1]*Pd[3][0][0]));
        P11[3][0][2] = (P11[3][0][2]-(G1[3][2]*Pd[3][0][0]));
        P11[3][1][1] = (P11[3][1][1]-(G1[3][1]*Pd[3][1][0]));
        P11[3][1][2] = (P11[3][1][2]-(G1[3][2]*Pd[3][1][0]));
        P11[3][2][2] = (P11[3][2][2]-(G1[3][2]*Pd[3][2][0]));
        Pd[3][0][1] = (Pd[3][0][1]-(G2[3][1]*Pd[3][0][0]));
        Pd[3][0][2] = (Pd[3][0][2]-(G2[3][2]*Pd[3][0][0]));
        Pd[3][1][1] = (Pd[3][1][1]-(G2[3][1]*Pd[3][1][0]));
        Pd[3][1][2] = (Pd[3][1][2]-(G2[3][2]*Pd[3][1][0]));
        Pd[3][2][1] = (Pd[3][2][1]-(G2[3][1]*Pd[3][2][0]));
        Pd[3][2][2] = (Pd[3][2][2]-(G2[3][2]*Pd[3][2][0]));
        P22[3][0][1] = (P22[3][0][1]-P22[3][1][0]);
        P22[3][0][2] = (P22[3][0][2]-P22[3][2][0]);
        P22[3][1][1] = (P22[3][1][1]-(G2[3][1]*P22[3][1][0]));
        P22[3][1][2] = (P22[3][1][2]-(G2[3][2]*P22[3][1][0]));
        P22[3][2][2] = (P22[3][2][2]-(G2[3][2]*P22[3][2][0]));
        sD1INV[0][0] = 0.;
        if (P11[3][0][0] >= 1e-13) {
            sD1INV[0][0] = (1./P11[3][0][0]);
        }
        sL11[1][0] = (P11[3][0][1]*sD1INV[0][0]);
        sL11[2][0] = (P11[3][0][2]*sD1INV[0][0]);
        sL11D1[1][1] = (P11[3][1][1]-(P11[3][0][1]*sL11[1][0]));
        sL11D1[2][1] = (P11[3][1][2]-(P11[3][0][2]*sL11[1][0]));
        sL11D1[2][2] = (P11[3][2][2]-(P11[3][0][2]*sL11[2][0]));
        sD1INV[1][1] = 0.;
        if (sL11D1[1][1] >= 1e-13) {
            sD1INV[1][1] = (1./sL11D1[1][1]);
        }
        sL11[2][1] = (sD1INV[1][1]*sL11D1[2][1]);
        sL11D1[2][2] = (sL11D1[2][2]-(sL11[2][1]*sL11D1[2][1]));
        sD1INV[2][2] = 0.;
        if (sL11D1[2][2] >= 1e-13) {
            sD1INV[2][2] = (1./sL11D1[2][2]);
        }
        sD1L21[1][1] = (Pd[3][1][1]-(Pd[3][0][1]*sL11[1][0]));
        sD1L21[1][2] = (Pd[3][1][2]-(Pd[3][0][2]*sL11[1][0]));
        sD1L21[2][1] = (Pd[3][2][1]-((Pd[3][0][1]*sL11[2][0])+(sD1L21[1][1]*
          sL11[2][1])));
        sD1L21[2][2] = (Pd[3][2][2]-((Pd[3][0][2]*sL11[2][0])+(sD1L21[1][2]*
          sL11[2][1])));
        sL21[1][0] = (Pd[3][0][1]*sD1INV[0][0]);
        sL21[1][1] = (sD1INV[1][1]*sD1L21[1][1]);
        sL21[1][2] = (sD1INV[2][2]*sD1L21[2][1]);
        sL21[2][0] = (Pd[3][0][2]*sD1INV[0][0]);
        sL21[2][1] = (sD1INV[1][1]*sD1L21[1][2]);
        sL21[2][2] = (sD1INV[2][2]*sD1L21[2][2]);
        sL22D2[1][1] = (P22[3][1][1]-((sD1L21[2][1]*sL21[1][2])+((Pd[3][0][1]*
          sL21[1][0])+(sD1L21[1][1]*sL21[1][1]))));
        sL22D2[2][1] = (P22[3][1][2]-((sD1L21[2][1]*sL21[2][2])+((Pd[3][0][1]*
          sL21[2][0])+(sD1L21[1][1]*sL21[2][1]))));
        sL22D2[2][2] = (P22[3][2][2]-((sD1L21[2][2]*sL21[2][2])+((Pd[3][0][2]*
          sL21[2][0])+(sD1L21[1][2]*sL21[2][1]))));
        sD2INV[1][1] = 0.;
        if (sL22D2[1][1] >= 1e-13) {
            sD2INV[1][1] = (1./sL22D2[1][1]);
        }
        sL22[2][1] = (sD2INV[1][1]*sL22D2[2][1]);
        sL22D2[2][2] = (sL22D2[2][2]-(sL22[2][1]*sL22D2[2][1]));
        N11[3][1][0] = ((sL11[1][0]*c3)-(sL11[2][0]*s3));
        N11[3][1][1] = (c3-(sL11[2][1]*s3));
        N11[3][2][0] = ((sL11[1][0]*s3)+(sL11[2][0]*c3));
        N11[3][2][1] = (s3+(sL11[2][1]*c3));
        N21[3][1][0] = ((sL21[1][0]*c3)-(sL21[2][0]*s3));
        N21[3][1][1] = ((sL21[1][1]*c3)-(sL21[2][1]*s3));
        N21[3][1][2] = ((sL21[1][2]*c3)-(sL21[2][2]*s3));
        N21[3][2][0] = ((sL21[1][0]*s3)+(sL21[2][0]*c3));
        N21[3][2][1] = ((sL21[1][1]*s3)+(sL21[2][1]*c3));
        N21[3][2][2] = ((sL21[1][2]*s3)+(sL21[2][2]*c3));
        N22[3][1][1] = (c3-(sL22[2][1]*s3));
        N22[3][2][1] = (s3+(sL22[2][1]*c3));
        psiD11[3][1][0] = (N11[3][1][0]*P11[3][0][0]);
        psiD11[3][1][1] = (N11[3][1][1]*sL11D1[1][1]);
        psiD11[3][1][2] = -(sL11D1[2][2]*s3);
        psiD11[3][2][0] = (N11[3][2][0]*P11[3][0][0]);
        psiD11[3][2][1] = (N11[3][2][1]*sL11D1[1][1]);
        psiD11[3][2][2] = (sL11D1[2][2]*c3);
        psiD21[3][1][0] = (N21[3][1][0]*P11[3][0][0]);
        psiD21[3][1][1] = (N21[3][1][1]*sL11D1[1][1]);
        psiD21[3][1][2] = (N21[3][1][2]*sL11D1[2][2]);
        psiD21[3][2][0] = (N21[3][2][0]*P11[3][0][0]);
        psiD21[3][2][1] = (N21[3][2][1]*sL11D1[1][1]);
        psiD21[3][2][2] = (N21[3][2][2]*sL11D1[2][2]);
        psiD22[3][1][1] = (N22[3][1][1]*sL22D2[1][1]);
        psiD22[3][1][2] = -(sL22D2[2][2]*s3);
        psiD22[3][2][1] = (N22[3][2][1]*sL22D2[1][1]);
        psiD22[3][2][2] = (sL22D2[2][2]*c3);
        P11[2][0][0] = (44.31+P11[3][0][0]);
        P11[2][0][1] = (N11[3][1][0]*P11[3][0][0]);
        P11[2][0][2] = (N11[3][2][0]*P11[3][0][0]);
        P11[2][1][0] = P11[2][0][1];
        P11[2][1][1] = (P11[2][1][1]+(((N11[3][1][0]*psiD11[3][1][0])+(
          N11[3][1][1]*psiD11[3][1][1]))-(psiD11[3][1][2]*s3)));
        P11[2][1][2] = (P11[2][1][2]+((psiD11[3][1][2]*c3)+((N11[3][2][0]*
          psiD11[3][1][0])+(N11[3][2][1]*psiD11[3][1][1]))));
        P11[2][2][0] = P11[2][0][2];
        P11[2][2][1] = P11[2][1][2];
        P11[2][2][2] = (P11[2][2][2]+((psiD11[3][2][2]*c3)+((N11[3][2][0]*
          psiD11[3][2][0])+(N11[3][2][1]*psiD11[3][2][1]))));
        Pd[2][0][1] = (Pd[2][0][1]+(N21[3][1][0]*P11[3][0][0]));
        Pd[2][0][2] = (Pd[2][0][2]+(N21[3][2][0]*P11[3][0][0]));
        Pd[2][1][1] = (Pd[2][1][1]+((N21[3][1][2]*psiD11[3][1][2])+((
          N21[3][1][0]*psiD11[3][1][0])+(N21[3][1][1]*psiD11[3][1][1]))));
        Pd[2][1][2] = (Pd[2][1][2]+((N21[3][2][2]*psiD11[3][1][2])+((
          N21[3][2][0]*psiD11[3][1][0])+(N21[3][2][1]*psiD11[3][1][1]))));
        Pd[2][2][1] = (Pd[2][2][1]+((N21[3][1][2]*psiD11[3][2][2])+((
          N21[3][1][0]*psiD11[3][2][0])+(N21[3][1][1]*psiD11[3][2][1]))));
        Pd[2][2][2] = (Pd[2][2][2]+((N21[3][2][2]*psiD11[3][2][2])+((
          N21[3][2][0]*psiD11[3][2][0])+(N21[3][2][1]*psiD11[3][2][1]))));
        P22[2][1][0] = P22[2][0][1];
        P22[2][1][1] = (P22[2][1][1]+(((N21[3][1][2]*psiD21[3][1][2])+((
          N21[3][1][0]*psiD21[3][1][0])+(N21[3][1][1]*psiD21[3][1][1])))+((
          N22[3][1][1]*psiD22[3][1][1])-(psiD22[3][1][2]*s3))));
        P22[2][1][2] = (P22[2][1][2]+(((N21[3][2][2]*psiD21[3][1][2])+((
          N21[3][2][0]*psiD21[3][1][0])+(N21[3][2][1]*psiD21[3][1][1])))+((
          N22[3][2][1]*psiD22[3][1][1])+(psiD22[3][1][2]*c3))));
        P22[2][2][0] = P22[2][0][2];
        P22[2][2][1] = P22[2][1][2];
        P22[2][2][2] = (P22[2][2][2]+(((N21[3][2][2]*psiD21[3][2][2])+((
          N21[3][2][0]*psiD21[3][2][0])+(N21[3][2][1]*psiD21[3][2][1])))+((
          N22[3][2][1]*psiD22[3][2][1])+(psiD22[3][2][2]*c3))));
        if (P22[2][0][0] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[2] = (1./P22[2][0][0]);
        }
        G1[2][1] = (DD[2]*Pd[2][1][0]);
        G1[2][2] = (DD[2]*Pd[2][2][0]);
        G2[2][1] = (DD[2]*P22[2][1][0]);
        G2[2][2] = (DD[2]*P22[2][2][0]);
        P11[2][1][1] = (P11[2][1][1]-(G1[2][1]*Pd[2][1][0]));
        P11[2][1][2] = (P11[2][1][2]-(G1[2][2]*Pd[2][1][0]));
        P11[2][2][2] = (P11[2][2][2]-(G1[2][2]*Pd[2][2][0]));
        Pd[2][1][1] = (Pd[2][1][1]-(G2[2][1]*Pd[2][1][0]));
        Pd[2][1][2] = (Pd[2][1][2]-(G2[2][2]*Pd[2][1][0]));
        Pd[2][2][1] = (Pd[2][2][1]-(G2[2][1]*Pd[2][2][0]));
        Pd[2][2][2] = (Pd[2][2][2]-(G2[2][2]*Pd[2][2][0]));
        P22[2][0][1] = (P22[2][0][1]-P22[2][1][0]);
        P22[2][0][2] = (P22[2][0][2]-P22[2][2][0]);
        P22[2][1][1] = (P22[2][1][1]-(G2[2][1]*P22[2][1][0]));
        P22[2][1][2] = (P22[2][1][2]-(G2[2][2]*P22[2][1][0]));
        P22[2][2][2] = (P22[2][2][2]-(G2[2][2]*P22[2][2][0]));
        sD1INV[0][0] = 0.;
        if (P11[2][0][0] >= 1e-13) {
            sD1INV[0][0] = (1./P11[2][0][0]);
        }
        sL11[1][0] = (P11[2][0][1]*sD1INV[0][0]);
        sL11[2][0] = (P11[2][0][2]*sD1INV[0][0]);
        sL11D1[1][1] = (P11[2][1][1]-(P11[2][0][1]*sL11[1][0]));
        sL11D1[2][1] = (P11[2][1][2]-(P11[2][0][2]*sL11[1][0]));
        sL11D1[2][2] = (P11[2][2][2]-(P11[2][0][2]*sL11[2][0]));
        sD1INV[1][1] = 0.;
        if (sL11D1[1][1] >= 1e-13) {
            sD1INV[1][1] = (1./sL11D1[1][1]);
        }
        sL11[2][1] = (sD1INV[1][1]*sL11D1[2][1]);
        sL11D1[2][2] = (sL11D1[2][2]-(sL11[2][1]*sL11D1[2][1]));
        sD1INV[2][2] = 0.;
        if (sL11D1[2][2] >= 1e-13) {
            sD1INV[2][2] = (1./sL11D1[2][2]);
        }
        sD1L21[1][1] = (Pd[2][1][1]-(Pd[2][0][1]*sL11[1][0]));
        sD1L21[1][2] = (Pd[2][1][2]-(Pd[2][0][2]*sL11[1][0]));
        sD1L21[2][1] = (Pd[2][2][1]-((Pd[2][0][1]*sL11[2][0])+(sD1L21[1][1]*
          sL11[2][1])));
        sD1L21[2][2] = (Pd[2][2][2]-((Pd[2][0][2]*sL11[2][0])+(sD1L21[1][2]*
          sL11[2][1])));
        sL21[1][0] = (Pd[2][0][1]*sD1INV[0][0]);
        sL21[1][1] = (sD1INV[1][1]*sD1L21[1][1]);
        sL21[1][2] = (sD1INV[2][2]*sD1L21[2][1]);
        sL21[2][0] = (Pd[2][0][2]*sD1INV[0][0]);
        sL21[2][1] = (sD1INV[1][1]*sD1L21[1][2]);
        sL21[2][2] = (sD1INV[2][2]*sD1L21[2][2]);
        sL22D2[1][1] = (P22[2][1][1]-((sD1L21[2][1]*sL21[1][2])+((Pd[2][0][1]*
          sL21[1][0])+(sD1L21[1][1]*sL21[1][1]))));
        sL22D2[2][1] = (P22[2][1][2]-((sD1L21[2][1]*sL21[2][2])+((Pd[2][0][1]*
          sL21[2][0])+(sD1L21[1][1]*sL21[2][1]))));
        sL22D2[2][2] = (P22[2][2][2]-((sD1L21[2][2]*sL21[2][2])+((Pd[2][0][2]*
          sL21[2][0])+(sD1L21[1][2]*sL21[2][1]))));
        sD2INV[1][1] = 0.;
        if (sL22D2[1][1] >= 1e-13) {
            sD2INV[1][1] = (1./sL22D2[1][1]);
        }
        sL22[2][1] = (sD2INV[1][1]*sL22D2[2][1]);
        sL22D2[2][2] = (sL22D2[2][2]-(sL22[2][1]*sL22D2[2][1]));
        N11[2][1][0] = ((sL11[1][0]*c2)-(sL11[2][0]*s2));
        N11[2][1][1] = (c2-(sL11[2][1]*s2));
        N11[2][2][0] = ((sL11[1][0]*s2)+(sL11[2][0]*c2));
        N11[2][2][1] = (s2+(sL11[2][1]*c2));
        N21[2][1][0] = ((sL21[1][0]*c2)-(sL21[2][0]*s2));
        N21[2][1][1] = ((sL21[1][1]*c2)-(sL21[2][1]*s2));
        N21[2][1][2] = ((sL21[1][2]*c2)-(sL21[2][2]*s2));
        N21[2][2][0] = ((sL21[1][0]*s2)+(sL21[2][0]*c2));
        N21[2][2][1] = ((sL21[1][1]*s2)+(sL21[2][1]*c2));
        N21[2][2][2] = ((sL21[1][2]*s2)+(sL21[2][2]*c2));
        N22[2][1][1] = (c2-(sL22[2][1]*s2));
        N22[2][2][1] = (s2+(sL22[2][1]*c2));
        psiD11[2][1][0] = (N11[2][1][0]*P11[2][0][0]);
        psiD11[2][1][1] = (N11[2][1][1]*sL11D1[1][1]);
        psiD11[2][1][2] = -(sL11D1[2][2]*s2);
        psiD11[2][2][0] = (N11[2][2][0]*P11[2][0][0]);
        psiD11[2][2][1] = (N11[2][2][1]*sL11D1[1][1]);
        psiD11[2][2][2] = (sL11D1[2][2]*c2);
        psiD21[2][1][0] = (N21[2][1][0]*P11[2][0][0]);
        psiD21[2][1][1] = (N21[2][1][1]*sL11D1[1][1]);
        psiD21[2][1][2] = (N21[2][1][2]*sL11D1[2][2]);
        psiD21[2][2][0] = (N21[2][2][0]*P11[2][0][0]);
        psiD21[2][2][1] = (N21[2][2][1]*sL11D1[1][1]);
        psiD21[2][2][2] = (N21[2][2][2]*sL11D1[2][2]);
        psiD22[2][1][1] = (N22[2][1][1]*sL22D2[1][1]);
        psiD22[2][1][2] = -(sL22D2[2][2]*s2);
        psiD22[2][2][1] = (N22[2][2][1]*sL22D2[1][1]);
        psiD22[2][2][2] = (sL22D2[2][2]*c2);
        P11[1][0][0] = P11[2][0][0];
        P11[1][0][1] = (N11[2][1][0]*P11[2][0][0]);
        P11[1][0][2] = (N11[2][2][0]*P11[2][0][0]);
        P11[1][1][0] = P11[1][0][1];
        P11[1][1][1] = (((N11[2][1][0]*psiD11[2][1][0])+(N11[2][1][1]*
          psiD11[2][1][1]))-(psiD11[2][1][2]*s2));
        P11[1][1][2] = ((psiD11[2][1][2]*c2)+((N11[2][2][0]*psiD11[2][1][0])+(
          N11[2][2][1]*psiD11[2][1][1])));
        P11[1][2][0] = P11[1][0][2];
        P11[1][2][1] = P11[1][1][2];
        P11[1][2][2] = ((psiD11[2][2][2]*c2)+((N11[2][2][0]*psiD11[2][2][0])+(
          N11[2][2][1]*psiD11[2][2][1])));
        Pd[1][0][1] = (N21[2][1][0]*P11[2][0][0]);
        Pd[1][0][2] = (N21[2][2][0]*P11[2][0][0]);
        Pd[1][1][1] = ((N21[2][1][2]*psiD11[2][1][2])+((N21[2][1][0]*
          psiD11[2][1][0])+(N21[2][1][1]*psiD11[2][1][1])));
        Pd[1][1][2] = ((N21[2][2][2]*psiD11[2][1][2])+((N21[2][2][0]*
          psiD11[2][1][0])+(N21[2][2][1]*psiD11[2][1][1])));
        Pd[1][2][1] = ((N21[2][1][2]*psiD11[2][2][2])+((N21[2][1][0]*
          psiD11[2][2][0])+(N21[2][1][1]*psiD11[2][2][1])));
        Pd[1][2][2] = ((N21[2][2][2]*psiD11[2][2][2])+((N21[2][2][0]*
          psiD11[2][2][0])+(N21[2][2][1]*psiD11[2][2][1])));
        P22[1][1][1] = (((N21[2][1][2]*psiD21[2][1][2])+((N21[2][1][0]*
          psiD21[2][1][0])+(N21[2][1][1]*psiD21[2][1][1])))+((N22[2][1][1]*
          psiD22[2][1][1])-(psiD22[2][1][2]*s2)));
        P22[1][1][2] = (((N21[2][2][2]*psiD21[2][1][2])+((N21[2][2][0]*
          psiD21[2][1][0])+(N21[2][2][1]*psiD21[2][1][1])))+((N22[2][2][1]*
          psiD22[2][1][1])+(psiD22[2][1][2]*c2)));
        P22[1][2][1] = P22[1][1][2];
        P22[1][2][2] = (((N21[2][2][2]*psiD21[2][2][2])+((N21[2][2][0]*
          psiD21[2][2][0])+(N21[2][2][1]*psiD21[2][2][1])))+((N22[2][2][1]*
          psiD22[2][2][1])+(psiD22[2][2][2]*c2)));
        if (P11[1][2][2] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[1] = (1./P11[1][2][2]);
        }
        G1[1][0] = (DD[1]*P11[1][0][2]);
        G1[1][1] = (DD[1]*P11[1][1][2]);
        G2[1][1] = (DD[1]*Pd[1][2][1]);
        G2[1][2] = (DD[1]*Pd[1][2][2]);
        P11[1][0][0] = (P11[1][0][0]-(G1[1][0]*P11[1][0][2]));
        P11[1][0][1] = (P11[1][0][1]-(G1[1][1]*P11[1][0][2]));
        P11[1][1][1] = (P11[1][1][1]-(G1[1][1]*P11[1][1][2]));
        Pd[1][0][1] = (Pd[1][0][1]-(G2[1][1]*P11[1][0][2]));
        Pd[1][0][2] = (Pd[1][0][2]-(G2[1][2]*P11[1][0][2]));
        Pd[1][1][1] = (Pd[1][1][1]-(G2[1][1]*P11[1][1][2]));
        Pd[1][1][2] = (Pd[1][1][2]-(G2[1][2]*P11[1][1][2]));
        P22[1][1][1] = (P22[1][1][1]-(G2[1][1]*Pd[1][2][1]));
        P22[1][1][2] = (P22[1][1][2]-(G2[1][2]*Pd[1][2][1]));
        P22[1][2][2] = (P22[1][2][2]-(G2[1][2]*Pd[1][2][2]));
        sD1INV[0][0] = 0.;
        if (P11[1][0][0] >= 1e-13) {
            sD1INV[0][0] = (1./P11[1][0][0]);
        }
        sL11[1][0] = (P11[1][0][1]*sD1INV[0][0]);
        sL11D1[1][1] = (P11[1][1][1]-(P11[1][0][1]*sL11[1][0]));
        sD1INV[1][1] = 0.;
        if (sL11D1[1][1] >= 1e-13) {
            sD1INV[1][1] = (1./sL11D1[1][1]);
        }
        sD1L21[1][1] = (Pd[1][1][1]-(Pd[1][0][1]*sL11[1][0]));
        sD1L21[1][2] = (Pd[1][1][2]-(Pd[1][0][2]*sL11[1][0]));
        sL21[1][0] = (Pd[1][0][1]*sD1INV[0][0]);
        sL21[1][1] = (sD1INV[1][1]*sD1L21[1][1]);
        sL21[2][0] = (Pd[1][0][2]*sD1INV[0][0]);
        sL21[2][1] = (sD1INV[1][1]*sD1L21[1][2]);
        sL22D2[1][1] = (P22[1][1][1]-((Pd[1][0][1]*sL21[1][0])+(sD1L21[1][1]*
          sL21[1][1])));
        sL22D2[2][1] = (P22[1][1][2]-((Pd[1][0][1]*sL21[2][0])+(sD1L21[1][1]*
          sL21[2][1])));
        sL22D2[2][2] = (P22[1][2][2]-((Pd[1][0][2]*sL21[2][0])+(sD1L21[1][2]*
          sL21[2][1])));
        sD2INV[1][1] = 0.;
        if (sL22D2[1][1] >= 1e-13) {
            sD2INV[1][1] = (1./sL22D2[1][1]);
        }
        sL22[2][1] = (sD2INV[1][1]*sL22D2[2][1]);
        sL22D2[2][2] = (sL22D2[2][2]-(sL22[2][1]*sL22D2[2][1]));
        N21[1][0][0] = -(q[1]*sL11[1][0]);
        N21[1][1][0] = (q[1]+sL21[1][0]);
        psiD11[1][1][0] = (P11[1][0][0]*sL11[1][0]);
        psiD21[1][0][0] = (N21[1][0][0]*P11[1][0][0]);
        psiD21[1][0][1] = -(q[1]*sL11D1[1][1]);
        psiD21[1][1][0] = (N21[1][1][0]*P11[1][0][0]);
        psiD21[1][1][1] = (sL11D1[1][1]*sL21[1][1]);
        psiD21[1][2][0] = (P11[1][0][0]*sL21[2][0]);
        psiD21[1][2][1] = (sL11D1[1][1]*sL21[2][1]);
        psiD22[1][2][1] = (sL22[2][1]*sL22D2[1][1]);
        P11[0][0][0] = P11[1][0][0];
        P11[0][0][1] = (P11[1][0][0]*sL11[1][0]);
        P11[0][1][0] = P11[0][0][1];
        P11[0][1][1] = (sL11D1[1][1]+(psiD11[1][1][0]*sL11[1][0]));
        Pd[0][0][0] = (N21[1][0][0]*P11[1][0][0]);
        Pd[0][0][1] = (N21[1][1][0]*P11[1][0][0]);
        Pd[0][0][2] = (P11[1][0][0]*sL21[2][0]);
        Pd[0][1][0] = ((N21[1][0][0]*psiD11[1][1][0])-(q[1]*sL11D1[1][1]));
        Pd[0][1][1] = ((N21[1][1][0]*psiD11[1][1][0])+(sL11D1[1][1]*sL21[1][1]))
          ;
        Pd[0][1][2] = ((psiD11[1][1][0]*sL21[2][0])+(sL11D1[1][1]*sL21[2][1]));
        P22[0][0][0] = ((N21[1][0][0]*psiD21[1][0][0])-(psiD21[1][0][1]*q[1]));
        P22[0][0][1] = ((N21[1][1][0]*psiD21[1][0][0])+(psiD21[1][0][1]*
          sL21[1][1]));
        P22[0][0][2] = ((psiD21[1][0][0]*sL21[2][0])+(psiD21[1][0][1]*sL21[2][1]
          ));
        P22[0][1][0] = P22[0][0][1];
        P22[0][1][1] = (sL22D2[1][1]+((N21[1][1][0]*psiD21[1][1][0])+(
          psiD21[1][1][1]*sL21[1][1])));
        P22[0][1][2] = ((sL22[2][1]*sL22D2[1][1])+((psiD21[1][1][0]*sL21[2][0])+
          (psiD21[1][1][1]*sL21[2][1])));
        P22[0][2][0] = P22[0][0][2];
        P22[0][2][1] = P22[0][1][2];
        P22[0][2][2] = ((sL22D2[2][2]+(psiD22[1][2][1]*sL22[2][1]))+((
          psiD21[1][2][0]*sL21[2][0])+(psiD21[1][2][1]*sL21[2][1])));
        if (P11[0][1][1] < 1e-13) {
            robotseterr(routine,47);
        } else {
            DD[0] = (1./P11[0][1][1]);
        }
        mmflg = 1;
    }
/*
 Used 1.86 seconds CPU time,
 90112 additional bytes of memory.
 Equations contain 1072 adds/subtracts/negates
                   1614 multiplies
                     55 divides
                   1131 assignments
*/
}

void robotlhs(int routine)
{
/* Compute all remaining state- and force-dependent quantities
*/

    roustate = 2;
    robotdomm(routine);
    robotdofs0();
}

void robotmassmat(double (*mmat)[18])
{
/* Calculate the system mass matrix
*/
    int i,j;
    double udotin[18],mmrow[18],biastrq[18];

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(57,23);
        return;
    }
    for (i = 0; i < 18; i++) {
        udotin[i] = 0.;
    }
    robotcomptrq(udotin,biastrq);
    for (i = 0; i < 18; i++) {
        udotin[i] = 1.;
        robotcomptrq(udotin,mmrow);
        udotin[i] = 0.;
        for (j = i; j <= 17; j++) {
            mmat[i][j] = mmrow[j]-biastrq[j];
            mmat[j][i] = mmat[i][j];
        }
    }
/*
Check for singular mass matrix
*/
    for (i = 0; i < 18; i++) {
        if (mmat[i][i] <= 1e-13) {
            robotseterr(57,47);
        }
    }
}

void robotfrcmat(double *fmat)
{
/* Return the system force matrix (RHS), excluding constraints
*/
    int i;

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(58,23);
        return;
    }
    robotdofs0();
    for (i = 0; i < 18; i++) {
        fmat[i] = fs0[i];
    }
}

void robotmfrc(double *imult)
{

}

void robotequivht(double *tau)
{
/* Compute tree hinge torques to match effect of applied loads
*/
    double fstareq[18][3],tstareq[18][3];

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(56,23);
        return;
    }
/*
Compute fstareq (forces)
*/
/*
Compute tstareq (torques)
*/
/*
Compute taus (RHS ignoring constraints and inertial forces)
*/
    tau[17] = (utau[17]-(((.039*ufk[15][1])+(.0442*ufk[15][2]))-utk[15][0]));
    Fstark[16][0] = -(ufk[14][0]+ufk[15][0]);
    Fstark[16][1] = (((ufk[15][2]*s17)-(ufk[15][1]*c17))-ufk[14][1]);
    Fstark[16][2] = -(ufk[14][2]+((ufk[15][1]*s17)+(ufk[15][2]*c17)));
    tvec1[0] = (((rik[17][2]*ufk[15][1])-(rik[17][1]*ufk[15][2]))-utk[15][0]);
    tvec1[1] = (((.0078*ufk[15][2])-(rik[17][2]*ufk[15][0]))-utk[15][1]);
    tvec1[2] = (((rik[17][1]*ufk[15][0])-(.0078*ufk[15][1]))-utk[15][2]);
    Tstark[16][0] = (tvec1[0]-utk[14][0]);
    Tstark[16][1] = (((tvec1[1]*c17)-(tvec1[2]*s17))-utk[14][1]);
    Tstark[16][2] = (((tvec1[1]*s17)+(tvec1[2]*c17))-utk[14][2]);
    tau[16] = (utau[16]-(Tstark[16][0]+((.0039*Fstark[16][1])-(.2158*
      Fstark[16][2]))));
    Fstark[15][0] = (Fstark[16][0]-ufk[13][0]);
    Fstark[15][1] = (((Fstark[16][1]*c16)-(Fstark[16][2]*s16))-ufk[13][1]);
    Fstark[15][2] = (((Fstark[16][1]*s16)+(Fstark[16][2]*c16))-ufk[13][2]);
    tvec1[0] = (Tstark[16][0]+((Fstark[16][2]*rik[16][1])-(Fstark[16][1]*
      rik[16][2])));
    tvec1[1] = (Tstark[16][1]+((Fstark[16][0]*rik[16][2])-(.0247*Fstark[16][2]))
      );
    tvec1[2] = (Tstark[16][2]+((.0247*Fstark[16][1])-(Fstark[16][0]*rik[16][1]))
      );
    Tstark[15][0] = (tvec1[0]-utk[13][0]);
    Tstark[15][1] = (((tvec1[1]*c16)-(tvec1[2]*s16))-utk[13][1]);
    Tstark[15][2] = (((tvec1[1]*s16)+(tvec1[2]*c16))-utk[13][2]);
    tau[15] = (utau[15]-(Tstark[15][0]-((.0143*Fstark[15][1])+(.2379*
      Fstark[15][2]))));
    Fstark[2][0] = (Fstark[15][0]-ufk[0][0]);
    Fstark[2][1] = (((Fstark[15][1]*c15)-(Fstark[15][2]*s15))-ufk[0][1]);
    Fstark[2][2] = (((Fstark[15][1]*s15)+(Fstark[15][2]*c15))-ufk[0][2]);
    tvec1[0] = (Tstark[15][0]+((Fstark[15][2]*rik[15][1])-(Fstark[15][1]*
      rik[15][2])));
    tvec1[1] = (Tstark[15][1]+((.0949*Fstark[15][2])+(Fstark[15][0]*rik[15][2]))
      );
    tvec1[2] = (Tstark[15][2]-((.0949*Fstark[15][1])+(Fstark[15][0]*rik[15][1]))
      );
    Tstark[2][0] = (tvec1[0]-utk[0][0]);
    Tstark[2][1] = (((tvec1[1]*c15)-(tvec1[2]*s15))-utk[0][1]);
    Tstark[2][2] = (((tvec1[1]*s15)+(tvec1[2]*c15))-utk[0][2]);
    tau[14] = (utau[14]-(((.039*ufk[12][1])+(.0442*ufk[12][2]))-utk[12][0]));
    Fstark[13][0] = -(ufk[11][0]+ufk[12][0]);
    Fstark[13][1] = (((ufk[12][2]*s14)-(ufk[12][1]*c14))-ufk[11][1]);
    Fstark[13][2] = -(ufk[11][2]+((ufk[12][1]*s14)+(ufk[12][2]*c14)));
    tvec1[0] = (((rik[14][2]*ufk[12][1])-(rik[14][1]*ufk[12][2]))-utk[12][0]);
    tvec1[1] = -(utk[12][1]+((.0078*ufk[12][2])+(rik[14][2]*ufk[12][0])));
    tvec1[2] = (((.0078*ufk[12][1])+(rik[14][1]*ufk[12][0]))-utk[12][2]);
    Tstark[13][0] = (tvec1[0]-utk[11][0]);
    Tstark[13][1] = (((tvec1[1]*c14)-(tvec1[2]*s14))-utk[11][1]);
    Tstark[13][2] = (((tvec1[1]*s14)+(tvec1[2]*c14))-utk[11][2]);
    tau[13] = (utau[13]-(Tstark[13][0]+((.0039*Fstark[13][1])-(.2158*
      Fstark[13][2]))));
    Fstark[12][0] = (Fstark[13][0]-ufk[10][0]);
    Fstark[12][1] = (((Fstark[13][1]*c13)-(Fstark[13][2]*s13))-ufk[10][1]);
    Fstark[12][2] = (((Fstark[13][1]*s13)+(Fstark[13][2]*c13))-ufk[10][2]);
    tvec1[0] = (Tstark[13][0]+((Fstark[13][2]*rik[13][1])-(Fstark[13][1]*
      rik[13][2])));
    tvec1[1] = (Tstark[13][1]+((.0247*Fstark[13][2])+(Fstark[13][0]*rik[13][2]))
      );
    tvec1[2] = (Tstark[13][2]-((.0247*Fstark[13][1])+(Fstark[13][0]*rik[13][1]))
      );
    Tstark[12][0] = (tvec1[0]-utk[10][0]);
    Tstark[12][1] = (((tvec1[1]*c13)-(tvec1[2]*s13))-utk[10][1]);
    Tstark[12][2] = (((tvec1[1]*s13)+(tvec1[2]*c13))-utk[10][2]);
    tau[12] = (utau[12]-(Tstark[12][0]-((.0143*Fstark[12][1])+(.2379*
      Fstark[12][2]))));
    Fstark[2][0] = (Fstark[2][0]+Fstark[12][0]);
    Fstark[2][1] = (Fstark[2][1]+((Fstark[12][1]*c12)-(Fstark[12][2]*s12)));
    Fstark[2][2] = (Fstark[2][2]+((Fstark[12][1]*s12)+(Fstark[12][2]*c12)));
    tvec1[0] = (Tstark[12][0]+((Fstark[12][2]*rik[12][1])-(Fstark[12][1]*
      rik[12][2])));
    tvec1[1] = (Tstark[12][1]+((Fstark[12][0]*rik[12][2])-(.0949*Fstark[12][2]))
      );
    tvec1[2] = (Tstark[12][2]+((.0949*Fstark[12][1])-(Fstark[12][0]*rik[12][1]))
      );
    Tstark[2][0] = (Tstark[2][0]+tvec1[0]);
    Tstark[2][1] = (Tstark[2][1]+((tvec1[1]*c12)-(tvec1[2]*s12)));
    Tstark[2][2] = (Tstark[2][2]+((tvec1[1]*s12)+(tvec1[2]*c12)));
    tau[11] = (utau[11]+(utk[9][2]+(.065*ufk[9][0])));
    Fstark[10][0] = (((ufk[9][1]*s11)-(ufk[9][0]*c11))-ufk[8][0]);
    Fstark[10][1] = -(ufk[8][1]+((ufk[9][0]*s11)+(ufk[9][1]*c11)));
    Fstark[10][2] = -(ufk[8][2]+ufk[9][2]);
    tvec1[0] = -(utk[9][0]+(rik[11][1]*ufk[9][2]));
    tvec1[1] = ((rik[11][0]*ufk[9][2])-utk[9][1]);
    tvec1[2] = (((rik[11][1]*ufk[9][0])-(rik[11][0]*ufk[9][1]))-utk[9][2]);
    Tstark[10][0] = (((tvec1[0]*c11)-(tvec1[1]*s11))-utk[8][0]);
    Tstark[10][1] = (((tvec1[0]*s11)+(tvec1[1]*c11))-utk[8][1]);
    Tstark[10][2] = (tvec1[2]-utk[8][2]);
    tau[10] = (utau[10]-(Tstark[10][0]-(.1378*Fstark[10][2])));
    Fstark[9][0] = (Fstark[10][0]-ufk[7][0]);
    Fstark[9][1] = (((Fstark[10][1]*c10)-(Fstark[10][2]*s10))-ufk[7][1]);
    Fstark[9][2] = (((Fstark[10][1]*s10)+(Fstark[10][2]*c10))-ufk[7][2]);
    tvec1[0] = (Tstark[10][0]+((Fstark[10][2]*rik[10][1])-(Fstark[10][1]*
      rik[10][2])));
    tvec1[1] = (Tstark[10][1]+((Fstark[10][0]*rik[10][2])-(.0039*Fstark[10][2]))
      );
    tvec1[2] = (Tstark[10][2]+((.0039*Fstark[10][1])-(Fstark[10][0]*rik[10][1]))
      );
    Tstark[9][0] = (tvec1[0]-utk[7][0]);
    Tstark[9][1] = (((tvec1[1]*c10)-(tvec1[2]*s10))-utk[7][1]);
    Tstark[9][2] = (((tvec1[1]*s10)+(tvec1[2]*c10))-utk[7][2]);
    tau[9] = (utau[9]-(Tstark[9][0]-((.0013*Fstark[9][1])+(.1326*Fstark[9][2])))
      );
    Fstark[3][0] = (Fstark[9][0]-ufk[1][0]);
    Fstark[3][1] = (((Fstark[9][1]*c9)-(Fstark[9][2]*s9))-ufk[1][1]);
    Fstark[3][2] = (((Fstark[9][1]*s9)+(Fstark[9][2]*c9))-ufk[1][2]);
    tvec1[0] = (Tstark[9][0]+((Fstark[9][2]*rik[9][1])-(Fstark[9][1]*rik[9][2]))
      );
    tvec1[1] = (Tstark[9][1]+((.1768*Fstark[9][2])+(Fstark[9][0]*rik[9][2])));
    tvec1[2] = (Tstark[9][2]-((.1768*Fstark[9][1])+(Fstark[9][0]*rik[9][1])));
    Tstark[3][0] = (tvec1[0]-utk[1][0]);
    Tstark[3][1] = (((tvec1[1]*c9)-(tvec1[2]*s9))-utk[1][1]);
    Tstark[3][2] = (((tvec1[1]*s9)+(tvec1[2]*c9))-utk[1][2]);
    tau[8] = (utau[8]+(utk[6][2]+(.065*ufk[6][0])));
    Fstark[7][0] = (((ufk[6][1]*s8)-(ufk[6][0]*c8))-ufk[5][0]);
    Fstark[7][1] = -(ufk[5][1]+((ufk[6][0]*s8)+(ufk[6][1]*c8)));
    Fstark[7][2] = -(ufk[5][2]+ufk[6][2]);
    tvec1[0] = -(utk[6][0]+(rik[8][1]*ufk[6][2]));
    tvec1[1] = ((rik[8][0]*ufk[6][2])-utk[6][1]);
    tvec1[2] = (((rik[8][1]*ufk[6][0])-(rik[8][0]*ufk[6][1]))-utk[6][2]);
    Tstark[7][0] = (((tvec1[0]*c8)-(tvec1[1]*s8))-utk[5][0]);
    Tstark[7][1] = (((tvec1[0]*s8)+(tvec1[1]*c8))-utk[5][1]);
    Tstark[7][2] = (tvec1[2]-utk[5][2]);
    tau[7] = (utau[7]-(Tstark[7][0]-(.1378*Fstark[7][2])));
    Fstark[6][0] = (Fstark[7][0]-ufk[4][0]);
    Fstark[6][1] = (((Fstark[7][1]*c7)-(Fstark[7][2]*s7))-ufk[4][1]);
    Fstark[6][2] = (((Fstark[7][1]*s7)+(Fstark[7][2]*c7))-ufk[4][2]);
    tvec1[0] = (Tstark[7][0]+((Fstark[7][2]*rik[7][1])-(Fstark[7][1]*rik[7][2]))
      );
    tvec1[1] = (Tstark[7][1]+((.0039*Fstark[7][2])+(Fstark[7][0]*rik[7][2])));
    tvec1[2] = (Tstark[7][2]-((.0039*Fstark[7][1])+(Fstark[7][0]*rik[7][1])));
    Tstark[6][0] = (tvec1[0]-utk[4][0]);
    Tstark[6][1] = (((tvec1[1]*c7)-(tvec1[2]*s7))-utk[4][1]);
    Tstark[6][2] = (((tvec1[1]*s7)+(tvec1[2]*c7))-utk[4][2]);
    tau[6] = (utau[6]-(Tstark[6][0]-((.0013*Fstark[6][1])+(.1326*Fstark[6][2])))
      );
    Fstark[3][0] = (Fstark[3][0]+Fstark[6][0]);
    Fstark[3][1] = (Fstark[3][1]+((Fstark[6][1]*c6)-(Fstark[6][2]*s6)));
    Fstark[3][2] = (Fstark[3][2]+((Fstark[6][1]*s6)+(Fstark[6][2]*c6)));
    tvec1[0] = (Tstark[6][0]+((Fstark[6][2]*rik[6][1])-(Fstark[6][1]*rik[6][2]))
      );
    tvec1[1] = (Tstark[6][1]+((Fstark[6][0]*rik[6][2])-(.1768*Fstark[6][2])));
    tvec1[2] = (Tstark[6][2]+((.1768*Fstark[6][1])-(Fstark[6][0]*rik[6][1])));
    Tstark[3][0] = (Tstark[3][0]+tvec1[0]);
    Tstark[3][1] = (Tstark[3][1]+((tvec1[1]*c6)-(tvec1[2]*s6)));
    Tstark[3][2] = (Tstark[3][2]+((tvec1[1]*s6)+(tvec1[2]*c6)));
    tau[5] = (utau[5]-(((.0312*ufk[3][1])-(.078*ufk[3][2]))-utk[3][0]));
    Fstark[4][0] = -(ufk[2][0]+ufk[3][0]);
    Fstark[4][1] = (((ufk[3][2]*s5)-(ufk[3][1]*c5))-ufk[2][1]);
    Fstark[4][2] = -(ufk[2][2]+((ufk[3][1]*s5)+(ufk[3][2]*c5)));
    tvec1[0] = (((rik[5][2]*ufk[3][1])-(rik[5][1]*ufk[3][2]))-utk[3][0]);
    tvec1[1] = -(utk[3][1]+(rik[5][2]*ufk[3][0]));
    tvec1[2] = ((rik[5][1]*ufk[3][0])-utk[3][2]);
    Tstark[4][0] = (tvec1[0]-utk[2][0]);
    Tstark[4][1] = (((tvec1[1]*c5)-(tvec1[2]*s5))-utk[2][1]);
    Tstark[4][2] = (((tvec1[1]*s5)+(tvec1[2]*c5))-utk[2][2]);
    tau[4] = (utau[4]-(Tstark[4][0]+((.0442*Fstark[4][2])-(.0065*Fstark[4][1])))
      );
    Fstark[3][0] = (Fstark[3][0]+Fstark[4][0]);
    Fstark[3][1] = (Fstark[3][1]+((Fstark[4][1]*c4)-(Fstark[4][2]*s4)));
    Fstark[3][2] = (Fstark[3][2]+((Fstark[4][1]*s4)+(Fstark[4][2]*c4)));
    tvec1[0] = (Tstark[4][0]+((Fstark[4][2]*rik[4][1])-(Fstark[4][1]*rik[4][2]))
      );
    tvec1[1] = (Tstark[4][1]+(Fstark[4][0]*rik[4][2]));
    tvec1[2] = (Tstark[4][2]-(Fstark[4][0]*rik[4][1]));
    Tstark[3][0] = (Tstark[3][0]+tvec1[0]);
    Tstark[3][1] = (Tstark[3][1]+((tvec1[1]*c4)-(tvec1[2]*s4)));
    Tstark[3][2] = (Tstark[3][2]+((tvec1[1]*s4)+(tvec1[2]*c4)));
    tau[3] = (utau[3]-(Tstark[3][0]+((.0351*Fstark[3][1])+(.14625*Fstark[3][2]))
      ));
    Fstark[2][0] = (Fstark[2][0]+Fstark[3][0]);
    Fstark[2][1] = (Fstark[2][1]+((Fstark[3][1]*c3)-(Fstark[3][2]*s3)));
    Fstark[2][2] = (Fstark[2][2]+((Fstark[3][1]*s3)+(Fstark[3][2]*c3)));
    tvec1[0] = (Tstark[3][0]+((Fstark[3][2]*rik[3][1])-(Fstark[3][1]*rik[3][2]))
      );
    tvec1[1] = (Tstark[3][1]+(Fstark[3][0]*rik[3][2]));
    tvec1[2] = (Tstark[3][2]-(Fstark[3][0]*rik[3][1]));
    Tstark[2][0] = (Tstark[2][0]+tvec1[0]);
    Tstark[2][1] = (Tstark[2][1]+((tvec1[1]*c3)-(tvec1[2]*s3)));
    Tstark[2][2] = (Tstark[2][2]+((tvec1[1]*s3)+(tvec1[2]*c3)));
    tau[2] = (utau[2]-(Tstark[2][0]+((.05*Fstark[2][1])-(.1206*Fstark[2][2]))));
    Fstark[1][0] = Fstark[2][0];
    Fstark[1][1] = ((Fstark[2][1]*c2)-(Fstark[2][2]*s2));
    Fstark[1][2] = ((Fstark[2][1]*s2)+(Fstark[2][2]*c2));
    tvec1[0] = (Tstark[2][0]+((.05*Fstark[2][1])-(.1206*Fstark[2][2])));
    tvec1[1] = (Tstark[2][1]-(.05*Fstark[2][0]));
    tvec1[2] = (Tstark[2][2]+(.1206*Fstark[2][0]));
    Tstark[1][0] = tvec1[0];
    Tstark[1][1] = ((tvec1[1]*c2)-(tvec1[2]*s2));
    Tstark[1][2] = ((tvec1[1]*s2)+(tvec1[2]*c2));
    tau[1] = (utau[1]-Fstark[1][2]);
    Fstark[0][0] = Fstark[1][0];
    Fstark[0][1] = Fstark[1][1];
    Fstark[0][2] = Fstark[1][2];
    tvec1[0] = (Tstark[1][0]-(Fstark[1][1]*q[1]));
    tvec1[1] = (Tstark[1][1]+(Fstark[1][0]*q[1]));
    Tstark[0][0] = tvec1[0];
    Tstark[0][1] = tvec1[1];
    Tstark[0][2] = Tstark[1][2];
    tau[0] = (utau[0]-Fstark[0][1]);
/*
Op counts below do not include called subroutines
*/
/*
 Used 0.22 seconds CPU time,
 0 additional bytes of memory.
 Equations contain  300 adds/subtracts/negates
                    242 multiplies
                      0 divides
                    170 assignments
*/
}

void robotfulltrq(double *udotin, double *multin, double *trqout)
{
/* Compute hinge torques which would produce indicated udots
*/
    double fstarr[18][3],tstarr[18][3],Otkr[18][3],Atir[18][3],Atkr[18][3];

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(61,23);
        return;
    }
/*
Account for inertial accelerations and supplied udots
*/
    Otkr[3][0] = (udotin[2]+udotin[3]);
    Otkr[4][0] = (Otkr[3][0]+udotin[4]);
    Otkr[5][0] = (Otkr[4][0]+udotin[5]);
    Otkr[6][0] = (Otkr[3][0]+udotin[6]);
    Otkr[7][0] = (Otkr[6][0]+udotin[7]);
    Otkr[8][0] = ((Otkr[7][0]*c8)+(u[8]*wk[8][1]));
    Otkr[8][1] = -((Otkr[7][0]*s8)+(u[8]*wk[8][0]));
    Otkr[9][0] = (Otkr[3][0]+udotin[9]);
    Otkr[10][0] = (Otkr[9][0]+udotin[10]);
    Otkr[11][0] = ((Otkr[10][0]*c11)+(u[11]*wk[11][1]));
    Otkr[11][1] = -((Otkr[10][0]*s11)+(u[11]*wk[11][0]));
    Otkr[12][0] = (udotin[2]+udotin[12]);
    Otkr[13][0] = (Otkr[12][0]+udotin[13]);
    Otkr[14][0] = (Otkr[13][0]+udotin[14]);
    Otkr[15][0] = (udotin[2]+udotin[15]);
    Otkr[16][0] = (Otkr[15][0]+udotin[16]);
    Otkr[17][0] = (Otkr[16][0]+udotin[17]);
    Atkr[2][1] = (((.05*udotin[2])+(.1206*(u[2]*u[2])))+((udotin[0]*c2)+(
      udotin[1]*s2)));
    Atkr[2][2] = (((.05*(u[2]*u[2]))-(.1206*udotin[2]))+((udotin[1]*c2)-(
      udotin[0]*s2)));
    Atir[3][1] = (Atkr[2][1]-((.05*udotin[2])+(.1206*(u[2]*u[2]))));
    Atir[3][2] = (Atkr[2][2]+((.1206*udotin[2])-(.05*(u[2]*u[2]))));
    Atkr[3][1] = (((.0351*Otkr[3][0])-(.14625*(wk[3][0]*wk[3][0])))+((Atir[3][1]
      *c3)+(Atir[3][2]*s3)));
    Atkr[3][2] = (((.0351*(wk[3][0]*wk[3][0]))+(.14625*Otkr[3][0]))+((Atir[3][2]
      *c3)-(Atir[3][1]*s3)));
    Atir[4][1] = (Atkr[3][1]+((.0013*Otkr[3][0])-(.24635*(wk[3][0]*wk[3][0]))));
    Atir[4][2] = (Atkr[3][2]+((.0013*(wk[3][0]*wk[3][0]))+(.24635*Otkr[3][0])));
    Atkr[4][1] = (((Atir[4][1]*c4)+(Atir[4][2]*s4))-((.0065*Otkr[4][0])+(.0442*(
      wk[4][0]*wk[4][0]))));
    Atkr[4][2] = (((.0442*Otkr[4][0])-(.0065*(wk[4][0]*wk[4][0])))+((Atir[4][2]*
      c4)-(Atir[4][1]*s4)));
    Atir[5][1] = (Atkr[4][1]-((.0065*Otkr[4][0])+(.0442*(wk[4][0]*wk[4][0]))));
    Atir[5][2] = (Atkr[4][2]+((.0442*Otkr[4][0])-(.0065*(wk[4][0]*wk[4][0]))));
    Atkr[5][1] = (((Atir[5][1]*c5)+(Atir[5][2]*s5))-((.0312*Otkr[5][0])+(.078*(
      wk[5][0]*wk[5][0]))));
    Atkr[5][2] = (((.078*Otkr[5][0])-(.0312*(wk[5][0]*wk[5][0])))+((Atir[5][2]*
      c5)-(Atir[5][1]*s5)));
    Atir[6][1] = (Atkr[3][1]-((.0013*Otkr[3][0])+(.18915*(wk[3][0]*wk[3][0]))));
    Atir[6][2] = (Atkr[3][2]+((.18915*Otkr[3][0])-(.0013*(wk[3][0]*wk[3][0]))));
    Atkr[6][1] = (((.1326*(wk[6][0]*wk[6][0]))-(.0013*Otkr[6][0]))+((Atir[6][1]*
      c6)+(Atir[6][2]*s6)));
    Atkr[6][2] = (((Atir[6][2]*c6)-(Atir[6][1]*s6))-((.0013*(wk[6][0]*wk[6][0]))
      +(.1326*Otkr[6][0])));
    Atir[7][1] = (Atkr[6][1]+((.1326*(wk[6][0]*wk[6][0]))-(.0013*Otkr[6][0])));
    Atir[7][2] = (Atkr[6][2]-((.0013*(wk[6][0]*wk[6][0]))+(.1326*Otkr[6][0])));
    Atkr[7][1] = ((.1378*(wk[7][0]*wk[7][0]))+((Atir[7][1]*c7)+(Atir[7][2]*s7)))
      ;
    Atkr[7][2] = (((Atir[7][2]*c7)-(Atir[7][1]*s7))-(.1378*Otkr[7][0]));
    Atir[8][1] = (Atkr[7][1]+(.1378*(wk[7][0]*wk[7][0])));
    Atir[8][2] = (Atkr[7][2]-(.1378*Otkr[7][0]));
    Atkr[8][0] = ((.065*(udotin[8]-(wk[8][0]*wk[8][1])))+(Atir[8][1]*s8));
    Atkr[8][1] = ((.065*((u[8]*u[8])+(wk[8][0]*wk[8][0])))+(Atir[8][1]*c8));
    Atkr[8][2] = (Atir[8][2]-(.065*(Otkr[8][0]+(u[8]*wk[8][1]))));
    Atir[9][1] = (Atkr[3][1]-((.0013*Otkr[3][0])+(.18915*(wk[3][0]*wk[3][0]))));
    Atir[9][2] = (Atkr[3][2]+((.18915*Otkr[3][0])-(.0013*(wk[3][0]*wk[3][0]))));
    Atkr[9][1] = (((.1326*(wk[9][0]*wk[9][0]))-(.0013*Otkr[9][0]))+((Atir[9][1]*
      c9)+(Atir[9][2]*s9)));
    Atkr[9][2] = (((Atir[9][2]*c9)-(Atir[9][1]*s9))-((.0013*(wk[9][0]*wk[9][0]))
      +(.1326*Otkr[9][0])));
    Atir[10][1] = (Atkr[9][1]+((.1326*(wk[9][0]*wk[9][0]))-(.0013*Otkr[9][0])));
    Atir[10][2] = (Atkr[9][2]-((.0013*(wk[9][0]*wk[9][0]))+(.1326*Otkr[9][0])));
    Atkr[10][1] = ((.1378*(wk[10][0]*wk[10][0]))+((Atir[10][1]*c10)+(Atir[10][2]
      *s10)));
    Atkr[10][2] = (((Atir[10][2]*c10)-(Atir[10][1]*s10))-(.1378*Otkr[10][0]));
    Atir[11][1] = (Atkr[10][1]+(.1378*(wk[10][0]*wk[10][0])));
    Atir[11][2] = (Atkr[10][2]-(.1378*Otkr[10][0]));
    Atkr[11][0] = ((.065*(udotin[11]-(wk[11][0]*wk[11][1])))+(Atir[11][1]*s11));
    Atkr[11][1] = ((.065*((u[11]*u[11])+(wk[11][0]*wk[11][0])))+(Atir[11][1]*c11
      ));
    Atkr[11][2] = (Atir[11][2]-(.065*(Otkr[11][0]+(u[11]*wk[11][1]))));
    Atir[12][1] = (Atkr[2][1]+((.0406*(u[2]*u[2]))-(.0058*udotin[2])));
    Atir[12][2] = (Atkr[2][2]-((.0058*(u[2]*u[2]))+(.0406*udotin[2])));
    Atkr[12][1] = (((.2379*(wk[12][0]*wk[12][0]))-(.0143*Otkr[12][0]))+((
      Atir[12][1]*c12)+(Atir[12][2]*s12)));
    Atkr[12][2] = (((Atir[12][2]*c12)-(Atir[12][1]*s12))-((.0143*(wk[12][0]*
      wk[12][0]))+(.2379*Otkr[12][0])));
    Atir[13][1] = (Atkr[12][1]+((.2379*(wk[12][0]*wk[12][0]))-(.0143*Otkr[12][0]
      )));
    Atir[13][2] = (Atkr[12][2]-((.0143*(wk[12][0]*wk[12][0]))+(.2379*Otkr[12][0]
      )));
    Atkr[13][1] = (((.0039*Otkr[13][0])+(.2158*(wk[13][0]*wk[13][0])))+((
      Atir[13][1]*c13)+(Atir[13][2]*s13)));
    Atkr[13][2] = (((.0039*(wk[13][0]*wk[13][0]))-(.2158*Otkr[13][0]))+((
      Atir[13][2]*c13)-(Atir[13][1]*s13)));
    Atir[14][1] = (Atkr[13][1]+((.0039*Otkr[13][0])+(.2158*(wk[13][0]*wk[13][0])
      )));
    Atir[14][2] = (Atkr[13][2]+((.0039*(wk[13][0]*wk[13][0]))-(.2158*Otkr[13][0]
      )));
    Atkr[14][1] = (((.0442*(wk[14][0]*wk[14][0]))-(.039*Otkr[14][0]))+((
      Atir[14][1]*c14)+(Atir[14][2]*s14)));
    Atkr[14][2] = (((Atir[14][2]*c14)-(Atir[14][1]*s14))-((.039*(wk[14][0]*
      wk[14][0]))+(.0442*Otkr[14][0])));
    Atir[15][1] = (Atkr[2][1]+((.0406*(u[2]*u[2]))-(.0058*udotin[2])));
    Atir[15][2] = (Atkr[2][2]-((.0058*(u[2]*u[2]))+(.0406*udotin[2])));
    Atkr[15][1] = (((.2379*(wk[15][0]*wk[15][0]))-(.0143*Otkr[15][0]))+((
      Atir[15][1]*c15)+(Atir[15][2]*s15)));
    Atkr[15][2] = (((Atir[15][2]*c15)-(Atir[15][1]*s15))-((.0143*(wk[15][0]*
      wk[15][0]))+(.2379*Otkr[15][0])));
    Atir[16][1] = (Atkr[15][1]+((.2379*(wk[15][0]*wk[15][0]))-(.0143*Otkr[15][0]
      )));
    Atir[16][2] = (Atkr[15][2]-((.0143*(wk[15][0]*wk[15][0]))+(.2379*Otkr[15][0]
      )));
    Atkr[16][1] = (((.0039*Otkr[16][0])+(.2158*(wk[16][0]*wk[16][0])))+((
      Atir[16][1]*c16)+(Atir[16][2]*s16)));
    Atkr[16][2] = (((.0039*(wk[16][0]*wk[16][0]))-(.2158*Otkr[16][0]))+((
      Atir[16][2]*c16)-(Atir[16][1]*s16)));
    Atir[17][1] = (Atkr[16][1]+((.0039*Otkr[16][0])+(.2158*(wk[16][0]*wk[16][0])
      )));
    Atir[17][2] = (Atkr[16][2]+((.0039*(wk[16][0]*wk[16][0]))-(.2158*Otkr[16][0]
      )));
    Atkr[17][1] = (((.0442*(wk[17][0]*wk[17][0]))-(.039*Otkr[17][0]))+((
      Atir[17][1]*c17)+(Atir[17][2]*s17)));
    Atkr[17][2] = (((Atir[17][2]*c17)-(Atir[17][1]*s17))-((.039*(wk[17][0]*
      wk[17][0]))+(.0442*Otkr[17][0])));
/*
Accumulate all forces and torques
*/
    fstarr[2][1] = (ufk[0][1]-(16.61*Atkr[2][1]));
    fstarr[2][2] = (ufk[0][2]-(16.61*Atkr[2][2]));
    fstarr[3][1] = (ufk[1][1]-(29.27*Atkr[3][1]));
    fstarr[3][2] = (ufk[1][2]-(29.27*Atkr[3][2]));
    fstarr[4][1] = (ufk[2][1]-Atkr[4][1]);
    fstarr[4][2] = (ufk[2][2]-Atkr[4][2]);
    fstarr[5][1] = (ufk[3][1]-(5.89*Atkr[5][1]));
    fstarr[5][2] = (ufk[3][2]-(5.89*Atkr[5][2]));
    fstarr[6][1] = (ufk[4][1]-(2.79*Atkr[6][1]));
    fstarr[6][2] = (ufk[4][2]-(2.79*Atkr[6][2]));
    fstarr[7][1] = (ufk[5][1]-(1.21*Atkr[7][1]));
    fstarr[7][2] = (ufk[5][2]-(1.21*Atkr[7][2]));
    fstarr[8][0] = (ufk[6][0]-(.55*Atkr[8][0]));
    fstarr[8][1] = (ufk[6][1]-(.55*Atkr[8][1]));
    fstarr[8][2] = (ufk[6][2]-(.55*Atkr[8][2]));
    fstarr[9][1] = (ufk[7][1]-(2.79*Atkr[9][1]));
    fstarr[9][2] = (ufk[7][2]-(2.79*Atkr[9][2]));
    fstarr[10][1] = (ufk[8][1]-(1.21*Atkr[10][1]));
    fstarr[10][2] = (ufk[8][2]-(1.21*Atkr[10][2]));
    fstarr[11][0] = (ufk[9][0]-(.55*Atkr[11][0]));
    fstarr[11][1] = (ufk[9][1]-(.55*Atkr[11][1]));
    fstarr[11][2] = (ufk[9][2]-(.55*Atkr[11][2]));
    fstarr[12][1] = (ufk[10][1]-(8.35*Atkr[12][1]));
    fstarr[12][2] = (ufk[10][2]-(8.35*Atkr[12][2]));
    fstarr[13][1] = (ufk[11][1]-(4.16*Atkr[13][1]));
    fstarr[13][2] = (ufk[11][2]-(4.16*Atkr[13][2]));
    fstarr[14][1] = (ufk[12][1]-(1.34*Atkr[14][1]));
    fstarr[14][2] = (ufk[12][2]-(1.34*Atkr[14][2]));
    fstarr[15][1] = (ufk[13][1]-(8.35*Atkr[15][1]));
    fstarr[15][2] = (ufk[13][2]-(8.35*Atkr[15][2]));
    fstarr[16][1] = (ufk[14][1]-(4.16*Atkr[16][1]));
    fstarr[16][2] = (ufk[14][2]-(4.16*Atkr[16][2]));
    fstarr[17][1] = (ufk[15][1]-(1.34*Atkr[17][1]));
    fstarr[17][2] = (ufk[15][2]-(1.34*Atkr[17][2]));
    tstarr[2][0] = (utk[0][0]-(.18*udotin[2]));
    tstarr[3][0] = (utk[1][0]-(.63*Otkr[3][0]));
    tstarr[4][0] = (utk[2][0]-(.006*Otkr[4][0]));
    tstarr[5][0] = (utk[3][0]-(.033*Otkr[5][0]));
    tstarr[6][0] = (utk[4][0]-(.025*Otkr[6][0]));
    tstarr[7][0] = (utk[5][0]-(.0054*Otkr[7][0]));
    tstarr[8][0] = (utk[6][0]-(WkIkWk[8][0]+(.0005*Otkr[8][0])));
    tstarr[8][1] = (utk[6][1]-(WkIkWk[8][1]+(.002*Otkr[8][1])));
    tstarr[8][2] = (utk[6][2]-(WkIkWk[8][2]+(.0016*udotin[8])));
    tstarr[9][0] = (utk[7][0]-(.025*Otkr[9][0]));
    tstarr[10][0] = (utk[8][0]-(.0054*Otkr[10][0]));
    tstarr[11][0] = (utk[9][0]-(WkIkWk[11][0]+(.0005*Otkr[11][0])));
    tstarr[11][1] = (utk[9][1]-(WkIkWk[11][1]+(.002*Otkr[11][1])));
    tstarr[11][2] = (utk[9][2]-(WkIkWk[11][2]+(.0016*udotin[11])));
    tstarr[12][0] = (utk[10][0]-(.16*Otkr[12][0]));
    tstarr[13][0] = (utk[11][0]-(.056*Otkr[13][0]));
    tstarr[14][0] = (utk[12][0]-(.0075*Otkr[14][0]));
    tstarr[15][0] = (utk[13][0]-(.16*Otkr[15][0]));
    tstarr[16][0] = (utk[14][0]-(.056*Otkr[16][0]));
    tstarr[17][0] = (utk[15][0]-(.0075*Otkr[17][0]));
/*
Now calculate the torques
*/
    trqout[17] = -(utau[17]+(tstarr[17][0]-((.039*fstarr[17][1])+(.0442*
      fstarr[17][2]))));
    Fstark[16][0] = (ufk[14][0]+ufk[15][0]);
    Fstark[16][1] = (fstarr[16][1]+((fstarr[17][1]*c17)-(fstarr[17][2]*s17)));
    Fstark[16][2] = (fstarr[16][2]+((fstarr[17][1]*s17)+(fstarr[17][2]*c17)));
    tvec1[0] = (tstarr[17][0]+((fstarr[17][2]*rik[17][1])-(fstarr[17][1]*
      rik[17][2])));
    tvec1[1] = (utk[15][1]+((rik[17][2]*ufk[15][0])-(.0078*fstarr[17][2])));
    tvec1[2] = (utk[15][2]+((.0078*fstarr[17][1])-(rik[17][1]*ufk[15][0])));
    Tstark[16][0] = (tstarr[16][0]+tvec1[0]);
    Tstark[16][1] = (utk[14][1]+((tvec1[1]*c17)-(tvec1[2]*s17)));
    Tstark[16][2] = (utk[14][2]+((tvec1[1]*s17)+(tvec1[2]*c17)));
    trqout[16] = -(utau[16]+(Tstark[16][0]+((.0039*Fstark[16][1])-(.2158*
      Fstark[16][2]))));
    Fstark[15][0] = (Fstark[16][0]+ufk[13][0]);
    Fstark[15][1] = (fstarr[15][1]+((Fstark[16][1]*c16)-(Fstark[16][2]*s16)));
    Fstark[15][2] = (fstarr[15][2]+((Fstark[16][1]*s16)+(Fstark[16][2]*c16)));
    tvec1[0] = (Tstark[16][0]+((Fstark[16][2]*rik[16][1])-(Fstark[16][1]*
      rik[16][2])));
    tvec1[1] = (Tstark[16][1]+((Fstark[16][0]*rik[16][2])-(.0247*Fstark[16][2]))
      );
    tvec1[2] = (Tstark[16][2]+((.0247*Fstark[16][1])-(Fstark[16][0]*rik[16][1]))
      );
    Tstark[15][0] = (tstarr[15][0]+tvec1[0]);
    Tstark[15][1] = (utk[13][1]+((tvec1[1]*c16)-(tvec1[2]*s16)));
    Tstark[15][2] = (utk[13][2]+((tvec1[1]*s16)+(tvec1[2]*c16)));
    trqout[15] = -(utau[15]+(Tstark[15][0]-((.0143*Fstark[15][1])+(.2379*
      Fstark[15][2]))));
    Fstark[2][0] = (Fstark[15][0]+ufk[0][0]);
    Fstark[2][1] = (fstarr[2][1]+((Fstark[15][1]*c15)-(Fstark[15][2]*s15)));
    Fstark[2][2] = (fstarr[2][2]+((Fstark[15][1]*s15)+(Fstark[15][2]*c15)));
    tvec1[0] = (Tstark[15][0]+((Fstark[15][2]*rik[15][1])-(Fstark[15][1]*
      rik[15][2])));
    tvec1[1] = (Tstark[15][1]+((.0949*Fstark[15][2])+(Fstark[15][0]*rik[15][2]))
      );
    tvec1[2] = (Tstark[15][2]-((.0949*Fstark[15][1])+(Fstark[15][0]*rik[15][1]))
      );
    Tstark[2][0] = (tstarr[2][0]+tvec1[0]);
    Tstark[2][1] = (utk[0][1]+((tvec1[1]*c15)-(tvec1[2]*s15)));
    Tstark[2][2] = (utk[0][2]+((tvec1[1]*s15)+(tvec1[2]*c15)));
    trqout[14] = -(utau[14]+(tstarr[14][0]-((.039*fstarr[14][1])+(.0442*
      fstarr[14][2]))));
    Fstark[13][0] = (ufk[11][0]+ufk[12][0]);
    Fstark[13][1] = (fstarr[13][1]+((fstarr[14][1]*c14)-(fstarr[14][2]*s14)));
    Fstark[13][2] = (fstarr[13][2]+((fstarr[14][1]*s14)+(fstarr[14][2]*c14)));
    tvec1[0] = (tstarr[14][0]+((fstarr[14][2]*rik[14][1])-(fstarr[14][1]*
      rik[14][2])));
    tvec1[1] = (utk[12][1]+((.0078*fstarr[14][2])+(rik[14][2]*ufk[12][0])));
    tvec1[2] = (utk[12][2]-((.0078*fstarr[14][1])+(rik[14][1]*ufk[12][0])));
    Tstark[13][0] = (tstarr[13][0]+tvec1[0]);
    Tstark[13][1] = (utk[11][1]+((tvec1[1]*c14)-(tvec1[2]*s14)));
    Tstark[13][2] = (utk[11][2]+((tvec1[1]*s14)+(tvec1[2]*c14)));
    trqout[13] = -(utau[13]+(Tstark[13][0]+((.0039*Fstark[13][1])-(.2158*
      Fstark[13][2]))));
    Fstark[12][0] = (Fstark[13][0]+ufk[10][0]);
    Fstark[12][1] = (fstarr[12][1]+((Fstark[13][1]*c13)-(Fstark[13][2]*s13)));
    Fstark[12][2] = (fstarr[12][2]+((Fstark[13][1]*s13)+(Fstark[13][2]*c13)));
    tvec1[0] = (Tstark[13][0]+((Fstark[13][2]*rik[13][1])-(Fstark[13][1]*
      rik[13][2])));
    tvec1[1] = (Tstark[13][1]+((.0247*Fstark[13][2])+(Fstark[13][0]*rik[13][2]))
      );
    tvec1[2] = (Tstark[13][2]-((.0247*Fstark[13][1])+(Fstark[13][0]*rik[13][1]))
      );
    Tstark[12][0] = (tstarr[12][0]+tvec1[0]);
    Tstark[12][1] = (utk[10][1]+((tvec1[1]*c13)-(tvec1[2]*s13)));
    Tstark[12][2] = (utk[10][2]+((tvec1[1]*s13)+(tvec1[2]*c13)));
    trqout[12] = -(utau[12]+(Tstark[12][0]-((.0143*Fstark[12][1])+(.2379*
      Fstark[12][2]))));
    Fstark[2][0] = (Fstark[2][0]+Fstark[12][0]);
    Fstark[2][1] = (Fstark[2][1]+((Fstark[12][1]*c12)-(Fstark[12][2]*s12)));
    Fstark[2][2] = (Fstark[2][2]+((Fstark[12][1]*s12)+(Fstark[12][2]*c12)));
    tvec1[0] = (Tstark[12][0]+((Fstark[12][2]*rik[12][1])-(Fstark[12][1]*
      rik[12][2])));
    tvec1[1] = (Tstark[12][1]+((Fstark[12][0]*rik[12][2])-(.0949*Fstark[12][2]))
      );
    tvec1[2] = (Tstark[12][2]+((.0949*Fstark[12][1])-(Fstark[12][0]*rik[12][1]))
      );
    Tstark[2][0] = (Tstark[2][0]+tvec1[0]);
    Tstark[2][1] = (Tstark[2][1]+((tvec1[1]*c12)-(tvec1[2]*s12)));
    Tstark[2][2] = (Tstark[2][2]+((tvec1[1]*s12)+(tvec1[2]*c12)));
    trqout[11] = -(utau[11]+(tstarr[11][2]+(.065*fstarr[11][0])));
    Fstark[10][0] = (ufk[8][0]+((fstarr[11][0]*c11)-(fstarr[11][1]*s11)));
    Fstark[10][1] = (fstarr[10][1]+((fstarr[11][0]*s11)+(fstarr[11][1]*c11)));
    Fstark[10][2] = (fstarr[10][2]+fstarr[11][2]);
    tvec1[0] = (tstarr[11][0]+(fstarr[11][2]*rik[11][1]));
    tvec1[1] = (tstarr[11][1]-(fstarr[11][2]*rik[11][0]));
    tvec1[2] = (tstarr[11][2]+((fstarr[11][1]*rik[11][0])-(fstarr[11][0]*
      rik[11][1])));
    Tstark[10][0] = (tstarr[10][0]+((tvec1[0]*c11)-(tvec1[1]*s11)));
    Tstark[10][1] = (utk[8][1]+((tvec1[0]*s11)+(tvec1[1]*c11)));
    Tstark[10][2] = (tvec1[2]+utk[8][2]);
    trqout[10] = -(utau[10]+(Tstark[10][0]-(.1378*Fstark[10][2])));
    Fstark[9][0] = (Fstark[10][0]+ufk[7][0]);
    Fstark[9][1] = (fstarr[9][1]+((Fstark[10][1]*c10)-(Fstark[10][2]*s10)));
    Fstark[9][2] = (fstarr[9][2]+((Fstark[10][1]*s10)+(Fstark[10][2]*c10)));
    tvec1[0] = (Tstark[10][0]+((Fstark[10][2]*rik[10][1])-(Fstark[10][1]*
      rik[10][2])));
    tvec1[1] = (Tstark[10][1]+((Fstark[10][0]*rik[10][2])-(.0039*Fstark[10][2]))
      );
    tvec1[2] = (Tstark[10][2]+((.0039*Fstark[10][1])-(Fstark[10][0]*rik[10][1]))
      );
    Tstark[9][0] = (tstarr[9][0]+tvec1[0]);
    Tstark[9][1] = (utk[7][1]+((tvec1[1]*c10)-(tvec1[2]*s10)));
    Tstark[9][2] = (utk[7][2]+((tvec1[1]*s10)+(tvec1[2]*c10)));
    trqout[9] = -(utau[9]+(Tstark[9][0]-((.0013*Fstark[9][1])+(.1326*
      Fstark[9][2]))));
    Fstark[3][0] = (Fstark[9][0]+ufk[1][0]);
    Fstark[3][1] = (fstarr[3][1]+((Fstark[9][1]*c9)-(Fstark[9][2]*s9)));
    Fstark[3][2] = (fstarr[3][2]+((Fstark[9][1]*s9)+(Fstark[9][2]*c9)));
    tvec1[0] = (Tstark[9][0]+((Fstark[9][2]*rik[9][1])-(Fstark[9][1]*rik[9][2]))
      );
    tvec1[1] = (Tstark[9][1]+((.1768*Fstark[9][2])+(Fstark[9][0]*rik[9][2])));
    tvec1[2] = (Tstark[9][2]-((.1768*Fstark[9][1])+(Fstark[9][0]*rik[9][1])));
    Tstark[3][0] = (tstarr[3][0]+tvec1[0]);
    Tstark[3][1] = (utk[1][1]+((tvec1[1]*c9)-(tvec1[2]*s9)));
    Tstark[3][2] = (utk[1][2]+((tvec1[1]*s9)+(tvec1[2]*c9)));
    trqout[8] = -(utau[8]+(tstarr[8][2]+(.065*fstarr[8][0])));
    Fstark[7][0] = (ufk[5][0]+((fstarr[8][0]*c8)-(fstarr[8][1]*s8)));
    Fstark[7][1] = (fstarr[7][1]+((fstarr[8][0]*s8)+(fstarr[8][1]*c8)));
    Fstark[7][2] = (fstarr[7][2]+fstarr[8][2]);
    tvec1[0] = (tstarr[8][0]+(fstarr[8][2]*rik[8][1]));
    tvec1[1] = (tstarr[8][1]-(fstarr[8][2]*rik[8][0]));
    tvec1[2] = (tstarr[8][2]+((fstarr[8][1]*rik[8][0])-(fstarr[8][0]*rik[8][1]))
      );
    Tstark[7][0] = (tstarr[7][0]+((tvec1[0]*c8)-(tvec1[1]*s8)));
    Tstark[7][1] = (utk[5][1]+((tvec1[0]*s8)+(tvec1[1]*c8)));
    Tstark[7][2] = (tvec1[2]+utk[5][2]);
    trqout[7] = -(utau[7]+(Tstark[7][0]-(.1378*Fstark[7][2])));
    Fstark[6][0] = (Fstark[7][0]+ufk[4][0]);
    Fstark[6][1] = (fstarr[6][1]+((Fstark[7][1]*c7)-(Fstark[7][2]*s7)));
    Fstark[6][2] = (fstarr[6][2]+((Fstark[7][1]*s7)+(Fstark[7][2]*c7)));
    tvec1[0] = (Tstark[7][0]+((Fstark[7][2]*rik[7][1])-(Fstark[7][1]*rik[7][2]))
      );
    tvec1[1] = (Tstark[7][1]+((.0039*Fstark[7][2])+(Fstark[7][0]*rik[7][2])));
    tvec1[2] = (Tstark[7][2]-((.0039*Fstark[7][1])+(Fstark[7][0]*rik[7][1])));
    Tstark[6][0] = (tstarr[6][0]+tvec1[0]);
    Tstark[6][1] = (utk[4][1]+((tvec1[1]*c7)-(tvec1[2]*s7)));
    Tstark[6][2] = (utk[4][2]+((tvec1[1]*s7)+(tvec1[2]*c7)));
    trqout[6] = -(utau[6]+(Tstark[6][0]-((.0013*Fstark[6][1])+(.1326*
      Fstark[6][2]))));
    Fstark[3][0] = (Fstark[3][0]+Fstark[6][0]);
    Fstark[3][1] = (Fstark[3][1]+((Fstark[6][1]*c6)-(Fstark[6][2]*s6)));
    Fstark[3][2] = (Fstark[3][2]+((Fstark[6][1]*s6)+(Fstark[6][2]*c6)));
    tvec1[0] = (Tstark[6][0]+((Fstark[6][2]*rik[6][1])-(Fstark[6][1]*rik[6][2]))
      );
    tvec1[1] = (Tstark[6][1]+((Fstark[6][0]*rik[6][2])-(.1768*Fstark[6][2])));
    tvec1[2] = (Tstark[6][2]+((.1768*Fstark[6][1])-(Fstark[6][0]*rik[6][1])));
    Tstark[3][0] = (Tstark[3][0]+tvec1[0]);
    Tstark[3][1] = (Tstark[3][1]+((tvec1[1]*c6)-(tvec1[2]*s6)));
    Tstark[3][2] = (Tstark[3][2]+((tvec1[1]*s6)+(tvec1[2]*c6)));
    trqout[5] = -(utau[5]+(tstarr[5][0]+((.078*fstarr[5][2])-(.0312*fstarr[5][1]
      ))));
    Fstark[4][0] = (ufk[2][0]+ufk[3][0]);
    Fstark[4][1] = (fstarr[4][1]+((fstarr[5][1]*c5)-(fstarr[5][2]*s5)));
    Fstark[4][2] = (fstarr[4][2]+((fstarr[5][1]*s5)+(fstarr[5][2]*c5)));
    tvec1[0] = (tstarr[5][0]+((fstarr[5][2]*rik[5][1])-(fstarr[5][1]*rik[5][2]))
      );
    tvec1[1] = (utk[3][1]+(rik[5][2]*ufk[3][0]));
    tvec1[2] = (utk[3][2]-(rik[5][1]*ufk[3][0]));
    Tstark[4][0] = (tstarr[4][0]+tvec1[0]);
    Tstark[4][1] = (utk[2][1]+((tvec1[1]*c5)-(tvec1[2]*s5)));
    Tstark[4][2] = (utk[2][2]+((tvec1[1]*s5)+(tvec1[2]*c5)));
    trqout[4] = -(utau[4]+(Tstark[4][0]+((.0442*Fstark[4][2])-(.0065*
      Fstark[4][1]))));
    Fstark[3][0] = (Fstark[3][0]+Fstark[4][0]);
    Fstark[3][1] = (Fstark[3][1]+((Fstark[4][1]*c4)-(Fstark[4][2]*s4)));
    Fstark[3][2] = (Fstark[3][2]+((Fstark[4][1]*s4)+(Fstark[4][2]*c4)));
    tvec1[0] = (Tstark[4][0]+((Fstark[4][2]*rik[4][1])-(Fstark[4][1]*rik[4][2]))
      );
    tvec1[1] = (Tstark[4][1]+(Fstark[4][0]*rik[4][2]));
    tvec1[2] = (Tstark[4][2]-(Fstark[4][0]*rik[4][1]));
    Tstark[3][0] = (Tstark[3][0]+tvec1[0]);
    Tstark[3][1] = (Tstark[3][1]+((tvec1[1]*c4)-(tvec1[2]*s4)));
    Tstark[3][2] = (Tstark[3][2]+((tvec1[1]*s4)+(tvec1[2]*c4)));
    trqout[3] = -(utau[3]+(Tstark[3][0]+((.0351*Fstark[3][1])+(.14625*
      Fstark[3][2]))));
    Fstark[2][0] = (Fstark[2][0]+Fstark[3][0]);
    Fstark[2][1] = (Fstark[2][1]+((Fstark[3][1]*c3)-(Fstark[3][2]*s3)));
    Fstark[2][2] = (Fstark[2][2]+((Fstark[3][1]*s3)+(Fstark[3][2]*c3)));
    tvec1[0] = (Tstark[3][0]+((Fstark[3][2]*rik[3][1])-(Fstark[3][1]*rik[3][2]))
      );
    tvec1[1] = (Tstark[3][1]+(Fstark[3][0]*rik[3][2]));
    tvec1[2] = (Tstark[3][2]-(Fstark[3][0]*rik[3][1]));
    Tstark[2][0] = (Tstark[2][0]+tvec1[0]);
    Tstark[2][1] = (Tstark[2][1]+((tvec1[1]*c3)-(tvec1[2]*s3)));
    Tstark[2][2] = (Tstark[2][2]+((tvec1[1]*s3)+(tvec1[2]*c3)));
    trqout[2] = -(utau[2]+(Tstark[2][0]+((.05*Fstark[2][1])-(.1206*Fstark[2][2])
      )));
    Fstark[1][0] = Fstark[2][0];
    Fstark[1][1] = ((Fstark[2][1]*c2)-(Fstark[2][2]*s2));
    Fstark[1][2] = ((Fstark[2][1]*s2)+(Fstark[2][2]*c2));
    tvec1[0] = (Tstark[2][0]+((.05*Fstark[2][1])-(.1206*Fstark[2][2])));
    tvec1[1] = (Tstark[2][1]-(.05*Fstark[2][0]));
    tvec1[2] = (Tstark[2][2]+(.1206*Fstark[2][0]));
    Tstark[1][0] = tvec1[0];
    Tstark[1][1] = ((tvec1[1]*c2)-(tvec1[2]*s2));
    Tstark[1][2] = ((tvec1[1]*s2)+(tvec1[2]*c2));
    trqout[1] = -(Fstark[1][2]+utau[1]);
    Fstark[0][0] = Fstark[1][0];
    Fstark[0][1] = Fstark[1][1];
    Fstark[0][2] = Fstark[1][2];
    tvec1[0] = (Tstark[1][0]-(Fstark[1][1]*q[1]));
    tvec1[1] = (Tstark[1][1]+(Fstark[1][0]*q[1]));
    Tstark[0][0] = tvec1[0];
    Tstark[0][1] = tvec1[1];
    Tstark[0][2] = Tstark[1][2];
    trqout[0] = -(Fstark[0][1]+utau[0]);
/*
Op counts below do not include called subroutines
*/
/*
 Used 0.46 seconds CPU time,
 0 additional bytes of memory.
 Equations contain  531 adds/subtracts/negates
                    538 multiplies
                      0 divides
                    305 assignments
*/
}

void robotcomptrq(double *udotin, double *trqout)
{
/* Compute hinge torques to produce these udots, ignoring constraints
*/
    double multin[1];

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(60,23);
        return;
    }
    robotfulltrq(udotin,multin,trqout);
}

void robotmulttrq(double *multin, double *trqout)
{
/* Compute hinge trqs which would be produced by these mults.
*/
    int i;

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(65,23);
        return;
    }
    for (i = 0; i < 18; i++) {
        trqout[i] = 0.;
    }
}

void robotfs0(void)
{

/*
Compute Fs (ignoring multiplier forces)
*/
    fs[0] = fs0[0];
    fs[1] = fs0[1];
    fs[2] = fs0[2];
    fs[3] = fs0[3];
    fs[4] = fs0[4];
    fs[5] = fs0[5];
    fs[6] = fs0[6];
    fs[7] = fs0[7];
    fs[8] = fs0[8];
    fs[9] = fs0[9];
    fs[10] = fs0[10];
    fs[11] = fs0[11];
    fs[12] = fs0[12];
    fs[13] = fs0[13];
    fs[14] = fs0[14];
    fs[15] = fs0[15];
    fs[16] = fs0[16];
    fs[17] = fs0[17];
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     18 assignments
*/
}

void robotfsmult(void)
{
    int i;

/*
Compute Fs (multiplier-generated forces only)
*/
    for (i = 0; i < 18; i++) {
        fs[i] = 0.;
    }
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     18 assignments
*/
}

void robotfsfull(void)
{

/*
Compute Fs (including all forces)
*/
    robotfsmult();
    fs[0] = (fs[0]+fs0[0]);
    fs[1] = (fs[1]+fs0[1]);
    fs[2] = (fs[2]+fs0[2]);
    fs[3] = (fs[3]+fs0[3]);
    fs[4] = (fs[4]+fs0[4]);
    fs[5] = (fs[5]+fs0[5]);
    fs[6] = (fs[6]+fs0[6]);
    fs[7] = (fs[7]+fs0[7]);
    fs[8] = (fs[8]+fs0[8]);
    fs[9] = (fs[9]+fs0[9]);
    fs[10] = (fs[10]+fs0[10]);
    fs[11] = (fs[11]+fs0[11]);
    fs[12] = (fs[12]+fs0[12]);
    fs[13] = (fs[13]+fs0[13]);
    fs[14] = (fs[14]+fs0[14]);
    fs[15] = (fs[15]+fs0[15]);
    fs[16] = (fs[16]+fs0[16]);
    fs[17] = (fs[17]+fs0[17]);
/*
 Used 0.01 seconds CPU time,
 0 additional bytes of memory.
 Equations contain   18 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     18 assignments
*/
}

void robotfsgenmult(void)
{
    int i;

/*
Compute Fs (generic multiplier-generated forces)
*/
    for (i = 0; i < 18; i++) {
        fs[i] = 0.;
    }
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     18 assignments
*/
}

void robotfsgenfull(void)
{

/*
Compute Fs (incl generic mult & other forces)
*/
    robotfsgenmult();
    fs[0] = (fs[0]+fs0[0]);
    fs[1] = (fs[1]+fs0[1]);
    fs[2] = (fs[2]+fs0[2]);
    fs[3] = (fs[3]+fs0[3]);
    fs[4] = (fs[4]+fs0[4]);
    fs[5] = (fs[5]+fs0[5]);
    fs[6] = (fs[6]+fs0[6]);
    fs[7] = (fs[7]+fs0[7]);
    fs[8] = (fs[8]+fs0[8]);
    fs[9] = (fs[9]+fs0[9]);
    fs[10] = (fs[10]+fs0[10]);
    fs[11] = (fs[11]+fs0[11]);
    fs[12] = (fs[12]+fs0[12]);
    fs[13] = (fs[13]+fs0[13]);
    fs[14] = (fs[14]+fs0[14]);
    fs[15] = (fs[15]+fs0[15]);
    fs[16] = (fs[16]+fs0[16]);
    fs[17] = (fs[17]+fs0[17]);
/*
 Used 0.01 seconds CPU time,
 0 additional bytes of memory.
 Equations contain   18 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     18 assignments
*/
}

void robotrhs(void)
{
/*
Generated 19-Jul-2001 15:43:03 by SD/FAST, Order(N) formulation
(sdfast B.2.6 #70405) on machine ID 690a1b33
Copyright (c) 1990-1996 Symbolic Dynamics, Inc.
Copyright (c) 1990-1996 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/

/*
Compute hinge torques for tree hinges
*/
    tauc[0] = utau[0];
    tauc[1] = utau[1];
    tauc[2] = utau[2];
    tauc[3] = utau[3];
    tauc[4] = utau[4];
    tauc[5] = utau[5];
    tauc[6] = utau[6];
    tauc[7] = utau[7];
    tauc[8] = utau[8];
    tauc[9] = utau[9];
    tauc[10] = utau[10];
    tauc[11] = utau[11];
    tauc[12] = utau[12];
    tauc[13] = utau[13];
    tauc[14] = utau[14];
    tauc[15] = utau[15];
    tauc[16] = utau[16];
    tauc[17] = utau[17];
    robotdoiner();
/*
Compute onk & onb (angular accels in N)
*/
    Onkb[3][0] = (udot[2]+udot[3]);
    Onkb[4][0] = (Onkb[3][0]+udot[4]);
    Onkb[5][0] = (Onkb[4][0]+udot[5]);
    Onkb[6][0] = (Onkb[3][0]+udot[6]);
    Onkb[7][0] = (Onkb[6][0]+udot[7]);
    Onkb[8][0] = (Onkb[7][0]*c8);
    Onkb[8][1] = -(Onkb[7][0]*s8);
    Onkb[9][0] = (Onkb[3][0]+udot[9]);
    Onkb[10][0] = (Onkb[9][0]+udot[10]);
    Onkb[11][0] = (Onkb[10][0]*c11);
    Onkb[11][1] = -(Onkb[10][0]*s11);
    Onkb[12][0] = (udot[2]+udot[12]);
    Onkb[13][0] = (Onkb[12][0]+udot[13]);
    Onkb[14][0] = (Onkb[13][0]+udot[14]);
    Onkb[15][0] = (udot[2]+udot[15]);
    Onkb[16][0] = (Onkb[15][0]+udot[16]);
    Onkb[17][0] = (Onkb[16][0]+udot[17]);
    onk[8][0] = (Onkb[8][0]+Otk[8][0]);
    onk[8][1] = (Onkb[8][1]+Otk[8][1]);
    onk[11][0] = (Onkb[11][0]+Otk[11][0]);
    onk[11][1] = (Onkb[11][1]+Otk[11][1]);
    onb[0][0] = udot[2];
    onb[0][1] = 0.;
    onb[0][2] = 0.;
    onb[1][0] = Onkb[3][0];
    onb[1][1] = 0.;
    onb[1][2] = 0.;
    onb[2][0] = Onkb[4][0];
    onb[2][1] = 0.;
    onb[2][2] = 0.;
    onb[3][0] = Onkb[5][0];
    onb[3][1] = 0.;
    onb[3][2] = 0.;
    onb[4][0] = Onkb[6][0];
    onb[4][1] = 0.;
    onb[4][2] = 0.;
    onb[5][0] = Onkb[7][0];
    onb[5][1] = 0.;
    onb[5][2] = 0.;
    onb[6][0] = onk[8][0];
    onb[6][1] = onk[8][1];
    onb[6][2] = udot[8];
    onb[7][0] = Onkb[9][0];
    onb[7][1] = 0.;
    onb[7][2] = 0.;
    onb[8][0] = Onkb[10][0];
    onb[8][1] = 0.;
    onb[8][2] = 0.;
    onb[9][0] = onk[11][0];
    onb[9][1] = onk[11][1];
    onb[9][2] = udot[11];
    onb[10][0] = Onkb[12][0];
    onb[10][1] = 0.;
    onb[10][2] = 0.;
    onb[11][0] = Onkb[13][0];
    onb[11][1] = 0.;
    onb[11][2] = 0.;
    onb[12][0] = Onkb[14][0];
    onb[12][1] = 0.;
    onb[12][2] = 0.;
    onb[13][0] = Onkb[15][0];
    onb[13][1] = 0.;
    onb[13][2] = 0.;
    onb[14][0] = Onkb[16][0];
    onb[14][1] = 0.;
    onb[14][2] = 0.;
    onb[15][0] = Onkb[17][0];
    onb[15][1] = 0.;
    onb[15][2] = 0.;
/*
Compute acceleration dyadics
*/
    dyad[0][0][0] = 0.;
    dyad[0][0][1] = 0.;
    dyad[0][0][2] = 0.;
    dyad[0][1][0] = 0.;
    dyad[0][1][1] = -w0w0[0];
    dyad[0][1][2] = -udot[2];
    dyad[0][2][0] = 0.;
    dyad[0][2][1] = udot[2];
    dyad[0][2][2] = -w0w0[0];
    dyad[1][0][0] = 0.;
    dyad[1][0][1] = 0.;
    dyad[1][0][2] = 0.;
    dyad[1][1][0] = 0.;
    dyad[1][1][1] = -w0w0[1];
    dyad[1][1][2] = -Onkb[3][0];
    dyad[1][2][0] = 0.;
    dyad[1][2][1] = Onkb[3][0];
    dyad[1][2][2] = -w0w0[1];
    dyad[2][0][0] = 0.;
    dyad[2][0][1] = 0.;
    dyad[2][0][2] = 0.;
    dyad[2][1][0] = 0.;
    dyad[2][1][1] = -w0w0[2];
    dyad[2][1][2] = -Onkb[4][0];
    dyad[2][2][0] = 0.;
    dyad[2][2][1] = Onkb[4][0];
    dyad[2][2][2] = -w0w0[2];
    dyad[3][0][0] = 0.;
    dyad[3][0][1] = 0.;
    dyad[3][0][2] = 0.;
    dyad[3][1][0] = 0.;
    dyad[3][1][1] = -w0w0[3];
    dyad[3][1][2] = -Onkb[5][0];
    dyad[3][2][0] = 0.;
    dyad[3][2][1] = Onkb[5][0];
    dyad[3][2][2] = -w0w0[3];
    dyad[4][0][0] = 0.;
    dyad[4][0][1] = 0.;
    dyad[4][0][2] = 0.;
    dyad[4][1][0] = 0.;
    dyad[4][1][1] = -w0w0[4];
    dyad[4][1][2] = -Onkb[6][0];
    dyad[4][2][0] = 0.;
    dyad[4][2][1] = Onkb[6][0];
    dyad[4][2][2] = -w0w0[4];
    dyad[5][0][0] = 0.;
    dyad[5][0][1] = 0.;
    dyad[5][0][2] = 0.;
    dyad[5][1][0] = 0.;
    dyad[5][1][1] = -w0w0[5];
    dyad[5][1][2] = -Onkb[7][0];
    dyad[5][2][0] = 0.;
    dyad[5][2][1] = Onkb[7][0];
    dyad[5][2][2] = -w0w0[5];
    dyad[6][0][0] = w11w22[6];
    dyad[6][0][1] = (w0w1[6]-udot[8]);
    dyad[6][0][2] = (onk[8][1]+w0w2[6]);
    dyad[6][1][0] = (udot[8]+w0w1[6]);
    dyad[6][1][1] = w00w22[6];
    dyad[6][1][2] = (w1w2[6]-onk[8][0]);
    dyad[6][2][0] = (w0w2[6]-onk[8][1]);
    dyad[6][2][1] = (onk[8][0]+w1w2[6]);
    dyad[6][2][2] = w00w11[6];
    dyad[7][0][0] = 0.;
    dyad[7][0][1] = 0.;
    dyad[7][0][2] = 0.;
    dyad[7][1][0] = 0.;
    dyad[7][1][1] = -w0w0[7];
    dyad[7][1][2] = -Onkb[9][0];
    dyad[7][2][0] = 0.;
    dyad[7][2][1] = Onkb[9][0];
    dyad[7][2][2] = -w0w0[7];
    dyad[8][0][0] = 0.;
    dyad[8][0][1] = 0.;
    dyad[8][0][2] = 0.;
    dyad[8][1][0] = 0.;
    dyad[8][1][1] = -w0w0[8];
    dyad[8][1][2] = -Onkb[10][0];
    dyad[8][2][0] = 0.;
    dyad[8][2][1] = Onkb[10][0];
    dyad[8][2][2] = -w0w0[8];
    dyad[9][0][0] = w11w22[9];
    dyad[9][0][1] = (w0w1[9]-udot[11]);
    dyad[9][0][2] = (onk[11][1]+w0w2[9]);
    dyad[9][1][0] = (udot[11]+w0w1[9]);
    dyad[9][1][1] = w00w22[9];
    dyad[9][1][2] = (w1w2[9]-onk[11][0]);
    dyad[9][2][0] = (w0w2[9]-onk[11][1]);
    dyad[9][2][1] = (onk[11][0]+w1w2[9]);
    dyad[9][2][2] = w00w11[9];
    dyad[10][0][0] = 0.;
    dyad[10][0][1] = 0.;
    dyad[10][0][2] = 0.;
    dyad[10][1][0] = 0.;
    dyad[10][1][1] = -w0w0[10];
    dyad[10][1][2] = -Onkb[12][0];
    dyad[10][2][0] = 0.;
    dyad[10][2][1] = Onkb[12][0];
    dyad[10][2][2] = -w0w0[10];
    dyad[11][0][0] = 0.;
    dyad[11][0][1] = 0.;
    dyad[11][0][2] = 0.;
    dyad[11][1][0] = 0.;
    dyad[11][1][1] = -w0w0[11];
    dyad[11][1][2] = -Onkb[13][0];
    dyad[11][2][0] = 0.;
    dyad[11][2][1] = Onkb[13][0];
    dyad[11][2][2] = -w0w0[11];
    dyad[12][0][0] = 0.;
    dyad[12][0][1] = 0.;
    dyad[12][0][2] = 0.;
    dyad[12][1][0] = 0.;
    dyad[12][1][1] = -w0w0[12];
    dyad[12][1][2] = -Onkb[14][0];
    dyad[12][2][0] = 0.;
    dyad[12][2][1] = Onkb[14][0];
    dyad[12][2][2] = -w0w0[12];
    dyad[13][0][0] = 0.;
    dyad[13][0][1] = 0.;
    dyad[13][0][2] = 0.;
    dyad[13][1][0] = 0.;
    dyad[13][1][1] = -w0w0[13];
    dyad[13][1][2] = -Onkb[15][0];
    dyad[13][2][0] = 0.;
    dyad[13][2][1] = Onkb[15][0];
    dyad[13][2][2] = -w0w0[13];
    dyad[14][0][0] = 0.;
    dyad[14][0][1] = 0.;
    dyad[14][0][2] = 0.;
    dyad[14][1][0] = 0.;
    dyad[14][1][1] = -w0w0[14];
    dyad[14][1][2] = -Onkb[16][0];
    dyad[14][2][0] = 0.;
    dyad[14][2][1] = Onkb[16][0];
    dyad[14][2][2] = -w0w0[14];
    dyad[15][0][0] = 0.;
    dyad[15][0][1] = 0.;
    dyad[15][0][2] = 0.;
    dyad[15][1][0] = 0.;
    dyad[15][1][1] = -w0w0[15];
    dyad[15][1][2] = -Onkb[17][0];
    dyad[15][2][0] = 0.;
    dyad[15][2][1] = Onkb[17][0];
    dyad[15][2][2] = -w0w0[15];
/*
Compute ank & anb (mass center linear accels in N)
*/
    Ankb[2][1] = ((.05*udot[2])+((udot[0]*c2)+(udot[1]*s2)));
    Ankb[2][2] = (((udot[1]*c2)-(udot[0]*s2))-(.1206*udot[2]));
    AOnkri[3][1] = (Ankb[2][1]-(.05*udot[2]));
    AOnkri[3][2] = (Ankb[2][2]+(.1206*udot[2]));
    Ankb[3][1] = ((.0351*Onkb[3][0])+((AOnkri[3][1]*c3)+(AOnkri[3][2]*s3)));
    Ankb[3][2] = ((.14625*Onkb[3][0])+((AOnkri[3][2]*c3)-(AOnkri[3][1]*s3)));
    AOnkri[4][1] = (Ankb[3][1]+(.0013*Onkb[3][0]));
    AOnkri[4][2] = (Ankb[3][2]+(.24635*Onkb[3][0]));
    Ankb[4][1] = (((AOnkri[4][1]*c4)+(AOnkri[4][2]*s4))-(.0065*Onkb[4][0]));
    Ankb[4][2] = ((.0442*Onkb[4][0])+((AOnkri[4][2]*c4)-(AOnkri[4][1]*s4)));
    AOnkri[5][1] = (Ankb[4][1]-(.0065*Onkb[4][0]));
    AOnkri[5][2] = (Ankb[4][2]+(.0442*Onkb[4][0]));
    Ankb[5][1] = (((AOnkri[5][1]*c5)+(AOnkri[5][2]*s5))-(.0312*Onkb[5][0]));
    Ankb[5][2] = ((.078*Onkb[5][0])+((AOnkri[5][2]*c5)-(AOnkri[5][1]*s5)));
    AOnkri[6][1] = (Ankb[3][1]-(.0013*Onkb[3][0]));
    AOnkri[6][2] = (Ankb[3][2]+(.18915*Onkb[3][0]));
    Ankb[6][1] = (((AOnkri[6][1]*c6)+(AOnkri[6][2]*s6))-(.0013*Onkb[6][0]));
    Ankb[6][2] = (((AOnkri[6][2]*c6)-(AOnkri[6][1]*s6))-(.1326*Onkb[6][0]));
    AOnkri[7][1] = (Ankb[6][1]-(.0013*Onkb[6][0]));
    AOnkri[7][2] = (Ankb[6][2]-(.1326*Onkb[6][0]));
    Ankb[7][1] = ((AOnkri[7][1]*c7)+(AOnkri[7][2]*s7));
    Ankb[7][2] = (((AOnkri[7][2]*c7)-(AOnkri[7][1]*s7))-(.1378*Onkb[7][0]));
    AOnkri[8][2] = (Ankb[7][2]-(.1378*Onkb[7][0]));
    Ankb[8][0] = ((.065*udot[8])+(Ankb[7][1]*s8));
    Ankb[8][1] = (Ankb[7][1]*c8);
    Ankb[8][2] = (AOnkri[8][2]-(.065*Onkb[8][0]));
    AOnkri[9][1] = (Ankb[3][1]-(.0013*Onkb[3][0]));
    AOnkri[9][2] = (Ankb[3][2]+(.18915*Onkb[3][0]));
    Ankb[9][1] = (((AOnkri[9][1]*c9)+(AOnkri[9][2]*s9))-(.0013*Onkb[9][0]));
    Ankb[9][2] = (((AOnkri[9][2]*c9)-(AOnkri[9][1]*s9))-(.1326*Onkb[9][0]));
    AOnkri[10][1] = (Ankb[9][1]-(.0013*Onkb[9][0]));
    AOnkri[10][2] = (Ankb[9][2]-(.1326*Onkb[9][0]));
    Ankb[10][1] = ((AOnkri[10][1]*c10)+(AOnkri[10][2]*s10));
    Ankb[10][2] = (((AOnkri[10][2]*c10)-(AOnkri[10][1]*s10))-(.1378*Onkb[10][0])
      );
    AOnkri[11][2] = (Ankb[10][2]-(.1378*Onkb[10][0]));
    Ankb[11][0] = ((.065*udot[11])+(Ankb[10][1]*s11));
    Ankb[11][1] = (Ankb[10][1]*c11);
    Ankb[11][2] = (AOnkri[11][2]-(.065*Onkb[11][0]));
    AOnkri[12][1] = (Ankb[2][1]-(.0058*udot[2]));
    AOnkri[12][2] = (Ankb[2][2]-(.0406*udot[2]));
    Ankb[12][1] = (((AOnkri[12][1]*c12)+(AOnkri[12][2]*s12))-(.0143*Onkb[12][0])
      );
    Ankb[12][2] = (((AOnkri[12][2]*c12)-(AOnkri[12][1]*s12))-(.2379*Onkb[12][0])
      );
    AOnkri[13][1] = (Ankb[12][1]-(.0143*Onkb[12][0]));
    AOnkri[13][2] = (Ankb[12][2]-(.2379*Onkb[12][0]));
    Ankb[13][1] = ((.0039*Onkb[13][0])+((AOnkri[13][1]*c13)+(AOnkri[13][2]*s13))
      );
    Ankb[13][2] = (((AOnkri[13][2]*c13)-(AOnkri[13][1]*s13))-(.2158*Onkb[13][0])
      );
    AOnkri[14][1] = (Ankb[13][1]+(.0039*Onkb[13][0]));
    AOnkri[14][2] = (Ankb[13][2]-(.2158*Onkb[13][0]));
    Ankb[14][1] = (((AOnkri[14][1]*c14)+(AOnkri[14][2]*s14))-(.039*Onkb[14][0]))
      ;
    Ankb[14][2] = (((AOnkri[14][2]*c14)-(AOnkri[14][1]*s14))-(.0442*Onkb[14][0])
      );
    AOnkri[15][1] = (Ankb[2][1]-(.0058*udot[2]));
    AOnkri[15][2] = (Ankb[2][2]-(.0406*udot[2]));
    Ankb[15][1] = (((AOnkri[15][1]*c15)+(AOnkri[15][2]*s15))-(.0143*Onkb[15][0])
      );
    Ankb[15][2] = (((AOnkri[15][2]*c15)-(AOnkri[15][1]*s15))-(.2379*Onkb[15][0])
      );
    AOnkri[16][1] = (Ankb[15][1]-(.0143*Onkb[15][0]));
    AOnkri[16][2] = (Ankb[15][2]-(.2379*Onkb[15][0]));
    Ankb[16][1] = ((.0039*Onkb[16][0])+((AOnkri[16][1]*c16)+(AOnkri[16][2]*s16))
      );
    Ankb[16][2] = (((AOnkri[16][2]*c16)-(AOnkri[16][1]*s16))-(.2158*Onkb[16][0])
      );
    AOnkri[17][1] = (Ankb[16][1]+(.0039*Onkb[16][0]));
    AOnkri[17][2] = (Ankb[16][2]-(.2158*Onkb[16][0]));
    Ankb[17][1] = (((AOnkri[17][1]*c17)+(AOnkri[17][2]*s17))-(.039*Onkb[17][0]))
      ;
    Ankb[17][2] = (((AOnkri[17][2]*c17)-(AOnkri[17][1]*s17))-(.0442*Onkb[17][0])
      );
    AnkAtk[2][1] = (Ankb[2][1]+Atk[2][1]);
    AnkAtk[2][2] = (Ankb[2][2]+Atk[2][2]);
    ank[2][1] = ((AnkAtk[2][1]*c2)-(AnkAtk[2][2]*s2));
    ank[2][2] = ((AnkAtk[2][1]*s2)+(AnkAtk[2][2]*c2));
    AnkAtk[3][1] = (Ankb[3][1]+Atk[3][1]);
    AnkAtk[3][2] = (Ankb[3][2]+Atk[3][2]);
    ank[3][1] = ((AnkAtk[3][1]*cnk[3][1][1])+(AnkAtk[3][2]*cnk[3][1][2]));
    ank[3][2] = ((AnkAtk[3][1]*cnk[3][2][1])+(AnkAtk[3][2]*cnk[3][2][2]));
    AnkAtk[4][1] = (Ankb[4][1]+Atk[4][1]);
    AnkAtk[4][2] = (Ankb[4][2]+Atk[4][2]);
    ank[4][1] = ((AnkAtk[4][1]*cnk[4][1][1])+(AnkAtk[4][2]*cnk[4][1][2]));
    ank[4][2] = ((AnkAtk[4][1]*cnk[4][2][1])+(AnkAtk[4][2]*cnk[4][2][2]));
    AnkAtk[5][1] = (Ankb[5][1]+Atk[5][1]);
    AnkAtk[5][2] = (Ankb[5][2]+Atk[5][2]);
    ank[5][1] = ((AnkAtk[5][1]*cnk[5][1][1])+(AnkAtk[5][2]*cnk[5][1][2]));
    ank[5][2] = ((AnkAtk[5][1]*cnk[5][2][1])+(AnkAtk[5][2]*cnk[5][2][2]));
    AnkAtk[6][1] = (Ankb[6][1]+Atk[6][1]);
    AnkAtk[6][2] = (Ankb[6][2]+Atk[6][2]);
    ank[6][1] = ((AnkAtk[6][1]*cnk[6][1][1])+(AnkAtk[6][2]*cnk[6][1][2]));
    ank[6][2] = ((AnkAtk[6][1]*cnk[6][2][1])+(AnkAtk[6][2]*cnk[6][2][2]));
    AnkAtk[7][1] = (Ankb[7][1]+Atk[7][1]);
    AnkAtk[7][2] = (Ankb[7][2]+Atk[7][2]);
    ank[7][1] = ((AnkAtk[7][1]*cnk[7][1][1])+(AnkAtk[7][2]*cnk[7][1][2]));
    ank[7][2] = ((AnkAtk[7][1]*cnk[7][2][1])+(AnkAtk[7][2]*cnk[7][2][2]));
    AnkAtk[8][0] = (Ankb[8][0]+Atk[8][0]);
    AnkAtk[8][1] = (Ankb[8][1]+Atk[8][1]);
    AnkAtk[8][2] = (Ankb[8][2]+Atk[8][2]);
    ank[8][0] = ((AnkAtk[8][0]*c8)-(AnkAtk[8][1]*s8));
    ank[8][1] = ((AnkAtk[8][2]*cnk[7][1][2])+((AnkAtk[8][0]*cnk[8][1][0])+(
      AnkAtk[8][1]*cnk[8][1][1])));
    ank[8][2] = ((AnkAtk[8][2]*cnk[7][2][2])+((AnkAtk[8][0]*cnk[8][2][0])+(
      AnkAtk[8][1]*cnk[8][2][1])));
    AnkAtk[9][1] = (Ankb[9][1]+Atk[9][1]);
    AnkAtk[9][2] = (Ankb[9][2]+Atk[9][2]);
    ank[9][1] = ((AnkAtk[9][1]*cnk[9][1][1])+(AnkAtk[9][2]*cnk[9][1][2]));
    ank[9][2] = ((AnkAtk[9][1]*cnk[9][2][1])+(AnkAtk[9][2]*cnk[9][2][2]));
    AnkAtk[10][1] = (Ankb[10][1]+Atk[10][1]);
    AnkAtk[10][2] = (Ankb[10][2]+Atk[10][2]);
    ank[10][1] = ((AnkAtk[10][1]*cnk[10][1][1])+(AnkAtk[10][2]*cnk[10][1][2]));
    ank[10][2] = ((AnkAtk[10][1]*cnk[10][2][1])+(AnkAtk[10][2]*cnk[10][2][2]));
    AnkAtk[11][0] = (Ankb[11][0]+Atk[11][0]);
    AnkAtk[11][1] = (Ankb[11][1]+Atk[11][1]);
    AnkAtk[11][2] = (Ankb[11][2]+Atk[11][2]);
    ank[11][0] = ((AnkAtk[11][0]*c11)-(AnkAtk[11][1]*s11));
    ank[11][1] = ((AnkAtk[11][2]*cnk[10][1][2])+((AnkAtk[11][0]*cnk[11][1][0])+(
      AnkAtk[11][1]*cnk[11][1][1])));
    ank[11][2] = ((AnkAtk[11][2]*cnk[10][2][2])+((AnkAtk[11][0]*cnk[11][2][0])+(
      AnkAtk[11][1]*cnk[11][2][1])));
    AnkAtk[12][1] = (Ankb[12][1]+Atk[12][1]);
    AnkAtk[12][2] = (Ankb[12][2]+Atk[12][2]);
    ank[12][1] = ((AnkAtk[12][1]*cnk[12][1][1])+(AnkAtk[12][2]*cnk[12][1][2]));
    ank[12][2] = ((AnkAtk[12][1]*cnk[12][2][1])+(AnkAtk[12][2]*cnk[12][2][2]));
    AnkAtk[13][1] = (Ankb[13][1]+Atk[13][1]);
    AnkAtk[13][2] = (Ankb[13][2]+Atk[13][2]);
    ank[13][1] = ((AnkAtk[13][1]*cnk[13][1][1])+(AnkAtk[13][2]*cnk[13][1][2]));
    ank[13][2] = ((AnkAtk[13][1]*cnk[13][2][1])+(AnkAtk[13][2]*cnk[13][2][2]));
    AnkAtk[14][1] = (Ankb[14][1]+Atk[14][1]);
    AnkAtk[14][2] = (Ankb[14][2]+Atk[14][2]);
    ank[14][1] = ((AnkAtk[14][1]*cnk[14][1][1])+(AnkAtk[14][2]*cnk[14][1][2]));
    ank[14][2] = ((AnkAtk[14][1]*cnk[14][2][1])+(AnkAtk[14][2]*cnk[14][2][2]));
    AnkAtk[15][1] = (Ankb[15][1]+Atk[15][1]);
    AnkAtk[15][2] = (Ankb[15][2]+Atk[15][2]);
    ank[15][1] = ((AnkAtk[15][1]*cnk[15][1][1])+(AnkAtk[15][2]*cnk[15][1][2]));
    ank[15][2] = ((AnkAtk[15][1]*cnk[15][2][1])+(AnkAtk[15][2]*cnk[15][2][2]));
    AnkAtk[16][1] = (Ankb[16][1]+Atk[16][1]);
    AnkAtk[16][2] = (Ankb[16][2]+Atk[16][2]);
    ank[16][1] = ((AnkAtk[16][1]*cnk[16][1][1])+(AnkAtk[16][2]*cnk[16][1][2]));
    ank[16][2] = ((AnkAtk[16][1]*cnk[16][2][1])+(AnkAtk[16][2]*cnk[16][2][2]));
    AnkAtk[17][1] = (Ankb[17][1]+Atk[17][1]);
    AnkAtk[17][2] = (Ankb[17][2]+Atk[17][2]);
    ank[17][1] = ((AnkAtk[17][1]*cnk[17][1][1])+(AnkAtk[17][2]*cnk[17][1][2]));
    ank[17][2] = ((AnkAtk[17][1]*cnk[17][2][1])+(AnkAtk[17][2]*cnk[17][2][2]));
    anb[0][0] = 0.;
    anb[0][1] = ank[2][1];
    anb[0][2] = ank[2][2];
    anb[1][0] = 0.;
    anb[1][1] = ank[3][1];
    anb[1][2] = ank[3][2];
    anb[2][0] = 0.;
    anb[2][1] = ank[4][1];
    anb[2][2] = ank[4][2];
    anb[3][0] = 0.;
    anb[3][1] = ank[5][1];
    anb[3][2] = ank[5][2];
    anb[4][0] = 0.;
    anb[4][1] = ank[6][1];
    anb[4][2] = ank[6][2];
    anb[5][0] = 0.;
    anb[5][1] = ank[7][1];
    anb[5][2] = ank[7][2];
    anb[6][0] = ank[8][0];
    anb[6][1] = ank[8][1];
    anb[6][2] = ank[8][2];
    anb[7][0] = 0.;
    anb[7][1] = ank[9][1];
    anb[7][2] = ank[9][2];
    anb[8][0] = 0.;
    anb[8][1] = ank[10][1];
    anb[8][2] = ank[10][2];
    anb[9][0] = ank[11][0];
    anb[9][1] = ank[11][1];
    anb[9][2] = ank[11][2];
    anb[10][0] = 0.;
    anb[10][1] = ank[12][1];
    anb[10][2] = ank[12][2];
    anb[11][0] = 0.;
    anb[11][1] = ank[13][1];
    anb[11][2] = ank[13][2];
    anb[12][0] = 0.;
    anb[12][1] = ank[14][1];
    anb[12][2] = ank[14][2];
    anb[13][0] = 0.;
    anb[13][1] = ank[15][1];
    anb[13][2] = ank[15][2];
    anb[14][0] = 0.;
    anb[14][1] = ank[16][1];
    anb[14][2] = ank[16][2];
    anb[15][0] = 0.;
    anb[15][1] = ank[17][1];
    anb[15][2] = ank[17][2];
    roustate = 3;
/*
 Used 0.27 seconds CPU time,
 0 additional bytes of memory.
 Equations contain  231 adds/subtracts/negates
                    194 multiplies
                      0 divides
                    409 assignments
*/
}

void robotpseudo(double *lqout, double *luout)
{
/*
Return pseudo-coordinates for loop joints.

*/
/*
There are no loop joints in this system.

*/
}

void robotpsqdot(double *lqdout)
{
/*
Return pseudo-coordinate derivatives for loop joints.

*/
/*
There are no loop joints in this system.

*/
}

void robotpsudot(double *ludout)
{
/*
Return pseudo-coordinate accelerations for loop joints.

*/
/*
There are no loop joints in this system.

*/
}

void robotperr(double *errs)
{

}

void robotverr(double *errs)
{

}

void robotaerr(double *errs)
{

}

int robotindx(int joint, int axis)
{
    int offs,gotit;

    if (robotchkjaxis(36,joint,axis) != 0) {
        return 0;
    }
    gotit = 0;
    if (jtype[joint] == 4) {
        if (axis == 3) {
            offs = ballq[joint];
            gotit = 1;
        }
    } else {
        if ((jtype[joint] == 6) || (jtype[joint] == 21)) {
            if (axis == 6) {
                offs = ballq[joint];
                gotit = 1;
            }
        }
    }
    if (gotit == 0) {
        offs = firstq[joint]+axis;
    }
    return offs;
}

void robotpresacc(int joint, int axis, double prval)
{

}

void robotpresvel(int joint, int axis, double prval)
{

}

void robotprespos(int joint, int axis, double prval)
{

}

void robotgetht(int joint, int axis, double *torque)
{

    if (robotchkjaxis(30,joint,axis) != 0) {
        return;
    }
    if (roustate != 3) {
        robotseterr(30,24);
        return;
    }
    *torque = tauc[robotindx(joint,axis)];
}

void robothinget(int joint, int axis, double torque)
{

    if (robotchkjaxis(10,joint,axis) != 0) {
        return;
    }
    if (roustate != 2) {
        robotseterr(10,23);
        return;
    }
    if (mfrcflg != 0) {
        mtau[robotindx(joint,axis)] = mtau[robotindx(joint,axis)]+torque;
    } else {
        fs0flg = 0;
        utau[robotindx(joint,axis)] = utau[robotindx(joint,axis)]+torque;
    }
}

void robotpointf(int body, double *point, double *force)
{
    double torque[3];

    if (robotchkbnum(11,body) != 0) {
        return;
    }
    if (roustate != 2) {
        robotseterr(11,23);
        return;
    }
    if (body == -1) {
        return;
    }
    torque[0] = point[1]*force[2]-point[2]*force[1];
    torque[1] = point[2]*force[0]-point[0]*force[2];
    torque[2] = point[0]*force[1]-point[1]*force[0];
    if (mfrcflg != 0) {
        mfk[body][0] = mfk[body][0]+force[0];
        mtk[body][0] = mtk[body][0]+torque[0];
        mfk[body][1] = mfk[body][1]+force[1];
        mtk[body][1] = mtk[body][1]+torque[1];
        mfk[body][2] = mfk[body][2]+force[2];
        mtk[body][2] = mtk[body][2]+torque[2];
    } else {
        fs0flg = 0;
        ufk[body][0] = ufk[body][0]+force[0];
        utk[body][0] = utk[body][0]+torque[0];
        ufk[body][1] = ufk[body][1]+force[1];
        utk[body][1] = utk[body][1]+torque[1];
        ufk[body][2] = ufk[body][2]+force[2];
        utk[body][2] = utk[body][2]+torque[2];
    }
}

void robotbodyt(int body, double *torque)
{

    if (robotchkbnum(12,body) != 0) {
        return;
    }
    if (roustate != 2) {
        robotseterr(12,23);
        return;
    }
    if (body == -1) {
        return;
    }
    if (mfrcflg != 0) {
        mtk[body][0] = mtk[body][0]+torque[0];
        mtk[body][1] = mtk[body][1]+torque[1];
        mtk[body][2] = mtk[body][2]+torque[2];
    } else {
        fs0flg = 0;
        utk[body][0] = utk[body][0]+torque[0];
        utk[body][1] = utk[body][1]+torque[1];
        utk[body][2] = utk[body][2]+torque[2];
    }
}

void robotdoww(int routine)
{

    roustate = 2;
    if (wwflg == 0) {
        wwflg = 1;
    }
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                      0 assignments
*/
}

void robotxudot0(int routine, double *oudot0)
{
/*
Compute unconstrained equations
*/
    int i;
    double eps[18],Z1[18][3],Z2[18][3],A1[18][3],A2[18][3],K1[18][3],K2[18][3];

    robotlhs(routine);
/*
Solve equations for udots
*/
    Z1[16][1] = ((4.87231936880381*(fs0[17]*s17))-(4.29910532541513*(fs0[17]*c17
      )));
    Z1[16][2] = -((4.29910532541513*(fs0[17]*s17))+(4.87231936880381*(fs0[17]*
      c17)));
    Z2[16][0] = (fs0[17]-((4.29910532541513*(fs0[17]*rikt[17][0][1]))+(
      4.87231936880381*(fs0[17]*rikt[17][0][2]))));
    Z2[16][1] = ((.067066043076476*(fs0[17]*s17))+(.0760081821533394*(fs0[17]*
      c17)));
    Z2[16][2] = ((.0760081821533394*(fs0[17]*s17))-(.067066043076476*(fs0[17]*
      c17)));
    eps[16] = (fs0[16]-Z2[16][0]);
    Z1[16][1] = (Z1[16][1]+(eps[16]*G1[16][1]));
    Z1[16][2] = (Z1[16][2]+(eps[16]*G1[16][2]));
    Z2[16][0] = (eps[16]+Z2[16][0]);
    Z2[16][1] = (Z2[16][1]+(eps[16]*G2[16][1]));
    Z2[16][2] = (Z2[16][2]+(eps[16]*G2[16][2]));
    Z1[15][1] = ((Z1[16][1]*c16)-(Z1[16][2]*s16));
    Z1[15][2] = ((Z1[16][1]*s16)+(Z1[16][2]*c16));
    Z2[15][0] = (Z2[16][0]+((rikt[16][0][1]*Z1[16][1])+(rikt[16][0][2]*Z1[16][2]
      )));
    Z2[15][1] = (((Z2[16][1]*c16)-(Z2[16][2]*s16))-(.0338*((Z1[16][1]*s16)+(
      Z1[16][2]*c16))));
    Z2[15][2] = ((.0338*((Z1[16][1]*c16)-(Z1[16][2]*s16)))+((Z2[16][1]*s16)+(
      Z2[16][2]*c16)));
    eps[15] = (fs0[15]-Z2[15][0]);
    Z1[15][1] = (Z1[15][1]+(eps[15]*G1[15][1]));
    Z1[15][2] = (Z1[15][2]+(eps[15]*G1[15][2]));
    Z2[15][0] = (eps[15]+Z2[15][0]);
    Z2[15][1] = (Z2[15][1]+(eps[15]*G2[15][1]));
    Z2[15][2] = (Z2[15][2]+(eps[15]*G2[15][2]));
    Z1[2][1] = ((Z1[15][1]*c15)-(Z1[15][2]*s15));
    Z1[2][2] = ((Z1[15][1]*s15)+(Z1[15][2]*c15));
    Z2[2][0] = (Z2[15][0]+((rikt[15][0][1]*Z1[15][1])+(rikt[15][0][2]*Z1[15][2])
      ));
    Z2[2][1] = ((.1118*((Z1[15][1]*s15)+(Z1[15][2]*c15)))+((Z2[15][1]*c15)-(
      Z2[15][2]*s15)));
    Z2[2][2] = ((.1118*((Z1[15][2]*s15)-(Z1[15][1]*c15)))+((Z2[15][1]*s15)+(
      Z2[15][2]*c15)));
    Z1[13][1] = ((4.87231936880381*(fs0[14]*s14))-(4.29910532541513*(fs0[14]*c14
      )));
    Z1[13][2] = -((4.29910532541513*(fs0[14]*s14))+(4.87231936880381*(fs0[14]*
      c14)));
    Z2[13][0] = (fs0[14]-((4.29910532541513*(fs0[14]*rikt[14][0][1]))+(
      4.87231936880381*(fs0[14]*rikt[14][0][2]))));
    Z2[13][1] = -((.067066043076476*(fs0[14]*s14))+(.0760081821533394*(fs0[14]*
      c14)));
    Z2[13][2] = ((.067066043076476*(fs0[14]*c14))-(.0760081821533394*(fs0[14]*
      s14)));
    eps[13] = (fs0[13]-Z2[13][0]);
    Z1[13][1] = (Z1[13][1]+(eps[13]*G1[13][1]));
    Z1[13][2] = (Z1[13][2]+(eps[13]*G1[13][2]));
    Z2[13][0] = (eps[13]+Z2[13][0]);
    Z2[13][1] = (Z2[13][1]+(eps[13]*G2[13][1]));
    Z2[13][2] = (Z2[13][2]+(eps[13]*G2[13][2]));
    Z1[12][1] = ((Z1[13][1]*c13)-(Z1[13][2]*s13));
    Z1[12][2] = ((Z1[13][1]*s13)+(Z1[13][2]*c13));
    Z2[12][0] = (Z2[13][0]+((rikt[13][0][1]*Z1[13][1])+(rikt[13][0][2]*Z1[13][2]
      )));
    Z2[12][1] = ((.0338*((Z1[13][1]*s13)+(Z1[13][2]*c13)))+((Z2[13][1]*c13)-(
      Z2[13][2]*s13)));
    Z2[12][2] = ((.0338*((Z1[13][2]*s13)-(Z1[13][1]*c13)))+((Z2[13][1]*s13)+(
      Z2[13][2]*c13)));
    eps[12] = (fs0[12]-Z2[12][0]);
    Z1[12][1] = (Z1[12][1]+(eps[12]*G1[12][1]));
    Z1[12][2] = (Z1[12][2]+(eps[12]*G1[12][2]));
    Z2[12][0] = (eps[12]+Z2[12][0]);
    Z2[12][1] = (Z2[12][1]+(eps[12]*G2[12][1]));
    Z2[12][2] = (Z2[12][2]+(eps[12]*G2[12][2]));
    Z1[2][1] = (Z1[2][1]+((Z1[12][1]*c12)-(Z1[12][2]*s12)));
    Z1[2][2] = (Z1[2][2]+((Z1[12][1]*s12)+(Z1[12][2]*c12)));
    Z2[2][0] = (Z2[2][0]+(Z2[12][0]+((rikt[12][0][1]*Z1[12][1])+(rikt[12][0][2]*
      Z1[12][2]))));
    Z2[2][1] = (Z2[2][1]+(((Z2[12][1]*c12)-(Z2[12][2]*s12))-(.1118*((Z1[12][1]*
      s12)+(Z1[12][2]*c12)))));
    Z2[2][2] = (Z2[2][2]+((.1118*((Z1[12][1]*c12)-(Z1[12][2]*s12)))+((Z2[12][1]*
      s12)+(Z2[12][2]*c12))));
    Z1[10][0] = (9.11118190506531*(fs0[11]*c11));
    Z1[10][1] = (9.11118190506531*(fs0[11]*s11));
    Z2[10][2] = (fs0[11]+(2.511041733036*(fs0[11]*c11)));
    Z1[10][2] = (fs0[10]*G1[10][2]);
    Z2[10][1] = (fs0[10]*G2[10][1]);
    Z1[9][0] = Z1[10][0];
    Z1[9][1] = ((Z1[10][1]*c10)-(Z1[10][2]*s10));
    Z1[9][2] = ((Z1[10][1]*s10)+(Z1[10][2]*c10));
    Z2[9][0] = (fs0[10]+((rikt[10][0][1]*Z1[10][1])+(rikt[10][0][2]*Z1[10][2])))
      ;
    Z2[9][1] = ((.0026*Z1[10][0])+((Z2[10][1]*c10)-(Z2[10][2]*s10)));
    Z2[9][2] = ((.2652*Z1[10][0])+((Z2[10][1]*s10)+(Z2[10][2]*c10)));
    eps[9] = (fs0[9]-Z2[9][0]);
    Z1[9][0] = (Z1[9][0]+(eps[9]*G1[9][0]));
    Z1[9][1] = (Z1[9][1]+(eps[9]*G1[9][1]));
    Z1[9][2] = (Z1[9][2]+(eps[9]*G1[9][2]));
    Z2[9][0] = (eps[9]+Z2[9][0]);
    Z2[9][1] = (Z2[9][1]+(eps[9]*G2[9][1]));
    Z2[9][2] = (Z2[9][2]+(eps[9]*G2[9][2]));
    Z1[3][0] = Z1[9][0];
    Z1[3][1] = ((Z1[9][1]*c9)-(Z1[9][2]*s9));
    Z1[3][2] = ((Z1[9][1]*s9)+(Z1[9][2]*c9));
    Z2[3][0] = (Z2[9][0]+((rikt[9][0][1]*Z1[9][1])+(rikt[9][0][2]*Z1[9][2])));
    Z2[3][1] = (((.1768*(Z1[9][2]*c9))+((.1768*(Z1[9][1]*s9))-(.0338*Z1[9][0])))
      +((Z2[9][1]*c9)-(Z2[9][2]*s9)));
    Z2[3][2] = (((.1768*(Z1[9][2]*s9))-((.1768*(Z1[9][1]*c9))+(.3354*Z1[9][0])))
      +((Z2[9][1]*s9)+(Z2[9][2]*c9)));
    Z1[7][0] = (9.11118190506531*(fs0[8]*c8));
    Z1[7][1] = (9.11118190506531*(fs0[8]*s8));
    Z2[7][2] = (fs0[8]+(2.511041733036*(fs0[8]*c8)));
    Z1[7][2] = (fs0[7]*G1[7][2]);
    Z2[7][1] = (fs0[7]*G2[7][1]);
    Z1[6][0] = Z1[7][0];
    Z1[6][1] = ((Z1[7][1]*c7)-(Z1[7][2]*s7));
    Z1[6][2] = ((Z1[7][1]*s7)+(Z1[7][2]*c7));
    Z2[6][0] = (fs0[7]+((rikt[7][0][1]*Z1[7][1])+(rikt[7][0][2]*Z1[7][2])));
    Z2[6][1] = ((.0026*Z1[7][0])+((Z2[7][1]*c7)-(Z2[7][2]*s7)));
    Z2[6][2] = ((.2652*Z1[7][0])+((Z2[7][1]*s7)+(Z2[7][2]*c7)));
    eps[6] = (fs0[6]-Z2[6][0]);
    Z1[6][0] = (Z1[6][0]+(eps[6]*G1[6][0]));
    Z1[6][1] = (Z1[6][1]+(eps[6]*G1[6][1]));
    Z1[6][2] = (Z1[6][2]+(eps[6]*G1[6][2]));
    Z2[6][0] = (eps[6]+Z2[6][0]);
    Z2[6][1] = (Z2[6][1]+(eps[6]*G2[6][1]));
    Z2[6][2] = (Z2[6][2]+(eps[6]*G2[6][2]));
    Z1[3][0] = (Z1[3][0]+Z1[6][0]);
    Z1[3][1] = (Z1[3][1]+((Z1[6][1]*c6)-(Z1[6][2]*s6)));
    Z1[3][2] = (Z1[3][2]+((Z1[6][1]*s6)+(Z1[6][2]*c6)));
    Z2[3][0] = (Z2[3][0]+(Z2[6][0]+((rikt[6][0][1]*Z1[6][1])+(rikt[6][0][2]*
      Z1[6][2]))));
    Z2[3][1] = (Z2[3][1]+(((Z2[6][1]*c6)-(Z2[6][2]*s6))-((.1768*(Z1[6][2]*c6))+(
      (.0338*Z1[6][0])+(.1768*(Z1[6][1]*s6))))));
    Z2[3][2] = (Z2[3][2]+(((Z2[6][1]*s6)+(Z2[6][2]*c6))+(((.1768*(Z1[6][1]*c6))-
      (.3354*Z1[6][0]))-(.1768*(Z1[6][2]*s6)))));
    Z1[4][1] = -((2.46442451777002*(fs0[5]*c5))+(6.16106129442506*(fs0[5]*s5)));
    Z1[4][2] = ((6.16106129442506*(fs0[5]*c5))-(2.46442451777002*(fs0[5]*s5)));
    Z2[4][0] = (fs0[5]+((6.16106129442506*(fs0[5]*rikt[5][0][2]))-(
      2.46442451777002*(fs0[5]*rikt[5][0][1]))));
    eps[4] = (fs0[4]-Z2[4][0]);
    Z1[4][1] = (Z1[4][1]+(eps[4]*G1[4][1]));
    Z1[4][2] = (Z1[4][2]+(eps[4]*G1[4][2]));
    Z2[4][0] = (eps[4]+Z2[4][0]);
    Z1[3][1] = (Z1[3][1]+((Z1[4][1]*c4)-(Z1[4][2]*s4)));
    Z1[3][2] = (Z1[3][2]+((Z1[4][1]*s4)+(Z1[4][2]*c4)));
    Z2[3][0] = (Z2[3][0]+(Z2[4][0]+((rikt[4][0][1]*Z1[4][1])+(rikt[4][0][2]*
      Z1[4][2]))));
    eps[3] = (fs0[3]-Z2[3][0]);
    Z1[3][0] = (Z1[3][0]+(eps[3]*G1[3][0]));
    Z1[3][1] = (Z1[3][1]+(eps[3]*G1[3][1]));
    Z1[3][2] = (Z1[3][2]+(eps[3]*G1[3][2]));
    Z2[3][0] = (eps[3]+Z2[3][0]);
    Z2[3][1] = (Z2[3][1]+(eps[3]*G2[3][1]));
    Z2[3][2] = (Z2[3][2]+(eps[3]*G2[3][2]));
    Z1[2][0] = Z1[3][0];
    Z1[2][1] = (Z1[2][1]+((Z1[3][1]*c3)-(Z1[3][2]*s3)));
    Z1[2][2] = (Z1[2][2]+((Z1[3][1]*s3)+(Z1[3][2]*c3)));
    Z2[2][0] = (Z2[2][0]+Z2[3][0]);
    Z2[2][1] = (Z2[2][1]+((Z2[3][1]*c3)-(Z2[3][2]*s3)));
    Z2[2][2] = (Z2[2][2]+((Z2[3][1]*s3)+(Z2[3][2]*c3)));
    eps[2] = (fs0[2]-Z2[2][0]);
    Z1[2][1] = (Z1[2][1]+(eps[2]*G1[2][1]));
    Z1[2][2] = (Z1[2][2]+(eps[2]*G1[2][2]));
    Z2[2][0] = (eps[2]+Z2[2][0]);
    Z2[2][1] = (Z2[2][1]+(eps[2]*G2[2][1]));
    Z2[2][2] = (Z2[2][2]+(eps[2]*G2[2][2]));
    Z1[1][0] = Z1[2][0];
    Z1[1][1] = ((Z1[2][1]*c2)-(Z1[2][2]*s2));
    Z1[1][2] = ((Z1[2][1]*s2)+(Z1[2][2]*c2));
    Z2[1][0] = Z2[2][0];
    Z2[1][1] = ((Z2[2][1]*c2)-(Z2[2][2]*s2));
    Z2[1][2] = ((Z2[2][1]*s2)+(Z2[2][2]*c2));
    eps[1] = (fs0[1]-Z1[1][2]);
    Z1[1][0] = (Z1[1][0]+(eps[1]*G1[1][0]));
    Z1[1][1] = (Z1[1][1]+(eps[1]*G1[1][1]));
    Z1[1][2] = (eps[1]+Z1[1][2]);
    Z2[1][1] = (Z2[1][1]+(eps[1]*G2[1][1]));
    Z2[1][2] = (Z2[1][2]+(eps[1]*G2[1][2]));
    Z1[0][0] = Z1[1][0];
    Z1[0][1] = Z1[1][1];
    Z1[0][2] = Z1[1][2];
    Z2[0][0] = (Z2[1][0]-(q[1]*Z1[1][1]));
    Z2[0][1] = (Z2[1][1]+(q[1]*Z1[1][0]));
    Z2[0][2] = Z2[1][2];
    eps[0] = (fs0[0]-Z1[0][1]);
    udot[0] = (DD[0]*eps[0]);
    udot[1] = ((DD[1]*eps[1])-(G1[1][1]*udot[0]));
    K1[2][1] = ((udot[0]*c2)+(udot[1]*s2));
    K1[2][2] = ((udot[1]*c2)-(udot[0]*s2));
    udot[2] = ((DD[2]*eps[2])-((G1[2][1]*K1[2][1])+(G1[2][2]*K1[2][2])));
    K1[3][1] = ((K1[2][1]*c3)+(K1[2][2]*s3));
    K1[3][2] = ((K1[2][2]*c3)-(K1[2][1]*s3));
    udot[3] = ((DD[3]*eps[3])-(udot[2]+((G1[3][1]*K1[3][1])+(G1[3][2]*K1[3][2]))
      ));
    A2[3][0] = (udot[2]+udot[3]);
    K1[4][1] = ((A2[3][0]*rikt[4][0][1])+((K1[3][1]*c4)+(K1[3][2]*s4)));
    K1[4][2] = ((A2[3][0]*rikt[4][0][2])+((K1[3][2]*c4)-(K1[3][1]*s4)));
    udot[4] = ((DD[4]*eps[4])-(A2[3][0]+((G1[4][1]*K1[4][1])+(G1[4][2]*K1[4][2])
      )));
    A2[4][0] = (A2[3][0]+udot[4]);
    K1[5][1] = ((A2[4][0]*rikt[5][0][1])+((K1[4][1]*c5)+(K1[4][2]*s5)));
    K1[5][2] = ((A2[4][0]*rikt[5][0][2])+((K1[4][2]*c5)-(K1[4][1]*s5)));
    udot[5] = ((13.4105204266794*fs0[5])-(A2[4][0]+((6.16106129442506*K1[5][2])-
      (2.46442451777002*K1[5][1]))));
    A2[5][0] = (A2[4][0]+udot[5]);
    K1[6][1] = ((A2[3][0]*rikt[6][0][1])+((K1[3][1]*c6)+(K1[3][2]*s6)));
    K1[6][2] = ((A2[3][0]*rikt[6][0][2])+((K1[3][2]*c6)-(K1[3][1]*s6)));
    udot[6] = ((DD[6]*eps[6])-(A2[3][0]+((G1[6][1]*K1[6][1])+(G1[6][2]*K1[6][2])
      )));
    A2[6][0] = (A2[3][0]+udot[6]);
    K1[7][1] = ((A2[6][0]*rikt[7][0][1])+((K1[6][1]*c7)+(K1[6][2]*s7)));
    K1[7][2] = ((A2[6][0]*rikt[7][0][2])+((K1[6][2]*c7)-(K1[6][1]*s7)));
    udot[7] = ((DD[7]*fs0[7])-(A2[6][0]+(G1[7][2]*K1[7][2])));
    A2[7][0] = (A2[6][0]+udot[7]);
    K1[8][0] = (K1[7][1]*s8);
    K1[8][1] = (K1[7][1]*c8);
    K1[8][2] = (K1[7][2]-(.2756*A2[7][0]));
    K2[8][0] = (A2[7][0]*c8);
    K2[8][1] = -(A2[7][0]*s8);
    udot[8] = ((254.858235106722*fs0[8])-(9.11118190506531*K1[8][0]));
    K1[9][1] = ((A2[3][0]*rikt[9][0][1])+((K1[3][1]*c9)+(K1[3][2]*s9)));
    K1[9][2] = ((A2[3][0]*rikt[9][0][2])+((K1[3][2]*c9)-(K1[3][1]*s9)));
    udot[9] = ((DD[9]*eps[9])-(A2[3][0]+((G1[9][1]*K1[9][1])+(G1[9][2]*K1[9][2])
      )));
    A2[9][0] = (A2[3][0]+udot[9]);
    K1[10][1] = ((A2[9][0]*rikt[10][0][1])+((K1[9][1]*c10)+(K1[9][2]*s10)));
    K1[10][2] = ((A2[9][0]*rikt[10][0][2])+((K1[9][2]*c10)-(K1[9][1]*s10)));
    udot[10] = ((DD[10]*fs0[10])-(A2[9][0]+(G1[10][2]*K1[10][2])));
    A2[10][0] = (A2[9][0]+udot[10]);
    K1[11][0] = (K1[10][1]*s11);
    K1[11][1] = (K1[10][1]*c11);
    K1[11][2] = (K1[10][2]-(.2756*A2[10][0]));
    K2[11][0] = (A2[10][0]*c11);
    K2[11][1] = -(A2[10][0]*s11);
    udot[11] = ((254.858235106722*fs0[11])-(9.11118190506531*K1[11][0]));
    K1[12][1] = ((rikt[12][0][1]*udot[2])+((K1[2][1]*c12)+(K1[2][2]*s12)));
    K1[12][2] = ((rikt[12][0][2]*udot[2])+((K1[2][2]*c12)-(K1[2][1]*s12)));
    udot[12] = ((DD[12]*eps[12])-(udot[2]+((G1[12][1]*K1[12][1])+(G1[12][2]*
      K1[12][2]))));
    A2[12][0] = (udot[2]+udot[12]);
    K1[13][1] = ((A2[12][0]*rikt[13][0][1])+((K1[12][1]*c13)+(K1[12][2]*s13)));
    K1[13][2] = ((A2[12][0]*rikt[13][0][2])+((K1[12][2]*c13)-(K1[12][1]*s13)));
    udot[13] = ((DD[13]*eps[13])-(A2[12][0]+((G1[13][1]*K1[13][1])+(G1[13][2]*
      K1[13][2]))));
    A2[13][0] = (A2[12][0]+udot[13]);
    K1[14][1] = ((A2[13][0]*rikt[14][0][1])+((K1[13][1]*c14)+(K1[13][2]*s14)));
    K1[14][2] = ((A2[13][0]*rikt[14][0][2])+((K1[13][2]*c14)-(K1[13][1]*s14)));
    udot[14] = ((82.2637834943576*fs0[14])-(A2[13][0]-((4.29910532541513*
      K1[14][1])+(4.87231936880381*K1[14][2]))));
    A2[14][0] = (A2[13][0]+udot[14]);
    K1[15][1] = ((rikt[15][0][1]*udot[2])+((K1[2][1]*c15)+(K1[2][2]*s15)));
    K1[15][2] = ((rikt[15][0][2]*udot[2])+((K1[2][2]*c15)-(K1[2][1]*s15)));
    udot[15] = ((DD[15]*eps[15])-(udot[2]+((G1[15][1]*K1[15][1])+(G1[15][2]*
      K1[15][2]))));
    A2[15][0] = (udot[2]+udot[15]);
    K1[16][1] = ((A2[15][0]*rikt[16][0][1])+((K1[15][1]*c16)+(K1[15][2]*s16)));
    K1[16][2] = ((A2[15][0]*rikt[16][0][2])+((K1[15][2]*c16)-(K1[15][1]*s16)));
    udot[16] = ((DD[16]*eps[16])-(A2[15][0]+((G1[16][1]*K1[16][1])+(G1[16][2]*
      K1[16][2]))));
    A2[16][0] = (A2[15][0]+udot[16]);
    K1[17][1] = ((A2[16][0]*rikt[17][0][1])+((K1[16][1]*c17)+(K1[16][2]*s17)));
    K1[17][2] = ((A2[16][0]*rikt[17][0][2])+((K1[16][2]*c17)-(K1[16][1]*s17)));
    udot[17] = ((82.2637834943576*fs0[17])-(A2[16][0]-((4.29910532541513*
      K1[17][1])+(4.87231936880381*K1[17][2]))));
    A2[17][0] = (A2[16][0]+udot[17]);
    for (i = 0; i <= 17; i++) {
        oudot0[i] = udot[i];
    }
/*
 Used 0.35 seconds CPU time,
 0 additional bytes of memory.
 Equations contain  308 adds/subtracts/negates
                    398 multiplies
                      0 divides
                    237 assignments
*/
}

void robotudot0(double *oudot0)
{

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(66,23);
        return;
    }
    robotxudot0(66,oudot0);
}

void robotsetudot(double *iudot)
{
/*
Assign udots and advance to stage Dynamics Ready
*/
    int i;

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(68,23);
        return;
    }
    for (i = 0; i <= 17; i++) {
        udot[i] = iudot[i];
    }
    robotrhs();
}

void robotxudotm(int routine, double *imult, double *oudotm)
{
/*
Compute udots due only to multipliers
*/
    int i;
    double eps[18],Z1[18][3],Z2[18][3],A1[18][3],A2[18][3],K1[18][3],K2[18][3];

    robotlhs(routine);
    for (i = 0; i <= 17; i++) {
        udot[i] = 0.;
    }
    for (i = 0; i <= 17; i++) {
        oudotm[i] = udot[i];
    }
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     36 assignments
*/
}

void robotudotm(double *imult, double *oudotm)
{

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(67,23);
        return;
    }
    robotxudotm(67,imult,oudotm);
}

void robotderiv(double *oqdot, double *oudot)
{
/*
This is the derivative section for a 16-body ground-based
system with 18 hinge degree(s) of freedom.
*/
    int i;
    double udot0[18],udot1[18];
    double eps[18],Z1[18][3],Z2[18][3],A1[18][3],A2[18][3],K1[18][3],K2[18][3];

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(17,23);
        return;
    }
    if (stabvelq == 1) {
        robotseterr(17,32);
    }
    if (stabposq == 1) {
        robotseterr(17,33);
    }
    wsiz = 0;
/*
Compute unconstrained equations
*/
    robotxudot0(17,udot0);
    robotrhs();
    wrank = 0;
    for (i = 0; i <= 17; i++) {
        oqdot[i] = qdot[i];
    }
    for (i = 0; i <= 17; i++) {
        oudot[i] = udot[i];
    }
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     36 assignments
*/
}
/*
Compute residuals for use with DAE integrator
*/

void robotresid(double *eqdot, double *eudot, double *emults, double *resid)
{
    int i;
    double uderrs[18];

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(16,23);
        return;
    }
    if (stabposq == 1) {
        robotseterr(16,33);
    }
    robotfulltrq(eudot,emults,uderrs);
    for (i = 0; i < 18; i++) {
        resid[i] = eqdot[i]-qdot[i];
    }
    for (i = 0; i < 18; i++) {
        resid[18+i] = uderrs[i];
    }
    for (i = 0; i < 18; i++) {
        udot[i] = eudot[i];
    }
    robotrhs();
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain   18 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     54 assignments
*/
}

void robotmult(double *omults, int *owrank, int *omultmap)
{

    if (roustate != 3) {
        robotseterr(34,24);
        return;
    }
    *owrank = wrank;
}

void robotreac(double (*force)[3], double (*torque)[3])
{
/*
Generated 19-Jul-2001 15:43:03 by SD/FAST, Order(N) formulation
(sdfast B.2.6 #70405) on machine ID 690a1b33
Copyright (c) 1990-1996 Symbolic Dynamics, Inc.
Copyright (c) 1990-1996 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/

    if (roustate != 3) {
        robotseterr(31,24);
        return;
    }
/*
Compute reaction forces for non-weld tree joints
*/
    fc[17][0] = -ufk[15][0];
    fc[17][1] = ((1.34*AnkAtk[17][1])-ufk[15][1]);
    fc[17][2] = ((1.34*AnkAtk[17][2])-ufk[15][2]);
    tc[17][0] = ((.0075*Onkb[17][0])-(utk[15][0]+((.039*fc[17][1])+(.0442*
      fc[17][2]))));
    tc[17][1] = -(utk[15][1]-(.039*fc[17][0]));
    tc[17][2] = -(utk[15][2]-(.0442*fc[17][0]));
    fccikt[17][0] = fc[17][0];
    fccikt[17][1] = ((fc[17][1]*c17)-(fc[17][2]*s17));
    fccikt[17][2] = ((fc[17][1]*s17)+(fc[17][2]*c17));
    ffk[16][0] = (ufk[14][0]-fccikt[17][0]);
    ffk[16][1] = (ufk[14][1]-fccikt[17][1]);
    ffk[16][2] = (ufk[14][2]-fccikt[17][2]);
    ttk[16][0] = (utk[14][0]-(tc[17][0]+((.0039*fccikt[17][1])-(.2158*
      fccikt[17][2]))));
    ttk[16][1] = (utk[14][1]-(((tc[17][1]*c17)-(tc[17][2]*s17))-((.0039*
      fccikt[17][0])+(.0078*fccikt[17][2]))));
    ttk[16][2] = (utk[14][2]-(((.0078*fccikt[17][1])+(.2158*fccikt[17][0]))+((
      tc[17][1]*s17)+(tc[17][2]*c17))));
    fc[16][0] = -ffk[16][0];
    fc[16][1] = ((4.16*AnkAtk[16][1])-ffk[16][1]);
    fc[16][2] = ((4.16*AnkAtk[16][2])-ffk[16][2]);
    tc[16][0] = ((.056*Onkb[16][0])-(ttk[16][0]+((.2158*fc[16][2])-(.0039*
      fc[16][1]))));
    tc[16][1] = -(ttk[16][1]+((.0039*fc[16][0])+(.0078*fc[16][2])));
    tc[16][2] = -(ttk[16][2]-((.0078*fc[16][1])+(.2158*fc[16][0])));
    fccikt[16][0] = fc[16][0];
    fccikt[16][1] = ((fc[16][1]*c16)-(fc[16][2]*s16));
    fccikt[16][2] = ((fc[16][1]*s16)+(fc[16][2]*c16));
    ffk[15][0] = (ufk[13][0]-fccikt[16][0]);
    ffk[15][1] = (ufk[13][1]-fccikt[16][1]);
    ffk[15][2] = (ufk[13][2]-fccikt[16][2]);
    ttk[15][0] = (utk[13][0]-(tc[16][0]-((.0143*fccikt[16][1])+(.2379*
      fccikt[16][2]))));
    ttk[15][1] = (utk[13][1]-(((.0143*fccikt[16][0])-(.0169*fccikt[16][2]))+((
      tc[16][1]*c16)-(tc[16][2]*s16))));
    ttk[15][2] = (utk[13][2]-(((.0169*fccikt[16][1])+(.2379*fccikt[16][0]))+((
      tc[16][1]*s16)+(tc[16][2]*c16))));
    fc[15][0] = -ffk[15][0];
    fc[15][1] = ((8.35*AnkAtk[15][1])-ffk[15][1]);
    fc[15][2] = ((8.35*AnkAtk[15][2])-ffk[15][2]);
    tc[15][0] = ((.16*Onkb[15][0])-(ttk[15][0]+((.0143*fc[15][1])+(.2379*
      fc[15][2]))));
    tc[15][1] = -(ttk[15][1]+((.0169*fc[15][2])-(.0143*fc[15][0])));
    tc[15][2] = -(ttk[15][2]-((.0169*fc[15][1])+(.2379*fc[15][0])));
    fccikt[15][0] = fc[15][0];
    fccikt[15][1] = ((fc[15][1]*c15)-(fc[15][2]*s15));
    fccikt[15][2] = ((fc[15][1]*s15)+(fc[15][2]*c15));
    ffk[2][0] = (ufk[0][0]-fccikt[15][0]);
    ffk[2][1] = (ufk[0][1]-fccikt[15][1]);
    ffk[2][2] = (ufk[0][2]-fccikt[15][2]);
    ttk[2][0] = (utk[0][0]-(tc[15][0]-((.0058*fccikt[15][1])+(.0406*
      fccikt[15][2]))));
    ttk[2][1] = (utk[0][1]-(((.0058*fccikt[15][0])+(.1118*fccikt[15][2]))+((
      tc[15][1]*c15)-(tc[15][2]*s15))));
    ttk[2][2] = (utk[0][2]-(((.0406*fccikt[15][0])-(.1118*fccikt[15][1]))+((
      tc[15][1]*s15)+(tc[15][2]*c15))));
    fc[14][0] = -ufk[12][0];
    fc[14][1] = ((1.34*AnkAtk[14][1])-ufk[12][1]);
    fc[14][2] = ((1.34*AnkAtk[14][2])-ufk[12][2]);
    tc[14][0] = ((.0075*Onkb[14][0])-(utk[12][0]+((.039*fc[14][1])+(.0442*
      fc[14][2]))));
    tc[14][1] = -(utk[12][1]-(.039*fc[14][0]));
    tc[14][2] = -(utk[12][2]-(.0442*fc[14][0]));
    fccikt[14][0] = fc[14][0];
    fccikt[14][1] = ((fc[14][1]*c14)-(fc[14][2]*s14));
    fccikt[14][2] = ((fc[14][1]*s14)+(fc[14][2]*c14));
    ffk[13][0] = (ufk[11][0]-fccikt[14][0]);
    ffk[13][1] = (ufk[11][1]-fccikt[14][1]);
    ffk[13][2] = (ufk[11][2]-fccikt[14][2]);
    ttk[13][0] = (utk[11][0]-(tc[14][0]+((.0039*fccikt[14][1])-(.2158*
      fccikt[14][2]))));
    ttk[13][1] = (utk[11][1]-(((.0078*fccikt[14][2])-(.0039*fccikt[14][0]))+((
      tc[14][1]*c14)-(tc[14][2]*s14))));
    ttk[13][2] = (utk[11][2]-(((.2158*fccikt[14][0])-(.0078*fccikt[14][1]))+((
      tc[14][1]*s14)+(tc[14][2]*c14))));
    fc[13][0] = -ffk[13][0];
    fc[13][1] = ((4.16*AnkAtk[13][1])-ffk[13][1]);
    fc[13][2] = ((4.16*AnkAtk[13][2])-ffk[13][2]);
    tc[13][0] = ((.056*Onkb[13][0])-(ttk[13][0]+((.2158*fc[13][2])-(.0039*
      fc[13][1]))));
    tc[13][1] = -(ttk[13][1]+((.0039*fc[13][0])-(.0078*fc[13][2])));
    tc[13][2] = -(ttk[13][2]+((.0078*fc[13][1])-(.2158*fc[13][0])));
    fccikt[13][0] = fc[13][0];
    fccikt[13][1] = ((fc[13][1]*c13)-(fc[13][2]*s13));
    fccikt[13][2] = ((fc[13][1]*s13)+(fc[13][2]*c13));
    ffk[12][0] = (ufk[10][0]-fccikt[13][0]);
    ffk[12][1] = (ufk[10][1]-fccikt[13][1]);
    ffk[12][2] = (ufk[10][2]-fccikt[13][2]);
    ttk[12][0] = (utk[10][0]-(tc[13][0]-((.0143*fccikt[13][1])+(.2379*
      fccikt[13][2]))));
    ttk[12][1] = (utk[10][1]-(((.0143*fccikt[13][0])+(.0169*fccikt[13][2]))+((
      tc[13][1]*c13)-(tc[13][2]*s13))));
    ttk[12][2] = (utk[10][2]-(((.2379*fccikt[13][0])-(.0169*fccikt[13][1]))+((
      tc[13][1]*s13)+(tc[13][2]*c13))));
    fc[12][0] = -ffk[12][0];
    fc[12][1] = ((8.35*AnkAtk[12][1])-ffk[12][1]);
    fc[12][2] = ((8.35*AnkAtk[12][2])-ffk[12][2]);
    tc[12][0] = ((.16*Onkb[12][0])-(ttk[12][0]+((.0143*fc[12][1])+(.2379*
      fc[12][2]))));
    tc[12][1] = -(ttk[12][1]-((.0143*fc[12][0])+(.0169*fc[12][2])));
    tc[12][2] = -(ttk[12][2]+((.0169*fc[12][1])-(.2379*fc[12][0])));
    fccikt[12][0] = fc[12][0];
    fccikt[12][1] = ((fc[12][1]*c12)-(fc[12][2]*s12));
    fccikt[12][2] = ((fc[12][1]*s12)+(fc[12][2]*c12));
    ffk[2][0] = (ffk[2][0]-fccikt[12][0]);
    ffk[2][1] = (ffk[2][1]-fccikt[12][1]);
    ffk[2][2] = (ffk[2][2]-fccikt[12][2]);
    ttk[2][0] = (ttk[2][0]-(tc[12][0]-((.0058*fccikt[12][1])+(.0406*
      fccikt[12][2]))));
    ttk[2][1] = (ttk[2][1]-(((.0058*fccikt[12][0])-(.1118*fccikt[12][2]))+((
      tc[12][1]*c12)-(tc[12][2]*s12))));
    ttk[2][2] = (ttk[2][2]-(((.0406*fccikt[12][0])+(.1118*fccikt[12][1]))+((
      tc[12][1]*s12)+(tc[12][2]*c12))));
    fc[11][0] = ((.55*AnkAtk[11][0])-ufk[9][0]);
    fc[11][1] = ((.55*AnkAtk[11][1])-ufk[9][1]);
    fc[11][2] = ((.55*AnkAtk[11][2])-ufk[9][2]);
    tc[11][0] = ((WkIkWk[11][0]+(.0005*onk[11][0]))-(utk[9][0]+(.065*fc[11][2]))
      );
    tc[11][1] = ((WkIkWk[11][1]+(.002*onk[11][1]))-utk[9][1]);
    tc[11][2] = ((WkIkWk[11][2]+(.0016*udot[11]))-(utk[9][2]-(.065*fc[11][0])));
    fccikt[11][0] = ((fc[11][0]*c11)-(fc[11][1]*s11));
    fccikt[11][1] = ((fc[11][0]*s11)+(fc[11][1]*c11));
    fccikt[11][2] = fc[11][2];
    ffk[10][0] = (ufk[8][0]-fccikt[11][0]);
    ffk[10][1] = (ufk[8][1]-fccikt[11][1]);
    ffk[10][2] = (ufk[8][2]-fccikt[11][2]);
    ttk[10][0] = (utk[8][0]-(((tc[11][0]*c11)-(tc[11][1]*s11))-(.1378*
      fccikt[11][2])));
    ttk[10][1] = (utk[8][1]-((.0039*fccikt[11][2])+((tc[11][0]*s11)+(tc[11][1]*
      c11))));
    ttk[10][2] = (utk[8][2]-(tc[11][2]+((.1378*fccikt[11][0])-(.0039*
      fccikt[11][1]))));
    fc[10][0] = -ffk[10][0];
    fc[10][1] = ((1.21*AnkAtk[10][1])-ffk[10][1]);
    fc[10][2] = ((1.21*AnkAtk[10][2])-ffk[10][2]);
    tc[10][0] = ((.0054*Onkb[10][0])-(ttk[10][0]+(.1378*fc[10][2])));
    tc[10][1] = -(ttk[10][1]+(.0039*fc[10][2]));
    tc[10][2] = -(ttk[10][2]-((.0039*fc[10][1])+(.1378*fc[10][0])));
    fccikt[10][0] = fc[10][0];
    fccikt[10][1] = ((fc[10][1]*c10)-(fc[10][2]*s10));
    fccikt[10][2] = ((fc[10][1]*s10)+(fc[10][2]*c10));
    ffk[9][0] = (ufk[7][0]-fccikt[10][0]);
    ffk[9][1] = (ufk[7][1]-fccikt[10][1]);
    ffk[9][2] = (ufk[7][2]-fccikt[10][2]);
    ttk[9][0] = (utk[7][0]-(tc[10][0]-((.0013*fccikt[10][1])+(.1326*
      fccikt[10][2]))));
    ttk[9][1] = (utk[7][1]-((.0013*fccikt[10][0])+((tc[10][1]*c10)-(tc[10][2]*
      s10))));
    ttk[9][2] = (utk[7][2]-((.1326*fccikt[10][0])+((tc[10][1]*s10)+(tc[10][2]*
      c10))));
    fc[9][0] = -ffk[9][0];
    fc[9][1] = ((2.79*AnkAtk[9][1])-ffk[9][1]);
    fc[9][2] = ((2.79*AnkAtk[9][2])-ffk[9][2]);
    tc[9][0] = ((.025*Onkb[9][0])-(ttk[9][0]+((.0013*fc[9][1])+(.1326*fc[9][2]))
      ));
    tc[9][1] = -(ttk[9][1]-(.0013*fc[9][0]));
    tc[9][2] = -(ttk[9][2]-(.1326*fc[9][0]));
    fccikt[9][0] = fc[9][0];
    fccikt[9][1] = ((fc[9][1]*c9)-(fc[9][2]*s9));
    fccikt[9][2] = ((fc[9][1]*s9)+(fc[9][2]*c9));
    ffk[3][0] = (ufk[1][0]-fccikt[9][0]);
    ffk[3][1] = (ufk[1][1]-fccikt[9][1]);
    ffk[3][2] = (ufk[1][2]-fccikt[9][2]);
    ttk[3][0] = (utk[1][0]-(tc[9][0]+((.18915*fccikt[9][2])-(.0013*fccikt[9][1])
      )));
    ttk[3][1] = (utk[1][1]-(((.0013*fccikt[9][0])+(.1768*fccikt[9][2]))+((
      tc[9][1]*c9)-(tc[9][2]*s9))));
    ttk[3][2] = (utk[1][2]-(((tc[9][1]*s9)+(tc[9][2]*c9))-((.1768*fccikt[9][1])+
      (.18915*fccikt[9][0]))));
    fc[8][0] = ((.55*AnkAtk[8][0])-ufk[6][0]);
    fc[8][1] = ((.55*AnkAtk[8][1])-ufk[6][1]);
    fc[8][2] = ((.55*AnkAtk[8][2])-ufk[6][2]);
    tc[8][0] = ((WkIkWk[8][0]+(.0005*onk[8][0]))-(utk[6][0]+(.065*fc[8][2])));
    tc[8][1] = ((WkIkWk[8][1]+(.002*onk[8][1]))-utk[6][1]);
    tc[8][2] = ((WkIkWk[8][2]+(.0016*udot[8]))-(utk[6][2]-(.065*fc[8][0])));
    fccikt[8][0] = ((fc[8][0]*c8)-(fc[8][1]*s8));
    fccikt[8][1] = ((fc[8][0]*s8)+(fc[8][1]*c8));
    fccikt[8][2] = fc[8][2];
    ffk[7][0] = (ufk[5][0]-fccikt[8][0]);
    ffk[7][1] = (ufk[5][1]-fccikt[8][1]);
    ffk[7][2] = (ufk[5][2]-fccikt[8][2]);
    ttk[7][0] = (utk[5][0]-(((tc[8][0]*c8)-(tc[8][1]*s8))-(.1378*fccikt[8][2])))
      ;
    ttk[7][1] = (utk[5][1]-(((tc[8][0]*s8)+(tc[8][1]*c8))-(.0039*fccikt[8][2])))
      ;
    ttk[7][2] = (utk[5][2]-(tc[8][2]+((.0039*fccikt[8][1])+(.1378*fccikt[8][0]))
      ));
    fc[7][0] = -ffk[7][0];
    fc[7][1] = ((1.21*AnkAtk[7][1])-ffk[7][1]);
    fc[7][2] = ((1.21*AnkAtk[7][2])-ffk[7][2]);
    tc[7][0] = ((.0054*Onkb[7][0])-(ttk[7][0]+(.1378*fc[7][2])));
    tc[7][1] = -(ttk[7][1]-(.0039*fc[7][2]));
    tc[7][2] = -(ttk[7][2]+((.0039*fc[7][1])-(.1378*fc[7][0])));
    fccikt[7][0] = fc[7][0];
    fccikt[7][1] = ((fc[7][1]*c7)-(fc[7][2]*s7));
    fccikt[7][2] = ((fc[7][1]*s7)+(fc[7][2]*c7));
    ffk[6][0] = (ufk[4][0]-fccikt[7][0]);
    ffk[6][1] = (ufk[4][1]-fccikt[7][1]);
    ffk[6][2] = (ufk[4][2]-fccikt[7][2]);
    ttk[6][0] = (utk[4][0]-(tc[7][0]-((.0013*fccikt[7][1])+(.1326*fccikt[7][2]))
      ));
    ttk[6][1] = (utk[4][1]-((.0013*fccikt[7][0])+((tc[7][1]*c7)-(tc[7][2]*s7))))
      ;
    ttk[6][2] = (utk[4][2]-((.1326*fccikt[7][0])+((tc[7][1]*s7)+(tc[7][2]*c7))))
      ;
    fc[6][0] = -ffk[6][0];
    fc[6][1] = ((2.79*AnkAtk[6][1])-ffk[6][1]);
    fc[6][2] = ((2.79*AnkAtk[6][2])-ffk[6][2]);
    tc[6][0] = ((.025*Onkb[6][0])-(ttk[6][0]+((.0013*fc[6][1])+(.1326*fc[6][2]))
      ));
    tc[6][1] = -(ttk[6][1]-(.0013*fc[6][0]));
    tc[6][2] = -(ttk[6][2]-(.1326*fc[6][0]));
    fccikt[6][0] = fc[6][0];
    fccikt[6][1] = ((fc[6][1]*c6)-(fc[6][2]*s6));
    fccikt[6][2] = ((fc[6][1]*s6)+(fc[6][2]*c6));
    ffk[3][0] = (ffk[3][0]-fccikt[6][0]);
    ffk[3][1] = (ffk[3][1]-fccikt[6][1]);
    ffk[3][2] = (ffk[3][2]-fccikt[6][2]);
    ttk[3][0] = (ttk[3][0]-(tc[6][0]+((.18915*fccikt[6][2])-(.0013*fccikt[6][1])
      )));
    ttk[3][1] = (ttk[3][1]-(((.0013*fccikt[6][0])-(.1768*fccikt[6][2]))+((
      tc[6][1]*c6)-(tc[6][2]*s6))));
    ttk[3][2] = (ttk[3][2]-(((.1768*fccikt[6][1])-(.18915*fccikt[6][0]))+((
      tc[6][1]*s6)+(tc[6][2]*c6))));
    fc[5][0] = -ufk[3][0];
    fc[5][1] = ((5.89*AnkAtk[5][1])-ufk[3][1]);
    fc[5][2] = ((5.89*AnkAtk[5][2])-ufk[3][2]);
    tc[5][0] = ((.033*Onkb[5][0])-(utk[3][0]+((.0312*fc[5][1])-(.078*fc[5][2])))
      );
    tc[5][1] = -(utk[3][1]-(.0312*fc[5][0]));
    tc[5][2] = -(utk[3][2]+(.078*fc[5][0]));
    fccikt[5][0] = fc[5][0];
    fccikt[5][1] = ((fc[5][1]*c5)-(fc[5][2]*s5));
    fccikt[5][2] = ((fc[5][1]*s5)+(fc[5][2]*c5));
    ffk[4][0] = (ufk[2][0]-fccikt[5][0]);
    ffk[4][1] = (ufk[2][1]-fccikt[5][1]);
    ffk[4][2] = (ufk[2][2]-fccikt[5][2]);
    ttk[4][0] = (utk[2][0]-(tc[5][0]+((.0442*fccikt[5][2])-(.0065*fccikt[5][1]))
      ));
    ttk[4][1] = (utk[2][1]-((.0065*fccikt[5][0])+((tc[5][1]*c5)-(tc[5][2]*s5))))
      ;
    ttk[4][2] = (utk[2][2]-(((tc[5][1]*s5)+(tc[5][2]*c5))-(.0442*fccikt[5][0])))
      ;
    fc[4][0] = -ffk[4][0];
    fc[4][1] = (AnkAtk[4][1]-ffk[4][1]);
    fc[4][2] = (AnkAtk[4][2]-ffk[4][2]);
    tc[4][0] = ((.006*Onkb[4][0])-(ttk[4][0]+((.0065*fc[4][1])-(.0442*fc[4][2]))
      ));
    tc[4][1] = -(ttk[4][1]-(.0065*fc[4][0]));
    tc[4][2] = -(ttk[4][2]+(.0442*fc[4][0]));
    fccikt[4][0] = fc[4][0];
    fccikt[4][1] = ((fc[4][1]*c4)-(fc[4][2]*s4));
    fccikt[4][2] = ((fc[4][1]*s4)+(fc[4][2]*c4));
    ffk[3][0] = (ffk[3][0]-fccikt[4][0]);
    ffk[3][1] = (ffk[3][1]-fccikt[4][1]);
    ffk[3][2] = (ffk[3][2]-fccikt[4][2]);
    ttk[3][0] = (ttk[3][0]-(tc[4][0]+((.0013*fccikt[4][1])+(.24635*fccikt[4][2])
      )));
    ttk[3][1] = (ttk[3][1]-(((tc[4][1]*c4)-(tc[4][2]*s4))-(.0013*fccikt[4][0])))
      ;
    ttk[3][2] = (ttk[3][2]-(((tc[4][1]*s4)+(tc[4][2]*c4))-(.24635*fccikt[4][0]))
      );
    fc[3][0] = -ffk[3][0];
    fc[3][1] = ((29.27*AnkAtk[3][1])-ffk[3][1]);
    fc[3][2] = ((29.27*AnkAtk[3][2])-ffk[3][2]);
    tc[3][0] = ((.63*Onkb[3][0])-(ttk[3][0]-((.0351*fc[3][1])+(.14625*fc[3][2]))
      ));
    tc[3][1] = -(ttk[3][1]+(.0351*fc[3][0]));
    tc[3][2] = -(ttk[3][2]+(.14625*fc[3][0]));
    fccikt[3][0] = fc[3][0];
    fccikt[3][1] = ((fc[3][1]*c3)-(fc[3][2]*s3));
    fccikt[3][2] = ((fc[3][1]*s3)+(fc[3][2]*c3));
    ffk[2][0] = (ffk[2][0]-fccikt[3][0]);
    ffk[2][1] = (ffk[2][1]-fccikt[3][1]);
    ffk[2][2] = (ffk[2][2]-fccikt[3][2]);
    ttk[2][0] = (ttk[2][0]-(tc[3][0]+((.1206*fccikt[3][2])-(.05*fccikt[3][1]))))
      ;
    ttk[2][1] = (ttk[2][1]-((.05*fccikt[3][0])+((tc[3][1]*c3)-(tc[3][2]*s3))));
    ttk[2][2] = (ttk[2][2]-(((tc[3][1]*s3)+(tc[3][2]*c3))-(.1206*fccikt[3][0])))
      ;
    fc[2][0] = -ffk[2][0];
    fc[2][1] = ((16.61*AnkAtk[2][1])-ffk[2][1]);
    fc[2][2] = ((16.61*AnkAtk[2][2])-ffk[2][2]);
    tc[2][0] = ((.18*udot[2])-(ttk[2][0]+((.1206*fc[2][2])-(.05*fc[2][1]))));
    tc[2][1] = -(ttk[2][1]+(.05*fc[2][0]));
    tc[2][2] = -(ttk[2][2]-(.1206*fc[2][0]));
    fccikt[2][0] = fc[2][0];
    fccikt[2][1] = ((fc[2][1]*c2)-(fc[2][2]*s2));
    fccikt[2][2] = ((fc[2][1]*s2)+(fc[2][2]*c2));
    ffk[1][0] = -fccikt[2][0];
    ffk[1][1] = -fccikt[2][1];
    ffk[1][2] = -fccikt[2][2];
    ttk[1][0] = -tc[2][0];
    ttk[1][1] = -((tc[2][1]*c2)-(tc[2][2]*s2));
    ttk[1][2] = -((tc[2][1]*s2)+(tc[2][2]*c2));
    fc[1][0] = -ffk[1][0];
    fc[1][1] = -ffk[1][1];
    fc[1][2] = -ffk[1][2];
    tc[1][0] = -ttk[1][0];
    tc[1][1] = -ttk[1][1];
    tc[1][2] = -ttk[1][2];
    fccikt[1][0] = fc[1][0];
    fccikt[1][1] = fc[1][1];
    fccikt[1][2] = fc[1][2];
    ffk[0][0] = -fccikt[1][0];
    ffk[0][1] = -fccikt[1][1];
    ffk[0][2] = -fccikt[1][2];
    ttk[0][0] = -(tc[1][0]-(fccikt[1][1]*q[1]));
    ttk[0][1] = -(tc[1][1]+(fccikt[1][0]*q[1]));
    ttk[0][2] = -tc[1][2];
    fc[0][0] = -ffk[0][0];
    fc[0][1] = -ffk[0][1];
    fc[0][2] = -ffk[0][2];
    tc[0][0] = -ttk[0][0];
    tc[0][1] = -ttk[0][1];
    tc[0][2] = -ttk[0][2];
    force[0][0] = fc[2][0];
    torque[0][0] = tc[2][0];
    force[0][1] = fc[2][1];
    torque[0][1] = tc[2][1];
    force[0][2] = fc[2][2];
    torque[0][2] = tc[2][2];
    force[1][0] = fc[3][0];
    torque[1][0] = tc[3][0];
    force[1][1] = fc[3][1];
    torque[1][1] = tc[3][1];
    force[1][2] = fc[3][2];
    torque[1][2] = tc[3][2];
    force[2][0] = fc[4][0];
    torque[2][0] = tc[4][0];
    force[2][1] = fc[4][1];
    torque[2][1] = tc[4][1];
    force[2][2] = fc[4][2];
    torque[2][2] = tc[4][2];
    force[3][0] = fc[5][0];
    torque[3][0] = tc[5][0];
    force[3][1] = fc[5][1];
    torque[3][1] = tc[5][1];
    force[3][2] = fc[5][2];
    torque[3][2] = tc[5][2];
    force[4][0] = fc[6][0];
    torque[4][0] = tc[6][0];
    force[4][1] = fc[6][1];
    torque[4][1] = tc[6][1];
    force[4][2] = fc[6][2];
    torque[4][2] = tc[6][2];
    force[5][0] = fc[7][0];
    torque[5][0] = tc[7][0];
    force[5][1] = fc[7][1];
    torque[5][1] = tc[7][1];
    force[5][2] = fc[7][2];
    torque[5][2] = tc[7][2];
    force[6][0] = fc[8][0];
    torque[6][0] = tc[8][0];
    force[6][1] = fc[8][1];
    torque[6][1] = tc[8][1];
    force[6][2] = fc[8][2];
    torque[6][2] = tc[8][2];
    force[7][0] = fc[9][0];
    torque[7][0] = tc[9][0];
    force[7][1] = fc[9][1];
    torque[7][1] = tc[9][1];
    force[7][2] = fc[9][2];
    torque[7][2] = tc[9][2];
    force[8][0] = fc[10][0];
    torque[8][0] = tc[10][0];
    force[8][1] = fc[10][1];
    torque[8][1] = tc[10][1];
    force[8][2] = fc[10][2];
    torque[8][2] = tc[10][2];
    force[9][0] = fc[11][0];
    torque[9][0] = tc[11][0];
    force[9][1] = fc[11][1];
    torque[9][1] = tc[11][1];
    force[9][2] = fc[11][2];
    torque[9][2] = tc[11][2];
    force[10][0] = fc[12][0];
    torque[10][0] = tc[12][0];
    force[10][1] = fc[12][1];
    torque[10][1] = tc[12][1];
    force[10][2] = fc[12][2];
    torque[10][2] = tc[12][2];
    force[11][0] = fc[13][0];
    torque[11][0] = tc[13][0];
    force[11][1] = fc[13][1];
    torque[11][1] = tc[13][1];
    force[11][2] = fc[13][2];
    torque[11][2] = tc[13][2];
    force[12][0] = fc[14][0];
    torque[12][0] = tc[14][0];
    force[12][1] = fc[14][1];
    torque[12][1] = tc[14][1];
    force[12][2] = fc[14][2];
    torque[12][2] = tc[14][2];
    force[13][0] = fc[15][0];
    torque[13][0] = tc[15][0];
    force[13][1] = fc[15][1];
    torque[13][1] = tc[15][1];
    force[13][2] = fc[15][2];
    torque[13][2] = tc[15][2];
    force[14][0] = fc[16][0];
    torque[14][0] = tc[16][0];
    force[14][1] = fc[16][1];
    torque[14][1] = tc[16][1];
    force[14][2] = fc[16][2];
    torque[14][2] = tc[16][2];
    force[15][0] = fc[17][0];
    torque[15][0] = tc[17][0];
    force[15][1] = fc[17][1];
    torque[15][1] = tc[17][1];
    force[15][2] = fc[17][2];
    torque[15][2] = tc[17][2];
/*
Compute reaction forces for tree weld joints
*/
/*
 Used 0.32 seconds CPU time,
 8192 additional bytes of memory.
 Equations contain  426 adds/subtracts/negates
                    326 multiplies
                      0 divides
                    357 assignments
*/
}

void robotmom(double *lm, double *am, double *ke)
{
/*
Compute system linear and angular momentum, and kinetic energy.

Generated 19-Jul-2001 15:43:04 by SD/FAST, Order(N) formulation
(sdfast B.2.6 #70405) on machine ID 690a1b33
Copyright (c) 1990-1996 Symbolic Dynamics, Inc.
Copyright (c) 1990-1996 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/
    double lk[16][3],hnk[16][3];

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(19,23);
        return;
    }
    lm[0] = (.55*(vnk[8][0]+vnk[11][0]));
    lm[1] = ((1.34*vnk[17][1])+((4.16*vnk[16][1])+((8.35*vnk[15][1])+((1.34*
      vnk[14][1])+((4.16*vnk[13][1])+((8.35*vnk[12][1])+((.55*vnk[11][1])+((1.21
      *vnk[10][1])+((2.79*vnk[9][1])+((.55*vnk[8][1])+((1.21*vnk[7][1])+((2.79*
      vnk[6][1])+((5.89*vnk[5][1])+(vnk[4][1]+((16.61*vnk[2][1])+(29.27*
      vnk[3][1]))))))))))))))));
    lm[2] = ((1.34*vnk[17][2])+((4.16*vnk[16][2])+((8.35*vnk[15][2])+((1.34*
      vnk[14][2])+((4.16*vnk[13][2])+((8.35*vnk[12][2])+((.55*vnk[11][2])+((1.21
      *vnk[10][2])+((2.79*vnk[9][2])+((.55*vnk[8][2])+((1.21*vnk[7][2])+((2.79*
      vnk[6][2])+((5.89*vnk[5][2])+(vnk[4][2]+((16.61*vnk[2][2])+(29.27*
      vnk[3][2]))))))))))))))));
    temp[0] = (((.025*wk[6][0])+(2.79*((rnk[6][1]*vnk[6][2])-(rnk[6][2]*
      vnk[6][1]))))+(((.033*wk[5][0])+(5.89*((rnk[5][1]*vnk[5][2])-(rnk[5][2]*
      vnk[5][1]))))+(((.006*wk[4][0])+((rnk[4][1]*vnk[4][2])-(rnk[4][2]*
      vnk[4][1])))+(((.18*u[2])+(16.61*((rnk[2][1]*vnk[2][2])-(rnk[2][2]*
      vnk[2][1]))))+((.63*wk[3][0])+(29.27*((rnk[3][1]*vnk[3][2])-(rnk[3][2]*
      vnk[3][1]))))))));
    temp[1] = (((.0054*wk[10][0])+(1.21*((rnk[10][1]*vnk[10][2])-(rnk[10][2]*
      vnk[10][1]))))+(((.025*wk[9][0])+(2.79*((rnk[9][1]*vnk[9][2])-(rnk[9][2]*
      vnk[9][1]))))+(((.55*((rnk[8][1]*vnk[8][2])-(rnk[8][2]*vnk[8][1])))+((
      .0005*(wk[8][0]*c8))-(.002*(wk[8][1]*s8))))+(((.0054*wk[7][0])+(1.21*((
      rnk[7][1]*vnk[7][2])-(rnk[7][2]*vnk[7][1]))))+temp[0]))));
    temp[2] = (((.0075*wk[14][0])+(1.34*((rnk[14][1]*vnk[14][2])-(rnk[14][2]*
      vnk[14][1]))))+(((.056*wk[13][0])+(4.16*((rnk[13][1]*vnk[13][2])-(
      rnk[13][2]*vnk[13][1]))))+(((.16*wk[12][0])+(8.35*((rnk[12][1]*vnk[12][2])
      -(rnk[12][2]*vnk[12][1]))))+(((.55*((rnk[11][1]*vnk[11][2])-(rnk[11][2]*
      vnk[11][1])))+((.0005*(wk[11][0]*c11))-(.002*(wk[11][1]*s11))))+temp[1])))
      );
    am[0] = ((((.0075*wk[17][0])+(1.34*((rnk[17][1]*vnk[17][2])-(rnk[17][2]*
      vnk[17][1]))))+(((.056*wk[16][0])+(4.16*((rnk[16][1]*vnk[16][2])-(
      rnk[16][2]*vnk[16][1]))))+(((.16*wk[15][0])+(8.35*((rnk[15][1]*vnk[15][2])
      -(rnk[15][2]*vnk[15][1]))))+temp[2])))-((com[1]*lm[2])-(com[2]*lm[1])));
    temp[0] = (((.209209*vnk[10][2])+((.493272*vnk[9][2])+(((.55*((rnk[8][2]*
      vnk[8][0])-(rnk[8][0]*vnk[8][2])))+((.0016*(cnk[7][1][2]*u[8]))+((.0005*(
      cnk[8][1][0]*wk[8][0]))+(.002*(cnk[8][1][1]*wk[8][1])))))-((.209209*
      vnk[7][2])+(.493272*vnk[6][2])))))+((.55*((rnk[11][2]*vnk[11][0])-(
      rnk[11][0]*vnk[11][2])))+((.0016*(cnk[10][1][2]*u[11]))+((.0005*(
      cnk[11][1][0]*wk[11][0]))+(.002*(cnk[11][1][1]*wk[11][1]))))));
    am[1] = (((.083616*vnk[17][2])+((.292032*vnk[16][2])+((.792415*vnk[15][2])+(
      ((temp[0]-(.792415*vnk[12][2]))-(.292032*vnk[13][2]))-(.083616*vnk[14][2])
      ))))-((com[2]*lm[0])-(com[0]*lm[2])));
    temp[0] = (((.55*((rnk[11][0]*vnk[11][1])-(rnk[11][1]*vnk[11][0])))+((.0016*
      (cnk[10][2][2]*u[11]))+((.0005*(cnk[11][2][0]*wk[11][0]))+(.002*(
      cnk[11][2][1]*wk[11][1])))))+(((((.209209*vnk[7][1])+(.493272*vnk[6][1]))+
      ((.55*((rnk[8][0]*vnk[8][1])-(rnk[8][1]*vnk[8][0])))+((.0016*(cnk[7][2][2]
      *u[8]))+((.0005*(cnk[8][2][0]*wk[8][0]))+(.002*(cnk[8][2][1]*wk[8][1])))))
      )-(.493272*vnk[9][1]))-(.209209*vnk[10][1])));
    am[2] = ((((((.083616*vnk[14][1])+((.292032*vnk[13][1])+((.792415*vnk[12][1]
      )+temp[0])))-(.792415*vnk[15][1]))-(.292032*vnk[16][1]))-(.083616*
      vnk[17][1]))-((com[0]*lm[1])-(com[1]*lm[0])));
    temp[0] = (((.033*(wk[5][0]*wk[5][0]))+(5.89*((vnk[5][1]*vnk[5][1])+(
      vnk[5][2]*vnk[5][2]))))+(((.006*(wk[4][0]*wk[4][0]))+((vnk[4][1]*vnk[4][1]
      )+(vnk[4][2]*vnk[4][2])))+(((.18*(u[2]*u[2]))+(16.61*((vnk[2][1]*vnk[2][1]
      )+(vnk[2][2]*vnk[2][2]))))+((.63*(wk[3][0]*wk[3][0]))+(29.27*((vnk[3][1]*
      vnk[3][1])+(vnk[3][2]*vnk[3][2])))))));
    temp[1] = (((.55*((vnk[8][2]*vnk[8][2])+((vnk[8][0]*vnk[8][0])+(vnk[8][1]*
      vnk[8][1]))))+((.0016*(u[8]*u[8]))+((.0005*(wk[8][0]*wk[8][0]))+(.002*(
      wk[8][1]*wk[8][1])))))+(((.0054*(wk[7][0]*wk[7][0]))+(1.21*((vnk[7][1]*
      vnk[7][1])+(vnk[7][2]*vnk[7][2]))))+(((.025*(wk[6][0]*wk[6][0]))+(2.79*((
      vnk[6][1]*vnk[6][1])+(vnk[6][2]*vnk[6][2]))))+temp[0])));
    temp[2] = (((.55*((vnk[11][2]*vnk[11][2])+((vnk[11][0]*vnk[11][0])+(
      vnk[11][1]*vnk[11][1]))))+((.0016*(u[11]*u[11]))+((.0005*(wk[11][0]*
      wk[11][0]))+(.002*(wk[11][1]*wk[11][1])))))+(((.0054*(wk[10][0]*wk[10][0])
      )+(1.21*((vnk[10][1]*vnk[10][1])+(vnk[10][2]*vnk[10][2]))))+(((.025*(
      wk[9][0]*wk[9][0]))+(2.79*((vnk[9][1]*vnk[9][1])+(vnk[9][2]*vnk[9][2]))))+
      temp[1])));
    temp[3] = (((.16*(wk[15][0]*wk[15][0]))+(8.35*((vnk[15][1]*vnk[15][1])+(
      vnk[15][2]*vnk[15][2]))))+(((.0075*(wk[14][0]*wk[14][0]))+(1.34*((
      vnk[14][1]*vnk[14][1])+(vnk[14][2]*vnk[14][2]))))+(((.056*(wk[13][0]*
      wk[13][0]))+(4.16*((vnk[13][1]*vnk[13][1])+(vnk[13][2]*vnk[13][2]))))+(((
      .16*(wk[12][0]*wk[12][0]))+(8.35*((vnk[12][1]*vnk[12][1])+(vnk[12][2]*
      vnk[12][2]))))+temp[2]))));
    *ke = (.5*(((.0075*(wk[17][0]*wk[17][0]))+(1.34*((vnk[17][1]*vnk[17][1])+(
      vnk[17][2]*vnk[17][2]))))+(((.056*(wk[16][0]*wk[16][0]))+(4.16*((
      vnk[16][1]*vnk[16][1])+(vnk[16][2]*vnk[16][2]))))+temp[3])));
/*
 Used 0.15 seconds CPU time,
 24576 additional bytes of memory.
 Equations contain  177 adds/subtracts/negates
                    252 multiplies
                      0 divides
                     16 assignments
*/
}

void robotsys(double *mtoto, double *cm, double (*icm)[3])
{
/*
Compute system total mass, and instantaneous center of mass and
inertia matrix.

Generated 19-Jul-2001 15:43:04 by SD/FAST, Order(N) formulation
(sdfast B.2.6 #70405) on machine ID 690a1b33
Copyright (c) 1990-1996 Symbolic Dynamics, Inc.
Copyright (c) 1990-1996 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/
    double ikcnkt[18][3][3];

    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(20,23);
        return;
    }
    *mtoto = 89.57;
    cm[0] = com[0];
    cm[1] = com[1];
    cm[2] = com[2];
    temp[0] = (((.0015*(s8*s8))+(.55*((rnk[8][1]*rnk[8][1])+(rnk[8][2]*rnk[8][2]
      ))))+((1.21*((rnk[7][1]*rnk[7][1])+(rnk[7][2]*rnk[7][2])))+((2.79*((
      rnk[6][1]*rnk[6][1])+(rnk[6][2]*rnk[6][2])))+((5.89*((rnk[5][1]*rnk[5][1])
      +(rnk[5][2]*rnk[5][2])))+(((16.61*((rnk[2][1]*rnk[2][1])+(rnk[2][2]*
      rnk[2][2])))+(29.27*((rnk[3][1]*rnk[3][1])+(rnk[3][2]*rnk[3][2]))))+((
      rnk[4][1]*rnk[4][1])+(rnk[4][2]*rnk[4][2])))))));
    temp[1] = ((1.34*((rnk[14][1]*rnk[14][1])+(rnk[14][2]*rnk[14][2])))+((4.16*(
      (rnk[13][1]*rnk[13][1])+(rnk[13][2]*rnk[13][2])))+((8.35*((rnk[12][1]*
      rnk[12][1])+(rnk[12][2]*rnk[12][2])))+(((.0015*(s11*s11))+(.55*((
      rnk[11][1]*rnk[11][1])+(rnk[11][2]*rnk[11][2]))))+((1.21*((rnk[10][1]*
      rnk[10][1])+(rnk[10][2]*rnk[10][2])))+((2.79*((rnk[9][1]*rnk[9][1])+(
      rnk[9][2]*rnk[9][2])))+temp[0]))))));
    icm[0][0] = (1.3578+(((1.34*((rnk[17][1]*rnk[17][1])+(rnk[17][2]*rnk[17][2])
      ))+((4.16*((rnk[16][1]*rnk[16][1])+(rnk[16][2]*rnk[16][2])))+((8.35*((
      rnk[15][1]*rnk[15][1])+(rnk[15][2]*rnk[15][2])))+temp[1])))-(89.57*((
      com[1]*com[1])+(com[2]*com[2])))));
    icm[0][1] = ((89.57*(com[0]*com[1]))+((.083616*rnk[17][1])+((.292032*
      rnk[16][1])+((.792415*rnk[15][1])+((((((.209209*rnk[10][1])+((.493272*
      rnk[9][1])+((((.0005*(cnk[8][1][0]*c8))-(.002*(cnk[8][1][1]*s8)))-(.55*(
      rnk[8][0]*rnk[8][1])))-((.209209*rnk[7][1])+(.493272*rnk[6][1])))))+(((
      .0005*(cnk[11][1][0]*c11))-(.002*(cnk[11][1][1]*s11)))-(.55*(rnk[11][0]*
      rnk[11][1]))))-(.792415*rnk[12][1]))-(.292032*rnk[13][1]))-(.083616*
      rnk[14][1]))))));
    icm[0][2] = ((89.57*(com[0]*com[2]))+((.083616*rnk[17][2])+((.292032*
      rnk[16][2])+((.792415*rnk[15][2])+((((((.209209*rnk[10][2])+((.493272*
      rnk[9][2])+((((.0005*(cnk[8][2][0]*c8))-(.002*(cnk[8][2][1]*s8)))-(.55*(
      rnk[8][0]*rnk[8][2])))-((.209209*rnk[7][2])+(.493272*rnk[6][2])))))+(((
      .0005*(cnk[11][2][0]*c11))-(.002*(cnk[11][2][1]*s11)))-(.55*(rnk[11][0]*
      rnk[11][2]))))-(.792415*rnk[12][2]))-(.292032*rnk[13][2]))-(.083616*
      rnk[14][2]))))));
    icm[1][0] = icm[0][1];
    temp[0] = (((.55*((rnk[8][0]*rnk[8][0])+(rnk[8][2]*rnk[8][2])))+((.0016*(
      cnk[7][1][2]*cnk[7][1][2]))+((.0005*(cnk[8][1][0]*cnk[8][1][0]))+(.002*(
      cnk[8][1][1]*cnk[8][1][1])))))+((1.21*(.02989441+(rnk[7][2]*rnk[7][2])))+(
      (2.79*(.03125824+(rnk[6][2]*rnk[6][2])))+((5.89*(rnk[5][2]*rnk[5][2]))+((
      rnk[4][2]*rnk[4][2])+((16.61*(rnk[2][2]*rnk[2][2]))+(29.27*(rnk[3][2]*
      rnk[3][2]))))))));
    temp[1] = ((1.34*(.00389376+(rnk[14][2]*rnk[14][2])))+((4.16*(.00492804+(
      rnk[13][2]*rnk[13][2])))+((8.35*(.00900601+(rnk[12][2]*rnk[12][2])))+(((
      .55*((rnk[11][0]*rnk[11][0])+(rnk[11][2]*rnk[11][2])))+((.0016*(
      cnk[10][1][2]*cnk[10][1][2]))+((.0005*(cnk[11][1][0]*cnk[11][1][0]))+(.002
      *(cnk[11][1][1]*cnk[11][1][1])))))+((1.21*(.02989441+(rnk[10][2]*
      rnk[10][2])))+((2.79*(.03125824+(rnk[9][2]*rnk[9][2])))+temp[0]))))));
    icm[1][1] = (((1.34*(.00389376+(rnk[17][2]*rnk[17][2])))+((4.16*(.00492804+(
      rnk[16][2]*rnk[16][2])))+((8.35*(.00900601+(rnk[15][2]*rnk[15][2])))+
      temp[1])))-(89.57*((com[0]*com[0])+(com[2]*com[2]))));
    temp[0] = ((((((.0016*(cnk[7][1][2]*cnk[7][2][2]))+((.0005*(cnk[8][1][0]*
      cnk[8][2][0]))+(.002*(cnk[8][1][1]*cnk[8][2][1]))))-(.55*(rnk[8][1]*
      rnk[8][2])))-((1.21*(rnk[7][1]*rnk[7][2]))+((2.79*(rnk[6][1]*rnk[6][2]))+(
      (5.89*(rnk[5][1]*rnk[5][2]))+((rnk[4][1]*rnk[4][2])+((16.61*(rnk[2][1]*
      rnk[2][2]))+(29.27*(rnk[3][1]*rnk[3][2]))))))))-(2.79*(rnk[9][1]*rnk[9][2]
      )))-(1.21*(rnk[10][1]*rnk[10][2])));
    icm[1][2] = ((89.57*(com[1]*com[2]))+((((((((((.0016*(cnk[10][1][2]*
      cnk[10][2][2]))+((.0005*(cnk[11][1][0]*cnk[11][2][0]))+(.002*(
      cnk[11][1][1]*cnk[11][2][1]))))-(.55*(rnk[11][1]*rnk[11][2])))+temp[0])-(
      8.35*(rnk[12][1]*rnk[12][2])))-(4.16*(rnk[13][1]*rnk[13][2])))-(1.34*(
      rnk[14][1]*rnk[14][2])))-(8.35*(rnk[15][1]*rnk[15][2])))-(4.16*(rnk[16][1]
      *rnk[16][2])))-(1.34*(rnk[17][1]*rnk[17][2]))));
    icm[2][0] = icm[0][2];
    icm[2][1] = icm[1][2];
    temp[0] = (((.55*((rnk[8][0]*rnk[8][0])+(rnk[8][1]*rnk[8][1])))+((.0016*(
      cnk[7][2][2]*cnk[7][2][2]))+((.0005*(cnk[8][2][0]*cnk[8][2][0]))+(.002*(
      cnk[8][2][1]*cnk[8][2][1])))))+((1.21*(.02989441+(rnk[7][1]*rnk[7][1])))+(
      (2.79*(.03125824+(rnk[6][1]*rnk[6][1])))+((5.89*(rnk[5][1]*rnk[5][1]))+((
      rnk[4][1]*rnk[4][1])+((16.61*(rnk[2][1]*rnk[2][1]))+(29.27*(rnk[3][1]*
      rnk[3][1]))))))));
    temp[1] = ((1.34*(.00389376+(rnk[14][1]*rnk[14][1])))+((4.16*(.00492804+(
      rnk[13][1]*rnk[13][1])))+((8.35*(.00900601+(rnk[12][1]*rnk[12][1])))+(((
      .55*((rnk[11][0]*rnk[11][0])+(rnk[11][1]*rnk[11][1])))+((.0016*(
      cnk[10][2][2]*cnk[10][2][2]))+((.0005*(cnk[11][2][0]*cnk[11][2][0]))+(.002
      *(cnk[11][2][1]*cnk[11][2][1])))))+((1.21*(.02989441+(rnk[10][1]*
      rnk[10][1])))+((2.79*(.03125824+(rnk[9][1]*rnk[9][1])))+temp[0]))))));
    icm[2][2] = (((1.34*(.00389376+(rnk[17][1]*rnk[17][1])))+((4.16*(.00492804+(
      rnk[16][1]*rnk[16][1])))+((8.35*(.00900601+(rnk[15][1]*rnk[15][1])))+
      temp[1])))-(89.57*((com[0]*com[0])+(com[1]*com[1]))));
/*
 Used 0.32 seconds CPU time,
 16384 additional bytes of memory.
 Equations contain  160 adds/subtracts/negates
                    243 multiplies
                      0 divides
                     20 assignments
*/
}

void robotpos(int body, double *pt, double *loc)
{
/*
Return inertial frame location of a point on a body.

*/
    double pv[3];

    if (robotchkbnum(21,body) != 0) {
        return;
    }
    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(21,23);
        return;
    }
    if (body  ==  -1) {
        loc[0] = pt[0];
        loc[1] = pt[1];
        loc[2] = pt[2];
    } else {
        pv[0] = rnb[body][0]+pt[0]*cnb[body][0][0]+pt[1]*cnb[body][0][1]+pt[2]*
          cnb[body][0][2];
        pv[1] = rnb[body][1]+pt[0]*cnb[body][1][0]+pt[1]*cnb[body][1][1]+pt[2]*
          cnb[body][1][2];
        pv[2] = rnb[body][2]+pt[0]*cnb[body][2][0]+pt[1]*cnb[body][2][1]+pt[2]*
          cnb[body][2][2];
        loc[0] = pv[0];
        loc[1] = pv[1];
        loc[2] = pv[2];
    }
}

void robotvel(int body, double *pt, double *velo)
{
/*
Return inertial frame velocity of a point on a body.

*/
    double pv[3];

    if (robotchkbnum(22,body) != 0) {
        return;
    }
    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(22,23);
        return;
    }
    if (body  ==  -1) {
        velo[0] = 0.;
        velo[1] = 0.;
        velo[2] = 0.;
    } else {
        pv[0] = wb[body][1]*pt[2]-wb[body][2]*pt[1];
        pv[1] = wb[body][2]*pt[0]-wb[body][0]*pt[2];
        pv[2] = wb[body][0]*pt[1]-wb[body][1]*pt[0];
        velo[0] = vnb[body][0]+pv[0]*cnb[body][0][0]+pv[1]*cnb[body][0][1]+pv[2]
          *cnb[body][0][2];
        velo[1] = vnb[body][1]+pv[0]*cnb[body][1][0]+pv[1]*cnb[body][1][1]+pv[2]
          *cnb[body][1][2];
        velo[2] = vnb[body][2]+pv[0]*cnb[body][2][0]+pv[1]*cnb[body][2][1]+pv[2]
          *cnb[body][2][2];
    }
}

void robotorient(int body, double (*dircos)[3])
{
/*
Return orientation of body w.r.t. ground frame.

*/

    if (robotchkbnum(23,body) != 0) {
        return;
    }
    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(23,23);
        return;
    }
    if (body == -1) {
        dircos[0][0] = 1.;
        dircos[0][1] = 0.;
        dircos[0][2] = 0.;
        dircos[1][0] = 0.;
        dircos[1][1] = 1.;
        dircos[1][2] = 0.;
        dircos[2][0] = 0.;
        dircos[2][1] = 0.;
        dircos[2][2] = 1.;
    } else {
        dircos[0][0] = cnb[body][0][0];
        dircos[0][1] = cnb[body][0][1];
        dircos[0][2] = cnb[body][0][2];
        dircos[1][0] = cnb[body][1][0];
        dircos[1][1] = cnb[body][1][1];
        dircos[1][2] = cnb[body][1][2];
        dircos[2][0] = cnb[body][2][0];
        dircos[2][1] = cnb[body][2][1];
        dircos[2][2] = cnb[body][2][2];
    }
}

void robotangvel(int body, double *avel)
{
/*
Return angular velocity of the body.

*/

    if (robotchkbnum(24,body) != 0) {
        return;
    }
    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(24,23);
        return;
    }
    if (body == -1) {
        avel[0] = 0.;
        avel[1] = 0.;
        avel[2] = 0.;
    } else {
        avel[0] = wb[body][0];
        avel[1] = wb[body][1];
        avel[2] = wb[body][2];
    }
}

void robottrans(int frbod, double *ivec, int tobod, double *ovec)
{
/*
Transform ivec from frbod frame to tobod frame.

*/
    double pv[3];

    if (robotchkbnum(25,frbod) != 0) {
        return;
    }
    if (robotchkbnum(25,tobod) != 0) {
        return;
    }
    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(25,23);
        return;
    }
    if (frbod == tobod) {
        robotvcopy(ivec,ovec);
        return;
    }
    if (frbod == -1) {
        robotvcopy(ivec,pv);
        ovec[0] = pv[0]*cnb[tobod][0][0]+pv[1]*cnb[tobod][1][0]+pv[2]*cnb[tobod
          ][2][0];
        ovec[1] = pv[0]*cnb[tobod][0][1]+pv[1]*cnb[tobod][1][1]+pv[2]*cnb[tobod
          ][2][1];
        ovec[2] = pv[0]*cnb[tobod][0][2]+pv[1]*cnb[tobod][1][2]+pv[2]*cnb[tobod
          ][2][2];
        return;
    }
    if (tobod == -1) {
        robotvcopy(ivec,pv);
        ovec[0] = pv[0]*cnb[frbod][0][0]+pv[1]*cnb[frbod][0][1]+pv[2]*cnb[frbod
          ][0][2];
        ovec[1] = pv[0]*cnb[frbod][1][0]+pv[1]*cnb[frbod][1][1]+pv[2]*cnb[frbod
          ][1][2];
        ovec[2] = pv[0]*cnb[frbod][2][0]+pv[1]*cnb[frbod][2][1]+pv[2]*cnb[frbod
          ][2][2];
        return;
    }
    pv[0] = ivec[0]*cnb[frbod][0][0]+ivec[1]*cnb[frbod][0][1]+ivec[2]*cnb[frbod
      ][0][2];
    pv[1] = ivec[0]*cnb[frbod][1][0]+ivec[1]*cnb[frbod][1][1]+ivec[2]*cnb[frbod
      ][1][2];
    pv[2] = ivec[0]*cnb[frbod][2][0]+ivec[1]*cnb[frbod][2][1]+ivec[2]*cnb[frbod
      ][2][2];
    ovec[0] = pv[0]*cnb[tobod][0][0]+pv[1]*cnb[tobod][1][0]+pv[2]*cnb[tobod][2][
      0];
    ovec[1] = pv[0]*cnb[tobod][0][1]+pv[1]*cnb[tobod][1][1]+pv[2]*cnb[tobod][2][
      1];
    ovec[2] = pv[0]*cnb[tobod][0][2]+pv[1]*cnb[tobod][1][2]+pv[2]*cnb[tobod][2][
      2];
}

void robotrel2cart(int coord, int body, double *point, double *linchg, double *rotchg)
{
/* Return derivative of pt loc and body orient w.r.t. hinge rate
*/
    int x,i,gnd;
    double lin[3],pv[3];
    double pink[3],ptvec[3];

    if ((coord < 0) || (coord > 17)) {
        robotseterr(59,45);
        return;
    }
    if (robotchkbnum(59,body) != 0) {
        return;
    }
    if ((roustate != 2) && (roustate != 3)) {
        robotseterr(59,23);
        return;
    }
    gnd = -1;
    robotvset(0.,0.,0.,linchg);
    robotvset(0.,0.,0.,rotchg);
    i = body;
    for (;;) {
        if (i == gnd) {
            return;
        }
        x = firstq[i];
        if (x <= coord) {
            if (coord >= x+njntdof[i]) {
                return;
            }
            break;
        }
        i = inb[i];
    }
    robotdoping();
    for (i = 0; i < 3; i++) {
        pink[i] = ping[coord][i];
        lin[i] = hngpt[coord][i];
    }
    robottrans(gnd,pink,body,pink);
    if (trans[coord] != 0) {
        robotvcopy(pink,linchg);
    } else {
        robotvcopy(pink,rotchg);
        robotpos(body,point,ptvec);
        robotvsub(ptvec,lin,ptvec);
        robottrans(gnd,ptvec,body,ptvec);
        robotvcross(pink,ptvec,linchg);
    }
}

void robotacc(int body, double *pt, double *accel)
{
/*
Return linear acceleration a point of the specified body.

*/
    double pv[3];

    if (robotchkbnum(32,body) != 0) {
        return;
    }
    if (roustate != 3) {
        robotseterr(32,24);
        return;
    }
    if (body  ==  -1) {
        accel[0] = 0.;
        accel[1] = 0.;
        accel[2] = 0.;
    } else {
        pv[0] = pt[0]*dyad[body][0][0]+pt[1]*dyad[body][0][1]+pt[2]*dyad[body][0
          ][2];
        pv[1] = pt[0]*dyad[body][1][0]+pt[1]*dyad[body][1][1]+pt[2]*dyad[body][1
          ][2];
        pv[2] = pt[0]*dyad[body][2][0]+pt[1]*dyad[body][2][1]+pt[2]*dyad[body][2
          ][2];
        accel[0] = anb[body][0]+pv[0]*cnb[body][0][0]+pv[1]*cnb[body][0][1]+pv[2
          ]*cnb[body][0][2];
        accel[1] = anb[body][1]+pv[0]*cnb[body][1][0]+pv[1]*cnb[body][1][1]+pv[2
          ]*cnb[body][1][2];
        accel[2] = anb[body][2]+pv[0]*cnb[body][2][0]+pv[1]*cnb[body][2][1]+pv[2
          ]*cnb[body][2][2];
    }
}

void robotangacc(int body, double *aacc)
{
/*
Return angular acceleration of the body.

*/

    if (robotchkbnum(33,body) != 0) {
        return;
    }
    if (roustate != 3) {
        robotseterr(33,24);
        return;
    }
    if (body == -1) {
        aacc[0] = 0.;
        aacc[1] = 0.;
        aacc[2] = 0.;
    } else {
        aacc[0] = onb[body][0];
        aacc[1] = onb[body][1];
        aacc[2] = onb[body][2];
    }
}

void robotgrav(double *gravin)
{

    robotseterr(1,19);
    roustate = 0;
}

void robotmass(int body, double massin)
{

    if (robotchkbnum(2,body) != 0) {
        return;
    }
    if (body == -1) {
        robotseterr(2,15);
        return;
    }
    if (mkq[body] != 0) {
        mk[body] = massin;
        mkq[body] = 3;
    } else {
        robotseterr(2,19);
    }
    roustate = 0;
}

void robotiner(int body, double (*inerin)[3])
{
    int anyques;

    if (robotchkbnum(3,body) != 0) {
        return;
    }
    if (body == -1) {
        robotseterr(3,15);
        return;
    }
    anyques = 0;
    if (ikq[body][0][0]  !=  0) {
        ik[body][0][0] = inerin[0][0];
        ikq[body][0][0] = 3;
        anyques = 1;
    }
    if (ikq[body][0][1]  !=  0) {
        ik[body][0][1] = inerin[0][1];
        ikq[body][0][1] = 3;
        ik[body][1][0] = inerin[0][1];
        ikq[body][1][0] = 3;
        anyques = 1;
    }
    if (ikq[body][0][2]  !=  0) {
        ik[body][0][2] = inerin[0][2];
        ikq[body][0][2] = 3;
        ik[body][2][0] = inerin[0][2];
        ikq[body][2][0] = 3;
        anyques = 1;
    }
    if (ikq[body][1][1]  !=  0) {
        ik[body][1][1] = inerin[1][1];
        ikq[body][1][1] = 3;
        anyques = 1;
    }
    if (ikq[body][1][2]  !=  0) {
        ik[body][1][2] = inerin[1][2];
        ikq[body][1][2] = 3;
        ik[body][2][1] = inerin[1][2];
        ikq[body][2][1] = 3;
        anyques = 1;
    }
    if (ikq[body][2][2]  !=  0) {
        ik[body][2][2] = inerin[2][2];
        ikq[body][2][2] = 3;
        anyques = 1;
    }
    if (anyques == 0) {
        robotseterr(3,19);
    }
    roustate = 0;
}

void robotbtj(int joint, double *btjin)
{
    int anyques;

    if (robotchkjnum(4,joint) != 0) {
        return;
    }
    anyques = 0;
    if (rkq[joint][0]  !=  0) {
        rk[joint][0] = btjin[0];
        rkq[joint][0] = 3;
        anyques = 1;
    }
    if (rkq[joint][1]  !=  0) {
        rk[joint][1] = btjin[1];
        rkq[joint][1] = 3;
        anyques = 1;
    }
    if (rkq[joint][2]  !=  0) {
        rk[joint][2] = btjin[2];
        rkq[joint][2] = 3;
        anyques = 1;
    }
    if (anyques == 0) {
        robotseterr(4,19);
    }
    roustate = 0;
}

void robotitj(int joint, double *itjin)
{
    int anyques;

    if (robotchkjnum(5,joint) != 0) {
        return;
    }
    anyques = 0;
    if (riq[joint][0]  !=  0) {
        ri[joint][0] = itjin[0];
        riq[joint][0] = 3;
        anyques = 1;
    }
    if (riq[joint][1]  !=  0) {
        ri[joint][1] = itjin[1];
        riq[joint][1] = 3;
        anyques = 1;
    }
    if (riq[joint][2]  !=  0) {
        ri[joint][2] = itjin[2];
        riq[joint][2] = 3;
        anyques = 1;
    }
    if (anyques == 0) {
        robotseterr(5,19);
    }
    roustate = 0;
}

void robotpin(int joint, int pinno, double *pinin)
{
    int anyques,offs;

    if (robotchkjpin(6,joint,pinno) != 0) {
        return;
    }
    anyques = 0;
    offs = firstq[joint]+pinno;
    if (jtype[joint] == 21) {
        offs = offs+3;
    }
    if (jtype[joint] == 11) {
        offs = offs+1;
    }
    if (pinq[offs][0]  !=  0) {
        pin[offs][0] = pinin[0];
        pinq[offs][0] = 3;
        anyques = 1;
    }
    if (pinq[offs][1]  !=  0) {
        pin[offs][1] = pinin[1];
        pinq[offs][1] = 3;
        anyques = 1;
    }
    if (pinq[offs][2]  !=  0) {
        pin[offs][2] = pinin[2];
        pinq[offs][2] = 3;
        anyques = 1;
    }
    if (anyques == 0) {
        robotseterr(6,19);
    }
    roustate = 0;
}

void robotpres(int joint, int axis, int presin)
{
    int anyques;

    if (robotchkjaxis(37,joint,axis) != 0) {
        return;
    }
    if ((presin != 0) && (presin != 1)) {
        robotseterr(37,20);
    }
    anyques = 0;
    if (presq[robotindx(joint,axis)]  !=  0) {
        if (presin  !=  0) {
            pres[robotindx(joint,axis)] = 1.;
        } else {
            pres[robotindx(joint,axis)] = 0.;
        }
        presq[robotindx(joint,axis)] = 3;
        anyques = 1;
    }
    if (anyques == 0) {
        robotseterr(37,19);
    }
    wwflg = 0;
}

void robotstab(double velin, double posin)
{

    stabvel = velin;
    stabvelq = 3;
    stabpos = posin;
    stabposq = 3;
}

void robotgetgrav(double *gravout)
{

    gravout[0] = grav[0];
    gravout[1] = grav[1];
    gravout[2] = grav[2];
}

void robotgetmass(int body, double *massout)
{

    if (robotchkbnum(40,body) != 0) {
        return;
    }
    if (body == -1) {
        robotseterr(40,15);
        return;
    }
    *massout = mk[body];
}

void robotgetiner(int body, double (*inerout)[3])
{

    if (robotchkbnum(41,body) != 0) {
        return;
    }
    if (body == -1) {
        robotseterr(41,15);
        return;
    }
    inerout[0][0] = ik[body][0][0];
    inerout[0][1] = ik[body][0][1];
    inerout[0][2] = ik[body][0][2];
    inerout[1][0] = ik[body][1][0];
    inerout[1][1] = ik[body][1][1];
    inerout[1][2] = ik[body][1][2];
    inerout[2][0] = ik[body][2][0];
    inerout[2][1] = ik[body][2][1];
    inerout[2][2] = ik[body][2][2];
}

void robotgetbtj(int joint, double *btjout)
{

    if (robotchkjnum(42,joint) != 0) {
        return;
    }
    btjout[0] = rk[joint][0];
    btjout[1] = rk[joint][1];
    btjout[2] = rk[joint][2];
}

void robotgetitj(int joint, double *itjout)
{

    if (robotchkjnum(43,joint) != 0) {
        return;
    }
    itjout[0] = ri[joint][0];
    itjout[1] = ri[joint][1];
    itjout[2] = ri[joint][2];
}

void robotgetpin(int joint, int pinno, double *pinout)
{
    int offs;

    if (robotchkjpin(44,joint,pinno) != 0) {
        return;
    }
    offs = firstq[joint]+pinno;
    if (jtype[joint] == 21) {
        offs = offs+3;
    }
    if (jtype[joint] == 11) {
        offs = offs+1;
    }
    pinout[0] = pin[offs][0];
    pinout[1] = pin[offs][1];
    pinout[2] = pin[offs][2];
}

void robotgetpres(int joint, int axis, int *presout)
{

    if (robotchkjaxis(45,joint,axis) != 0) {
        return;
    }
    if (pres[robotindx(joint,axis)]  !=  0.) {
        *presout = 1;
    } else {
        *presout = 0;
    }
}

void robotgetstab(double *velout, double *posout)
{

    *velout = stabvel;
    *posout = stabpos;
}

void robotinfo(int *info)
{

    info[0] = ground;
    info[1] = nbod;
    info[2] = ndof;
    info[3] = ncons;
    info[4] = nloop;
    info[5] = nldof;
    info[6] = nloopc;
    info[7] = nball;
    info[8] = nlball;
    info[9] = npres;
    info[10] = nuser;
    info[11] = 0;
/* info entries from 12-49 are reserved */
}

void robotjnt(int joint, int *info, int *tran)
{
    int i,offs;

    if (robotchkjnum(48,joint) != 0) {
        return;
    }
    info[0] = jtype[joint];
    info[1] = 0;
    offs = 0;
    info[2] = inb[joint];
    info[3] = outb[joint];
    info[4] = njntdof[joint];
    info[5] = njntc[joint];
    info[6] = njntp[joint];
    info[7] = firstq[joint];
    info[8] = ballq[joint];
    info[9] = firstm[joint];
    info[10] = firstp[joint];
/* info entries from 11-49 are reserved */

    for (i = 0; i <= 5; i++) {
        if (i  <  njntdof[joint]) {
            tran[i] = trans[offs+firstq[joint]+i];
        } else {
            tran[i] = -1;
        }
    }
}

void robotcons(int consno, int *info)
{

    if (robotchkucnum(49,consno) != 0) {
        return;
    }
/* There are no user constraints in this problem. */
}

int robotchkbnum(int routine, int bnum)
{

    if ((bnum < -1) || (bnum > 15)) {
        robotseterr(routine,15);
        return 1;
    }
    return 0;
}

int robotchkjnum(int routine, int jnum)
{

    if ((jnum < 0) || (jnum > 15)) {
        robotseterr(routine,16);
        return 1;
    }
    return 0;
}

int robotchkucnum(int routine, int ucnum)
{

    if ((ucnum < 0) || (ucnum > -1)) {
        robotseterr(routine,21);
        return 1;
    }
    return 0;
}

int robotchkjaxis(int routine, int jnum, int axnum)
{
    int maxax;

    if (robotchkjnum(routine,jnum) != 0) {
        return 1;
    }
    if ((axnum < 0) || (axnum > 6)) {
        robotseterr(routine,17);
        return 1;
    }
    maxax = njntdof[jnum]-1;
    if ((jtype[jnum] == 4) || (jtype[jnum] == 6) || (jtype[jnum] == 21)) {
        maxax = maxax+1;
    }
    if (axnum > maxax) {
        robotseterr(routine,18);
        return 1;
    }
    return 0;
}

int robotchkjpin(int routine, int jnum, int pinno)
{
    int maxax,pinok;

    if (robotchkjnum(routine,jnum) != 0) {
        return 1;
    }
    if ((pinno < 0) || (pinno > 5)) {
        robotseterr(routine,17);
        return 1;
    }
    if (njntdof[jnum] >= 3) {
        maxax = 2;
    } else {
        maxax = njntdof[jnum]-1;
    }
    if (jtype[jnum] == 4) {
        maxax = -1;
    }
    if (jtype[jnum] == 7) {
        maxax = 0;
    }
    pinok = 0;
    if (pinno <= maxax) {
        pinok = 1;
    }
    if (pinok == 0) {
        robotseterr(routine,18);
        return 1;
    }
    return 0;
}

/* Convert state to form using 1-2-3 Euler angles for ball joints. */

void robotst2ang(double *st, double *stang)
{
    int i;

    for (i = 0; i < 18; i++) {
        stang[i] = st[i];
    }
}

/* Convert 1-2-3 form of state back to Euler parameters for ball joints. */

void robotang2st(double *stang, double *st)
{
    int i;

    for (i = 0; i < 18; i++) {
        st[i] = stang[i];
    }
}

/* Normalize Euler parameters in state. */

void robotnrmsterr(double *st, double *normst, int routine)
{
    int i;

    for (i = 0; i < 18; i++) {
        normst[i] = st[i];
    }
}

void robotnormst(double *st, double *normst)
{

    robotnrmsterr(st,normst,0);
}

void robotgentime(int *gentm)
{

    *gentm = 154259;
}
/*
Done. CPU seconds used: 5.56  Memory used: 1146880 bytes.
Equation complexity:
  sdstate:   447 adds   641 multiplies     0 divides   701 assignments
  sdderiv:  2036 adds  2666 multiplies    55 divides  2089 assignments
  sdresid:   780 adds   732 multiplies     0 divides   768 assignments
  sdreac:    426 adds   326 multiplies     0 divides   357 assignments
  sdmom:     177 adds   252 multiplies     0 divides    16 assignments
  sdsys:     160 adds   243 multiplies     0 divides    20 assignments
*/
