
#ifndef SDFAST_H

#ifdef __cplusplus
extern "C"{
#endif


#ifdef WIN32
#ifndef DLLIMPORT
#define DLLIMPORT __declspec(dllimport)
#endif
#ifndef DLLEXPORT
#define DLLEXPORT __declspec(dllexport)
#endif

#else
#ifndef DLLIMPORT
#define DLLIMPORT
#endif
#ifndef DLLEXPORT
#define DLLEXPORT
#endif
#endif


#include <stdio.h>


// User supplied sdfast functions

#define robotuforce (*sduforce)
extern DLLIMPORT void robotuforce(double t, double *q, double *u);

#define robotumotion (*sdumotion)
extern DLLIMPORT void robotumotion(double t, double *q, double *u);

#define robotuperr (*sduperr)
extern DLLIMPORT void robotuperr(double t, double *q, double *err);

#define robotuverr (*sduverr)
extern DLLIMPORT void robotuverr(double t, double *q, double *u, double *err);

#define robotuaerr (*sduaerr)
extern DLLIMPORT void robotuaerr(double t, double *q, double *u, 
double *udot, double *err);

#define robotuconsfrc (*sduconsfrc)
extern DLLIMPORT void robotuconsfrc(double t, double *q, double *u, 
double *mults);

// BEGIN robot_d.c function prototypes
DLLEXPORT void robotinit();
DLLEXPORT void robotst2ang(double *st, double *stang);
DLLEXPORT void robotang2st(double *stang, double *st);
DLLEXPORT void robotnrmsterr(double *st, double *normst, int routine);
DLLEXPORT void robotnormst(double *st, double *normst);
DLLEXPORT void robotstate(double timein, double *qin, double *uin);
DLLEXPORT void robotqdot(double *oqdot);
DLLEXPORT void robotu2qdot(double *uin, double *oqdot);
DLLEXPORT void robotpsstate(double *lqin);
DLLEXPORT void robotdoping();
DLLEXPORT void robotdoltau();
DLLEXPORT void robotdoiner();
DLLEXPORT void robotdofs0();
DLLEXPORT void robotdomm(int routine);
DLLEXPORT void robotlhs(int routine);
DLLEXPORT void robotmfrc(double *imult);
DLLEXPORT void robotequivht(double *tau);
DLLEXPORT void robotfs0();
DLLEXPORT void robotfsmult();
DLLEXPORT void robotfsfull();
DLLEXPORT void robotfsgenmult();
DLLEXPORT void robotfsgenfull();
DLLEXPORT void robotfulltrq(double *udotin, double *multin, double *trqout);
DLLEXPORT void robotcomptrq(double *udotin, double *trqout);
DLLEXPORT void robotmulttrq(double *multin, double *trqout);
DLLEXPORT void robotrhs();
DLLEXPORT void robotmassmat(double mmat[18][18]);
DLLEXPORT void robotfrcmat(double *fmat);
DLLEXPORT void robotpseudo(double *lqout, double *luout);
DLLEXPORT void robotpsqdot(double *lqdout);
DLLEXPORT void robotpsudot(double *ludout);
DLLEXPORT void robotperr(double *errs);
DLLEXPORT void robotverr(double *errs);
DLLEXPORT void robotaerr(double *errs);
DLLEXPORT int 
robotchkbnum(int routine, int bnum);
DLLEXPORT int 
robotchkjnum(int routine, int jnum);
DLLEXPORT int 
robotchkucnum(int routine, int ucnum);
DLLEXPORT int 
robotchkjaxis(int routine, int jnum, int axnum);
DLLEXPORT int 
robotchkjpin(int routine, int jnum, int pinno);
DLLEXPORT int 
robotindx(int joint, int axis);
DLLEXPORT void robotpresacc(int joint, int axis, double prval);
DLLEXPORT void robotpresvel(int joint, int axis, double prval);
DLLEXPORT void robotprespos(int joint, int axis, double prval);
DLLEXPORT void robotgetht(int joint, int axis, double *torque);
DLLEXPORT void robothinget(int joint, int axis, double torque);
DLLEXPORT void robotpointf(int body, double *point, double *force);
DLLEXPORT void robotbodyt(int body, double *torque);
DLLEXPORT void robotdoww(int routine);
DLLEXPORT void robotxudot0(int routine, double *oudot0);
DLLEXPORT void robotudot0(double *oudot0);
DLLEXPORT void robotsetudot(double *iudot);
DLLEXPORT void robotxudotm(int routine, double *imult, double *oudotm);
DLLEXPORT void robotudotm(double *imult, double *oudotm);
DLLEXPORT void robotderiv(double *oqdot, double *oudot);
DLLEXPORT void robotresid(double *eqdot, double *eudot, double *emults, double *resid);
DLLEXPORT void robotmult(double *omults, int *owrank, int *omultmap);
DLLEXPORT void robotreac(double force[16][3], double torque[16][3]);
DLLEXPORT void robotmom(double *lm, double *am, double *ke);
DLLEXPORT void robotsys(double *mtoto, double *cm, double icm[3][3]);
DLLEXPORT void robotpos(int body, double *pt, double *loc);
DLLEXPORT void robotvel(int body, double *pt, double *velo);
DLLEXPORT void robotorient(int body, double dircos[3][3]);
DLLEXPORT void robotangvel(int body, double *avel);
DLLEXPORT void robottrans(int frbod, double *ivec, int tobod, double *ovec);
DLLEXPORT void robotrel2cart(int coord, int body, double *point, double *linchg, double *rotchg);
DLLEXPORT void robotacc(int body, double *pt, double *accel);
DLLEXPORT void robotangacc(int body, double *aacc);
DLLEXPORT void robotgrav(double *gravin);
DLLEXPORT void robotmass(int body, double massin);
DLLEXPORT void robotiner(int body, double inerin[3][3]);
DLLEXPORT void robotbtj(int joint, double *btjin);
DLLEXPORT void robotitj(int joint, double *itjin);
DLLEXPORT void robotpin(int joint, int pinno, double *pinin);
DLLEXPORT void robotpres(int joint, int axis, int presin);
DLLEXPORT void robotconschg();
DLLEXPORT void robotstab(double velin, double posin);
DLLEXPORT void robotgetgrav(double *gravout);
DLLEXPORT void robotgetmass(int body, double *massout);
DLLEXPORT void robotgetiner(int body, double inerout[3][3]);
DLLEXPORT void robotgetbtj(int joint, double *btjout);
DLLEXPORT void robotgetitj(int joint, double *itjout);
DLLEXPORT void robotgetpin(int joint, int pinno, double *pinout);
DLLEXPORT void robotgetpres(int joint, int axis, int *presout);
DLLEXPORT void robotgetstab(double *velout, double *posout);
DLLEXPORT void robotinfo(int *info);
DLLEXPORT void robotjnt(int joint, int *info, int *tran);
DLLEXPORT void robotcons(int consno, int *info);
DLLEXPORT void robotgentime(int *gentm);
// END robot_d.c function prototypes


// BEGIN robot_s.c function prototypes
DLLEXPORT void robotposfunc(double *vars, double *param, double *resid);
DLLEXPORT void robotvelfunc(double *vars, double *param, double *resid);
DLLEXPORT int robotstatfunc(double *vars, double *param, double *resid);
DLLEXPORT int robotstdyfunc(double *vars, double *param, double *resid);
DLLEXPORT int robotmotfunc(double time, double *state, double *dstate, double *param, int *status);
DLLEXPORT void robotassemble(double time, double *state, int *lock, double tol, int maxevals, int *fcnt, int *err);
DLLEXPORT void robotinitvel(double time, double *state, int *lock, double tol, int maxevals, int *fcnt, int *err);
DLLEXPORT void robotstatic(double time, double *state, int *lock, double ctol, double tol, int maxevals, int *fcnt, int *err);
DLLEXPORT void robotsteady(double time, double *state, int *lock, double ctol, double tol, int maxevals, int *fcnt, int *err);
DLLEXPORT void robotmotion(double *time, double *state, double *dstate, double dt, double ctol, double tol, int *flag, int *err);
DLLEXPORT void robotfmotion(double *time, double *state, double *dstate, double dt, double ctol, int *flag, double *errest, int *err);
// END robot_s.c function prototypes


// BEGIN robotlib.c function prototypes
DLLEXPORT void robotprerrmsg(FILE *fnum, int routine, int errnum);
DLLEXPORT void roboterror(int *routine, int *errnum);
DLLEXPORT void robotprinterr(FILE *fnum);
DLLEXPORT void robotclearerr();
DLLEXPORT void robotseterr(int routine, int errnum);
DLLEXPORT void robotldudcomp(int n, int na, int *map, double tol, double *ld, double *sum, double *m, double *l, double *d);
DLLEXPORT void robotldubsl(int n, int na, int *map, double *l, double *b, double *x);
DLLEXPORT void robotldubsd(int n, int na, int *map, double *d, double *b, double *x);
DLLEXPORT void robotldubsu(int n, int na, int *map, double *l, double *b, double *x);
DLLEXPORT void robotldubslv(int n, int na, int *map, double *work, double *l, double *d, double *b, double *x);
DLLEXPORT void robotlduslv(int n, int na, int *map, double tol, double *work1, double *work2, double *m, double *b, double *l, double *d, double *x);
DLLEXPORT void robotqrdcomp(int nr, int nc, int nra, int nca, int *mapr, int *mapc, double *w, double *qraux, int *jpvt);
DLLEXPORT void robotqrsl(int nr, int nc, int nra, int nca, int *mapr, int *mapc, int k, double *work, double *w, double *qraux, double *b, double *x);
DLLEXPORT void robotqrbslv(int nr, int nc, int nra, int nca, int *mapr, int *mapc, double tol, double *work, int *iwork, double *w, double *qraux, int *jpvt, double *b, double *x, int *rank);
DLLEXPORT void robotqrslv(int nr, int nc, int nra, int nca, int *mapr, int *mapc, double tol, int *jpvt, double *qraux, double *work, int *iwork, double *w, double *b, double *x, int *rank);
DLLEXPORT void robotlsslv(int nr, int nc, int nra, int nca, int ndes, int *mapr, int *mapc, double tol, double *dw, double *rw, int *iw, double *w, double *b, double *x);
DLLEXPORT void robotcalcerrs(double *fval, int nfunc, int ndes, int dnorm, double *maxderr, double *maxrerr, double *derrnorm);
DLLEXPORT void robotadjvars(int (*func)(), double *vars, double *param, int nfunc, int ndes, int dnorm, int nvar, double *deltas, double step, double rerr, double tderr, double rtol, int *fcnt, double *newvars, double *newerrs);
DLLEXPORT void robotcalcjac(int (*func)(), double *vars, double *param, int nfunc, int nvar, int *lock, double delta, double *fval, double *ftmp, double *jw, int *fcnt, double *scale);
DLLEXPORT void robotroot(int (*func)(), double *vars, double *param, int nfunc, int nvar, int ndesin, int *lock, double rtol, double dtol, int maxeval, double *jw, double *dw, double *rw, int *iw, double *fret, int *fcnt, int *err);
DLLEXPORT void robotrk4m(int (*func)(), double time, double *st, double *dst0, double *param, double step, double *nst, int neq, double *work, double *errs, double *maxerr, int *which);
DLLEXPORT void robotfinteg(int (*func)(), double *time, double *st, double *dst, double *param, double step, int neq, double *work, double *errest, int *status);
DLLEXPORT void robotvinteg(int (*func)(), double *time, double *st, double *dst, double *param, double dt, double *step, int neqin, double tol, double *work, int *err, int *which);
DLLEXPORT void robotdc2ang(double dircos[3][3], double *a1, double *a2, double *a3);
DLLEXPORT void robotdc2quat(double dircos[3][3], double *e1, double *e2, double *e3, double *e4);
DLLEXPORT void robotang2dc(double a1, double a2, double a3, double dircos[3][3]);
DLLEXPORT void robotquat2dc(double ie1, double ie2, double ie3, double ie4, double dircos[3][3]);
DLLEXPORT void robotvcopy(double *ivec, double *ovec);
DLLEXPORT void robotvset(double sclr1, double sclr2, double sclr3, double *ovec);
DLLEXPORT void robotvadd(double *ivec1, double *ivec2, double *ovec);
DLLEXPORT void robotvsub(double *ivec1, double *ivec2, double *ovec);
DLLEXPORT void robotvmul(double sclr, double *ivec, double *ovec);
DLLEXPORT void robotvaxpy(double sclr, double *ivec1, double *ivec2, double *ovec);
DLLEXPORT void robotvcross(double *ivec1, double *ivec2, double *ovec);
DLLEXPORT void robotvrot(double *ivec, double *rvec, double theta, double *ovec);
DLLEXPORT void robotserialno(int *serno);
// END robotlib.c function prototypes


// FILE *traceFile;



#ifdef __cplusplus
}
#endif


#endif
