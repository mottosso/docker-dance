#ifdef __cplusplus
extern "C" {
#endif
/*
Generated 19-Jul-2001 15:43:29 by SD/FAST, Order(N) formulation
Generated 19-Jul-2001 15:43:29 by SD/FAST, Order(N) formulation
(sdfast B.2.6 #70405) on machine ID 690a1b33
Copyright (c) 1990-1996 Symbolic Dynamics, Inc.
Copyright (c) 1990-1996 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/
#include <math.h>
#include "sdfast.h"

/* These routines are passed to robotroot. */

void robotposfunc(double *vars, double *param, double *resid)
{
    int i;
    double pos[18],vel[18];

    for (i = 0; i < 18; i++) {
        vel[i] = 0.;
    }
    robotang2st(vars,pos);
    robotstate(param[0],pos,vel);
    robotperr(resid);
}

void robotvelfunc(double *vars, double *param, double *resid)
{

    robotstate(param[18],param,vars);
    robotverr(resid);
}

void robotstatfunc(double *vars, double *param, double *resid)
{
    double pos[18],qdotdum[18];

    robotang2st(vars,pos);
    robotstate(param[18],pos,param);
    robotuforce(param[18],pos,param);
    robotperr(resid);
    robotderiv(qdotdum,&resid[0]);
}

void robotstdyfunc(double *vars, double *param, double *resid)
{
    double pos[18],qdotdum[18];

    robotang2st(vars,pos);
    robotstate(param[0],pos,&vars[18]);
    robotuforce(param[0],pos,&vars[18]);
    robotperr(resid);
    robotverr(&resid[0]);
    robotderiv(qdotdum,&resid[0]);
}

/* This routine is passed to the integrator. */

void robotmotfunc(double time, double *state, double *dstate, double *param, int *status)
{

    robotstate(time,state,&state[18]);
    robotuforce(time,state,&state[18]);
    robotderiv(dstate,&dstate[18]);
    *status = 0;
}

/* This routine performs assembly analysis. */

void robotassemble(double time, double *state, int *lock, double tol, int maxevals, int *fcnt, int *err)
{
    double perrs[1],param[1];
    int i;

    robotgentime(&i);
    if (i != 154329) {
        robotseterr(50,42);
    }
    param[0] = time;
    *err = 0;
    *fcnt = 0;
    robotposfunc(state,param,perrs);
    *fcnt = *fcnt+1;
}

/* This routine performs initial velocity analysis. */

void robotinitvel(double time, double *state, int *lock, double tol, int maxevals, int *fcnt, int *err)
{
    double verrs[1],param[19];
    int i;

    robotgentime(&i);
    if (i != 154329) {
        robotseterr(51,42);
    }
    for (i = 0; i < 18; i++) {
        param[i] = state[i];
    }
    param[18] = time;
    *err = 0;
    *fcnt = 0;
    robotvelfunc(&state[18],param,verrs);
    *fcnt = *fcnt+1;
}

/* This routine performs static analysis. */

void robotstatic(double time, double *state, int *lock, double ctol, double tol, int maxevals, int *fcnt, int *err)
{
    double resid[18],param[19],jw[324],dw[2592],rw[288];
    int iw[144],rooterr,i;

    robotgentime(&i);
    if (i != 154329) {
        robotseterr(52,42);
    }
    for (i = 0; i < 18; i++) {
        param[i] = state[18+i];
    }
    param[18] = time;
    robotroot(robotstatfunc,state,param,18,18,18,lock,
      ctol,tol,maxevals,jw,dw,rw,iw,resid,fcnt,&rooterr);
    robotstatfunc(state,param,resid);
    *fcnt = *fcnt+1;
    if (rooterr == 0) {
        *err = 0;
    } else {
        if (*fcnt >= maxevals) {
            *err = 2;
        } else {
            *err = 1;
        }
    }
}

/* This routine performs steady motion analysis. */

void robotsteady(double time, double *state, int *lock, double ctol, double tol, int maxevals, int *fcnt, int *err)
{
    double resid[18],param[1];
    double jw[648],dw[5832],rw[450];
    int iw[216],rooterr,i;

    robotgentime(&i);
    if (i != 154329) {
        robotseterr(53,42);
    }
    param[0] = time;
    robotroot(robotstdyfunc,state,param,18,36,18,lock,
      ctol,tol,maxevals,jw,dw,rw,iw,resid,fcnt,&rooterr);
    robotstdyfunc(state,param,resid);
    *fcnt = *fcnt+1;
    if (rooterr == 0) {
        *err = 0;
    } else {
        if (*fcnt >= maxevals) {
            *err = 2;
        } else {
            *err = 1;
        }
    }
}

/* This routine performs state integration. */

void robotmotion(double *time, double *state, double *dstate, double dt, double ctol, double tol, int *flag, int *err)
{
    static double step;
    double work[216],ttime,param[1];
    int vintgerr,which,ferr,i;

    robotgentime(&i);
    if (i != 154329) {
        robotseterr(54,42);
    }
    param[0] = ctol;
    ttime = *time;
    if (*flag != 0) {
        robotmotfunc(ttime,state,dstate,param,&ferr);
        step = dt;
        *flag = 0;
    }
    if (step <= 0.) {
        step = dt;
    }
    robotvinteg(robotmotfunc,&ttime,state,dstate,param,dt,&step,36,tol,work,&
      vintgerr,&which);
    *time = ttime;
    *err = vintgerr;
}

/* This routine performs state integration with a fixed-step integrator. */

void robotfmotion(double *time, double *state, double *dstate, double dt, double ctol, int *flag, double *errest, int *err)
{
    double work[144],ttime,param[1];
    int ferr,i;

    robotgentime(&i);
    if (i != 154329) {
        robotseterr(55,42);
    }
    param[0] = ctol;
    *err = 0;
    ttime = *time;
    if (*flag != 0) {
        robotmotfunc(ttime,state,dstate,param,&ferr);
        *flag = 0;
    }
    robotfinteg(robotmotfunc,&ttime,state,dstate,param,dt,36,work,errest,&ferr);
    if (ferr != 0) {
        *err = 1;
    }
    *time = ttime;
}
#ifdef __cplusplus
}
#endif
