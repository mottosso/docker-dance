// BEGIN /nfs/medusa.dgp/ondemand10/pfal/danceMulti/sdfastObjs/robot/robot_sar.c function prototypes

void robotposfunc(double *vars, double *param, double *resid);
void robotvelfunc(double *vars, double *param, double *resid);
void robotstatfunc(double *vars, double *param, double *resid);
void robotstdyfunc(double *vars, double *param, double *resid);
void robotmotfunc(double time, double *state, double *dstate, double *param, int *status);
void robotassemble(double time, double *state, int *lock, double tol, int maxevals, int *fcnt, int *err);
void robotinitvel(double time, double *state, int *lock, double tol, int maxevals, int *fcnt, int *err);
void robotstatic(double time, double *state, int *lock, double ctol, double tol, int maxevals, int *fcnt, int *err);
void robotsteady(double time, double *state, int *lock, double ctol, double tol, int maxevals, int *fcnt, int *err);
void robotmotion(double *time, double *state, double *dstate, double dt, double ctol, double tol, int *flag, int *err);
void robotfmotion(double *time, double *state, double *dstate, double dt, double ctol, int *flag, double *errest, int *err);

// END of /nfs/medusa.dgp/ondemand10/pfal/danceMulti/sdfastObjs/robot/robot_sar.c function prototypes.

