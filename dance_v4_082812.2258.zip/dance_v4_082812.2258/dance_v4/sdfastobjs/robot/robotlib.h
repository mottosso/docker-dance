// BEGIN /nfs/medusa.dgp/ondemand10/pfal/danceMulti/sdfastObjs/robot/robotlib.c function prototypes

void roboterror(int *routine, int *errnum);
void robotprinterr(FILE *fnum);
void robotclearerr(void);
void robotseterr(int routine, int errnum);
void robotldudcomp(int n, int na, int *map, double tol, double *ld, double *sum, double *m, double *l, double *d);
void robotldubsl(int n, int na, int *map, double *l, double *b, double *x);
void robotldubsd(int n, int na, int *map, double *d, double *b, double *x);
void robotldubsu(int n, int na, int *map, double *l, double *b, double *x);
void robotldubslv(int n, int na, int *map, double *work, double *l, double *d, double *b, double *x);
void robotlduslv(int n, int na, int *map, double tol, double *work1, double *work2, double *m, double *b, double *l, double *d, double *x);
void robotqrdcomp(int nr, int nc, int nra, int nca, int *mapr, int *mapc, double *w, double *qraux, int *jpvt);
void robotqrsl(int nr, int nc, int nra, int nca, int *mapr, int *mapc, int k, double *work, double *w, double *qraux, double *b, double *x);
void robotqrbslv(int nr, int nc, int nra, int nca, int *mapr, int *mapc, double tol, double *work, int *iwork, double *w, double *qraux, int *jpvt, double *b, double *x, int *rank);
void robotqrslv(int nr, int nc, int nra, int nca, int *mapr, int *mapc, double tol, int *jpvt, double *qraux, double *work, int *iwork, double *w, double *b, double *x, int *rank);
void robotlsslv(int nr, int nc, int nra, int nca, int ndes, int *mapr, int *mapc, double tol, double *dw, double *rw, int *iw, double *w, double *b, double *x);
void robotcalcerrs(double *fval, int nfunc, int ndes, int dnorm, double *maxderr, double *maxrerr, double *derrnorm);
void robotadjvars(void (*func) (double *,double *,double *), double *vars, double *param, int nfunc, int ndes, int dnorm, int nvar, double *deltas, double step, double rerr, double tderr, double rtol, int *fcnt, double *newvars, double *newerrs);
void robotcalcjac(void (*func) (double *,double *,double *), double *vars, double *param, int nfunc, int nvar, int *lock, double delta, double *fval, double *ftmp, double *jw, int *fcnt, double *scale);
void robotroot(void (*func) (double *,double *,double *), double *vars, double *param, int nfunc, int nvar, int ndesin, int *lock, double rtol, double dtol, int maxeval, double *jw, double *dw, double *rw, int *iw, double *fret, int *fcnt, int *err);
void robotrk4m(void (*func) (double,double *,double *,double *,int *), double time, double *st, double *dst0, double *param, double step, double *nst, int neq, double *work, double *errs, double *maxerr, int *which);
void robotfinteg(void (*func) (double,double *,double *,double *,int *), double *time, double *st, double *dst, double *param, double step, int neq, double *work, double *errest, int *status);
void robotvinteg(void (*func) (double,double *,double *,double *, int *), double *time, double *st, double *dst, double *param, double dt, double *step, int neqin, double tol, double *work, int *err, int *which);
void robotdc2ang(double (*dircos)[3], double *a1, double *a2, double *a3);
void robotdc2quat(double (*dircos)[3], double *e1, double *e2, double *e3, double *e4);
void robotang2dc(double a1, double a2, double a3, double (*dircos)[3]);
void robotquat2dc(double ie1, double ie2, double ie3, double ie4, double (*dircos)[3]);
double robotvdot(double *ivec1, double *ivec2);
double robotvnorm(double *ivec);
void robotvcopy(double *ivec, double *ovec);
void robotvset(double sclr1, double sclr2, double sclr3, double *ovec);
void robotvadd(double *ivec1, double *ivec2, double *ovec);
void robotvsub(double *ivec1, double *ivec2, double *ovec);
void robotvmul(double sclr, double *ivec, double *ovec);
void robotvaxpy(double sclr, double *ivec1, double *ivec2, double *ovec);
void robotvcross(double *ivec1, double *ivec2, double *ovec);
void robotvrot(double *ivec, double *rvec, double theta, double *ovec);
void robotprerrmsg(FILE *fnum, int routine, int errnum);
void robotserialno(int *serno);

// END of /nfs/medusa.dgp/ondemand10/pfal/danceMulti/sdfastObjs/robot/robotlib.c function prototypes.

