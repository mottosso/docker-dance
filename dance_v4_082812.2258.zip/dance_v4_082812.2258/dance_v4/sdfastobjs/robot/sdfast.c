

#ifdef __cplusplus
extern "C"{
#endif


#ifdef WIN32
#ifndef DLLIMPORT
#define DLLIMPORT __declspec(dllimport)
#endif
#ifndef DLLEXPORT
#define DLLEXPORT __declspec(dllexport)
#endif

#else
#ifndef DLLIMPORT
#define DLLIMPORT
#endif
#ifndef DLLEXPORT
#define DLLEXPORT
#endif
#endif


#include <stdio.h>

#include <stdio.h>

// User supplied sdfast functions.
// Implementations
DLLEXPORT void (*sduforce)(double,  double *, double *) = 0;
DLLEXPORT void (*sdumotion)(double,  double *, double *) = 0;
DLLEXPORT void (*sduperr)(double, double *, double *) = 0;
DLLEXPORT void (*sduverr)(double, double *, double *, double *) = 0;
DLLEXPORT void (*sduaerr)(double, double *, double *, double *, double *) = 0;
DLLEXPORT void (*sduconsfrc)(double, double *, double *, double *) = 0;
DLLEXPORT void SdSetUserForce(void (*userforce)(double, double *, double *))
{
sduforce = userforce;
}
DLLEXPORT void SdSetUserMotion(void (*usermotion)(double, double *, double *))
{
sdumotion = usermotion;
}


FILE *traceFile;



#ifdef __cplusplus
}
#endif

