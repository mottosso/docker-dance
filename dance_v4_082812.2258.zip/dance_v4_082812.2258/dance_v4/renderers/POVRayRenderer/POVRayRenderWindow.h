/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

// Managing Author: Richard Park
// Email: rpark@cs.ucla.edu

#ifndef RENDERWINDOW_H
#define RENDERWINDOW_H

#include <fstream>
#include "DObject.h"
#include "DView.h"
#include "DLight.h"
#include "ViewManager.h"
#include "danceInterp.h"
#include "POVRayRenderLight.h"
#include <fltk/Window.h>
#include <fltk/TabGroup.h>
#include <fltk/Group.h>
#include <fltk/Button.h>
#include <fltk/RadioButton.h>
#include <fltk/FileInput.h>
#include <fltk/Input.h>
#include <fltk/Choice.h>
#include <fltk/Button.h>
#include <fltk/ValueInput.h>
#include <fltk/FileChooser.h>

using namespace std;

class POVRayRenderer;

using namespace fltk;

class POVRayRenderWindow  : public Group
{
	public:
		POVRayRenderWindow(POVRayRenderer* renderer, int x,int y,int w,int h,char* s);
		POVRayRenderer* getRenderer();

		void show();
		void make_window();

		Group *RenderingOptions;
		Group *m_fileOutputTab;
		Button *m_pickDirectoryButton;  
		FileInput *m_dirBaseTB;
		Input *m_baseFileTB;
		Choice *m_fileTypeChoice;
		RadioButton *m_radioToScreen;
		ValueInput *m_startingFrameNumVB;
		ValueInput *m_endingFrameNumVB;
		RadioButton *m_radioToFile;
		Group *m_lightOptionsTab;
		Choice *m_modifyLightPull;
		ValueInput *m_intensityValTB;
		Choice *m_lightStyleDrop;
		ValueInput *m_lightFromXval;
		ValueInput *m_lightFromYval;
		ValueInput *m_lightFromZval;
		ValueInput *m_lightToXval;
		ValueInput *m_lightToYval;
		ValueInput *m_lightToZval;
		ValueInput *m_coneAngleVB;
		ValueInput *m_coneAngleDeltaVB;
		ValueInput *m_beamDistributionVB;
		Group *m_cameraOptionsTab;
		ValueInput *m_perspFovVB;
		RadioButton *m_radioPinhole;
		RadioButton *m_radioDefineCamera;
		ValueInput *m_depthOfFieldFSTOPVB;
		ValueInput *m_depthOfFieldfocalLengthVB;
		ValueInput *m_depthOfFieldfocalDistanceVB;
		Group *m_imageQualityOptionsTab;
		ValueInput *m_imageXresVB;
		Choice *m_imageDepthChoice;
		ValueInput *m_imageYresVB;
		ValueInput *m_pixelAspectRatioVB;
		Button *m_doRenderButton;
		Button *m_closeButton;
		Button *m_resetButton;
		Button *m_updateLights;

		vector<POVRayRenderLight> RenderLightsVec;  
		bool enableScreenOut;
		static double computeFOV(DView* dv);
		static double computeFOV_LR(DView* curView);

	private:
  		void deactivateLightOptions();

		static void cb_m_pickDirectoryButton(Button*, void*);
		inline void cb_m_dirBaseTB_i(FileInput*, void*);
		static void cb_m_dirBaseTB(FileInput*, void*);
		static void cb_m_radioToScreen(RadioButton*, void*);  
		inline void cb_m_radioToFile_i(RadioButton*, void*);
		static void cb_m_radioToFile(RadioButton*, void*);
		static void cb_m_modifyLightPull(Choice*, void*);
		static void cb_m_lightStyleDrop(Choice*, void*);
		static void cb_m_radioPinhole(RadioButton*, void*);
		static void cb_m_radioDefineCamera(RadioButton*, void*);
		inline void cb_m_doRenderButton_i(Button*, void*);
		static void cb_m_doRenderButton(Button*, void*);
		inline void cb_m_updateLights_i(Button*, void*);
		static void cb_m_updateLights(Button*, void*);
		static void cb_m_intensityValTB(ValueInput*, void*);
		static void cb_m_lightFromXval(ValueInput*, void*);
		static void cb_m_lightFromYval(ValueInput*, void*);
		static void cb_m_lightFromZval(ValueInput*, void*);
		static void cb_m_lightToXval(ValueInput*, void*);
		static void cb_m_lightToYval(ValueInput*, void*);
		static void cb_m_lightToZval(ValueInput*, void*);
		static void cb_m_coneAngleVB(ValueInput*, void*);
		static void cb_m_coneAngleDeltaVB(ValueInput*, void*);
		static void cb_m_beamDistribution(ValueInput*, void*);
		static bool lightExistsInPull(char* nameOfLight);
		static void setLightOpsGUIbyType(POVRayRenderWindow* sWin, int lightType, int lightIndex);
		void reset();
		inline void cb_m_closeButton_i(Button*, void*);
		static void cb_m_closeButton(Button*, void*);
		inline void cb_m_resetButton_i(Button*, void*);
		static void cb_m_resetButton(Button*, void*);
		static void update(FileChooser* fc, void* data);

		FileChooser* m_fc;
		const char* fileTypes[4];
		POVRayRenderer* renderer;
};
#endif
