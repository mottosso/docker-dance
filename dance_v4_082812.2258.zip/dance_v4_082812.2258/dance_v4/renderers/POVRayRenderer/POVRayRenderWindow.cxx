/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

// Managing Author: Richard Park
// Email: rpark@cs.ucla.edu

#include "POVRayRenderWindow.h"
#include "dance.h"
#include "DObjectList.h"
#include "matrix3x3.h"
#include "vectorObj.h"
#include <cmath>			// for arc tan calculation in the FOV
#include "POVRayRenderer.h"
#include "DSimulatorManager.h"
#include <fltk/file_chooser.h>

using namespace fltk;
using namespace std;

const char* DEFAULT_BASE_PATH = "./";
const char* DEFAULT_BASE_NAME = "POV_RENDER";
const char* DEFAULT_RIB_NAME = "DANCE_RENDERING.pov";
const double DEFAULT_LIGHT_INTENSITY = 30.0;

POVRayRenderWindow::POVRayRenderWindow(POVRayRenderer* r, int xVal,int yVal,int wVal,int hVal,char* name) : Group(xVal,yVal,wVal,hVal,name)
{
	this->renderer = r;

	Group* w;
	m_fc = NULL;
	enableScreenOut = false;
  this->begin();
  { 
	Group* o = RenderingOptions = new Group(0, 0, wVal, hVal, "Rendering Options");
    w = o;
    o->labelsize(12);
    o->user_data((void*)(this));
    { 
	  TabGroup* o = new TabGroup(10, 10, 655, 305);
      { 
		Group* o = m_fileOutputTab = new Group(15, 40, 650, 275, "Output Options");
//        o->labelfont(1);
  //      o->labelsize(12);
        
		{ 
		  Button* o = m_pickDirectoryButton = new Button(600, 55, 30, 30, "...");
          o->labelsize(12);
          o->callback((Callback*)cb_m_pickDirectoryButton, this);
        }
        { 
		  FileInput* o = m_dirBaseTB = new FileInput(210, 55, 380, 30, "Render Directory:");
          o->labelsize(12);
          o->textsize(12);
          o->callback((Callback*)cb_m_dirBaseTB, this);
        }

		{ 
		  Input* o = m_baseFileTB = new Input(210, 95, 185, 25, "File Prefix:");
          o->color(215);
          o->labelsize(12);
          o->textsize(12);
        }
        { 
		  Choice* o = m_fileTypeChoice = new Choice(460, 95, 95, 25, "File Type:");
		  o->box(fltk::BORDER_BOX);
          o->labelsize(12);
          o->textsize(12);
		  o->add(".bmp");
		  o->add(".gif");
		  o->add(".jpg");
		  o->add(".tif");
		  fileTypes[0] = ".bmp";
		  fileTypes[1] = ".gif";
		  fileTypes[2] = ".jpg";
		  fileTypes[3] = ".tif";
		  o->value(3);
        }
        { 
		  Button* o = m_radioToScreen = new RadioButton(210, 205, 25, 25, "Display Rendered Image on Screen");
		  o->box(fltk::ROUND_DOWN_BOX);
          o->labelsize(12);
          o->callback((Callback*)cb_m_radioToScreen, this);
        }

	    { ValueInput* o = m_imageXresVB = new ValueInput(210, 125, 35, 25, "Image Resolution X:");
          o->labelsize(12);
          o->textsize(12);
        }

		{ ValueInput* o = m_imageYresVB = new ValueInput(260, 125, 35, 25, "Y:");
          o->labelsize(12);
          o->textsize(12);	
        }

        { Button* o = m_radioToFile = new RadioButton(210, 235, 25, 25, "Dump rendered results to specified location with no onscreen display");
		  o->box(fltk::ROUND_DOWN_BOX);
          o->labelsize(12);
          o->callback((Callback*)cb_m_radioToFile, this);
        }
        o->end();
      }
      { Group* o = m_lightOptionsTab = new Group(15, 40, 635, 275, "Lighting Options");
//        o->labelfont(1);
  //      o->labelsize(12);
        o->hide();
        { Choice* o = m_modifyLightPull = new Choice(185, 50, 200, 25, "Which Light?");
          o->callback((Callback*)cb_m_modifyLightPull,this);
        }
		{ Button* o = m_updateLights = new Button(390, 50, 150, 25, "Update Light Listing");
			o->color(50);
			o->labelsize(12);
			o->callback((Callback*)cb_m_updateLights,this);
		}
        { ValueInput* o = m_intensityValTB = new ValueInput(185, 120, 140, 25, "Intensity Value");
          o->labelsize(12);
          o->textsize(12);
		  o->callback((Callback*)cb_m_intensityValTB, this);
        }
        { Choice* o = m_lightStyleDrop = new Choice(185, 85, 140, 25, "Modify Rendering Light Type:");
		  o->box(fltk::BORDER_BOX);
          o->labelsize(12);
          o->textsize(12);
          o->callback((Callback*)cb_m_lightStyleDrop, this);
		  o->add("ambientlight");
		  o->add("distantlight");
		  o->add("pointlight");
		  o->add("spotlight");
		  o->value(0);
        }
        { ValueInput* o = m_lightFromXval = new ValueInput(185, 155, 30, 25, "From X:");
          o->labelsize(12);
          o->textsize(12);
		  o->callback((Callback*)cb_m_lightFromXval, this);
        }
        { ValueInput* o = m_lightFromYval = new ValueInput(240, 155, 30, 25, "Y: ");
          o->labelsize(12);
          o->textsize(12);
		  o->callback((Callback*)cb_m_lightFromYval, this);
        }
        { ValueInput* o = m_lightFromZval = new ValueInput(295, 155, 30, 25, "Z: ");
          o->labelsize(12);
          o->textsize(12);
		  o->callback((Callback*)cb_m_lightFromZval, this);
        }
        { ValueInput* o = m_lightToXval = new ValueInput(185, 190, 30, 25, "To X:");
          o->labelsize(12);
          o->textsize(12);
		  o->callback((Callback*)cb_m_lightToXval, this);
        }
        { ValueInput* o = m_lightToYval = new ValueInput(240, 190, 30, 25, "Y: ");
          o->labelsize(12);
          o->textsize(12);
		  o->callback((Callback*)cb_m_lightToYval, this);
        }
        { ValueInput* o = m_lightToZval = new ValueInput(295, 190, 30, 25, "Z: ");
          o->labelsize(12);
          o->textsize(12);
		  o->callback((Callback*)cb_m_lightToZval, this);
        }
        { ValueInput* o = m_coneAngleVB = new ValueInput(185, 220, 85, 25, "Radius:");
          o->labelsize(12);
          o->textsize(12);
		  o->callback((Callback*)cb_m_coneAngleVB, this);
        }
        { ValueInput* o = m_coneAngleDeltaVB = new ValueInput(185, 250, 85, 25, "Falloff:");
          o->labelsize(12);
          o->textsize(12);
		  o->callback((Callback*)cb_m_coneAngleDeltaVB, this);
        }
        { ValueInput* o = m_beamDistributionVB = new ValueInput(185, 280, 85, 25, "Tightness:");
          o->labelsize(12);
          o->textsize(12);
		  o->callback((Callback*)cb_m_beamDistribution, this);
        }
        o->end();
      }	       
      o->end();
    }
    { Button* o = m_doRenderButton = new Button(10, 325, 210, 25, " Render");
      o->tooltip("Render the scene using the given settings.");
      o->color(25);      
//      o->labelfont(1);
      o->labelcolor(0);
      o->callback((Callback*)cb_m_doRenderButton,this);
	  o->align(100 | fltk::ALIGN_INSIDE);
    }
    { Button* o = m_closeButton = new Button(235, 325, 50, 25, "Close");
      o->callback((Callback*)cb_m_closeButton, RenderingOptions);
    }
    { Button* o = m_resetButton = new Button(525, 325, 140, 25, "Set All Values to Default");
      o->color(50);
      o->labelsize(12);
      o->callback((Callback*)cb_m_resetButton,this);
    }

    o->end();

  }


  this->reset();	// initialize all the values
}




void POVRayRenderWindow::update(FileChooser* fc, void* data) {
	FileInput* temp = (FileInput* )(data);
	temp->value(fc->value());
}


void POVRayRenderWindow::cb_m_pickDirectoryButton(Button* b, void* v) {
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	// Do this to prevent the instantiation of lots of File Choosers.
	if(sWin->m_fc != NULL)
		delete sWin->m_fc;
	
	// Make a new file chooser that starts in the directory pointed to by the text box
//	sWin->m_fc = fltk::file_chooser("Pick Destination Directory", "*", sWin->m_dirBaseTB->value(), true);
//	sWin->m_fc->show();
//	sWin->m_fc->callback(update, sWin->m_dirBaseTB);		// register the callback that will update the text box
//	sWin->m_dirBaseTB->value(sWin->m_fc->directory());		// just in case, set the value
}


inline void POVRayRenderWindow::cb_m_dirBaseTB_i(FileInput*, void*) {
  // insert callback here, if necessary
}
void POVRayRenderWindow::cb_m_dirBaseTB(FileInput* o, void* v) {
  ((POVRayRenderWindow*)(o->parent()->parent()->parent()->user_data()))->cb_m_dirBaseTB_i(o,v);
}

/*inline void POVRayRenderWindow::cb_m_fileTypeChoice_i(Choice*, void*) {
  // insert callback here, if necessary....bmp? tif? jpg? gif?
}fl
void POVRayRenderWindow::cb_m_fileTypeChoice(Choice* o, void* v) {
  ((POVRayRenderWindow*)(o->parent()->parent()->parent()->user_data()))->cb_m_fileTypeChoice_i(o,v);
}
*/

void POVRayRenderWindow::cb_m_radioToScreen(RadioButton* b, void* v) 
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	sWin->m_radioToScreen->value(1);
	sWin->m_radioToFile->value(0);			
	sWin->enableScreenOut = true;
	
}

void POVRayRenderWindow::cb_m_radioToFile(RadioButton* b, void* v) {
  // insert call back here to turn off the other radio button;
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	sWin->m_radioToScreen->value(0);
	sWin->m_radioToFile->value(1);			
	sWin->enableScreenOut = false;	
}


double POVRayRenderWindow::computeFOV(DView* curView) 
{
	double fetchNearVal[2];
	double halfFOVangle = 0.0;
	curView->getNearFar(fetchNearVal, (fetchNearVal+1));		// get the near value, might as well get far too
	halfFOVangle = (180.0 / M_PI) * atan( (.50 * curView->getFrustumHeight(0)) / fetchNearVal[0]);
	return 2.0 * halfFOVangle;
}

double POVRayRenderWindow::computeFOV_LR(DView* curView) 
{
	double fetchNearVal[2];
	double halfFOVangle = 0.0;
	curView->getNearFar(fetchNearVal, (fetchNearVal+1));		// get the near value, might as well get far too
	halfFOVangle = (180.0 / M_PI) * atan( (.50 * curView->getFrustumWidth(0)) / fetchNearVal[0]);
	return 2.0 * halfFOVangle;
}

// Utility Operation
void POVRayRenderWindow::setLightOpsGUIbyType(POVRayRenderWindow* sWin, int lightType, int lightIndex)
{
// ==== Used to fetch light characteristics from DLight* ====
	float lightPos[4];

	switch(lightType)
	{
	case TYPE_AMBIENT:
		// Clear everything except light type and intensity
		sWin->m_lightFromXval->deactivate();
		sWin->m_lightFromXval->value(0);
		sWin->m_lightFromYval->deactivate();
		sWin->m_lightFromYval->value(0);
		sWin->m_lightFromZval->deactivate();
		sWin->m_lightFromZval->value(0);
		sWin->m_lightToXval->deactivate();
		sWin->m_lightToXval->value(0);
		sWin->m_lightToYval->deactivate();
		sWin->m_lightToYval->value(0);
		sWin->m_lightToZval->deactivate();
		sWin->m_lightToZval->value(0);
		sWin->m_coneAngleVB->deactivate();
		sWin->m_coneAngleVB->value(0);
		sWin->m_coneAngleDeltaVB->deactivate();
		sWin->m_coneAngleDeltaVB->value(0);
		sWin->m_beamDistributionVB->deactivate();
		sWin->m_beamDistributionVB->value(0);
		break;
	case TYPE_DISTANT:
		// Light: "distantlight" has [intensity, lightcolor, from, to]. Activate GUI for these parameters
		sWin->RenderLightsVec[lightIndex].getLight()->getPosition(lightPos);
		sWin->m_lightFromXval->activate();
		sWin->m_lightFromYval->activate();
		sWin->m_lightFromZval->activate();
		sWin->m_lightToXval->activate();
		sWin->m_lightToYval->activate();
		sWin->m_lightToZval->activate();
		sWin->m_lightFromXval->value(lightPos[0]);
		sWin->m_lightFromYval->value(lightPos[1]);
		sWin->m_lightFromZval->value(lightPos[2]);			
		sWin->m_lightToXval->value(sWin->RenderLightsVec[lightIndex].getXto());	
		sWin->m_lightToYval->value(sWin->RenderLightsVec[lightIndex].getYto());
		sWin->m_lightToZval->value(sWin->RenderLightsVec[lightIndex].getZto());	

		// Clear everything else in the GUI
		sWin->m_coneAngleVB->deactivate();
		sWin->m_coneAngleVB->value(0);
		sWin->m_coneAngleDeltaVB->deactivate();
		sWin->m_coneAngleDeltaVB->value(0);
		sWin->m_beamDistributionVB->deactivate();
		sWin->m_beamDistributionVB->value(0);
		break;
	case TYPE_POINT:
		// Light: "pointlight" has [intensity, lightcolor, from]. Activate GUI for these paramters
		sWin->RenderLightsVec[lightIndex].getLight()->getPosition(lightPos);
		sWin->m_lightFromXval->activate();
		sWin->m_lightFromYval->activate();
		sWin->m_lightFromZval->activate();		
		sWin->m_lightFromXval->value(lightPos[0]);
		sWin->m_lightFromYval->value(lightPos[1]);
		sWin->m_lightFromZval->value(lightPos[2]);					

		// Clear everything else in the GUI
		sWin->m_lightToXval->deactivate();
		sWin->m_lightToXval->value(0);
		sWin->m_lightToYval->deactivate();
		sWin->m_lightToYval->value(0);
		sWin->m_lightToZval->deactivate();
		sWin->m_lightToZval->value(0);
		sWin->m_coneAngleVB->deactivate();
		sWin->m_coneAngleVB->value(0);
		sWin->m_coneAngleDeltaVB->deactivate();
		sWin->m_coneAngleDeltaVB->value(0);
		sWin->m_beamDistributionVB->deactivate();
		sWin->m_beamDistributionVB->value(0);
		break;
	case TYPE_SPOT:
		// Light: "spotlight" has [intensity, lightcolor, from, to, coneangle, coneangledelta, beam distribution].
		sWin->RenderLightsVec[lightIndex].getLight()->getPosition(lightPos);
		double spotLightQualities[3];
		sWin->RenderLightsVec[lightIndex].getSpotlightQualities(spotLightQualities);
		sWin->m_lightFromXval->activate();
		sWin->m_lightFromYval->activate();
		sWin->m_lightFromZval->activate();
		sWin->m_lightToXval->activate();
		sWin->m_lightToYval->activate();
		sWin->m_lightToZval->activate();
		sWin->m_coneAngleVB->activate();
		sWin->m_coneAngleDeltaVB->activate();
		sWin->m_beamDistributionVB->activate();		
		sWin->m_lightFromXval->value(lightPos[0]);
		sWin->m_lightFromYval->value(lightPos[1]);
		sWin->m_lightFromZval->value(lightPos[2]);			
		sWin->m_lightToXval->value(sWin->RenderLightsVec[lightIndex].getXto());					
		sWin->m_lightToYval->value(sWin->RenderLightsVec[lightIndex].getYto());
		sWin->m_lightToZval->value(sWin->RenderLightsVec[lightIndex].getZto());		
		sWin->m_coneAngleVB->value(spotLightQualities[0]);
		sWin->m_coneAngleDeltaVB->value(spotLightQualities[1]);
		sWin->m_beamDistributionVB->value(spotLightQualities[2]);
		break;
	default:
		break;
	}
}

bool POVRayRenderWindow::lightExistsInPull(char* nameOfLight)
{
	// search for the nameOfLight name in the list of lights
	return false;
}

void POVRayRenderWindow::cb_m_modifyLightPull(Choice* o, void* v) 
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;					// Cast the context of the void* pointer
	int lightIndex = sWin->m_modifyLightPull->value();		// which light is being modified by top most pull down?

	// Enable the modification of the light type and set it with current value
	sWin->m_lightStyleDrop->activate();
	sWin->m_lightStyleDrop->value(sWin->RenderLightsVec[lightIndex].getType());

	// Enable the modification of the light intensity and set it with the current value
	sWin->m_intensityValTB->activate();
	sWin->m_intensityValTB->value(sWin->RenderLightsVec[lightIndex].getIntensity());

	// Set the rest of the light options GUI (from? to? coneangle? coneangledelta? beam distribution?)
	sWin->setLightOpsGUIbyType(sWin, sWin->RenderLightsVec[lightIndex].getType(), lightIndex);
} 

void POVRayRenderWindow::cb_m_lightStyleDrop(Choice* o, void* v) 
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;					// Cast the context of the void* pointer
	int lightIndex = sWin->m_modifyLightPull->value();		// which light is being modified by top most pull down?

	sWin->RenderLightsVec[lightIndex].setType(sWin->m_lightStyleDrop->value()); // update data structure for light type

	// Set the rest of the light options GUI (from? to? coneangle? coneangledelta? beam distribution?)
	sWin->setLightOpsGUIbyType(sWin, sWin->RenderLightsVec[lightIndex].getType(), lightIndex);
}


void POVRayRenderWindow::cb_m_radioPinhole(RadioButton* o, void* v) 
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;					// Cast the context of the void* pointer	
	sWin->m_radioPinhole->set();
	sWin->m_radioDefineCamera->value(0);
	sWin->m_perspFovVB->deactivate();
	sWin->m_depthOfFieldFSTOPVB->deactivate();
	sWin->m_depthOfFieldfocalLengthVB->deactivate();
	sWin->m_depthOfFieldfocalDistanceVB->deactivate();	
}

void POVRayRenderWindow::cb_m_radioDefineCamera(RadioButton* o, void* v) 
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;					// Cast the context of the void* pointer
	sWin->m_radioDefineCamera->set();
	sWin->m_radioPinhole->value(0);
	sWin->m_perspFovVB->activate();
	sWin->m_depthOfFieldFSTOPVB->activate();
	sWin->m_depthOfFieldfocalLengthVB->activate();
	sWin->m_depthOfFieldfocalDistanceVB->activate();	
}

void POVRayRenderWindow::cb_m_intensityValTB(ValueInput* o, void* v) 
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	int currentLightIndex = sWin->m_modifyLightPull->value();
	sWin->RenderLightsVec[currentLightIndex].setIntensity(sWin->m_intensityValTB->value());
}

void POVRayRenderWindow::cb_m_lightFromXval(ValueInput* o, void* v)
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	int currentLightIndex = sWin->m_modifyLightPull->value();
	float currentPosition[4];

	// get the current position of the light
	sWin->RenderLightsVec[currentLightIndex].getLight()->getPosition(currentPosition);

	// modify the position's x-value	
	currentPosition[0] = (float) sWin->m_lightFromXval->value();

	// save the new position
	sWin->RenderLightsVec[currentLightIndex].getLight()->setPosition(currentPosition);

	// update the dance world
	dance::AllViews->postRedisplay();
}

void POVRayRenderWindow::cb_m_lightFromYval(ValueInput* o, void* v)
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	int currentLightIndex = sWin->m_modifyLightPull->value();
	float currentPosition[4];

	// get the current position of the light
	sWin->RenderLightsVec[currentLightIndex].getLight()->getPosition(currentPosition);

	// modify the position's x-value
	currentPosition[1] = (float) sWin->m_lightFromYval->value();

	// save the new position
	sWin->RenderLightsVec[currentLightIndex].getLight()->setPosition(currentPosition);

	// update the dance world
	dance::AllViews->postRedisplay();
}

void POVRayRenderWindow::cb_m_lightFromZval(ValueInput* o, void* v)
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	int currentLightIndex = sWin->m_modifyLightPull->value();
	float currentPosition[4];

	// get the current position of the light
	sWin->RenderLightsVec[currentLightIndex].getLight()->getPosition(currentPosition);

	// modify the position's x-value
	currentPosition[2] = (float) sWin->m_lightFromZval->value();

	// save the new position
	sWin->RenderLightsVec[currentLightIndex].getLight()->setPosition(currentPosition);

	// update the dance world
	dance::AllViews->postRedisplay();
}

void POVRayRenderWindow::cb_m_lightToXval(ValueInput* o, void* v)
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	int currentLightIndex = sWin->m_modifyLightPull->value();
	
	// set the x-coordinate of where the light is pointing to, where appropriate
	sWin->RenderLightsVec[currentLightIndex].setXto(sWin->m_lightToXval->value());  

	// update the dance world
	//dance::AllViews->postRedisplay();
}

void POVRayRenderWindow::cb_m_lightToYval(ValueInput* o, void* v)
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	int currentLightIndex = sWin->m_modifyLightPull->value();
	
	// set the y-coordinate of where the light is pointing to, where appropriate
	sWin->RenderLightsVec[currentLightIndex].setYto(sWin->m_lightToYval->value());

	// update the dance world
	//dance::AllViews->postRedisplay();
}

void POVRayRenderWindow::cb_m_lightToZval(ValueInput* o, void* v)
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	int currentLightIndex = sWin->m_modifyLightPull->value();
	
	// set the z-coordinate of where the light is pointing to, where appropriate
	sWin->RenderLightsVec[currentLightIndex].setZto(sWin->m_lightToZval->value());

	// update the dance world
	//dance::AllViews->postRedisplay();
}


void POVRayRenderWindow::cb_m_coneAngleVB(ValueInput* i, void* v)
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	int currentLightIndex = sWin->m_modifyLightPull->value();
	
	double spotlightQualities[3];
	sWin->RenderLightsVec[currentLightIndex].getSpotlightQualities(spotlightQualities);

	// spotlightQualities[0] represents the cone angle
	// spotlightQualities[1] represents the cone angle delta
	// spotlightQualities[2] represents the beam distribution
	spotlightQualities[0] = sWin->m_coneAngleVB->value();

	sWin->RenderLightsVec[currentLightIndex].setSpotlightQualities(spotlightQualities);
}

void POVRayRenderWindow::cb_m_coneAngleDeltaVB(ValueInput* i, void* v)
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	int currentLightIndex = sWin->m_modifyLightPull->value();
	
	double spotlightQualities[3];
	sWin->RenderLightsVec[currentLightIndex].getSpotlightQualities(spotlightQualities);

	// spotlightQualities[0] represents the cone angle
	// spotlightQualities[1] represents the cone angle delta
	// spotlightQualities[2] represents the beam distribution
	spotlightQualities[1] = sWin->m_coneAngleDeltaVB->value();

	sWin->RenderLightsVec[currentLightIndex].setSpotlightQualities(spotlightQualities);
}

void POVRayRenderWindow::cb_m_beamDistribution(ValueInput* i, void* v)
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) v;
	int currentLightIndex = sWin->m_modifyLightPull->value();
	
	double spotlightQualities[3];
	sWin->RenderLightsVec[currentLightIndex].getSpotlightQualities(spotlightQualities);

	// spotlightQualities[0] represents the cone angle
	// spotlightQualities[1] represents the cone angle delta
	// spotlightQualities[2] represents the beam distribution
	spotlightQualities[2] = sWin->m_beamDistributionVB->value();

	sWin->RenderLightsVec[currentLightIndex].setSpotlightQualities(spotlightQualities);
}

void POVRayRenderWindow::cb_m_doRenderButton(Button* o, void* v) 
{
   ((POVRayRenderWindow*)(o->parent()->user_data()))->cb_m_doRenderButton_i(o,v);
}

void POVRayRenderWindow::cb_m_doRenderButton_i(Button* b, void* p)
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow*) p;

	DView* curView = dance::AllViews->getViewFocus();

	sWin->getRenderer()->render(sWin->m_dirBaseTB->value(), sWin->m_baseFileTB->value(), curView->getFrameNumber(), curView->getWidth(), curView->getHeight());

	/*
	//ofstream povfile;
	povfile.open("POV_RENDERING.pov");
	povfile << "#include \"colors.inc\"\n";
	povfile << "#include \"textures.inc\"\n";
	povfile << "#include \"shapes.inc\"\n";
	povfile << "#include \"metals.inc\"\n";
	povfile << "#include \"glass.inc\"\n";

	// get the current view 
	DView* curView = dance::AllViews->getViewFocus();

	// background color
	float backgroundColor[4];
	curView->getBackgroundColor(backgroundColor);
	povfile << "background { <" << backgroundColor[0] << ", " << backgroundColor[1] << ", " << backgroundColor[2] << "> }\n";

	//int size = dance::AllGeometry->size(); // get the # of objects 
	int numSystems = dance::AllSystems->size(); // get the # of systems


	// note: OpenGL stores the matrices that are column major. So the getCameraTransformation() function
	// ......will return a matrix that is ready for premultiplication (Point*Matrix). Renderman uses the
	// ......premultiplication standard for transforming points. 
	
	// transformation for the camera
	float camMatrix[4][4];
	curView->getCameraTransformation(camMatrix);
	// extract Euler angles in XYZ order form the camera's transformation matrix (radians)
	Matrix3x3 mat3;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			mat3[i][j] = camMatrix[i][j];
	
	VectorObj vec;
		mat3.matToEuler(Matrix3x3::XYZ, vec);
	VectorObj xVec(1.0, 0.0, 0.0);
	VectorObj yVec(0.0, 1.0, 0.0);
	VectorObj zVec(0.0, 0.0, 1.0);
	
	Matrix3x3 xrot;
		xrot.setRotation(xVec, -vec.x());
	Matrix3x3 yrot;
		yrot.setRotation(yVec, -vec.y());
	Matrix3x3 zrot;
		zrot.setRotation(zVec, vec.z());
	Matrix3x3 result;
		result = zrot * yrot * xrot;
	
	VectorObj resultVec;
	result.matToEuler(Matrix3x3::XYZ, resultVec);

	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			camMatrix[i][j] = (float) result[i][j];

	povfile << "\ncamera {";
	povfile << "\n\tperspective";
	povfile << "\n\tangle " << computeFOV_LR(curView);
	povfile << "\n\tlocation <0, 0, " << camMatrix[3][2] << ">";
	povfile << "\n\tdirection <0,0,1>";
	povfile << "\n\tup <0,1,0>";
	povfile << "\n\tright 1.33*x";
	povfile << "\n\ttranslate <" << -camMatrix[3][0] << ", " << -camMatrix[3][1] << ", 0>";
	povfile << "\n\trotate <" << resultVec.x()*(180/M_PI) << ", " << resultVec.y()*(180/M_PI)
			<< ", " << resultVec.z()*(180/M_PI) << ">";	
	
	povfile << "\n}\n";

	
// ===== Generate global parameters ======
	float lightPos[4];
	float lightAmbient[4];
	float lightDiffuse[4];
	float lightSpecularity[4];
	

	// output individual light information
	for (int i = 0; i < dance::AllLights->size(); i++) 
	{
		DLight* light = (DLight*) dance::AllLights->get(i);		
	
		povfile << "\nlight_source {<";
		light->getPosition(lightPos);
		light->getAmbient(lightAmbient);
		light->getDiffuse(lightDiffuse);
		light->getSpecular(lightSpecularity);			

		povfile << "\t" << lightPos[0] << ", " << lightPos[1] << ", " << -lightPos[2] << "> color rgb <" << lightDiffuse[0]
				<< ", " << lightDiffuse[1] << ", " << lightDiffuse[2] << ">";

		
		switch(RenderLightsVec[i].getType())
		{
		case TYPE_AMBIENT:
			povfile << "\nshadowless"; 
			break;
		case TYPE_DISTANT:
			povfile << "\nparallel";
			povfile << "\npoint_at <" << RenderLightsVec[i].getXto() << ", " << RenderLightsVec[i].getYto() << ", " 
					<< RenderLightsVec[i].getZto() << ">";
			break;
		case TYPE_POINT:			
			break;
		case TYPE_SPOT:
			povfile << "\nspotlight";
			povfile << "\npoint_at <" << RenderLightsVec[i].getXto() << ", " << RenderLightsVec[i].getYto() << ", " 
					<< RenderLightsVec[i].getZto() << ">";
			povfile << "\nradius " << m_coneAngleVB->value();
			povfile << "\nfalloff " << m_coneAngleDeltaVB->value();
			povfile << "\ntightness " << m_beamDistributionVB->value();

			break;
		default:
			break;
		}

		povfile << "\n}";
		
	}

	double transMatrix[4][4];		
	double geomMatrix[4][4];
	
	povfile << "\n\n";

	vector<unsigned int> processed;		// temporary fix: maintan a list of objects that we've rendered (ArticulatedObjects are different right now)


	// ***** This first for loop will render "skeletons" for us. ************************************************
	danceInterp::OutputMessage("\nnumSystems: %i", numSystems);
	for (int i = 0; i < numSystems; i++) // loop through each system
	{	
		DObject* o = dance::AllSystems->get(i);
		ArticulatedObject* ao = (ArticulatedObject*) o;
		int numLinks = ao->getNumLinks();



		danceInterp::OutputMessage("\n\tnumLinks: %i", numLinks);

		for (int j = 0; j < numLinks; j++)			// for each link, find the IFS and transform it
		{
			Link* link = ao->getLink(j);
			
			DGeometry* geom = link->GetGeometry();
			
			//link->getParentJoint()->getPosition(jposition);
			//this->drawJoint(jposition);

			if (geom == NULL)
				continue;

			processed.push_back(geom->getID());			// remember that we rendered this item
			
			IndexedFaceSet* ifs = (IndexedFaceSet*) geom;
			Material* ifs_mat = ifs->getMaterials();
			//ifs_mat->mAmbientColor[1];
					
			link->getTransMat(transMatrix);					
			link->GetGeometry()->getTransMatrix(geomMatrix);
 
			povfile << "\nmesh { \n";

		// cast to an IndexedFaceSet
		// the IndexedFaceSet stores an array of faces (IndexedFace)
		// and normals. Look at the IndexedFaceSet.h code.		
		//IndexedFaceSet* ifs = (IndexedFaceSet*) dance::AllGeometry->get(i);
			IndexedFace* faces = ifs->getFaces();					

			// loop through the vertices
			for (int v = 0; v < ifs->getNumFaces(); v++)
			{	
				// ========= REMOVE ME FOR POV-RAY REMOVAL =========				
				povfile << "\tsmooth_triangle {";	

				// ========== Output all the Vertices for each Indexed Face ==============			
				for (int i = 0; i < faces[v].numVertices; i++)
				{
					Vector point;
					VecCopy(point, ifs->m_Vertices[faces[v].vertexIndex[i]]);																						
					transformPoint_mat(point, geomMatrix);
					transformPoint_mat(point, transMatrix);					
					

					// ========= REMOVE ME FOR POV-RAY REMOVAL =========				
					Vector pointNorm;
					VecCopy(pointNorm, ifs->m_Normals[faces[v].normalIndex[i]]);
					
					transformPoint_mat(pointNorm, geomMatrix);
					transformPoint_mat(pointNorm, transMatrix);										
				
					povfile << "<" << point[0] << ", " << point[1] << ", " << -point[2] << "> ";
					povfile << "<" << pointNorm[0] << ", " << pointNorm[1] << ", " << -pointNorm[2] << "> ";

					// ========= REMOVE ME FOR POV-RAY REMOVAL =========								
					if(i < 2)
						povfile << ",";
					
				}
				
				//povfile << "\n\t\ttexture { pigment {color Red}}";
				// ========= REMOVE ME FOR POV-RAY REMOVAL =========						
				povfile << "}\n";	// close the triangle
			}

			povfile << "\ntexture {pigment {color rgb <" << ifs_mat->mDiffuseColor[0]+ifs_mat->mAmbientColor[0] << ", " << ifs_mat->mDiffuseColor[1]+ifs_mat->mAmbientColor[1] << ", " << ifs_mat->mDiffuseColor[2]+ifs_mat->mAmbientColor[2] << ">} finish {Phong_Dull}}";
			povfile << "\n}";		// close the mesh
		}
	}


	// ***** This second for loop will render standard IFS objects for us. ************************************************
	int numGeoms = dance::AllGeometry->size();			

	bool texturesOn = false;						// just a little something to temporarily fix the issue of a model w/ incomplete tex maps	

	for (int i = 0; i < numGeoms; i++)				// For every geometric object in the system...
	{
		DGeometry* geom = (DGeometry*) dance::AllGeometry->get(i);
		// make sure that we haven't already rendered this object
		bool found = false;
		vector<unsigned int>::iterator iter;
		
		for (iter = processed.begin(); iter != processed.end(); iter++)			// Have we rendered this geometry object already?
		{
			if ((*iter) == geom->getID())
			{
				found = true;
				break;
			}
		}
		if (!found)																// if we haven't rendered it yet....
		{
			IndexedFaceSet* ifs = (IndexedFaceSet*) geom;
			Material* ifs_mat = ifs->getMaterials();

			//for (int z = 0; z < ifs->te

			//ifs_mat->mAmbientColor[1];


			// ========== 0. Define all the textures ===============
			if (ifs->getNumMaterials() > 0)
			{
				Material *mlist = ifs->getMaterials();

				for (int matCount = 0; matCount < ifs->getNumMaterials(); matCount++)
				{
					povfile << "\n\t#declare DANCE" << mlist[matCount].m_name << "=";
					povfile << "\n\ttexture{pigment {color rgb <" << mlist[matCount].mDiffuseColor[0] << ", " << mlist[matCount].mDiffuseColor[1] << ", " 
						<< mlist[matCount].mDiffuseColor[2] << "> transmit 0}}";

					if(mlist[matCount].tex != NULL)
					{
						if (mlist[matCount].tex->getTexFileName() != NULL)
						{
							povfile << "\n\ttexture{pigment {image_map{sys \"" << mlist[matCount].tex->getTexFileName();
							povfile << "\" interpolate 2 transmit all 0 filter all 0.8} ";
							povfile << "} finish {phong 0 phong_size 20 ambient rgb <" << mlist[matCount].mAmbientColor[0] << ", ";
							povfile	<< mlist[matCount].mAmbientColor[1] << ", ";
							povfile	<< mlist[matCount].mAmbientColor[2] << "> reflection{0 metallic}}}";
						}
					}

				}
			}
					
			ifs->getTransMatrix(transMatrix);					
 
			povfile << "\nmesh2 {";	// BEGIN MESH2

			IndexedFace* faces = ifs->getFaces();					

			// =========== 1. Output all the vertices ===============
			povfile << "\n\tvertex_vectors {";
			povfile << "\n\t\t" << ifs->m_NumVertices << ",";			

			for (int a = 0; a < ifs->m_NumVertices - 1; a++) 
			{
				Vector point;
				VecCopy(point, ifs->m_Vertices[a]);																						
				transformPoint_mat(point, transMatrix);					
				povfile << "\n\t<" << point[0] << ", " << point[1] << ", " << -point[2]<< ">, ";
			}

			// this is to account for the fact the last triple shouldn't have a comma after it
			Vector point;
			VecCopy(point, ifs->m_Vertices[a]);
			transformPoint_mat(point, transMatrix);					
			povfile << "\n\t<" << point[0] << ", " << point[1] << ", " << -point[2]<< "> ";

			povfile << "\n\t}";


			// =========== 2. Output all the normal vectors, if there exist normal vectors ===========
			if (ifs->m_Normals != NULL && ifs->m_NumNormals > 0) 
			{
				povfile << "\n\tnormal_vectors {";
				povfile << "\n\t\t" << ifs->m_NumNormals << ",";
				
				for (int b = 0; b < ifs->m_NumNormals - 1; b++)
				{
					Vector pointNorm;
					VecCopy(pointNorm, ifs->m_Normals[b]);
					povfile << "\n\t<" << pointNorm[0] << ", " << pointNorm[1] << ", " << -pointNorm[2] << ">, ";
				}

				// this is to account for the fact the last triple shouldn't have a comma after it
				Vector pointNorm;
				VecCopy(pointNorm, ifs->m_Normals[b]);
				povfile << "\n\t<" << pointNorm[0] << ", " << pointNorm[1] << ", " << -pointNorm[2] << "> ";				

				povfile << "\n\t}";
			}


			// =========== 3. Output all the UV vectors, if they exist ============
			if (ifs->getNumTexcoords() > 0)
			{
				povfile << "\n\tuv_vectors {";
				povfile << "\n\t" << ifs->getNumTexcoords() << ", ";

				for (int g = 1; g < ifs->getNumTexcoords(); g++)
					povfile << "\n\t<" << ifs->getTexcoords()[2*g] << ", " << ifs->getTexcoords()[(2*g) + 1] << ">, ";

				povfile << "\n\t<" << ifs->getTexcoords()[2*g] << ", " << ifs->getTexcoords()[(2*g) + 1] << ">";

				povfile << "\n\t}";	// END uv_vectors
			}

			
			// ======= Generate the texture styles =========
			if (ifs->getNumMaterials() > 0)
			{
				Material *mlist = ifs->getMaterials();
				povfile << "\ntexture_list {";
				povfile << "\n" << ifs->getNumMaterials() << ", ";

				for (int mCount = 0; mCount < ifs->getNumMaterials(); mCount++) 				
					povfile << "\ntexture{DANCE" << mlist[mCount].m_name << "}";
					
				povfile << "}";
			}
		

			// =========== 4. Output all the face_indices ============
			// **** THERE ARE TWO WAYS.....non-grouped and grouped..........
			povfile << "\n\tface_indices {";
			povfile << "\n\t\t" << ifs->m_NumFaces << ",";

			faces = ifs->getFaces();
			if (ifs->getFaceGroups() == NULL)
			{				
				for (int c = 0; c < ifs->m_NumFaces-1; c++)
				{
					povfile << "\n\t<";

					for (int d = 0; d < faces[c].numVertices - 1; d++) 								
						povfile << faces[c].vertexIndex[d] << ", ";

					povfile << faces[c].vertexIndex[d] << "> ";		// to account for the last one not having a comma after it				
				}

				povfile << "\n\t<";
				for (int d = 0; d < faces[c].numVertices - 1; d++) 								
					povfile << faces[c].vertexIndex[d] << ", ";

				povfile << faces[c].vertexIndex[d];		// to account for the last one not having a comma after it				
				povfile << ">";
				
			}
			else // Do it group style
			{
				FaceGroup *fg = ifs->getFaceGroups();

				// For each face group, output each face
				while (fg) 
				{
					// for each "face/triangle" in the group...
					if (fg->numtriangles == 0)
					{
						fg = fg->next;
						continue;
					}

					for (int e = 0; e < fg->numtriangles - 1; e++)
					{						
						povfile << "\n\t<";						
						for (int vertNum = 0; vertNum < faces[fg->triangles[e]].numVertices - 1; vertNum++)
							povfile << faces[fg->triangles[e]].vertexIndex[vertNum] << ", ";
						povfile << faces[fg->triangles[e]].vertexIndex[vertNum] << ">, ";
						
						if (ifs->getNumMaterials() > 0) 
							povfile << fg->material << ", ";							
					}

					povfile << "\n\t<";
					for (int d = 0; d < faces[fg->triangles[e]].numVertices - 1; d++) 								
						povfile << faces[fg->triangles[e]].vertexIndex[d] << ", ";
					povfile << faces[fg->triangles[e]].vertexIndex[d];		// to account for the last one not having a comma after it				
					povfile << ">, ";
					
					if(ifs->getNumMaterials() > 0)
						povfile << fg->material;

					fg = fg->next;
				}	
			}
			povfile << "\n\t}";		// END face_indices

			// =========== 5. Output all the UV for the faces ===========
			if (ifs->getFaceGroups() != NULL && ifs->getNumTexcoords() != 0) 
			{
				FaceGroup *fguv = ifs->getFaceGroups();
				
				povfile << "\n\tuv_indices {";
				povfile << "\n\t" << ifs->getNumFaces() << ", ";
				IndexedFace* faces = ifs->getFaces();

				// For each face group, output each uv_ind
				while (fguv) 
				{	
					if (fguv->numtriangles == 0)
					{
						fguv = fguv->next;
						continue;
					}

					for (int triInd = 0; triInd < fguv->numtriangles - 1; triInd++)
					{						
						povfile << "\n\t<";						
						for (int vertNum = 0; vertNum < faces[fguv->triangles[triInd]].numVertices - 1; vertNum++)													
								povfile << faces[fguv->triangles[triInd]].texCoordIndex[vertNum] - 1 << ", ";						
						
						povfile << faces[fguv->triangles[triInd]].texCoordIndex[vertNum] - 1  << ">, ";						
					}

					povfile << "\n\t<";						
					for (int vertNum = 0; vertNum < faces[fguv->triangles[triInd]].numVertices - 1; vertNum++)						
						povfile << faces[fguv->triangles[triInd]].texCoordIndex[vertNum] - 1 << ", ";					
					
					povfile << faces[fguv->triangles[triInd]].texCoordIndex[vertNum] - 1 << "> ";
					
					fguv = fguv->next;
					
				}

				povfile << "\n}";					// END uv_indices
			}			

			povfile << "\n\tuv_mapping";
			povfile << "\n\ttexture {pigment {color rgb <.9, .9, .9>} finish {Phong_Dull}}";		
			povfile << "\n}";	// END MESH2
		}
	}

	int args = 1;
	char* argv[1];
	argv[0] = "povray";
	// dump the actuators
	for (int x = 0; x < dance::AllActuators->size(); x++)
	{
		DObject* object = (DObject*) dance::AllActuators->get(x);
		object->render(args,argv, povfile);
	}

	// dump the simulators
	for (int x = 0; x < dance::AllSimulators->size(); x++)
	{
		DObject* object = (DObject*) dance::AllSimulators->get(x);
		object->render(args,argv, povfile);
	}

	// dump the modifiers
	for (int x = 0; x < dance::AllModifiers->size(); x++)
	{
		DObject* object = (DObject*) dance::AllModifiers->get(x);
		object->render(args,argv, povfile);
	}


	// DEBUG
//	povfile << "\nplane { // the floor";
//	povfile << "\ny, -1  // along the x-z plane (y is the normal vector)";
//	povfile << "\npigment { checker color Red color Blue } // checkered pattern";
//	povfile << "\n}";


	strcpy(outfilename, "+o");
	strcat(outfilename, m_baseFileTB->value());

	switch(m_fileTypeChoice->value())
	{
	case 0:
		strcat(outfilename, ".bmp");
		break;
	case 1:
		strcat(outfilename, ".gif");
		break;
	case 2:
		strcat(outfilename, ".jpg");
		break;
	case 3:
		strcat(outfilename, ".tif");
		break;
	default:
		strcat(outfilename, ".tif");
		break;
	}

	char* iwidth = new char[10];
	char* iheight = new char[10];
	itoa((int)m_imageXresVB->value(), iwidth, 10);
	itoa((int)m_imageYresVB->value(), iheight, 10);

	strcpy(filesizes, "+W");
	if(iwidth == NULL)
		strcat(filesizes, "640");
	else
		strcat(filesizes, iwidth);
	strcat(filesizes, " ");
	strcat(filesizes, "+H");
	if(iheight == NULL)
		strcat(filesizes, "480");
	else
		strcat(filesizes, iheight);


	strcpy(command, this->renderer->getBinaryLocation().c_str());
	strcat(command, "pvengine /render POV_RENDERING.pov ");	
	strcat(command, outfilename);
	strcat(command, " ");
	strcat(command, filesizes);
    strcat(command, " ");

	if(!enableScreenOut)
		strcat(command, "/exit");	

	danceInterp::OutputMessage(command);

	povfile.close();		// close the rendering file
	int ret = system(command);
	// check return value of povray command
	// ...
	// ...
*/
}

inline void POVRayRenderWindow::cb_m_closeButton_i(Button* b, void* d) {
  // insert callback here to close the POVRayRenderWindow;  
}
void POVRayRenderWindow::cb_m_closeButton(Button* o, void* v) {
  ((POVRayRenderWindow*)(o->parent()->user_data()))->cb_m_closeButton_i(o,v);
  Window* sWin = (Window*) v;
  sWin->hide();
}

inline void POVRayRenderWindow::cb_m_resetButton_i(Button*, void*) 
{
	POVRayRenderWindow::reset();		// reset all values to defaults
}
void POVRayRenderWindow::cb_m_resetButton(Button* o, void* v) 
{
  ((POVRayRenderWindow*)(o->parent()->user_data()))->cb_m_resetButton_i(o,v);
}

inline void POVRayRenderWindow::cb_m_updateLights_i(Button* b, void* v) 
{	

}
void POVRayRenderWindow::cb_m_updateLights(Button* o, void* v) 
{
	POVRayRenderWindow* sWin = (POVRayRenderWindow *) v;

  	// for each light, check if it exists. If it doesn't, add it. 
	for (int i = 0; i < dance::AllLights->size(); i++) 
	{
		DLight* light = (DLight*) dance::AllLights->get(i);				

		// linear search through existing lights
		for(unsigned int i = 0; i < sWin->RenderLightsVec.size(); i++)
		{
			// if the light's name matches
			if(strcmp(light->getName(), sWin->RenderLightsVec[i].getLight()->getName()) != 0)
			{
				// create new light, and add it to the drop down list. 
				danceInterp::OutputMessage("\nLight Name is: %s", light->getName());
				sWin->m_modifyLightPull->add(light->getName());
				POVRayRenderLight v(TYPE_POINT, 30, light);				// set light to be point, as default.		
				sWin->RenderLightsVec.push_back(v);
			}
		}			
	}	
}

void POVRayRenderWindow::show()
{
	RenderingOptions->show();	
}



void POVRayRenderWindow::reset() {	
	RenderLightsVec.clear();
	m_dirBaseTB->value(DEFAULT_BASE_PATH);		// set the base path for the file
	m_baseFileTB->value(DEFAULT_BASE_NAME);		// set the base file name
	m_fileTypeChoice->value(3);					// default to .tiff file format
	m_baseFileTB->deactivate();
	m_fileTypeChoice->deactivate();
	m_radioToFile->value(1);		// send outputs to file
	m_radioToScreen->value(0);		// and not to screen
	enableScreenOut = false;		// flag to recognize this	
	m_modifyLightPull->clear();
	m_imageXresVB->value(640);
	m_imageYresVB->value(480);

	// Initialize the lights drop down:
	RenderLightsVec.clear();
	for (int i = 0; i < dance::AllLights->size(); i++) 
	{
		DLight* light = (DLight*) dance::AllLights->get(i);		
		danceInterp::OutputMessage("\nLight Name is: %s", light->getName());
		m_modifyLightPull->add(light->getName());
		POVRayRenderLight v(TYPE_POINT, 30, light);				// set light to be point, as default.		
		RenderLightsVec.push_back(v);
	}
	this->deactivateLightOptions();				// modify the GUI to enable only the relevant fields

}

void POVRayRenderWindow::deactivateLightOptions() 
{
	m_lightStyleDrop->deactivate();
	m_intensityValTB->deactivate();
	m_lightFromXval->deactivate();
	m_lightFromYval->deactivate();
	m_lightFromZval->deactivate();
	m_lightToXval->deactivate();
	m_lightToYval->deactivate();
	m_lightToZval->deactivate();
	m_coneAngleVB->deactivate();
	m_coneAngleDeltaVB->deactivate();
	m_beamDistributionVB->deactivate();
}


void POVRayRenderWindow::make_window() {
}



// purpose: converts an integer to a string
// parameters: takes a number, and a char* to write to
// returns: none, but char* is changed to be the char format of "number"
/*void itoa(int number,char* num){
  int i=0;
  int num_cp=number;

  if(number==0){
    strcpy(num,"0");
    return;
  }
  while(num_cp!=0){
    i++;
    num_cp/=10;
  }
  num[i]='\0';

  while(i>0){
    num[i-1]=(number%10)+48;
    number/=10;
    i--;
  }
  return;

}*/

POVRayRenderer* POVRayRenderWindow::getRenderer()
{
	return this->renderer;
}




