/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

// Managing Author: Richard Park
// Email: rpark@cs.ucla.edu

#include "POVRayRenderLight.h"

POVRayRenderLight::POVRayRenderLight(int typeIn, double intensityIn, DLight* dlightIn, 
							   double coneAngleIn, double coneAngleDeltaIn, double beamDistIn)
{
	if (typeIn < 0 || typeIn > 3)	// if invalid light type, default it to ambient...produce warning
	{
		danceInterp::OutputMessage("\n\t** Warning: invalid light type: %i. This light will now be a default ambient light.", typeIn);
		TYPE = TYPE_POINT;					
	}
	else
		TYPE = typeIn;

	if (intensityIn < 0) 
	{
		danceInterp::OutputMessage("\n\t** Warning: invalid light intensity %d (must be positive). Defaulting to zero.", intensityIn); 
		intensity = 0;
	}
	else
		intensity = intensityIn;

	dl = dlightIn;

	if (coneAngleIn < 0)
	{
		danceInterp::OutputMessage("\n\t** Warning: invalid cone angle %d (must be positive). Defaulting to 90 degrees.", coneAngleIn);
		coneAngle = 90;
	}
	else
		coneAngle = coneAngleIn;

	if (coneAngleDeltaIn < 0)
	{
		danceInterp::OutputMessage("\n\t** Warning: invalid cone angle delta %d (must be positive). Defaulting to 5 degrees.", coneAngleDeltaIn);
		coneAngleDelta = 5;
	}
	else
		coneAngleDelta = coneAngleDeltaIn;

	if (beamDistIn < 0)
	{
		danceInterp::OutputMessage("\n\t** Warning: invalid beam distribution %d (must be positive). Defaulting to 1", beamDistIn);
		beamDistribution = 2;
	}
	else
		beamDistribution = beamDistIn;

	xTo = yTo = zTo = 0;
}

void POVRayRenderLight::setIntensity(double intensityIn)
{
	if (intensityIn < 0) 
	{
		danceInterp::OutputMessage("\n\t** Warning: invalid light intensity %d (must be positive). Defaulting to zero.", intensityIn); 
		intensity = 0;
	}
	else
		intensity = intensityIn;	
}

double POVRayRenderLight::getIntensity()
{
	return intensity;
}

void POVRayRenderLight::setType(int typeIn)
{
	if (typeIn < 0 || typeIn > 3)	// if invalid light type, default it to ambient...produce warning
	{
		danceInterp::OutputMessage("\n\t** Warning: invalid light type: %i. This light will now be a default ambient light.", typeIn);
		TYPE = TYPE_POINT;					
	}
	else
		TYPE = typeIn;
}

int POVRayRenderLight::getType()
{
	return TYPE;
}

void POVRayRenderLight::setLight(DLight* dlIn)
{
	dl = dl;
}

DLight* POVRayRenderLight::getLight()
{
	return dl;
}

void POVRayRenderLight::setSpotlightQualities(double put[3]) 
{
	if (put[0] < 0)
	{
		danceInterp::OutputMessage("\n\t** Warning: invalid cone angle %d (must be positive). Defaulting to 90 degrees.", put[0]);
		coneAngle = 90;
	}
	else
		coneAngle = put[0];

	if (put[1] < 0)
	{
		danceInterp::OutputMessage("\n\t** Warning: invalid cone angle delta %d (must be positive). Defaulting to 5 degrees.", put[1]);
		coneAngleDelta = 5;
	}
	else
		coneAngleDelta = put[1];

	if (put[2] < 0)
	{
		danceInterp::OutputMessage("\n\t** Warning: invalid beam distribution %d (must be positive). Defaulting to 1", put[2]);
		beamDistribution = 2;
	}
	else
		beamDistribution = put[2];
}

void POVRayRenderLight::getSpotlightQualities(double fetch[3])
{
	fetch[0] = coneAngle;
	fetch[1] = coneAngleDelta;
	fetch[2] = beamDistribution;
}

void POVRayRenderLight::setXto(double val)
{
	xTo = val;
}

void POVRayRenderLight::setYto(double val)
{
	yTo = val;
}
	
void POVRayRenderLight::setZto(double val)
{
	zTo = val;
}

double POVRayRenderLight::getXto()
{
	return xTo;
}

double POVRayRenderLight::getYto()
{
	return yTo;
}

double POVRayRenderLight::getZto()
{
	return zTo;
}
