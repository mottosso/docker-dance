/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

// Managing Author: Richard Park
// Email: rpark@cs.ucla.edu


#ifndef RENDERLIGHT_H
#define RENDERLIGHT_H

#include <vector>
#include "DView.h"
#include "DLight.h"
#include "danceInterp.h"

const int TYPE_AMBIENT = 0;
const int TYPE_DISTANT = 1;
const int TYPE_POINT = 2;
const int TYPE_SPOT = 3;

class POVRayRenderLight {
public:
	POVRayRenderLight(int TYPE, double intensity, DLight* dlightPtr, 
	  	     double coneAngle = 0, double coneAngleDelta = 0, double beamDistribution = 0);	// 2nd row for spotlight only
	
	void setIntensity(double intensityValue);
	double getIntensity();
	void setType(int TYPE_OF_LIGHT);
	int getType();
	void setLight(DLight* dl);
	DLight* getLight();
	void setSpotlightQualities(double put[3]);
	void getSpotlightQualities(double fetch[3]);
	double getXto();
	double getYto();
	double getZto();
	void setXto(double val);
	void setYto(double val);
	void setZto(double val);
private:	
	int TYPE;
	double intensity;
	DLight* dl;
	double coneAngle;
	double coneAngleDelta;
	double beamDistribution;
	double xTo;
	double yTo;
	double zTo;
};

#endif
