/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "BitmapRenderer.h"

#include <sstream>
#include <fstream>
#include <fltk/gl.h>
#include <iomanip>
#include <Magick++.h>
#include "danceInterp.h"
#include "BitmapRendererWindow.h"
#include "DConnection.h"

using namespace std;
using namespace Magick;

PlugIn* BitmapRenderer::create(int argc, char **argv)
{
	BitmapRenderer* r = new BitmapRenderer();

	return r;
}


PlugIn* Proxy()
{
	return new BitmapRenderer(); 
}

BitmapRenderer::BitmapRenderer()
{
	windowRenderer = NULL;

	m_imageExtensionsAttr = this->createStringAttribute("extensions", "png", true, "Images", 10);
	std::vector<std::string> extensions;
	extensions.push_back("bmp");
	extensions.push_back("gif");
	extensions.push_back("jpg");
	extensions.push_back("png");
	extensions.push_back("tga");
	m_imageExtensionsAttr->setValidValues(extensions);

	
	#ifdef WIN32
	this->setImageViewerCommand("C:\\WINDOWS\\system32\\rundll32.exe C:\\WINDOWS\\System32\\shimgvw.dll,ImageView_Fullscreen %1");
	#else
	this->setImageViewerCommand("display %1");
	#endif

	this->setRunImageViewer(true);
}

BitmapRenderer::~BitmapRenderer()
{
	if (windowRenderer != NULL)
		delete windowRenderer;
}

int BitmapRenderer::commandPlugIn(int argc, char** argv)
{
	int ret = DRenderer::commandPlugIn(argc, argv);
	if (ret == DANCE_ERROR || ret == DANCE_OK)
		return ret;

	if (strcmp(argv[0], "image_type") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("dance.renderer(\"\"%s\", \"image_type\", <bmp|gif|png|tga|jpg>)", this->getName());
			return DANCE_ERROR;
		}
		m_imageExtensionsAttr->setValue(argv[1]);
		danceInterp::OutputMessage("Images rendered from the view will now be saved to image type '%s'.", argv[1]);
		return DANCE_OK;
	}

	return DANCE_CONTINUE;
}


bool BitmapRenderer::render(string directory, string filename, int frameNum, int width, int height)
{
	// assemble the proper filename:  directory/<filename without extension><frameNum>.<extension from filename or bmp>
	stringstream filenamestream;

	if (directory.length() > 0)
	{
		filenamestream << directory;
		filenamestream << "/";
	}

	const char *ext, *begin;
	begin=filename.c_str();
	ext=strrchr(begin, '.');
	if (ext!=NULL) 
		while (begin!=ext) 
			filenamestream << *begin++;
	else
		filenamestream << filename;

	filenamestream << setw(6) << setfill('0') << frameNum;


	if (ext) {
		while (*ext) 
			filenamestream << *ext++;
	} else
		filenamestream << "." << m_imageExtensionsAttr->getValue();


	unsigned char *pixels = new unsigned char [3 * width * height], *paux;
    if(	pixels == NULL )
    {
		danceInterp::OutputMessage("Cannot allocate enough memory for screen dump to PPM.\n");
		return false;
    }

	glReadBuffer(GL_BACK);

	paux=pixels;
	for	(int y = height - 1; y >= 0; y--) {
		glReadPixels(0, y, width, 1, GL_RGB, GL_UNSIGNED_BYTE, (GLvoid *) paux);
		paux+=3*width;
	}

	string tmp;
	try {
		Image image(width, height, "RGB", CharPixel, pixels );
		// Write the image to a file

		filenamestream >> tmp;
		image.write(tmp.c_str());
     }
	catch( Exception &error_ )
    {
	  danceInterp::OutputMessage("Error writing the image: %s", error_.what());
    } 

	this->setLastRenderedFileName((char*) tmp.c_str());

    delete [] pixels;

	return true;
}

void BitmapRenderer::save(int mode, std::ofstream& file)
{
	//char buff[1024];

	if (mode == 0)
	{
		file << "dance.instance(\"BitmapRenderer\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 0)
	{
	}

	DRenderer::save(mode, file);
}

fltk::Widget* BitmapRenderer::getInterface()
{
	if (windowRenderer == NULL)
	{
		windowRenderer = new BitmapRendererWindow(this, 10, 10, 330, 400, this->getName());
	}

	return windowRenderer;
}
