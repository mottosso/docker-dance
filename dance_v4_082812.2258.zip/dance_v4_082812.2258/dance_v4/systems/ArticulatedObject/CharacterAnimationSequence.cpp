/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "CharacterAnimationSequence.h"
#include <string>
#include "danceInterp.h"
#include "ParserBVH.h"
#include "ArticulatedObject.h"
#include "Joint.h"
#include "Link.h"
#include "KeyFrame.h"
#include "Quaternion.h"
#include "matrix3x3.h"
#include <assert.h>

using namespace std;

CharacterAnimationSequence::CharacterAnimationSequence(ArticulatedObject* ao) : AnimationSequence()
{
	setArticulatedObject(ao);
}

CharacterAnimationSequence::CharacterAnimationSequence() : AnimationSequence()
{
	setArticulatedObject(NULL);
}

void CharacterAnimationSequence::setArticulatedObject(ArticulatedObject* ao)
{
	m_ao = ao;
}

ArticulatedObject* CharacterAnimationSequence::getArticulatedObject()
{
	return m_ao;
}

//added new load of direct keyframe dump MN Nov.,2005
int CharacterAnimationSequence::load(char *fname, int N1, int N2)
{
	std::string str = fname;
	unsigned int pos = str.find_last_of(".bvh");
	unsigned int pos2 = str.find_last_of(".dkf");
	int ret = 0;
	unsigned int length = str.length();
	if (pos != string::npos && pos == length - 1)
	{
		ifstream file(fname, ios::in);
		if (!file.good())
		{
			danceInterp::OutputMessage("Cannot open file %s.", fname);
			return DANCE_ERROR;
		}
		ret = this->loadBVH(file, N1, N2);
		file.close();
	}
	else if (pos2 != string::npos && pos2 == length - 1)
	{
		FILE * fp = fopen(fname, "r");
		if (!fp)
		{
			danceInterp::OutputMessage("Cannot open file %s.", fname);
			return DANCE_ERROR;
		}
		ret = this->loadDKF(fp);
		fclose(fp);
	}
	else
	{
		FILE *fp;
		if ((fp = fopen(fname,"r")) == NULL)
		{
			danceInterp::OutputMessage("Cannot open file %s", fname);
			return -1;
		}
		ret = AnimationSequence::load(fp);
	    fclose(fp);
	}
		
	return ret;
}

//nd no change, the second branch in the code below is problematic
//Added support for direct dumps of keyframe data.  To use this,
//add the file extension .dkf (DANCE KeyFrame) MN Nov.,05
int CharacterAnimationSequence::save(char *fname)
{
	string str = fname;
	unsigned int pos = str.find_last_of(".bvh");
	unsigned int pos2 = str.find_last_of(".dkf");
	int ret = 0;
	unsigned int length = str.length();
	if (pos != string::npos && pos == length - 1)
	{
		ofstream file(fname, ios::out);
		if (!file.good())
		{
			danceInterp::OutputMessage("Cannot open file %s.", fname);
			return DANCE_ERROR;
		}
		KeyFrame* startkf = this->getKeyFrameByIndex(0);
		KeyFrame* endkf = this->getKeyFrameByIndex(this->getNumKeyFrames() - 1);
		double startTime = 0;
		if (startkf != NULL)
			startTime = startkf->getTime();
		double endTime = 0;
		if (endkf != NULL)
			endTime = endkf->getTime();

		ret = this->saveBVHFrameTime(file, (endTime - startTime) / this->getNumKeyFrames());
		file.close();
	}
	else if (pos2 != string::npos && pos2 == length - 1)
	{
		FILE *fp = fopen(fname, "w");

		if (!fp)
		{
			danceInterp::OutputMessage("Cannot open .dkf file %s.", fname);
			return DANCE_ERROR;
		}
		ret = this->saveDKF(fp);
		fclose(fp);
	}
	else
	{
		FILE *fp;
		if ((fp = fopen(fname,"r")) == NULL)
		{
			danceInterp::OutputMessage("Cannot open file %s", fname);
			return -1;
		}
		ret = AnimationSequence::save(fp);
	    fclose(fp);
	}
		
	return ret;
}

int CharacterAnimationSequence::loadBVH(std::ifstream& file, int N1, int N2)
{
	Character* c = ParserBVH::parse("tempbvhcharacter", file, N1, N2);
	if (c == NULL)
		return -1;
	
	// verify that the character loaded from the BVH file matches the articulated object
	int cNumJoints = c->getNumJoints();
	int aNumJoints = m_ao->getNumJoints();

	if (cNumJoints != aNumJoints)
	{
		danceInterp::OutputMessage("Joints do not match. BVH file contains %d joints, %s has %d joints.", cNumJoints, m_ao->getName(), aNumJoints);
		return -1;
	}

	if( 0 == cNumJoints )
	{
		danceInterp::OutputMessage("ERROR: CharacterAnimationSequence::loadBVH(), no joints found in BVH.");
		return -1;		
	}

	// compare the DOF of the joints
	CharJoint* cCurJoint = c->getRoot();
	Joint* aCurJoint = m_ao->getJoint(0);

	bool ok = compareJointHierarchyRecurse(cCurJoint, aCurJoint);
	if (ok)
	{
		// copy the data from the character to the articulated object
		this->clear();
		int numFrames = c->getNumFrames();
		int index = 0;
		for (int x = 0; x < numFrames; x++)
		{
			KeyFrame* kf = new KeyFrame(m_ao->getStateSize());
			kf->setTime(c->getRoot()->getFrameTime() * x);
			loadBVHJointHierarchyRecurse(cCurJoint, aCurJoint, kf, index, x);
			this->insertKeyFrame(kf);
			index = 0;
		}
	}

	this->m_ao->updateStateConfig();

	delete c;

	return 0;
}

void CharacterAnimationSequence::loadBVHJointHierarchyRecurse(CharJoint* charJoint, Joint* joint, KeyFrame* kf, int& index, int frameNum)
{
	// if charjoint channels match the art obj joint's DOF, perform direct translation of data
	int channels[6];
	charJoint->getChannels(channels);
	double axes[3][3];
	joint->getAxis(axes);
	double frames[6];
	charJoint->getFrames(frameNum, frames);

	if (joint->getJointType() == J_FREE)
	{
		// copy the XYZ translation
		if (channels[0] == CharJoint::XPOSITION)
		{
			if (channels[1] == CharJoint::YPOSITION)
			{ // XYZ
				kf->setParam(0, frames[0]);
				kf->setParam(1, frames[1]);
				kf->setParam(2, frames[2]);
			}
			else 
			{ // XZY
				kf->setParam(0, frames[0]);
				kf->setParam(1, frames[2]);
				kf->setParam(2, frames[1]);
			}
		}
		else if (channels[0] == CharJoint::YPOSITION)
		{
			if (channels[1] == CharJoint::XPOSITION)
			{ // YXZ
				kf->setParam(0, frames[1]);
				kf->setParam(1, frames[0]);
				kf->setParam(2, frames[2]);
			}
			else 
			{ // YZX
				kf->setParam(0, frames[2]);
				kf->setParam(1, frames[0]);
				kf->setParam(2, frames[1]);
			}
		}
		else // ZPOSITION
		{
			if (channels[1] == CharJoint::XPOSITION)
			{ // ZXY
				kf->setParam(0, frames[1]);
				kf->setParam(1, frames[2]);
				kf->setParam(2, frames[0]);
			}
			else 
			{ // ZYX
				kf->setParam(0, frames[2]);
				kf->setParam(1, frames[1]);
				kf->setParam(2, frames[0]);
			}
		}

		// switch around the parameters to match the rotational axes
		double oldVals[3] = {kf->getParam(0), kf->getParam(1), kf->getParam(2) };
		switch (joint->determineRotationOrder())
		{
			case Matrix3x3::XYZ:
				break;
			case Matrix3x3::XZY:
				kf->setParam(0, oldVals[0]);
				kf->setParam(1, oldVals[2]);
				kf->setParam(2, oldVals[1]);
				break;
			case Matrix3x3::YXZ:
				kf->setParam(0, oldVals[1]);
				kf->setParam(1, oldVals[0]);
				kf->setParam(2, oldVals[2]);
				break;
			case Matrix3x3::YZX:
				kf->setParam(0, oldVals[1]);
				kf->setParam(1, oldVals[2]);
				kf->setParam(2, oldVals[0]);
				break;
			case Matrix3x3::ZXY:
				kf->setParam(0, oldVals[2]);
				kf->setParam(1, oldVals[0]);
				kf->setParam(2, oldVals[1]);
				break;
			case Matrix3x3::ZYX:
				kf->setParam(0, oldVals[2]);
				kf->setParam(1, oldVals[1]);
				kf->setParam(2, oldVals[0]);
				break;
		}
	
		// set the quaternion
		Quaternion* quat = charJoint->getQuaternion(frameNum);
		kf->setParam(3, quat->data()[0]);
		kf->setParam(4, quat->data()[1]);
		kf->setParam(5, quat->data()[2]);
		kf->setParam(6, quat->data()[3]);
		
		index += 7;
	}
	else if (joint->getJointType() == J_GIMBAL)
	{
		// assume the same rotation order
		kf->setParam(index, frames[0] * M_PI / 180.0);
		kf->setParam(index + 1, frames[1] * M_PI / 180.0);
		kf->setParam(index + 2, frames[2] * M_PI / 180.0);
	
		index += 3;
		
	}
	else if (joint->getJointType() == J_UNIVERSAL)
	{
		// assume the same rotation order
		kf->setParam(index, frames[0] * M_PI / 180.0);
		kf->setParam(index + 1, frames[1]  * M_PI / 180.0);

		index += 2;
	}
	else if (joint->getJointType() == J_PIN)
	{
		// assume the same rotation order
		kf->setParam(index, frames[0] * M_PI / 180.0);

		index += 1;
	}
	else if (joint->getJointType() == J_PLANAR)
	{
		double posVals[3];
		if (channels[0] == CharJoint::XPOSITION)
		{
			if (channels[1] == CharJoint::YPOSITION)
			{ // XYZ
				posVals[0] = frames[0];
				posVals[1] = frames[1];
				posVals[2] = frames[2];
			}
			else 
			{ // XZY
				posVals[0] = frames[0];
				posVals[1] = frames[2];
				posVals[2] = frames[1];
			}
		}
		else if (channels[0] == CharJoint::YPOSITION)
		{
			if (channels[1] == CharJoint::XPOSITION)
			{ // YXZ
				posVals[0] = frames[1];
				posVals[1] = frames[0];
				posVals[2] = frames[2];		}
			else 
			{ // YZX
				posVals[0] = frames[2];
				posVals[1] = frames[0];
				posVals[2] = frames[1];
			}
		}
		else // ZPOSITION
		{
			if (channels[1] == CharJoint::XPOSITION)
			{ // ZXY
				posVals[0] = frames[1];
				posVals[1] = frames[2];
				posVals[2] = frames[0];
			}
			else 
			{ // ZYX
				posVals[0] = frames[2];
				posVals[1] = frames[1];
				posVals[2] = frames[0];
			}
		}

		switch (joint->determineRotationOrder())
		{
			case Matrix3x3::XYZ:
				kf->setParam(0, posVals[0]);
				kf->setParam(1, posVals[1]);
				break;
			case Matrix3x3::XZY:
				kf->setParam(0, posVals[0]);
				kf->setParam(1, posVals[2]);
				break;
			case Matrix3x3::YXZ:
				kf->setParam(0, posVals[1]);
				kf->setParam(1, posVals[0]);
				break;
			case Matrix3x3::YZX:
				kf->setParam(0, posVals[1]);
				kf->setParam(1, posVals[2]);
				break;
			case Matrix3x3::ZXY:
				kf->setParam(0, posVals[2]);
				kf->setParam(1, posVals[0]);
				break;
			case Matrix3x3::ZYX:
				kf->setParam(0, posVals[2]);
				kf->setParam(1, posVals[1]);
				break;
		}
	

		// set the rotational component
		kf->setParam(2, frames[3] * M_PI / 180.0);

		index += 3;

	}
	else if (joint->getJointType() == J_BALL)
	{
		//added support MN Nov.,05
		//This is copied from the FREE joint above
		//If it works for one, it should work for the other....

		// set the quaternion
		Quaternion* quat = charJoint->getQuaternion(frameNum);
		kf->setParam(index, quat->data()[0]);
		kf->setParam(index+1, quat->data()[1]);
		kf->setParam(index+2, quat->data()[2]);
		kf->setParam(index+3, quat->data()[3]);
		
		index += 4;

	}
	else if (joint->getJointType() == J_SLIDER)
	{
		// not handled
	}
	else if (joint->getJointType() == J_WELD)
	{
		// not handled
	}
	
	// joints match in number of DOF, recurse children
	int cNumChildren = charJoint->getNumChildren();
	Link* link = joint->getOutboardLink();
	for (int x = 0; x < cNumChildren; x++)
	{
		CharJoint* cChild = charJoint->getChild(x);
		Joint* aChild = link->getChildLinks()[x]->getParentJoint();
		loadBVHJointHierarchyRecurse(cChild, aChild, kf, index, frameNum);
	}
}

//loads the dance keyframe file
//File format:
//frameTime: <time between frames>
//frame 0 <data for each state variable in the key>
//frame 1 <data for each state variable in the key>
//...
int CharacterAnimationSequence::loadDKF(FILE* fp)
{

	//should validate the file, but we will simply assume it is correct for the current skeleton

	const int MAX_DKF_LINE = 1000;
	char line[MAX_DKF_LINE];
	fgets(line,MAX_DKF_LINE,fp);
	double frameTime;
	if(1 != sscanf(line, "frameTime: %lf", &frameTime) )
	{
		danceInterp::OutputMessage("Invalid dkf file.  Stopping load.");
		return DANCE_ERROR;
	}

	fgets(line,MAX_DKF_LINE,fp);
	int frame = 0;
	//read the file
	while(feof(fp) == 0)
	{
		KeyFrame* kf = new KeyFrame(m_ao->getStateSize());
		kf->setTime(frameTime * frame);
		int index = 0;

		char seps[] = " ";
		char * token;
		double dof;
		//eat the first two tokens
		token = strtok(line, seps);
		token = strtok(NULL, seps);
		token = strtok(NULL, seps);

		while(token && index < m_ao->getStateSize())
		{
			if(1!= sscanf(token, "%lf", &dof))
			{
				danceInterp::OutputMessage("Invalid dkf file data string.  Stopping load.");
				return DANCE_ERROR;
			}

			kf->setParam(index, dof);

			index++;
			token = strtok(NULL, seps);

		}


		if(m_ao->getStateSize() != index)
		{
			danceInterp::OutputMessage("Invalid dkf file: not enough data.  Stopping load.");
			return DANCE_ERROR;
		}



		this->insertKeyFrame(kf);

		index = 0;

		frame++;
		fgets(line,MAX_DKF_LINE,fp);
	}




	this->m_ao->updateStateConfig();

	return 0;
}



bool CharacterAnimationSequence::compareJointHierarchyRecurse(CharJoint* charJoint, Joint* joint)
{
	if( !charJoint || !joint )
	{
		danceInterp::OutputMessage( "CharacterAnimationSequence::compareJointHierarchyRecurse() failed due to null argument." );
	}
	int cNumDOF = charJoint->getNumChannels();
	// is the first joint a planar joint (planer joints get written into .bvh with 3 translational components,
	// even though they only have 2 translational components
	if (joint->getJointType() == J_PLANAR && joint->getInboardLink() == NULL)
	{
		cNumDOF--;
	}
	int aNumDOF = joint->getNumDof();
	if (cNumDOF != aNumDOF)
	{
		danceInterp::OutputMessage("Number of DOF do not match (BVH file contains %s which has %d DOF, while %s contains joint %s which has %d DOF.", charJoint->getName(), cNumDOF, m_ao->getName(), joint->getName(), aNumDOF);
		return false;
	}

	// joints match in number of DOF, recurse children
	int cNumChildren = charJoint->getNumChildren();
	Link* link = joint->getOutboardLink();
	int aNumChildren = link->getNumChildLinks();
	if (cNumChildren != aNumChildren)
	{
		danceInterp::OutputMessage("Number of children does not match (BVH file contains %s which has %d children, while %s contains joint %s which has %d children.", charJoint->getName(), cNumChildren, m_ao->getName(), joint->getName(), aNumChildren);
		return false;
	}

	for (int x = 0; x < cNumChildren; x++)
	{
		CharJoint* cChild = charJoint->getChild(x);
		Joint* aChild = link->getChildLinks()[x]->getParentJoint();
		bool ok = compareJointHierarchyRecurse(cChild, aChild);
		if (!ok)
			return false;
	}

	return true;
}


int CharacterAnimationSequence::saveBVH(std::ofstream& file, double fps)
{
	return saveBVHFrameTime(file, 1.0 / fps);
}

int CharacterAnimationSequence::saveBVHFrameTime(std::ofstream& file, double frameTime)
{
	// convert the articulated object into a character, 
	// then use the save functionality of the character

	Character c;
	Joint** joints = this->m_ao->getJoints();

	if( joints[0] == NULL )
	{
		danceInterp::OutputMessage("ERROR: CharacterAnimationSequence::saveBVHFrameTime: Object %s"
									" does not have joints!", this->m_ao->getName()) ;
		return 0 ;
	}
	CharJoint* charRoot = new CharJoint(joints[0]->getName());
	charRoot->setParent(NULL);
	charRoot->setCharacter(&c);
	c.setRoot(charRoot);

	convertToCharacterRecurse(&c, NULL, charRoot, NULL, joints[0]);

	// now copy the frames
	// create new frames to uniformly interpolate between keyframes
	double frameStep = frameTime;
	double endTime = this->getEndTime();
	double curTime = 0.0;
	int numJoints = this->m_ao->getNumJoints();
	double* params = new double[this->m_ao->getStateSize()];
	
	while (curTime <= (endTime + 10e-6))
	{
		this->interpolate(curTime, params);
		int count = 0;
		for (int j = 0; j < numJoints; j++)
		{
			Joint* joint = joints[j];
			CharJoint* charJoint = c.getJointByIndex(j);
			charJoint->setFrameTime(frameTime);
			double frame[6];

			int jointType = joint->getJointType();
			switch (jointType)
			{
			case J_FREE:
				{
				Quaternion q;
				q.fromVector(&params[count + 3]);
				Matrix3x3 matrix;
				q.toMatrix(matrix);
				VectorObj vec;
				int order = joint->determineRotationOrder();
				matrix.matToEuler(order, vec, false);
				switch (order)
				{
					case Matrix3x3::XYZ:
						frame[0] = params[count];
						frame[1] = params[count + 1];
						frame[2] = params[count + 2];
						frame[3] = vec[0] * 180.0 / M_PI;
						frame[4] = vec[1] * 180.0 / M_PI;
						frame[5] = vec[2] * 180.0 / M_PI;
						break;
					case Matrix3x3::XZY:
						frame[0] = params[count];
						frame[1] = params[count + 2];
						frame[2] = params[count + 1];
						frame[3] = vec[0] * 180.0 / M_PI;
						frame[4] = vec[2] * 180.0 / M_PI;
						frame[5] = vec[1] * 180.0 / M_PI;
						break;
					case Matrix3x3::YXZ:
						frame[0] = params[count + 1];
						frame[1] = params[count];
						frame[2] = params[count + 2];
						frame[3] = vec[1] * 180.0 / M_PI;
						frame[4] = vec[0] * 180.0 / M_PI;
						frame[5] = vec[2] * 180.0 / M_PI;
						break;
					case Matrix3x3::YZX:
						frame[0] = params[count + 2];
						frame[1] = params[count];
						frame[2] = params[count + 1];
						frame[3] = vec[1] * 180.0 / M_PI;
						frame[4] = vec[2] * 180.0 / M_PI;
						frame[5] = vec[0] * 180.0 / M_PI;
						break;
					case Matrix3x3::ZXY:
						frame[0] = params[count + 1];
						frame[1] = params[count + 2];
						frame[2] = params[count];
						frame[3] = vec[2] * 180.0 / M_PI;
						frame[4] = vec[0] * 180.0 / M_PI;
						frame[5] = vec[1] * 180.0 / M_PI;
						break;
					case Matrix3x3::ZYX:
						frame[0] = params[count + 2];
						frame[1] = params[count + 1];
						frame[2] = params[count];
						frame[3] = vec[2] * 180.0 / M_PI;
						frame[4] = vec[1] * 180.0 / M_PI;
						frame[5] = vec[0] * 180.0 / M_PI;
						break;
				}
				count += 7;
				}
				break;
			case J_PLANAR:
				frame[0] = params[count];
				frame[1] = params[count + 1];
				frame[2] = params[count + 2] * 180.0 / M_PI;;
				count += 3;
				break;
			case J_PIN:
				frame[0] = params[count]  * 180.0 / M_PI;;
				count += 1;
				break;
			case J_UNIVERSAL:
				frame[0] = params[count]  * 180.0 / M_PI;;
				frame[1] = params[count + 1]  * 180.0 / M_PI;;
				count += 2;
				break;
			case J_BALL:
				{
				//Added for ball joint support Nov.05 MN
				//I believe Ball joints will always be XYZ, but I've left this more
				//flexible representation.
				Quaternion q;
				q.fromVector(&params[count]);
				Matrix3x3 matrix;
				q.toMatrix(matrix);
				VectorObj vec;
				int order = joint->determineRotationOrder();
				matrix.matToEuler(order, vec, false);
				switch (order)
				{
					case Matrix3x3::XYZ:
						frame[0] = vec[0] * 180.0 / M_PI;
						frame[1] = vec[1] * 180.0 / M_PI;
						frame[2] = vec[2] * 180.0 / M_PI;
						break;
					case Matrix3x3::XZY:
						frame[0] = vec[0] * 180.0 / M_PI;
						frame[1] = vec[2] * 180.0 / M_PI;
						frame[2] = vec[1] * 180.0 / M_PI;
						break;
					case Matrix3x3::YXZ:
						frame[0] = vec[1] * 180.0 / M_PI;
						frame[1] = vec[0] * 180.0 / M_PI;
						frame[2] = vec[2] * 180.0 / M_PI;
						break;
					case Matrix3x3::YZX:
						frame[0] = vec[1] * 180.0 / M_PI;
						frame[1] = vec[2] * 180.0 / M_PI;
						frame[2] = vec[0] * 180.0 / M_PI;
						break;
					case Matrix3x3::ZXY:
						frame[0] = vec[2] * 180.0 / M_PI;
						frame[1] = vec[0] * 180.0 / M_PI;
						frame[2] = vec[1] * 180.0 / M_PI;
						break;
					case Matrix3x3::ZYX:
						frame[0] = vec[2] * 180.0 / M_PI;
						frame[1] = vec[1] * 180.0 / M_PI;
						frame[2] = vec[0] * 180.0 / M_PI;
						break;
				}
				
				count += 4;
				}
				break;

			case J_GIMBAL:
				frame[0] = params[count] * 180.0 / M_PI;;
				frame[1] = params[count + 1] * 180.0 / M_PI;;
				frame[2] = params[count + 2] * 180.0 / M_PI;;
				count += 3;
				break;
			case J_WELD:
				break;
			default:
				break;
			}

			charJoint->addFrame(frame);

		}
		curTime += frameStep;
	}

	c.saveBVH(file);
	delete [] params;

	return 1;
}

int CharacterAnimationSequence::saveDKF(FILE * fp, double fps)
{
	// convert the articulated object into a character, 
	// then use the save functionality of the character

//	Character c;

//	CharJoint* charRoot = new CharJoint(joints[0]->getName());
//	charRoot->setParent(NULL);
//	charRoot->setCharacter(&c);
//	c.setRoot(charRoot);

//	Vector pos = {0.0, 0.0, 0.0};
//	convertToCharacterRecurse(&c, NULL, charRoot, NULL, joints[0]);

	// now copy the frames
	// create new frames to uniformly interpolate between keyframes
	double frameStep = 1.0 / fps;
	double endTime = this->getEndTime();
	double curTime = 0.0;
	int index = 0;
	double* params = new double[this->m_ao->getStateSize()];
	fprintf(fp, "frameTime: %lf\n", frameStep);
	while (curTime <= endTime)
	{
		this->interpolate(curTime, params);

		//add frame count
		fprintf(fp, "frame %d ", index);
		for(int i = 0; i<m_ao->getStateSize(); i++)
		{
			fprintf(fp, "%lf ", params[i]);
		}
		fprintf(fp, "\n");

		index++;

		curTime += frameStep;
	}

	delete [] params;

	return 1;
}


void CharacterAnimationSequence::convertToCharacterRecurse(Character* c, CharJoint* charParent, CharJoint* charJoint, Joint* parent, Joint* joint)
{
	// set the offset from the parent joint
	Vector inboardToJoint;
	joint->getInbToJoint(inboardToJoint);
	Vector bodyToJoint;
	joint->getBodyToJoint(bodyToJoint);

	int channels[6];
	int order = joint->determineRotationOrder();

	// set the channels
	if (joint->getJointType() == J_FREE)
	{
		channels[0] = CharJoint::XPOSITION;
		channels[1] = CharJoint::YPOSITION;
		channels[2] = CharJoint::ZPOSITION;
		switch (order)
		{
			case Matrix3x3::XYZ:
				channels[3] = CharJoint::XROTATION;
				channels[4] = CharJoint::YROTATION;
				channels[5] = CharJoint::ZROTATION;
				break;
			case Matrix3x3::XZY:
				channels[3] = CharJoint::XROTATION;
				channels[4] = CharJoint::ZROTATION;
				channels[5] = CharJoint::YROTATION;
				break;
			case Matrix3x3::YXZ:
				channels[3] = CharJoint::YROTATION;
				channels[4] = CharJoint::XROTATION;
				channels[5] = CharJoint::ZROTATION;
				break;
			case Matrix3x3::YZX:
				channels[3] = CharJoint::YROTATION;
				channels[4] = CharJoint::ZROTATION;
				channels[5] = CharJoint::XROTATION;
				break;
			case Matrix3x3::ZXY:
				channels[3] = CharJoint::ZROTATION;
				channels[4] = CharJoint::XROTATION;
				channels[5] = CharJoint::YROTATION;
				break;
			case Matrix3x3::ZYX:
				channels[3] = CharJoint::ZROTATION;
				channels[4] = CharJoint::YROTATION;
				channels[5] = CharJoint::XROTATION;
				break;
			default:
				break;
		}
		charJoint->setChannels(6, channels);
	}
	else if (joint->getJointType() == J_GIMBAL)
	{
		switch (order)
		{
			case Matrix3x3::XYZ:
				channels[0] = CharJoint::XROTATION;
				channels[1] = CharJoint::YROTATION;
				channels[2] = CharJoint::ZROTATION;
				break;
			case Matrix3x3::XZY:
				channels[0] = CharJoint::XROTATION;
				channels[1] = CharJoint::ZROTATION;
				channels[2] = CharJoint::YROTATION;
				break;
			case Matrix3x3::YXZ:
				channels[0] = CharJoint::YROTATION;
				channels[1] = CharJoint::XROTATION;
				channels[2] = CharJoint::ZROTATION;
				break;
			case Matrix3x3::YZX:
				channels[0] = CharJoint::YROTATION;
				channels[1] = CharJoint::ZROTATION;
				channels[2] = CharJoint::XROTATION;
				break;
			case Matrix3x3::ZXY:
				channels[0] = CharJoint::ZROTATION;
				channels[1] = CharJoint::XROTATION;
				channels[2] = CharJoint::YROTATION;
				break;
			case Matrix3x3::ZYX:
				channels[0] = CharJoint::ZROTATION;
				channels[1] = CharJoint::YROTATION;
				channels[2] = CharJoint::XROTATION;
				break;
			default:
				break;
		}

		charJoint->setChannels(3, channels);
	}
	else if (joint->getJointType() == J_UNIVERSAL)
	{
		switch (order)
		{
			case Matrix3x3::XY:
				channels[0] = CharJoint::XROTATION;
				channels[1] = CharJoint::YROTATION;
				break;
			case Matrix3x3::XZ:
				channels[0] = CharJoint::XROTATION;
				channels[1] = CharJoint::ZROTATION;
				break;
			case Matrix3x3::YX:
				channels[0] = CharJoint::YROTATION;
				channels[1] = CharJoint::XROTATION;
				break;
			case Matrix3x3::YZ:
				channels[0] = CharJoint::YROTATION;
				channels[1] = CharJoint::ZROTATION;
				break;
			case Matrix3x3::ZX:
				channels[0] = CharJoint::ZROTATION;
				channels[1] = CharJoint::XROTATION;
				break;
			case Matrix3x3::ZY:
				channels[0] = CharJoint::ZROTATION;
				channels[1] = CharJoint::YROTATION;
				break;
			default:
				break;
		}
		charJoint->setChannels(2, channels);
	}
	else if (joint->getJointType() == J_PIN)
	{
		switch (order)
		{
			case Matrix3x3::X:
				channels[0] = CharJoint::XROTATION;
				break;
			case Matrix3x3::Y:
				channels[0] = CharJoint::YROTATION;
				break;
			case Matrix3x3::Z:
				channels[0] = CharJoint::ZROTATION;
				break;
			default:
				break;
		}
		charJoint->setChannels(1, channels);
	}
	else if (joint->getJointType() == J_PLANAR)
	{
		switch (order)
		{
			case Matrix3x3::XYZ:
					channels[0] = CharJoint::XPOSITION;
					channels[1] = CharJoint::YPOSITION;
					channels[2] = CharJoint::ZPOSITION;
					channels[3] = CharJoint::ZROTATION;
					break;
			case Matrix3x3::XZY:
					channels[0] = CharJoint::XPOSITION;
					channels[1] = CharJoint::YPOSITION;
					channels[2] = CharJoint::ZPOSITION;
					channels[3] = CharJoint::YROTATION;
				break;
			case Matrix3x3::YXZ:
					channels[0] = CharJoint::XPOSITION;
					channels[1] = CharJoint::YPOSITION;
					channels[2] = CharJoint::ZPOSITION;
					channels[3] = CharJoint::ZROTATION;
				break;
			case Matrix3x3::YZX:
					channels[0] = CharJoint::XPOSITION;
					channels[1] = CharJoint::YPOSITION;
					channels[2] = CharJoint::ZPOSITION;
					channels[3] = CharJoint::XROTATION;
				break;
			case Matrix3x3::ZXY:
					channels[0] = CharJoint::XPOSITION;
					channels[1] = CharJoint::YPOSITION;
					channels[2] = CharJoint::ZPOSITION;
					channels[3] = CharJoint::YROTATION;
				break;
			case Matrix3x3::ZYX:
					channels[0] = CharJoint::XPOSITION;
					channels[1] = CharJoint::YPOSITION;
					channels[2] = CharJoint::ZPOSITION;
					channels[3] = CharJoint::XROTATION;
				break;
			default:
				break;
		}
		// set the rotational channel
		charJoint->setChannels(4, channels);
	}
	else if (joint->getJointType() == J_BALL)
	{
		//Added support for BALL joints.  MN Nov., 05
		switch (order)
		{
			case Matrix3x3::XYZ:
				channels[0] = CharJoint::XROTATION;
				channels[1] = CharJoint::YROTATION;
				channels[2] = CharJoint::ZROTATION;
				break;
			case Matrix3x3::XZY:
				channels[0] = CharJoint::XROTATION;
				channels[1] = CharJoint::ZROTATION;
				channels[2] = CharJoint::YROTATION;
				break;
			case Matrix3x3::YXZ:
				channels[0] = CharJoint::YROTATION;
				channels[1] = CharJoint::XROTATION;
				channels[2] = CharJoint::ZROTATION;
				break;
			case Matrix3x3::YZX:
				channels[0] = CharJoint::YROTATION;
				channels[1] = CharJoint::ZROTATION;
				channels[2] = CharJoint::XROTATION;
				break;
			case Matrix3x3::ZXY:
				channels[0] = CharJoint::ZROTATION;
				channels[1] = CharJoint::XROTATION;
				channels[2] = CharJoint::YROTATION;
				break;
			case Matrix3x3::ZYX:
				channels[0] = CharJoint::ZROTATION;
				channels[1] = CharJoint::YROTATION;
				channels[2] = CharJoint::XROTATION;
				break;
			default:
				break;
		}

/*		//we know the order of ball joints is fixed
		//	case Matrix3x3::XYZ:
		channels[0] = CharJoint::XROTATION;
		channels[1] = CharJoint::YROTATION;
		channels[2] = CharJoint::ZROTATION;
*/
		charJoint->setChannels(3, channels);
	}
	else if (joint->getJointType() == J_SLIDER)
	{
		// not handled
	}
	else if (joint->getJointType() == J_WELD)
	{
		// not handled
	}

	if (charParent == NULL)
	{
		charJoint->setOffset(inboardToJoint[0], inboardToJoint[1], inboardToJoint[2]);
	}
	else
	{
		Vector offset = {0.0, 0.0, 0.0};
		Vector parentBodyToJoint;
		parent->getBodyToJoint(parentBodyToJoint);
		VecNumMul(parentBodyToJoint, parentBodyToJoint, -1.0);
		VecAdd(offset, offset, parentBodyToJoint);
		VecAdd(offset, offset, inboardToJoint);
		charJoint->setOffset(offset[0], offset[1], offset[2]);
	}

	Link* link = joint->getOutboardLink();

	for (int x = 0; x < link->getNumChildLinks(); x++)
	{
		Joint* childJoint = link->getChildLinks()[x]->getParentJoint();
		CharJoint* charChild = new CharJoint(childJoint->getName());
		charJoint->addChild(charChild);
		charChild->setParent(charJoint);
		convertToCharacterRecurse(c, charJoint, charChild, joint, childJoint); 
	}
	if (link->getNumChildLinks() == 0)
	{ // is an end effector
		charJoint->setEndEffector(true);
		Vector endEff;
		VecCopy(endEff, bodyToJoint);
		VecNumMul(endEff, endEff, -1.0);
		Vector aoEndEff;
		link->getEndEffector(aoEndEff);
		Vector finalEndEff;
		VecAdd(finalEndEff, aoEndEff, endEff);
		charJoint->setEndEffectorOffset(finalEndEff[0], finalEndEff[1], finalEndEff[2]);
	}
}

bool CharacterAnimationSequence::interpolate(double time, double* val)
{
	if (this->getArticulatedObject() == NULL)
		return false;

	KeyFrame* kf = this->getKeyFrame(time);

	if (kf != NULL)
	{
		double* data1 = kf->getParams();
		KeyFrame* kf2 = kf->getNext();
		if (kf2 == NULL || kf->getTime() == time)
		{
			for (int x = 0; x < kf->getNumParams(); x++)
				val[x] = data1[x];
			return true;
		}
		else
		{
			double* data2 = kf2->getParams();

			double denom = kf2->getTime() - kf->getTime();
			double interp = 0.0;
			if (denom != 0.0)
				interp = (time - kf->getTime()) / denom;

			int count = 0 ;
			Quaternion q1;
			Quaternion q2;
			int numJoints = this->getArticulatedObject()->getNumJoints();
			Joint** joint = this->getArticulatedObject()->getJoints();
			for (int i = 0; i < numJoints; i++)
			{
				int jointType = joint[i]->getJointType();
				if (jointType == J_FREE)
				{
					// for joints with translational components, assume linear interpolation
					for (int x = 0; x < 3; x++)
						val[count + x] = (data1[x] * (1.0 - interp)) + (data2[x] * interp);
					count += 3;

					// free joints already have the quaternion saved as part of their state
					q1.fromVector(&data1[count]);
					q2.fromVector(&data2[count]);

				}
				else if (jointType == J_BALL)
				{ //added to support BALL joints  MN Nov., 05

					// ball joints already have the quaternion saved as part of their state
					q1.fromVector(&data1[count]);
					q2.fromVector(&data2[count]);

				}
				else
				{
					if (jointType == J_SLIDER)
					{
						for (int x = 0; x < 2; x++)
							val[count + x] = (data1[x] * (1.0 - interp)) + (data2[x] * interp);
						count += 2;
					}

					int numAxes = joint[i]->getNumAxis();
					Matrix3x3 finalMatrix1;
					Matrix3x3 finalMatrix2;
					finalMatrix1.identity();
					finalMatrix2.identity();
					double axes[3][3];
					joint[i]->getAxis(axes);
					Matrix3x3 tempMatrix1;
					Matrix3x3 tempMatrix2;
					for (int a = 0; a < numAxes; a++)
					{
						if (axes[a][0] == 1.0 && axes[a][1] == 0.0 && axes[a][2] == 0.0) // X
						{
							tempMatrix1.setRotateMatrix(Matrix3x3::X, data1[count + a]);
							tempMatrix2.setRotateMatrix(Matrix3x3::X, data2[count + a]);
						}
						else if (axes[a][0] == 0.0 && axes[a][1] == 1.0 && axes[a][2] == 0.0) // Y
						{
							tempMatrix1.setRotateMatrix(Matrix3x3::Y, data1[count + a]);
							tempMatrix2.setRotateMatrix(Matrix3x3::Y, data2[count + a]);
						}
						else if (axes[a][0] == 0.0 && axes[a][1] == 0.0 && axes[a][2] == 1.0) // Z
						{
							tempMatrix1.setRotateMatrix(Matrix3x3::Z, data1[count + a]);
							tempMatrix2.setRotateMatrix(Matrix3x3::Z, data2[count + a]);
						}

						finalMatrix1 *= tempMatrix1;
						finalMatrix2 *= tempMatrix2;
					}
					q1.fromMatrix(finalMatrix1);
					q2.fromMatrix(finalMatrix2);
				}

				Quaternion q3;
				q1.Slerp(&q2, interp, &q3);

				// decompose quaternion into matrix
				Matrix3x3 matrix;
				q3.toMatrix(matrix);
				int rotationOrder = joint[i]->determineRotationOrder();
				VectorObj vec(-9999,-9999,-9999);
				switch (jointType)
				{
				case J_FREE:
					// copy the quaternion directly
					for (int x = 0; x < 4; x++)
						val[count + x] = q3.data()[x];
					count += 4;
					break;
				case J_BALL:
					//added support for BALL joints MN Nov.,05
					// copy the quaternion directly
					for (int x = 0; x < 4; x++)
						val[count + x] = q3.data()[x];
					count += 4;
					break;
				case J_PIN:
/*					// see explanation under J_UNIVERSAL, BELOW
					val[count] = (data1[count] * (1.0 - interp)) + (data2[count] * interp);
*/
					val[count] = matrix.matToEuler1D(rotationOrder);
					count += 1;
					break;
				case J_UNIVERSAL:
/*					// if we use quaternions and slerp to interpolate 2 Euler angles, 
					// then the resultant quaternion might yield a matrix
					// that requires a 3 Euler angle decomposition
					// so....
					// just linearly interpolate the individual angles instead.
					for (int x = 0; x < 2; x++)
							val[count + x] = (data1[count + x] * (1.0 - interp)) + (data2[count + x] * interp);
*/
					matrix.matToEuler2D(rotationOrder, vec, false);
					val[count] = vec[0];
					val[count + 1] = vec[1];

					count += 2;
					break;
				case J_GIMBAL:
					matrix.matToEuler(rotationOrder, vec, false);
					if (rotationOrder == Matrix3x3::XYZ)
					{
						val[count] = vec[0];
						val[count + 1] = vec[1];
						val[count + 2] = vec[2];
					}
					else if (rotationOrder == Matrix3x3::XZY)
					{
						val[count] = vec[0];
						val[count + 1] = vec[2];
						val[count + 2] = vec[1];
					}
					else if (rotationOrder == Matrix3x3::YXZ)
					{
						val[count] = vec[1];
						val[count + 1] = vec[0];
						val[count + 2] = vec[2];
					}
					else if (rotationOrder == Matrix3x3::YZX)
					{
						val[count] = vec[1];
						val[count + 1] = vec[2];
						val[count + 2] = vec[0];
					}
					else if (rotationOrder == Matrix3x3::ZXY)
					{
						val[count] = vec[2];
						val[count + 1] = vec[0];
						val[count + 2] = vec[1];
					}
					else if (rotationOrder == Matrix3x3::ZYX)
					{
						val[count] = vec[2];
						val[count + 1] = vec[1];
						val[count + 2] = vec[0];
					}
					else
					{
						val[count] = 0;
						val[count + 1] = 0;
						val[count + 2] = 0;
					}
					count += 3;
					break;
				case J_SLIDER:
					val[count] = (data1[count] * (1.0 - interp)) + (data2[count] * interp);
					count += 1;
					break;
				default:
					break;
				}
			}
		}
	}
	else
	{
		return false;
	}

	return true;
}


