/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "AutomaticSettingsWindow.h"
#include <fltk/ask.h>
#include "Cube.h"
#include "Sphere.h"
#include "Capsule.h"
#include "dance.h"
#include "Link.h"
#include "Joint.h"

#include "Model.h"

using namespace fltk;

AutomaticSettingsWindow::AutomaticSettingsWindow(ArticulatedObject* ao, int x, int y, int w, int h, const char* name) : Window(x, y, w, h, name)
{
	artObj = ao;

	this->begin();

	buttonOk = new Button(10, h - 40, 80, 20, "Ok");
	buttonOk->callback(OkButton, this);
	buttonCancel = new Button(w - 100, h - 40, 80, 20, "Cancel");
	buttonCancel->callback(CancelButton, this);

	radioCapsules = new RadioButton(10, 10, 80, 20, "Use Capsules");
	radioCapsules->callback(CapsuleSetting, this);
	radioCapsules->value(false);

	radioSpheres = new RadioButton(10, 35, 80, 20, "Use Spheres");
	radioSpheres->callback(SphereSetting, this);
	radioSpheres->value(true);

	radioCubes = new RadioButton(10, 60, 80, 20, "Use Cubes");
	radioCubes->callback(CubeSetting, this);
	radioCubes->value(false);

	inputRatio = new FloatInput(80, 85, 40, 20, "Aspect Ratio");
	inputRatio->value(.3);

	inputLinkProportion = new FloatInput(80, 110, 40, 20, "Link Proportion");
	inputLinkProportion->value(.6);

	checkCalculateInertias = new CheckButton(10, 135, 80, 20, "Calculate Intertias");
	checkCalculateInertias->hide();

	checkRemoveOldGeometry = new CheckButton(10, 160, 80, 20, "Remove old geometry?");
	checkRemoveOldGeometry->value(true);

	buttonMaterial = new Button(10, 185, 80, 20, "Material");
	buttonMaterial->callback(MaterialSetting, this);

	outputMaterial = new Output(100, 185, 80, 20);
	outputMaterial->color(fltk::GRAY75);

	this->end();

	material = dance::MaterialManager->getDefaultMaterial();
	outputMaterial->value(material->getMaterialName());


	this->updateGUI();
}

void AutomaticSettingsWindow::updateGUI()
{

}

void hackmatrix(double matrix[4][4], double x, double y, double z)
{
	matrix[0][0] *= x;
	matrix[1][1] *= y;
	matrix[2][2] *= z;
}

void hackmatrix2(Vector trans, Vector rot, Vector scale, double result[4][4])
{
	double matrix[4][4];
	setIdentMat(&matrix[0][0], 4);
	TransMatFromScaleRotTrans(matrix, 
								scale[0], 
								scale[1], 
								scale[2],
								rot[0] * M_PI / 180.0, 
								rot[1] * M_PI / 180.0, 
								rot[2] * M_PI / 180.0, 
								trans[0], 
								trans[1], 
								trans[2]
								);

	transpArray(result, matrix);
}


void AutomaticSettingsWindow::OkButton(fltk::Widget *o, void *p)
{
	AutomaticSettingsWindow *sWin = (AutomaticSettingsWindow *)p;

	double aspectRatio = sWin->inputRatio->fvalue();
	double linkProportion = sWin->inputLinkProportion->fvalue();

	double state[500];
	sWin->artObj->getState(state);
	sWin->artObj->setZeroState();

	char buff[512];
	
	DGeometry* linkGeom = NULL;

	double volumes[500];
	double volumeTotal = 0.0;
	for (int x = 0; x < sWin->artObj->getNumLinks(); x++)
	{
		Link* link = sWin->artObj->getLink(x);
		// remove any old geometry
		DGeometry* geom = link->getGeometry();
		if (geom != NULL)
		{
			link->replaceGeometry(NULL, false);
			if (sWin->checkRemoveOldGeometry->value())
				dance::removeObject(geom);
		}

		// spheres, cubes, or capsules?
		if (sWin->radioCapsules->value())
		{
			linkGeom = new Capsule();
		}
		else if (sWin->radioSpheres->value())
		{
			linkGeom = new Sphere();
//// HACK! REMOVE SOON! LOAD A MODEL SPHERE INSTEAD OF THE NORMAL SPHERE
		/*	std::string lname = link->getName();
			if (lname.find("RightHandMOC") != std::string::npos || 
				lname.find("RightFingerMOC") != std::string::npos || 
				lname.find("RightThumbMOC") != std::string::npos || 
				lname.find("LeftHandMOC") != std::string::npos || 
				lname.find("LeftFingerMOC") != std::string::npos || 
				lname.find("LeftThumbMOC") != std::string::npos) 
			{
				linkGeom = new Cube();
			}
			else
			{
				linkGeom = new Model();
				Model* model = (Model*) linkGeom;
				model->Read3DS("c:/users/ashapiro/dance_v3/data/models/sphere.3ds");
			}*/
			
		}
		else 
		{
			linkGeom = new Cube();
		}

		// set the material
		linkGeom->setMaterial(sWin->material);

		sprintf(buff, "cube_%s", link->getName());
		// make sure that the name is unique
		int num = 1;
		std::string geomname = link->getName();
		bool found = true;
		while (found)
		{
			if (dance::AllGeometry->get((char*) geomname.c_str()) == NULL)
			{
				found = false;
			}
			else
			{
				geomname = link->getName();
				char buff[10];
				sprintf(buff, "%d", num);
				geomname.append(buff);
				num++;
			}
		}
		linkGeom->setName((char*) geomname.c_str());
		// register the geometry with DANCE
		bool ok = dance::AllGeometry->add(linkGeom);
		if (!ok)
		{
			fltk::alert("Cube %s could not be added to DANCE.");
			delete linkGeom;
			return;
		}

		BoundingBox box;
		sWin->artObj->calcBoundingBox(&box);

		// scale the cube to the general dimensions of each link
		Vector zero = {0.0, 0.0, 0.0};
		Vector curPos;
		link->getWorldCoord(curPos, zero);
		// find the length of this link
		Vector jointPos;
		link->getParentJoint()->getBodyToJoint(jointPos);
		Vector endEffPos;
		link->getEndEffector(endEffPos);
		Vector worldJoint;
		link->getWorldCoord(worldJoint, jointPos);
		Vector worldEndEff;
		link->getWorldCoord(worldEndEff, endEffPos);
		double lengthX = fabs(worldEndEff[0] - worldJoint[0]);
		double lengthY = fabs(worldEndEff[1] - worldJoint[1]);
		double lengthZ = fabs(worldEndEff[2] - worldJoint[2]);
		// make sure that no dimension is '0'
		// assign smallest dimension to 1/10 dimension of largest
		if (lengthX < .001)
		{
			if (lengthY > lengthZ)
				lengthX = .1 * lengthY;
			else
				lengthX = .1 * lengthZ;

		}
		else if (lengthY < .001)
		{
			if (lengthX > lengthZ)
				lengthY = .1 * lengthX;
			else
				lengthY = .1 * lengthZ;
		}
		else if (lengthZ < .001)
		{
			if (lengthY > lengthX)
				lengthZ = .1 * lengthY;
			else
				lengthZ = .1 * lengthX;
		}
		if (lengthX < .001 && lengthY < .001 && lengthZ < .001)
		{
			lengthX = lengthY = lengthZ = .1;
		}
		double curVolume = lengthX * lengthY + lengthZ;
		volumes[x] = curVolume;
		volumeTotal += volumes[x];
		// calculate the volume as
		double length = VecDist(worldJoint, worldEndEff);
		// assume links that are twice as long in the longest direction 
		// as they are in the other dimensions
		int whichDim = 0;
		if (lengthX > lengthY)
		{
			if (lengthZ > lengthX)
				whichDim = 2;
		}
		else
		{
			if (lengthY > lengthZ)
				whichDim = 1;
			else
				whichDim = 2;
		}

		length = length * linkProportion; // avoid overlap by scaling down to 80%
		double matrix[4][4];
		setIdentMat(&matrix[0][0], 4);

		if (sWin->radioSpheres->value() || sWin->radioCubes->value())
		{
			for (int i = 0; i < 3; i++)
			{
				if (i == whichDim)
					matrix[i][i] = length;
				else 
					matrix[i][i] = length * aspectRatio;
			}
			Vector scaling = {length, length, length};
			if (whichDim == 0)
			{
				scaling[1] *= aspectRatio;
				scaling[2] *= aspectRatio;
			}
			else if (whichDim == 1)
			{
				scaling[0] *= aspectRatio;
				scaling[2] *= aspectRatio;
			}
			else // if (whichDim == 2)
			{
				scaling[0] *= aspectRatio;
				scaling[1] *= aspectRatio;
			}

			linkGeom->Scale(scaling[0], scaling[1], scaling[2]);
		}
		else // capsules
		{ 
			// capsules should be as long as the length of the bone
			Vector l = {lengthX, lengthY, lengthZ};
			double capsuleLength = VecLength(l);
			Capsule* capsule = dynamic_cast<Capsule*>(linkGeom);
			// with multiple children, attempt to span the space
			if (link->getNumChildLinks() > 1)
			{
				// form a bounding box for of the child joints
				BoundingBox box;
				for (int c = 0; c < link->getNumChildLinks(); c++)
				{
					Link* child = link->getChildLinks()[c];
					Vector childJoint;
					child->getParentJoint()->getPosition(childJoint);
					if (box.xMin > childJoint[0])
						box.xMin = childJoint[0];
					if (box.xMax < childJoint[0])
						box.xMax = childJoint[0];
					if (box.yMin > childJoint[1])
						box.yMin = childJoint[1];
					if (box.yMax > childJoint[1])
						box.yMax = childJoint[1];
					if (box.zMin > childJoint[2])
						box.zMin = childJoint[2];
					if (box.zMax > childJoint[2])
						box.zMax = childJoint[2];
				}
				// use radius to fill space
				Vector lengths;
				lengths[0] = fabs(box.xMax - box.xMin);
				lengths[1] = fabs(box.yMax - box.yMin);
				lengths[2] = fabs(box.zMax - box.zMin);
				double finalRadius = lengths[0];
				if (finalRadius < lengths[1])
					finalRadius = lengths[1];
				if (finalRadius < lengths[2])
					finalRadius = lengths[2];
				capsule->setRadius(finalRadius * aspectRatio);
				capsule->setLength(finalRadius * aspectRatio);
			}
			else
			{
				capsule->setLength(capsuleLength);
				capsule->setRadius(capsuleLength * .5 * aspectRatio);
			}
			// orient the capsules around the proper axis
			// first take the standard axis of the capsule
			Vector capsuleAxis = {0, 0, 1};
			// second, determine the bone axis
			Vector boneAxis;
			VecSubtract(boneAxis, worldEndEff, worldJoint);
			VecNormalize(boneAxis);
			// third, determine the rotation needed to go from one to the other
			Quaternion q;
			q.rotateAxis(capsuleAxis, boneAxis);
			// change to a matrix
			Matrix3x3 m;
			q.toMatrix(m);
			// map to geometry 
			m.to4x4(matrix);
		}
		// position the link geom's center
		for (int i = 0; i < 3; i++)
			matrix[3][i] = curPos[i];
		linkGeom->Translate(matrix[3][0], matrix[3][1], matrix[3][2]);

// HACK! REMOVE SOON! CREATE THE PROPER PROPORTIONS FOR THE PLANNING SKELETON
//std::string lname = link->getName();
//if (lname.find("UpperLegMOC") != std::string::npos)
//{
//	hackmatrix(matrix, .4, .55, .4);
//}
//else if (lname.find("LowerLegMOC") != std::string::npos)
//{
//	hackmatrix(matrix, .4, .55, .4);
//}
//else if (lname.find("ShoulderMOC") != std::string::npos)
//{
//	hackmatrix(matrix, .5, .4, .4);
//}
//else if (lname.find("ElbowMOC") != std::string::npos)
//{
//	hackmatrix(matrix, .5, .4, .4);
//}
//else if (lname.find("HeadPointerMOC") != std::string::npos)
//{
//	matrix[0][0] = .05;
//	matrix[1][1] = .05;
//	matrix[2][2] = .15;
//	setVector(matrix[3], .018, 2.7, .058);
//}
//else if (lname.find("HeadMOC") != std::string::npos)
//{
//	hackmatrix(matrix, 2.5, 1, 2);
//}
//else if (lname.find("WaistMOC") != std::string::npos)
//{
//	hackmatrix(matrix, .6, .5, .5);
//}
//else if (lname.find("LowerTorsoMOC") != std::string::npos)
//{
//	hackmatrix(matrix, .8, .5, .5);
//}
//else if (lname.find("UpperTorsoMOC") != std::string::npos)
//{
//	hackmatrix(matrix, .5, .5, .5);
//}
//else if (lname.find("Clav") != std::string::npos)
//{
//	hackmatrix(matrix, .6, .6, .6);
//}
//else if (lname.find("NeckMOC") != std::string::npos)
//{
//	hackmatrix(matrix, .6, .6, .6);
//}
//else if (lname.find("rootMOC") != std::string::npos)
//{
//	hackmatrix(matrix, 8, 1.5, 1.5);
//}
//else if (lname.find("LeftHeelMOC") != std::string::npos)
//{
//	Vector trans = {0.370393, -3.930000, 0.523536};
//	Vector rotate = {20.000000, 0.000000, 0.000000};
//	Vector scale = {0.140000, 0.068000, 0.273000};
//	hackmatrix2(trans, rotate, scale, matrix);
//}
//else if (lname.find("LeftToesMOC") != std::string::npos)
//{
//	Vector trans = { 0.370000, -4.027388, 0.939724};
//	Vector rotate = {0.000000, 0.000000, 0.000000};
//	Vector scale = {0.097412, 0.044749, 0.178995};
//	hackmatrix2(trans, rotate, scale, matrix);
//}
//else if (lname.find("RightHeelMOC") != std::string::npos)
//{
//	Vector trans = { -0.371550, -3.959793, 0.409634};
//	Vector rotate = {20.000000, 0.000000, 0.000000};
//	Vector scale = {0.148620, 0.068272, 0.273089};
//	hackmatrix2(trans, rotate, scale, matrix);
//}
//else if (lname.find("RightToesMOC") != std::string::npos)
//{
//	Vector trans = { -0.365296, -4.040000, 0.805478};
//	Vector rotate = {0.000000, 0.000000, 0.000000};
//	Vector scale = {0.097000, 0.044000, 0.179000};
//	hackmatrix2(trans, rotate, scale, matrix);
//}
//else if (lname.find("LeftHandMOC") != std::string::npos)
//{
//	Vector trans = { 2.870407, 1.875870, -0.070000};
//	Vector rotate = {0.000000, 0.000000, 0.000000};
//	Vector scale = {0.380000, 0.100000, 0.250000};
//	//Vector scale = {0.380000 * .6, 0.100000 * .6, 0.250000 * .6};
//	hackmatrix2(trans, rotate, scale, matrix);
//}
//else if (lname.find("LeftFingerMOC") != std::string::npos)
//{
//	Vector trans = {3.149474, 1.875870, -0.070000};
//	Vector rotate = {0.000000, 0.000000, 0.000000};
//	Vector scale = {0.230000, 0.100000, 0.200000};
////	Vector scale = {0.230000 * .6, 0.100000 * .6, 0.200000 * .6};
//	hackmatrix2(trans, rotate, scale, matrix);
//}
//else if (lname.find("RightHandMOC") != std::string::npos)
//{
//	Vector trans = {-2.871231, 1.875871, -0.070000};
//	Vector rotate = {0.000000, 0.000000, 0.000000};
//	Vector scale = {0.380000, 0.100000, 0.250000};
////	Vector scale = {0.380000 * .6, 0.100000 * .6, 0.250000 * .6};
//	hackmatrix2(trans, rotate, scale, matrix);
//}
//else if (lname.find("RightFingerMOC") != std::string::npos)
//{
//	Vector trans = {-3.186971, 1.875870, -0.070000};
//	Vector rotate = {0.000000, 0.000000, 0.000000};
//	Vector scale = {0.230000, 0.100000, 0.200000};
////	Vector scale = {0.230000 * .6, 0.100000 * .6, 0.200000 * .6};
//	hackmatrix2(trans, rotate, scale, matrix);
//}


		linkGeom->setTransMatrix(matrix);
		link->replaceGeometry(linkGeom, true);

		// create the default monitor points
		if (sWin->radioSpheres->value())
			link->assignMonitorPoints(40); // create more monitor points on spheres
		else
			link->assignMonitorPoints(8); // cubes only need 8 monitor points
	}

	sWin->artObj->setState(state);

	sWin->updateGUI();
	dance::AllViews->postRedisplay();
	sWin->hide();
}

void AutomaticSettingsWindow::CancelButton(fltk::Widget *o, void *p)
{
	AutomaticSettingsWindow* win = (AutomaticSettingsWindow*) p;
	
	win->hide();
}


void AutomaticSettingsWindow::CapsuleSetting(fltk::Widget *o, void *p)
{
	AutomaticSettingsWindow* win = (AutomaticSettingsWindow*) p;

	if (win->radioCapsules->value())
	{
		win->radioCubes->value(false);
		win->radioSpheres->value(false);
		win->inputLinkProportion->deactivate();
	}
}

void AutomaticSettingsWindow::CubeSetting(fltk::Widget *o, void *p)
{
	AutomaticSettingsWindow* win = (AutomaticSettingsWindow*) p;

	if (win->radioCubes->value())
	{
		win->radioSpheres->value(false);
		win->radioCapsules->value(false);
		win->inputLinkProportion->activate();
	}
}

void AutomaticSettingsWindow::SphereSetting(fltk::Widget *o, void *p)
{
	AutomaticSettingsWindow* win = (AutomaticSettingsWindow*) p;

	if (win->radioSpheres->value())
	{
		win->radioCubes->value(false);
		win->radioCapsules->value(false);
		win->inputLinkProportion->activate();
	}
}

void AutomaticSettingsWindow::MaterialSetting(fltk::Widget *o, void *p)
{
	AutomaticSettingsWindow* win = (AutomaticSettingsWindow*) p;

	dance::rootWindow->materialWindow->setSelectMode(true);
	dance::rootWindow->materialWindow->exec();
	win->material = dance::rootWindow->materialWindow->getSelected();
	win->outputMaterial->value(win->material->getMaterialName());
}


