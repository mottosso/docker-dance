/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
// TimeSlider.h
// author: Jonathan Garcia (jonathan.f.garcia@ucla.edu)
// description: TimeSlider is a modified ValueSlider that handles
//              the addition, deletion, and navigation of key frames.

#ifndef __TIMESLIDER_H__
#define __TIMESLIDER_H__

#include <fltk/ValueSlider.h>
#include <vector>

class TimeSlider : public fltk::ValueSlider
{
	public:
		TimeSlider(int X, int Y, int W, int H, const char *l=0);

		std::vector<double> keyframes;

		void removeAllKeyFrames();
		void addKeyFrame();
		void removeKeyFrame();
		void removeKeyFramesLess(double time);
		void removeKeyFramesGreater(double time);
		void nextKeyFrame();
		void prevKeyFrame();
		void gotoStartTime();
		void gotoEndTime();
		void setStartTime(double time);
		void setEndTime(double time);

	protected:
		void draw();

	private:
		void slider_rect(fltk::Rectangle &);
};

#endif
