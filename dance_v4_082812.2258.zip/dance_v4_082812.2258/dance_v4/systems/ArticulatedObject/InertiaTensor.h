/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

***************************************************************
******General License Agreement and Lack of Warranty ***********
****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment
-----------------------------------------
AUTHOR:
Ari Shapiro (ashapiro@cs.ucla.edu)
ORIGINAL AUTHORS: 
Victor Ng (victorng@dgp.toronto.edu)
Petros Faloutsos (pfal@cs.ucla.edu)
CONTRIBUTORS:
Yong Cao (abingcao@cs.ucla.edu)
Paco Abad (fjabad@dsic.upv.es)
Brian Allen (vector@acm.org)
**********************************************************/

#ifndef	_INERTIATENSOR_H_
#define	_INERTIATENSOR_H_

#include "matrix3x3.h"
#include "vector.h"

#ifdef WIN32
#ifdef _EXPORTING_AR
#define DLLENTRY_AR __declspec(dllexport)
#else
#define DLLENTRY_AR __declspec(dllimport)
#endif
#else
#define DLLENTRY_AR
#endif

/// InertiaTensor maintains the inertia information for a rotational rigid-body.
/// \sa Link, ArticulatedObject
class DLLENTRY_AR InertiaTensor
{
public:

	/// Default constructor creates mass properties for a 0.1m x 0.1m x 0.1m cube
	/// with the density of water, centered at the origin.
	InertiaTensor( void );

	/// Copy constructor.
	InertiaTensor( const InertiaTensor& argFrom );

	InertiaTensor( const double argRawInertiaTensor[3][3], double argMass, Vector argCenterOfMass );

	/// Creates an inertia tensor equivalent to a box of the given dimensions
	/// (in meters) and with the given density (in kg/m^3)
	InertiaTensor( const Vector argBoxDimensionsMeters, const double& argDensityKgPerM3 );

	//////////////////////////////////////////////////////////////////////////
	// Accessors 
	//////////////////////////////////////////////////////////////////////////

	/// Returns a reference to the possibly-transformed inertia tensor as a 3x3 matrix.
	const Matrix3x3& getInertia( void ) const;

	/// Copies the possibly-transformed inertia tensor to the given 3x3 matrix.
	void getInertia( Matrix3x3& outInertiaTensor ) const;

	/// Returns the total scalar mass.
	double getMass( void ) const;

	/// Overwrites outCenterOfMass with current center of mass of this Inertia.
	void getCenterOfMass( Vector& outCenterOfMass ) const;
	//////////////////////////////////////////////////////////////////////////

	/// Transforms this inertia by the given homogeneous matrix.
	/// Note that both the internal Inertia tensor and the center of mass are affected.
	void transform( const double argTransformationMatrix[4][4] );
	
	/// Sets the inertia tensor and auxiliary information to the additive identity.
	void clear( void );

	/// Uses the standard parallel-axis theorem to compute the moment of inertia
	/// of this body around the provided axis at the distance offset provided.
	double getMoment( const Vector argAxis, const Vector argPointToRotateAbout ) const;

	/// Uses the standard parallel-axis theorem to compute the moment of inertia
	/// of this body around the provided axis at our known center-of-mass offset.
	double getMoment( const Vector argAxisOfRotation ) const;

	/// Assignment operator.
	void operator= ( const InertiaTensor& argFrom );

	/// Add the given inertia tensor to this, aggregating the mass and computing
	/// the new center of mass for the combined body.
	/// Note: the two InertiaTensors must be in the same coordinate system.
	InertiaTensor operator += ( const InertiaTensor& argOther );

	//////////////////////////////////////////////////////////////////////////
	// Friends
	//////////////////////////////////////////////////////////////////////////
	/// Add the two inertia tensors, including aggregating the mass and computing
	/// the new center of mass for the combined body.
	/// Note: the two InertiaTensors must be in the same coordinate system.
	friend InertiaTensor operator+ ( const InertiaTensor& argLHS, const InertiaTensor& argRHS );
	//////////////////////////////////////////////////////////////////////////

	/// Draw the inertia mass as a ellipsoid.  Assume to be in the same coordinate system
	/// for rendering as this object's data is.
	void display( int argModeBitFlag ) const;

private:
	Matrix3x3	m_tensor;		//< Symmetric definite inertia tensor (in kg*meters^2)
	double		m_mass;			//< Scalar total mass (in kilograms)
	Vector		m_centerOfMass; //< Usage defines the coordinate system (in meters)
	double		m_displayScale;	//< Determines the scale to draw moment ellipsoids (in meters/kg)
};


#endif
