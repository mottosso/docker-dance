/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
// TimeSlider.cxx
// author: Jonathan Garcia (jonathan.f.garcia@ucla.edu)
// description: TimeSlider is a modified ValueSlider that handles
//              the addition, deletion, and navigation of key frames.

#include "dance.h"
#include <fltk/draw.h>
#include <fltk/damage.h>
#include <fltk/Box.h>
#include <fltk/FloatInput.h>
#include <fltk/Group.h>
#include "TimeSlider.h"

using namespace fltk;
using namespace std;

TimeSlider::TimeSlider(int X, int Y, int W, int H, const char *l)
	: ValueSlider(X, Y, W, H, l)
{
	this->input.reserve(7);
}

// Return the area to draw the slider in:
void TimeSlider::slider_rect(Rectangle& r)
{
	r.set(0,0,w(),h()); box()->inset(r);
	if (vertical()) r.move_b(-input.h());
	else r.move_x(input.w());
}

void TimeSlider::draw()
{
	if (damage() & ~DAMAGE_CHILD)
	{
		input.set_damage(DAMAGE_ALL);
		Flags f2 = flags() & ~FOCUSED;
#ifdef WIN32
		if (pushed()) f2 |= STATE|PUSHED;
#else
		if (pushed()) f2 |= STATE|PUSHED;
#endif
		Box* box = this->box();
		if (!box->fills_rectangle()) draw_background();
		drawstyle(style(),flags()&~HIGHLIGHT);
		Rectangle r(w(),h()); box->draw(r);
		slider_rect(r);
		Slider::draw(r, f2, r.y()==0);

		// place keyframe marker drawing here
		for (vector<double>::iterator iter = keyframes.begin(); iter != keyframes.end(); iter++)
		{
			int x = r.x() + this->slider_position((*iter), r.w()) + slider_size()/2;
			Rectangle key(x, h()/2, 1, h()/2-1);

			if ((*iter) >= minimum() && (*iter) <= maximum())
			{
				if (this->value() == (*iter))
					setcolor(BLUE);
				else
					setcolor(RED);
				fillrect(key);
			}
		}
	}

	input.label(label());
	input.align(align());

	input.flags(flags()|CLICK_TO_FOCUS);
	push_matrix();
	translate(input.x(),input.y());
	input.draw();
	pop_matrix();
	input.set_damage(0);
}

void TimeSlider::removeAllKeyFrames()
{
	keyframes.clear();
}

void TimeSlider::addKeyFrame()
{
	double time = value();
	
	for (vector<double>::iterator iter = keyframes.begin(); iter != keyframes.end(); iter++)
	{
		if ((*iter) == time)
		{
			danceInterp::OutputMessage("A keyframe at %0.4f already exists, use Update instead.", time);
			return ;
		}
	}

	keyframes.push_back(time);
//	danceInterp::OutputMessage("Keyframe successfully added at time %0.4f.", time);
	redraw();
}

void TimeSlider::removeKeyFrame()
{
	double time = value();
	
	for (vector<double>::iterator iter = keyframes.begin(); iter != keyframes.end(); iter++)
	{
		if ((*iter) == time)
		{
			danceInterp::OutputMessage("Keyframe at time %0.4f removed successfully", time);
			keyframes.erase(iter);
			redraw();
			return ;
		}
	}

	danceInterp::OutputMessage("A keyframe at time %0.4f could not be found.", time);
}

void TimeSlider::removeKeyFramesLess(double time)
{
	for (vector<double>::iterator iter = keyframes.begin(); iter != keyframes.end(); iter++)
	{
		if ((*iter) < time)
		{
			danceInterp::OutputMessage("Keyframe at time %0.4f removed successfully", time);
			keyframes.erase(keyframes.begin(), iter);
			redraw();
			return;
		}
	}
}

void TimeSlider::removeKeyFramesGreater(double time)
{
	for (vector<double>::iterator iter = keyframes.begin(); iter != keyframes.end(); iter++)
	{
		if ((*iter) > time)
		{
			danceInterp::OutputMessage("Keyframe at time %0.4f removed successfully", time);
			keyframes.erase(iter, keyframes.end());
			redraw();
			return;
		}
	}
}

// Step to previous key.
void TimeSlider::prevKeyFrame()
{
	double time = value();
	double key = -1;
	for (vector<double>::iterator iter = keyframes.begin(); iter != keyframes.end(); iter++)
	{
		if ((*iter) < time && (*iter) > key)
			key = (*iter);
	}

	if (key != -1)
	{
		value(key);
		redraw();
	}
}

// Step to next key.
void TimeSlider::nextKeyFrame()
{
	double time = value();
	double key = maximum()+1;
	for (vector<double>::iterator iter = keyframes.begin(); iter != keyframes.end(); iter++)
	{
		if ((*iter) > time && (*iter) < key)
			key = (*iter);
	}

	if (key != maximum()+1)
	{
		value(key);
		redraw();
	}
}

void TimeSlider::gotoStartTime()
{
	value(minimum());
	redraw();
}

void TimeSlider::gotoEndTime()
{
	value(maximum());
	redraw();
}


void TimeSlider::setStartTime(double time)
{
	minimum(time);
	redraw();
}

void TimeSlider::setEndTime(double time)
{
	maximum(time);
	redraw();
}
