/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_JOINT_H_
#define	_JOINT_H_ 1

#include "ArticulatedObject.h"

#include "Quaternion.h"

// types of joints
#define	J_UNDEF	     0
#define	J_PIN	     1
#define	J_BALL	     2
#define	J_CYLINDER   3
#define	J_SLIDER     4
#define	J_FREE	     5
#define	J_GIMBAL     6
#define	J_WELD	     7
#define	J_PLANAR     8
#define	J_BEARING    9
#define	J_UNIVERSAL 10
#define	J_BUSHING   11

class DObject ;
class Link;

#ifdef WIN32
#ifdef _EXPORTING_AR
#define DLLENTRY_AR __declspec(dllexport)
#else
#define DLLENTRY_AR __declspec(dllimport)
#endif
#else
#define DLLENTRY_AR
#endif

#define JOINT_MAX_NAME_LEN (128)

class DLLENTRY_AR Joint
{
//friend class Link ;

public:
	Joint() ;
	~Joint();

	void CalcState();
	int isChanged();
	void addDof(int index, double deltaAngle, double deltaTrans);
	int getAvailableTypes();
	int getJointTypeFromString(char *typeString);

	int setDof(int dof, double value);
	double getDof(int dof);
	int getLabel(int dof, char *label);

    void create(int num, int t, Link *p, Link *l) ;
    int	getAxis(double a[3][3])	;
    int	getNumAxis();
    void setNumAxis(int num);
	void setAxis(int index, double* axis);
    int	getOrientation(double m[4][4]);
	Quaternion* getQuaternion();
	void setQuaternion(Quaternion* q);
    void getPosition(double p[3]) ;
    inline void	getInbToJoint(double p[3]) { VecCopy(p,m_InbToJoint) ;} ;
    inline void	getBodyToJoint(double p[3]) { VecCopy(p,m_BodyToJoint) ; } ;
    double getState(int	index);
	void getStateVector(double* vec);
    int	getStateSize();
    int	getNumDof()	;
    void setLastState();
    void setPosition(double p[3]);
    void setRelativePosition(double p[3]);
    void setState(int index, double state, int batch = FALSE) ;
	void setState( double* argNewVal );
    void setDState(int index, double state) ;
	void setInitDState(double *ds) ;
	void getInitDState(double ds[3]) ; // allways takes a vector even if the DOFs are less
	double getInitDState(int indx) ;
	void setInitDState(int index, double state) ;

    double getDState(int index) ;
	bool hasVelocity();
	void setHasVelocity(bool val);
    void applyTransformation() ;
    void changeType(int	newtype);
    void display(int mode=0);
    void display2(int mode=0, bool active=false);
    void displayRefFrame(double	length,	double frame[4][4]);
    void displayAxis(double axis[3], double length, int	arrowtype=0);
    void displayManipulators();
    void setParam(int ax, double stif, double damp) ;
	void setZeroState();

    void getLimits(int dof, double *low, double *high);
    void setLimits(int dof, double low, double high);

	void setDamping(int index, double d);
	double getDamping(int index);
	void setStiffness(int index, double s);
	double getStiffness(int index);
	void setMaxDamping(int index, double d);
	double getMaxDamping(int index);
	void setMaxStiffness(int index, double s);
	double getMaxStiffness(int index);

	void writeBVHFile(FILE *fp, int depth) ;
	void writeMayaFile(FILE *fp) ;

	double* getBodyToJoint();
	double* getInbToJoint();
	void setBodyToJoint(double* vec);
	void setInbToJoint(double* vec);
	Link* getInboardLink();
	Link* getOutboardLink();
	void setInboardLink(Link* l);
	void setOutboardLink(Link* l);
	int getJointNum();
	void setJointNum(int val);
	int getJointType();
	void setJointType(int type);
	void TetraOut(GLdouble tetraLenRatio, Vector point1, Vector point2, bool active);
	void setShowBoundingBox(bool val);


	int determineRotationOrder();
	void setRotationOrder(int order);

	void setArticulatedObject(ArticulatedObject* artObj);
	ArticulatedObject* getArticulatedObject();

	int	Command(int argc, char **argv);

	void setName(const char* name);
	const char* getName();
	

private:

	// Use the arg as a 4-elem quat, handles normalization.
	void setStateQuaternion( double* argNewVal );
	int m_jointNumber ;		// number of joint
    int m_jointType ;			// type	of joint

    double m_axis[3][3] ;		// the up to three rotational axis
    double damping[7] ;
    double stiffness[7]	;
    double maxDamping[7] ;
    double maxStiffness[7] ;
    double m_Limits[6][2];
    int	m_numAxis	;		// 0 1 2 3 depending on	the joint type
    Quaternion m_Frame;		// the initial orientation quaternion
	Quaternion m_AuxFrame;  // Auxiliary reference frame for a joint.
    Link *inboardLink ;		// Inboard link	of joint.
    Link *outboardLink ;	// Outboard link of joint.
    double m_InbToJoint[3] ;	// inboard to joint (parent to joint)
    double m_BodyToJoint[3] ;	// child link to joint vector
	double m_OldInbToJoint[3]; 
	double m_OldBodyToJoint[3];

	bool m_ShowBoundingBox;

	double m_OldState[7];   // the old state vector of this joint.
	double m_State[7] ;	// the state vector of this joint
	double m_dState[7]; // state derivatives (velocity) 
	double m_InitDState[7]; // state derivatives (velocity) 
	ArticulatedObject* m_artObj;
	char m_name[JOINT_MAX_NAME_LEN];
	bool m_hasVelocity;

} ;
#endif
