/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "IKChain.h"
#include <cstdlib>

using namespace std;

IKChain::IKChain()
	: numDOFs(0), numJoints(0), ikTol(0.001), transMat(NULL), rotMat(NULL), dRotMat(NULL), numIterations(5)
{
	joint.clear();

	stepDivision = .1;
}

IKChain::~IKChain()
{
	cleanup();
}

void IKChain::cleanup()
{
	if(transMat) { delete [] transMat; transMat = NULL; }
	if(rotMat) { delete [] rotMat; rotMat = NULL; }
	if(dRotMat) { delete [] dRotMat; dRotMat = NULL; }
}

int IKChain::init()
{
	// make sure there is a valid chain
	if(!isChain()) {
		return IK_INIT_ERROR;
	}

	cleanup();

	numDOFs = 0;
	for(int j=0; j<numJoints; j++)
		numDOFs += joint[j]->getNumDof();

	if(numDOFs <= 0)
		return IK_INIT_ERROR;
	
	// allocate memory for needed matrices
	// dTheta
	dTheta.setSize(numDOFs, 1);

	// jacobian matrix
	J.setSize(3, numDOFs);
    
	// transpose of jacobian
	Jtrans.setSize(numDOFs, 3);

	// translation matrices
	transMat = new mat4x4[numJoints+1];
	if(transMat == NULL)
	{
		cleanup();
		return IK_INIT_ERROR;
	}

	// rotation matrices
	rotMat = new mat4x4[numJoints*3];
	if(rotMat == NULL)
	{
		cleanup();
		return IK_INIT_ERROR;
	}

	// derivates of rotation matrices
	dRotMat = new mat4x4[numJoints*3];
	if(dRotMat == NULL)
	{
		cleanup();
		return IK_INIT_ERROR;
	}

	Vector temp, temp2;
	for(int j=0; j<=numJoints; j++)
	{
		// compute translation matrices
		if(j == 0) {
			joint[j]->getInbToJoint(temp);
		} else if( j == numJoints ) {
			Link *end = joint[numJoints-1]->getOutboardLink();
			joint[numJoints-1]->getBodyToJoint(temp);
			VecScale(temp, -1);
			end->getEndEffector(temp2);
			VecAdd(temp, temp, temp2);
		} else {
			joint[j-1]->getPosition(temp);
			joint[j]->getPosition(temp2);
			VecSubtract(temp, temp2, temp);
		}

		// initialize translation matrix
		transMat[j][0]  = 1;	transMat[j][1]  = 0;	transMat[j][2]  = 0;	transMat[j][3]  = temp[0];
		transMat[j][4]  = 0;	transMat[j][5]  = 1;	transMat[j][6]  = 0;	transMat[j][7]  = temp[1];
		transMat[j][8]  = 0;	transMat[j][9]  = 0;	transMat[j][10] = 1;	transMat[j][11] = temp[2];
		transMat[j][12] = 0;	transMat[j][13] = 0;	transMat[j][14] = 0;	transMat[j][15] = 1;
	}

	return IK_INIT_SUCCESS;
}

void IKChain::reset()
{
	cleanup();
	joint.clear();
	numJoints = 0;
	numDOFs = 0;
}

void IKChain::addJoint(Joint* j)
{
	if(j->getNumDof() >= 0 && j->getNumDof() <= 3) {
		joint.resize(++numJoints);
		joint[numJoints-1] = j;
		this->numDOFs += j->getNumDof();
	}
}

Joint* IKChain::getJoint(int index)
{
	if(index < 0 || index > numJoints)
		return NULL;
	
	return joint[index];
}

void IKChain::setGoal(const Vector goal)
{
	VecCopy(ikGoal, goal);
}

void IKChain::getGoal(Vector goal)
{
	VecCopy(goal, ikGoal);
}

void IKChain::getEndEffector(Vector ee)
{
	if(numJoints >= 1) {
		joint[numJoints-1]->getOutboardLink()->getPosition(ee);
	}
	else
		setVector(ee, 0.0, 0.0, 0.0);
}

void IKChain::getIKOrigin(Vector origin)
{
	if(numJoints >= 1)
		joint[0]->getPosition(origin);
	else
		setVector(origin, 0.0, 0.0, 0.0);
}

int IKChain::getNumDofs()
{
	return numDOFs;
}

int IKChain::getNumJoints()
{
	return numJoints;
}

double IKChain::getIKTolerance()
{
	return ikTol;
}

void IKChain::setIKTolerance(double tol)
{
	if(tol < 0)
		ikTol = -tol;
	else
		ikTol = tol;
}

bool IKChain::isChain()
{
	for(int j=numJoints-1; j>0; j--)
	{
		if(joint[j]->getOutboardLink()->getParentLink()->getParentJoint() != joint[j-1])
			return false;
	}

	return true;
}

int IKChain::computeStep(int numSteps, bool &early, double* dtheta)
{
	int result = IK_GOAL_NOT_REACHED;
	early = false;
	for(int steps = 0; steps < numSteps; steps++)
	{
		if((result = this->compute()) == IK_GOAL_REACHED)
		{
			early = true;
			break;
		}
	}

	for(int i=0; i<numDOFs; i++)
		dtheta[i] = dTheta.elem(i, 0);

	return result;
}

int IKChain::compute()
{
	// temporary matrices for partial solutions
	double temp[4][4], temp2[4][4], temp4x1[4][1];

	// initialize parent transformation matrix
	Link* parentLink = joint[0]->getInboardLink();
	parentLink->getWTransMat(temp);
	for(int I=0; I<4; I++)
		for(int J=0; J<4; J++)
			parentMatrix[I][J] = temp[J][I];

	// initialize rotation matrices & their derivatives
	double axes[3][3], a, c, s;
	for(int j=0; j<numJoints; j++)
	{
		joint[j]->getAxis(axes);
		int dofs = joint[j]->getNumDof();
		VectorObj obj;
		if (joint[j]->getJointType() == J_BALL)
		{
			// convert quaternion -> matrix
			double val[4];
			for (int x = 0; x <  4; x++)
			{
				val[x] = joint[j]->getState(x);
			}
			Quaternion q(val[0], val[1], val[2], val[3]);
			Matrix3x3 matrix;
			q.toMatrix(matrix);
			matrix.matToEuler(Matrix3x3::XYZ, obj, false);
		}
		for(int i=0; i<dofs; i++)	// assumes there is 3 DOFs
		{
			Vector axis = { axes[i][0], axes[i][1], axes[i][2] };
			
			if (joint[j]->getJointType() == J_BALL)
			{
				a = obj[i];
			}
			else
			{
				a = joint[j]->getState(i);
			}
			c = cos(a);
			s = sin(a);

			if(axis[0] == 1)
			{
				// rotation around x-axis
				rotMat[j*3+i][0]  = 1;	rotMat[j*3+i][1]  =  0;	rotMat[j*3+i][2]  =  0;	rotMat[j*3+i][3]  = 0;
				rotMat[j*3+i][4]  = 0;	rotMat[j*3+i][5]  =  c;	rotMat[j*3+i][6]  = -s;	rotMat[j*3+i][7]  = 0;
				rotMat[j*3+i][8]  = 0;	rotMat[j*3+i][9]  =  s;	rotMat[j*3+i][10] =  c;	rotMat[j*3+i][11] = 0;
				rotMat[j*3+i][12] = 0;	rotMat[j*3+i][13] =  0;	rotMat[j*3+i][14] =  0;	rotMat[j*3+i][15] = 1;

				// derivative of rotation around x-axis
				dRotMat[j*3+i][0]  = 0;	dRotMat[j*3+i][1]  =  0;	dRotMat[j*3+i][2]  =  0;	dRotMat[j*3+i][3]  = 0;
				dRotMat[j*3+i][4]  = 0;	dRotMat[j*3+i][5]  = -s;	dRotMat[j*3+i][6]  = -c;	dRotMat[j*3+i][7]  = 0;
				dRotMat[j*3+i][8]  = 0;	dRotMat[j*3+i][9]  =  c;	dRotMat[j*3+i][10] = -s;	dRotMat[j*3+i][11] = 0;
				dRotMat[j*3+i][12] = 0;	dRotMat[j*3+i][13] =  0;	dRotMat[j*3+i][14] =  0;	dRotMat[j*3+i][15] = 0;
			}
			else if(axis[1] == 1)
			{
				// rotation around y-axis
				rotMat[j*3+i][0]  =  c;	rotMat[j*3+i][1]  = 0;	rotMat[j*3+i][2]  =  s;	rotMat[j*3+i][3]  = 0;
				rotMat[j*3+i][4]  =  0;	rotMat[j*3+i][5]  = 1;	rotMat[j*3+i][6]  =  0;	rotMat[j*3+i][7]  = 0;
				rotMat[j*3+i][8]  = -s;	rotMat[j*3+i][9]  = 0;	rotMat[j*3+i][10] =  c;	rotMat[j*3+i][11] = 0;
				rotMat[j*3+i][12] =  0;	rotMat[j*3+i][13] = 0;	rotMat[j*3+i][14] =  0;	rotMat[j*3+i][15] = 1;

				// derivative of rotation around y-axis
				dRotMat[j*3+i][0]  = -s;	dRotMat[j*3+i][1]  = 0;	dRotMat[j*3+i][2]  =  c;	dRotMat[j*3+i][3]  = 0;
				dRotMat[j*3+i][4]  =  0;	dRotMat[j*3+i][5]  = 0;	dRotMat[j*3+i][6]  =  0;	dRotMat[j*3+i][7]  = 0;
				dRotMat[j*3+i][8]  = -c;	dRotMat[j*3+i][9]  = 0;	dRotMat[j*3+i][10] = -s;	dRotMat[j*3+i][11] = 0;
				dRotMat[j*3+i][12] =  0;	dRotMat[j*3+i][13] = 0;	dRotMat[j*3+i][14] =  0;	dRotMat[j*3+i][15] = 0;
			}
			else if(axis[2] == 1)
			{
				// rotation around z-axis
				rotMat[j*3+i][0]  =  c;	rotMat[j*3+i][1]  = -s;	rotMat[j*3+i][2]  =  0;	rotMat[j*3+i][3]  = 0;
				rotMat[j*3+i][4]  =  s;	rotMat[j*3+i][5]  =  c;	rotMat[j*3+i][6]  =  0;	rotMat[j*3+i][7]  = 0;
				rotMat[j*3+i][8]  =  0;	rotMat[j*3+i][9]  =  0;	rotMat[j*3+i][10] =  1;	rotMat[j*3+i][11] = 0;
				rotMat[j*3+i][12] =  0;	rotMat[j*3+i][13] =  0;	rotMat[j*3+i][14] =  0;	rotMat[j*3+i][15] = 1;

				// derivative of rotation around z-axis
				dRotMat[j*3+i][0]  = -s;	dRotMat[j*3+i][1]  = -c;	dRotMat[j*3+i][2]  =  0;	dRotMat[j*3+i][3]  = 0;
				dRotMat[j*3+i][4]  =  c;	dRotMat[j*3+i][5]  = -s;	dRotMat[j*3+i][6]  =  0;	dRotMat[j*3+i][7]  = 0;
				dRotMat[j*3+i][8]  =  0;	dRotMat[j*3+i][9]  =  0;	dRotMat[j*3+i][10] =  0;	dRotMat[j*3+i][11] = 0;
				dRotMat[j*3+i][12] =  0;	dRotMat[j*3+i][13] =  0;	dRotMat[j*3+i][14] =  0;	dRotMat[j*3+i][15] = 0;
			}
		}
	}

	// origin
	double x0[4][1];
	x0[0][0] = 0;
	x0[1][0] = 0;
	x0[2][0] = 0;
	x0[3][0] = 1;
/*
	multArray(&temp[0][0], &parentMatrix[0][0], transMat[0], 4, 4, 4);
	multArray(&temp2[0][0], &temp[0][0], rotMat[0], 4, 4, 4);
	multArray(&temp[0][0], &temp2[0][0], rotMat[1], 4, 4, 4);
	multArray(&temp2[0][0], &temp[0][0], rotMat[2], 4, 4, 4);
	multArray(&temp[0][0], &temp2[0][0], transMat[1], 4, 4, 4);
	multArray(&temp4x1[0][0], &temp[0][0], &x0[0][0], 4, 4, 1);
	setVector(ikEndEffector, temp4x1[0][0], temp4x1[1][0], temp4x1[2][0]);

	return IK_GOAL_NOT_REACHED;
*/
	// compute end effector
	bool useTemp2 = false;
	setIdentMat(*temp, 4);
	setIdentMat(*temp2, 4);
	//multArray(*temp2, *temp, *parentMatrix, 4, 4, 4);
	multArray4x4(temp2, temp, parentMatrix);
	for(int j=0; j<=numJoints; j++)
	{
		if(useTemp2) {
			//multArray(*temp2, *temp, transMat[j], 4, 4, 4);
			multArray4x4(temp2, temp, transMat[j]);
			useTemp2 = false;
		}
		else {
            //multArray(*temp, *temp2, transMat[j], 4, 4, 4);
			multArray4x4(temp, temp2, transMat[j]);
			useTemp2 = true;
		}

		for(int i=0; j<numJoints && i<joint[j]->getNumDof(); i++)
		{
			if(useTemp2) {
				//multArray(*temp2, *temp, rotMat[j*3+i], 4, 4, 4);
				multArray4x4(temp2, temp, rotMat[j * 3 + i]);
				useTemp2 = false;
			}
			else {
				//multArray(*temp, *temp2, rotMat[j*3+i], 4, 4, 4);
				multArray4x4(temp, temp2, rotMat[j * 3 + i]);

				useTemp2 = true;
			}
		}
	}

	if(useTemp2)
		multArray(*temp4x1, *temp, *x0, 4, 4, 1);
	else
		multArray(*temp4x1, *temp2, *x0, 4, 4, 1);

	setVector(ikEndEffector, temp4x1[0][0], temp4x1[1][0], temp4x1[2][0]);

	Vector vel;
	VecSubtract(vel, ikGoal, ikEndEffector);

	double dist = VecLength(vel);
	if(dist >= -ikTol && dist <= ikTol)
	{
		return IK_GOAL_REACHED;
	}

//	return IK_GOAL_NOT_REACHED;

	double V[3][1];
	V[0][0] = vel[0] * stepDivision;
	V[1][0] = vel[1] * stepDivision;
	V[2][0] = vel[2] * stepDivision;

	// compute jacobian
	for(int d=0; d<numDOFs; d++)
	{
		int counter = 0;
		useTemp2 = false;
		setIdentMat(*temp, 4);
		setIdentMat(*temp2, 4);

		//multArray(*temp2, *temp, *parentMatrix, 4, 4, 4);
		multArray4x4(temp2, temp, parentMatrix);

		for(int j=0; j<=numJoints; j++)
		{
			if(useTemp2) {
				//multArray(*temp2, *temp, transMat[j], 4, 4, 4);
				multArray4x4(temp2, temp, transMat[j]);

				useTemp2 = false;
			}
			else {
				//multArray(*temp, *temp2, transMat[j], 4, 4, 4);
				multArray4x4(temp, temp2, transMat[j]);

				useTemp2 = true;
			}

			for(int i=0; j<numJoints && i<joint[j]->getNumDof(); i++)
			{
				if(useTemp2) {
					if(d == counter++) {
                        //multArray(*temp2, *temp, dRotMat[j*3+i], 4, 4, 4);
						multArray4x4(temp2, temp, dRotMat[j * 3 + i]);
					}
					else {
						//multArray(*temp2, *temp, rotMat[j*3+i], 4, 4, 4);
						multArray4x4(temp2, temp, rotMat[j * 3 + i]);
					}
					useTemp2 = false;
				}
				else {
					if(d == counter++) {
						//multArray(*temp, *temp2, dRotMat[j*3+i], 4, 4, 4);
						multArray4x4(temp, temp2, dRotMat[j * 3 + i]);
					}
					else {
						//multArray(*temp, *temp2, rotMat[j*3+i], 4, 4, 4);
						multArray4x4(temp, temp2, rotMat[j * 3 + i]);
					}
					useTemp2 = true;
				}
			}
		}

		if(useTemp2)
			multArray(*temp4x1, *temp, *x0, 4, 4, 1);
		else
			multArray(*temp4x1, *temp2, *x0, 4, 4, 1);

		J.elem(0,d) = temp4x1[0][0];
		J.elem(1,d) = temp4x1[1][0];
		J.elem(2,d) = temp4x1[2][0];	
	}

	// compute Jtrans (transpose of jacobian)
	for(int i=0; i<numDOFs; i++)
		for(int j=0; j<3; j++)
			Jtrans.elem(i,j) = J.elem(j,i);

	// compute dTheta
	multArray(dTheta.getData(), Jtrans.getData(), *V, numDOFs, 3, 1);

	return IK_GOAL_NOT_REACHED;
}

void IKChain::setIKNumIterations(int val)
{
	this->numIterations = val;
}

int IKChain::getIKNumIterations()
{ 
	return this->numIterations;
}

void IKChain::setIKStepDivision(double val)
{
	this->stepDivision = val;
}

double IKChain::getIKStepDivision()
{ 
	return this->stepDivision;
}

