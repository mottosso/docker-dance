/**************************************************

Copyright 2005 by Ari Shapiro and Petros Faloutsos



DANCE

Dynamic ANimation and Control Environment



 ***************************************************************

 ******General License Agreement and Lack of Warranty ***********

 ****************************************************************St





This software is distributed for noncommercial use in the hope that it will 

be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility

to anyone for the consequences	of using it or for whether it serves any 

particular purpose or works at all. No warranty is made about the software 

or its performance. Commercial use is prohibited. 



Any plugin code written for DANCE belongs to the developer of that plugin,

who is free to license that code in any manner desired.



Content and code development by third parties (such as FLTK, Python, 

ImageMagick, ODE) may be governed by different licenses.

You may modify and distribute this software as long as you give credit 

to the original authors by including the following text in every file 

that is distributed: */



/*********************************************************

	Copyright 2005 by Ari Shapiro and Petros Faloutsos



	DANCE

	Dynamic ANimation and Control Environment

	-----------------------------------------

	AUTHOR:

		Ari Shapiro (ashapiro@cs.ucla.edu)

	ORIGINAL AUTHORS: 

		Victor Ng (victorng@dgp.toronto.edu)

		Petros Faloutsos (pfal@cs.ucla.edu)

	CONTRIBUTORS:

		Yong Cao (abingcao@cs.ucla.edu)

		Paco Abad (fjabad@dsic.upv.es)

**********************************************************/



#define TOL 0.001						// tolerance for singularities

#define DOFS 4

#define IK_MODE_OFF -1



#include <ctype.h>

#include "defs.h"

#include "dance.h"

#include "danceInterp.h"

#include "DSystem.h"

#include "ArticulatedObject.h"

#include "ArticulatedObjectWindow.h"

#include "ViewManager.h"

#include "DView.h"

#include "DSimulator.h"

#include "KeyFrame.h"

#include "LinkStack.h"

#include "Link.h"

#include "Joint.h"

#include "MonitorPoints.h"

#include <vector>

#include "Quaternion.h"

#include "matrix3x3.h"

#include "EditWindow.h"

#include "IKChain.h"

#include "DSimulatorManager.h"

#include <iostream>




#ifdef macintosh

#ifdef __cplusplus

extern "C" {

#endif

#include <assert.h>

#ifdef __cplusplus

}

#endif

#else

#include <assert.h>

#endif



using namespace fltk;

using namespace std;



static char Sep[2] = {(char) 32, '\t'} ;



enum SelectionModes { Link_selection, Joint_selection } ;

enum DirectionMode {

	x_direction,

	y_direction,

	z_direction,

	global_direction,

	up_direction,

	down_direction

};



enum SkeletonCreateMode {

	eChooseParentLink,

	eDefineEndEffector,

	eDefineJointPosition

};





PlugIn* Proxy()

{

	return new ArticulatedObject;

}



PlugIn *ArticulatedObject::create(int argc, char **argv)

{

    ArticulatedObject *f = new ArticulatedObject ;



    if (f == NULL)

    {

		danceInterp::OutputMessage("Cannot allocate memory!\n") ;

		return NULL ;

    }



    return f ;

}



void ArticulatedObject::setName(const char* name)

{

	danceInterp::OutputMessage("Setting name to '%s'\n", name);

	DObject* d = (DObject*) this;

	d->setName(name);

}



ArticulatedObject::ArticulatedObject() : DSystem(),

	m_isShowingInertia( false ),

	m_collisionData( 0 )

{

	m_ArticulatedObjectWindow = NULL;



	m_anim.setArticulatedObject(this);

    density = 1.0 ;

    setName("DummyArticulatedObject") ;

    m_numLinks = 0 ;

    m_numJoints =	0 ;

    m_Mass = 0.0 ;

    treeFlag = FALSE ;		// by default links are	considered independently

				// when	they are drawn

    m_ActiveLink = NULL	;

	m_CheckCollisions = 0;

    m_ActiveJoint = NULL;

    for (int i = 0 ; i < MAX_LINKS ; i++ )

	link[i]	= NULL ;

    for (int i = 0 ; i < MAX_JOINTS	; i++ )

	joint[i] = NULL	;

    setType("ArticulatedObject");

    setBaseType("system");

    //events = new SimulatorEvents ;

	 m_isColliding = false;



	 m_selectMode = false;

	 m_selectMouseX = 0;

	 m_selectMouseY = 0;

	 m_dimensionCalculated = false;

	 setShowingLinks(false);

	 setShowingJoints(false);

	 setShowingSpheres(false);

	 setShowingCollisionGeometry(false);

	 setIsShowingAttachments(false);

	 m_flagChangedSize = true;

	 m_stateSize = 0;



	 for( int i = 0 ; i < MAX_STATE ; i++ )

			m_dstate[i] = 0 ;



	 m_numCollisionData = 0;

	 m_collisionData = NULL;



	 m_numSphereCollisionData = 0;

	 m_sphereCollisionData = NULL;

	 m_pointHierarchy = NULL;

	 m_sphereHierarchy = NULL;



	 //Julia's code BEGIN

	 m_isEmpty = true;

	 firstclick = false;

	 edit_joint = false;

	 cm_valid = false;

	//Julia's code END



	 m_sphereMaterial = dance::MaterialManager->getDefaultMaterial();



//	 m_ikMode = false;

	 m_validIKChain = false;

	 this->setShowActiveIKChain(false);

	 this->setShowActiveIKTarget(false);

	 m_initMousePosition = 1;

	 m_activeIKChain = -1;

	 m_ikChain.clear();

	 

	 interactionMode = NO_mode;



	 resetGlobalTransMatrix();



	 this->setPlayback(true);

	 this->setRecording(true);
	 this->setRecordStep(dance::AllSimulators->getSimulationTimeStep());

	 this->setEditMode(false);



	 this->setLinkColor(.9, .9, .9);

}



ArticulatedObject::~ArticulatedObject()

{

    int	i ;



	for(i=0; i<this->getNumIKChains(); i++)

	{

		delete m_ikChain[i];

	}



    while (getNumLinks())

    {

		i = getNumLinks() ;

		delete link[i - 1] ; // this call reduces m_numLinks, 

		// m_numJoints

		link[i - 1] = NULL ;

    }

    

    

    // this should never execute cause all joints are deleted by

    // the links destructors

    for( i = 0 ; i < getNumJoints() ; i++ )

    {

		delete joint[i]	;

		joint[i] = NULL	;

    }



	m_anim.clear();



	if (m_collisionData != NULL)

	{

		for (int x = 0; x < m_numCollisionData; x++)

			delete m_collisionData[x];

		delete [] m_collisionData;

		m_collisionData = 0;

	}





	if (m_sphereCollisionData != NULL)

	{

		for (int x = 0; x < m_numSphereCollisionData; x++)

			delete m_sphereCollisionData[x];

		delete [] m_sphereCollisionData;

	}



	if (m_pointHierarchy != NULL)

		delete m_pointHierarchy;



	if (m_sphereHierarchy != NULL)

		delete m_sphereHierarchy;



	if (m_ArticulatedObjectWindow != NULL)

		delete m_ArticulatedObjectWindow;

}



void ArticulatedObject::recordState(double time)

{

	KeyFrame* kf = new KeyFrame(this->getStateSize());

	kf->setTime(time);



	// loop through the joints and DOF

	int index = 0;

	Joint** joints = this->getJoints();

	int numJoints = this->getNumJoints();

	for (int  j = 0; j < numJoints; j++)

	{

		int numStates = joints[j]->getStateSize();

		for (int a = 0; a < numStates; a++)

		{

			kf->setParam(index, joints[j]->getState(a));

			index++;

		}

	}

	m_anim.insertKeyFrame(kf);

}



void ArticulatedObject::erasePlayback()

{

	m_anim.clear();

	this->setLastRecordTime(0.0);

}





// saveObj:

//	Saves object with given	format.

//

// filename: Pointer to	filename.

// format  : Format to save under.

// returns: 1 on success, 0 on failure

//

int ArticulatedObject::saveObj( char format[256], char *filename)

{  

    // make the	name the of file to be name/name

    // sdfast format can only be named following this convention

    const char *name = getName();

    char fileRoot[MAX_LINE];

    sprintf(fileRoot,"%s/sdfastobjs/%s/%s",	dance::getDanceDir(),name,name);



    char newFilename[MAX_LINE];

    if( filename == NULL )

    {

		// make the	directory if needed.

		char command[MAX_LINE] ;

		sprintf(command,"cd $env(DANCE_DIR)/sdfastobjs ; catch {mkdir %s}",name);

		danceInterp::ExecuteCommandNoRecord(command);

    }

    else

	{

		strcpy(newFilename, filename) ;

	}

    

    if (strcmp(format,"sdfast") == 0)

	{

		if( filename == NULL )

		{

			// Add .sd extension

			sprintf(newFilename,"%s.sd",fileRoot);

		}

		int result = writeSdFile(newFilename);

		if (result)

		{

			danceInterp::OutputMessage("Wrote sd file '%s'.", newFilename);

			return DANCE_OK;

		}

		else

		{

			danceInterp::OutputMessage("Could not write sd file '%s'.", newFilename);

			return DANCE_ERROR;

		}

    }

    else if (strcmp(format,"state")	== 0)

	{

		if( filename == NULL )

		{

			// Add .Init extension

			sprintf(newFilename,"%s.Init",fileRoot);

		}

		if (saveStateConfig(newFilename) == OK)

		{

			danceInterp::OutputMessage("Wrote state file '%s'.", newFilename);

			return DANCE_OK;

		}

		else

		{

			danceInterp::OutputMessage("Could not write state file '%s'.", newFilename);

			return DANCE_ERROR;

		}

    }

    else if (strcmp(format,"dstate") == 0 ||
             strcmp(format,"initdstate") == 0)

	{
		if( filename == NULL )
		{
			sprintf(newFilename,"%s.dstate",fileRoot);
		}

                if (strcmp(newFilename, "dstate") == 0)
                {
                        saveDStateConfig(newFilename, false);
                }
                else // initdstate
                {
                        saveDStateConfig(newFilename, true);
                }

		if (this->getNumSimulators() == 0)
			return 0;

                /*
		DSimulator* simulator = this->getSimulator(0);

		FILE *fp = fopen(newFilename, "w"); 

		if( fp   == NULL )

		{

			danceInterp::OutputMessage("Cannot open %s.", newFilename);

			return 0 ;

		}

		double *dstate = simulator->GetVel(); 

		int size = simulator->GetVelSize();

		for( int i = 0 ; i < (size - 1)  ; i++ )

			fprintf(fp, "%lf ", dstate[i]) ;

		fprintf(fp, "%lf", dstate[size-1]) ;

		fclose(fp) ;
                */
		return 1 ;

    }

	else if (strcmp(format, "anim") == 0)

	{

		this->getAnimationSequence()->save(filename);

	}

    else if( strcmp(format, "maya") == 0)

		WriteMayaFile(filename) ;

    else if( strcmp(format, "bvh") == 0 )

		WriteBVHFile(filename) ;



	return 0;

}



int ArticulatedObject::setNumLinks(int n)

{

    if(	n > MAX_LINKS)

    {

		danceInterp::OutputMessage("Maximum number of links exceeded.") ;

		return ERR ;

    }

    if(	n < 0)

    {

		danceInterp::OutputMessage("Attempt to set link counter to a negative value.") ;

		return ERR ;

    }

    m_numLinks = n ;



	m_flagChangedSize = true;

    return n ;

}





int ArticulatedObject::setNumJoints(int	n)

{

    if(	n > MAX_JOINTS)

    {

		danceInterp::OutputMessage("Maximum number of joints exceeded.\n") ;

		return ERR ;

    }



    if(	n < 0)

    {

		danceInterp::OutputMessage("Attempt to set joint counter to a negative value.\n") ;

		return ERR ;

    }

    m_numJoints =	n ;



	m_flagChangedSize = true;



    return n ;

}



// Gets called when creating link from an SD/FAST file.

//

void ArticulatedObject::addLink(Link *l)

{

    int	nl = getNumLinks() ;



    if(setNumLinks(nl+1) == ERR)

    {

		danceInterp::OutputMessage("Cannot add  link!  Returning.\n") ;

		return ;

    }

    link[nl] = l ;



	l->setArticulatedObject(this);

    m_Mass += l->getMass() ;



    // assuming	that all the fields in the link	are valid

    // update the parent link of this link about new joint and its

    // new child

    Link * pl ;

    if((pl = l->getParentLink()) != NULL )

    {

		pl->incNumChildLinks(l)	; // updates the pointers too

		// pl->incNumChildJoints()	;

    }

	m_dimensionCalculated = false;



	m_flagChangedSize = true;

}





void ArticulatedObject::addJoint(Joint *j)

{

    int	nj = getNumJoints() ;



    if(setNumJoints(nj+1) == ERR)

    {

		danceInterp::OutputMessage("Cannot add Joint!  Returning.\n") ;

		return ;

    }

    joint[nj] =	j ;



	j->setArticulatedObject(this);



	m_dimensionCalculated = false;



	m_flagChangedSize = true;

	calculateStateIndexMapping();

}



// You can only	remove a leaf link

void ArticulatedObject::removeLink(Link	*l)

{

    int	nl = l->getNumber() ;



	m_flagChangedSize = true;



    if(	(nl < 0	) && (nl >= MAX_LINKS))

    {

		danceInterp::OutputMessage("Index out of bounds 1!\n") ;

		return ;

    }

    if(	l->getNumChildLinks() != 0)

    {

		danceInterp::OutputMessage("Cannot a remove a non-leaf link!\n") ;

		danceInterp::OutputMessage("Link not removed!\n") ;

		return	;

    }

    delete link[nl] ;

    setNumLinks(getNumLinks() -	1) ;

	m_dimensionCalculated = false;

}



void ArticulatedObject::displayLinks(int mode)

{

    int	i ;



	if(	areLinksRelativeToParent() == FALSE)

	{

		glPushName(m_numLinks);

		for( i = 0 ; i < m_numLinks ; i++)

		{

			glLoadName(i); // For picking operations

			link[i]->Display(mode) ;

		}

		glPopName();

	}

	else

		link[0]->displayTree(mode) ;

}



// PROC: displayJoints()

// displays all	joints.	It gets	the position of

// each	joint in world coordinates and then displays it.

//

// mode: 0,  joint centres

//	 1,  inboard and outboard vectors

//	 2,  manipulators

//

void ArticulatedObject::displayJoints(int mode)

{

    glPushName((GLuint) -1);

    for (int i = 0 ; i < m_numJoints ; i++)

    {

		glLoadName(i) ;

		joint[i]->setShowBoundingBox(m_isShowingActiveBox);

		joint[i]->display2(mode, joint[i] == m_ActiveJoint);

    }

    glPopName() ;

    if (mode & JDISPLAY_SELECTION)

		if (m_ActiveJoint)

			m_ActiveJoint->displayManipulators();

    //  glPopName() ;

}



// display:

//	Displays the articulated object.

//

//	linkmode: Modes	for displaying links

//	jointmode: Modes for displaying	joints

//

void ArticulatedObject::output(int mode)

{

	// display IK chains

	if(m_activeIKChain >= 0 && m_ikChain.size() > 0 && this->isShowActiveIKTarget() && this->isShowActiveIKChain() && m_activeIKChain < getNumIKChains())

	{

		glPushAttrib(GL_ENABLE_BIT | GL_LINE_BIT);

		glDisable(GL_LIGHTING);

		glColor3f(0.2f, 0.2f, 0.6f);

		glLineWidth(6.0);

		glBegin(GL_LINE_STRIP);

			Vector j;

			for(int i=0; i<m_ikChain[m_activeIKChain]->getNumJoints(); i++)

			{

				m_ikChain[m_activeIKChain]->getJoint(i)->getPosition(j);

				glVertex3dv(j);

			}

			m_ikChain[m_activeIKChain]->getEndEffector(j);

			glVertex3dv(j);

		glEnd();

		glPopAttrib();

	}



	// display IK target

	if (getInteractionMode() == IK_mode)

	{

		if (this->isShowActiveIKTarget())

		{

			glPushAttrib(GL_ENABLE_BIT);

			glDisable(GL_LIGHTING);

			glColor3f(1.0f, 1.0f, 0.0f);

			glPointSize(1.0);

			glLineStipple(0, 0xF0F0);

			glEnable(GL_LINE_STIPPLE);

			glBegin(GL_LINES);

				glVertex3dv(m_ikEndEffector);

				glVertex3dv(m_ikTarget);

			glEnd();

			glDisable(GL_LINE_STIPPLE);

			glPopAttrib();

		}



/*		glLineWidth(2.0f);

		glBegin(GL_LINES);

			glColor3f(1.0f,0.2f,0.2f);

			glVertex3dv(m_posShoulder);

			Vector temp;

			VecAdd(temp, m_posShoulder, m_posElbow);

			glVertex3dv(temp);

			glColor3f(0.2f,0.2f,1.0f);

			glVertex3dv(temp);

			VecAdd(temp, temp, m_posHand);

			glVertex3dv(temp);

		glEnd();

*/

/*

		glPushAttrib(GL_ENABLE_BIT|GL_CURRENT_BIT);

		glEnable(GL_LIGHTING);

		glMatrixMode(GL_MODELVIEW);

		glPushMatrix();

			glTranslated(m_ikPos[0],m_ikPos[1],m_ikPos[2]);

			glutSolidSphere(0.05, 10, 10);

		glPopMatrix();

		glPopAttrib();

*/

	}

	glPushAttrib(GL_ENABLE_BIT);

   

    // Draw joints first so they can be seen if the links are transparent.

	// first, remove the SELECTION mode

	if (mode & LDISPLAY_SELECTION)

	{

		int filter = 0;

		filter = filter | LDISPLAY_SELECTION;

		mode = mode ^ filter;

	}

	

    displayJoints(mode) ;

    displayLinks(mode) ;



	// draw the attachments if applicable

	if (this->isShowingAttachments())

	{

		glColor3f(1.0f, 1.0f, 0.0f);

		glDisable(GL_LIGHTING);

		glLineWidth(4.0f);

		for (int l = 0; l < this->getNumLinks(); l++)

		{

			Link* link = this->getLink(l);

			Vector localLoc = {0.0, 0.0, 0.0};

			Vector linkLoc;

			link->getWorldCoord(linkLoc, localLoc);



			int loc; 

			ArticulatedObject* attachAO = link->getAttachment(loc);

			if (attachAO)

			{

				// draw a line from the center of the link 

				// to the attached link
				if (loc < 0)
					continue;

				Link* attachedLink = attachAO->getLink(loc);

				Vector attachedLinkLoc;

				attachedLink->getPosition(attachedLinkLoc);

				double dist = VecDist(linkLoc, attachedLinkLoc);

				// source

				glPushMatrix();

				glTranslated(linkLoc[0], linkLoc[1], linkLoc[2]);

				glutWireSphere(dist/10.0, 10, 10);

				glPopMatrix();



				glBegin(GL_LINES);

				glVertex3dv(linkLoc);

				glVertex3dv(attachedLinkLoc);

				glEnd();
				// target

				glPushMatrix();

				glTranslated(attachedLinkLoc[0], attachedLinkLoc[1], attachedLinkLoc[2]);

				glutWireSphere(dist/10.0, 10, 10);

				glPopMatrix();

			}



			DGeometry* geom = link->getAttachmentStatic();

			if (geom)

			{

				// draw a line from the center of the link 

				// to the attached link

				Vector geomPos;

				geom->getCenter(geomPos);

				double dist = VecDist(linkLoc, geomPos);

				// source

				glPushMatrix();

				glTranslated(linkLoc[0], linkLoc[1], linkLoc[2]);

				glutWireSphere(dist/10.0, 10, 10);

				glPopMatrix();

				glBegin(GL_LINES);

				glVertex3dv(linkLoc);

				glVertex3dv(geomPos);

				glEnd();



				// target

				glPushMatrix();

				glTranslated(geomPos[0], geomPos[1], geomPos[2]);

				glutWireSphere(dist/10.0, 10, 10);

				glPopMatrix();

			}

		}

	}



	glPopAttrib();

}   



// PROC: changeToLocal

// changes all transformation matrices from the	world form to the local	tree form

void ArticulatedObject::changeToLocal()

{

    if(	treeFlag == TRUE ) return ;

    treeFlag = TRUE ;

    if(	getNumLinks() >	0)

		link[0]->changeToLocal() ;

}



// PROC: changeToGlobal

// changes all transformation matrices from the	local systems to the global one

void ArticulatedObject::changeToGlobal()

{

    if(	treeFlag != TRUE )

		return ;

    treeFlag = FALSE ;

    if(	getNumLinks() >	0)

		link[0]->changeToGlobal() ;

}





BoundingBox *ArticulatedObject::calcBoundingBox(BoundingBox *b)

{

    int	i ;

    int	n = getNumLinks();

    BoundingBox	b1 ;



    if (n < 1)

		return NULL ;



	if (b)

	{

		b->copy(link[0]->calcBoundingBox(&b1));

		for( i = 1; i < getNumLinks(); i++ )

		{

			b->merge(b,link[i]->calcBoundingBox(&b1));

		}

	}

	return b;

}



// addLink()

// pt1 first point, pt2	second point.

// as a	default	the link is created as a line segment.

// the activeParent and	currentEndEffector are updated!

// Called when creating links interactively.

//

Link *ArticulatedObject::addLink(double	pt1_t[3],double	pt2_t[3])

{   



	m_flagChangedSize = true;



	// see if we can add a new link

	int nl = getNumLinks() ;

    if ( setNumLinks(nl+1) == ERR )

    {

		danceInterp::OutputMessage("addLink: Cannot create link! Returning.\n") ;

		return NULL ;

    }

    // allocate	the link

    link[nl] = new Link(nl) ;

   

	// set up default name

	char linkname[256];

    sprintf(linkname,"link%d",nl);

    link[nl]->setName(linkname);



	// set pointers to dependent instances

	link[nl]->setArticulatedObject(this);

	link[nl]->setGeometry(NULL);



    // fill in the cs parameters

	CoordSystem	cs ;

    Vector cm; 

	link[nl]->getCoordSystem(&cs);

    VecAdd(cm,pt1_t,pt2_t);

    VecNumMul(cm,cm,0.5);

    VecCopy(cs.origin,cm);





    // calculate a coordinate system that corresponds to this two points

    // Contraint: y axis must be aligned with that coordinate system

    VecSubtract(cs.y,pt2_t,pt1_t) ;

    double den, len	= VecLength(cs.y) ;

    if(	len == (double)	0.0)

    {

		setVector(cs.x,-1.0,0.0,0.0) ;	// for the *(-1.0) later on

		setVector(cs.y,0.0,1.0,0.0) ;

    }

    else if( (den = sqrt(cs.y[0]*cs.y[0] + cs.y[1]*cs.y[1])) ==	(double) 0.0)

    {

		setVector(cs.x,0.0,1.0,0.0) ;

		if( (pt1_t[2]-pt2_t[2]) < 0.0)

			setVector(cs.y,1.0,0.0,0.0)	;

		else

			setVector(cs.y,-1.0,0.0,0.0) ;

    }

    else

    {

		double cos_x =	-(cs.y[1])/den ;

		cs.x[0]	= cos_x	;

		cs.x[1]= sqrt(1	- cos_x*cos_x) ;

		cs.x[2]	= 0.0 ;

		if( cs.y[0] > 0.0) cs.x[1] =  fabs(cs.x[1]) ;

		else	cs.x[1]	= -(fabs(cs.x[1])) ;

    }



    // Added in	to make	it a right-handed system

    VecNumMul(cs.x,cs.x,-1.0);



    VecNormalize(cs.y) ;

    VecCrossProd(cs.z,cs.x,cs.y) ;



    VecNormalize(cs.z) ;

    link[nl]->setTransMat(cs);



    // set end effector	for link and articulated object.

    // Must set	the link's transformation matrix first.

    link[nl]->setEndEffectorWC(pt2_t);



    // set parent link and update new active parent

    if (m_ActiveLink != NULL) 

		m_ActiveLink->incNumChildLinks(link[nl]);

    

    link[nl]->setParentLink(m_ActiveLink) ;

    m_ActiveLink = link[nl] ;



    // fill in joint information

    int nj = getNumJoints()	;

    if(setNumJoints(nj+1) == ERR )

    {

		danceInterp::OutputMessage("addLink: no joint can be added\n") ;

		danceInterp::OutputMessage("This is serious. Remove the last link added.\n") ;

		return NULL ;

    }

	if(	link[nl]->getParentLink() != NULL ) // we have a new joint

    {

		// create new ball joint

		joint[nj] = new	Joint;

		joint[nj]->create(nj,J_BALL,link[nl]->getParentLink(),link[nl]) ;

		// set parent joint

		link[nl]->setParentJoint(joint[nj]);

		// set default position

		// joint[nj]->getInboardLink()->getEndEffectorWC(p)  ;

		joint[nj]->setPosition(pt1_t) ;

		joint[nj]->setArticulatedObject( this );

    }

    else // create a free joint	with the ground	assuming ground	at y = 0

    {

		joint[nj] = new	Joint;

		joint[nj]->create(nj,J_FREE,NULL,link[nl]) ;

		link[nl]->setParentJoint(joint[nj]);

		// set position

		joint[nj]->setPosition(pt1_t) ;

		joint[nj]->setArticulatedObject( this );

    }



	m_dimensionCalculated = false;



	calculateStateIndexMapping();



    return link[nl] ;

}



// Moves the joint position and	the parent links above it.

// Must call update state to visually see new configuration.

//

void ArticulatedObject::moveJointAndParents(int	jointID, double	pos[3])

{

	m_flagChangedSize = true;



	// Set joint position

	Joint *jnt = joint[jointID];

	Joint *parentJoint = link[0]->getParentJoint();	

	if (jnt == parentJoint)

	{

		moveJointAndChildren(parentJoint->getJointNum(), pos);

		return;

	}

	// Find new updated outboard (body to joint) vector.

	double linkpos[3];

	jnt->getOutboardLink()->getPosition(linkpos);

	double outb[3];

	VecSubtract(outb,pos,linkpos);



	// Convert back to outboard's frame of reference.

	rotPoint_mat4(outb, jnt->getOutboardLink()->m_invTransMat) ;

	jnt->setBodyToJoint(outb);



	// Now translate topmost joint.



	// Calculate delta change.

	double delta[3];

	double opos[3]; jnt->getPosition(opos);

	VecSubtract(delta,pos,opos);



	// Translate top joint to new translated position.						

	double jpos[3]; parentJoint->getPosition(jpos);

	VecAdd(jpos,jpos,delta);

	moveJointAndChildren(parentJoint->getJointNum(),jpos);

}



// Moves the joint and the children underneath it by a relative	amount

// Must apply transformation on entire articulated figure to correctly update

// state.

//

void ArticulatedObject::moveJointAndChildren(int jointID, double pos[3])

{

	m_flagChangedSize = true;



	Joint* joint = this->joint[jointID];



	// Adjust the inboard joint	vector.

	double inb[3];

	joint->getInbToJoint(inb);



	if (joint->getOutboardLink())

	{ // Transform to world coordinates from inboard frame.

		if (joint->getInboardLink() != NULL)

		{

			transformPoint_mat(inb, joint->getInboardLink()->m_transMat);



			// Subtract of origin of inboard link frame to get actual vector in world space.

			double linkpos[3]; joint->getInboardLink()->getPosition(linkpos);

			VecSubtract(inb,inb,linkpos);

		}

	}

	// Add the delta to the inboard position.

	double opos[3];

	joint->getPosition(opos);	

	double delta[3];

	for	(int i = 0;	i < 3; i++)

	{

		delta[i] = pos[i]-opos[i];

		inb[i] += delta[i];

	}



	if (joint->getInboardLink()) // bring it back to local coordinates of inboard frame.

		rotPoint_mat4(inb, joint->getInboardLink()->m_invTransMat) ;

	joint->setInbToJoint(inb);

}





// set the current end effector	of the object

void ArticulatedObject::setCurrentEndEffector(Vector p)

{

    VecCopy(m_CurrentEndEffector,p) ;

}



void ArticulatedObject::getCurrentEndEffector(Vector p)

{

    VecCopy(p,m_CurrentEndEffector) ;

}



// writeSdFile:

//

// Writes the system description file for sdfast

// returns 1 on success, 0 on failure

//

int ArticulatedObject::writeSdFile(const char *filename)

{  

	FILE *fp;

    if((fp = fopen(filename,"w")) == NULL )

		return 0 ;



	const char *name = getName();

    fprintf(fp,"# This is the system description file for object %s\n", name) ;

    fprintf(fp,"\ngravity = 0 0 0\n") ;

    fprintf(fp,"language = c\n\n") ;

    fprintf(fp,"double\n") ;

    fprintf(fp,"prefix = %s\n\n", name)	;

    for( int i = 0 ; i < m_numLinks ;	i++ )

	if( link[i]->writeSdFile(fp) ==	ERR)

	    return 0;

	

    fclose(fp) ;



    return(1);

}





Joint *ArticulatedObject::getJoint(int index)

{

    if(	(index < 0) || (!(index	< m_numJoints)) )

    {

		danceInterp::OutputMessage("Articulated Object::getJoint(%d). Index out of bounds!\n", index) ;

		return NULL ;

    }

    else return	joint[index] ;

}



// Returns the link given its name.

Link *ArticulatedObject::getLink(const char *name)

{

	Link *wlink = NULL;

	Link **linkList = getLinks();

	for (int i = 0; i < getNumLinks(); i++) {

		if (strcmp(name,linkList[i]->getName()) == 0) {

			wlink = linkList[i];	

			break;

		}

	}

	return (wlink);

}





//		   loadSdfast

// reads in an sdfast file. It follows only the	format printed by

// writeSdFile!!

int ArticulatedObject::loadSdfast(const char *fname)

{

	// remove all links and joints first

	for (int x = this->getNumLinks() - 1; x >= 0; x--)

	{

		Link* l = this->getLink(x);

		this->deleteLinkAndJoint(l, l->getParentJoint());

	}



    FILE *fp = NULL;

    char line[MAX_LINE], tok[MAX_LINE] ;

    int	numLinks_temp =	0 ;

    int	i ;



    m_Mass = 0.0 ;



	char filename[MAX_LINE];

	danceInterp::OutputMessage("Looking for sd/fast definition file '%s'", fname);

    if (fname) 

	fp = fopen(fname,"r");

	



    if( fp == NULL ) {

		



		if (fname == NULL) // Create default name.

			sprintf(filename,"%s/sdfastobjs/%s/%s.sd",dance::getDanceDir(),

				getName(), getName());

		else // Add default path to name.

			sprintf(filename,"%s/sdfastobjs/%s/%s",dance::getDanceDir(),

				getName(), fname);

			danceInterp::OutputMessage("Looking for sd/fast definition file '%s'", filename);



		fp = fopen(filename,"r");

		if( fp == NULL )

		{

			danceInterp::OutputMessage("Error:ArticulatedObject::loadSdfast: "

				"Cannot open %s", filename) ;

			return ERR ;

		}

    }

	else

		strcpy(filename,fname);

		



    int	found =	FALSE ;

    fgets(line,MAX_LINE,fp) ;

    while(!feof(fp) && (found == FALSE))

    {

	fgets(line,MAX_LINE,fp)	;

	sscanf(line,"%s", tok) ;

	if(strcmp(tok,"prefix")	== 0)

	{

	    sscanf(line,"prefix	= %s", tok) ;

	    found = TRUE ;

	   // setName(tok);

	}

    }



    if(	found == FALSE )

    {

	danceInterp::OutputMessage("Prefix not found! Using TestObj\n") ;

	//setName("TestObj");

    }



    // do a first pass to find the number of links



    while(!feof(fp))

    {

	fgets(line,MAX_LINE,fp)	;

	sscanf(line,"%s", tok) ;

	if(strcmp(tok,"body") == 0)

	    numLinks_temp++ ;

    }

    fclose(fp) ;



    fp = fopen(filename,"r") ;

    Link *l ;

    for( i = 0 ; i < numLinks_temp ; i++ )

    {

		l = new	Link(i)	;

		l->setArticulatedObject(this);

		if( l == NULL )

		{

			danceInterp::OutputMessage("Cannot allocate link!\n") ;

			return ERR;

		}

		if( l->readSdfast(fp) == NULL)

		{

			danceInterp::OutputMessage("Cannot read link number %d!\n",i) ;

			return ERR ;

		}

		addLink(l) ;

    }



    fclose(fp) ;

	dance::AllViews->postRedisplay();

    danceInterp::OutputMessage("Object loaded successfully.\n") ;

	if (this->m_ArticulatedObjectWindow != NULL)

		this->m_ArticulatedObjectWindow->updateGUI();

    return OK ;

}



//	     read the state from a file

int ArticulatedObject::loadStateConfig(const char *fname)

{

    char filename[MAX_LINE], line[MAX_LINE] ;

    int	i, nj ;

    char *s ;

    double st ;



    if (fname)

	{

		strcpy(filename,fname);

	}

    else

	{

   		// use default file

		sprintf(filename,"%s/sdfastobjs/%s/%s.Init", dance::getDanceDir(),getName(),getName()) ;

	}

    

    FILE *fp = fopen(filename, "r") ;

    if( fp == NULL )

    {

		danceInterp::OutputMessage("Cannot open %s", fname) ;

		return ERR ;

    }

    fgets(line,MAX_LINE,fp) ;

    // eat comments and	blank lines

    while((!feof(fp)) && ((line[0] == '#') || (line[0] == '\n')) )

    {

		fgets(line,MAX_LINE,fp)	;

    }



    // set all link transformation matrices to the indentity matrix

    // cause updateStateConfig does a change to local. If the matrices

    // have been corrupted (i.e bad simulation, we can never get the

    // state back.

    for( i = 0 ; i < m_numLinks ; i++ )

    {

		setIdentMat(&link[i]->m_transMat[0][0],4) ;

		setIdentMat(&link[i]->m_invTransMat[0][0],4) ;

    }



    for( nj = 0	; nj < m_numJoints ; nj++ )

    {
		if( feof(fp) && (joint[nj]->getJointType() != J_WELD) )

		{

			danceInterp::OutputMessage("Problem loading joint information from '%s': joint %d has no joint state.\n", fname, nj) ;

			fclose(fp);

			return ERR ;

		}

		for( i = 0 ; i < joint[nj]->getStateSize() ; i++ )

		{

		   

			if(	i == 0)

			{

				if( (s = strtok(line, Sep)) == NULL )

				{

			                danceInterp::OutputMessage("Problem loading joint information from '%s': joint %d needs %d states.\n", fname, nj, joint[nj]->getStateSize());
					fclose(fp);

					return ERR ;

				}

			}

			else if( (s	= strtok(NULL, Sep)) == NULL )

			{
                                danceInterp::OutputMessage("Problem loading joint information from '%s': joint %d needs %d states, has only %d.\n", fname, nj, joint[nj]->getStateSize(), i);

				fclose(fp);



				return ERR ;

			}

			sscanf(s,"%lf",&st)	;

			joint[nj]->setState(i,st) ;

		}

		line[0]	= '\0' ;

		fgets(line,MAX_LINE,fp)	;

		//Added to handle more generic files. Oct., 05 MN

		// eat comments and	blank lines

		while((!feof(fp)) && ((line[0] == '#') || (line[0] == '\n')) )

		{

			fgets(line,MAX_LINE,fp)	;

		}



    }



    fclose(fp) ;

    updateStateConfig(); // Update entire articulated object's joints.



    return OK ;

}











// saveStateConfig:

// save	the state on file. Depending on	the type of joint

// for each joint a quaternion or 1,2,3	angles are saved.

// Also	the global position is saved too.

//

// returns 1 on success 0 on failure

int ArticulatedObject::saveStateConfig(const char *filename)

{

    FILE *fp;

    if((fp = fopen(filename,"w")) == NULL )

	return 0;

    

    const char *name = getName();

    fprintf(fp,"# This is the configuration file for object %s\n", name) ;

    fprintf(fp,"# Number of Joints: %d\n", m_numJoints) ;

    fprintf(fp,"\n") ;

    for(int i = 0 ; i < m_numJoints	; i++ )

    {

	for(int j =	0 ; j <	joint[i]->getStateSize() ; j++ )

	{

	    if( j != 0) fprintf(fp," ") ;

	    fprintf(fp,"%lf", joint[i]->getState(j)) ;

	}

	fprintf(fp,"\n") ;

    }

    fclose(fp);

    

    return OK ;

}



int	ArticulatedObject::loadDStateConfig(const char* fname, bool
useInitVelocities)

{

	FILE *fp = fopen(fname, "r") ;

  	if( fp == NULL )

  	{

  		danceInterp::OutputMessage("Cannot open %s", fname) ;

  		danceInterp::OutputMessage("Using 0 velocities") ;

  		return DANCE_ERROR ;

  	}



	int stateSize = this->getStateSize();

	double* val = new double[stateSize];

  	for( int i = 0 ; i < stateSize; i++ )

  	{

  		if( fscanf(fp, "%lf", &val[i]) != 1 )

  		{

  			danceInterp::OutputMessage("Error reading velocity file.") ;

  			fclose(fp) ;

  			return DANCE_ERROR ;

  		}

  	}



	// now assign these velocities to the joints

	int count = 0;

	Joint** joints = this->getJoints();

	for (int j = 0; j < this->getNumJoints(); j++)

	{

		joints[j]->setHasVelocity(true);

		for (int s = 0; s < joints[j]->getStateSize(); s++)

		{
                        if (useInitVelocities)
        			joints[j]->setInitDState(s, val[count]);
                        else
			        joints[j]->setDState(s, val[count]);

			count++;

		}

	}

	

	delete val;

  	danceInterp::OutputMessage("Read new velocities from file %s.", fname) ;

  	fclose(fp) ;



	return OK;

}



int	ArticulatedObject::saveDStateConfig(const char* fname, bool useInitVelocities)

{

    FILE *fp = fopen(fname, "w") ; 

	if (fp   == NULL )

	{

		danceInterp::OutputMessage("Cannot open %s.", fname) ;

	    return 0 ;

	}



	// are the velocities present?

	double* simdstate = NULL;

	DSimulator* simulator = this->getSimulator(0);

	if (simulator != NULL)

		simdstate = simulator->GetVel() ;



	double* dstate = new double[this->getStateSize()];





	Joint** joints = this->getJoints();

	int count = 0;

	for (int j = 0; j < this->getNumJoints(); j++)

	{

		for (int d = 0; d < joints[j]->getNumDof(); d++)

		{
                        if (useInitVelocities)
                        {
				dstate[count] = joints[j]->getInitDState(d);
                        } 
                        else if (joints[j]->hasVelocity())
			{

				dstate[count] = joints[j]->getDState(d);

			}

			else // retrieve from simulator if present

			{

				if (simulator != NULL && (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_PAUSED || dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_RUNNING))

				{

					dstate[count] = simdstate[count];

				}

				else

				{

					dstate[count] = 0.0;

				}

			}

			count++;

		}

	}



	// pad zeroes for any free joint

	while (count < this->getStateSize())

	{

		dstate[count] = 0.0;

		count++;

	}



	for( int i = 0 ; i < count - 1; i++ )

	    fprintf(fp, "%lf ", dstate[i]) ;

	fprintf(fp, "%lf", dstate[count - 1]) ;

	fclose(fp) ;



	delete [] dstate;

    

    return OK ;

}



int	ArticulatedObject::saveDStateConfigExplicitVelocities(char* fname)

{

    FILE *fp = fopen(fname, "w") ; 

	if (fp   == NULL )

	{

		danceInterp::OutputMessage("Cannot open %s.", fname) ;

	    return 0 ;

	}



	// get the velocities from those explicitly set in the joints

	double* dstate = new double[this->getStateSize()];





	Joint** joints = this->getJoints();

	int count = 0;

	for (int j = 0; j < this->getNumJoints(); j++)

	{

		for (int d = 0; d < joints[j]->getNumDof(); d++)

		{

			if (joints[j]->hasVelocity())

			{

				dstate[count] = joints[j]->getDState(d);

			}

			else

			{

				dstate[count] = 0.0;

			}

			count++;

		}

	}



	// pad zeroes for any free joint

	while (count < this->getStateSize())

	{

		dstate[count] = 0.0;

		count++;

	}



	for( int i = 0 ; i < count - 1; i++ )

	    fprintf(fp, "%lf ", dstate[i]) ;

	fprintf(fp, "%lf", dstate[count - 1]) ;

	fclose(fp) ;



	delete [] dstate;

    

    return OK ;

}





// UpdateState: 

//      Sets the state of all joints and then calls updateStateConfig

//      to calculate the transformation matrices etc.

// Assumes that the parameters of all joints are grouped together in

// sequence. This is not the case if state comes directly from sdfast

// where the fourth quaternion parameter of the free joint is at the end.

void ArticulatedObject::UpdateState(double *state)

{ 

	int count = 0 ;

    for( int  i = 0 ; i < getNumJoints() ; i++ )

	for( int j = 0 ; j < joint[i]->getStateSize() ; j++)

	{

	    joint[i]->setState(j,state[count]) ;

	    count++ ;

	}



    updateStateConfig() ;

}



// updateStateConfig:

//	Uses the already loaded	 information to	assume

//	the initial position.

//

//

void ArticulatedObject::updateStateConfig(int index)

{



    if (index == -1)

	{

    		changeToLocal() ;

		for (int i = 0 ; i < m_numJoints ; i++ )

			joint[i]->applyTransformation() ;

    		changeToGlobal();

	}

	else

	{

    		link[index]->changeToLocal();

		joint[index]->applyTransformation() ;

    		link[index]->changeToGlobal();

	}





	// added by achu: 9-16-2003

	// tells list of dependent modifiers to change their states.

	if (m_influencedModifiers.size() > 0)

	{

		vector<DModifier*>::iterator iter;

		for (iter = m_influencedModifiers.begin(); iter != m_influencedModifiers.end(); iter++)

		{

			(*iter)->modify();

		}

	}

}



int ArticulatedObject::commandPlugIn(int argc, char **argv)

{

	int ret = DSystem::commandPlugIn(argc, argv);

	if (ret == DANCE_OK || ret == DANCE_ERROR)

		return ret;



    if (strcmp(argv[0],"save") == 0)

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("USAGE: save <format> [<filename>]\n",(char *)NULL);

			return DANCE_ERROR;

		}

		char *filename = NULL;

		if (argc == 3)

			filename = argv[2];

		int ret = saveObj(argv[1],filename);

		if (ret) 

			return DANCE_OK;

		else

			return DANCE_ERROR;

    }

    else if (strcmp(argv[0],"load") == 0)

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("USAGE: load <format> <filename>\n");

			return DANCE_ERROR;

		}

		char *file ;

		if( argc == 2 ) 

		    file = NULL ;

		else 

		    file = argv[2] ;

		if (strcmp(argv[1],"sdfast") ==	0)

			loadSdfast(file);

		else if	(strcmp(argv[1],"state") == 0)

			loadStateConfig(file);

		else if	(strcmp(argv[1],"dstate") == 0)

			loadDStateConfig(file, false);

		else if	(strcmp(argv[1],"initdstate") == 0)

			loadDStateConfig(file, true);

		else if ( strcmp(argv[1], "bvh") == 0 )

		{

			this->m_anim.load(argv[2]);

		}

		else if ( strcmp(argv[1], "anim") == 0 )

		{

			this->m_anim.load(file) ;

			this->setPlayback(true);

			this->setLastRecordTime(this->getAnimationSequence()->getEndTime());

			dance::AllSimulators->calculatePlaybackEndTime();

		}

		else 

		{

			danceInterp::OutputMessage("USAGE: load sdfast|state|dstate|bvh <filename>");

			return DANCE_ERROR ;

		}



		if (this->m_ArticulatedObjectWindow != NULL && this->m_ArticulatedObjectWindow->visible())

			this->m_ArticulatedObjectWindow->updateGUI();

		

		dance::AllViews->postRedisplay();

		return DANCE_OK;

	}

	else if (strcmp(argv[0],"show") == 0)

	{

		if (argc >= 2)

		{

			if (strcmp(argv[1],"links") == 0)

			{

				string str = "";

				for (int i=0; i < getNumLinks(); i++) 

				{

					if (i > 0)

						str.append(" ");

					str.append(link[i]->getName());

				}

				danceInterp::OutputResult("%s", str.c_str());

			}

			else if (strcmp(argv[1],"joints") == 0)

			{

				for (int i=0; i < getNumJoints(); i++)

				{

				    if( i != 0 ) danceInterp::OutputResult("%c", 32) ;

				    danceInterp::OutputResult("%s", joint[i]->getName());

				}

			}



			else if (strcmp(argv[1],"number_of_joints") == 0)

			{

			    danceInterp::OutputResult("%d", getNumJoints()) ;

			}

			else if (strcmp(argv[1],"number_of_links") == 0)

			{

				int x = getNumLinks();

			    danceInterp::OutputResult("%d", x) ;

			}

			else if (strcmp(argv[1],"max_dimensions") == 0)

			{

				BoundingBox b ;

				Vector dim ;

				calcBoundingBox(&b) ;

				b.getDimensions(dim) ;

				danceInterp::OutputResult("%lf %lf %lf\n", dim[0], dim[1], dim[2]) ;

			}

			else if (strcmp(argv[1], "monitor_points") == 0)

			{

				if (argc > 2)

				{

					if (strcmp(argv[2], "on") == 0)

					{

						for (int x = 0; x < this->m_numLinks; x++)

						{

							link[x]->setDisplayMonitorPoints(true);

						}

						danceInterp::OutputMessage("Monitor points for system %s will now be shown.", this->getName());

						return DANCE_OK;

					}

					else if (strcmp(argv[2], "off") == 0)

					{

						for (int x = 0; x < this->m_numLinks; x++)

						{

							link[x]->setDisplayMonitorPoints(false);

						}

						danceInterp::OutputMessage("Monitor points for system %s will not be shown.");

						return DANCE_OK;

					}

					else

					{

						danceInterp::OutputMessage("Usage: system %s show monitor_points <on|off>");

						return DANCE_ERROR;

					}

				}

			}

			else

			{

			     danceInterp::OutputResult("usage: show links|joints|"

						    "number_of_links|"

						    "number_of_joints|"

						    "max_dimensions.") ;

			}

		}

		return DANCE_OK;

	}

    else if (strcmp(argv[0],"setstate") == 0)

	{

		if (argc < 3)

		{

			danceInterp::OutputMessage("Usage: dance.system(\"%s\", \"setstate\", <statenum>, <statevalue>\")");

			return DANCE_ERROR;

		}

		int stateNum = atoi(argv[1]);

		if (stateNum < 0 || stateNum >= this->getStateSize())

		{

			danceInterp::OutputMessage("State %d is not a valid state for system %s.", stateNum, this->getName());

			return DANCE_ERROR;

		}

		double val = atof(argv[2]);

		this->setState(stateNum, val);

		danceInterp::OutputMessage("State %d has been set to %f", stateNum, val);

		dance::Refresh();

		return DANCE_OK;

	}

	else if (strcmp(argv[0],"update") == 0)

	{

		updateStateConfig(); // Update configuration of object.

		return DANCE_OK;

	}

	else if (strcmp(argv[0], "transparency") == 0 )

	{

		if( argc == 1 )

		{

			danceInterp::OutputMessage("usage: transparency <value>") ;

			danceInterp::OutputMessage("where value is between 0, 1") ;

			return DANCE_ERROR;

		}

		double tr = atof(argv[1]) ;

		for( int i = 0 ; i < getNumLinks() ; i++ )

		{

			link[i]->setTransparency((float) tr);

		}

	}

	else if( strcmp(argv[0], "link")  == 0 )

	{

		if (argc == 1)

		{

			danceInterp::OutputMessage("USAGE: link <name|number>\n") ;

			return DANCE_ERROR;

		}

		// Get link number

		int link; 

		int isNumber = sscanf(argv[1],"%d",&link);



		Link **linkList	= getLinks();

		if (linkList ==	NULL)

		{

			danceInterp::OutputMessage("ERROR: No links existing for this system.\n");

			return DANCE_ERROR;

		}



		// Get the link.

		Link *wlink = NULL;

		if (isNumber != 1)

		{ // Could be a name string.

			wlink = getLink(argv[1]);

			if (wlink == NULL)

			{

				danceInterp::OutputMessage("ERROR: No link exists with given name '%s'.", argv[1]);

				return DANCE_ERROR;

			}

		}

		else

		{

			// check if the	object has such	a link

			if (link >= getNumLinks() || link < 0)

			{	

	    		danceInterp::OutputMessage("ERROR: Link index does not exist.\n");

	    		return DANCE_ERROR;

			}

			wlink = linkList[link];

        }

		return wlink->Command(argc-2, argv+2) ;

    }

    else if (strcmp(argv[0], "root") == 0)

    {

		if (getNumLinks() > 0)

		{

		    Link **linkList = getLinks();

		    danceInterp::OutputResult("%s",linkList[0]->getName());

		}

		else 

			danceInterp::OutputResult("");

		return DANCE_OK;

    }

    else if( strcmp(argv[0], "joint") == 0 )

    {

        int joint; 

		int isNumber = sscanf(argv[1],"%d",&joint);

	

		Joint **jointList = getJoints();

		if (jointList == NULL)

		{

			danceInterp::OutputMessage("ERROR: No joints existing for this object.\n");

			return DANCE_ERROR;

		}

	

		// Get the link.

		Joint *wjoint = NULL;

		if (isNumber != 1) { // Could be a name string.

	    

	    wjoint = getJoint(argv[1]);

	    if (wjoint == NULL)

		{

			danceInterp::OutputMessage("ERROR: No joint exists with the given name '%s'.", argv[1]);

			return DANCE_ERROR;

	    }

		}

		else

		{

			if (joint < 0 || joint >= getNumJoints())

			{

				danceInterp::OutputMessage("ERROR: Joint index does not exist.");

				return DANCE_ERROR;

			}

			wjoint = jointList[joint];

		}

		return wjoint->Command(argc-2, argv+2);

    }

    

    //    else if( strcmp(argv[0], "make_sdfast") == 0 )

    //{

    //		SdfastSimul::makeCompile(getName());

    //		return DANCE_OK;

    //}

    //else if( strcmp(argv[0], "simul") == 0 )

    //{

    //	simul(argc-1, &argv[1]);

    //	return DANCE_OK;

    //}

    else if( strcmp(argv[0], "combine") == 0 )

    {

		return combineLinks(argc-1, &argv[1]) ;

    }

    else if (strcmp(argv[0], "usage") == 0 )

    {

		danceInterp::OutputMessage("USAGE: object <name> load|save|link|scale"

		      "|make_sdfast\n") ;

		return DANCE_OK;

    }

	else if (strcmp(argv[0], "show_spheres") == 0 )

    {

		this->setShowingSpheres(true);

		dance::AllViews->postRedisplay();

		return DANCE_OK;

    }

	else if (strcmp(argv[0], "hide_spheres") == 0 )

    {

		this->setShowingSpheres(false);

		dance::AllViews->postRedisplay();

		return DANCE_OK;

    }

	else if (strcmp(argv[0], "show_collision_geometry") == 0 )

    {

		this->setShowingCollisionGeometry(true);

		dance::AllViews->postRedisplay();

		return DANCE_OK;

    }

	else if (strcmp(argv[0], "hide_collision_geometry") == 0 )

    {

		this->setShowingCollisionGeometry(false);

		dance::AllViews->postRedisplay();

		return DANCE_OK;

    }

	else if (strcmp(argv[0], "show_inertia") == 0 )

	{

		setIsShowingInertia( true );

		dance::AllViews->postRedisplay();

		return DANCE_OK;

	}

	else if (strcmp(argv[0], "hide_inertia") == 0 )

	{

		setIsShowingInertia( false );

		dance::AllViews->postRedisplay();

		return DANCE_OK;

	}

	else if (strcmp(argv[0], "load_spheres") == 0 )

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("Usage: system %s load_spheres <file>", this->getName());

			return DANCE_ERROR;

		}

		if (this->loadSpheres(argv[1]))

		{

			danceInterp::OutputMessage("Spheres loaded for articulated object %s", this->getName());

			return DANCE_OK;

		}

		else

		{

			danceInterp::OutputMessage("Spheres not loaded for articulated object %s, problem loading spheres from file '%s'.", this->getName(), argv[1]);

			return DANCE_ERROR;

		}

	}

	else if (strcmp(argv[0], "save_spheres") == 0 )

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("Usage: system %s save_spheres <file>", this->getName());

			return DANCE_ERROR;

		}

		if (this->loadSpheres(argv[1]))

		{

			danceInterp::OutputMessage("Spheres saved for articulated object %s into file '%s'.", this->getName(), argv[1]);

			return DANCE_OK;

		}

		else

		{

			danceInterp::OutputMessage("Spheres not saved for articulated object %s, problem saving spheres to file '%s'.", this->getName(), argv[1]);

			return DANCE_ERROR;

		}

	}

	else if (strcmp(argv[0], "sphere_material") == 0 )

	{

		if (argc < 2)

		{

			danceInterp::OutputMessage("Usage: system %s sphere_material <material>", this->getName());

			return DANCE_ERROR;

		}

		Material* sphereMaterial = dance::MaterialManager->getMaterialbyName(argv[1]);

		if (sphereMaterial == NULL)

		{

			danceInterp::OutputMessage("Spheres material %s was not found in the material manager.", argv[1]);

			return DANCE_ERROR;

		}



		this->setSphereMaterial(sphereMaterial);

		danceInterp::OutputMessage("Sphere material is now %s", sphereMaterial->getMaterialName());

		dance::AllViews->postRedisplay();

		return DANCE_OK;

	}

	else if (strcmp(argv[0], "create_ik") == 0)

	{

		if (argc != 2)

		{

			danceInterp::OutputMessage("Usage: dance.system(\"%s\", \"create_ik\", \"<ik_name>\")", this->getName());

			return DANCE_ERROR;

		} else {

			createIKChain(argv[1]);

		}

		return DANCE_OK;

	}

	else if(strcmp(argv[0], "activate_ik") == 0)

	{

		if(argc != 2)

		{

			danceInterp::OutputMessage("Usage: dance.system(\"%s\", \"activate_ik\", \"<ik_name>\")", this->getName());

			return DANCE_ERROR;

		}

		else

		{

			int i;

			for(i=0; i<getNumIKChains(); i++)

				if(strcmp(m_ikChain[i]->getName(), argv[1]) == 0)

					break;



			if(getNumIKChains() < 0 || i >= getNumIKChains())

			{

				danceInterp::OutputMessage("%s is an invalid IKChain, no chains were activated", argv[1]);

				return DANCE_ERROR;

			}

			else

			{

				setActiveIKChain(i);

				activateIKChain();



				if(this->m_ArticulatedObjectWindow != NULL)

					this->m_ArticulatedObjectWindow->updateGUI();

			}

		}

		return DANCE_OK;

	}

	else if(strcmp(argv[0], "ik") == 0)

	{

		if(argc != 4)

		{

			danceInterp::OutputMessage("Usage: dance.system(\"%s\", \"ik\", \"<ik_name>\", \"add_joint\", \"<joint_name>\")", this->getName());

			return DANCE_ERROR;

		}

		else

		{

			Joint *joint = this->getJoint(argv[3]);

			int id;

			for(id=0; id<getNumIKChains(); id++) {

				if(strcmp(m_ikChain[id]->getName(), argv[1]) == 0)

					break;

			}

			if(joint == NULL) {

				danceInterp::OutputMessage("%s is not a valid joint.", argv[3]);

				return DANCE_ERROR;

			}

			else if (id >= getNumIKChains()) {

				danceInterp::OutputMessage("%s is not a valid IK Chain.", argv[1]);

				return DANCE_ERROR;

			} else {

				if(strcmp(argv[2], "add_joint") == 0) {

					m_ikChain[id]->addJoint(joint);

					danceInterp::OutputMessage("Joint %s was successfully added to IK Chain %s.", joint->getName(), m_ikChain[getNumIKChains()-1]->getName());

				}

//				else if(strcmp(argv[2], "<other commands with this format>") == 0)

				else {

					danceInterp::OutputMessage("Usage: dance.system(\"%s\", \"ik\", \"<ik_name>\", \"add_joint\", \"<joint_name>\")", this->getName());

					return DANCE_ERROR;

				}

			}

		}

		return DANCE_OK;

	}

	else if (strcmp(argv[0], "remove_ik") == 0)

	{

		if(argc != 2)

		{

			danceInterp::OutputMessage("Usage: dance.system(\"%s\", \"remove_ik\", \"<ik_name>\")", this->getName());

			return DANCE_ERROR;

		}

		else

		{

			if(getNumIKChains() > 0)

			{

				return removeIKChain(argv[1]);

			}

			else

			{

				danceInterp::OutputMessage("There are no IK Chains to remove.");

				return DANCE_ERROR;

			}



			/** old script action

			vector<IKChain*>::iterator iter;

			int i=0;

			bool removed = false;

			for(iter = m_ikChain.begin(); iter != m_ikChain.end(); iter++, i++) {

				if(strcmp((*iter)->getName(), argv[1]) == 0) {

					m_ikChain[i]->reset();

					delete m_ikChain[i];

					danceInterp::OutputMessage("IK Chain %s was successfully removed.", (*iter)->getName());

					removed = true;

					break;

				}

			}



			if(!removed) {

				danceInterp::OutputMessage("%s is not a valid IK Chain, no IK Chains were removed.", argv[1]);

				return DANCE_ERROR;

			} else {

				if(this->m_ArticulatedObjectWindow != NULL)

					this->m_ArticulatedObjectWindow->updateGUI();

			}

			**/

		}

		return DANCE_OK;

	}

	else if (strcmp(argv[0], "reset_velocities") == 0)

	{

		int numJoints = this->getNumJoints();

		for (int j = 0; j < numJoints; j++)

		{

			Joint* joint = this->getJoint(j);

			for (int s = 0; s < joint->getNumDof(); s++)

			{

				joint->setDState(s, 0);

			}

		}



	}

	else 

	{

		danceInterp::OutputMessage("USAGE: object <name> load|save|link|scale"

		      "|make_sdfast\n") ;

		return DANCE_ERROR;

	}



    return DANCE_CONTINUE;

}



// start stop or re-start the simulation

// Also	makes the shared object	using the system function

// when	a simulation starts

//  int ArticulatedObject::simul(int argc, char **argv)

//  {

//      if( isImobile == TRUE ) return DANCE_OK ;



//      if(	argc < 1 )

//      {

//  	danceInterp::OutputMessage("USAGE: simul start [<dt>]|stop|pause|cont|"

//  		      "assemble|static|initvel|steady|set\n") ;

//  	return DANCE_ERROR ;

//      }

//      if( strcmp(argv[0],"load") == 0 )

//      {

//  	LoadSimulator(interp) ;

//      }

//      else if (strcmp(argv[0],"start")	== 0 ) // start new simulation

//      {

//  	// if no simulator present load it

//  	if( simulator == NULL )	

//  	{

//  	    if( LoadSimulator(interp) == DANCE_ERROR )

//  		return DANCE_ERROR ;

//  	}

//  	isSimul	= TRUE ;

//  	// set state from joint	configuration of object

//  	SdfastSimul *sim = simulator;



//  	sim->time = 0.0 ;

//  	if( simulator->init() == ERR )

//  	{

//  	    danceInterp::OutputMessage("Error in init()") ;

//  	    isSimul = FALSE ;

//  	    delete simulator ;

//  	    simulator = NULL ;

//  	    return DANCE_ERROR ;

//  	}

//  	if( SetParamAndInitSimul(interp, argc-1, &argv[1]) == DANCE_ERROR )

//  	{

//  	    isSimul = FALSE ;

//  	    danceInterp::OutputMessage("Problem starting the simulation.") ;

//  	}

	

//      }

//      else if (strcmp(argv[0],"stop") == 0 ) // stop simulation and delete the	simulator

//      {

//  	isSimul	= FALSE	;

//         	if( simulator != NULL )

//  	{

//  	    simulator->EndSimul(this) ;

//  	    //delete simulator ;

//  	    //simulator = NULL ;

//  	}

//      }

//      else if (strcmp(argv[0],"pause") ==	0 ) // pause	simulation

//      {

//  	isSimul	= FALSE	;

//      }

//      else if ((strstr(argv[0],"assemble") != NULL)

//  	     ||	 (strstr(argv[0],"static") != NULL)

//  	     ||	 (strstr(argv[0],"initvel") != NULL)

//  	     ||	 (strstr(argv[0],"steady") != NULL)

//  	     ) // assemble and static analysis

//      {

//  	if (simulator != NULL) {

//  	    SdfastSimul	*sim = simulator;

//  	    SdfastSimul::CurrentSimulObject = sim->ao ;

//  	    sim->setStateVectorFromJoints();

//  	    sim->assemblyAnalysis();

//  	    if ( (strstr(argv[0],"initvel") != NULL)

//  		 ||(strstr(argv[0],"steady") !=	NULL) )

//  		sim->initVelocityAnalysis();

//  	    if (strstr(argv[0],"static") != NULL)

//  		sim->staticAnalysis();

//  	    if (strstr(argv[0],"steady") != NULL)

//  		sim->steadyStateAnalysis();

//  	    sim->setJointsFromStateVector();

//  	    updateStateConfig();

//  	}

//      }

//      else if (strcmp(argv[0],"cont") == 0 )

//      {

//  	if( simulator == NULL )

//  	    danceInterp::OutputMessage("No existing simulator, use 'start'\n") ;

//  	else

//  	{

//  	    // In case simulation configuration	was changed by editor,

//  		// update the SD/FAST state.



//  	    SdfastSimul	*sim = simulator;

//  	    sim->setStateVectorFromJoints();

//  	    sim->assemblyAnalysis();



//  	    isSimul = TRUE ;

//  	}

//      }



//      return DANCE_OK ;

//  }





//  int ArticulatedObject::SetParamAndInitSimul(int argc, char	**argv)

//  {



//      int new_vel = FALSE ;



//      if(	simulator == NULL )

//      {

//  	danceInterp::OutputMessage("Simulator not present!! Cannot set the parameters!\n") ;

//  	return DANCE_ERROR ;

//      }

//      while(argc)

//      {

//  	if( strcmp(argv[0], "dt") == 0)

//  	{

//  	    if(	argc < 2 )

//  	    {

//  		danceInterp::OutputMessage("ERROR: expected: dt <dt>\n");

//  		return DANCE_ERROR ;

//  	    }

//  	    if(	!isdigit(argv[1][0]) )

//  	    {

//  		danceInterp::OutputMessage("ERROR: expected dt <dt>\n");

//  		continue ;

//  	    }

//  	    simulator->dt = atof(argv[1]) ;

//  	    argc -= 2 ;

//  	    argv += 2 ;

//  	}

//  	else if( strcmp(argv[0], "integ") == 0)

//  	{

//  	    if(	argc < 2 )

//  	    {

//  		danceInterp::OutputMessage("ERROR: expected: integ 0|<value>\n");

//  		return DANCE_ERROR ;

//  	    }

//  	    simulator->m_integrator = atoi(argv[1]) ;

//  	    argc -= 2 ;

//  	    argv += 2 ;

//  	}

//  	else if( strcmp(argv[0], "tol") == 0)

//  	{

//  	    if(	argc < 2 )

//  	    {

//  		danceInterp::OutputMessage("ERROR: expected: tol <tol>\n");

//  		return DANCE_ERROR ;

//  	    }

//  	    if(	!isdigit(argv[1][0]) )

//  	    {

//  		danceInterp::OutputMessage("ERROR: expected tol <tol>\n");

//  		continue ;

//  	    }

//  	    simulator->tol = atof(argv[1]) ;

//  	    argc -= 2 ;

//  	    argv += 2 ;

//  	}

//  	else if( strcmp(argv[0], "ctol") == 0)

//  	{

//  	    if(	argc < 2 )

//  	    {

//  		danceInterp::OutputMessage("ERROR: expected: ctol <ctol>\n");

//  		return DANCE_ERROR ;

//  	    }

//  	    if(	!isdigit(argv[1][0]) )

//  	    {

//  		danceInterp::OutputMessage("ERROR: expected ctol <ctol>\n");

//  		argc -= 1 ;

//  		argv += 1 ;



//  		continue ;

//  	    }

//  	    simulator->ctol = atof(argv[1]) ;

//  	    argc -= 2 ;

//  	    argv += 2 ;

//  	}

//  	else if( strcmp(argv[0], "f") == 0 )

//  	{

//  	    danceInterp::OutputMessage("Using fixed time step\n") ;

//  	    simulator->fixedStep = TRUE	;

//  	    argc -= 1 ;

//  	    argv += 1 ;

//  	}

//  	else if( strcmp(argv[0], "v") == 0 )

//  	{

//  	    danceInterp::OutputMessage("Using variable time step\n") ;

//  	    simulator->fixedStep = FALSE ;

//  	    argc -= 1 ;

//  	    argv += 1 ;

//  	}

//  	else if( strcmp(argv[0], "end")	== 0)

//  	{

//  	    if(	argc < 2 )

//  	    {

//  		danceInterp::OutputMessage("ERROR: expected: dt <dt>\n");

//  		return DANCE_ERROR ;

//  	    }



//  	    if(	!isdigit(argv[1][0]) )

//  	    {

//  	        danceInterp::OutputMessage("ERROR: expected dt <dt>\n");

//  		argc -= 1 ;

//  		argv += 1 ;

//  		continue ;

//  	    }

//  	    simulator->end = atof(argv[1]) ;

//  	    argc -= 2 ;

//  	    argv += 2 ;

//  	}

//  	else if( (strcmp(argv[0], "sstate") == 0 ) || (strcmp(argv[0], "dstate") == 0 ) )

//  	{

//  	    // read the velocities from the given file

//  	    if( argc > 1 )

//  	    {

//  		FILE *fp = fopen(argv[1], "r") ;

//  		if( fp == NULL )

//  		{

//  		    danceInterp::OutputMessage("Cannot open %s", argv[1]) ;

//  		    danceInterp::OutputMessage("Using 0 velocities") ;

//  		    argc -= 2 ;

//  		    argv += 2 ;

//  		    return DANCE_ERROR ;

//  		}

//  		for( int i = 0 ; i < simulator->nu ; i++ )

//  		{

//  		    if( fscanf(fp, "%lf", &simulator->m_dstate[i]) != 1 )

//  		    {

//  			danceInterp::OutputMessage("Error reading velocity file.") ;

//  			fclose(fp) ;

//  			argc -= 2 ;

//  			argv += 2 ;

//  			fclose(fp) ;

//  			return DANCE_ERROR ;

//  		    }

//  		    simulator->m_state[simulator->nq+i] = simulator->m_dstate[i] ;

//  		}

//  		danceInterp::OutputMessage("Read new velocities") ;

//  		new_vel = TRUE ;		

//  		fclose(fp) ;

	

//  	    }



	   

//  	    argc -= 2 ;

//  	    argv += 2 ;



//  	}

//  	else

//  	{

//  	    danceInterp::OutputMessage("Unknown parameter %s.", argv[0]) ;

//  	    return DANCE_ERROR ;

//  	}

//      }



//      simulator->setStateVectorFromJoints();

//      simulator->sdinit() ;		  // initialize	sdfast

//      danceInterp::OutputMessage("Starting simulation dt = %lf time = %lf tol = %lf\n",

//  			    simulator->dt,

//  			    simulator->time,

//  			    simulator->tol) ;

    

//      simulator->assemblyAnalysis();

//      simulator->initVelocityAnalysis();

    

//      if( new_vel == TRUE ) 

//  	simulator->sdstate(simulator->time,

//  			   simulator->m_state, 

//  			   simulator->m_dstate) ;

//      return DANCE_OK ;

//  }





Joint * ArticulatedObject::getJoint(const char * name)

{

  	Joint *wjnt = NULL;

	Joint **jointList = getJoints();

	for (int i = 0; i < getNumJoints(); i++) {

		if (strcmp(name,jointList[i]->getName()) == 0) {

			wjnt = jointList[i];	

			break;

		}

	}

	return (wjnt);

}



void ArticulatedObject::WriteBVHFile(const char *filename)

{

	FILE *fp = fopen(filename, "w") ;

	if( fp == NULL ) 

	{

		danceInterp::OutputMessage("ERROR: WriteBVH: cannot open %s.\n", filename) ;

		return ;

	}

	WriteBVHFile(fp) ;

	fclose(fp) ;

	return ;

}



void ArticulatedObject::WriteBVHFile(FILE *fp)

{

	Link *RootLink = NULL ;

	

	// find the root link which is the one whose parent is NULL

	for( int i = 0 ; i < m_numLinks ; i++ )

		if( link[i]->getParentLink() == NULL )

			RootLink = link[i] ;

	if( RootLink == NULL )

	{

		danceInterp::OutputMessage("ERROR: WriteBVH: cannot find root link!") ;

		return ;

	}



	RootLink->WriteBVHFile(fp, 1) ;

	return ;

}



// PROC:  combineLinks()

// DOES: combines two links into one. The links

//       must have a parent->child relationship and must

//       be given in parent first, child second order.

int ArticulatedObject::combineLinks(int argc, char **argv)

{

	if( argc != 2 ) 

	{

		printf("usage: combine <name of link1> <name of link2>\n") ;

		return DANCE_OK ;

	}

	struct Link_s {

		Vector inbToJ ;

		Vector bodyToJ ;

		char name[MAX_LINE] ;

	} plink, clink, combinedLink ;

		

	int i ;

	



	Link *pl = getLink(argv[0]) ;

	if( pl == NULL )

	{

		printf("Link %s not found! Aborting operation.\n", argv[0]) ;

		return DANCE_ERROR ;

	}

	Vector v ;

	pl->getParentJoint()->getInbToJoint(v) ;

	VecCopy(plink.inbToJ, v) ;

	pl->getParentJoint()->getBodyToJoint(v) ;

	VecCopy(plink.bodyToJ, v) ;

	strcpy(plink.name, pl->getName()) ;

	

	Link *cl = getLink(argv[1]) ;

	if( cl == NULL )

	{

		printf("Link %s not found! Aborting operation.\n", argv[1]) ;

		return DANCE_ERROR ;

	}



	cl->getParentJoint()->getInbToJoint(v) ;

	VecCopy(clink.inbToJ, v) ;

	cl->getParentJoint()->getBodyToJoint(v) ;

	VecCopy(clink.bodyToJ, v) ;

	strcpy(clink.name, cl->getName()) ;



	// first calculate the new center of mass as

	// the average of the center of masses of the links being combined.

	// assumed that the coordinate system used is the one of the parent.

	Vector combCM ;

	VecSubtract(combCM, clink.inbToJ, clink.bodyToJ) ;

	VecScale(combCM, 0.5) ;

	// now combCM is the combined cm in the cs of the parent link.

	// for the combined links this is where its origin should be

	// so produce the appropriate body to joint. inb stays the same

	// as the parent link's

	VecCopy(combinedLink.inbToJ, plink.inbToJ) ;

	VecSubtract(combinedLink.bodyToJ, plink.bodyToJ, combCM) ;



	printf("Link combined inbtoJ %lf %lf %lf\n",

			combinedLink.inbToJ[0], 

			combinedLink.inbToJ[1], 

			combinedLink.inbToJ[2]) ;

	printf("\tbodyToJ %lf %lf %lf\n",

			combinedLink.bodyToJ[0], 

			combinedLink.bodyToJ[1],

			combinedLink.bodyToJ[2]) ;



	// now for every child link of the two links that combined

	// update the inbToJoint

	Link **childs = pl->getChildLinks() ;

	for( i = 0 ; i < pl->getNumChildLinks() ; i++ )

	{

		Vector citj, newcitj ;

		childs[i]->getParentJoint()->getInbToJoint(citj) ;

		VecAdd(newcitj, citj, combCM) ;

		printf("Link %s new parent combined\n", childs[i]->getName()) ;

		printf("\tinbtoj %lf %lf %lf\n", 

			newcitj[0], 

			newcitj[1], newcitj[2]) ;

	}



	childs = cl->getChildLinks() ;

	for( i = 0 ; i < cl->getNumChildLinks() ; i++ )

	{

		Vector citj, newcitj ;

		childs[i]->getParentJoint()->getInbToJoint(citj) ;

		VecAdd(newcitj, citj, combCM) ;

		printf("Link %s new parent combined\n", childs[i]->getName()) ;

		printf("\tinbtoj %lf %lf %lf\n", 

			newcitj[0], 

			newcitj[1], newcitj[2]) ;

	}



	return DANCE_OK ;

}



// calculates the center of mass of the articulated object in world cordinates

// If a simulator is present then this it uses the simulator so that the

// center of mass is valid when the simulator uses a variable time step .

double *ArticulatedObject::calcCM()

{

    Vector origin = {0.0, 0.0, 0.0} ;

    Vector cm_link ;

    m_cm[0] = m_cm[1] = m_cm[2] = 0.0 ; 



    for( int i = 0 ; i < m_numLinks ; i++ )

    {

		if (this->getNumSimulators() > 0)

			this->getSimulator(0)->GetPosition(i, origin, cm_link) ;

		else

			this->getWorldCoord(i, cm_link, origin) ;

		VecScale(cm_link, link[i]->getMass()) ; 

		VecAdd(m_cm, m_cm, cm_link) ;

    }

    VecScale(m_cm, 1.0 / (double) m_Mass) ;

    return &m_cm[0] ;

}



double *ArticulatedObject::calcCMVelocity(Vector vcm)

{

	if (this->getNumSimulators() == 0)

		return NULL ;



    Vector origin = { 0.0, 0.0, 0.0 } ;

    Vector vcm_link = { 0.0, 0.0, 0.0 } ;



	DSimulator* simulator = this->getSimulator(0);

    for( int i = 0 ; i < m_numLinks ; i++ )

    {

		simulator->GetVel(i, origin, vcm_link) ;

		VecScale(vcm_link, link[i]->getMass()) ; 

		VecAdd(vcm, vcm, vcm_link) ;

    }

    VecScale(vcm, 1.0 / (double) m_Mass) ;

 

    return &vcm[0] ;

}



void ArticulatedObject::DeleteLinkChildren(Link *wlink)

{

	

	double point[3] = {0.0,0.0,0.0};

	if (wlink) {

		wlink->getEndEffectorWC(point);	

		wlink->DeleteChildren();

	}

	m_ActiveLink = wlink;

	setCurrentEndEffector(point);



}



//ADDED BY JULIA 6/05

Joint* ArticulatedObject::HandleJointAdd(int linkNumber, int jointType, Vector axis1, Vector axis2, Vector axis3)

{

	//create parent link

	Link *l;

	Joint *j = new Joint;



	Quaternion id;

	id.identity();

	j->setQuaternion(&id);



	int numAxis;

	Vector axis[3];

	Vector temp;



	Vector pos;

	//Vector vec = {0, 0, 0};

	Vector inbToJoint = {0, 0, 0};

	Vector bodyToJoint = {0, 0, 0};

	Vector endeff = {0, 0.0, 0};

	Vector zero = {0, 0, 0};



	// add root joint/link

	if (m_numJoints == 0)

	{

		l = new Link(0);

		l->setArticulatedObject(this);

		l->setName("Root_Link");



		// if no CoM specified, set it halfway between endpoint by default

		if (!getCMvalidity())

		{

			VecSubtract(bodyToJoint, newEndEffPos, rootNewJointPos);

			VecNumMul(bodyToJoint, bodyToJoint, -0.5);

			VecNumMul(endeff, bodyToJoint, -1.0);

		}

		else	// otherwise, set specified CoM

		{

			VecSubtract(bodyToJoint, rootNewJointPos, newCMPos);

			VecSubtract(endeff, newEndEffPos, newCMPos);

		}



		//define coordinate system

		CoordSystem cs;

		l->setParentLink(NULL);

		setVector(cs.x, 1.0, 0.0, 0.0);

		setVector(cs.y, 0.0, 1.0, 0.0);

		setVector(cs.z, 0.0, 0.0, 1.0);

		VecSubtract(cs.origin, inbToJoint, bodyToJoint);



		l->setEndEffector(endeff);



		l->setCenterMass(newCMPos);

//		l->setCenterMass(l->m_transMat[3]);

		l->setTransMat(cs);



		//allocate joint

		j->create(getNumJoints(), jointType, NULL, l);

		if (jointType == J_WELD)

		{

			j->setNumAxis(0);

		}

		else if (jointType == J_PIN)

		{

			j->setNumAxis(1);

			j->setAxis(0, axis1);

		}

		else if (jointType == J_UNIVERSAL)

		{

			j->setNumAxis(2);

			j->setAxis(0, axis1);

			j->setAxis(1, axis2);

		}

		else if (jointType == J_GIMBAL)

		{

			j->setNumAxis(3);

			j->setAxis(0, axis1);

			j->setAxis(1, axis2);

			j->setAxis(2, axis3);

		}

		else if (jointType == J_BALL)

		{

			j->setNumAxis(3);

			j->setAxis(0, axis1);

			j->setAxis(1, axis2);

			j->setAxis(2, axis3);

		}

		else if (jointType == J_FREE)

		{

			j->setNumAxis(3);

			j->setAxis(0, axis1);

			j->setAxis(1, axis2);

			j->setAxis(2, axis3);

		}



		j->setInbToJoint(inbToJoint);

		j->setBodyToJoint(bodyToJoint);



		//add joint and link to articulated object

		addJoint(j);

		l->setParentJoint(j);

		addLink(l);



		//set active joint and link

		m_ActiveLink = l;

		m_ActiveJoint = j;



		//set joint position

		//j->setState(0, rootNewJointPos[0], 0);

		//j->setState(1, rootNewJointPos[1], 0);

		//j->setState(2, rootNewJointPos[2], 0);



		j->setInbToJoint(rootNewJointPos);



		this->changeToLocal();

 		this->updateStateConfig();	



		setVector(newJointPos, newEndEffPos[0], newEndEffPos[1], newEndEffPos[2]);



		firstclick = false;

/*		j->getPosition(pos);

		danceInterp::OutputMessage("The joint pos is: %f, %f, %f", pos[0], pos[1], pos[2]);

		l->getPosition(pos);

		danceInterp::OutputMessage("The link pos is: %f, %f, %f", pos[0], pos[1], pos[2]);					

*/				

	}

	else

	{

		VecSubtract(temp, newEndEffPos, newJointPos);



		if (!getCMvalidity())	//default center of mass

		{

			//set BodyToJoint vector of current joint

			VecScale(temp, -0.5);

			setVector(bodyToJoint, temp[0], temp[1], temp[2]);



			//set endeffector

			VecNumMul(endeff, bodyToJoint, -1);

	//		VecAdd(endeff, endeff, bodyToJoint);

		}

		else	//explicit center of mass

		{

			VecSubtract(bodyToJoint, newJointPos, newCMPos);

			VecSubtract(endeff, newEndEffPos, newCMPos);

		}



		if (!edit_joint)		// set new joint/link at end effector of previous

		{

			//set ITJ vector of current vector

			m_ActiveJoint->getPosition(pos);

			VecSubtract(inbToJoint, newJointPos, pos);

			VecNumMul(inbToJoint, inbToJoint, 0.5);

		}

		else	//if joint offset from parent end effector

		{

			Vector cm;

			Vector worldcm;

			if (m_ActiveLink != NULL)

			{

				m_ActiveLink->getCenterMass(cm);

				m_ActiveLink->getWorldCoord(worldcm, cm);



				VecSubtract(inbToJoint, newJointPos, worldcm);

			}

			else

			{

				VecCopy(inbToJoint, zero);

			}



//			double invmatrix[4][4];

//			this->m_ActiveJoint->getOutboardLink()->getInvTransMat(invmatrix);

//			transformPoint_mat(inbToJoint, invmatrix);

		}



		//set axis to Identity matrix

		for (int r = 0; r < 3; r++)

			for (int c = 0; c < 3; c++)

				if (r == c)

					axis[r][c] = 1.0;

				else

					axis[r][c] = 0.0;



		numAxis = 0;

		if (jointType == J_WELD)

			numAxis = 0;

		else if (jointType == J_FREE)

			numAxis = 3;

		else if (jointType == J_GIMBAL)

			numAxis = 3;

		else if (jointType == J_BALL)

			numAxis = 3;

		else if (jointType == J_UNIVERSAL)

			numAxis = 2;

		else if (jointType == J_PIN)

			numAxis = 1;



		//	getWorldCoords function does not work properly

	//	event->Window->getWorldCoords(world,event->winX,event->winY, 0);



//		danceInterp::OutputMessage("Window x position is %f", newEndEffPos[0]);

//		danceInterp::OutputMessage("Window y position is %f\n", newEndEffPos[1]);



		// set link number to default if not specified

		if (linkNumber == -1)

			l = new Link(m_numLinks);

		else

			l = new Link(linkNumber);



		l->setArticulatedObject(this);



		//find and set parent

		l->setParentLink(NULL);

		if( m_numLinks != 0)

		{

			l->setParentLink(m_ActiveLink);

		}



		//define the coordinate system

		Link *pl = l->getParentLink();

/*		CoordSystem cs;

		setVector(cs.x, 1.0, 0.0, 0.0);

		setVector(cs.y, 0.0, 1.0, 0.0);

		setVector(cs.z, 0.0, 0.0, 1.0);

		VecSubtract(cs.origin, inbToJoint, bodyToJoint);

*/

		// determine the coordinate system for the new link

		double invParentMatrix[4][4];

		m_ActiveLink->getInvTransMat(invParentMatrix);

		double parentMatrix[4][4];

		m_ActiveLink->getTransMat(parentMatrix);



		// find the com in world coordinates of the new link

		Vector worldCM;

		if (!getCMvalidity())

		{

			VecAdd(worldCM, newJointPos, newEndEffPos);

			VecScale(worldCM, 0.5);

		}

		else

		{

			VecCopy(worldCM, newCMPos);

		}



		Vector localCM;

		VecCopy(localCM, worldCM);

		transformPoint_mat(localCM, invParentMatrix);

		

		double localTranslationMatrix[4][4];

		setIdentMat(&localTranslationMatrix[0][0], 4);

		localTranslationMatrix[3][0] = localCM[0];

		localTranslationMatrix[3][1] = localCM[1];

		localTranslationMatrix[3][2] = localCM[2];



		double childMatrix[4][4];

		//multArray(&childMatrix[0][0], &localTranslationMatrix[0][0], &parentMatrix[0][0],4, 4, 4);

		multArray4x4(childMatrix, localTranslationMatrix, parentMatrix);



		//		setVector(cs.origin, globalCM);



		//give the link an end effector

//		l->setEndEffector(endeff);



		if (pl != NULL)

		{

			Vector parent_position;

			pl->getPosition(parent_position);

//			VecAdd(cs.origin, parent_position, cs.origin);

		}



		l->setCenterMass(l->m_transMat[3]);

		

		// more Ari's experiment

		l->setTransMat(childMatrix);

		//l->setTransMat(coord);

		//l->setTransMat(cs);



		double invMatrix[4][4];

		l->getInvTransMat(invMatrix);



		// set end effector

		Vector localEndEff;

		VecCopy(localEndEff, newEndEffPos);

		transformPoint_mat(localEndEff, invMatrix);

		l->setEndEffector(localEndEff);





		//allocate joint and fill in the fields

		//Caution! All link fields must be properly set

		//to ensure that the joint is created properly

		if( joint == NULL)

		{

			danceInterp::OutputMessage("Cannot allocate joint!\n");

			return NULL;

		}



		if (linkNumber == -1)

			j->create(getNumJoints(), jointType, pl, l);

		else

			j->create(linkNumber, jointType, pl, l);



		j->setNumAxis(numAxis);

		for (int i = 0; i < numAxis; i++)

		{

			j->setAxis(i, axis[i]);

		}



		//Make special axes for BALL joint

		if( j->getJointType() == J_BALL)

		{

			Vector temp = {1.0, 0.0, 0.0};

			j->setAxis(0, temp);

			temp[0] = 0.0; temp [1] = 1.0; temp[2] = 0.0;

			j->setAxis(1, temp);

			temp[0] = 0.0; temp [1] = 0.0; temp[2] = 1.0;

			j->setAxis(2, temp);

		}



//		j->setInbToJoint(inbToJoint);

//		j->setBodyToJoint(bodyToJoint);



		//calculate/set body to joint vector

		Vector localBodyToJoint;

		VecCopy(localBodyToJoint, newJointPos);				//get new joint's global position

		transformPoint_mat(localBodyToJoint, invMatrix);	//find new joint's position local to new center of mass

		j->setBodyToJoint(localBodyToJoint);



		//calculate/set inboard to joint vector

		Vector parentPos;

		pl->getPosition(parentPos);

		Vector localParentPos;

		VecCopy(localParentPos, parentPos);					//get global position of parent's center of mass

		transformPoint_mat(localParentPos, invMatrix);		//find parent's center of mass position wrt new link center of mass



		Vector localJointPos;

		VecCopy(localJointPos, newJointPos);				//get new joint's global position

		transformPoint_mat(localJointPos, invMatrix);		//find new joint's position local to new center of mass



		Vector localInbToJoint;

		VecSubtract(localInbToJoint, localJointPos, localParentPos);	//subtract to find local inboard to joint

		j->setInbToJoint(localInbToJoint);



		m_ActiveJoint = j;

		m_ActiveLink = l;



		//add joint to the articulated object

		addJoint(j);

		//set parent joint for the link

		l->setParentJoint(j);

		//add link to the articulated object

		addLink(l);



		j->setPosition(newJointPos);



/*		double linkMatrix[4][4];

		l->getWTransMat(linkMatrix);

		transformPoint_mat(bodyToJoint, linkMatrix);

		Vector linkPos;

		VecSubtract(linkPos, newJointPos, bodyToJoint);

		l->setPosition(linkPos);

*/

		Vector t;

		j->getPosition(t);



//		this->changeToLocal();

 		this->updateStateConfig();	



		setVector(newJointPos, newEndEffPos[0], newEndEffPos[1], newEndEffPos[2]);

	}



	if (this->m_ArticulatedObjectWindow != NULL)

	{

		this->m_ArticulatedObjectWindow->updateGUI();

	}

	

	calculateStateIndexMapping();

	dance::Refresh();



	return j;	

}



//	Gets world coordinates of mouse click in XY-plane

void ArticulatedObject::getWorldPos(double worldt[3])

{

	//////////input/////////////////

	int x = fltk::event_x();

	int y = fltk::event_y();

	////////////////////////////////



	double modelView[16];

	double projection[16];

	GLint viewport[4];



	double x1, y1, z1, x2, y2, z2;



	glGetDoublev(GL_MODELVIEW_MATRIX, modelView);

	glGetDoublev(GL_PROJECTION_MATRIX, projection);

	glGetIntegerv(GL_VIEWPORT, viewport);



	y = viewport[3] - y;

	gluUnProject(x, y, 0, modelView, projection, viewport, &x1, &y1, &z1);

	gluUnProject(x, y, 1, modelView, projection, viewport, &x2, &y2, &z2);



	double t = z1 / (z1 - z2);



	worldt[0] = (1-t)*x1 + t*x2;

	worldt[1] = (1-t)*y1 + t*y2;

	worldt[2] = 0;

}



// Delete's active link/joint if it has no children

int ArticulatedObject::deleteLinkAndJoint(Link* thelink, Joint* thejoint)

{

	//create temp joint holder

	Joint* jtemp;

	Link* ltemp;



/*	if (m_isEmpty == true)	//empty drawing

	{

		danceInterp::OutputMessage("No Link to delete: object is empty");

		firstclick = false;

	}

*/

	//if 1 link/joint left		

	if (m_numLinks == 1) 

	{

		delete link[m_numLinks - 1];



		//update menu

		if (this->m_ArticulatedObjectWindow != NULL)

		{

			this->m_ArticulatedObjectWindow->updateGUI();

		}



		//update Object display

		dance::AllViews->postRedisplay();



		return -1;

	}

	//if selected link is not leaf (has children) -> cannot delete

	else if (thelink->getNumChildLinks() != 0)

	{

		danceInterp::OutputMessage("Cannot delete link, choose an endpoint link");

		return 1;

	}

	//otherwise, do delete

	else

	{

//		danceInterp::OutputMessage("Deleting Link");



		// remove any IK chains that use that link

		int numChains = this->getNumIKChains();

		for (int x = numChains - 1; x >= 0; x--)

		{

			bool remove = false;

			IKChain* chain = this->getIKChain(x);

			int numJointsInChain = chain->getNumJoints();

			for (int j = 0; j < numJointsInChain; j++)

			{

				Joint* chainJoint = chain->getJoint(j);

				if (chainJoint == thejoint)

				{

					remove = true;

					break;

				}

			}

			if (remove)

				this->removeIKChain(chain->getName());

		}





		//save link/joint to be erased

		ltemp = thelink;

		jtemp = thejoint;



		jtemp->getPosition(newJointPos);



		//delete link/joint

		delete jtemp;

		delete ltemp;



	

		//update menu

		if (this->m_ArticulatedObjectWindow != NULL)

		{

			this->m_ArticulatedObjectWindow->updateGUI();

		}



		dance::AllViews->postRedisplay();



		return -1;

	}



	return 1;

}



void ArticulatedObject::createIKChain(char *name)

{

	for (int i = 0; i < getNumIKChains(); i++)

	{

		if (strcmp(name, m_ikChain[i]->getName()) == 0)

		{

			danceInterp::OutputMessage("IK Chain %s already exists, no new chains were created.", name);

			return ;

		}

	}



	m_ikChain.resize(getNumIKChains()+1);

	m_ikChain[getNumIKChains()-1] = new IKChain;

	m_ikChain[getNumIKChains()-1]->setName(name);



	if(this->m_ArticulatedObjectWindow != NULL)

		this->m_ArticulatedObjectWindow->updateGUI();



	danceInterp::OutputMessage("IK Chain %s was successfully created.", m_ikChain[getNumIKChains()-1]->getName());

}



void ArticulatedObject::createIKChain(IKChain *ikChain)

{

	for (int i = 0; i < getNumIKChains(); i++)

	{

		if (strcmp(ikChain->getName(), m_ikChain[i]->getName()) == 0)

		{

			danceInterp::OutputMessage("IK Chain %s already exists, no new chains were created.", ikChain->getName());

			return ;

		}

	}



	m_ikChain.push_back(ikChain);

	danceInterp::OutputMessage("IK Chain %s was successfully created.", m_ikChain[getNumIKChains()-1]->getName());

}



int ArticulatedObject::removeIKChain(char *name)

{

	bool removed = false;

	for (vector<IKChain*>::iterator iter = m_ikChain.begin(); iter != m_ikChain.end(); iter++)

	{

		if(strcmp(name, (*iter)->getName()) == 0)

		{

			if(m_ikChain[getActiveIKChain()] == (*iter))

				setActiveIKChain(-1);



			IKChain* chain = (*iter);

			m_ikChain.erase(iter);

			danceInterp::OutputMessage("IK Chain %s was successfully removed.", chain->getName());

			delete chain;

			removed = true;

			break;

		}

	}



	if(!removed) {

		danceInterp::OutputMessage("%s is not a valid IK Chain, no IK Chains were removed.", name);

		return DANCE_ERROR;

	} else {

		if(this->m_ArticulatedObjectWindow != NULL)

			this->m_ArticulatedObjectWindow->updateGUI();

	}



	return DANCE_OK;

}



/*void ArticulatedObject::setIKMode(int val)

{

	interactionMode = val;



	m_ikMode = val;

	if(interactionMode == IK_mode)

	{

		danceInterp::OutputMessage("IK Mode is now on.");

		dance::addInteraction(this);

	}

	else

	{

		danceInterp::OutputMessage("IK Mode is now off.");

		dance::removeInteraction(this);

	}



	if(this->m_ArticulatedObjectWindow != NULL)

		this->m_ArticulatedObjectWindow->updateGUI();

}*/



void ArticulatedObject::setShowActiveIKChain(bool val)

{

	m_showActiveIKChain = val;



	if(this->m_ArticulatedObjectWindow != NULL)

		this->m_ArticulatedObjectWindow->updateGUI();



	dance::AllViews->postRedisplay();

}



bool ArticulatedObject::isShowActiveIKChain()

{

	return m_showActiveIKChain;

}



void ArticulatedObject::setShowActiveIKTarget(bool val)

{

	m_showIKTarget = val;



	if(this->m_ArticulatedObjectWindow != NULL)

		this->m_ArticulatedObjectWindow->updateGUI();



	dance::AllViews->postRedisplay();

}



bool ArticulatedObject::isShowActiveIKTarget()

{

	return m_showIKTarget;

}



int ArticulatedObject::getNumIKChains()

{

	return m_ikChain.size();

}



void ArticulatedObject::setActiveIKChain(int i)

{

		m_activeIKChain = i;

}



int ArticulatedObject::getActiveIKChain()

{

	return m_activeIKChain;

}



IKChain* ArticulatedObject::getIKChain(int i)

{

	if(this->getNumIKChains() > 0 && i >=0 && i < this->getNumIKChains())

		return m_ikChain[i];



	return NULL;

}



int ArticulatedObject::getIKChainNum(IKChain* chain)

{

	for (int x = 0; x < this->getNumIKChains(); x++)

	{

		if (chain == m_ikChain[x])

			return x;

	}

	return -1;

}







IKChain* ArticulatedObject::getIKChain(char* name)

{

	if (name == NULL)



		return NULL;

	for (int i = 0; i < this->getNumIKChains(); i++)

	{

		if (strcmp(this->getIKChain(i)->getName(), name) == 0)

			return this->getIKChain(i);

	}

	return NULL;

}



void ArticulatedObject::activateIKChain()

{

	// update state variables

	m_initMousePosition = 1;



	// temporarily reset to zero position

	double curState[MAX_STATE];

	this->getState(curState);

	this->setZeroState();



	// initialize IK chain

	m_ikChain[m_activeIKChain]->init();



	// set articulated object to its pervious position

	this->setState(curState);

	this->updateStateConfig();



	m_ikChain[m_activeIKChain]->getEndEffector(m_ikTarget);

	m_ikChain[m_activeIKChain]->getEndEffector(m_ikEndEffector);

	danceInterp::OutputMessage("IK Chain %s has been activated.", m_ikChain[m_activeIKChain]->getName());

}



void ArticulatedObject::deactivateIKChain()

{

	danceInterp::OutputMessage("IK Chain %s has been deactivated.", m_ikChain[m_activeIKChain]->getName());

}



void ArticulatedObject::pushIK_cb(int button, int x, int y)

{

	if(button == fltk::LeftButton &&

		m_ikChain[m_activeIKChain]->isChain() &&

		m_ikChain[m_activeIKChain]->getNumDofs() > 0)

	{

			this->activateIKChain();

			m_validIKChain = true;

	}

}



void ArticulatedObject::dragIK_cb(int button, int x, int y)

{

	if(button == fltk::LeftButton && m_validIKChain)

	{

		static double mousex, mousey, mousez;



		double modelview[16];

		double projection[16];

		GLint viewport[4];



		glGetDoublev(GL_MODELVIEW_MATRIX, modelview);

		glGetDoublev(GL_PROJECTION_MATRIX, projection);

		glGetIntegerv(GL_VIEWPORT, viewport);



		if(m_initMousePosition == 1)

		{

			gluProject(m_ikEndEffector[0], m_ikEndEffector[1], m_ikEndEffector[2], modelview, projection, viewport, &mousex, &mousey, &mousez);

			m_initMousePosition = 0;

		}



		mousex = (double)fltk::event_x();

		mousey = (double)fltk::event_y();

		dance::AllViews->getViewFocus()->getWorldCoords(m_ikTarget, (int)mousex, (int)mousey, mousez);

		this->computeIKChain();

	}

}



void ArticulatedObject::releaseIK_cb(int button, int x, int y)

{

	if(button == fltk::LeftButton && m_validIKChain)

	{

		this->deactivateIKChain();

		m_validIKChain = false;

	}

}



void ArticulatedObject::computeIKChain()

{

	bool early;

	double *dtheta;

	dtheta = new double[m_ikChain[m_activeIKChain]->getNumDofs()];

	m_ikChain[m_activeIKChain]->setGoal(m_ikTarget);

	int iterations = m_ikChain[m_activeIKChain]->getIKNumIterations();

	for(int i=0; m_ikChain[m_activeIKChain]->computeStep(1, early, dtheta) == IKChain::IK_GOAL_NOT_REACHED && i<iterations; i++)

	{

		m_ikChain[m_activeIKChain]->getEndEffector(m_ikEndEffector);

		m_ikChain[m_activeIKChain]->getIKOrigin(m_ikOrigin);

		this->updateIKChain(dtheta);

	}

	dance::AllViews->postRedisplay();

	delete [] dtheta;

}



void ArticulatedObject::updateIKChain(const double *dtheta)

{

	double low, high;

	double val;

	int count = 0;



	// update joints' states

	int numJoints = m_ikChain[m_activeIKChain]->getNumJoints();

	for(int x = 0; x < numJoints; x++)

	{

		Joint *joint = m_ikChain[m_activeIKChain]->getJoint(x);

		if (joint->getJointType() == J_BALL)

		{

			// convert Euler angles to Quaternion

			double val[4];

			for (int i = 0; i < 4; i++)

				val[i] = joint->getState(i);

			Quaternion q(val[0], val[1], val[2], val[3]);

			Matrix3x3 matrix;

			q.toMatrix(matrix);

			VectorObj obj;

			matrix.matToEuler(Matrix3x3::XYZ, obj, false);



			for (int e = 0; e < 3; e++)

			{

				obj[e] += dtheta[count++];

				double low, high;

				joint->getLimits(e, &low, &high);

				low = low * M_PI / 180;

				high = high * M_PI / 180;

				if( obj[e] >= (high - 0.009))

					obj[e] = high - 0.009;

				if( obj[e] <= (low + 0.009))

					obj[e] = low + 0.009;

			}

			// convert back to quaternion

			Matrix3x3 xrot;

			xrot.setRotateMatrix(Matrix3x3::X, obj[0]);

			Matrix3x3 yrot;

			yrot.setRotateMatrix(Matrix3x3::Y, obj[1]);

			Matrix3x3 zrot;

			zrot.setRotateMatrix(Matrix3x3::Z, obj[2]);

			Matrix3x3 final;

			final = xrot * yrot * zrot;

			Quaternion qFinal;

			qFinal.fromMatrix(final);

			for (int j = 0; j < 4; j++)

				joint->setState(j, qFinal[j]);

		}

		else

		{

			for(int y = 0; y < joint->getNumDof(); y++)

			{

				joint->getLimits(y, &low, &high);

				low = low * M_PI / 180;

				high = high * M_PI / 180;

				val = joint->getState(y) + dtheta[count++];

				if( val >= (high-0.009))

					val = high-0.009;

				if( val <= (low+0.009))

					val = low+0.009;

				if (y == joint->getNumDof() - 1)

					joint->setState(y, val);

				else

					joint->setState(y, val, true);

			}

		}

	}

 

	this->updateStateConfig();

}



int ArticulatedObject::interactEditMode(Event *event)

{

		switch (event->getEventType())

		{

			case fltk::KEY:

				switch (fltk::event_key())

				{

				case '1':

				case '2':

				case '3':

				case '6':	//change joint type selection mode

					if (draw_mode == CHANGE_TYPE)

					{

						if (fltk::event_key() == '1')

						{

							m_ActiveJoint->setJointType(J_PIN);

							danceInterp::OutputMessage("Joint type changed to PIN.");

						}

						else if (fltk::event_key() == '2')

						{

							m_ActiveJoint->setJointType(J_UNIVERSAL);

							danceInterp::OutputMessage("Joint type changed to UNIVERSAL.");

						}

						else if (fltk::event_key() == '3')

						{

							m_ActiveJoint->setJointType(J_GIMBAL);

							danceInterp::OutputMessage("Joint type changed to GIMBAL.");

						}

						else if (fltk::event_key() == '4')

						{

							m_ActiveJoint->setJointType(J_BALL);

							danceInterp::OutputMessage("Joint type changed to BALL.");

						}

						else if (fltk::event_key() == '6')

						{

							m_ActiveJoint->setJointType(J_FREE);

							danceInterp::OutputMessage("Joint type changed to FREE.");

						}

						draw_mode = INTERACT_NONE;

						return -1;	

					}

					else

					{

						return 1;

					}

					break;

				case 'j': //draw joint/link

					if (this->m_ActiveJoint != NULL || this->m_numJoints == 0)

					{

						danceInterp::OutputMessage("joint drawing mode is now on");

						draw_mode = DRAW_JOINT;

					}

					else

						danceInterp::OutputMessage("No Parent Joint/Link Selected");

					return -1;

					break;

				case 'd': //delete joint/link

					{

					danceInterp::OutputMessage("delete joint/link mode is now on");

					int ret = this->deleteLinkAndJoint(this->getActiveLink(), this->getActiveJoint());

					return ret;

					}

					break;

				case 't':	//change joint type

					if (draw_mode != CHANGE_TYPE)

					{

						danceInterp::OutputMessage("change joint type mode now on");

						danceInterp::OutputMessage("Current joint type is %d", m_ActiveJoint->getJointType());

						draw_mode = CHANGE_TYPE;

					}

					danceInterp::OutputMessage("Choose new joint type:");

					danceInterp::OutputMessage("PIN = 1,  UNIVERSAL = 2,  GIMBAL = 3,  FREE = 6");

					return -1;

					break;

				default:

					break;

				}

				break;

			case fltk::SHORTCUT:

				return 1;

				break;

			case  fltk::PUSH: //mouse click

				if (draw_mode == DRAW_JOINT)

				{

					if (m_numJoints == 0 && m_isEmpty)		//if empty object save first click

					{

						getWorldPos(rootNewJointPos);

						firstclick = true;

						dance::AllViews->postRedisplay();

						m_isEmpty = false;

					}

					else		//otherwise create link with 2 previous clicks' positions

					{

						if (m_ActiveLink != NULL)

						{

							Vector temp;

							Vector temp2;

							m_ActiveLink->getEndEffector(temp);

							m_ActiveLink->getWorldCoord(temp2, temp);

							setNewJointPos(temp2);

						}



						getWorldPos(newEndEffPos);

						setCMvalidity(false);					// default center of mass

						Vector axis1 = {1.0, 0.0, 0.0};

						Vector axis2 = {0.0, 1.0, 0.0};

						Vector axis3 = {0.0, 0.0, 1.0};

						HandleJointAdd(-1, J_GIMBAL, axis1, axis2, axis3);

					}

					return -1;

				}

				return 1;

				break;

			case  fltk::MOVE:

				return 1;

				break;

			case  fltk::DRAG:	//mouse drag

				//delete last link drawn and redraw with new mouse positions

				if (draw_mode == DRAW_JOINT && m_numLinks != 0)

				{

					Link* l = link[m_numLinks-1];

					Joint* j = l->getParentJoint();

					setActiveLink(l->getParentLink());

					setActiveJoint(l->getParentLink()->getParentJoint());

					//delete last link

					this->deleteLinkAndJoint(l, j);

					//get new mouse positions

					getWorldPos(newEndEffPos);

					

					if (m_numJoints == 0)

						this->setEmpty(true);

					

					setCMvalidity(false);					// default center of mass

					Vector axis1 = {1.0, 0.0, 0.0};

					Vector axis2 = {0.0, 1.0, 0.0};

					Vector axis3 = {0.0, 0.0, 1.0};

					HandleJointAdd(-1, J_GIMBAL, axis1, axis2, axis3);



					setEmpty(false);

					this->changeToLocal();

			 		this->updateStateConfig();				

					dance::AllViews->postRedisplay();

					return -1;

				}

				return 1;

				break;

			case  fltk::RELEASE:		//turn off draw mode if ON

				if (draw_mode == DRAW_JOINT)

				{

					draw_mode = INTERACT_NONE;

					return -1;

				}

				else

					return 1;

				break;

			case fltk::FOCUS:

				return 1;

				break;

		}

		return 0;

}



int ArticulatedObject::interactIKMode(Event *event)

{

	switch (event->getEventType())

	{

		case fltk::KEY:

			switch (fltk::event_key())

			{

				case 't':

					this->setShowActiveIKTarget(!this->isShowActiveIKTarget());

					return -1;

					break;

				

				case 'c':

					this->setShowActiveIKChain(!this->isShowActiveIKChain());

					return -1;

					break;



				case 'i':

					if(getNumIKChains() > 0 && getActiveIKChain() >= 0 && getActiveIKChain() < getNumIKChains())

					{

						if(getInteractionMode() == IK_mode)

						{

							setInteractionMode(NO_mode);

						}

						else

						{

							setInteractionMode(IK_mode);

						}

						return -1;

					}

					break;



				default:

					break;

			}

			break;



		case  fltk::PUSH:

			if((getInteractionMode() == IK_mode) && getNumIKChains() > 0 && getActiveIKChain() >= 0 && getActiveIKChain() < getNumIKChains())

			{

				this->pushIK_cb(fltk::event_button(), fltk::event_x(), fltk::event_y());

				return -1;

			}

			break;



		case  fltk::DRAG:

			if(getInteractionMode() == IK_mode)

			{

				this->dragIK_cb(fltk::event_button(), fltk::event_x(), fltk::event_y());

				return -1;

			}

			break;



		case  fltk::RELEASE:

			if(getInteractionMode() == IK_mode)

			{

				this->releaseIK_cb(fltk::event_button(), fltk::event_x(), fltk::event_y());

				return -1;

			}

			break;

	}

	return 0;

}







int ArticulatedObject::interact(Event *event)

{

	// do if New/Edit Button is on

	if (this->getInteractionMode() == EDIT_mode)

	{

		return interactEditMode(event);

	}

	else if (this->getInteractionMode() == IK_mode)

	{

		if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_NOT_RUNNING)

			return interactIKMode(event);

		else

			return 0;

	}

	else

	{

		return 0;

	}

}



void ArticulatedObject::WriteMayaFile(const char *fname)

{

    if( getNumJoints() < 1 ) return ;

    FILE *fp ;

    if( fname == NULL ) 

	fp = stdin ;

    else

	fp = fopen(fname, "w") ;

    if( fp == NULL ) 

    {

	danceInterp::OutputMessage("WriteMayaFile: ERROR: Cannot open %s", fname) ;

	return ;

    }

    Joint **j = getJoints() ;

    for( int i = 0 ; i < getNumJoints(); i++ )

   	j[i]->writeMayaFile(fp) ;

	fclose(fp) ;



	danceInterp::OutputMessage("Maya mel format saved in %s", fname) ;

		

    return ;

}



  bool ArticulatedObject::isColliding()

  {

	  return m_isColliding;

  }



  void ArticulatedObject::setColliding(bool val)

  {

	  m_isColliding = val;

  }



// added by achu

void ArticulatedObject::assignModifier(DModifier *mod)

{

	vector<DModifier*>::iterator iter;

	for (iter = m_influencedModifiers.begin(); iter != m_influencedModifiers.end(); iter++)

	{

		if ((*iter) == mod)

			return;

	}

	m_influencedModifiers.push_back(mod);



	//danceInterp::OutputMessage("Modifer %s added to %s's list of influenced modifiers.", mod->getName(), this->getName());

}





void ArticulatedObject::removeModifier(DModifier *mod)

{

	vector<DModifier*>::iterator iter;

	for (iter = m_influencedModifiers.begin(); iter != m_influencedModifiers.end(); iter++)

	{

		if ((*iter) == mod)

		{

			m_influencedModifiers.erase(iter);

			return;

		}

	}



	//danceInterp::OutputMessage("Modifer %s removed from %s's list of influenced modifiers.", mod->getName(), this->getName());

}



double ArticulatedObject::getHeight()

{



	if (m_dimensionCalculated == false)

	{

		BoundingBox box;

		this->calcBoundingBox(&box);

		m_height = abs(box.yMax - box.yMin);

	}



	return m_height;





}



double ArticulatedObject::getWidth()

{



	if (m_dimensionCalculated == false)

	{

		BoundingBox box;

		this->calcBoundingBox(&box);

		m_width= abs(box.xMax - box.xMin);

	}



	return m_width;

}



void ArticulatedObject::setShowingLinks(bool val)

{

	m_isShowingLinks = val;

}



bool ArticulatedObject::isShowingLinks()

{

	return m_isShowingLinks;

}



void ArticulatedObject::setShowingJoints(bool val)

{

	m_isShowingJoints = val;

}



bool ArticulatedObject::isShowingJoints()

{

	return m_isShowingJoints;

}



void ArticulatedObject::setShowingActiveBox(bool val)

{

	m_isShowingActiveBox = val;

	

	m_ArticulatedObjectWindow->checkDisplayBoundingBox->value(val);

}



bool ArticulatedObject::isShowingActiveBox()

{

	return m_isShowingActiveBox;

}



void ArticulatedObject::setShowingSpheres(bool val)

{

	m_isShowingSpheres = val;

}



bool ArticulatedObject::isShowingSpheres()

{

	return m_isShowingSpheres;

}



void ArticulatedObject::setShowingCollisionGeometry(bool val)

{

	m_isShowingCollisionGeometry = val;



	for (int l = 0; l < this->getNumLinks(); l++)

	{

		Link* link = this->getLink(l);

		link->setShowGeometryCollision(m_isShowingCollisionGeometry);

	}

}



bool ArticulatedObject::isShowingCollisionGeometry()

{

	return m_isShowingCollisionGeometry;

}



bool ArticulatedObject::isShowingInertia( void )

{

	return m_isShowingInertia;

}



void ArticulatedObject::setIsShowingInertia( bool argVal )

{

	m_isShowingInertia = argVal;

	for( int l=0; l < getNumLinks(); l++ )

	{

		Link* link = getLink( l );

		link->setIsShowingInertia( m_isShowingInertia );

	}

}



bool ArticulatedObject::isShowingAttachments( void )

{

	return m_isShowingAttachments;

}



void ArticulatedObject::setIsShowingAttachments( bool argVal )

{

	m_isShowingAttachments = argVal;

}



Widget* ArticulatedObject::getInterface()

{

	if (m_ArticulatedObjectWindow == NULL)

	{

		m_ArticulatedObjectWindow = new ArticulatedObjectWindow(this, 0, 0, 370, 400, this->getName());

		m_ArticulatedObjectWindow->setJointChoices(-1);



	}



	return m_ArticulatedObjectWindow;

}



double ArticulatedObject::GetGroupMass(int index)

{

	return link[index]->getMass();

};



int ArticulatedObject::getStateSize()

{

	if (!m_flagChangedSize)

		return m_stateSize;



    int size = 0 ;

    for( int i = 0; i < getNumJoints(); i++ )

   		size += joint[i]->getStateSize() ;

	m_stateSize = size;

	m_flagChangedSize = false;



    return m_stateSize ;

}



void ArticulatedObject::recalculateStateSize()

{

	m_flagChangedSize = true;

}





/// DEPRECATED: use setState( double* val ) instead

void ArticulatedObject::setState(int index, double val)

{

	joint[stateIndexMapping[index]]->setState(stateDOFMapping[index], val);

	updateStateConfig(stateIndexMapping[index]);



/*	// need a faster state retrieval mechanism than this one!

	int count = 0 ;

    for (int i = 0; i < getNumJoints(); i++)

	{

		for (int j = 0; j < joint[i]->getStateSize(); j++)

		{

			if (count == index)

			{

				joint[i]->setState(j, val);

				updateStateConfig(i);

				return;

			}

			count++;

		}

	}

*/

}





void ArticulatedObject::setZeroState()

{

	// reset all the joint positions to zero

	for (int x = 0; x < this->getNumJoints(); x++)

	{

		Joint* joint = this->getJoint(x);

		joint->setZeroState();

	}

	this->updateStateConfig();

	if (m_ArticulatedObjectWindow != NULL)

		this->m_ArticulatedObjectWindow->updateGUI();

	dance::AllViews->postRedisplay();

}



double ArticulatedObject::getState(int index)

{

	// need a faster state retrieval mechanism than this one!

	int count = 0 ;

    for( int i = 0 ; i < getNumJoints() ; i++ )

    {

		for( int j = 0 ; j < joint[i]->getStateSize() ; j++)

		{

			if (count == index)

				return joint[i]->getState(j) ;

			count ++ ;

		}

    }



	return 0;

}



void ArticulatedObject::setState(double* val)

{

	int count = 0 ;



	for (int i = 0; i < getNumJoints(); i++)

	{

		int jointStateSize = joint[i]->getStateSize();

		joint[i]->setState( &(val[count]) );

		count += jointStateSize;

	}

    updateStateConfig();

}



void ArticulatedObject::getState(double* val)

{

	int count = 0 ;

    for( int i = 0 ; i < getNumJoints() ; i++ )

    {

		for( int j = 0 ; j < joint[i]->getStateSize() ; j++)

		{

			val[count] = joint[i]->getState(j) ;

			count ++ ;

		}

    }

}



void ArticulatedObject::setState(double time)

{

	//KeyFrame* kf = this->m_anim.getKeyFrame(time);

	//if (kf != NULL)

	//	this->setState(kf->getParams());

	double state[MAX_STATE];

	bool ok = this->m_anim.interpolate(time, state);

	if (ok)

		this->setState(state);

}



void ArticulatedObject::getDState( double* arg )

{

	int count = 0 ;

	for( int i = 0 ; i < getNumJoints() ; i++ )

	{

		for( int j = 0 ; j < joint[i]->getStateSize() ; j++)

		{

			arg[count] = joint[i]->getDState(j) ;

			count ++ ;

		}

	}

}



void ArticulatedObject::setDState( double* arg )

{

	int count = 0 ;

	for( int i = 0 ; i < getNumJoints() ; i++ )

	{

		for( int j = 0 ; j < joint[i]->getStateSize() ; j++)

		{

			joint[i]->setDState( j, arg[count] );

			count ++ ;

		}

	}

}



void ArticulatedObject::setInitDState( double* arg )

{

	int count = 0 ;

	for( int i = 0 ; i < getNumJoints() ; i++ )

	{

		for( int j = 0 ; j < joint[i]->getStateSize() ; j++)

		{

			joint[i]->setDState( j, arg[count] );

			count ++ ;

		}

	}

}



DCollision** ArticulatedObject::getPointCollisionData()

{

	return m_collisionData;

}



int ArticulatedObject::getNumPointCollisionData()

{

	return m_numCollisionData;

}



void ArticulatedObject::startSimulation()

{

	createPointCollisionHierarchy();



	createSphereCollisionHierarchy();



}



void ArticulatedObject::endSimulation()

{

	if (m_pointHierarchy != NULL)

		delete m_pointHierarchy;



	if (m_sphereHierarchy != NULL)

		delete m_sphereHierarchy;



	if (m_collisionData != NULL)

	{

		for (int x = 0; x < this->getNumLinks(); x++)

			delete m_collisionData[x];

	}

}



void ArticulatedObject::createPointCollisionHierarchy()

{

	// we should reset character to zero position before making these calculations



	// reset the point collision data

	if (m_collisionData != NULL)

	{

		delete[] m_collisionData;

		m_collisionData = 0;

	}



	int numLinks = this->getNumLinks();

	m_collisionData = new DCollision*[numLinks];

	int count = 0;



	// create one DCollision instance for each set of monitor points (each link)

	for (int x = 0; x < numLinks; x++)

	{

		int numMonitorPoints = link[x]->getNumMonitorPoints();



		DCollision* col = new DCollision(x);

		col->setID(x);

		col->setSystem(this);

		col->setNumPoints(numMonitorPoints);

		m_collisionData[count] = col;

		MonitorPoints* mp = link[x]->getMonitorPoints();

		for (int m = 0; m < numMonitorPoints; m++)

		{

			col->setPoint(m, mp->m_Point[m]);

		}

		count++;

	}



	m_numCollisionData = count;



	// the hierarchy will consist of two levels:

	//		1) top level sphere that encompasses that entire articulated object

	//		2) one second-level sphere for each link

	if (m_pointHierarchy != NULL)

		delete m_pointHierarchy;



	m_pointHierarchy = new DCollisionHierarchy();

	m_pointHierarchy->setID(0);

	m_pointHierarchy->setNumCollisions(0);

	m_pointHierarchy->setCollisions(NULL);

	Vector zero = {0.0, 0.0, 0.0};

	m_pointHierarchy->setLocation(zero); // set the local point to be the zero position in body coords

	// make the radius of the sphere as tall/wide/long as the character.

	BoundingBox box;

	this->calcBoundingBox(&box);

	// get the largest dimension

	double maxSize = -1;

	double width = box.xMax - box.xMin;

	double height = box.yMax - box.yMin;

	double length = box.zMax - box.zMin;



	if (width > height)

	{

		if (width > length)

			maxSize = width;

		else

			maxSize = length;

	}

	else

	{

		if (height > length)

			maxSize = height;

		else

			maxSize = length;

	}

	m_pointHierarchy->setSize(maxSize);



	// at the second level, place a bounding sphere around each link

	m_pointHierarchy->setChildren(new DCollisionHierarchy*[m_numCollisionData]);

	m_pointHierarchy->setNumChildren(m_numCollisionData);



	for (int x = 0; x < m_numCollisionData; x++)

	{

		// determine the size of the second level sphere around each link

		double maxDist = -1;

		for (int y = 0; y < m_collisionData[x]->getNumPoints(); y++)

		{

			double* localPoint;

			localPoint = m_collisionData[x]->getPoint(y);

			double dist = sqrt(localPoint[0] * localPoint[0] + localPoint[1] * localPoint[1] + localPoint[2] * localPoint[2]);

			if (dist > maxDist)

				maxDist = dist;

		}



		DCollisionHierarchy* child = new DCollisionHierarchy();

		child->setID(m_collisionData[x]->getID());

		DCollision** c = new DCollision*[1]; // memory leak!?

		c[0] = m_collisionData[x];

		child->setNumCollisions(1);

		child->setCollisions(c);

		child->setNumChildren(0);

		child->setLocation(zero);

		child->setSize(maxDist);

		m_pointHierarchy->getChildren()[x] = child;



	}

}



void ArticulatedObject::createSphereCollisionHierarchy()

{

	// we should reset character to zero position before making these calculations



	// reset the sphere collision data

	if (m_sphereCollisionData != NULL)

		delete[] m_sphereCollisionData;



	int numLinks = this->getNumLinks();



	m_sphereCollisionData = new DSphereCollision*[numLinks];

	int sphereCount = 0;



	for (int x = 0; x < numLinks; x++)

	{

		int numSpheres = link[x]->getNumSpheres();

		if (numSpheres == 0)

		{

			continue;

		}

		DSphereCollision* sphereCol = new DSphereCollision(x);

		sphereCol->setSystem(this);

		sphereCol->setNumPoints(numSpheres);

		m_sphereCollisionData[sphereCount] = sphereCol;

		for (int s = 0; s < numSpheres; s++)

		{

			Vector loc;

			link[x]->getSphereTranslation(s, loc[0], loc[1], loc[2]);

			sphereCol->setPoint(s, loc);

			double size = link[x]->getSphereScale(s);

			sphereCol->setRadius(s, size);

		}

		sphereCount++;

	}



	m_numSphereCollisionData = sphereCount;





	// -- bounding hierarchy for spheres--

	// at the top level, create a bounding sphere that encapsulates the entire body

	if (m_sphereHierarchy != NULL)

		delete m_sphereHierarchy;

	m_sphereHierarchy = new DCollisionHierarchy();

	m_sphereHierarchy->setID(0);

	m_sphereHierarchy->setNumCollisions(0);

	m_sphereHierarchy->setCollisions(NULL);

	Vector zero = {0.0, 0.0, 0.0};

	m_sphereHierarchy->setLocation(zero);

	// how large is the encapsulating sphere? As tall/wide as the character.

	double rootDist = -1;



	// at the next level, place a bounding sphere around each link

	m_sphereHierarchy->setChildren(new DCollisionHierarchy*[m_numSphereCollisionData]);

	m_sphereHierarchy->setNumChildren(m_numSphereCollisionData);



	for (int x = 0; x < m_numSphereCollisionData; x++)

	{

		// determine the size of the second level sphere around each link

		double maxDist = -1;

		for (int y = 0; y < m_sphereCollisionData[x]->getNumPoints(); y++)

		{

			double* localPoint;

			localPoint = m_sphereCollisionData[x]->getPoint(y);

			double dist = sqrt(localPoint[0] * localPoint[0] + localPoint[1] * localPoint[1] + localPoint[2] * localPoint[2]);

			dist += m_sphereCollisionData[x]->getRadius(y); // add the radius to determine limit of sphere

			if (dist > maxDist)

				maxDist = dist;



			// convert to global coordinates and calculate min/max for top-level sphere

			Vector worldPoint;

			link[m_sphereCollisionData[x]->getID()]->getWorldCoord(worldPoint, localPoint);

			Vector rootPoint;

			link[0]->getLocalCoord(rootPoint, worldPoint);

			double linkDist = sqrt(rootPoint[0] * rootPoint[0] + rootPoint[1] * rootPoint[1] + rootPoint[2] * rootPoint[2]);

			linkDist += m_sphereCollisionData[x]->getRadius(y);

			if (linkDist > rootDist)

				rootDist = linkDist;



		}

		DCollisionHierarchy* child = new DCollisionHierarchy();

		child->setID(m_sphereCollisionData[x]->getID());

		DCollision** c = new DCollision*[1]; // memory leak!? yes it is?

		c[0] = m_sphereCollisionData[x];

		child->setNumCollisions(1);

		child->setCollisions(c);

		child->setLocation(zero);

		child->setNumChildren(0);

		child->setSize(maxDist);

		m_sphereHierarchy->getChildren()[x] = child;



	}



	m_sphereHierarchy->setSize(rootDist);

}





bool ArticulatedObject::loadSpheres(char* fname)

{

	// read the sphere information from a file

	FILE *fp = fopen(fname, "r");

	if (fp == NULL)

	{

		danceInterp::OutputMessage("Could not open sphere file %s for reading.", fname);

		return false;

	}

	Link** links = this->getLinks();

	int numLinks = this->getNumLinks();

	for (int l = 0; l < numLinks; l++)

	{

		links[l]->setNumSpheres(0);

	}



	char line[MAX_LINE];

	fgets(line,MAX_LINE,fp) ;

    

	while (line[0] != '\0')

	{

		if (line[0] != '#' && line[0] != '\n')

		{

			Vector translation;

			double scale;

			char linkName[256];

			int sphereNum;

			sscanf(line, "%s %d %lf %lf %lf %lf\n", &linkName[0], &sphereNum, &translation[0], &translation[1], &translation[2], &scale);

			// find the proper link

			Link* link = this->getLink(linkName);

			if (link != NULL)

			{

				if (sphereNum  >= 0 && sphereNum <= MAXNUMSPHERES)

				{

					link->setSphereTranslation(sphereNum, translation[0], translation[1], translation[2]);

					link->setSphereScale(sphereNum, scale);

					link->setSphereMatrix(sphereNum);

					link->setNumSpheres(link->getNumSpheres() + 1);

				}

			}

		}

		if (!feof(fp))

		{

			char* str = fgets(line,MAX_LINE,fp);

			if (str == NULL)

				break;

		}

		else

			line[0] = '\0';

	}

	fclose(fp);



	return true;

}



bool ArticulatedObject::saveSpheres(char* fname)

{

	// save the sphere information to a file

	FILE *fp = fopen(fname, "w"); 

	if (fp == NULL)

	{

		danceInterp::OutputMessage("Could not write to sphere file '%s', spheres not saved...", fname);

		return false;

	}

	fprintf(fp, "# sphere file for articulated object\n");

	fprintf(fp, "# format is: <linkname> <spherenumber> <translationx> <translationy> <translationz> <scale>\n");;



	int numLinks = this->getNumLinks();

	Link** links = this->getLinks();

	for (int x = 0; x < numLinks; x++)

	{

		int numSpheres = links[x]->getNumSpheres();

		for (int s = 0; s < numSpheres; s++)

		{

			Vector translation;

			links[x]->getSphereTranslation(s, translation[0], translation[1], translation[2]);

			double scale = links[x]->getSphereScale(s);

			fprintf(fp, "%s %d %f %f %f %f\n", links[x]->getName(), s, translation[0], translation[1], translation[2], scale);

		}

	}



	fclose(fp);



	return true;

}



void ArticulatedObject::onDependencyRemoval(DObject* object)

{

	DSystem::onDependencyRemoval(object);



	bool foundGeometry = false;

	bool foundGeometryCollision = false;

	bool foundGeometryProp = false;

	bool foundAttachment = false;

	// disconnect geometry from link

	for (int x = 0; x < this->m_numLinks; x++)

	{

		if (link[x]->getGeometry() == object)

		{

			link[x]->setGeometry(NULL, false);

			foundGeometry = true;

			break;

		}

		else if (link[x]->getGeometryCollision() == object)

		{

			link[x]->setGeometryCollision(NULL, false);

			foundGeometryCollision = true;

			break;

		}

		else if (link[x]->getGeometryProp() == object)

		{

			link[x]->setGeometryProp(NULL, false);

			foundGeometryProp = true;

			break;

		}

		else 

		{

			int num;

			if (link[x]->getAttachment(num) == object)

			{

				link[x]->setAttachment(NULL, 0, false);

				break;

			}

		}

	}



	if (foundGeometry)

		this->removeDependency(object);



	if (foundGeometryCollision)

		this->removeDependency(object);



	if (foundGeometryProp)

		this->removeDependency(object);	

}



void ArticulatedObject::renderRecurse(int argc, char** argv, Link* link, std::ofstream& file)

{

	// push the transformation matrix

	double transMatrix[4][4];

	link->getTransMat(transMatrix);



	file << "#declare SETMATRIX = transform { matrix < " << transMatrix[0][0] << ", " << transMatrix[0][1] << ", " << transMatrix[0][2] << ", ";

	file << transMatrix[1][0] << ", " << transMatrix[1][1] << ", " << transMatrix[1][2] << ", ";

	file << transMatrix[2][0] << ", " << transMatrix[2][1] << ", " << transMatrix[2][2] << ", ";

	file << transMatrix[3][0] << ", " << transMatrix[3][1] << ", " << transMatrix[3][2];



	file << "> }\n";



	double invGeomsMatrix[4][4];

	link->getInvGeometryTransMat(invGeomsMatrix);



		file << "#declare SETMATRIX2 = transform { matrix < " << invGeomsMatrix[0][0] << ", " << invGeomsMatrix[0][1] << ", " << invGeomsMatrix[0][2] << ", ";

	file << invGeomsMatrix[1][0] << ", " << invGeomsMatrix[1][1] << ", " << invGeomsMatrix[1][2] << ", ";

	file << invGeomsMatrix[2][0] << ", " << invGeomsMatrix[2][1] << ", " << invGeomsMatrix[2][2] << ", ";

	file << invGeomsMatrix[3][0] << ", " << invGeomsMatrix[3][1] << ", " << invGeomsMatrix[3][2];



	file << "> }\n";



	// show the geometry if present

	DGeometry* geom = link->getGeometry();

	if (geom != NULL)

	{

		// must set it to visible

		bool isv = geom->isVisible() ;

		geom->setVisible(true) ;

		geom->render(argc, argv, file);

		/// restore the isVisible 

		geom->setVisible(isv) ;

	}

        else

	{ // show something to indicate the links

		file << "sphere  { <0, 0, 0>, 1\n no_image true\ntransform { SETMATRIX }}\n";

	}



	// show the geometry if present

	DGeometry* prop = link->getGeometryProp();

	if (prop != NULL)

	{

		double invPropMatrix[4][4];

		link->getInvGeometryPropTransMat(invPropMatrix);



		file << "#declare SETMATRIX2 = transform { matrix < " << invPropMatrix[0][0] << ", " << invPropMatrix[0][1] << ", " << invPropMatrix[0][2] << ", ";

		file << invPropMatrix[1][0] << ", " << invPropMatrix[1][1] << ", " << invPropMatrix[1][2] << ", ";

		file << invPropMatrix[2][0] << ", " << invPropMatrix[2][1] << ", " << invPropMatrix[2][2] << ", ";

		file << invPropMatrix[3][0] << ", " << invPropMatrix[3][1] << ", " << invPropMatrix[3][2];



		file << "> }\n";

		prop->setVisible(true);

		prop->render(argc, argv, file);

		prop->setVisible(false);

	}



	// recurse to children

	int numChildren = link->getNumChildLinks();

	Link** children = link->getChildLinks();

	for (int x = 0; x < numChildren; x++)

	{

		renderRecurse(argc, argv, children[x], file);

	}

}



void ArticulatedObject::render(int argc, char** argv, std::ofstream& file)

{

	if (argc > 0 && strcmp(argv[0],"povray") == 0)

	{

		ArticulatedObject* ao = (ArticulatedObject*) this;

		int numLinks = ao->getNumLinks();



		//danceInterp::OutputMessage("\n\tnumLinks: %i", numLinks);



		if (numLinks == 0)

			return;

		

		renderRecurse(argc, argv, link[0], file);

		file << "#undef SETMATRIX\n";

		file << "#undef SETMATRIX2\n";

//		for (int j = 0; j < numLinks; j++)			// for each link, find the IFS and transform it

//		{

//			Link* link = ao->getLink(j);

			

			//link->getParentJoint()->getPosition(jposition);

			//this->drawJoint(jposition);





			// push a transformation matrix



/*

			IndexedFaceSet* ifs = (IndexedFaceSet*) geom;

			Material* ifs_mat = ifs->getMaterials();

			//ifs_mat->mAmbientColor[1];

					

			link->getTransMat(transMatrix);					

			link->getGeometry()->getTransMatrix(geomMatrix);

 

			povfile << "\nmesh { \n";



		// cast to an IndexedFaceSet

		// the IndexedFaceSet stores an array of faces (IndexedFace)

		// and normals. Look at the IndexedFaceSet.h code.		

		//IndexedFaceSet* ifs = (IndexedFaceSet*) dance::AllGeometry->get(i);

			IndexedFace* faces = ifs->getFaces();					



			// loop through the vertices

			for (int v = 0; v < ifs->getNumFaces(); v++)

			{	

				// ========= REMOVE ME FOR POV-RAY REMOVAL =========				

				povfile << "\tsmooth_triangle {";	



				// ========== Output all the Vertices for each Indexed Face ==============			

				for (int i = 0; i < faces[v].numVertices; i++)

				{

					Vector point;

					VecCopy(point, ifs->m_Vertices[faces[v].vertexIndex[i]]);																						

					transformPoint_mat(point, geomMatrix);

					transformPoint_mat(point, transMatrix);					

					



					// ========= REMOVE ME FOR POV-RAY REMOVAL =========				

					Vector pointNorm;

					VecCopy(pointNorm, ifs->m_Normals[faces[v].normalIndex[i]]);

					

					transformPoint_mat(pointNorm, geomMatrix);

					transformPoint_mat(pointNorm, transMatrix);										

				

					povfile << "<" << point[0] << ", " << point[1] << ", " << -point[2] << "> ";

					povfile << "<" << pointNorm[0] << ", " << pointNorm[1] << ", " << -pointNorm[2] << "> ";



					// ========= REMOVE ME FOR POV-RAY REMOVAL =========								

					if(i < 2)

						povfile << ",";

					

				}

				

				//povfile << "\n\t\ttexture { pigment {color Red}}";

				// ========= REMOVE ME FOR POV-RAY REMOVAL =========						

				povfile << "}\n";	// close the triangle

			}



			povfile << "\ntexture {pigment {color rgb <" << ifs_mat->mDiffuseColor[0]+ifs_mat->mAmbientColor[0] << ", " << ifs_mat->mDiffuseColor[1]+ifs_mat->mAmbientColor[1] << ", " << ifs_mat->mDiffuseColor[2]+ifs_mat->mAmbientColor[2] << ">} finish {Phong_Dull}}";

			povfile << "\n}";		// close the mesh

*/

//		}

	}

}



AnimationSequence* ArticulatedObject::getAnimationSequence()

{

	return &m_anim;

}



DSphereCollision** ArticulatedObject::getSphereCollisionData()

{

	return m_sphereCollisionData;

}



int ArticulatedObject::getNumSphereCollisionData()

{

	return m_numSphereCollisionData;

}



void ArticulatedObject::setSphereMaterial(Material* m)

{

	m_sphereMaterial=m;

}



Material* ArticulatedObject::getSphereMaterial()

{

	return m_sphereMaterial;

}



void ArticulatedObject::getLocalCoord(int group, double local[3], double world[3])

{

	if (group < this->m_numLinks)

		link[group]->getLocalCoord(local, world);

}



void ArticulatedObject::getWorldCoord(int group, double world[3], double local[3])

{

	if (group < this->m_numLinks)

		link[group]->getWorldCoord(world, local);

}



void ArticulatedObject::getWorldVelocity(int group, double world[3], double local[3])

{

	if( group >= 0 && group < m_numLinks )

	{

		link[group]->getWorldVelocity( world, local );

	}

}



void ArticulatedObject::getWorldCoord( double world[3], double local[3] )

{

	getWorldCoord( 0, world, local );

}



void ArticulatedObject::getLocalCoord( double local[3], double world[3] )

{

	getLocalCoord( 0, local, world );

}



void ArticulatedObject::getWorldVelocity(double world[3], double local[3])

{

	getWorldVelocity( 0, world, local );

}





void ArticulatedObject::setActiveJoint(Joint *joint)

{

	m_ActiveJoint = joint;

}



Joint* ArticulatedObject::getActiveJoint()

{

	return m_ActiveJoint;

}





void ArticulatedObject::getNewJointPos(Vector v)

{

	v[0] = newJointPos[0];

	v[1] = newJointPos[1];

	v[2] = newJointPos[2];

}



void ArticulatedObject::setNewJointPos(Vector v)

{

	VecCopy(newJointPos, v);

}



void ArticulatedObject::setRootNewJointPos(Vector v)

{

	VecCopy(rootNewJointPos, v);

}



void ArticulatedObject::setNewEndEffPos(Vector v)

{

	VecCopy(newEndEffPos, v);

}



void ArticulatedObject::setEmpty(bool b)

{

	m_isEmpty = b;

}



bool ArticulatedObject::isEmpty()

{

	return m_isEmpty;

}



DCollisionHierarchy* ArticulatedObject::getPointCollisionHierarchy()

{

	return m_pointHierarchy;

}



DCollisionHierarchy* ArticulatedObject::getSphereCollisionHierarchy()

{

	return m_sphereHierarchy;

}



void ArticulatedObject::renderHierarchy(DCollisionHierarchy* hierarchy, DSystem* sys)

{

	if (hierarchy != NULL)

	{

		glColor3f(1, 1, 0);

		glPushMatrix();

		// get the current location

		Vector curLoc;

		this->getLink(hierarchy->getID())->getWorldCoord(curLoc, hierarchy->getLocation());

		glTranslated(curLoc[0], curLoc[1], curLoc[2]);

		glScaled(hierarchy->getSize(), hierarchy->getSize(), hierarchy->getSize());

		glutWireSphere(1, 10, 10);

		glPopMatrix();



		// show the children

		for (int x = 0; x < hierarchy->getNumChildren(); x++)

		{

			DCollisionHierarchy* child = hierarchy->getChildren()[x];

			renderHierarchy(child, sys);

		}

	}

}



void ArticulatedObject::copy(ArticulatedObject* ao)

{

	// copy the topology

	string s = ao->getName();

	s.append(".sd");

	ao->writeSdFile((char*) s.c_str());



	this->loadSdfast((char*) s.c_str());

}



void ArticulatedObject::getGlobalTransMatrix(double matrix[4][4])

{

	for (int x = 0; x < 4; x++)

		for (int y = 0; y < 4; y++)

			matrix[x][y] = m_globalMatrix[x][y]; 

		

}



void ArticulatedObject::setGlobalTransMatrix(double matrix[4][4])

{

	for (int x = 0; x < 4; x++)

		for (int y = 0; y < 4; y++)

			 m_globalMatrix[x][y] =matrix[x][y];



}



bool ArticulatedObject::isUseGlobalMatrix()

{

	return m_useGlobalMatrix;

}



void ArticulatedObject::resetGlobalTransMatrix()

{

	setIdentMat(&m_globalMatrix[0][0], 4);

	m_useGlobalMatrix = false;

}



void ArticulatedObject::setEditJoint(bool b)

{

	edit_joint = b;

}

bool ArticulatedObject::getEditJoint()

{

	return edit_joint;

}



ArticulatedObject* ArticulatedObject::convertCharacterToArticulatedObject(Character* character, char* name)

{

	if (character == NULL)

	{

		danceInterp::OutputMessage("No character has been specified for conversion to articulated object.");

		return NULL;

	}



	// traverse the character and create a corresponding joint for each character joint

	ArticulatedObject* artObj = new ArticulatedObject();

	artObj->setName(name);

	dance::AllSystems->add(artObj);



	vector<CharJoint*> charJoints;

	int numCharJoints = character->getNumJoints();

	for (int cj = 0; cj < numCharJoints; cj++)

		charJoints.push_back(character->getJointByIndex(cj));



	vector<Link*> links;

	vector<Joint*> joints;

	// set up an array for the parent-child hierarchy

	int* parentIndex = new int[numCharJoints];

	for (int n = 0; n < numCharJoints; n++)

		parentIndex[n] = -1;



	for (int n = 0; n < numCharJoints; n++)

	{

		for (int m = 0; m < numCharJoints; m++) // find the parent index

		{

			CharJoint* tempParent = charJoints[m];

			if (tempParent == charJoints[n]->getParent())

			{

				parentIndex[n] = m;

			}

		}

	}



	for (int n = 0; n < numCharJoints; n++)

	{

		CharJoint* charJoint = character->getJointByIndex(n);

		Vector jointPosition;

		charJoint->getOffsetFromRoot(jointPosition);

		Link* link = new Link(n);

		link->setName(charJoint->getName());

		link->setArticulatedObject(artObj);

		Link* parent = NULL;

		if (parentIndex[n] != -1)

		{

			parent = links[parentIndex[n]];

		}



		// set the link axes

		link->setParentLink(parent);

		// position of center of mass of body is halfway to the average of all the child joints

		int numChildren = charJoint->getNumChildren();

		Vector linkPosition;

		Vector sumChildJointPosition = {0.0, 0.0, 0.0};

		if (numChildren != 0)

		{

			for (int c = 0; c < numChildren; c++)

			{

				CharJoint* child = charJoint->getChild(c);

				Vector childPosition;

				child->getOffsetFromRoot(childPosition);

				VecAdd(sumChildJointPosition, sumChildJointPosition, childPosition);

			}

			VecCopy(linkPosition, sumChildJointPosition);

			VecAdd(linkPosition, linkPosition, jointPosition);

			VecNumMul(linkPosition, linkPosition, 1.0 / (numChildren + 1.0));

		}

		else // no children, link position should be halfway to end effector

		{

			Vector endEffector;

			charJoint->getEndEffectorOffset(endEffector);

			VecNumMul(linkPosition, endEffector, .5);

			VecAdd(linkPosition, jointPosition, linkPosition);

		}

		CoordSystem cs;

		setVector(cs.x, 1.0, 0.0, 0.0);

		setVector(cs.y, 0.0, 1.0, 0.0);

		setVector(cs.z, 0.0, 0.0, 1.0);

		// calculate inboard and outboard parameters

		Vector bodyToJoint;

		VecSubtract(bodyToJoint, jointPosition, linkPosition);

		Vector inboardToJoint;

		if (parent != NULL)

		{

			CharJoint* parentCharJoint = character->getJointByIndex(parentIndex[n]);

			Vector parentJointPosition;

			parentCharJoint->getOffsetFromRoot(parentJointPosition);



			Vector parentBodyToJoint;

			parent->getParentJoint()->getBodyToJoint(parentBodyToJoint);

			Vector parentLinkPosition;

			VecSubtract(parentLinkPosition, parentJointPosition, parentBodyToJoint);



			VecSubtract(inboardToJoint, jointPosition, parentLinkPosition);



			VecAdd(cs.origin, cs.origin, parentLinkPosition);

		}

		else

		{

			setVector(inboardToJoint, 0, 0, 0);

		}



		double matrix[4][4];

		link->getTransMat(matrix);

		link->setCenterMass(matrix[3]);



//		link->setTransMat(cs);



		int jointType = J_FREE;

		int numAxes = 3;

		if (charJoint->getParent() != NULL)

		{

			int numChannels = charJoint->getNumChannels();

			if (numChannels == 1)

			{

				jointType = J_PIN;

				numAxes = 1;

				if (charJoint->useAxis()) // if the joint uses an axis, upgrade to 3 DOF

				{

					jointType = J_GIMBAL;

					numAxes = 3;

				}

			}

			else if (numChannels == 2)

			{

				jointType = J_UNIVERSAL;

				numAxes = 2;

				if (charJoint->useAxis()) // if the joint uses an axis, upgrade to 3 DOF

				{

					jointType = J_GIMBAL;

					numAxes = 3;

				}

			}

			else if (numChannels == 3)

			{

				jointType = J_GIMBAL;

				numAxes = 3;

			}

		}



		// add the joint

		Joint* joint = new Joint();

		joint->create(n, jointType, parent, link);

		joint->setNumAxis(numAxes);

		int offset = 0;

		if (jointType == J_FREE)

			offset = 3;

		int numChannels = charJoint->getNumChannels();

		int channels[6];

		charJoint->getChannels(channels);

		Vector xaxis = {1.0, 0.0, 0.0};

		Vector yaxis = {0.0, 1.0, 0.0};

		Vector zaxis = {0.0, 0.0, 1.0};

		for (int c = 0; c + offset < numChannels; c++)

		{

			if (channels[c + offset] == CharJoint::XROTATION)

				joint->setAxis(c, xaxis);

			else if (channels[c + offset] == CharJoint::YROTATION)

				joint->setAxis(c, yaxis);

			else if (channels[c + offset] == CharJoint::ZROTATION)

				joint->setAxis(c, zaxis);

		}

		joint->setInbToJoint(inboardToJoint);

		joint->setBodyToJoint(bodyToJoint);

		artObj->addJoint(joint);

		link->setParentJoint(joint);

		artObj->addLink(link);



		Vector endEffector;

		if (charJoint->isEndEffector())

		{ // end effector is explicitly indicated

			charJoint->getEndEffectorOffset(endEffector);

			// end effector given is offset from joint, but we need 

			// to calculate the offset from the link

			Vector finalOffset;

			VecAdd(finalOffset, endEffector, bodyToJoint);



			link->setEndEffector(finalOffset);

		}

		else

		{ // end effector is distance to the next joint

			double invMatrix[4][4];

			link->getInvTransMat(invMatrix);

			transformPoint_mat(linkPosition, invMatrix);

			Vector avgChildJoint;

			VecNumMul(avgChildJoint, sumChildJointPosition, 1.0 / numChildren);

			transformPoint_mat(avgChildJoint, invMatrix);

			VecSubtract(endEffector, avgChildJoint, linkPosition);

			link->setEndEffector(endEffector);

		}

danceInterp::OutputMessage("End Effector for %s (%d children) is %f %f %f", charJoint->getName(), numChildren, endEffector[0], endEffector[1], endEffector[2]);



		links.push_back(link);

		joints.push_back(joint);

	}



	artObj->updateStateConfig();



	// calculate masses automatically

	// assume that the character weighs 80 kg

	// assume that root joint has 20% of total body weight

	// assume that all the links have the same thickness and

	// the rest of the weight is proportional to the length

	// of the link.

	double totalMass = 80;

	double totalLength = 0;

	vector<double> distances;

	for (int l = 0; l < artObj->getNumLinks(); l++)

	{

		Link* link = artObj->getLink(l);

		double matrix[4][4];

		link->getWTransMat(matrix);

		Vector endEff;

		link->getEndEffector(endEff);

		transformPoint_mat(endEff, matrix);

		Vector joint;

		link->getParentJoint()->getBodyToJoint(joint);

		transformPoint_mat(joint, matrix);

		double dist = VecDist(endEff, joint);

		totalLength += dist;

		distances.push_back(dist);

	}



	// assign at least 20% of the mass to the root link

	for (int l = 0; l < artObj->getNumLinks(); l++)

	{

		Link* link = artObj->getLink(l);

		double proportion = distances[l] / totalLength;

		if (l == 0)

		{

			if (proportion < .2)

				link->setMass(totalMass * .2);

			else

				link->setMass(totalMass * proportion);

		}

		else

		{

				link->setMass(totalMass * proportion);

		}

		if (link->getMass() < 1)

			link->setMass(1);

		// set an approximate moment of inertia for a box = 1/6 m l^2

		double m;

		if (l == 0)

		{ 

			// moments of torso segment (assumed to be first)

			//m = .16666 * link->getMass() * .04 * totalLength * totalLength;

			m = ( 1.0 / 6.0 ) * 0.04 * totalLength * totalLength;

			// the 0.04 factor is because we're using the "total length" of the whole

			// character, but the torso is assumed to be 20% of the length (0.4)^2 = 0.04

		}

		else

		{

			// moments of all other segments

			m = ( 1.0 / 6.0 ) * distances[l] * distances[l];

		}

		double moments[] = {m, m, m};

		link->setMoments(moments);



		// set the stiffness/damping parameters

		Joint* joint = link->getParentJoint();

		for (int a = 0; a < joint->getNumAxis(); a++)

		{

			joint->setStiffness(a, m * joint->getStiffness(a));

			joint->setMaxStiffness(a, joint->getStiffness(a));

			joint->setDamping(a, joint->getStiffness(a) / 10.0);

			joint->setMaxDamping(a, joint->getDamping(a));

		}

	}



	

	return artObj;



}



void ArticulatedObject::save(int mode, std::ofstream& file)

{

	char buff[1024];



	if (mode == 0)

	{

		file << "dance.instance(\"ArticulatedObject\", \"" << this->getName() << "\")" << std::endl;

	}

	else if (mode == 1)

	{	

		// topology

		std::string topologyFileName = this->getName();

		topologyFileName.append(".sd");

		this->writeSdFile((char*) topologyFileName.c_str());

		sprintf(buff, "\"load\", \"sdfast\", \"%s\"", topologyFileName.c_str());

		pythonSave(file, buff);

		

		// spheres

		std::string sphereFileName = this->getName();

		sphereFileName.append(".sphere");

		this->saveSpheres((char*) sphereFileName.c_str());

		sprintf(buff, "\"load_spheres\", \"%s\"", sphereFileName.c_str());

		pythonSave(file, buff);



		// show spheres

		if (this->isShowingSpheres())

		{

			sprintf(buff, "\"show_spheres\"");

			pythonSave(file, buff);

		}

		else

		{

			sprintf(buff, "\"hide_spheres\"");

			pythonSave(file, buff);

		}



		// show collision geometry

		if (this->isShowingCollisionGeometry())

		{

			sprintf(buff, "\"show_collision_geometry\"");

			pythonSave(file, buff);

		}

		else

		{

			sprintf(buff, "\"hide_collision_geometry\"");

			pythonSave(file, buff);

		}



		// show inertia tensor approx

		if( isShowingInertia() )

		{

			sprintf(buff, "\"show_inertia\"");

			pythonSave(file, buff);

		}

		else

		{

			sprintf(buff, "\"hide_inertia\"");

			pythonSave(file, buff);

		}



		// sphere material

		Material* m = this->getSphereMaterial();

		if (m != NULL)

		{

			sprintf(buff, "\"sphere_material\", \"%s\"", m->getMaterialName());

			pythonSave(file, buff);

		}

		

		// inverse kinematics

		int numIK = this->getNumIKChains();

		for (int x = 0; x < numIK; x++)

		{

			IKChain* chain = this->getIKChain(x);

			sprintf(buff, "\"create_ik\", \"%s\"", chain->getName());

			pythonSave(file, buff);

			for (int j = 0; j < chain->getNumJoints(); j++)

			{

				Joint* joint = chain->getJoint(j);

				sprintf(buff, "\"ik\", \"%s\", \"add_joint\", \"%s\"", chain->getName(), joint->getName());

				pythonSave(file, buff);

			}

		}



		// joint limits, stiffness & damping

		for (int j = 0; j < this->getNumJoints(); j++)

		{

			double low, high;

			double stiff, damp;

			Joint* joint = this->getJoint(j);

			int numAxes = joint->getNumAxis();

			if (joint->getJointType() == J_BALL)

				numAxes = 3;

			for (int a = 0; a < numAxes; a++)

			{

				joint->getLimits(a, &low, &high);

				sprintf(buff, "\"joint\", \"%s\", \"dof\", %d, \"limits\", %f, %f", joint->getName(), a, low, high);

				pythonSave(file, buff);



				stiff = joint->getMaxStiffness(a);

				damp = joint->getMaxDamping(a);

				sprintf(buff, "\"joint\", \"%s\", \"dof\", %d, \"stiff_damp_no_inertia_scale\", %f, %f", joint->getName(), a, stiff, damp);

				pythonSave(file, buff);

            }

            

            if (joint->hasVelocity())

            {

                sprintf(buff, "\"joint\", \"%s\", \"has_velocity\", \"yes\"", joint->getName());

                pythonSave(file, buff);

                

                int stateSize = joint->getStateSize();

                for (int s = 0; s < stateSize; s++)

                {

                    sprintf(buff, "\"joint\", \"%s\", \"init_velocity\", %d, %f", joint->getName(), s, joint->getInitDState(s));

                    pythonSave(file, buff);

                }                

            }

            else

            {

                sprintf(buff, "\"joint\", \"%s\", \"has_velocity\", \"no\"", joint->getName());

                pythonSave(file, buff);

            }

		}



		// restitution, endeffectors

		for (int l = 0; l < this->getNumLinks(); l++)

		{

			Link* link = this->getLink(l);

			sprintf(buff, "\"link\", \"%s\", \"restitution\", %f", link->getName(), link->getRestitution());

			pythonSave(file, buff);



			Vector ee;

			link->getEndEffector(ee);

			sprintf(buff, "\"link\", \"%s\", \"endeffector\", %f, %f, %f", link->getName(), ee[0], ee[1], ee[2]);

			pythonSave(file, buff);

		}



		// show links



		// show joints



		// show spheres





	}

	else if (mode == 2)

	{

		// connect geometry to the links

		double* oldState = new double[this->getStateSize()];

		this->getState(oldState);



		// zero the state for binding purposes

		this->setZeroState();



		for (int x = 0; x < this->getNumLinks(); x++)

		{

			Link* curLink = this->getLink(x);

			DGeometry* geom = curLink->getGeometry();

			// geometry

			if (geom != NULL)

			{

				sprintf(buff, "\"link\", \"%s\", \"geometry\", \"%s\", \"world\"", curLink->getName(), geom->getName());

				pythonSave(file, buff);



				// geometry scale (if necessary)

				double* geomScale = curLink->getGeometryScale();

				sprintf(buff, "\"link\", \"%s\", \"scale\", %f, %f, %f", curLink->getName(), geomScale[0], geomScale[1], geomScale[2]);

				pythonSave(file, buff);



				// geometry inv trans mat

				double matrix[4][4];

				curLink->getInvGeometryTransMat(matrix);

				sprintf(buff, "\"link\", \"%s\", \"geom_inv_trans_matrix\", %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f", curLink->getName(), 

						matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3], 

						matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3], 

						matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3], 

						matrix[3][0], matrix[3][1], matrix[3][2], matrix[3][3]);

				pythonSave(file, buff);



				// monitor points

				Vector *pts;

				int numMonitorPoints = curLink->getGeometry()->getMonitorPoints(&pts);

				if (numMonitorPoints > 0)

				{

					if (curLink->isExplicitMonitorPoints())

					{

						file << "dance.system(\"" << this->getName() << "\", \"link\", \"" << curLink->getName() << "\", \"assign_monitor_points\", ";

						for (int x = 0; x < numMonitorPoints; x++)

						{

							if (x > 0)

								file << ", ";

							file << pts[x][0] << ", " << pts[x][1] << ", " << pts[x][2];



						}

						file << ")" << endl;

					}

					else

					{

						if (curLink->isRandomMonitorPoints())

						{

							sprintf(buff, "\"link\", \"%s\", \"assign_monitor_points_random\", %d", curLink->getName(), numMonitorPoints);

							pythonSave(file, buff);

						}

						else

						{

							sprintf(buff, "\"link\", \"%s\", \"assign_monitor_points\", %d", curLink->getName(), numMonitorPoints);

							pythonSave(file, buff);

						}

					}

				}

			}



			// collision geometry

			DGeometry* collisionGeom = curLink->getGeometryCollision();

			if (collisionGeom != NULL)

			{

				sprintf(buff, "\"link\", \"%s\", \"collision_geometry\", \"%s\", \"world\"", curLink->getName(), collisionGeom->getName());

				pythonSave(file, buff);



				// collision geometry scale (if necessary)

				double* geomScale = curLink->getGeometryCollisionScale();

				sprintf(buff, "\"link\", \"%s\", \"scale\", %f, %f, %f", curLink->getName(), geomScale[0], geomScale[1], geomScale[2]);

				pythonSave(file, buff);



				// collision geometry inv trans mat

				double matrix[4][4];

				curLink->getInvGeometryCollisionTransMat(matrix);

				sprintf(buff, "\"link\", \"%s\", \"collision_geom_inv_trans_matrix\", %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f", curLink->getName(), 

						matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3], 

						matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3], 

						matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3], 

						matrix[3][0], matrix[3][1], matrix[3][2], matrix[3][3]);

				pythonSave(file, buff);



				// collision monitor points

				Vector *pts;

				int numMonitorPoints = curLink->getGeometryCollision()->getMonitorPoints(&pts);

				if (numMonitorPoints > 0)

				{

					if (curLink->isExplicitMonitorPointsProp())

					{

						file << "dance.system(\"" << this->getName() << "\", \"link\", \"" << curLink->getName() << "\", \"assign_collision_monitor_points\", ";

						for (int x = 0; x < numMonitorPoints; x++)

						{

							if (x > 0)

								file << ", ";

							file << pts[x][0] << ", " << pts[x][1] << ", " << pts[x][2];



						}

						file << ")" << endl;

					}

					else

					{

						if (curLink->isRandomMonitorPoints())

						{

							sprintf(buff, "\"link\", \"%s\", \"assign_collision_monitor_points_random\", %d", curLink->getName(), numMonitorPoints);

							pythonSave(file, buff);

						}

						else

						{

							sprintf(buff, "\"link\", \"%s\", \"assign_collision_monitor_points\", %d", curLink->getName(), numMonitorPoints);

							pythonSave(file, buff);

						}

					}

				}

			}



			// prop geometry

			DGeometry* propGeom = curLink->getGeometryProp();

			if (propGeom != NULL)

			{

				// collision geometry

				sprintf(buff, "\"link\", \"%s\", \"prop_geometry\", \"%s\", \"world\"", curLink->getName(), propGeom->getName());

				pythonSave(file, buff);



				// collision geometry scale (if necessary)

				double* geomScale = curLink->getGeometryPropScale();

				sprintf(buff, "\"link\", \"%s\", \"scale\", %f, %f, %f", curLink->getName(), geomScale[0], geomScale[1], geomScale[2]);

				pythonSave(file, buff);



				// collision geometry inv trans mat

				double matrix[4][4];

				curLink->getInvGeometryPropTransMat(matrix);

				sprintf(buff, "\"link\", \"%s\", \"prop_geom_inv_trans_matrix\", %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f", curLink->getName(), 

						matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3], 

						matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3], 

						matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3], 

						matrix[3][0], matrix[3][1], matrix[3][2], matrix[3][3]);

				pythonSave(file, buff);



				// collision monitor points

				Vector *pts;

				int numMonitorPoints = curLink->getGeometryProp()->getMonitorPoints(&pts);

				if (numMonitorPoints > 0)

				{

					if (curLink->isExplicitMonitorPointsProp())

					{

						file << "dance.system(\"" << this->getName() << "\", \"link\", \"" << curLink->getName() << "\", \"assign_monitor_points\", ";

						for (int x = 0; x < numMonitorPoints; x++)

						{

							if (x > 0)

								file << ", ";

							file << pts[x][0] << ", " << pts[x][1] << ", " << pts[x][2];



						}

						file << ")" << endl;

					}

					else

					{

						if (curLink->isRandomMonitorPoints())

						{

							sprintf(buff, "\"link\", \"%s\", \"assign_prop_monitor_points_random\", %d", curLink->getName(), numMonitorPoints);

							pythonSave(file, buff);

						}

						else

						{

							sprintf(buff, "\"link\", \"%s\", \"assign_prop_monitor_points\", %d", curLink->getName(), numMonitorPoints);

							pythonSave(file, buff);

						}

					}

				}

			}



			// attachments

			int attachNum;

			ArticulatedObject* ao = curLink->getAttachment(attachNum);

			if (ao != NULL)

			{

				sprintf(buff, "\"link\", \"%s\", \"attachment\", \"%s\", \"%d\"", curLink->getName(), ao->getName(), attachNum);

				pythonSave(file, buff);

			}



			// static attachments

			DGeometry* staticgeom = curLink->getAttachmentStatic();

			if (staticgeom != NULL)

			{

				sprintf(buff, "\"link\", \"%s\", \"attachment_static\", \"%s\"", curLink->getName(), staticgeom->getName());

				pythonSave(file, buff);

			}

		}

		// reset the state

		this->setState(oldState);



		delete [] oldState;



		// state

		std::string stateFileName = this->getName();

		stateFileName.append(".state");

		this->saveStateConfig((char*) stateFileName.c_str());

		sprintf(buff, "\"load\", \"state\", \"%s\"", stateFileName.c_str());

		pythonSave(file, buff);



		// dstate (velocities)

		std::string dstateFileName = this->getName();

		dstateFileName.append(".dstate");

		this->saveDStateConfigExplicitVelocities((char*) dstateFileName.c_str());

		sprintf(buff, "\"load\", \"dstate\", \"%s\"", dstateFileName.c_str());

		pythonSave(file, buff);

                // initdstate (initial velocities)
		std::string initdstateFileName = this->getName();

		initdstateFileName.append("_init");
		initdstateFileName.append(".dstate");

		this->saveDStateConfig((char*) initdstateFileName.c_str(),
true);

		sprintf(buff, "\"load\", \"initdstate\", \"%s\"", initdstateFileName.c_str());

		pythonSave(file, buff);






		// save any recorded frames

		if (this->m_anim.getNumKeyFrames() > 0)

		{

			std::string animFileName = this->getName();

			animFileName.append(".bvh");

			std::ofstream bvhfile(animFileName.c_str());

			if (bvhfile.good())

			{

				double frameRate = (this->m_anim.getKeyFrameByIndex(this->m_anim.getNumKeyFrames() - 1)->getTime() - this->m_anim.getKeyFrameByIndex(0)->getTime()) / this->m_anim.getNumKeyFrames();

				if (abs(frameRate ) < 10e-6)

					frameRate = .033;

				this->m_anim.saveBVHFrameTime(bvhfile, frameRate);

			}

			else

			{

				danceInterp::OutputMessage("Articulated object %s could not open file %s for writing recorded animation.", this->getName(), animFileName.c_str());			}

			bvhfile.close();

			sprintf(buff, "\"load\", \"anim\", \"%s\"", animFileName.c_str());

			pythonSave(file, buff);

		}



	}



	DSystem::save(mode, file);

}



void ArticulatedObject::setEditMode(bool val)

{

	m_editJointMode = val;

}



bool ArticulatedObject::isEditMode()

{

	return m_editJointMode;

}



void ArticulatedObject::setInteractionMode(int mode)

{

	interactionMode = mode;



	if(interactionMode == IK_mode)

	{

		danceInterp::OutputMessage("IK Mode is now on.");

		dance::addInteraction(this);

	}

	else if (interactionMode == EDIT_mode)

	{

		danceInterp::OutputMessage("Edit Mode is now on.");

		dance::addInteraction(this);

	}

	else if (interactionMode == NO_mode)

	{

		danceInterp::OutputMessage("Interaction mode now off.");

		dance::removeInteraction(this);

	}

	else

	{

		danceInterp::OutputMessage("NO MODE is now on.");

		dance::addInteraction(this);

	}

	if(this->m_ArticulatedObjectWindow != NULL)

		this->m_ArticulatedObjectWindow->updateGUI();



}

int ArticulatedObject::getInteractionMode()

{

	return interactionMode;

}



void ArticulatedObject::setCMvalidity(bool val)

{

	cm_valid = val;

}



bool ArticulatedObject::getCMvalidity()

{

	return cm_valid;

}



void ArticulatedObject::setNewCMPos(Vector cm)

{

	VecCopy(newCMPos, cm);

}



void ArticulatedObject::setLinkColor(double r, double g, double b)

{

	setVector(m_linkColor, r, g, b);

}



double* ArticulatedObject::getLinkColor()

{

	return m_linkColor;

}



int ArticulatedObject::getNumPluginDependents()

{

	return 2;

}



const char* ArticulatedObject::getPluginDependent(int num)

{

	if (num == 0)

		return "Cube";

	else if (num == 1)

		return "Sphere";

	else

		return NULL;

}



ArticulatedObject* ArticulatedObject::convertGeometryToArticulatedObject(DGeometry* geometry)

{

	ArticulatedObject* ao = new ArticulatedObject();

	char buff[1024];

	sprintf(buff, "%s_moveable", geometry->getName());

	ao->setName(buff);

	ao->setPlayback(true);

	ao->setRecording(false);



	dance::AllSystems->add(ao);



// create a free joint and associated link for this rigid body

	Link* link = new Link(0);

	link->setName("root");

	ao->addLink(link);



	Joint* joint = new Joint();

	joint->setName("root");

	joint->setInboardLink(NULL);

	joint->setOutboardLink(link);

	joint->setJointType(J_FREE);

	link->setParentJoint(joint);

	ao->addJoint(joint);

	Vector endEffector = {0.0, 0.5, 0.0};

	link->setEndEffector(endEffector);



	// set the XYZ location of the system

	// (at the center of the geometry)

	BoundingBox box;

	geometry->calcBoundingBox(&box);

	Vector center;

	box.getMidPoint(center);



	for (int x = 0; x < 3; x++)

		ao->setState(x, center[x]);



	link->replaceGeometry(geometry, true);

	// add some monitor points for easy collisions with the ground

	link->assignMonitorPoints(30);



	return ao;

}



void ArticulatedObject::calculateStateIndexMapping()

{

	int cur = 0;

	for (int j = 0; j < this->getNumJoints(); j++)

	{

		int stateSize = joint[j]->getStateSize();

		for (int x = cur; x < cur + stateSize; x++)

		{

			stateIndexMapping[cur + x] = j; 

			stateDOFMapping[cur + x] = x;

			stateJointMapping[j][x - cur] = x;

		}

		cur += stateSize;

	}

}





int ArticulatedObject::getStateMapping(int jointNum, int jointStateNum)

{

	return stateJointMapping[jointNum][jointStateNum];

}



void ArticulatedObject::calcTotalInertia( void )

{

	changeToLocal();

	Link* root = getLinks()[0];  // Computes starting with the root joint.  Will only work for singly rooted hierarchies

	root->accumTotalInertia();

	changeToGlobal();

}



double ArticulatedObject::getLastRecordTime()

{

	return this->m_anim.getEndTime();



}

