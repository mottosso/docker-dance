/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _CHARACTERANIMATIONSEQUENCE_
#define _CHARACTERANIMATIONSEQUENCE_

#ifdef WIN32
#ifdef _EXPORTING_AR
#define DLLENTRY_AR __declspec(dllexport)
#else
#define DLLENTRY_AR __declspec(dllimport)
#endif
#else
#define DLLENTRY_AR
#endif

#include <fstream>

#include "AnimationSequence.h"
#include "Character.h"
#include "CharJoint.h"

class ArticulatedObject;
class Joint;

class DLLENTRY_AR CharacterAnimationSequence : public AnimationSequence
{
	public:
		CharacterAnimationSequence(ArticulatedObject* ao);
		CharacterAnimationSequence();

		void setArticulatedObject(ArticulatedObject* ao);
		ArticulatedObject* getArticulatedObject();

		int load(char *fname, int N1 = -1, int N2 = 2000000);
		int save(char *fname);

		int loadBVH(std::ifstream& file, int N1 = -1, int N2 = 2000000);
		int saveBVH(std::ofstream& file, double fps = 30.0);
		int saveBVHFrameTime(std::ofstream& file, double frameTime = .033);
		int saveDKF(FILE * fp, double fps = 30.0);
		int loadDKF(FILE* fp);

		bool interpolate(double time, double* val);

private:
		bool compareJointHierarchyRecurse(CharJoint* charJoint, Joint* joint);
		void loadBVHJointHierarchyRecurse(CharJoint* charJoint, Joint* joint, KeyFrame* kf, int& index, int frameNum);
		void convertToCharacterRecurse(Character* c, CharJoint* charParent, CharJoint* charJoint, Joint* parent, Joint* joint);

		ArticulatedObject* m_ao;
};


#endif
