/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "KeyFrameEditorWindow.h"
#include "KeyFrame.h"
#include "dance.h"
#include <fltk/ask.h>

using namespace fltk;

KeyFrameEditorWindow::KeyFrameEditorWindow(ArticulatedObjectWindow *aWin, int x, int y, const char *l)
	: Window(x, y, 700, 135, l)
{
	m_ao = aWin->m_artObj;
	m_animSeq = (CharacterAnimationSequence*)m_ao->getAnimationSequence();

	this->begin();

	timeSlider = new TimeSlider(5, 10, 690, 35);
	timeSlider->callback(timeSlider_cb, this);
	timeSlider->box(DOWN_BOX);
	timeSlider->type(Slider::TICK_ABOVE);
	timeSlider->step(0.001);

	rangeSlider = new RangeSlider(5, 60, 610, 20);
	rangeSlider->time_slider(timeSlider);

	homeButton = new Button(615, 60, 20, 20, "@<<");
	homeButton->callback(homeButton_button_cb, this);
	homeButton->tooltip("Goto start of time slider range.");

	prevKeyButton = new Button(635, 60, 20, 20, "@[]<");
	prevKeyButton->callback(prevKeyButton_button_cb, this);
	prevKeyButton->tooltip("Step back one key.");

	nextKeyButton = new Button(655, 60, 20, 20, "@>[]");
	nextKeyButton->callback(nextKeyButton_button_cb, this);
	nextKeyButton->tooltip("Step forward one key.");

	endButton = new Button(675, 60, 20, 20, "@>>");
	endButton->callback(endButton_button_cb, this);
	endButton->tooltip("Goto end of time slider range.");

	refreshButton = new Button(5, 110, 100, 20, "Refresh Editor");
	refreshButton->callback(refresh_button_cb, this);

	displayButton = new CheckButton(5, 85, 20, 20, "Slider Updates Display");
	displayButton->callback(displayButton_button_cb, this);
	displayButton->align(ALIGN_RIGHT);
	displayButton->tooltip("If activated, changing the Time Slider's value will update the DANCE display.");
	displayButton->value(false);

	numKeysOutput = new Output(325, 85, 50, 20, "Total Keyframes:");
	numKeysOutput->align(ALIGN_LEFT);

	addButton = new Button(385, 85, 100, 20, "Add Keyframe");
	addButton->callback(addButton_button_cb, this);

	replaceButton = new Button(490, 85, 100, 20, "Replace Keyframe");
	replaceButton->callback(replaceButton_button_cb, this);

	removeButton = new Button(595, 85, 100, 20, "Remove Keyframe");
	removeButton->callback(removeButton_button_cb, this);

	removeBeforeButton = new Button(385, 110, 100, 20, "@< Remove Keyframe"); 
	removeBeforeButton->callback(this->removeLeft_button_cb, this);

	removeAfterButton = new Button(490, 110, 100, 20, "Remove Keyframe @>"); 
	removeAfterButton->callback(this->removeRight_button_cb, this);

	removeAllButton = new Button(595, 110, 100, 20, "Clear Keyframes");
	removeAllButton->callback(removeAllButton_button_cb, this);
	removeAllButton->tooltip("Removes all keyframes from the animation sequence.");

	this->end();

	_updateDisplay = displayButton->value();
	
	this->loadKeyframes();
	this->updateGUI();
	this->redraw();
}

void KeyFrameEditorWindow::updateGUI()
{
	// which buttons do we activate?
	addButton->activate();
	replaceButton->deactivate();
	removeButton->deactivate();
	removeAllButton->deactivate();
	for (std::vector<double>::iterator iter = timeSlider->keyframes.begin(); iter != timeSlider->keyframes.end(); iter++)
	{
		if ((*iter) == timeSlider->value())
		{
			addButton->deactivate();
			replaceButton->activate();
			removeButton->activate();
			break;
		}
	}

	if (timeSlider->keyframes.size() > 0)
		removeAllButton->activate();

	char buf[128];
	sprintf(buf, "%d", timeSlider->keyframes.size());
	numKeysOutput->value(buf);
}

void KeyFrameEditorWindow::loadKeyframes()
{
	// load in keyframes
	timeSlider->removeAllKeyFrames();
	if (m_animSeq != NULL)
	{
		for (int i = 0; i < m_animSeq->getNumKeyFrames(); i++)
		{
			KeyFrame *key = m_animSeq->getKeyFrameByIndex(i);
			timeSlider->value(key->getTime());
			timeSlider->addKeyFrame();
		}
	}
	timeSlider->setEndTime(m_animSeq->getEndTime());
	timeSlider->redraw();
	rangeSlider->input3->value(m_animSeq->getEndTime());
	rangeSlider->input4->value(m_animSeq->getEndTime());
	rangeSlider->redraw();
}

void KeyFrameEditorWindow::show()
{
	this->loadKeyframes();
	this->updateGUI();
	Window::show();
}

void KeyFrameEditorWindow::timeSlider_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;
	kWin->updateGUI();
	kWin->redraw();

	if (kWin->_updateDisplay)
	{
		double time = kWin->timeSlider->value();
		kWin->m_ao->setState(time);
		dance::AllViews->postRedisplay();
	}
}

void KeyFrameEditorWindow::homeButton_button_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;
	kWin->timeSlider->gotoStartTime();
	kWin->updateGUI();
	kWin->redraw();

	double time = kWin->timeSlider->value();
	if (dance::AllSimulators->getSimulationMode() == dance::AllSimulators->MODE_SIMULATION)
	{
		dance::AllSimulators->setSimulationMode(dance::AllSimulators->MODE_PLAYBACK);
		dance::AllSimulators->calculatePlaybackEndTime();
	}
	dance::AllSimulators->setPlaybackTime(time);

	if (kWin->_updateDisplay)
		dance::AllViews->postRedisplay();
}

void KeyFrameEditorWindow::prevKeyButton_button_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;
	kWin->timeSlider->prevKeyFrame();
	kWin->updateGUI();
	kWin->redraw();

	double time = kWin->timeSlider->value();
	if (dance::AllSimulators->getSimulationMode() == dance::AllSimulators->MODE_SIMULATION)
	{
		dance::AllSimulators->setSimulationMode(dance::AllSimulators->MODE_PLAYBACK);
		dance::AllSimulators->calculatePlaybackEndTime();
	}
	dance::AllSimulators->setPlaybackTime(time);

	if (kWin->_updateDisplay)
		dance::AllViews->postRedisplay();
}

void KeyFrameEditorWindow::nextKeyButton_button_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;
	kWin->timeSlider->nextKeyFrame();
	kWin->updateGUI();
	kWin->redraw();

	double time = kWin->timeSlider->value();
	if (dance::AllSimulators->getSimulationMode() == dance::AllSimulators->MODE_SIMULATION)
	{
		dance::AllSimulators->setSimulationMode(dance::AllSimulators->MODE_PLAYBACK);
		dance::AllSimulators->calculatePlaybackEndTime();
	}
	dance::AllSimulators->setPlaybackTime(time);

	if (kWin->_updateDisplay)
		dance::AllViews->postRedisplay();
}

void KeyFrameEditorWindow::endButton_button_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;
	kWin->timeSlider->gotoEndTime();
	kWin->updateGUI();
	kWin->redraw();

	if (kWin->_updateDisplay)
	{
		double time = kWin->timeSlider->value();
		kWin->m_ao->setState(time);
		dance::AllViews->postRedisplay();
	}
}

void KeyFrameEditorWindow::displayButton_button_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;
	kWin->_updateDisplay = kWin->displayButton->value();

	if (kWin->_updateDisplay)
	{
		double time = kWin->timeSlider->value();
		kWin->m_ao->setState(time);
		dance::AllViews->postRedisplay();
	}
}

void KeyFrameEditorWindow::addButton_button_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;
	kWin->timeSlider->addKeyFrame();
	kWin->updateGUI();
	kWin->redraw();

	//
	// insert keyframe into AnimationSequence
	//
	int size = kWin->m_ao->getStateSize();
	KeyFrame *kf = new KeyFrame(size);
	kf->setTime(kWin->timeSlider->value());
	
	// set parameters
	for (int x = 0; x < size; x++)
	{
		double val = kWin->m_ao->getState(x);
		kf->setParam(x, val);
	}

	kWin->m_animSeq->insertKeyFrame(kf);

	// recalculate the playback
	kWin->m_ao->setLastRecordTime(kWin->m_animSeq->getEndTime());
	dance::AllSimulators->calculatePlaybackEndTime();
	dance::rootWindow->simControlWindow->adjustCurrent();
}

void KeyFrameEditorWindow::replaceButton_button_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;

	//
	// replace keyframe in AnimationSequence
	//
	double time = kWin->timeSlider->value();
	int size = kWin->m_ao->getStateSize();
	KeyFrame *old_kf = kWin->m_animSeq->getKeyFrame(time);
	if (old_kf == NULL)
	{
		danceInterp::OutputMessage("No keyframe found at time %f, use 'Add Keyframe' instead.", time);
		return ;
	}

	KeyFrame *new_kf = new KeyFrame(size);
	new_kf->setTime(time);
	
	// set parameters
	for (int x = 0; x < size; x++)
	{
		double val = kWin->m_ao->getState(x);
		new_kf->setParam(x, val);
	}

	kWin->m_animSeq->replaceKeyFrame(old_kf, new_kf);
	danceInterp::OutputMessage("Keyframe at time %f successfully replaced.", time);

	// recalculate the playback
	kWin->m_ao->setLastRecordTime(kWin->m_animSeq->getEndTime());
	dance::AllSimulators->calculatePlaybackEndTime();
	dance::rootWindow->simControlWindow->adjustCurrent();
}

void KeyFrameEditorWindow::removeButton_button_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;
	kWin->timeSlider->removeKeyFrame();
	kWin->updateGUI();
	kWin->redraw();

	// remove keyframe from AnimationSequence
	kWin->m_animSeq->deleteKeyFrame(kWin->timeSlider->value());

	// recalculate the playback
	kWin->m_ao->setLastRecordTime(kWin->m_animSeq->getEndTime());
	dance::AllSimulators->calculatePlaybackEndTime();
	dance::rootWindow->simControlWindow->adjustCurrent();
}

void KeyFrameEditorWindow::removeLeft_button_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;
	if (ask("Are you sure you want to remove\nall keyframes for time < %6.2f?", kWin->timeSlider->value()))
	{
		kWin->timeSlider->removeKeyFramesLess(kWin->timeSlider->value());
		kWin->updateGUI();
		kWin->redraw();
	}
	

	// remove keyframe from AnimationSequence
	kWin->m_animSeq->deleteKeyFramesBefore(kWin->timeSlider->value());

	// recalculate the playback
	kWin->m_ao->setLastRecordTime(kWin->m_animSeq->getEndTime());
	dance::AllSimulators->calculatePlaybackEndTime();
	dance::rootWindow->simControlWindow->adjustCurrent();
}

void KeyFrameEditorWindow::removeRight_button_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;
	if (ask("Are you sure you want to remove\nall keyframes for time > %6.2f?", kWin->timeSlider->value()))
	{
		kWin->timeSlider->removeKeyFramesGreater(kWin->timeSlider->value());
		kWin->updateGUI();
		kWin->redraw();
	}

	// remove keyframe from AnimationSequence
	kWin->m_animSeq->deleteKeyFramesAfter(kWin->timeSlider->value());

	// recalculate the playback
	kWin->m_ao->setLastRecordTime(kWin->m_animSeq->getEndTime());
	dance::AllSimulators->calculatePlaybackEndTime();
	dance::rootWindow->simControlWindow->adjustCurrent();
}


void KeyFrameEditorWindow::removeAllButton_button_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;

	// remove all keyframes
	if (fltk::ask("Are you sure you want to remove all keyframes from the current animation sequence?"))
	{
		kWin->m_animSeq->deleteKeyFrames();
		kWin->timeSlider->removeAllKeyFrames();

		danceInterp::OutputMessage("All keyframes have been successfully removed.");

		kWin->updateGUI();
		kWin->redraw();
	}
}

void KeyFrameEditorWindow::refresh_button_cb(fltk::Widget *o, void *p)
{
	KeyFrameEditorWindow *kWin = (KeyFrameEditorWindow *)p;
	kWin->loadKeyframes();
	kWin->updateGUI();
	kWin->redraw();
}
