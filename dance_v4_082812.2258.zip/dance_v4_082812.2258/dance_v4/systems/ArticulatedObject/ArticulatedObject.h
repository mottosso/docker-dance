/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_ARTICOBJECT_H_
#define	_ARTICOBJECT_H_

//********************************************************
//-------- Articulated objects header file  --------------
//********************************************************

#include "defs.h"
#include "DSystem.h"
#include "DModifier.h"
#include "CharacterAnimationSequence.h"
#include "DCollision.h"
#include "Material.h"
#include "DCollisionHierarchy.h"
#include "InertiaTensor.h"

#include <fltk/gl.h>
//#include <vector>

#define MAX_LINKS 300
#define MAX_JOINTS 300
#define MAX_STATE 700

#define INTERACT_NONE 0
#define DRAW_JOINT 1
#define CHANGE_TYPE 2

#ifdef WIN32
#ifdef _EXPORTING_AR
#define DLLENTRY_AR __declspec(dllexport)
#else
#define DLLENTRY_AR __declspec(dllimport)
#endif
#else
#define DLLENTRY_AR
#endif

class ArticulatedObjectWindow;
class Link;
class Joint;
class IKChain;

enum Mode
{
	NO_mode,
	IK_mode,
	EDIT_mode,
} ;

class DView ;
class DSimulator ;
class DSystem ;
class BoundingBox ;

class DLLENTRY_AR ArticulatedObject : public DSystem {
public:
//	friend class Link;

	PlugIn* create(int argc, char **argv) ;

	ArticulatedObject()	;
	~ArticulatedObject() ;

	int commandPlugIn(int argc, char **argv);
	void output(int mode);
	int interact(Event *event);
	void render(int argc, char** argv, std::ofstream& file);
	fltk::Widget* getInterface();
	void onDependencyRemoval(DObject* object);

	int getStateSize();
	void setState(int index, double val);
	double getState(int index);
	void setState(double* val);
	void getState(double* val);
	void setState(double time);
	void setZeroState();
	void recalculateStateSize();
	int getStateMapping(int jointNum, int jointStateNum);

	void setDState( double* arg );
	void getDState( double* arg );

	void recordState(double time);
	void erasePlayback();

	INLINE int getNumLinks() {return m_numLinks; };
	INLINE Link** getLinks() {return &link[0]; };
	INLINE Link*getLink(int i)	{return	link[i]; };
	Joint* getJoint(const char *name);
	Link* getLink(const char *name);
	INLINE int getNumJoints() {	return m_numJoints; };
	Joint** getJoints() { return &joint[0]; };
	Joint* getJoint(int	val);

	void setShowingLinks(bool val);
	bool isShowingLinks( void );
	void setShowingJoints(bool val);
	bool isShowingJoints( void );

	void setShowingSpheres(bool val);
	bool isShowingSpheres( void );

	void setShowingCollisionGeometry(bool val);
	bool isShowingCollisionGeometry( void );

	void setIsShowingInertia( bool argVal );
	bool isShowingInertia( void );

	void setIsShowingAttachments( bool argVal );
	bool isShowingAttachments( void );

	bool loadSpheres(char* fname);
	bool saveSpheres(char* fname);

	bool areLinksRelativeToParent() { return treeFlag ;};
	INLINE double *getCM(double	v[3]) {	VecCopy(v,m_cm) ; return &v[0] ; } ;
	INLINE double getMass() { return m_Mass ; } ;
	INLINE Link	*getActiveLink() { return m_ActiveLink ;} ;
	void getCurrentEndEffector(double pt[3]) ;

	void changeToLocal() ;
	void changeToGlobal() ;
	void moveJointAndParents(int jointID, double pos[3]);
	void moveJointAndChildren(int jointID, double pos[3]);
	void addJoint(Joint	*) ;
	void removeLink(Link *) ;
	void DeleteLinkChildren(Link *wlink);

	int m_CheckCollisions;

	int setNumLinks(int num);
	int setNumJoints(int num);
	void addLink(Link* link);
	Link *addLink(double pt1[3],double pt2[3]);
	double *calcCM() ;
	double *calcCMVelocity(Vector vcm) ;

	void setCurrentEndEffector(double pt[3]) ;
	INLINE void	setActiveLink(Link *l) { m_ActiveLink	= l ; }	;
	int simul();

	void setName(const char* name);

	int loadSdfast(const char* filename) ;
	int writeSdFile(const char* filename = NULL) ;
	void WriteMayaFile(const char* filename = NULL) ;
	void WriteBVHFile(const char* filename) ;
	void WriteBVHFile(FILE* fp) ;
	virtual int saveObj(char format[256], char* filename);

	int loadStateConfig(const char* fname = NULL);
	int saveStateConfig(const char* fname = NULL);
	int loadDStateConfig(const char* fname = NULL, bool useInitVelocities = false);
	int saveDStateConfig(const char* fname = NULL, bool useInitVelocities = false);
	int saveDStateConfigExplicitVelocities(char* fname = NULL);

	void setInitDState( double* arg ) ;


	void UpdateState(double *state) ;
	void SetLastState();
	void updateStateConfig(int index = -1);

	void setActiveJoint(Joint *joint);
	Joint* getActiveJoint();
  
	int combineLinks(int argc, char **argv) ;

	/// Computes the total inertia of all links by recursive iteration.
	/// Needs to be called after any significant changes to joint angles or 
	/// ArticualtedObject orientation.
	/// Used by PDController's getTotalInertia
	void calcTotalInertia( void );

	int m_numLinks ;		// number of links
	int m_numJoints ;		// number of joints
	Link *link[MAX_LINKS] ;	// all links
	Joint *joint[MAX_JOINTS] ;	 // all	joints
	Vector  m_cm ;
	double m_Mass ;
	double density ;
	bool treeFlag ;		// if true then	each link is considered	relative to its	parent
	double m_CurrentEndEffector[3] ;
	double m_AnchorPoint[3];

	Joint* HandleJointAdd(int linkNumber, int jointType, Vector axis1, Vector axis2, Vector axis3);				//added by Julia Summer 05
	void getWorldPos(double world[3]);	//(Jonathan's code)
	int deleteLinkAndJoint(Link* link, Joint* joint);
	void getNewJointPos(Vector);
	void setNewJointPos(Vector);
	void setRootNewJointPos(Vector);
	void setNewEndEffPos(Vector);
	void setNewCMPos(Vector);
	void setEmpty(bool b);
	bool isEmpty();
	void setEditJoint(bool b);
	bool getEditJoint();
	void setEditMode(bool val);
	bool isEditMode();
	void setCMvalidity(bool val);
	bool getCMvalidity();
	//END added by Julia

	double GetGroupMass(int index);
	int GetNumGroups() { return m_numLinks ;} ;
	BoundingBox	*calcBoundingBox(BoundingBox *b)	;  

	bool isColliding();
	void setColliding(bool val);

	AnimationSequence* getAnimationSequence();

	//added by achu
	void assignModifier(DModifier *mod);
	void removeModifier(DModifier *mod);

	double getHeight();
	double getWidth();

	DCollision** getPointCollisionData();
	int getNumPointCollisionData();
	DCollisionHierarchy* getPointCollisionHierarchy();

	DSphereCollision** getSphereCollisionData();
	int getNumSphereCollisionData();
	DCollisionHierarchy* getSphereCollisionHierarchy();

	void setSphereMaterial(Material* m);
	Material* getSphereMaterial();

	void startSimulation();
	void endSimulation();

	void getLocalCoord(int group, double local[3], double world[3]);
	void getWorldCoord(int group, double world[3], double local[3]);

	void getWorldVelocity(int group, double world[3], double local[3]);

	virtual void getWorldCoord(double world[3], double local[3]);
	virtual void getLocalCoord(double local[3], double world[3]);

	virtual void getWorldVelocity(double world[3], double local[3]);
	
	void copy(ArticulatedObject* ao);
	void setShowingActiveBox(bool val);
	bool isShowingActiveBox();
	void getGlobalTransMatrix(double matrix[4][4]);
	void setGlobalTransMatrix(double matrix[4][4]);
	bool isUseGlobalMatrix();
	void resetGlobalTransMatrix();

	//IK and EDIT MODE stuff//
	int interactionMode;

	void setInteractionMode(int mode);
	int getInteractionMode();
	//end IK and EDIT MODE stuff//

	// begin IK stuff //
	void createIKChain(char *name = 0);
	void createIKChain(IKChain *ikChain);
	int removeIKChain(char *name = 0);
	void setShowActiveIKChain(bool val);
	bool isShowActiveIKChain();
	void setShowActiveIKTarget(bool val);
	bool isShowActiveIKTarget();
	int getNumIKChains();
	int getIKChainNum(IKChain* chain);
	void setActiveIKChain(int i);
	int getActiveIKChain();
	IKChain* getIKChain(int i);
	IKChain* getIKChain(char* name);
	void activateIKChain();
	void deactivateIKChain();
	void pushIK_cb(int button, int x, int y);
	void dragIK_cb(int button, int x, int y);
	void releaseIK_cb(int button, int x, int y);
	// end IK stuff //

	void save(int mode, std::ofstream& file);
	static ArticulatedObject* convertCharacterToArticulatedObject(Character* character, char* name);

	void setLinkColor(double r, double g, double b);
	double* getLinkColor();

	int getNumPluginDependents();
	const char* getPluginDependent(int num);

	static ArticulatedObject* convertGeometryToArticulatedObject(DGeometry* geom);

	double getLastRecordTime();
protected:
	void displayLinks(int mode = 0);
	void displayJoints(int mode = 0);

	void createPointCollisionHierarchy();
	void createSphereCollisionHierarchy();

private:
	int interactEditMode(Event *event);
	int interactIKMode(Event *event);

	void renderHierarchy(DCollisionHierarchy* hierarchy, DSystem* sys);
	void renderRecurse(int argc, char** argv, Link* link, std::ofstream& file);

	void calculateStateIndexMapping();

	Link *m_ActiveLink ;
	Joint * m_ActiveJoint;

	bool m_isColliding;

	//added by achu
	std::vector<DModifier*> m_influencedModifiers;

	bool m_selectMode;
	int m_selectMouseX;
	int m_selectMouseY;

	bool m_dimensionCalculated;
	BoundingBox* m_originalDimensions;
	double m_height;
	double m_width;
	bool m_isShowingLinks;
	bool m_isShowingJoints;
	bool m_isShowingActiveBox;
	bool m_isShowingSpheres;
	bool m_isShowingCollisionGeometry;
	bool m_isShowingInertia;  //< if true, then the composite inertia tensor (if computed) will be displayed
	bool m_isShowingAttachments;

	double m_dstate[MAX_STATE];
	ArticulatedObjectWindow* m_ArticulatedObjectWindow;
	bool m_flagChangedSize;
	int m_stateSize;
	CharacterAnimationSequence m_anim;

	DCollision** m_collisionData;
	int m_numCollisionData;

	DSphereCollision** m_sphereCollisionData;
	int m_numSphereCollisionData;
	Material *m_sphereMaterial;

	DCollisionHierarchy* m_pointHierarchy;
	DCollisionHierarchy* m_sphereHierarchy;

	//variables for event handle (skeleton draw) : julia
	int draw_mode;
	Vector rootNewJointPos;
	Vector newJointPos;
	Vector newEndEffPos;
	Vector newCMPos;

	bool m_isEmpty;
	bool firstclick;
	bool edit_joint;
	bool m_editJointMode;
	bool cm_valid;

	// BEGIN: ik chain stuff //
//	bool m_ikMode;
	bool m_validIKChain;
	bool m_showActiveIKChain;
	bool m_showIKTarget;
	Vector m_ikOrigin;
	Vector m_ikTarget;
	Vector m_ikEndEffector;
	std::vector<IKChain*> m_ikChain;
	
	int m_activeIKChain;
	int m_initMousePosition;

	void computeIKChain();
	void updateIKChain(const double *dtheta);
	
	// END: ik chain stuff //
	double m_globalMatrix[4][4];
	bool m_useGlobalMatrix;

	Vector m_linkColor;
	int stateIndexMapping[MAX_STATE];
	int stateDOFMapping[MAX_STATE];
	int stateJointMapping[MAX_LINKS][7];
} ;

#endif

