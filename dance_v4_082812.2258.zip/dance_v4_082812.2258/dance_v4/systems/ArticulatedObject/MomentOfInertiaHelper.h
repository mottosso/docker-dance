/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "defs.h"
#include "Model.h"
#include <vector>
#include "vectorObj.h"
#include "Cube.h"
#include "Sphere.h"
#include "Capsule.h"

class POLYHEDRON;

class FACE
{
    public:
        FACE();
		int numVerts;
		double norm[3];
		double w;
		std::vector<int> verts;
		POLYHEDRON *poly;
};

class POLYHEDRON
{
    public:
        POLYHEDRON();
		int numVerts, numFaces;
		std::vector<VectorObj> verts;
		std::vector<FACE*> faces;
};

class MomentOfInertiaHelper
{
	public:
		MomentOfInertiaHelper();

		double mass;
		double com[3];            /* center of mass */
		double inertia[3][3];         /* inertia tensor */

		int A;   /* alpha */
		int B;   /* beta */
		int C;   /* gamma */

		/* projection integrals */
		double P1, Pa, Pb, Paa, Pab, Pbb, Paaa, Paab, Pabb, Pbbb;

		/* face integrals */
		double Fa, Fb, Fc, Faa, Fbb, Fcc, Faaa, Fbbb, Fccc, Faab, Fbbc, Fcca;

		/* volume integrals */
		double T0, T1[3], T2[3], TP[3];
    
		/* compute various integrations over projection of face */
		void compProjectionIntegrals(FACE *f);
		void compFaceIntegrals(FACE *f);
		void compVolumeIntegrals(POLYHEDRON *p);
		void createPolyhedronFromShape(Model* model, POLYHEDRON *p, double mat[4][4]);
		bool computeInertia(DGeometry* geometry, double density, double mat[4][4]);
};

