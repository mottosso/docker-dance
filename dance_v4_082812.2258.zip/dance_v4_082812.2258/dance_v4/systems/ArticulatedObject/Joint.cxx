/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "Joint.h"
#include <assert.h>

#include "defs.h"
#include "GLutilities.h"
#include "DObject.h"
#include "Link.h"
#include "dance.h"
#include "danceInterp.h"
#include "ViewManager.h"
#include "DView.h"
#include "ArticulatedObject.h"
#include "Link.h"
#include "matrix3x3.h"

const float DEG2RAD = (float) ( 3.14159 / 180.0);
 
void drawEllipse(float xradius, float yradius)
{
   glBegin(GL_LINE_LOOP);
 
   for (int i=0; i < 360; i++)
   {
      //convert degrees into radians
      float degInRad = i*DEG2RAD;
      glVertex2f(cos(degInRad)*xradius,sin(degInRad)*yradius);
   }
 
   glEnd();
}

// Default constructor and initializer for class Joint
Joint::Joint()
{
    m_jointNumber = -1 ;
    m_jointType = J_BALL ;

    m_numAxis = 0;
    m_AuxFrame.set(0.0,0.0,0.0,1.0);

    inboardLink	= NULL ;
    outboardLink = NULL	;
    m_Frame.set(0.0,0.0,0.0,1.0) ;
    setVector(m_InbToJoint,0.0,0.0,0.0) ;
    setVector(m_BodyToJoint,0.0,0.0,0.0) ;

	m_ShowBoundingBox = false;

    for( int i = 0 ; i < 7 ; i++ )
    {
		m_OldState[i] = 0.0;
		m_State[i] = 0.0 ;
		m_dState[i] = 0.0;
		m_InitDState[i] = 0.0;

		this->setStiffness(i, 50.0);
		this->setDamping(i, 5.0);
		this->setMaxStiffness(i, 50.0);
		this->setMaxDamping(i, 5.0);
    }

	for( int a = 0 ; a < 3 ; a++)
	{
		for( int i = 0 ; i < 3 ; i++)
		{
			if (i == a) 
				m_axis[a][i] = 1.0;
			else
				m_axis[a][i] = 0.0 ;
		}
	}

	m_artObj = NULL;
	for (int i = 0; i < 6; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			m_Limits[i][j] = 0.0;
		}
	}

	this->setHasVelocity(false);
}

// Removes Joint and connections to links.
// Does not remove link, link must delete itself explicitly.
Joint::~Joint()
{

	// Unlink inboard link.
	if (inboardLink)
		inboardLink->RemoveChildJoint(this);

	// Unlink outboard link.
	if (outboardLink)
		outboardLink->setParentJoint(NULL);

	

}

// create joint	number num of type t, between parent link p
// and link l
void Joint::create(int num, int t, Link *p, Link *l)
{

    //    sprintf(getName(),"joint%d",num);
    strcpy(m_name, l->getName()) ;
    m_jointNumber	= num ;
    m_jointType =	t ;
    inboardLink	= p ;
    outboardLink = l ;

    switch(t)
    {
	case J_PIN:
	    m_numAxis = 1 ;
	    setVector(m_axis[0],0.0,0.0,1.0) ;
	    setState(0, 0.0) ;
	    m_Limits[0][0] = -180.0; m_Limits[0][1] = 180.0;
	    break ;
	case J_PLANAR:
	    m_numAxis = 3 ;
	    setVector(m_axis[0],0.0,1.0,0.0) ;
	    setVector(m_axis[1],0.0,0.0,1.0) ;
	    setVector(m_axis[2],1.0,0.0,0.0) ;
	    setState(0, 0.0) ;
	    setState(1, 0.0) ;
	    setState(2, 0.0) ;
	    m_Limits[2][0] = -180.0; m_Limits[2][1] = 180.0;
	    break ;

    case J_UNIVERSAL:
		m_numAxis = 2 ;
		setVector(m_axis[0],1.0,0.0,0.0) ;
		setVector(m_axis[1],0.0,1.0,0.0) ;
		setState(0, 0.0) ;
		setState(1, 0.0) ;
		m_Limits[0][0] = -180.0; m_Limits[0][1] = 180.0;
		m_Limits[1][0] = -180.0; m_Limits[1][1] = 180.0;
	break ;
    case J_GIMBAL:
    case J_FREE:
	{
		m_numAxis = 3 ;
		setVector(m_axis[0],1.0,0.0,0.0) ;
		setVector(m_axis[1],0.0,1.0,0.0) ;
		setVector(m_axis[2],0.0,0.0,1.0) ;
		if (t == J_FREE) {
			m_Limits[0][0] = -180.0; m_Limits[0][1] = 180.0;
			m_Limits[1][0] = -180.0; m_Limits[1][1] = 180.0;
			m_Limits[2][0] = -180.0; m_Limits[2][1] = 180.0;
		}
		else {
			m_Limits[0][0] = -180.0; m_Limits[0][1] = 180.0;
			m_Limits[1][0] = -180.0; m_Limits[1][1] = 180.0;
			m_Limits[2][0] = -180.0; m_Limits[2][1] = 180.0;
		}

		double mat[4][4], cmat[4][4], pmat[4][4];
		if (inboardLink)
			inboardLink->getOrientation(pmat);
		else {
			for	(int i=0; i < 4; i++)
			for (int j=0; j	< 4; j++) {
				if (i==j) pmat[i][j] = 1.0;
				else pmat[i][j]	= 0.0;
			}
		}
		outboardLink->getOrientation(cmat);
		relativeToFrame(mat,cmat,pmat);
		m_Frame.fromMatrix(mat);
		CalcState();
		m_Limits[0][0] = -180; m_Limits[0][1] = 180.0;
		m_Limits[1][0] = -180; m_Limits[1][1] = 180.0;
		m_Limits[2][0] = -180; m_Limits[2][1] = 180.0;
	}
	break ;
    case J_BALL:
	{
		m_numAxis	= 0;
		// Determine frame of link l relative to link p
		// Convert to quaternion
		double mat[4][4], cmat[4][4], pmat[4][4];
		if (inboardLink)
			inboardLink->getOrientation(pmat);
		else {
			for	(int i=0; i < 4; i++)
			for (int j=0; j	< 4; j++) {
				if (i==j) pmat[i][j] = 1.0;
				else pmat[i][j]	= 0.0;
			}
		}
		l->getOrientation(cmat);
		relativeToFrame(mat,cmat,pmat);
		m_Frame.fromMatrix(mat);
		m_AuxFrame.set(0.0,0.0,0.0,1.0);
		CalcState();
		m_Limits[0][0] = -180; m_Limits[0][1] = 180.0;
		m_Limits[1][0] = -180; m_Limits[1][1] = 180.0;
		m_Limits[2][0] = -180; m_Limits[2][1] = 180.0;
	}
	break ;
    case J_SLIDER:
		m_numAxis	= 1;
		setState(0,0.0);
		setVector(m_axis[0],1.0,0.0,0.0) ;
		m_Limits[0][0] = -10.0; m_Limits[0][1] = 10.0;
	break;
    case J_WELD:
	 m_numAxis = 0 ;
	 break ;
    default:
		danceInterp::OutputMessage("Joint type %d\n", t) ;
		danceInterp::OutputMessage("ERROR:Joint::create: "
					"Not implemented yet.") ;
		break;
    }
}

// applyTransformation:
// Given the quaternion	or the angles that define
// the relative	orientation of the outboard link
// with	respect	to the inboard link
// calculate the matrix	that transforms	from child to parent
// assuming that the two coordinate systems are	currently
// aligned.
// The transformation matrix is:
// M = [ R 0 ]
//     [ T 1]
// where R is the rotation matrix defined by the m_Frame or the angles
// and T= Tinb -R*Toutb
void Joint::applyTransformation()
{
    double m[4][4];

    // apply the orientation corresponding to the joint.
    switch(m_jointType)
	{
	case J_PLANAR:
	case J_PIN:
	case J_UNIVERSAL:
	case J_SLIDER:
	case J_FREE:
	case J_BALL:
	case J_GIMBAL:
	    m_Frame.toMatrix(m)	;
	    break;
	case J_WELD:
		setIdentMat(&m[0][0], 4);
	    break ;
    }

    // now construct the translation part of the transformation	matrix
    Vector trans ;
    VecCopy(trans,m_BodyToJoint) ;
    rotPoint_mat4(trans,m) ;

    // Add in effects of slider	joints.
    if (m_jointType == J_FREE || m_jointType == J_SLIDER) {
	      double wtrans[3]={0.0,0.0,0.0};
		  for (int i=0; i <	m_numAxis; i++) {
			wtrans[0] += m_axis[i][0]*m_State[i];
			wtrans[1] += m_axis[i][1]*m_State[i];
			wtrans[2] += m_axis[i][2]*m_State[i];
		  }
		  VecSubtract(trans,trans,wtrans);
    }
	else if( m_jointType == J_PLANAR)
	{
		// first two axis are translational
		double wtrans[3] ;
		wtrans[0] = m_axis[0][0]*m_State[0] + m_axis[1][0]*m_State[1] ;
		wtrans[1] = m_axis[0][1]*m_State[0] + m_axis[1][1]*m_State[1] ;
		wtrans[2] = m_axis[0][2]*m_State[0] + m_axis[1][2]*m_State[1] ;
		VecSubtract(trans,trans,wtrans);
	}

    VecSubtract(m[3],m_InbToJoint,trans) ;
   
	if (this->outboardLink != NULL)
		getOutboardLink()->setTransMat(m) ;
    // caution:	it is set in local coordinates
}


// getStateSize:
//	returns	the number of items in the state vector
//
//	returns: size of state vector
int Joint::getStateSize()
{
	int num	= 0;
	switch(m_jointType)
	{
	    case J_PIN:
		num = 1;
		break;
	    case J_SLIDER:
		num = 3;
		break;
	    case J_UNIVERSAL:
		num = 2	;
		break ;
	    case J_BALL:
		num = 4;
		break;
	    case J_GIMBAL:
		num = 3;
		break;
	    case J_FREE:
		num = 7;
		break;
	    case J_WELD:
		num = 0 ;
		break ;
	    case J_PLANAR:
		num = 3 ;
		break ;
	    default:
		num = 0;
	}
	return(num);
}

// getNumDof:
//	returns	the number of dofs
//
int Joint::getNumDof()
{
	int num	= 0;
	switch(m_jointType)
	{
	    case J_PIN:
	    case J_SLIDER:
		num = 1;
		break;
	    case J_UNIVERSAL:
		num = 2	;
		break ;
	    case J_BALL:
	    case J_GIMBAL:
		num = 3;
		break;
	    case J_FREE:
		num = 6;
		break;
	    case J_WELD:
		num = 0 ;
		break ;
	    case J_PLANAR:
		num = 3 ;
		break ;
	    default:
		num = 0;
	}
	return(num);
}

// setLastState:
//	copies the contents of m_State to m_OldState
void Joint::setLastState()
{
	memcpy(m_OldState,m_State,sizeof(double)*getStateSize());
	memcpy(m_OldInbToJoint,m_InbToJoint,3*sizeof(double));
	memcpy(m_OldBodyToJoint,m_BodyToJoint,3*sizeof(double));
}

// getState:
//	returns	the state of a joint with the given index
//
//	index  : index of state	to get
//	returns: state value
double Joint::getState(int index)
{
	double value = 0.0;
	switch(m_jointType) {
	    case J_GIMBAL:
	    case J_FREE:
		 if (index < 3)
			value =	m_State[index];
		 else
			value =	m_Frame.get(index-3);
		 break;
	    case J_BALL:
		 value = m_Frame.get(index);
		 break;
	    default:
		 value = m_State[index];
	}
	return(value);
}

// getStateVector:
// sets vec to state vector
void Joint::getStateVector(double* vec)
{
	for (int i = 0; i < 7; i++)
	{
		vec[i] = m_State[i];
	}
}

/// allways takes three numbers
void Joint::getInitDState(double ds[3])
{
	ds[0] = this->m_InitDState[0] ;
	ds[1] = this->m_InitDState[1] ;
	ds[2] = this->m_InitDState[2] ;
}

/// allways takes three numbers
void Joint::setInitDState(double ds[3])
{
	this->m_InitDState[0] = ds[0] ;
	this->m_InitDState[1] = ds[1] ;
	this->m_InitDState[2] = ds[2] ;
}


// setState:
//	sets the state of a joint with the given index
//
//	index: index within the	state vector
//	state: new value to be put in this index position of the state vector
//
void Joint::setState(int index,	double state, int batch)
{
    switch (m_jointType) {
	case J_BALL:
		if (batch == TRUE)
		{
			m_Frame.set(index, state, true);
		}
		else
		{
			m_Frame.set(index, state);
		}
	    m_State[index] = state;
	    break;
	case J_FREE:
	    
	    if (index	>= 3) {
			if (batch == TRUE)
			{
				m_Frame.set(index - 3, state, true);
			}
			else
			{
				m_Frame.set(index-3,state);
			}
	    }
	    m_State[index] = state;
	    break;
	case J_PIN:
	    m_State[index] = state ;
	    m_Frame.set(state, m_axis[0]) ;
	    break;
	case J_PLANAR:
	    m_State[index] = state ;
	    if( index == 2 )	// rotational parameter
		m_Frame.set(state, m_axis[2]) ; // <------------- check it out
		break ;
	case J_GIMBAL:
	case J_UNIVERSAL: {
	    m_State[index] = state ;
	    
	    Quaternion q ;
	    if( batch == FALSE )	// we want immediate update
	    {
			m_Frame.set(m_State[0], m_axis[0]) ;
			// multiply the three	rotations together
			// using quaternion multiplication
			for( int i = 1 ; i < getNumAxis() ; i++ )
			{
				q.set(m_State[i], m_axis[i]) ;
				m_Frame.multiply(&q)	;
			}
	    }
	    else // Optimized so we don't need to produce unnecessary multiplications.
	    {
			q.set(state, m_axis[index]) ;
			if( index == 0 ) m_Frame.copy(&q) ;
				else m_Frame.multiply(&q) ;
	    }
	    
	}
	break;
	default:
	    m_State[index] = state ;
    }
}

void Joint::setStateQuaternion( double* argNewVal )
{
	int start = 0;
	if( J_FREE == m_jointType )
	{
		start = 3;
	}
	Quaternion q( argNewVal[start + 0], argNewVal[start + 1], argNewVal[start + 2], argNewVal[start + 3] );
	q.normalize();
	m_Frame.copy(&q);
	for( int i=0; i<4; ++i )
	{
		m_State[start + i] = q[i];
	}
}

void Joint::setState( double* argNewVal )
{
	Quaternion q ;
	switch (m_jointType) {
	case J_BALL:
		setStateQuaternion( argNewVal );
		break;
	case J_FREE:
		setStateQuaternion( argNewVal );
		for( int i=0; i<3; ++i )
		{
			m_State[i] = argNewVal[i];
		}
		break;
	case J_PIN:
		m_State[0] = argNewVal[0] ;
		m_Frame.set(argNewVal[0], m_axis[0]) ;
		break;
	case J_PLANAR:
		// the plane
		for( int i=0; i<2; ++i )
		{
			m_State[i] = argNewVal[i];
		}
		// Rotation around the normal to the plane
		m_Frame.set( argNewVal[2], m_axis[2] ) ; // <------------- check it out
		break ;
	case J_GIMBAL:
	case J_UNIVERSAL:
		for( int i=0; i<getStateSize(); ++i )
		{
			m_State[i] = argNewVal[i];
		}

		m_Frame.set(m_State[0], m_axis[0]) ;
		// multiply the three	rotations together
		// using quaternion multiplication
		for( int i = 1 ; i < getNumAxis() ; i++ )
		{
			q.set(m_State[i], m_axis[i]) ;
			m_Frame.multiply(&q)	;
		}
		break;
	case J_WELD:
		// ignore state for weld joints
		break;
	default:
		assert( false );
	}
}


void Joint::setParam(int ax, double stif, double damp)
{
    if(	(ax >= 0) && (ax < getStateSize()))
    {
		this->setStiffness(ax, stif);
		this->setDamping(ax, damp);
    }
    else
    {
		danceInterp::OutputMessage("ERROR:Joint::setParam:Index out of bounds.")	;
    }
}

// changeType:
//	Changes	the type of the	joint and resets its state, giving
//	default	parameters.
//
//	type: new joint	type
//
void Joint::changeType(int newtype)
{
	if (newtype == m_jointType) return; // No	need to	adjust type.
	m_jointType = newtype;

	switch(m_jointType)	{
	   case	J_SLIDER:
		m_numAxis	= 1;
		setVector(m_axis[0],1.0,0.0,0.0) ;
		setState(0,0.0);
		{
		double wangle =	0.0;
		double waxis[3]	= {0.0,0.0,1.0};
		m_Frame.set(wangle,waxis);
		}
		break;
	   case	J_FREE:
		m_numAxis	= 3;
		setVector(m_axis[0],1.0,0.0,0.0) ;
		setVector(m_axis[1],0.0,1.0,0.0) ;
		setVector(m_axis[2],0.0,0.0,1.0) ;
		setState(0,0.0);
		setState(1,0.0);
		setState(2,0.0);
		{
		double wangle =	0.0;
		double waxis[3]	= {0.0,0.0,1.0};
		m_Frame.set(wangle,waxis);
		}
		break;
	   case	J_BALL:
		{
		m_numAxis	= 0;
		setVector(m_axis[0],1.0,0.0,0.0) ;
		setVector(m_axis[1],0.0,1.0,0.0) ;
		setVector(m_axis[2],0.0,0.0,1.0) ;
		setState(0,0.0);
		setState(1,0.0);
		setState(2,0.0);
		setState(3,1.0);
		double wangle =	0.0;
		double waxis[3]	= {0.0,0.0,1.0};
		m_Frame.set(wangle,waxis);
		}
		break;
	   case	J_GIMBAL:
		{
		m_numAxis	= 3;
		setVector(m_axis[0],1.0,0.0,0.0) ;
		setVector(m_axis[1],0.0,1.0,0.0) ;
		setVector(m_axis[2],0.0,0.0,1.0) ;
		setState(0,0.0);
		setState(1,0.0);
		setState(2,0.0);
		double wangle =	0.0;
		double waxis[3]	= {0.0,0.0,1.0};
		m_Frame.set(wangle,waxis);
		}
		break;
	   case	J_UNIVERSAL:
		{
		m_numAxis	= 2;
		setVector(m_axis[0],1.0,0.0,0.0) ;
		setVector(m_axis[1],0.0,1.0,0.0) ;
		setState(0,0.0);
		setState(1,0.0);
		double wangle =	0.0;
		double waxis[3]	= {0.0,1.0,0.0};
		m_Frame.set(wangle,waxis);
		}
		break;
	    case J_PLANAR:
		m_numAxis = 3 ;
		setVector(m_axis[0],0.0,1.0,0.0) ;
		setVector(m_axis[1],0.0,0.0,1.0) ;
		setVector(m_axis[1],1.0,0.0,0.0) ;
		setState(0,0.0);
		setState(1,0.0);
		setState(2,0.0) ;
		m_Frame.set(m_State[2],m_axis[2]);
	   case	J_PIN:
		{
			m_numAxis	= 1;
			setState(0,0.0);
			setVector(m_axis[0],0.0,0.0,1.0);
			m_Frame.set(m_State[0],m_axis[0]);
		}
		break;
	   default:
		danceInterp::OutputMessage("Change type to %d: not "
					"implemented yet.",newtype);
	}
}

//*******************************************
// PROC: Joint::getAxis()
// DOES: returns the axis associated with
//	 a Joint and their number
//*******************************************
int  Joint::getAxis(double a[3][3])
{
    int	i,j ;

    for( i = 0 ; i < 3 ; i++ )
	for( j = 0 ; j < 3 ; j++ )
	    a[i][j] = m_axis[i][j] ;
    return m_numAxis ;
}

// gets	the initial orientation	of the link given the information
// in angle and	 m_Frame fields
int Joint::getOrientation(double m[4][4])
{
    m_Frame.toMatrix(m) ;
    return OK ;
}





/**
 * Calculates the position of the joint in world coordinates
 *
 * Calculates the position of the joint in world coordinates
 * using the getWTransMat. So it works properly inpendendly of 
 * hierarchical or absolute structure.
 * @param double p[3] the position of the joint
 * @return void 
 */
void Joint::getPosition(double p[3])
{

	Vector outb ;
    getBodyToJoint(outb) ;
    double tm[4][4] ;
    outboardLink->getWTransMat(tm) ;
    transformPoint_mat(outb,tm);
    VecCopy(p,outb) ;
}

// displayArcBall:
//	Displays joint's arcball
//
void Joint::displayRefFrame(double length, double frame[4][4])
{
	glPushMatrix();
	glMultMatrixd((double *)frame);

	// display quaternion axis.
	/*
	glPushAttrib(GL_CURRENT_BIT);
	const GLfloat axisColor[4] = {0.7f,0.0f,0.7f,1.0f};
	glColor4fv(axisColor); // violet color
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE,axisColor) ;

	double rotaxis[3], angle;	
	m_Frame.getAxisAngle(rotaxis,&angle);
	
	// Labels
	char msgString[256];sprintf(msgString,"%f",angle);
	glRasterPos3d(0.0,0.0,0.0);
	GLlabel(msgString);
	
	displayAxis((double *)rotaxis,length);

	// Labels
	glRasterPos3d(rotaxis[0],rotaxis[1],rotaxis[2]);
	sprintf(msgString,"(%f,%f,%f)\n",rotaxis[0],rotaxis[1],rotaxis[2]);
	GLlabel(msgString);
	glPopAttrib();
    */

	glPushAttrib(GL_LIGHTING_BIT);
	glDisable(GL_LIGHTING);

	glLineWidth(2.0);

	// X-axis
	glPushName(3);
	glColor3f(0.7f,0.0f,0.0f);
	glPushMatrix();
	glRotatef(90.0f,0.0f,1.0f,0.0f);
	GLdrawCircle(length,12); 
	glPopMatrix();
	glPopName();

	// Y-axis
	glPushName(4);
	glColor3f(0.0,0.9f,0.0f);
	glPushMatrix();
	glRotatef(-90.0f,1.0f,0.0f,0.0f);
	GLdrawCircle(length,12); 
	glPopMatrix();
	glPopName();

	// Z-axis
	glPushName(5);
	glColor3f(0.0f,0.0f,0.9f);
	GLdrawCircle(length,12); 
	glPopName();

	glLineWidth(1.0);

	glPopAttrib();

	glPopMatrix();


}

// displayAxis:
//	Displays joint axis.
//
//	axis:	Vector direction (length 1 is expected)
//	length:	Scaling	factor
//	type:	1 for translational, 0 for rotational
//
void Joint::displayAxis(double axis[3],	double length, int arrowtype)
{
    double point[3]; point[0] =	0.0; point[1] =	0.0; point[2] =	0.0;
    GLdrawVector(point,	axis, length);


    if (arrowtype) {
       for (int i =	0; i < 3; i++)
		axis[i]	*= -1.0;
       GLdrawVector(point,axis,length);
    }
}


// displayManipulators:
//	Displays the joint manipulators	based on type.
//
void Joint::displayManipulators()
{
    // Get frames of reference for each	link.
    double inb_tm[4][4], outb_tm[4][4];
    double inb[3];
    getInbToJoint(inb);
    if (inboardLink) {
		inboardLink->getWTransMat(inb_tm);
		transformPoint_mat(inb,inb_tm);
    }
    else // This is a root inboard
    {
	for (int i = 0;	i < 4; i ++)
	   for (int j =	0; j < 4; j++)
	     if	(i == j)
			inb_tm[i][j] = 1.0;
	     else
			inb_tm[i][j] = 0.0;
		 getInbToJoint(inb);
    }

    // Translate to inboard and outboard position
    memcpy(inb_tm[3],inb,3*sizeof(double));

    double outb[3]; getBodyToJoint(outb);
    outboardLink->getWTransMat(outb_tm);
    transformPoint_mat(outb,outb_tm);
    memcpy(outb_tm[3],outb,3*sizeof(double));

	// Calculate suitable arrow	lengths	for inboard and	outboard vectors.
	// Scale these arrows as a percentage of the View Volume dimensions.
	double arrowLength = 1.0;
	DView *wview = dance::AllViews->getViewFocus();
	if (wview) {
		double pos[3]; getPosition(pos);		
		double win[3]; wview->getWindowCoords(pos,win);
		double worldwidth = wview->getFrustumWidth(win[2]);
		arrowLength = 0.05*worldwidth;
	}

    	double axis[3][3];
	double frameMat[4][4];

	const GLfloat sliderColor[] = {0.0f,0.0f,0.9f,1.0f};
	const GLfloat revoluteColor[] = {0.2f,0.2f,0.9f,1.0f};
    glColor4fv(revoluteColor);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE,revoluteColor) ;
	
    // Draw any	axes that must be in the inboard frame.
    // Need to add glPushName
    glPushMatrix();
	switch(m_jointType) {
	   case	J_GIMBAL:
		glMultMatrixd((GLdouble *)inb_tm);
	
		glPushName(0);
		displayAxis(axis[0], arrowLength);
		glPopName();

		glRotated(m_State[0]*180.0/M_PI, axis[0][0],axis[0][1],axis[0][2]);
		glPushName(1);
		displayAxis(axis[1], arrowLength);
		glPopName();

		glRotated(m_State[1]*180.0/M_PI, axis[1][0],axis[1][1],axis[1][2]);
		glPushName(2);
		displayAxis(axis[2], arrowLength);
		glPopName();
		
		break;
	  case J_UNIVERSAL:
		glMultMatrixd((GLdouble	*)inb_tm);
		glPushName(0);
		displayAxis(axis[0], arrowLength);
		glPopName();

		glRotated(m_State[0]*180.0/M_PI, axis[0][0],axis[0][1],axis[0][2]);
		glPushName(1);
		displayAxis(axis[1], arrowLength);
		glPopName();

		break;
	   case	J_BALL:
		// displayRefFrame(arrowLength,outb_tm); // Show quaternion axes
		
		glMultMatrixd((GLdouble *)outb_tm);
		m_AuxFrame.toMatrix(frameMat);
	
		glPushName(0);
		glColor4f(1.0,0.0,0.0,1.0);
		displayAxis(frameMat[0],arrowLength);
		glPopName();
		glPushName(1);
		glColor4f(0.0,1.0,0.0,1.0);
		displayAxis(frameMat[1],arrowLength);
		glPopName();
		glPushName(2);
		glColor4f(0.0,0.0,1.0,1.0);
		displayAxis(frameMat[2],arrowLength);
		glPopName();

		break;
	   case	J_PIN:
		glMultMatrixd((GLdouble	*)inb_tm);
		glPushName(0);
		displayAxis(axis[0], arrowLength);
		glPopName();
		break;
	   case J_PLANAR:
		glMultMatrixd((GLdouble	*)inb_tm);
		glColor4fv(sliderColor);
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE,sliderColor) ;
		glPushName(0);
		displayAxis(axis[0], arrowLength,1);
		glPopName();
		glPushName(1);
		displayAxis(axis[1], arrowLength,1);
		glPopName();
		glColor4fv(revoluteColor);
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE,revoluteColor) ;
		glPushName(2);
		displayAxis(axis[2], arrowLength,1);
		glPopName();
		break ;
	   case	J_FREE:
		displayRefFrame(arrowLength,outb_tm);
		
		// Translate to outboard frame but don't rotate to match orientation
		glTranslated(outb_tm[3][0],outb_tm[3][1],outb_tm[3][2]);
		glColor4fv(sliderColor);
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE,sliderColor) ;
		glPushName(0);
		displayAxis(axis[0], arrowLength,1);
		glPopName();
		glPushName(1);
		displayAxis(axis[1], arrowLength,1);
		glPopName();
		glPushName(2);
		displayAxis(axis[2], arrowLength,1);
		glPopName();
		break;
	   case	J_SLIDER:   
		glMultMatrixd((GLdouble	*)inb_tm);
		glColor3fv(sliderColor);
		glPushName(0);
		displayAxis(axis[0], arrowLength, 1);
		glPopName();
		break;
	}
    glPopMatrix();

}

//draw tetrahedron and bounding box if link/joint is active
void Joint::TetraOut(GLdouble tetraLenRatio, Vector point1, Vector point2, bool active_joint)
{
	// Require our ArticulatedObject to be set to draw correctly
	if( !m_artObj )
	{
		return;
	}
		glPushAttrib(GL_ENABLE_BIT | GL_DEPTH_BUFFER_BIT);
        glLineWidth((GLfloat) 0.3);
        glDisable(GL_LIGHTING);

        double vector[3];
        for (int i = 0; i < 3; i++)
                vector[i] = point2[i] - point1[i];

        double length = VecLength(vector) ;
        double spacing = length/4;

        // Don't draw anything if too short.
        if (length < 0.000001)
        {
                glPopAttrib();
                return;
        }

        // Calculate angle to rotate tetrahedrons
		double angle = acos(vector[1]/length)*180.0/M_PI;

		glPushMatrix() ;

                glTranslated(point1[0],point1[1],point1[2]);
                glRotated(-angle,-1.0*vector[2],0.0,vector[0]);

                //draw 2 square base tetrahedrons
/*                for (int i = 0; i < 2; i++)
                {
                        glBegin(GL_TRIANGLE_STRIP);
                        glColor3f(0.0f, 0.0f, 0.0f);

                                for (int k = 0; k < 4; k++)
                                {
                                        glVertex3dv(extremePt);
                                        glVertex3dv(quadpts[k]);
                                        glVertex3dv(quadpts[(k+1)%4]);
                                }
                        glEnd();
                        extremePt[1] = length;
                }
*/
                //DRAW TRIANGLE BASE TETRAHEDRON (constant width)
              GLdouble points[4][3] = {{0, 0, 0},{0.05, spacing, 0}, {-0.025, spacing, 0.0433},{-0.025, spacing, -0.0433}};
			  for (int j = 1; j < 4; j++)
			  {
                  VecScale(points[j], 1.5*length);
				  points[j][1] = spacing;
			  }
                // draw tetrahedron with axis aligned with the vector
                for (int i = 0; i < 2; i++)
                {
                        glBegin(GL_LINE_LOOP);
//                        glColor3f(0.4f, 0.4f, 0.4f);

                        for (int j = 0; j < 4; j++) //for every triangle
                        {
                                for (int k = 0; k < 4; k++) //for all points except 1 (of 4)
                                {

								   if (k != j)
									   glVertex3dv( points[k]);                //draw vertex
                                }
                        }
                        glEnd();
                        points[0][1] = length;
                }

				if (m_artObj->getActiveLink()!= NULL && active_joint && m_ShowBoundingBox)
				{
					Vector pos1;
					Vector pos2;
					Vector diff;
					Vector temp;
					double length;
					double angle;

					m_artObj->getActiveLink()->getParentJoint()->getPosition(pos1);
					m_artObj->getActiveLink()->getEndEffector(pos2);
					m_artObj->getActiveJoint()->getBodyToJoint(temp);

					VecNumMul(temp, temp, -1);
					VecAdd(pos2, pos2, temp);
					VecAdd(pos2, pos2, pos1);

					VecSubtract(diff, pos2, pos1);
					VecSubtract(temp, point2, point1);
//					length = VecLength(temp);
					length = VecLength(diff);
					angle = acos(diff[1]/length)*180/M_PI;

					glPushMatrix();
					glDisable(GL_LIGHTING);
					glColor3d(0.0, 0.9, 0.0);

			/*		glPushMatrix();
					glLoadIdentity();
					glBegin(GL_POINTS);		//test endpoints
					glVertex3dv(pos1);
					glVertex3dv(pos2);
					glEnd();
					glPopMatrix();*/

//					glRotated(-angle, -1*diff[2], 0.0, diff[0]);
					glTranslated(0.0, length/2, 0.0);
					glScaled(length/4.0, length, length/4.0);
					glutWireCube(1.0);
					glEnable(GL_LIGHTING);
					glPopMatrix();
				}

        glPopMatrix();
        glPopAttrib();
}

void Joint::setShowBoundingBox(bool val)
{
	m_ShowBoundingBox = val;
}

// display:
//	Displays a Joint as a sphere (commented out)
//	Displays Links between Joints as tetrahedrons
//
// mode: JDISPLAY_CENTRES, Displays joint centres only.
//		 JDISPLAY_MANIPS , Joint manipulators, inboard and outboard vectors, joint centres
//
void Joint::display2(int mode, bool active)
{
	Vector zero = {0, 0, 0};
	

	Vector childPos[10];
//	for (int i = 0; i < 10; i++)
//		zeroVector(childPos[i]);

	Vector jointPos = {0,0,0};
	Vector efPos = {0,0,0};
	Vector cm = {0,0,0};

	if ((mode & JDISPLAY_CENTRES) || (outboardLink != NULL && outboardLink->getGeometry() == NULL) || (getArticulatedObject() && getArticulatedObject()->isShowingJoints() == true))
	{
		glPushAttrib(GL_ENABLE_BIT | GL_CURRENT_BIT);
			glDisable(GL_LIGHTING) ;
			glLineWidth(3.0);

			if (true) //inboardLink && mode != 0) // Could be a NULL link (if root)
			{
				Vector ef;
//				this->getOutboardLink()->getEndEffector(ef);
//				VecScale(ef, 2);
				VecNumMul(ef, m_BodyToJoint, -1);

				glPushMatrix();
//					glMultMatrixd((GLdouble *)inboardLink->m_transMat);

					//get global position of current joint (curPos)
//					getPosition(curPos);
					VecCopy(jointPos, m_BodyToJoint);

					double matrix[4][4];
					outboardLink->getTransMat(matrix);
					transformPoint_mat(jointPos, matrix);
					outboardLink->getEndEffector(efPos);
					transformPoint_mat(efPos, matrix);
//					VecSubtract(ef, ef, m_BodyToJoint);
//					VecAdd(ef, ef, curPos);
//					VecCopy(efPos, ef);

				glPopMatrix();
			}
/*			else //if root link
			{
				Vector ef;
				Vector btj;
				this->getOutboardLink()->getEndEffector(ef);
				this->getBodyToJoint(btj);
				VecScale(btj, -1);

//				VecNumMul(ef, m_BodyToJoint, -1);
//				VecSubtract(ef, ef, m_BodyToJoint);

				//get position of next joint (childPos)
				if (jointPos != NULL)
					getPosition(jointPos);
				VecAdd(ef, ef, btj);
				VecAdd(ef, ef, jointPos);
				VecCopy(efPos, ef);

				double matrix[4][4];
				outboardLink->getTransMat(matrix);
				transformPoint_mat(jointPos, matrix);
				transformPoint_mat(efPos, matrix);
			}
*/
			glPushAttrib(GL_ENABLE_BIT | GL_CURRENT_BIT);
			glColor3dv(this->getArticulatedObject()->getLinkColor());
			TetraOut(0.05, jointPos, efPos, active);
			glPopAttrib();

			//draw dashed line from CM to next joint pos
			//CM position of current link
			this->outboardLink->getWorldCoord(cm, zero);

			//get child link positions
			int numChildren = outboardLink->getNumChildLinks(); 
			if (numChildren > 0)
			{
				Link** children = outboardLink->getChildLinks();

				for (int i = 0; i < numChildren; i++)
				{
					Joint* childJoint = children[i]->getParentJoint();
					childJoint->getPosition(childPos[i]);
				}
			}

			glPushAttrib(GL_ENABLE_BIT | GL_CURRENT_BIT);
			glColor3d(0.0, 0.5, 0.9);
			glEnable(GL_LINE_STIPPLE);
			glLineStipple(1, 0x000F);
			glBegin(GL_LINES);
			for (int j = 0; j < numChildren; j++)
			{
				//draw dashed line from CM to childPos[j]
				glVertex3dv(cm);
				glVertex3dv(childPos[j]);
			}
			glEnd();
			glDisable(GL_LINE_STIPPLE);
			glPopAttrib();

		glPopAttrib();

    }

    if (mode & JDISPLAY_MANIPS)
		displayManipulators();
}


// display:
//	Displays a Joint as a sphere
//
// mode: JDISPLAY_CENTRES, Displays joint centres only.
//		 JDISPLAY_MANIPS , Joint manipulators, inboard and outboard vectors, joint centres
//
void Joint::display(int	mode)
{
	return;

	// glLoadName(m_jointNumber); //	For picking operations
	if ((mode & JDISPLAY_CENTRES) || (outboardLink != NULL && outboardLink->getGeometry() == NULL) || (this->getArticulatedObject()->isShowingJoints() == true))
	{
		glPushAttrib(GL_ENABLE_BIT | GL_CURRENT_BIT);
		glDisable(GL_LIGHTING) ;
		glLineWidth(3.0);
		// Draw inboard and outboard vectors.

		if (inboardLink && mode != 0) { // Could be a NULL link (if root)
			glPushMatrix();
			glMultMatrixd((GLdouble *)inboardLink->m_transMat);

			glColor4f(1.0,0.0,1.0,1.0);
			glBegin(GL_LINES);
			glVertex3d(0.0,0.0,0.0);
			glVertex3dv(m_InbToJoint);
			glEnd();
//			glutSolidSphere(.05, 10, 10);
			glPopMatrix();
		}

		glPushMatrix();
		glMultMatrixd((GLdouble	*)outboardLink->m_transMat);
		if (mode != 0) { 
			glColor4f(1.0,0.0,0.0,1.0);
			glBegin(GL_LINES);
				glVertex3d(0.0,0.0,0.0);
				glVertex3dv(m_BodyToJoint);
			glEnd();
		}
		glLineWidth(1.0);
		// Joint centre.
		glColor4f((float)0.3,(float)0.3,(float)1.0,(float)1.0);
		
//		double jointSize = getArticulatedObject()->getHeight() / 50.0;
//		glutWireSphere(jointSize, 8, 8);

//		glPointSize(7.0);
//		glBegin(GL_POINTS);
//			glVertex3dv(m_BodyToJoint);
//		glEnd();
//		glPointSize(1.0);S
		glPopMatrix();
		glPopAttrib();
    }

    if (mode & JDISPLAY_MANIPS)
		displayManipulators();

	//drawEllipse(2.5f, 2.0f);
}

// setPosition:
//	sets a single point which will coincide	with a common inboard
//	and outboard joint position for	each joint.
//
//	p:  Sets the position of the joint.
//
void Joint::setPosition(double p[3])
{
    assert(outboardLink);

    Vector inb,outb;
    Vector parentpos, childpos;
    if(	inboardLink != NULL)
    {
	inboardLink->getPosition(parentpos); //	world coordinates
	VecSubtract(inb,p, parentpos) ;	// world coordinates
	rotPoint_mat4(inb,inboardLink->m_invTransMat) ; // bring it to local coordinates
	setInbToJoint(inb);
    }
    else  // root link with respect to ground
	setInbToJoint(p) ;

    outboardLink->getPosition(childpos);

	// Make adjustments if translation involved due to slider or free joint.
	if (m_jointType == J_SLIDER || m_jointType == J_FREE)
	{
		// Convert translation into world.
		double wtrans[3] = {0.0,0.0,0.0};
		for (int i = 0; i < m_numAxis; i++) {
			wtrans[0] += m_axis[i][0]*m_State[0];
			wtrans[1] += m_axis[i][1]*m_State[1];
			wtrans[2] += m_axis[i][2]*m_State[2];
		}
		if (inboardLink) 
			transformPoint_mat(wtrans,inboardLink->m_transMat);
		VecAdd(p,p,wtrans);
	}


    VecSubtract(outb,p,childpos) ; // world coordinates

    rotPoint_mat4(outb,outboardLink->m_invTransMat) ; // local coordinates
    setBodyToJoint(outb);
}



// setRelativePosition:
//	set the	relative position of the joints.
//
void Joint::setRelativePosition(double p[3])
{
    // Get inboard and outboard	in world coordinates
    Vector inb,	outb ;
    getInbToJoint(inb);
    if(	inboardLink != NULL)
	transformPoint_mat(inb,inboardLink->m_transMat);

    getBodyToJoint(outb);
    transformPoint_mat(outb,outboardLink->m_transMat);

    // Adjust both inboard and outboard	vectors.
    for	(int i=0; i < 3; i++) {
	inb[i] += p[i];
	outb[i]	+= p[i];
    }

    // Now bring back to local frame.
    Vector parentpos, childpos;
    if(	inboardLink != NULL)
    {
	inboardLink->getPosition(parentpos); //	world coordinates
	VecSubtract(inb,inb, parentpos)	; // world coordinates
	rotPoint_mat4(inb,inboardLink->m_invTransMat) ; // bring it to local coordinates
	setInbToJoint(inb);
    }
    else
	setInbToJoint(inb);

    // update body to joint
    outboardLink->getPosition(childpos);
    VecSubtract(outb,outb,childpos) ; // world coordinates
    rotPoint_mat4(outb,outboardLink->m_invTransMat) ; // local coordinates
    setBodyToJoint(outb);
}


void addChildInertialValues(Joint* joint, Vector inertia)
{
	Link* link = joint->getOutboardLink();
	double* tensor = joint->getOutboardLink()->getInerTensor();
	inertia[0] += tensor[0];
	inertia[1] += tensor[4];
	inertia[2] += tensor[8];

	int numChildren = link->getNumChildLinks();
	Link** children = link->getChildLinks();
	for (int c = 0; c < numChildren; c++)
	{
		Joint* childJoint = children[c]->getParentJoint();
		addChildInertialValues(childJoint, inertia);
	}
}

int Joint::Command(int argc,	char **argv)
{
	char dofString[MAX_LINE];

	int count = 0;
	// For compatibility
    if(	strcmp(argv[count],	"set") == 0 )
		count = 1;

	if (strcmp(argv[count],"position") == 0)
	{
		double pos[3];
		if (argc-count-1 >= 3) { // Set position.
			pos[0] = atof(argv[count+1]);
			pos[1] = atof(argv[count+2]);
			pos[2] = atof(argv[count+3]);
		
			if (argc-count-1 == 4) {
				Link *wlink = getOutboardLink();
				
				ArticulatedObject *ao = wlink->getArticulatedObject();
				if (strcmp(argv[count+4],"parents") == 0) 
					   ao->moveJointAndParents(m_jointNumber,pos);
				else if (strcmp(argv[count+4],"children") == 0) 
					   ao->moveJointAndChildren(m_jointNumber,pos);
				else 
					   setPosition(pos);

			}
			else 
				setPosition(pos);
			
		}
		else {
			getPosition(pos);
			danceInterp::OutputListElement("%f",pos[0]);
			danceInterp::OutputListElement("%f",pos[1]);
			danceInterp::OutputListElement("%f",pos[2]);
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[count],"ndof") == 0)
	{
		int num = getNumDof();
		danceInterp::OutputResult("%d", num) ;
	}
	else if (strcmp(argv[count],"dof") == 0)
	{
		if (argc-count-1 < 2)
		{
			danceInterp::OutputMessage("USAGE: dof <number> {value [<value>] | label}"); 
			return DANCE_ERROR;
		}
		int	dof = atoi(argv[count+1]) ;
		if( strcmp(argv[count + 2],"stiff_damp") == 0 || strcmp(argv[count + 2], "stiff_damp_no_inertia_scale") == 0)
		{
			count += 2;
			if( argc-1-count == 2 )
			{
				double st =  atof(argv[count+1]) ;
				double damp = atof(argv[count+2]) ;
				if (strcmp(argv[count], "stiff_damp_no_inertia_scale") == 0)
				{
					this->setStiffness(dof, st);
					this->setDamping(dof, damp);
					//added for consistency  MN Nov.,05
					this->setMaxStiffness(dof, st);
					this->setMaxDamping(dof, damp);
				}
				else
				{
					//double *iner = outboardLink->getInerTensor() ;
					int i;
					int numAxes = this->getNumAxis();
					if (this->getJointType() == J_BALL)
						numAxes = 3;

					// scale by a factor that includes all child joints
					Vector inertia = {0.0, 0.0, 0.0};
					addChildInertialValues(this, inertia);

					for( i = 0 ; i < numAxes; i++ )
					{
						if( fabs(m_axis[i][0] - 1.0) <  0.00001 )
						{
							this->setStiffness(i, st * inertia[0]);
							this->setDamping(i, damp * inertia[0]);
						}
						else if( fabs(m_axis[i][1] - 1.0) <  0.00001 )
						{
							this->setStiffness(i, st * inertia[1]);
							this->setDamping(i, damp * inertia[1]);
						}
						else 
						{
							this->setStiffness(i, st * inertia[2]);
							this->setDamping(i, damp * inertia[2]);
						}
						//Fix:  set max stiffness based on inertia  MN Oct., 05
						this->setMaxStiffness(i, getStiffness(i));//this->getStiffness(i));
						this->setMaxDamping(i, getStiffness(i));//this->getDamping(i));
					}
	//incorect lines		this->setMaxStiffness(i, this->getStiffness(i));
	//				this->setMaxDamping(i, this->getDamping(i));
					danceInterp::OutputResult("parameter: stiffness %lf damp %lf\n",this->getStiffness(i), this->getDamping(i));
				}
				return DANCE_OK ;
			}
			if (argc-1-count != 3)
			{
				danceInterp::OutputMessage("USAGE: stiff_damp <dof> <stiffness> <damping>\n");
				return DANCE_ERROR ;
			}
			if(	(dof >= 0) && (dof < getStateSize()))
			{
				this->setStiffness(dof, atof(argv[count + 2]));
				this->setDamping(dof, atof(argv[count + 3]));
			}
			else
			{
				danceInterp::OutputMessage("ERROR: Joint index out of bounds\n");
				return DANCE_ERROR;
			}
		}

		int num = atoi(argv[count+1]);
		if (num < 0 || num >= getNumDof()) {
			danceInterp::OutputMessage("Dof index out of range, ignoring...");
			return DANCE_OK;
		}

 		if (strcmp(argv[count+2],"value") == 0) {
			if (argc-count-1 == 3) {
				double val = atof(argv[count+3]);
				setDof(num,val);
			}
			else {
				sprintf(dofString,"%f",getDof(num));
				danceInterp::OutputResult("%f", getDof(num)) ;
			}
		}
		else if (strcmp(argv[count+2],"label") == 0) { 
			if (getLabel(num,dofString))
				danceInterp::OutputResult("%s", dofString);
			else
				danceInterp::OutputResult("%s", "");
		}
		else if (strcmp(argv[count+2],"limits") == 0) {
			if (argc-count-1 == 4) 
				setLimits(num,atof(argv[count+3]),atof(argv[count+4]));
			else {
			    danceInterp::OutputListElement("%lf", m_Limits[num][0]) ;
			    danceInterp::OutputListElement("%lf", m_Limits[num][1]) ;
			}
			return DANCE_OK;
				
		}
		
	}
	else if (strcmp(argv[count],"types") == 0)
		return getAvailableTypes();
	else if (strcmp(argv[count],"change") == 0) 
    {
		if (argc-count-1 == 1) {
			int m_jointType = getJointTypeFromString(argv[count+1]);
			changeType(m_jointType);
		}
		return DANCE_OK;
	}
    
    else if (strcmp(argv[count],"has_velocity") == 0) 
    {
        if (argc - count - 1 == 1)
        {
            if (strcmp(argv[count + 1], "yes") == 0)
            {
                this->setHasVelocity(true);
            }
            else if (strcmp(argv[count + 1], "no") == 0)
            {
                this->setHasVelocity(false);
            }                
        }
        return DANCE_OK;
    }
    else if (strcmp(argv[count], "init_velocity") == 0)
    {
        int state = atoi(argv[count + 1]);
        double vel = atoi(argv[count + 2]);
            
        this->setInitDState(state, vel);
        danceInterp::OutputMessage("Set init velocity of joint %s to (%d, %f)", this->getName(), state, vel);
        return DANCE_OK;
    }
 
    return DANCE_OK;
}

int Joint::getLabel(int dof, char *label)
{
	const char *coord[] = { "x","y","z","azim","elev","twist"};
	if (dof < 0 || dof > getNumDof() -1) return 0;

	switch(m_jointType)	{
	   case	J_SLIDER:
		sprintf(label,"axis%d",dof);
		break;
	   case	J_FREE:
		strcpy(label,coord[dof]);
		break;
	   case	J_BALL:
			strcpy(label,coord[dof+3]);
		break;
	   case	J_GIMBAL:
	   case J_UNIVERSAL:
	   case J_PIN:
		sprintf(label,"rot%d",dof);
		break;
	}
	return 1;
}

// Sets the dof of the joint. These are user-interpreted degrees of freedom
// opposed to the "true" representation of the joint which is stored in
// m_State and m_Frame. This method also changes the appropriate m_State vector.
// All angles assumed to be in degrees.
// This function checks for joint limits while the almost equivalent setState doesn't.
int Joint::setDof(int dof, double value)
{
    if (dof < 0 || dof > getNumDof()) {
		danceInterp::OutputMessage("ERROR: dof index out of range.\n");
		return 0;
    }
    if (value < m_Limits[dof][0]) value = m_Limits[dof][0];
    if (value > m_Limits[dof][1]) value = m_Limits[dof][1];

    double azim, elev, twist;
    switch (m_jointType) {
    case J_BALL:
	  m_Frame.toAzimElevTwist(&azim,&elev,&twist);
	  if (dof == 0) azim = value;
	  if (dof == 1) elev = value;
	  if (dof == 2) twist = value;
	  m_Frame.set(azim,elev,twist);
	  m_Frame.toVector(&(m_State[0]));
    break;
    case J_FREE:
	  if (dof >= 3) {
/*
		  // changed by AS & RD 3/8/04 - hack!! 
		  Matrix3x3 matrix;
		  m_Frame.toMatrix(matrix);
		  VectorObj angles;
		  matrix.matToEuler(Matrix3x3::XYZ, angles);
		  if (dof == 3)
			  angles.assign(value * M_PI / 180.0, angles.y(), angles.z());
		  else if (dof == 4)
			  angles.assign(angles.x(), value * M_PI / 180.0, angles.z());
		  else if (dof == 5)
			  angles.assign(angles.x(), angles.y(), value * M_PI / 180.0);
		  matrix.matFromEuler(Matrix3x3::XYZ, angles);
		  m_Frame.fromMatrix(matrix);
	      m_Frame.toVector(&(m_State[3]));
*/		  
		  m_Frame.toAzimElevTwist(&azim,&elev,&twist);
	      if (dof == 3) azim = value;
	      if (dof == 4) elev = value;
	      if (dof == 5) twist = value;
	      m_Frame.set(azim,elev,twist);
	      m_Frame.toVector(&(m_State[3]));
	  }
 	  else
	      m_State[dof] = value;
    break;
    case J_PIN:
      m_State[dof] = value*M_PI/180.0;
      m_Frame.set(m_State[dof], m_axis[0]) ;
    break;
    case J_GIMBAL:
    case J_UNIVERSAL:
	{
      	  m_State[dof] = value*M_PI/180.0 ;

	  m_Frame.set(m_State[0], m_axis[0]) ;
	  // multiply the three	rotations together
	  // using quaternion multiplication
	  for( int i = 1 ; i < getNumAxis() ; i++ )
	  {
		  Quaternion q;
	      q.set(m_State[i], m_axis[i]) ;
	      m_Frame.multiply(&q)	;
	  }
	}
    break;
    case J_SLIDER:
      m_State[dof] = value ;
    break;
    }

    return 1;
}

/** Returns the degree of freedom in degrees */
double Joint::getDof(int dof)
{
    double azim, elev, twist;

    double result = 0.0;

    switch (m_jointType) {
    case J_BALL:
	  m_Frame.toAzimElevTwist(&azim,&elev,&twist);
	  if (dof == 0) result = azim;
	  if (dof == 1) result = elev;
	  if (dof == 2) result = twist;
      break;
    case J_FREE:
	  if (dof >= 3) {
	      m_Frame.toAzimElevTwist(&azim,&elev,&twist);
	      if (dof == 3) result =  azim;
	      if (dof == 4) result =  elev;
	      if (dof == 5) result =  twist;
	  }
 	  else
		  result = m_State[dof];
      break;
    case J_PIN:
		  result = m_State[dof]*180.0/M_PI;
      break;
    case J_GIMBAL:
    case J_UNIVERSAL:
		  result = m_State[dof]*180.0/M_PI;
      break;
	case J_PLANAR:
		if( dof == 2 )
			result = m_State[dof]*180.0/M_PI;
		else
			result = m_State[dof] ;
		break ;
    case J_SLIDER:
		  result = m_State[dof];
      break;
    }

    return  result;
}

void Joint::getLimits(int dof, double *low, double *high)
{
	*low = m_Limits[dof][0];
	*high = m_Limits[dof][1];
}

void Joint::setLimits(int dof, double low, double high)
{
	m_Limits[dof][0] = low; 
	m_Limits[dof][1] = high;
}

// Given the string, returns the type number.
int Joint::getJointTypeFromString(char * typeString)
{
	if (strcmp(typeString,"Pin") == 0) return J_PIN;
	if (strcmp(typeString,"Ball") == 0) return J_BALL;
	if (strcmp(typeString,"Cylinder") == 0) return J_CYLINDER;
	if (strcmp(typeString,"Slider") == 0) return J_SLIDER;
	if (strcmp(typeString,"Free") == 0) return J_FREE;
	if (strcmp(typeString,"Gimbal") == 0) return J_GIMBAL;
	if (strcmp(typeString,"Weld") == 0) return J_WELD;
	if (strcmp(typeString,"Planar") == 0) return J_PLANAR;
	if (strcmp(typeString,"Bearing") == 0) return J_BEARING;
	if (strcmp(typeString,"Universal") == 0) return J_UNIVERSAL;
	if (strcmp(typeString,"Bushing") == 0) return J_BUSHING;

	return J_UNDEF;
}

// getAvailableJoints:
//	interp: Tcl interpreter
//
// Returns a list of available joints.
// NOTE: Commented out lines are not implemented yet.
int Joint::getAvailableTypes()
{
	danceInterp::OutputListElement("Pin");
	danceInterp::OutputListElement("Ball");
	// danceInterp::OutputListElement("Cylinder");
	danceInterp::OutputListElement("Slider");
	danceInterp::OutputListElement("Free");
	danceInterp::OutputListElement("Gimbal");
	// danceInterp::OutputListElement("Weld");
	danceInterp::OutputListElement("Planar");
	// danceInterp::OutputListElement("Bearing");
	danceInterp::OutputListElement("Universal");
	// danceInterp::OutputListElement("Bushing");

	return DANCE_OK;
}

// addDof:
//		Adds the applicable delta to the joints state.
//
//		index:	index of degree of freedom
//	        deltaAngle: Delta to use for angles
//		deltaTrans: Delta to use for translations.
//              The use of setDof ensures that the joint limits
//              are preserved.
void Joint::addDof(int index, double deltaAngle, double deltaTrans)
{
	double stateValue	= 0.0;
        switch(m_jointType) {
		case J_PIN:
		     stateValue = deltaAngle+getState(0) ;
		     // convert to degrees which is what setDof takes
		     stateValue = stateValue*180.0 / (double) M_PI ;
		     setDof(0,stateValue);
		break;
	    case J_PLANAR:
		if( index == 2) 
		{
		    stateValue = deltaAngle+getState(index) ;
		    // convert to degrees which is what setDof takes
		    stateValue = stateValue*180.0 / (double) M_PI ;
		}
		else
		     stateValue = deltaTrans+getState(index) ;
		setDof(index,stateValue);
		    
		case J_BALL:
			switch(index) {
			  case  0:
			  case	1:
			  case	2: 
				{
					 Quaternion q;
					 double auxMat[4][4]; m_AuxFrame.toMatrix(auxMat);
					 q.set(deltaAngle, auxMat[index]);

					 double newMat[4][4],new_rot[4][4];
					 q.toMatrix(new_rot);
					 
					 // If alt-key pressed, change joint rotation axes.
					 if (false) { // removed by AS 1/1/05 (dance::m_ModifierKey == GLUT_ACTIVE_ALT) {
						 multArray((double *)newMat, (double *)auxMat, (double *)new_rot,4,4,4);
						 m_AuxFrame.fromMatrix(newMat);
					 }
					 else {
						 double mat[4][4]; getOrientation(mat);
						 multArray((double *)newMat,(double *)new_rot, (double *)mat,4,4,4);
						 m_Frame.fromMatrix(newMat);
						 m_Frame.toVector(&(m_State[0]));
					 }
				}
		   	   break;
			   case	3: // red 
			   case	4: // green
			   case	5: // blue
				{
				double mat[4][4];
				getOrientation(mat);

				Quaternion q_rot;
				q_rot.set(deltaAngle,mat[index-3]);

				double	 rot[4][4], new_rot[4][4];
				q_rot.toMatrix(rot);
				multArray((double *)new_rot,(double *)mat,(double *)rot,4,4,4);
				m_Frame.fromMatrix(new_rot);
				m_Frame.toVector(&(m_State[0]));
				}
				break;
			}
		break;
		case J_SLIDER:
		case J_FREE:
		case J_GIMBAL:
		case J_UNIVERSAL:
		    switch(index) {
			   case	0:
			   case	1:
			   case	2:
				if (m_jointType == J_GIMBAL ||
				    m_jointType == J_UNIVERSAL)
				{
				    // convert the value from radians to degrees
				    stateValue	=  deltaAngle + getState(index);
				    stateValue = stateValue*180.0 / (double) M_PI ;
				}
				else  // Translation stuff for free, and slider	joints
				     stateValue	= deltaTrans + getState(index);
				
				setDof(index, stateValue);
				break;
			   // Ball and socket and quaternion part of Free joint
			   case	3: // red ,
			   case	4: // green
			   case	5: // blue
				{
				double mat[4][4];
				getOrientation(mat);

				Quaternion q_rot;
				q_rot.set(deltaAngle,mat[index-3]);

				double	 rot[4][4], new_rot[4][4];
				q_rot.toMatrix(rot);
				multArray((double *)new_rot,(double *)mat,(double *)rot,4,4,4);
				m_Frame.fromMatrix(new_rot);
				m_Frame.toVector(&(m_State[3]));
				}
				break;
		    }
		break;
		default:
		    danceInterp::OutputMessage("Not implemented: joint editing\n");
    }
}

void Joint::writeBVHFile(FILE *fp, int depth)
{
	char prfx[MAX_LINE] = "" ;
	int i ;


	if( m_jointType == J_BALL )
	{
		danceInterp::OutputMessage("ERROR: writeBHVFile not "
					"implemented for ball joints yet.\n") ;
		return ;
	}

	for( i = 1 ; i < depth ; i++ )
		strcat(prfx, "\t") ;

	if( depth == 1 )
		fprintf(fp, "%s\tOFFSET 0.0000 0.0000 0.0000\n", prfx) ;
	else
	{
		Vector offset ;
		// get the parent joint of the inboard link
		Joint *inbJoint = inboardLink->getParentJoint() ;
		if( inbJoint == NULL ) 
		{
		       danceInterp::OutputMessage("ERROR: WriteBVHFile: missing joint!\n");
			return ;
		}
		Vector inbBtoJ ;
		inbJoint->getBodyToJoint(inbBtoJ) ;
		VecSubtract(offset, m_InbToJoint, inbBtoJ) ;
		fprintf(fp, "%s\tOFFSET %lf %lf %lf\n", prfx, offset[0], 
			offset[1], offset[2]) ;
	}
	
	// write the channels
	fprintf(fp, "%s\tCHANNELS %d", prfx, getNumDof()) ;
	switch (m_jointType)
	{
	case J_FREE:
		fprintf(fp, " Xposition Yposition Zposition") ;
		break ;
	case J_SLIDER:
		if( fabs(m_axis[0][0] - 1.0) < 0.00001 )
			fprintf(fp, " Xposition") ;
		else if( fabs(m_axis[0][1] - 1.0) < 0.00001 )
			fprintf(fp, " Yposition") ;
		else if( fabs(m_axis[0][2] - 1.0) < 0.00001 )
			fprintf(fp, " Zposition") ;
		else
		{
			danceInterp::OutputMessage("ERROR: WriteBVHFile: "
						"slide joint must be along "
						"one of the x,y,z axis!\n") ;
			return ;
		}
	}
	
	if( m_jointType != J_SLIDER )
	{
		for( i = 0 ; i < m_numAxis ; i++ )
		{
			if( fabs(m_axis[i][0] - 1.0) < 0.00001 )
				fprintf(fp, " Xrotation ") ;
			else if( fabs(m_axis[i][1] - 1.0) < 0.00001 )
				fprintf(fp, " Yrotation ") ;
			else if( fabs(m_axis[i][2] - 1.0) < 0.00001 )
				fprintf(fp, " Zrotation ") ;
			else
			{
				danceInterp::OutputMessage("ERROR: WriteBVHFile: "
							"axis must be along one "
							"of the x,y,z axis!\n") ;
				return ;
			}
		}
	}
	fprintf(fp, "\n") ;
}	

// Returns 1 if there has been a change in joint state.
//
int Joint::isChanged()
{
	int result = 0, i;
	double tol = 0.00001;
	for (i = 0; i < 3; i++) {
		if (fabs(m_InbToJoint[i] - m_OldInbToJoint[i]) > tol) {
			result = 1;
			break;
		}
		if (fabs(m_BodyToJoint[i] - m_OldBodyToJoint[i]) > tol) {
			result = 1;
			break;
		}
	}
	if (result) return(result);

	for (i = 0; i < getStateSize(); i++) 
		if (fabs(m_State[i] - m_OldState[i]) > tol) {
			result = 1;
			break;
		}
	return(result);
}


/**
 * Calculates the joint state variables from the joint's transformation matrix.
 *
 * @return void 
 */
void Joint::CalcState()
{
    switch (m_jointType) {
	case J_BALL:
	    m_Frame.toVector(&(m_State[0]));
	    break;
	case J_FREE:
	    // Assumes zero initial translation.
	    m_State[0] = 0.0;
	    m_State[1] = 0.0;
	    m_State[2] = 0.0;
	    m_Frame.toVector(&(m_State[3]));
	    break;
	case J_PLANAR:
	    break ;
	case J_PIN:
	    break;
	case J_GIMBAL:
	case J_UNIVERSAL:
	    break;
	case J_SLIDER:
	    break;
    }
}

void Joint::writeMayaFile(FILE *fp)
{

    // set the parent first
    if( inboardLink != NULL )
    {
		fprintf(fp, "select -r %s ;\n", inboardLink->getParentJoint()->getName()) ;
    }
    Vector p ;
    getPosition(p) ;
    fprintf(fp, "joint -name %s -absolute -p %lf %lf %lf ", 
	    getName(), p[0], p[1], p[2]) ;
    fprintf(fp, "-dof ") ;
    char dof[4] = "" ;
    if( m_jointType == J_BALL )
	strcpy(dof, "xyz") ;
    else
    {
	int i ;
	for( i = 0 ; i < getNumAxis() ; i++ )
	{
	    if( m_axis[i][0] > 0.5 ) 
		dof[i] = 'x' ; 
	    else if( m_axis[i][1] > 0.5 )
		dof[i] = 'y' ;
	    else
	    dof[i] = 'z' ;
	}
        dof[i] = '\0' ;
    }
    fprintf(fp, "%s ", dof) ;
    if( getNumAxis() == 3 )
	fprintf(fp, "-roo %s", dof) ;
    fprintf(fp, " ;\n") ;
    
    // set end effectors for childless links
    if( outboardLink->getNumChildLinks() == 0 )
    {
	fprintf(fp,"select -r %s ;\n", getName()) ;
	outboardLink->getEndEffectorWC(p) ;
	fprintf(fp, "joint -name %sEndEffector -absolute -p %lf %lf %lf ;\n",
		getName(), p[0], p[1], p[2]) ;
    }
    return ;
}

void Joint::setArticulatedObject(ArticulatedObject* artObj)
{
	m_artObj = artObj;
}

ArticulatedObject* Joint::getArticulatedObject()
{
	return m_artObj;
}

int Joint::determineRotationOrder()
{
	int index = 0;

	//added support for BALL joints MN Nov.,05
	if (this->getJointType() == J_FREE  || this->getJointType() == J_BALL)
		index = 3;
	else if (this->getJointType() == J_PLANAR)
		index = 2;

	int order = -1;
	int numDOF = this->getNumDof();

	if (m_axis[0][0] == 1.0 && m_axis[0][1] == 0.0 && m_axis[0][2] == 0.0)
	{
		if (numDOF > 1)
		{
			if (m_axis[1][0] == 0.0 && m_axis[1][1] == 1.0 && m_axis[1][2] == 0.0)
			{
				if (numDOF > 2)
					order = Matrix3x3::XYZ;
				else
					order = Matrix3x3::XY;
			}
			else
			{
				if (numDOF > 2)
					order = Matrix3x3::XZY;
				else
					order = Matrix3x3::XZ;
			}
		}
		else
		{
			order = Matrix3x3::X;
		}
	}
	else if (m_axis[0][0] == 0.0 && m_axis[0][1] == 1.0 && m_axis[0][2] == 0.0)
	{
		if (numDOF > 1)
		{
			if (m_axis[1][0] == 1.0 && m_axis[1][1] == 0.0 && m_axis[1][2] == 0.0)
			{
				if (numDOF > 2)
					order = Matrix3x3::YXZ;
				else
					order = Matrix3x3::YX;
			}
			else
			{
				if (numDOF > 2)
					order = Matrix3x3::YZX;
				else
					order = Matrix3x3::YZ;
			}
		}
		else
		{
			order = Matrix3x3::Y;
		}
	}
	else if (m_axis[0][0] == 0.0 && m_axis[0][1] == 0.0 && m_axis[0][2] == 1.0)
	{
		if (numDOF > 1)
		{
			if (m_axis[1][0] == 1.0 && m_axis[1][1] == 0.0 && m_axis[1][2] == 0.0)
			{
				if (numDOF > 2)
					order = Matrix3x3::ZXY;
				else
					order = Matrix3x3::ZX;
			}
			else
			{
				if (numDOF > 2)
					order = Matrix3x3::ZYX;
				else
					order = Matrix3x3::ZY;
			}
		}
		else
		{
			order = Matrix3x3::Z;
		}
	}

	return order;
}

void Joint::setRotationOrder(int order)
{
	Vector xaxis = {1.0, 0.0, 0.0};
	Vector yaxis = {0.0, 1.0, 0.0};
	Vector zaxis = {0.0, 0.0, 1.0};

	switch (this->getJointType())
	{
		case J_PIN:
			if (order == Matrix3x3::X)  // X
			{
				this->setAxis(0, xaxis);
			}
			else if (order == Matrix3x3::Y) // Y
			{
				this->setAxis(0, yaxis);
			}
			else if (order == Matrix3x3::Z) // Z
			{
				this->setAxis(0, zaxis);
			}
			else
			{
				danceInterp::OutputMessage("Order %d not appropriate for pin joint.", order);
			}
			break;
		case J_UNIVERSAL:
			if (order == Matrix3x3::XY)  // XY
			{
				this->setAxis(0, xaxis);
				this->setAxis(1, yaxis);
			}
			else if (order == Matrix3x3::XZ) // XZ
			{
				this->setAxis(0, xaxis);
				this->setAxis(1, zaxis);
			}
			else if (order == Matrix3x3::YX) // YX
			{
				this->setAxis(0, yaxis);
				this->setAxis(1, xaxis);
			}
			else if (order == Matrix3x3::YZ) // YZ
			{
				this->setAxis(0, yaxis);
				this->setAxis(1, zaxis);
			}
			else if (order == Matrix3x3::ZX) // ZX
			{
				this->setAxis(0, zaxis);
				this->setAxis(1, xaxis);
			}
			else if (order == Matrix3x3::ZY) // ZY
			{
				this->setAxis(0, zaxis);
				this->setAxis(1, yaxis);
			}
			else
			{
				danceInterp::OutputMessage("Order %d not appropriate for universal joint.", order);
			}
			break;
		case J_GIMBAL:
		case J_BALL:
		case J_FREE:
			if (order == Matrix3x3::XYZ)  // XYZ
			{
				this->setAxis(0, xaxis);
				this->setAxis(1, yaxis);
				this->setAxis(2, zaxis);
			}
			else if (order == Matrix3x3::XZY) // XZY
			{
				this->setAxis(0, xaxis);
				this->setAxis(1, zaxis);
				this->setAxis(2, yaxis);
			}
			else if (order == Matrix3x3::YXZ) // YXZ
			{
				this->setAxis(0, yaxis);
				this->setAxis(1, xaxis);
				this->setAxis(2, zaxis);
			}
			else if (order == Matrix3x3::YZX) // YZX
			{
				this->setAxis(0, yaxis);
				this->setAxis(1, zaxis);
				this->setAxis(2, xaxis);
			}
			else if (order == Matrix3x3::ZXY) // ZXY
			{
				this->setAxis(0, zaxis);
				this->setAxis(1, xaxis);
				this->setAxis(2, yaxis);
			}
			else if (order == Matrix3x3::ZYX) // ZYX
			{
				this->setAxis(0, zaxis);
				this->setAxis(1, yaxis);
				this->setAxis(2, xaxis);
			}
			else
			{
				danceInterp::OutputMessage("Order %d not appropriate for gimbal/free joint.", order);
			}
			break;
		default:
			danceInterp::OutputMessage("Joint number %d not supported yet in setRotationOrder().", this->getJointType());
			break;
	}
}

void Joint::setName(const char* name)
{
	strncpy(m_name, name, JOINT_MAX_NAME_LEN);
}

const char* Joint::getName()
{
	return m_name;
}

int	Joint::getNumAxis()
{
	return m_numAxis;
}

void Joint::setNumAxis(int num)
{
	m_numAxis = num;
}

void Joint::setAxis(int index, double* axis)
{
	VecCopy(m_axis[index], axis);
}

double* Joint::getBodyToJoint()
{
	return this->m_BodyToJoint;
}

double* Joint::getInbToJoint()
{
	return this->m_InbToJoint;
}

void Joint::setBodyToJoint(double* vec)
{
	VecCopy(this->m_BodyToJoint, vec);
}

void Joint::setInbToJoint(double* vec)
{
	VecCopy(this->m_InbToJoint, vec);

/*	if (inboardLink) // will be NULL for first link				commented out by Julia 8/16/05
		inboardLink->setEndEffector(vec);*/
}

Link* Joint::getInboardLink()
{
	return this->inboardLink;
}

Link* Joint::getOutboardLink()
{
	return this->outboardLink;
}

void Joint::setInboardLink(Link* l)
{
	this->inboardLink = l;
}

void Joint::setOutboardLink(Link* l)
{
	this->outboardLink = l;
}

int Joint::getJointNum()
{
	return this->m_jointNumber;
}

void Joint::setJointNum(int val)
{
	this->m_jointNumber = val;
}

int Joint::getJointType()
{
	return this->m_jointType;
}

void Joint::setJointType(int type)
{
	this->m_jointType = type;

	switch(type)
    {
	case J_PIN:
	    m_numAxis = 1 ;
	    setVector(m_axis[0],0.0,0.0,1.0) ;
	    setState(0, 0.0) ;
	    m_Limits[0][0] = -180.0; m_Limits[0][1] = 180.0;
	    break ;
	case J_PLANAR:
	    m_numAxis = 3 ;
	    setVector(m_axis[0],0.0,1.0,0.0) ;
	    setVector(m_axis[1],0.0,0.0,1.0) ;
	    setVector(m_axis[2],1.0,0.0,0.0) ;
	    setState(0, 0.0) ;
	    setState(1, 0.0) ;
	    setState(2, 0.0) ;
	    m_Limits[2][0] = -180.0; m_Limits[2][1] = 180.0;
	    break ;

    case J_UNIVERSAL:
		m_numAxis = 2 ;
		setVector(m_axis[0],1.0,0.0,0.0) ;
		setVector(m_axis[1],0.0,1.0,0.0) ;
		setState(0, 0.0) ;
		setState(1, 0.0) ;
		m_Limits[0][0] = -180.0; m_Limits[0][1] = 180.0;
		m_Limits[1][0] = -180.0; m_Limits[1][1] = 180.0;
	break ;
    case J_GIMBAL:
    case J_FREE:
	{
		m_numAxis = 3 ;
		setVector(m_axis[0],1.0,0.0,0.0) ;
		setVector(m_axis[1],0.0,1.0,0.0) ;
		setVector(m_axis[2],0.0,0.0,1.0) ;
		m_Limits[0][0] = -180.0; m_Limits[0][1] = 180.0;
		m_Limits[1][0] = -180.0; m_Limits[1][1] = 180.0;
		m_Limits[2][0] = -180.0; m_Limits[2][1] = 180.0;

		double mat[4][4], cmat[4][4], pmat[4][4];
		if (inboardLink)
			inboardLink->getOrientation(pmat);
		else {
			for	(int i=0; i < 4; i++)
			for (int j=0; j	< 4; j++) {
				if (i==j) pmat[i][j] = 1.0;
				else pmat[i][j]	= 0.0;
			}
		}
		if (outboardLink)
			outboardLink->getOrientation(cmat);

		relativeToFrame(mat,cmat,pmat);
		m_Frame.fromMatrix(mat);
		CalcState();
		m_Limits[3][0] = -180; m_Limits[3][1] = 180.0;
		m_Limits[4][0] = -180; m_Limits[4][1] = 180.0;
		m_Limits[5][0] = -180; m_Limits[5][1] = 180.0;
	}
	break ;
    case J_BALL:
	{
		m_numAxis	= 0;
		// Determine frame of link l relative to link p
		// Convert to quaternion
		double mat[4][4], cmat[4][4], pmat[4][4];
		if (inboardLink)
			inboardLink->getOrientation(pmat);
		else {
			for	(int i=0; i < 4; i++)
			for (int j=0; j	< 4; j++) {
				if (i==j) pmat[i][j] = 1.0;
				else pmat[i][j]	= 0.0;
			}
		}
		if (outboardLink)
			outboardLink->getOrientation(cmat);
		relativeToFrame(mat,cmat,pmat);
		m_Frame.fromMatrix(mat);
		m_AuxFrame.set(0.0,0.0,0.0,1.0);
		CalcState();
		m_Limits[0][0] = -180; m_Limits[0][1] = 180.0;
		m_Limits[1][0] = -180; m_Limits[1][1] = 180.0;
		m_Limits[2][0] = -180; m_Limits[2][1] = 180.0;
	}
	break ;
    case J_SLIDER:
		m_numAxis	= 1;
		setState(0,0.0);
		setVector(m_axis[0],1.0,0.0,0.0) ;
		m_Limits[0][0] = -10.0; m_Limits[0][1] = 10.0;
	break;
    case J_WELD:
	 m_numAxis = 0 ;
	 break ;
    default:
		danceInterp::OutputMessage("Joint type %d\n", type) ;
		danceInterp::OutputMessage("ERROR:Joint::create: "
					"Not implemented yet.") ;
		break;
    }

}


void Joint::setDamping(int index, double d)
{
	damping[index] = d;
}

double Joint::getDamping(int index)
{
	return damping[index];
}

void Joint::setStiffness(int index, double s)
{
	stiffness[index] = s;
}

double Joint::getStiffness(int index)
{
		return stiffness[index];
}

void Joint::setMaxDamping(int index, double d)
{
	maxDamping[index] = d;
}

double Joint::getMaxDamping(int index)
{
	return maxDamping[index];
}

void Joint::setMaxStiffness(int index, double s)
{
	maxStiffness[index] = s;
}

double Joint::getMaxStiffness(int index)
{
	return maxStiffness[index];
}

Quaternion* Joint::getQuaternion()
{
	return &m_Frame;
}

void Joint::setQuaternion(Quaternion* q)
{
	double* data = q->data();
	m_Frame.set(data[0], data[1], data[2], data[3]);
}

void Joint::setDState(int index, double state)
{
	m_dState[index] = state;
}

void Joint::setInitDState(int index, double state)
{
		m_InitDState[index] = state;
}

double Joint::getDState(int index)
{
	return m_dState[index];
}

double Joint::getInitDState(int index)
{
	return m_InitDState[index];
}

bool Joint::hasVelocity()
{
	return m_hasVelocity;
}

void Joint::setHasVelocity(bool val)
{
	m_hasVelocity = val;
}

void Joint::setZeroState()
{
	if (this->getJointType() == J_FREE)
	{
		this->setState(0, 0.0);
		this->setState(1, 0.0);
		this->setState(2, 0.0);
		this->setState(3, 0.0);
		this->setState(4, 0.0);
		this->setState(5, 0.0);
		this->setState(6, 1.0);
	}
	else if (this->getJointType() == J_BALL)
	{
		this->setState(0, 0.0);
		this->setState(1, 0.0);
		this->setState(2, 0.0);
		this->setState(3, 1.0);
	}
	else if (this->getJointType() == J_GIMBAL)
	{
		this->setState(0, 0.0);
		this->setState(1, 0.0);
		this->setState(2, 0.0);
	}
	else if (this->getJointType() == J_UNIVERSAL)
	{
		this->setState(0, 0.0);
		this->setState(1, 0.0);
	}
	else if (this->getJointType() == J_PIN)
	{
		this->setState(0, 0.0);
	}
	else if (this->getJointType() == J_PLANAR)
	{
		this->setState(0, 0.0);
		this->setState(1, 0.0);
		this->setState(2, 0.0);
	}
	else if (this->getJointType() == J_WELD)
	{
		// no DOF for weld joint
	}
	else
	{
		danceInterp::OutputMessage("Joint type %d not supported for zero pose functionality.");
	}
}









