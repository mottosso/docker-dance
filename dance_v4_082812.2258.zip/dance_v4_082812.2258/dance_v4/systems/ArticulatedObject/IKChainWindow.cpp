/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "IKChainWindow.h"
#include "ArticulatedObjectWindow.h"
#include "dance.h"
#include "Preference.h"
#include <fltk/ask.h>
#include <fltk/Item.h>
#include <fltk/Font.h>

using namespace fltk;

IKChainWindow::IKChainWindow(ArticulatedObjectWindow* win, int x, int y, int w, int h, const char* name) : Window(x, y, w, h, name)
{
	this->begin();

	nameInput = new Input(80, 10, w-90, 20, "IK Chain name:");
	nameInput->align(ALIGN_LEFT);

	availJointsBrowser = new Browser(10, 55, 165, h-95, "Available Joints");
	availJointsBrowser->align(ALIGN_LEFT | ALIGN_TOP);
	availJointsBrowser->callback(availbrowser_cb, this);

	addButton = new Button(185, 100, 30, 30, "@->");
	addButton->callback(addjoint_cb, this);
	
	Button *button = new Button(185, 150, 30, 30, "Reset");
	button->labelsize(10);
	button->callback(resetchain_cb, this);

	button = new Button(185, 200, 30, 30, "@<-");
	button->callback(removejoint_cb, this);
    
	addedJointsBrowser = new Browser(225, 55, 165, h-95, "Added Joints");
	addedJointsBrowser->align(ALIGN_LEFT | ALIGN_TOP);

	button = new Button(400, 100, 30, 30, "@8->");
	button->callback(moveupjoint_cb, this);

	button = new Button(400, 150, 30, 30, "@2->");
	button->callback(movedownjoint_cb, this);

	button = new Button(w-80, h-30, 70, 20, "Cancel");
	button->callback(cancel_cb, this);

	button = new Button(w-160, h-30, 70, 20, "OK");
	button->callback(ok_cb, this);

	this->end();
	this->set_modal();

	activeIKChain = NULL;
	aoWin = win;
}

void IKChainWindow::setIKChain(IKChain* chain)
{
	activeIKChain = chain;

	this->removeAllAddedJoints();
	this->removeAllAvailJoints();

	if(activeIKChain != NULL)
	{
		this->nameInput->value(activeIKChain->getName());

		for(int i = 0, j = 0; i < this->aoWin->m_artObj->getNumJoints(); i++)
		{
			Joint *joint = this->aoWin->m_artObj->getJoint(i);
			if(activeIKChain->getNumJoints() > 0 && j < activeIKChain->getNumJoints())
			{
				if(joint == activeIKChain->getJoint(j) && joint->getNumDof() <= 3)
				{
					addJointToAddedBrowser(joint);
					j++;
				}
				else
				{
					if(joint->getNumDof() <= 3)
						addJointToAvailBrowser(joint);
				}
			}
			else
			{
				if(joint->getNumDof() <= 3)
					addJointToAvailBrowser(joint);
			}
		}
	}
	else
	{
		// update name
		this->nameInput->value("new_ik_chain");

		// populate browsers
		for(int i = 0; i < this->aoWin->m_artObj->getNumJoints(); i++)
		{
			Joint *joint = this->aoWin->m_artObj->getJoint(i);
			if(joint->getNumDof() <= 3)
				addJointToAvailBrowser(joint);
		}
	}
}

IKChain* IKChainWindow::getIKChain()
{
	return activeIKChain;
}

void IKChainWindow::addJointToAddedBrowser(Joint* j)
{
	if(j != NULL)
	{
		// determine where to add the joint
		for (int x = 0; x < this->addedJointsBrowser->size(); x++)
		{
			Joint* curJoint = this->aoWin->getArtObj()->getJoint(addedJoints[x]->getName());
			Link* inboard = curJoint->getInboardLink();
			if (inboard == NULL)
				continue;
			
			Joint* tempJoint = inboard->getParentJoint();
			while (tempJoint != NULL)
			{
				if (tempJoint == j)
				{
					// insert joint before this child
					addedJointsBrowser->insert(x, j->getName());
					addedJointsBrowser->value(x);
					// add to the corresponding position in the added joints vector
					int count = 0;
					for (std::vector<Joint*>::iterator iter = addedJoints.begin(); iter != addedJoints.end(); iter++)
					{
						if (count == x)
						{
							addedJoints.insert(iter, j);
							break;
						}
						else 
						{
							count++;
						}
					}
					return;
				}

				inboard = tempJoint->getInboardLink();
				if (inboard == NULL)
					break;
				tempJoint = inboard->getParentJoint();
			}
		}
		addedJointsBrowser->add(j->getName());
		addedJointsBrowser->value(addedJointsBrowser->size()-1);
		addedJoints.push_back(j);
	}
}

void IKChainWindow::addJointToAvailBrowser(Joint* j)
{
	if(j != NULL)
	{
		// determine where to add the joint
		for (int x = 0; x < this->availJointsBrowser->size(); x++)
		{
			Joint* curJoint = this->aoWin->getArtObj()->getJoint(availJoints[x]->getName());
			Link* inboard = curJoint->getInboardLink();
			if (inboard == NULL)
				continue;
			
			Joint* tempJoint = inboard->getParentJoint();
			while (tempJoint != NULL)
			{
				if (tempJoint == j)
				{
					// insert joint before this child
					availJointsBrowser->insert(x, j->getName());
					availJointsBrowser->value(x);
					// add to the corresponding position in the added joints vector
					int count = 0;
					for (std::vector<Joint*>::iterator iter = availJoints.begin(); iter != availJoints.end(); iter++)
					{
						if (count == x)
						{
							availJoints.insert(iter, j);
							break;
						}
						else 
						{
							count++;
						}
					}
					return;
				}

				inboard = tempJoint->getInboardLink();
				if (inboard == NULL)
					break;
				tempJoint = inboard->getParentJoint();
			}
		}

		availJointsBrowser->add(j->getName());
		availJointsBrowser->value(availJointsBrowser->size()-1);
		availJoints.push_back(j);
	}
}

void IKChainWindow::removeAllAddedJoints()
{
	this->addedJointsBrowser->clear();
	addedJoints.clear();
}

void IKChainWindow::removeAllAvailJoints()
{
	this->availJointsBrowser->clear();
	availJoints.clear();
}

void IKChainWindow::updateGUI()
{
	this->addedJointsBrowser->clear();
	this->availJointsBrowser->clear();

	if (activeIKChain != NULL)	// edit IK chain window
	{
		this->label("Edit IK Chain");
	}
	else						// create IK chain window
	{
		this->label("Create IK Chain");
	}

	// populate added joints browser
	for(unsigned int i = 0; i < addedJoints.size(); i++)
	{
		char label[256];
		strcpy(label, addedJoints[i]->getName());

		if( i == 0 )
			strcat(label, " (root)");

		addedJointsBrowser->add(label);
	}

	// populate available joints browser
	for(unsigned int i = 0; i < availJoints.size(); i++)
	{
		availJointsBrowser->add(availJoints[i]->getName());

		bool isParentOrChild = false;
		for(unsigned int j = 0; j < addedJoints.size(); j++)
		{
			if(addedJoints[j]->getInboardLink() == NULL)
				continue ;
			
			Joint* parentJoint = addedJoints[j]->getInboardLink()->getParentJoint();
			if(parentJoint == NULL)
				continue ;

			if(parentJoint == availJoints[i])
			{
				isParentOrChild = true;
			}
			else
			{
				Link* childLink = addedJoints[j]->getOutboardLink();
				if(childLink == NULL)
					continue ;

				Link** childLinks = childLink->getChildLinks();
				if(childLinks == NULL)
					continue ;

				for(int k = 0; k < childLink->getNumChildLinks(); k++)
				{
					if(childLinks[k] == NULL)
						continue ;

					if(childLinks[k]->getParentJoint() == availJoints[i])
						isParentOrChild = true;
				}
			}
		}

		if(!isParentOrChild && addedJoints.size() > 0)
		{
			Item* w = (Item *)availJointsBrowser->find(availJoints[i]->getName());
			w->textcolor(fltk::RED);
			w->selection_textcolor();
			w->deactivate();
		}
	}

	int selected = this->availJointsBrowser->value();
	if (selected >= 0 && 
	    this->availJoints.size() > 0 && 
	    selected < availJoints.size())
	 {
		if(!this->availJointsBrowser->find(availJoints[selected]->getName())->active())
			this->addButton->deactivate();
		else
			this->addButton->activate();
	 }

}

void IKChainWindow::show()
{
	updateGUI();
	
	this->availJointsBrowser->value(0);

	// save the state of the ik chain
	addedState.clear();
	for(unsigned int i = 0; i < addedJoints.size(); i++)
		addedState.push_back(addedJoints[i]);

	availState.clear();
	for(unsigned int i=0; i<availJoints.size(); i++)
		availState.push_back(availJoints[i]);

	Window::show();
}

void IKChainWindow::availbrowser_cb(fltk::Widget* o, void *p)
{
	IKChainWindow *sWin = (IKChainWindow *)p;

	int selected = sWin->availJointsBrowser->value();
	if(!sWin->availJointsBrowser->find(sWin->availJoints[selected]->getName())->active())
		sWin->addButton->deactivate();
	else
		sWin->addButton->activate();
}

void IKChainWindow::addjoint_cb(fltk::Widget* o, void* p)
{
	IKChainWindow *sWin = (IKChainWindow *)p;

	int selected = sWin->availJointsBrowser->value();
	int size = sWin->availJointsBrowser->size();
	if(selected >= 0 && selected < size && size > 0)
	{
		sWin->addJointToAddedBrowser(sWin->availJoints[selected]);
		std::vector<Joint *>::iterator iter = sWin->availJoints.begin() + selected;
		sWin->availJoints.erase(iter);

		sWin->updateGUI();
	}
}

void IKChainWindow::resetchain_cb(fltk::Widget* o, void* p)
{
	IKChainWindow *sWin = (IKChainWindow *)p;
	
	sWin->removeAllAddedJoints();
	sWin->removeAllAvailJoints();

	for(unsigned int i=0; i<sWin->addedState.size(); i++)
		sWin->addedJoints.push_back(sWin->addedState[i]);

	for(unsigned int i=0; i<sWin->availState.size(); i++)
		sWin->availJoints.push_back(sWin->availState[i]);

	sWin->updateGUI();
}

void IKChainWindow::removejoint_cb(fltk::Widget* o, void* p)
{
	IKChainWindow *sWin = (IKChainWindow *)p;
	
	int selected = sWin->addedJointsBrowser->value();
	int size = sWin->addedJointsBrowser->size();
	if(selected >= 0 && selected < size && size > 0)
	{
		sWin->addJointToAvailBrowser(sWin->addedJoints[selected]);
		std::vector<Joint *>::iterator iter = sWin->addedJoints.begin() + selected;
		sWin->addedJoints.erase(iter);

		sWin->updateGUI();
	}
}

void IKChainWindow::moveupjoint_cb(fltk::Widget* o, void* p)
{
	IKChainWindow *sWin = (IKChainWindow *)p;
	
	int selected = sWin->addedJointsBrowser->value();
	if(selected > 0 && sWin->addedJointsBrowser->size() > 0)
	{
		Joint* j = sWin->addedJoints[selected-1];
		sWin->addedJoints[selected-1] = sWin->addedJoints[selected];
		sWin->addedJoints[selected] = j;
//		sWin->addedJointsBrowser->swap(selected, selected-1);
		sWin->updateGUI();
		sWin->addedJointsBrowser->value(selected-1);
	}
}

void IKChainWindow::movedownjoint_cb(fltk::Widget* o, void* p)
{
	IKChainWindow *sWin = (IKChainWindow *)p;
	
	int size = sWin->addedJointsBrowser->size();
	int selected = sWin->addedJointsBrowser->value();
	if(selected >= 0 && selected < size-1  && size > 0)
	{
		Joint* j = sWin->addedJoints[selected+1];
		sWin->addedJoints[selected+1] = sWin->addedJoints[selected];
		sWin->addedJoints[selected] = j;
//		sWin->addedJointsBrowser->swap(selected, selected+1);
		sWin->updateGUI();
		sWin->addedJointsBrowser->value(selected+1);
	}
}

void IKChainWindow::cancel_cb(fltk::Widget* o, void* p)
{
	IKChainWindow *sWin = (IKChainWindow *)p;
	
	sWin->removeAllAddedJoints();
	sWin->removeAllAvailJoints();

	for(unsigned int i=0; i<sWin->addedState.size(); i++)
		sWin->addedJoints.push_back(sWin->addedState[i]);

	for(unsigned int i=0; i<sWin->availState.size(); i++)
		sWin->availJoints.push_back(sWin->availState[i]);
	
	Preference::setWindowPreference("ArticulatedObject.ikchainwindow", sWin);
	dance::writePreferences();
	sWin->hide();
}

void IKChainWindow::ok_cb(fltk::Widget* o, void* p)
{
	IKChainWindow *sWin = (IKChainWindow *)p;
	ArticulatedObject *aObj = sWin->aoWin->m_artObj;

	for(int i=0; i < aObj->getNumIKChains(); i++)
	{
		if( strcmp(sWin->nameInput->value(), aObj->getIKChain(i)->getName()) == 0 )
		{
			if(sWin->activeIKChain == NULL)
			{
				fltk::alert("There is already an IK Chain with the name '%s'.  Please choose a different name.", sWin->nameInput->value());
				return ;
			}
			else if(sWin->activeIKChain != NULL && sWin->activeIKChain != aObj->getIKChain(i))
			{
				fltk::alert("There is already an IK Chain with the name '%s'.  Please choose a different name.", sWin->nameInput->value());
				return ;
			}
		}
	}

	if(sWin->activeIKChain == NULL)	// create a new chain
	{
		IKChain *ikChain = new IKChain;
		
		for (unsigned int i=0; i<sWin->addedJoints.size(); i++)
			ikChain->addJoint(sWin->addedJoints[i]);

		if(!ikChain->isChain())
		{
			fltk::alert("The joints of '%s' do not make a valid IK Chain.  Please adjust the joints accordingly.", sWin->nameInput->value());
			delete ikChain;
			return ;
		}

		ikChain->setName(sWin->nameInput->value());
		sWin->aoWin->m_artObj->createIKChain(ikChain);

		sWin->aoWin->m_artObj->setActiveIKChain(sWin->aoWin->m_artObj->getNumIKChains()-1);
		sWin->aoWin->updateGUI();
	}
	else							// edit an exisiting chain
	{
		IKChain *ikChain = aObj->getIKChain(aObj->getActiveIKChain());
		ikChain->reset();
		
		for(unsigned int i=0; i<sWin->addedJoints.size(); i++)
			ikChain->addJoint(sWin->addedJoints[i]);

		if(!ikChain->isChain())
		{
			fltk::alert("The joints of '%s' do not make a valid IK Chain.  Please rearrange the joint order accordingly.", sWin->nameInput->value());

			ikChain->reset();
			for(unsigned int i=0; i<sWin->addedState.size(); i++)
				ikChain->addJoint(sWin->addedState[i]);

			return ;
		}

		ikChain->setName(sWin->nameInput->value());
		sWin->aoWin->updateGUI();
	}

	Preference::setWindowPreference("ArticulatedObject.ikchainwindow", sWin);
	dance::writePreferences();

	sWin->hide();
}
