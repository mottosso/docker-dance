/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "AttachmentWindow.h"
#include <fltk/Output.h>
#include <fltk/Input.h>
#include "ArticulatedObjectWindow.h"
#include "matrix3x3.h"
#include <fltk/ask.h>
#include "Preference.h"
#include "dance.h"

using namespace fltk;

AttachmentWindow::AttachmentWindow(ArticulatedObjectWindow* aowin, int w, int h, const char* name) : Window(w, h, name)
{
	artObjWin = aowin;

	this->attachedAO = NULL;
	this->attachedLinkNum = -1;
	this->attachedStatic = NULL;

	this->begin();

	choiceJoints = new Choice(30, 10, 100, 20, "Joint");
	choiceJoints->callback(changejoint_cb, this);

	Group* groupSkeletons = new Group(15, 40, 200, 70, "Skeleton Attachments");
	groupSkeletons->box(fltk::BORDER_BOX);
	groupSkeletons->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupSkeletons->begin();

	choiceSkeletons = new Choice(70, 15, 100, 20, "Skeletons");
	choiceSkeletons->callback(this->chooseskeletons_cb, this);

	choiceBodies = new Choice(70, 40, 100, 20, "Body");
	choiceBodies->callback(this->choosebodies_cb, this);

	groupSkeletons->end();

	Group* groupStatic = new Group(15, 130, 200, 70, "Static Attachments");
	groupStatic->box(fltk::BORDER_BOX);
	groupStatic->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupStatic->begin();

	choiceStatic = new Choice(70, 15, 100, 20, "Geometries");
	choiceStatic->callback(this->choosestatic_cb, this);

	groupSkeletons->end();

	buttonSetAndClose = new Button(20, this->h() - 30, 80, 20, "Set and Close");
	buttonSetAndClose->callback(setattachments_cb, this);
	buttonSet = new Button(110, this->h() - 30, 50, 20, "Set");
	buttonSet->callback(setattachments_cb, this);
	buttonCancel = new Button(this->w() - 80, this->h() - 30, 50, 20, "Cancel");
	buttonCancel->callback(cancel_cb, this);

	buttonRemoveAllAttachments = new Button(20, this->h() - 85, 140, 20, "Remove All Attachments");
	buttonRemoveAllAttachments->callback(this->removeallattachments_cb, this);
	
	buttonRemoveCurrentAttachments = new Button(20, this->h() - 110, 140, 20, "Remove Attachments");
	buttonRemoveCurrentAttachments->callback(this->removecurrentattachments_cb, this);

	buttonShowAttachments = new CheckButton(20, this->h() - 60, 140, 20, "Show Attachments");
	buttonShowAttachments->callback(this->showattachments_cb, this);
	
	this->end();

	this->setJoint(NULL);
}

void AttachmentWindow::setJoint(Joint* j)
{
	joint = j;
	if (joint == NULL)
	{
		this->choiceJoints->value(0);
	}
	else
	{
		// select this joint in the choice joint
		int num = j->getOutboardLink()->getNumber();
		if (this->choiceJoints->value() != num)
			this->choiceJoints->value(num);
	}
}

Joint* AttachmentWindow::getJoint()
{
	return joint;
}

void AttachmentWindow::updateGUI()
{
	int num = choiceJoints->value();

	ArticulatedObject* ao = this->artObjWin->getArtObj();
	this->choiceJoints->clear();
	for (int x = 0; x < ao->getNumJoints(); x++)
	{
		Joint* curJoint = ao->getJoint(x);
		this->choiceJoints->add(curJoint->getName());
	}

	if (ao->isShowingAttachments())
	{
		this->buttonShowAttachments->value(1);
	}
	else
	{
		this->buttonShowAttachments->value(0);
	}

	choiceJoints->value(num);

	this->choiceSkeletons->clear();
	this->choiceSkeletons->add("Please choose a skeleton");
	if (joint != NULL)
	{
		int current = 0;
		ArticulatedObject* cur = NULL;
		for (int x = 0; x < dance::AllSystems->size(); x++)
		{
			ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get(x));
			if (ao != NULL)
			{
				this->choiceSkeletons->add(ao->getName());
				if (ao == attachedAO)
				{
					cur = ao;
					this->choiceSkeletons->value(current);
				}
				current++;
			}
		}

		if (cur == NULL)
		{
			this->choiceSkeletons->value(0);
			this->choiceBodies->clear();
			this->choiceBodies->add("No skeleton selected");
			this->choiceBodies->deactivate();
		}
		else
		{			
			this->choiceSkeletons->value(current);
			this->choiceBodies->clear();
			this->choiceBodies->add("Please choose a skeleton");
			for (int x = 0; x < cur->getNumLinks(); x++)
			{
				Link* link = cur->getLink(x);
				this->choiceBodies->add(link->getName());
			}
			this->choiceBodies->activate();
			this->choiceBodies->value(this->attachedLinkNum + 1);
		}


		this->choiceStatic->clear();
		this->choiceStatic->add("Please choose a geometry");
		if (joint == NULL)
		{
			this->choiceStatic->value(0);
		}
		else
		{
			int current = 0;
			DGeometry* geom = NULL;
			for (int x = 0; x < dance::AllGeometry->size(); x++)
			{
				DGeometry* geom = dynamic_cast<DGeometry*>(dance::AllGeometry->get(x));
				if (geom != NULL)
				{
					// make sure that this geometry is not attached to any skeleton
					bool found = false;
					for (int s = 0; s < dance::AllSystems->size(); s++)
					{
						ArticulatedObject* curAO = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get(s));
						if (curAO != NULL)
						{
							for (int l = 0; l < curAO->getNumLinks(); l++)
							{
								Link* curLink = curAO->getLink(l);
								if (curLink->getGeometry() == geom ||
									curLink->getGeometryCollision() == geom ||
									curLink->getGeometryProp() == geom)
								{
									found = true;
									continue;
								}
							}
						}
					}
					
					if (!found)
					{
						this->choiceStatic->add(geom->getName());
						if (geom == this->attachedStatic)
						{
							this->attachedStatic = geom;
							this->choiceStatic->value(current + 1);
						}
						current++;
					}
				}
			}
			if (this->attachedStatic == NULL)
				this->choiceStatic->value(0);
		}

	}
	else
	{

	}


	this->redraw();
}

void AttachmentWindow::show()
{
	int attachNum;
	this->attachedAO = joint->getOutboardLink()->getAttachment(attachNum);
	this->attachedLinkNum = attachNum;

	this->updateGUI();
	Window::show();
}

void AttachmentWindow::removeallattachments_cb(fltk::Widget* widget, void* data)
{
	AttachmentWindow* vWin = (AttachmentWindow*) data;

	if (fltk::ask("Are you sure you want to\nremove all attachments?"))
	{
		ArticulatedObject* ao = vWin->artObjWin->getArtObj();
		int numJoints = ao->getNumLinks();
		for (int l = 0; l < numJoints; l++)
		{
			Link* link = ao->getLink(l);
			link->setAttachment(NULL, -1);
			link->setAttachmentStatic(NULL);
		}
		vWin->attachedAO = NULL;
		vWin->attachedLinkNum = -1;
		vWin->attachedStatic = NULL;
		vWin->updateGUI();
	}
}

void AttachmentWindow::removecurrentattachments_cb(fltk::Widget* widget, void* data)
{
	AttachmentWindow* vWin = (AttachmentWindow*) data;

	ArticulatedObject* ao = vWin->artObjWin->getArtObj();

	Link* link = ao->getLink(vWin->choiceJoints->value());

	link->setAttachment(NULL, -1);
	link->setAttachmentStatic(NULL);

	vWin->attachedAO = NULL;
	vWin->attachedLinkNum = -1;
	vWin->attachedStatic = NULL;
	vWin->updateGUI();
}

void AttachmentWindow::showattachments_cb(fltk::Widget* widget, void* data)
{
	AttachmentWindow* vWin = (AttachmentWindow*) data;

	ArticulatedObject* ao = vWin->artObjWin->getArtObj();

	CheckButton* checkButton = (CheckButton*) widget;

	ao->setIsShowingAttachments(checkButton->value());

	vWin->updateGUI();

	dance::Refresh();
}

void AttachmentWindow::cancel_cb(fltk::Widget* widget, void* data)
{
	AttachmentWindow* vWin = (AttachmentWindow*) data;

	vWin->hide();
}

void AttachmentWindow::changejoint_cb(fltk::Widget* widget, void* data)
{
	AttachmentWindow* vWin = (AttachmentWindow*) data;

	ArticulatedObject* ao = vWin->artObjWin->getArtObj();

	Joint* joint = ao->getJoint(vWin->choiceJoints->value());

	vWin->setJoint(joint);
	int attachNum;
	vWin->attachedAO = joint->getOutboardLink()->getAttachment(attachNum);
	vWin->attachedLinkNum = attachNum;
	vWin->attachedStatic = joint->getOutboardLink()->getAttachmentStatic();
	vWin->updateGUI();

}

void AttachmentWindow::setattachments_cb(fltk::Widget* widget, void* data)
{
	AttachmentWindow* win = (AttachmentWindow*) data;

	win->getJoint()->getOutboardLink()->setAttachment(win->attachedAO, win->attachedLinkNum);
	win->getJoint()->getOutboardLink()->setAttachmentStatic(win->attachedStatic);

	if (widget == win->buttonSetAndClose)
	{
		Preference::setWindowPreference("ArticulatedObject.attachmentwindow", win);
		dance::writePreferences();
		win->hide();
	}

	dance::Refresh();
}

void AttachmentWindow::chooseskeletons_cb(fltk::Widget* widget, void* data)
{
	AttachmentWindow* win = (AttachmentWindow*) data;

	if (win->choiceSkeletons->value() > 0)
	{
		Widget* w = win->choiceSkeletons->child(win->choiceSkeletons->value());
		ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get((char*) w->label()));
		if (ao != NULL)
		{
			win->attachedAO = ao;
		}
		else
		{
			alert("Skeleton %s does not exist.", win->choiceSkeletons->label());
		}
	}
	win->updateGUI();
}

void AttachmentWindow::choosebodies_cb(fltk::Widget* widget, void* data)
{
	AttachmentWindow* win = (AttachmentWindow*) data;

	if (win->choiceBodies->value() > 0)
	{
 		win->attachedLinkNum = win->choiceBodies->value() - 1;
	}
	else
	{
		win->attachedLinkNum = -1;
	}
	win->updateGUI();
}

void AttachmentWindow::choosestatic_cb(fltk::Widget* widget, void* data)
{
	AttachmentWindow* win = (AttachmentWindow*) data;

	if (win->choiceStatic->value() > 0)
	{
		Widget* w = win->choiceStatic->child(win->choiceStatic->value());
		DGeometry* geom = dynamic_cast<DGeometry*>(dance::AllGeometry->get((char*) w->label()));
		if (geom != NULL)
		{
			win->attachedStatic = geom;
		}
		else
		{
			alert("Geometry %s does not exist.", win->choiceStatic->label());
		}
	}
	else
	{
			win->attachedStatic = NULL;
	}
	win->updateGUI();
}

