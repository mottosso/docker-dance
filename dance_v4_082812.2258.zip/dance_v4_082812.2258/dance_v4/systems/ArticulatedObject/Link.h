/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef	_LINK_H_
#define	_LINK_H_ 

#include "ArticulatedObject.h"
#include "DGeometry.h"

#define	DEF_MASS_DEN 1.0
#define MAX_BRANCHING 10 

#define MAXNUMSPHERES 20

/*
typedef struct InCollision
{
  char objectName[50];
  int linkNumber;
} Incollision;
*/

class Joint;
class InertiaTensor;

class DLLENTRY_AR Link
{
	public:
		Link(int ln) ;
		~Link() ;

		void DeleteChildren();
		void DeleteChildLink(Link *l);
		void RemoveChildJoint(Joint *wjoint);
		void Highlight(float r, float g, float b, float a);
		void displayAxes();

		void displayMonitorPoints();
		void displayMonitorPointsCollision();
		void displayMonitorPointsProp();

		BoundingBox	boundingBox;
		bool m_DisplayBoundingBox;

		bool isShowGeometryCollision();
		void setShowGeometryCollision(bool val);

		double m_transMat[4][4] ;	// the matrix that transforms a	point in link coordinates
		double m_invTransMat[4][4] ;	// the inverse of the above
		double m_prevWTransMat[4][4] ;  

		INLINE DGeometry* getGeometry();
		INLINE void setGeometry(DGeometry* g, bool updateDependencies = true);
		INLINE DGeometry *getGeometryCollision();
		INLINE void setGeometryCollision(DGeometry* g, bool updateDependencies = true );
		INLINE DGeometry *getGeometryProp();
		INLINE void setGeometryProp(DGeometry* g, bool updateDependencies = true );
		double* getGeometryScale();
		void setGeometryScale(double* scale);
		double* getGeometryCollisionScale();
		void setGeometryCollisionScale(double* val);
		double* getGeometryPropScale();
		void setGeometryPropScale(double* val);
		void getInvGeometryTransMat(double m[4][4]);
		void getInvGeometryCollisionTransMat(double	m[4][4]);
		void getInvGeometryPropTransMat(double	m[4][4]);
		void setInvGeometryTransMat(double m[4][4]);
		void setInvGeometryCollisionTransMat(double	m[4][4]);
		void setInvGeometryPropTransMat(double m[4][4]);

		INLINE int getNumber () { return m_linkNumber	;} ;
		INLINE int getNumChildLinks() { return m_numChildLinks ; } ;
		// INLINE int getNumChildJoints() { return m_numChildLinks ;} ;
		INLINE Link	**getChildLinks() { return &childLink[0] ; } ;
		INLINE Link	*getParentLink() { return parentLink ; } ;

		ArticulatedObject* getArticulatedObject();
		void setArticulatedObject(ArticulatedObject* ao);

	   
		void  getTransMat(double m[4][4]) ;
		void  getInvTransMat(double	m[4][4]) ;
		INLINE Joint *getParentJoint() { return parentJoint	; } ;
		void getEndEffectorWC(double p[3]);
		void setEndEffectorWC(double p[3]);
	   
		void getLocalCoord(double local[3], double world[3]);
		void getWorldCoord(double world[3], double local[3]);
		void getLocalCoordSim(double local[3], double world[3]);
		void getWorldNormal(double world[3], double local[3]);
		void getWorldVelocity(double worldvel[3], double local[3]);
		void getLocalVector(double local[3], double world[3])  ;

		void getWTransMatGeom(double transMat[4][4]) ;
		void getWTransMat(double tm[4][4]) ;
		void getWTransMat(float tm[4][4]) ; 

		INLINE void setMass(double m);
		INLINE double getMass();
		void setMoments(double moments[3]);
		void getMoments(double moments[3]);

		void Display(int mode=0) ;
		void displayTree(int mode) ;
		void changeToLocal() ;
		void changeToGlobal() ;
		void displayBoundingBox(float r=0.0, float g=1.0, float b=0.0, float a=1.0);
		BoundingBox	*calcBoundingBox(BoundingBox *)	;
		void getAxes(double	x[3], double y[3], double z[3]);
		void getCoordSystem(CoordSystem *cs);
		void setPosition(double p[3]) ;
		void getPosition(double p[3]) ;
		void getOrientation(float tm[4][4]);
		void getOrientation(double tm[4][4]);
		void setOrientation(int naxis, double v[3])	;
		void setOrientation(double tm[4][4]);
		void getRotation(double tm[3][3]);
		void getPoint(int index, int modifier, double *point);
		void setTransMat(double tm[4][4]) ;
		void setTransMat(CoordSystem cs);
		void setEndEffector(double* vec);
		void getEndEffector(double* vec);
	   
		void setCenterMass(Vector p) { VecCopy(m_cm,p);} ;
		void getCenterMass(Vector p) { VecCopy(p,m_cm);} ;
		void setParentLink(Link *l)	{ parentLink = l ;} ;
		void setParentJoint(Joint *pj) { parentJoint = pj ;}
		void incNumChildLinks(Link *child) {
			childLink[m_numChildLinks] = child;	m_numChildLinks++; } ;
		int	writeSdFile(FILE *fp) ;
		void WriteBVHFile(FILE *fp, int depth) ;
		Link *readSdfast(FILE *fp) ;
		void FitGeometryToLink(int argc, char **argv) ;

		int	Command(int argc, char **argv);
		void replaceGeometry(DGeometry* geomery, bool worldCoords);
		void replaceGeometryCollision(DGeometry* geomery, bool worldCoords);
		void replaceGeometryProp(DGeometry* geomery, bool worldCoords);

		int rotateGeometry(int argc, char **argv) ;

		int	assignMonitorPoints(Vector* points, int numPoints);
		int assignMonitorPoints(int numPoints, bool random = false);
		int	assignMonitorPointsCollision(Vector* points, int numPoints);
		int assignMonitorPointsCollision(int numPoints, bool random = false);
		int	assignMonitorPointsProp(Vector* points, int numPoints);
		int assignMonitorPointsProp(int numPoints, bool random = false);

		void GetRapidTriangle(int n, Vector v1, Vector v2, Vector v3) ;
		int getChildren();

		int	getMonitorPoints(Vector** pts);
		MonitorPoints* getMonitorPoints();
		INLINE int getNumMonitorPoints();
		INLINE int getNumMonitorPointsCollision();
		INLINE int getNumMonitorPointsProp();
		int	getMonitorPointsCollision(Vector** pts);
		int	getMonitorPointsProp(Vector** pts);
		MonitorPoints* getMonitorPointsCollision();
		MonitorPoints* getMonitorPointsProp();

		INLINE bool isDisplayMonitorPoints();
		INLINE void setDisplayMonitorPoints(bool val);

		bool m_DisplayGeometry ;
		INLINE double *getInerTensor() { return &m_InerTensor[0][0] ;} ;
		void getInerTensor(double tensor[3][3]);

		void setName(const char* name);
		const char* getName();

		void setTransparency(float val);
		float getTransparency();

		void setNumSpheres(int num);
		int getNumSpheres();
		void setSphereTranslation(int num, double x, double y, double z);
		void getSphereTranslation(int num, double& x, double& y, double& z);
		void setSphereScale(int num, double s);
		double getSphereScale(int num);
		void setSphereMatrix(int num);
		void getSphereMatrix(int num, double matrix[4][4]);

		void setExplicitMonitorPoints(bool val);
		bool isExplicitMonitorPoints();
		void setRandomMonitorPoints(bool val);
		bool isRandomMonitorPoints();
		void setExplicitMonitorPointsCollision(bool val);
		bool isExplicitMonitorPointsCollision();
		void setExplicitMonitorPointsProp(bool val);
		bool isExplicitMonitorPointsProp();
		void setRandomMonitorPointsCollision(bool val);
		bool isRandomMonitorPointsCollision();
		void setRandomMonitorPointsProp(bool val);
		bool isRandomMonitorPointsProp();

		void setRestitution(double val);
		double getRestitution();

		void copy(Link* link);

		/// Recursively accumulate the total inertia of this link and all of its child links.
		/// Result is total inertia stored in joint-local coordinates (ie, relative to pivot).
		/// (Total inertia is accumulated and stored in m_totalInertia)
		void accumTotalInertia( void );

		/// Returns the current total InertiaTensor, which was computed in the 
		/// last call to accumTotalInertia.
		/// Returns total inertia stored in joint-local coordinates (ie, relative to this joint's pivot).
		const InertiaTensor& getTotalInertiaTensor( void ) const;

		/// If set to true, will display equivalent spheroid volumes for the composite inertia tensor.
		void setIsShowingInertia( bool argVal );
		bool isShowingInertia( void ) const;

		double getParentCalculatedAngularAccel( Vector argAxis ) const;
		void resetParentCalculatedAngularAccel( void );
		void accumCalculatedAngularAccel( Vector argEstimatedOmegaDot );

		void setAttachment(ArticulatedObject* ao, int link, bool updateDependencies = true);
		ArticulatedObject* getAttachment(int& link);
		void setAttachmentStatic(DGeometry* geom, bool updateDependencies = true);
		DGeometry* getAttachmentStatic();

	private:
		int getMonitorPointsFromGeom();
		int getMonitorPointsFromGeomCollision();
		int getMonitorPointsFromGeomProp();
		void resetInbAndOutb(int flip = 0);

		// Mass properties.
		double m_Mass;				//< mass of link
		double m_InerTensor[3][3] ;	//< inertia tensor of link
		bool m_isShowingInertia;	//< if true, draw stippled ellipsoids representing the moments of inertia around the local axes.
		int m_InerTensorIsDiagonal;	

		InertiaTensor m_totalInertia; //< Accumulated inertia from this joint to the end effector

		Vector m_accumulatedAngularAccel; //< per-frame accumulated acceleration on this link due to parent torques.

		float m_Transparency;
		bool m_DisplayAxes;
		bool m_showGlobalAxes;

		bool m_DisplayNormals;
		ArticulatedObject* m_ao;
		double m_endEffector[3];	 // end	effector for link
		MonitorPoints m_monitorPoints; // Monitor points for link
		MonitorPoints m_monitorPointsCollision; // Monitor points for link's collision geometry
		MonitorPoints m_monitorPointsProp; // Monitor points for link's prop

		int	m_linkNumber ;		// holds the number of the links
		int	m_numChildLinks ;		// number of links attached to the end joint
		Link *parentLink ;		// pointer to the parent link (NULL if grounded	or free)
		Joint *parentJoint ;	// pointer to parent joint ( always not	null)
		Vector m_cm ;

		Link  *childLink[MAX_BRANCHING] ;		// holds the links that	follow this one
		bool m_displayMonitorPoints;

		DGeometry *m_geom ;
		double m_geomScale[3];
		bool m_geomFix;

		DGeometry *m_geomCollision ;
		double m_geomScaleCollision[3];
		bool m_geomFixCollision;

		DGeometry *m_geomProp;
		double m_geomScaleProp[3];
		bool m_geomFixProp;

		double m_invGeom[4][4];
		double m_invGeomCollision[4][4];
		double m_invGeomProp[4][4];
		bool m_showCollisionGeometry;
		char m_name[128];

		int m_numSpheres;
		double m_sphereMatrix[MAXNUMSPHERES][4][4];
		Vector m_sphereTranslation[MAXNUMSPHERES];
		double m_sphereScale[MAXNUMSPHERES];

		bool m_explicitMonitorPoints;
		bool m_randomMonitorPoints;
		bool m_explicitMonitorPointsCollision;
		bool m_randomMonitorPointsCollision;
		bool m_explicitMonitorPointsProp;
		bool m_randomMonitorPointsProp;

		double m_restitution;
		ArticulatedObject* m_attachment;
		int m_attachmentLinkNum;
		DGeometry* m_attachmentStatic;
} ;

#endif
