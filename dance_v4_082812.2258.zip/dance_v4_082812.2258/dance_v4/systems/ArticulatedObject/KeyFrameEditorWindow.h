/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef __KEYFRAME_EDITOR_WINDOW_H__
#define __KEYFRAME_EDITOR_WINDOW_H__

#include <fltk/Window.h>
#include <fltk/file_chooser.h>
#include <fltk/Group.h>
#include <fltk/Output.h>
#include <fltk/Button.h>
#include <fltk/CheckButton.h>
#include <fltk/FloatInput.h>
#include <fltk/draw.h>
#include "TimeSlider.h"
#include "RangeSlider.h"
#include "ArticulatedObjectWindow.h"
#include "CharacterAnimationSequence.h"
#include "ArticulatedObject.h"

class KeyFrameEditorWindow : public fltk::Window
{
	public:
		KeyFrameEditorWindow(ArticulatedObjectWindow *aWin, int x, int y, const char *l=0);

		ArticulatedObject *m_ao;
		CharacterAnimationSequence *m_animSeq;

		TimeSlider			*timeSlider;
		RangeSlider			*rangeSlider;
		fltk::Output		*numKeysOutput;
		fltk::Button		*homeButton;
		fltk::Button		*prevKeyButton;
		fltk::Button		*nextKeyButton;
		fltk::Button		*endButton;
		fltk::Button		*refreshButton;
		fltk::CheckButton	*displayButton;
		fltk::Button		*addButton;
		fltk::Button		*replaceButton;
		fltk::Button		*removeButton;
		fltk::Button		*removeAllButton;
		fltk::Button		*removeBeforeButton;
		fltk::Button		*removeAfterButton;

		void loadKeyframes();
		void updateGUI();
		void show();

		static void refresh_button_cb(fltk::Widget *o, void *p);
		static void timeSlider_cb(fltk::Widget *o, void *p);
		static void homeButton_button_cb(fltk::Widget *o, void *p);
		static void prevKeyButton_button_cb(fltk::Widget *o, void *p);
		static void nextKeyButton_button_cb(fltk::Widget *o, void *p);
		static void endButton_button_cb(fltk::Widget *o, void *p);
		static void displayButton_button_cb(fltk::Widget *o, void *p);
		static void addButton_button_cb(fltk::Widget *o, void *p);
		static void replaceButton_button_cb(fltk::Widget *o, void *p);
		static void removeButton_button_cb(fltk::Widget *o, void *p);
		static void removeLeft_button_cb(fltk::Widget *o, void *p);
		static void removeRight_button_cb(fltk::Widget *o, void *p);
		static void removeAllButton_button_cb(fltk::Widget *o, void *p);

	private:
		bool _updateDisplay;
};

#endif
