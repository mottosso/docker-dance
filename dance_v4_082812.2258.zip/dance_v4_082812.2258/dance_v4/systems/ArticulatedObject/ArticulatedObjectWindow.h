/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _ARTICULATEDOBJECTWINDOW_
#define _ARTICULATEDOBJECTWINDOW_

#include <fltk/Window.h>
#include "ArticulatedObject.h"

#include <fltk/Button.h>
#include <fltk/FileChooser.h>
#include <fltk/CheckButton.h>
#include <fltk/ValueInput.h>
#include <fltk/IntInput.h>
#include <fltk/ThumbWheel.h>
#include <fltk/Output.h>
#include <fltk/ValueSlider.h>
#include <fltk/ScrollGroup.h>
#include <fltk/LightButton.h>
#include "IKChainWindow.h"
#include "VelocityWindow.h"
#include "AttachmentWindow.h"
#include "AutomaticSettingsWindow.h"
#include "AutoLimitsWindow.h"

#define NEW_MODE 0
#define EDIT_MODE 1

class Joint;
class Link;
class EditWindow;
class KeyFrameEditorWindow;

class ArticulatedObjectWindow : public fltk::ScrollGroup
{
	public:
		ArticulatedObjectWindow(ArticulatedObject *ao, int x, int y, int w, int h, const char* name);
		~ArticulatedObjectWindow();

		void show();

		ArticulatedObject* getArtObj();
		void selectJoint(int jointNum);
		void setJointChoices(int jointNum);
		void updateJointState();
		void setIKChainChoices(int val=0);
		void updateGUI();

		int curSphereChosen;


		ArticulatedObject * m_artObj;

		fltk::Choice* m_jointList;

		fltk::ValueInput* inputRotate[3];
		fltk::ValueSlider* sliderRotate[3];
		int m_dofRotIndex[3];

		fltk::ValueInput *inputTranslate[3];
		fltk::ThumbWheel* thumbWheelTranslate[3];

		fltk::FloatInput* inputLimitLow[3];
		fltk::FloatInput* inputLimitHigh[3];

		fltk::Button* buttonPositionSaver;
		fltk::Button* buttonPositionLoader;
		fltk::Button* buttonVelocitySaver;
		fltk::Button* buttonVelocityLoader;
		fltk::Button* buttonAnimSaver;
		fltk::Button* buttonAnimLoader;
		fltk::Button* buttonZeroPosition;
		fltk::Button* buttonZeroJointPosition;
		fltk::Button* buttonNewJoint;
		fltk::Button* buttonEditJoint;
		fltk::Button* buttonShowVelocities;
		fltk::Button* buttonShowAttachments;
		fltk::Button* buttonLoadTopology;
		fltk::Button* buttonSaveTopology;
		fltk::Button* buttonAutoGeometry;
		fltk::Button* buttonAutoSpheres;

		fltk::CheckButton* checkDisplayMonitorPoints;
		fltk::CheckButton* checkDisplayAllMonitorPoints;
		fltk::CheckButton* checkDisplayLinks;
		fltk::CheckButton* checkDisplayJoints;
		fltk::CheckButton* checkDisplayBoundingBox;
		fltk::CheckButton* checkDisplayInertia;
		fltk::ValueSlider* sliderTransparency;
		
		fltk::CheckButton* checkShowGeometryCollision;
		fltk::CheckButton* checkShowAllGeometryCollision;
		fltk::Choice* choiceGeometry;
		fltk::Choice* choiceCollisionGeometry;
		fltk::Choice* choicePropGeometry;
		fltk::FloatInput* inputNumMonitorPoints;
		fltk::Button* buttonAssignMonitorPoints;

		fltk::CheckButton* checkShowSpheres;
		fltk::Choice* choiceSphere;
		fltk::ThumbWheel* thumbWheelSphereTranslate[3];
		fltk::ValueInput* inputSphereTranslate[3];
		fltk::ThumbWheel* thumbWheelSphereScale;
		fltk::ValueInput* inputSphereScale;
		fltk::Button* buttonAddSphere;
		fltk::Button* buttonRemoveSphere;
		fltk::Button* buttonLoadSphere;
		fltk::Button* buttonSaveSphere;
		fltk::Button* buttonSphereMaterial;

		fltk::FloatInput* inputMass;
		fltk::FloatInput* inputMoments[3];
		fltk::FloatInput* inputStiffness[3];
		fltk::FloatInput* inputDamping[3];
		fltk::FloatInput* inputRestitution;
		fltk::Button* buttonAllRestitution;
		fltk::Button* buttonAutomaticInertia;
		fltk::FloatInput* inputDensity;

		fltk::FloatInput* inputQuaternionAxis[3];
		fltk::FloatInput* inputQuaternionAngle;

		fltk::ThumbWheel* thumbWheelNumIterations;
		fltk::ValueInput* inputNumIterations;
		fltk::Choice* choiceChains;
		fltk::CheckButton* checkButtonShowTarget;
		fltk::CheckButton* checkButtonShowChain;
		fltk::Button* buttonAdd;
		fltk::Button* buttonEdit;
		fltk::Button* buttonRemove;
		fltk::LightButton* buttonActivateIK;
		fltk::Button* buttonKeyFrameEditor;
		fltk::Button* buttonAutoLimits;
		fltk::Output* outputJointDescription;

		IKChainWindow* windowIKChain;

		VelocityWindow* windowVelocity;
		AttachmentWindow* windowAttachments;

		EditWindow* windowEdit;
		EditWindow* windowNew;

		KeyFrameEditorWindow* windowKeyFrameEditor;
		AutomaticSettingsWindow* windowAutoSettings;
		AutomaticLimitsWindow* windowAutoLimits;

		fltk::CheckButton* checkRecord;
		fltk::CheckButton* checkPlayback;

	private:
		static void performplayback_cb(fltk::Widget* o, void* p);
		static void performrecord_cb(fltk::Widget* o, void* p);
		static void jointList_choice_cb(fltk::Widget* o, void* p);
		static void zeroposition_cb(fltk::Widget* o, void* p);
		static void zerojointposition_cb(fltk::Widget* o, void* p);
		static void jointedit_cb(fltk::Widget* o, void* p);
		static void jointnew_cb(fltk::Widget* o, void* p);
		static void velocities_cb(fltk::Widget* o, void* p);
		static void attachments_cb(fltk::Widget* o, void* p);
		static void geometry_choice_cb(fltk::Widget* o, void* p);
		static void geometryCollision_choice_cb(fltk::Widget* o, void* p);
		static void geometryProp_choice_cb(fltk::Widget* o, void* p);
		static void assign_monitor_points_cb(fltk::Widget* o, void* p);
		static void autogeometry_cb(fltk::Widget* o, void* p);
		static void autospheres_cb(fltk::Widget* o, void* p);
		static void autolimits_cb(fltk::Widget* o, void* p);

		static void activateEDIT_cb(fltk::Widget* o, void* p);

		static void inputRotateX_input_cb(fltk::Widget* o, void* p);
		static void sliderRotateX_slider_cb(fltk::Widget* o, void* p);
		static void inputRotateY_input_cb(fltk::Widget* o, void* p);
		static void sliderRotateY_slider_cb(fltk::Widget* o, void* p);
		static void inputRotateZ_input_cb(fltk::Widget* o, void* p);
		static void sliderRotateZ_slider_cb(fltk::Widget* o, void* p);
		static void limits_cb(fltk::Widget* o, void* p);

		static void inputQuaternion_input_cb(fltk::Widget* o, void* p);
		static void inputTranslate_input_cb(fltk::Widget* o, void* p);
		static void ThumbWheelTranslate_ThumbWheel_cb(fltk::Widget* o, void* p);

		static void toggleShowSpheres_cb(fltk::Widget* o, void* p);
		static void choiceSphere_cb(fltk::Widget* o, void* p);
		static void inputSphereTranslate_input_cb(fltk::Widget* o, void* p);
		static void thumbWheelSphereTranslate_cb(fltk::Widget* o, void* p);
		static void inputSphereScale_input_cb(fltk::Widget* o, void* p);
		static void thumbWheelSphereScale_cb(fltk::Widget* o, void* p);
		static void addSphere_cb(fltk::Widget* o, void* p);
		static void removeSphere_cb(fltk::Widget* o, void* p);
		static void loadSpheres_cb(fltk::Widget* o, void* p);
		static void saveSpheres_cb(fltk::Widget* o, void* p);
		static void sphereColor_cb(fltk::Widget* o, void* p);

		static void positionSaver_button_cb(fltk::Widget* o, void* p);
		static void positionLoader_button_cb(fltk::Widget* o, void* p);
		static void velocitySaver_button_cb(fltk::Widget* o, void* p);
		static void velocityLoader_button_cb(fltk::Widget* o, void* p);
		static void animSaver_button_cb(fltk::Widget* o, void* p);
		static void animLoader_button_cb(fltk::Widget* o, void* p);
		static void keyFrameEditor_button_cb(fltk::Widget* o, void *p);
		static void loadTopology_button_cb(fltk::Widget* o, void* p);
		static void saveTopology_button_cb(fltk::Widget* o, void* p);
		static void displaymonitorpoints_cb(fltk::Widget* o, void* p);
		static void displayallmonitorpoints_cb(fltk::Widget* o, void* p);
		static void displaylinks_cb(fltk::Widget* o, void* p);
		static void displayjoints_cb(fltk::Widget* o, void* p);
		static void displayboundingbox_cb(fltk::Widget* o, void* p);
		static void displayInertia_cb( fltk::Widget* o, void* p );
		static void transparency_cb(fltk::Widget* o, void* p);

		static void stiffdamp_cb(fltk::Widget* o, void* p);
		static void mass_cb(fltk::Widget* o, void* p);
		static void moments_cb(fltk::Widget* o, void* p);

		static void chainchoice_cb(fltk::Widget* o, void* p);
		static void addchain_cb(fltk::Widget* o, void* p);
		static void editchain_cb(fltk::Widget* o, void* p);
		static void removechain_cb(fltk::Widget* o, void* p);
		static void showTarget_cb(fltk::Widget* o, void *p);
		static void showChain_cb(fltk::Widget* o, void *p);
		static void activateIK_cb(fltk::Widget* o, void* p);
		static void inputNumIterations_cb(fltk::Widget* o, void* p);
		static void thumbWheelNumIterations_cb(fltk::Widget* o, void* p);

		static void showcollisiongeometry_cb(fltk::Widget* o, void* p);
		static void showallcollisiongeometry_cb(Widget* o, void* p);
		static void restitution_cb(fltk::Widget* o, void* p);
		static void automaticinertia_cb(fltk::Widget* o, void* p);
		static void restitutionall_cb(fltk::Widget* o, void* p);

		void setStateFromEulerAngles(int jointNum, double x, double y, double z);
		void setQuaternionValuesFromEulerAngles(double x, double y, double z, Quaternion* q);
		void translate(Joint* joint, double newpos[3]);
};

#endif
