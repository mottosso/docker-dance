/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "AutoLimitsWindow.h"
#include <fltk/ask.h>
#include <fltk/file_chooser.h>
#include "Cube.h"
#include "Sphere.h"
#include "dance.h"
#include "Link.h"
#include "Joint.h"
#include "ParserASFAMC.h"
#include "ParserBVH.h"

//#include "Model.h"

using namespace fltk;

AutomaticLimitsWindow::AutomaticLimitsWindow(ArticulatedObject* ao, int x, int y, int w, int h, const char* name) : Window(x, y, w, h, name)
{
	artObj = ao;

	this->begin();

	buttonOk = new Button(10, h - 40, 80, 20, "Ok");
	buttonOk->callback(OkButton, this);
	buttonCancel = new Button(w - 100, h - 40, 80, 20, "Cancel");
	buttonCancel->callback(CancelButton, this);

	browserFiles = new Browser(10, 20, 200, 140, "Files");

	buttonAddFile = new Button(10, 200, 80, 20, "Add File");
	buttonAddFile->callback(AddFile, this);

	buttonRemoveFile = new Button(120, 200, 80, 20, "Remove File");
	buttonRemoveFile->callback(RemoveFile, this);

	this->end();

	this->updateGUI();
}

void AutomaticLimitsWindow::updateGUI()
{
	browserFiles->clear();

	for (unsigned int x = 0; x < this->filenames.size(); x++)
	{
		browserFiles->add(this->filenames[x].c_str());
	}
}

void AutomaticLimitsWindow::OkButton(fltk::Widget *o, void *p)
{
	AutomaticLimitsWindow* win = (AutomaticLimitsWindow*) p;

	// remove the old values
	for (int x = win->limits.size() - 1; x >= 0; x--)
	{
		delete win->limits[x];
	}

	win->limits.clear();

	// loop through all the files
	for (unsigned int x = 0; x < win->filenames.size(); x++)
	{
		Character* character = NULL;
		std::ifstream file(win->filenames[x].c_str());
		character = ParserBVH::parse("templimitsloader", file);
		file.close();
		if (character != NULL)
		{
			for (int j = 0; j < character->getNumJoints(); j++)
			{
				CharJoint* cjoint = character->getJointByIndex(j);
				// find the jointlimits record with the same joint name
				JointLimits* curLim = NULL;
				for (unsigned int l = 0; l < win->limits.size(); l++)
				{
					if (strcmp(cjoint->getName(), win->limits[l]->jointName.c_str()) == 0)
					{
						curLim = win->limits[l];
					}
				}
				if (curLim == NULL)
				{
					curLim = new JointLimits();
					curLim->jointName = cjoint->getName();
					win->limits.push_back(curLim);
				}
				
				int numChannels = cjoint->getNumChannels();
				int channels[6];
				cjoint->getChannels(channels);
				if (numChannels > 3) // ignore 
					continue;

				for (int x = 0; x < numChannels; x++)
				{
					double low, high;
					cjoint->getLimitsFromData(x, low, high);
					if (curLim->min[x] > low)
						curLim->min[x] = low;
					if (curLim->max[x] < high)
						curLim->max[x] = high;
				}

			}
			delete character;
		}
		else
		{
			danceInterp::OutputMessage("Could not parse file '%s', skipping...", win->filenames[x].c_str());
		}
	}

	// ask if the joint limits are acceptable:
	std::string results = "The following limits have been found:\n";
	for (unsigned int x = 0; x < win->limits.size(); x++)
	{
		char buff[512];
		sprintf(buff, "%s: (%6.2f/%6.2f) (%6.2f/%6.2f) (%6.2f/%6.2f)\n", win->limits[x]->jointName.c_str(),
							win->limits[x]->min[0], win->limits[x]->max[0],
							win->limits[x]->min[1], win->limits[x]->max[1],
							win->limits[x]->min[2], win->limits[x]->max[2]);
		results.append(buff);
	}
	results.append("Ok to apply these limits?");
	int ret = fltk::ask(results.c_str());
	if (ret)
	{
		for (unsigned int x = 0; x < win->limits.size(); x++)
		{
			JointLimits* curLim = win->limits[x];
			Joint* joint = win->artObj->getJoint((char*) curLim->jointName.c_str());
			if (joint != NULL)
			{
				int numDOF = joint->getNumAxis();
				for (int i = 0; i < numDOF; i++)
					joint->setLimits(i, curLim->min[i], curLim->max[i]);
			}
			else
			{
				danceInterp::OutputMessage("No joint named %s found.", curLim->jointName.c_str());
			}
		}
		fltk::alert("Limits have been set.");
	}

	// remove the old values
	for (int x = win->limits.size() - 1; x >= 0; x--)
	{
		delete win->limits[x];
	}
	win->limits.clear();

	win->updateGUI();
	dance::AllViews->postRedisplay();
	win->hide();
}

void AutomaticLimitsWindow::CancelButton(fltk::Widget *o, void *p)
{
	AutomaticLimitsWindow* win = (AutomaticLimitsWindow*) p;
	
	win->hide();
}

void AutomaticLimitsWindow::AddFile(fltk::Widget *o, void *p)
{
	AutomaticLimitsWindow* win = (AutomaticLimitsWindow*) p;

	const char* fname = fltk::file_chooser("Choose a file to use for motion limits:", "{*.bvh}", NULL);
	char* newname = new char[2048];
	strcpy(newname, fname);
	if (fname != NULL)
	{
		win->filenames.push_back(newname);
	}

	win->updateGUI();
}

void AutomaticLimitsWindow::RemoveFile(fltk::Widget *o, void *p)
{
	AutomaticLimitsWindow* win = (AutomaticLimitsWindow*) p;

	int val = win->browserFiles->value();

	int count = 0;
	for (std::vector<std::string>::iterator iter = win->filenames.begin(); iter != win->filenames.end(); win++)
	{
		if (count == val)
		{
			win->filenames.erase(iter);
			break;
		}
	}
	win->updateGUI();
}

JointLimits::JointLimits()
{
	zeroVector(this->min);
	zeroVector(this->max);
}
