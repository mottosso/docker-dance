/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "VelocityWindow.h"
#include <fltk/Output.h>
#include <fltk/Input.h>
#include "ArticulatedObjectWindow.h"
#include "matrix3x3.h"
#include <fltk/ask.h>
#include "Preference.h"
#include "dance.h"

using namespace fltk;

VelocityWindow::VelocityWindow(ArticulatedObjectWindow* aowin, int w, int h, const char* name) : Window(w, h, name)
{
	artObjWin = aowin;

	this->begin();

	choiceJoints = new Choice(30, 10, 100, 20, "Joint");
	choiceJoints->callback(changejoint_cb, this);

	for (int x = 0; x < 6; x++)
	{
		outputVelocity[x] = new Output(20, 40 + (x * 30), 100, 20);
		outputVelocity[x]->color(fltk::GRAY75);
		inputInitVelocity[x] = new FloatInput(130, 40 + (x * 30), 100, 20); 
		inputInitVelocity[x]->callback(setvelocities_cb, this);
		currentVelocity[x] = new FloatInput(240, 40 + (x * 30), 100, 20); 
		currentVelocity[x]->callback(setvelocities_cb, this);
		currentVelocity[x]->deactivate();
		if (x == 0)
		{
			inputInitVelocity[x]->align(fltk::ALIGN_TOP);
			inputInitVelocity[x]->label("Initial");
			currentVelocity[x]->align(fltk::ALIGN_TOP);
			currentVelocity[x]->label("Current");
		}
	}

	buttonSetAndClose = new Button(20, this->h() - 30, 80, 20, "Set and Close");
	buttonSetAndClose->callback(setvelocities_cb, this);
	buttonSet = new Button(110, this->h() - 30, 50, 20, "Set");
	buttonSet->callback(setvelocities_cb, this);
	buttonCancel = new Button(this->w() - 80, this->h() - 30, 50, 20, "Cancel");
	buttonCancel->callback(cancel_cb, this);

	buttonResetAllVelocities = new Button(20, this->h() - 60, 100, 20, "Reset all velocities");
	buttonResetAllVelocities->callback(resetallvelocities_cb, this);
	
	this->end();

	this->setJoint(NULL);
}

void VelocityWindow::setJoint(Joint* j)
{
	joint = j;
	if (joint == NULL)
	{
		this->choiceJoints->value(0);
	}
	else
	{
		// select this joint in the choice joint
		int num = j->getOutboardLink()->getNumber();
		if (this->choiceJoints->value() != num)
			this->choiceJoints->value(num);
	}
}

Joint* VelocityWindow::getJoint()
{
	return joint;
}

void VelocityWindow::updateGUI()
{
	int num = choiceJoints->value();

	ArticulatedObject* ao = this->artObjWin->getArtObj();
	this->choiceJoints->clear();
	for (int x = 0; x < ao->getNumJoints(); x++)
	{
		Joint* curJoint = ao->getJoint(x);
		this->choiceJoints->add(curJoint->getName());
	}

	choiceJoints->value(num);

	if (joint != NULL)
	{

		int stateSize = joint->getStateSize();
		for (int x = 0; x < 6; x++)
		{
			if (x < stateSize)
			{
				outputVelocity[x]->show();
				inputInitVelocity[x]->show();
				currentVelocity[x]->show();

				int jointType = joint->getJointType();
				int order = joint->determineRotationOrder();
				switch (jointType)
				{
				case J_FREE:
					switch (order)
					{
					case Matrix3x3::XYZ:
						outputVelocity[0]->value("Linear Vel X");
						outputVelocity[1]->value("Linear Vel Y");
						outputVelocity[2]->value("Linear Vel Z");
						outputVelocity[3]->value("Angular Vel X");
						outputVelocity[4]->value("Angular Vel Y");
						outputVelocity[5]->value("Angular Vel Z");
						break;
					case Matrix3x3::XZY:
						outputVelocity[0]->value("Linear Vel X");
						outputVelocity[1]->value("Linear Vel Z");
						outputVelocity[2]->value("Linear Vel Y");
						outputVelocity[3]->value("Angular Vel X");
						outputVelocity[4]->value("Angular Vel Z");
						outputVelocity[5]->value("Angular Vel Y");
						break;
					case Matrix3x3::YXZ:
						outputVelocity[0]->value("Linear Vel Y");
						outputVelocity[1]->value("Linear Vel X");
						outputVelocity[2]->value("Linear Vel Z");
						outputVelocity[3]->value("Angular Vel Y");
						outputVelocity[4]->value("Angular Vel X");
						outputVelocity[5]->value("Angular Vel Z");
						break;
					case Matrix3x3::YZX:
						outputVelocity[0]->value("Linear Vel Y");
						outputVelocity[1]->value("Linear Vel Z");
						outputVelocity[2]->value("Linear Vel X");
						outputVelocity[3]->value("Angular Vel Y");
						outputVelocity[4]->value("Angular Vel Z");
						outputVelocity[5]->value("Angular Vel X");
						break;
					case Matrix3x3::ZXY:
						outputVelocity[0]->value("Linear Vel Z");
						outputVelocity[1]->value("Linear Vel X");
						outputVelocity[2]->value("Linear Vel Y");
						outputVelocity[3]->value("Angular Vel Z");
						outputVelocity[4]->value("Angular Vel X");
						outputVelocity[5]->value("Angular Vel Y");
						break;
					case Matrix3x3::ZYX:
						outputVelocity[0]->value("Linear Vel Z");
						outputVelocity[1]->value("Linear Vel Y");
						outputVelocity[2]->value("Linear Vel X");
						outputVelocity[3]->value("Angular Vel Z");
						outputVelocity[4]->value("Angular Vel Y");
						outputVelocity[5]->value("Angular Vel X");
						break;
					}

					inputInitVelocity[0]->value(this->joint->getInitDState(0));
					inputInitVelocity[1]->value(this->joint->getInitDState(1));
					inputInitVelocity[2]->value(this->joint->getInitDState(2));
					inputInitVelocity[3]->value(this->joint->getInitDState(3));
					inputInitVelocity[4]->value(this->joint->getInitDState(4));
					inputInitVelocity[5]->value(this->joint->getInitDState(5));

					currentVelocity[0]->value(this->joint->getDState(0));
					currentVelocity[1]->value(this->joint->getDState(1));
					currentVelocity[2]->value(this->joint->getDState(2));
					currentVelocity[3]->value(this->joint->getDState(3));
					currentVelocity[4]->value(this->joint->getDState(4));
					currentVelocity[5]->value(this->joint->getDState(5));

					break;
				case J_SLIDER:

					break;
				case J_PIN:
					switch (order)
					{
					case Matrix3x3::X:
						outputVelocity[0]->value("Angular Vel X");
						break;
					case Matrix3x3::Y:
						outputVelocity[0]->value("Angular Vel Y");
						break;
					case Matrix3x3::Z:
						outputVelocity[0]->value("Angular Vel Z");
						break;
					}

					inputInitVelocity[0]->value(this->joint->getInitDState(0));

					currentVelocity[0]->value(this->joint->getDState(0));
					break;
				case J_UNIVERSAL:
					switch (order)
					{
					case Matrix3x3::XY:
						outputVelocity[0]->value("Angular Vel X");
						outputVelocity[1]->value("Angular Vel Y");
						break;
					case Matrix3x3::XZ:
						outputVelocity[0]->value("Angular Vel X");
						outputVelocity[1]->value("Angular Vel Z");
						break;
					case Matrix3x3::YX:
						outputVelocity[0]->value("Angular Vel Y");
						outputVelocity[1]->value("Angular Vel X");
						break;
					case Matrix3x3::YZ:
						outputVelocity[0]->value("Angular Vel Y");
						outputVelocity[1]->value("Angular Vel Z");
						break;
					case Matrix3x3::ZX:
						outputVelocity[0]->value("Angular Vel Z");
						outputVelocity[1]->value("Angular Vel X");
						break;
					case Matrix3x3::ZY:
						outputVelocity[0]->value("Angular Vel Z");
						outputVelocity[1]->value("Angular Vel Y");
						break;
					}

					inputInitVelocity[0]->value(this->joint->getInitDState(0));
					inputInitVelocity[1]->value(this->joint->getInitDState(1));
					inputInitVelocity[2]->value(this->joint->getInitDState(0));
					inputInitVelocity[3]->value(this->joint->getInitDState(1));

					currentVelocity[0]->value(this->joint->getDState(0));
					currentVelocity[1]->value(this->joint->getDState(1));
					currentVelocity[2]->value(this->joint->getDState(0));
					currentVelocity[3]->value(this->joint->getDState(1));
					break;
				case J_BALL:
				case J_GIMBAL:
					switch (order)
					{
					case Matrix3x3::XYZ:
						outputVelocity[0]->value("Angular Vel X");
						outputVelocity[1]->value("Angular Vel Y");
						outputVelocity[2]->value("Angular Vel Z");
						break;
					case Matrix3x3::XZY:
						outputVelocity[0]->value("Angular Vel X");
						outputVelocity[1]->value("Angular Vel Z");
						outputVelocity[2]->value("Angular Vel Y");
						break;
					case Matrix3x3::YXZ:
						outputVelocity[0]->value("Angular Vel Y");
						outputVelocity[1]->value("Angular Vel X");
						outputVelocity[2]->value("Angular Vel Z");
						break;
					case Matrix3x3::YZX:
						outputVelocity[0]->value("Angular Vel Y");
						outputVelocity[1]->value("Angular Vel Z");
						outputVelocity[2]->value("Angular Vel X");
						break;
					case Matrix3x3::ZXY:
						outputVelocity[0]->value("Angular Vel Z");
						outputVelocity[1]->value("Angular Vel X");
						outputVelocity[2]->value("Angular Vel Y");
						break;
					case Matrix3x3::ZYX:
						outputVelocity[0]->value("Angular Vel Z");
						outputVelocity[1]->value("Angular Vel Y");
						outputVelocity[2]->value("Angular Vel X");
						break;
					}

					inputInitVelocity[0]->value(this->joint->getInitDState(0));
					inputInitVelocity[1]->value(this->joint->getInitDState(1));
					inputInitVelocity[2]->value(this->joint->getInitDState(2));

					currentVelocity[0]->value(this->joint->getDState(0));
					currentVelocity[1]->value(this->joint->getDState(1));
					currentVelocity[2]->value(this->joint->getDState(2));
					break;
				case J_PLANAR:
					switch (order)
					{
					case Matrix3x3::XYZ:
						outputVelocity[0]->value("Linear Vel X");
						outputVelocity[1]->value("Linear Vel Y");
						outputVelocity[2]->value("Angular Vel Z");
						break;
					case Matrix3x3::XZY:
						outputVelocity[0]->value("Linear Vel X");
						outputVelocity[1]->value("Linear Vel Z");
						outputVelocity[2]->value("Angular Vel Y");
						break;
					case Matrix3x3::YXZ:
						outputVelocity[0]->value("Linear Velocity Y");
						outputVelocity[1]->value("Linear Velocity X");
						outputVelocity[2]->value("Angular Velocity Z");
						break;
					case Matrix3x3::YZX:
						outputVelocity[0]->value("Linear Vel Y");
						outputVelocity[1]->value("Linear Vel Z");
						outputVelocity[2]->value("Angular Vel X");
						break;
					case Matrix3x3::ZXY:
						outputVelocity[0]->value("Linear Vel Z");
						outputVelocity[1]->value("Linear Vel X");
						outputVelocity[2]->value("Angular Vel Y");
						break;
					case Matrix3x3::ZYX:
						outputVelocity[0]->value("Linear Vel Z");
						outputVelocity[1]->value("Linear Vel Y");
						outputVelocity[2]->value("Angular Vel X");
						break;
					}

					inputInitVelocity[0]->value(this->joint->getInitDState(0));
					inputInitVelocity[1]->value(this->joint->getInitDState(1));
					inputInitVelocity[2]->value(this->joint->getInitDState(2));

					currentVelocity[0]->value(this->joint->getDState(0));
					currentVelocity[1]->value(this->joint->getDState(1));
					currentVelocity[2]->value(this->joint->getDState(2));
					break;
				}
			}
			else
			{
				outputVelocity[x]->hide();
				inputInitVelocity[x]->hide(); 
				currentVelocity[x]->hide(); 
			}

		}

	}
	else
	{
		for (int x = 0; x < 6; x++)
		{
			outputVelocity[x]->hide();
			inputInitVelocity[x]->hide(); 
			currentVelocity[x]->hide(); 
		}
	}
	this->redraw();
}

void VelocityWindow::show()
{
	this->updateGUI();
	Window::show();
}

void VelocityWindow::resetallvelocities_cb(fltk::Widget* widget, void* data)
{
	VelocityWindow* vWin = (VelocityWindow*) data;

	if (fltk::ask("Are you sure you want to\nreset all velocities to zero?"))
	{
		ArticulatedObject* ao = vWin->artObjWin->getArtObj();
		int numJoints = ao->getNumJoints();
		for (int j = 0; j < numJoints; j++)
		{
			Joint* joint = ao->getJoint(j);
			for (int s = 0; s < joint->getNumDof(); s++)
			{
				joint->setDState(s, 0);
			}
		}
		vWin->updateGUI();
	}
}


void VelocityWindow::setvelocities_cb(fltk::Widget* widget, void* data)
{
	VelocityWindow* vWin = (VelocityWindow*) data;


	Joint* joint = vWin->getJoint();

	int type = joint->getJointType();

	joint->setHasVelocity(true);

	switch (type)
	{
	case J_FREE:
		joint->setDState(0, vWin->currentVelocity[0]->fvalue());
		joint->setDState(1, vWin->currentVelocity[1]->fvalue());
		joint->setDState(2, vWin->currentVelocity[2]->fvalue());
		joint->setDState(3, vWin->currentVelocity[3]->fvalue());
		joint->setDState(4, vWin->currentVelocity[4]->fvalue());
		joint->setDState(5, vWin->currentVelocity[5]->fvalue());

		joint->setInitDState(0, vWin->inputInitVelocity[0]->fvalue());
		joint->setInitDState(1, vWin->inputInitVelocity[1]->fvalue());
		joint->setInitDState(2, vWin->inputInitVelocity[2]->fvalue());
		joint->setInitDState(3, vWin->inputInitVelocity[3]->fvalue());
		joint->setInitDState(4, vWin->inputInitVelocity[4]->fvalue());
		joint->setInitDState(5, vWin->inputInitVelocity[5]->fvalue());
		break;
	case J_UNIVERSAL:
		joint->setDState(0, vWin->currentVelocity[0]->fvalue());
		joint->setDState(1, vWin->currentVelocity[1]->fvalue());

		joint->setInitDState(0, vWin->inputInitVelocity[0]->fvalue());
		joint->setInitDState(1, vWin->inputInitVelocity[1]->fvalue());
		break;
	case J_GIMBAL:
	case J_BALL:
		joint->setDState(0, vWin->currentVelocity[0]->fvalue());
		joint->setDState(1, vWin->currentVelocity[1]->fvalue());
		joint->setDState(2, vWin->currentVelocity[2]->fvalue());

		joint->setInitDState(0, vWin->inputInitVelocity[0]->fvalue());
		joint->setInitDState(1, vWin->inputInitVelocity[1]->fvalue());
		joint->setInitDState(2, vWin->inputInitVelocity[2]->fvalue());
		break;
	case J_SLIDER:
		break;
	case J_PIN:
		joint->setDState(0, vWin->currentVelocity[0]->fvalue());

		joint->setInitDState(0, vWin->currentVelocity[0]->fvalue());
		break;
	case J_PLANAR:
		joint->setDState(0, vWin->currentVelocity[0]->fvalue());
		joint->setDState(1, vWin->currentVelocity[1]->fvalue());
		joint->setDState(2, vWin->currentVelocity[2]->fvalue());

		joint->setInitDState(0, vWin->inputInitVelocity[0]->fvalue());
		joint->setInitDState(1, vWin->inputInitVelocity[1]->fvalue());
		joint->setInitDState(2, vWin->inputInitVelocity[2]->fvalue());
		break;
	}

	if (widget == vWin->buttonSetAndClose)
	{
		Preference::setWindowPreference("ArticulatedObject.velocitywindow", vWin);
		dance::writePreferences();
		vWin->hide();
	}

}

void VelocityWindow::cancel_cb(fltk::Widget* widget, void* data)
{
	VelocityWindow* vWin = (VelocityWindow*) data;

	vWin->hide();
}

void VelocityWindow::changejoint_cb(fltk::Widget* widget, void* data)
{
	VelocityWindow* vWin = (VelocityWindow*) data;

	ArticulatedObject* ao = vWin->artObjWin->getArtObj();

	Joint* joint = ao->getJoint(vWin->choiceJoints->value());

	vWin->setJoint(joint);
	vWin->updateGUI();

}



