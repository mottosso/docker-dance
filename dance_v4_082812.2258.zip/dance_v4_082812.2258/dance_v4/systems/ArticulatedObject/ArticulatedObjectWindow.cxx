/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "ArticulatedObjectWindow.h"
#include "DSimulatorManager.h"
#include "dance.h"
#include "danceInterp.h"
#include "DObjectList.h"
#include "DObject.h"
#include "ViewManager.h"
#include "matrix3x3.h"
#include "Quaternion.h"
#include "DGeometry.h"
#include "DMaterialManagerWindow.h"
#include "DMaterialManager.h"
#include "RootWindow.h"
#include "Joint.h"
#include "Link.h"
#include "IKChain.h"
#include <fltk/file_chooser.h>
#include <fltk/ColorChooser.h>
#include <fltk/PackedGroup.h>
#include "EditWindow.h"
#include "KeyFrameEditorWindow.h"
#include <fltk/ask.h>
#include <fstream>
#include "ParserBVH.h"
#include "Cube.h"
#include "Sphere.h"
#include "Model.h"
#include "CompositeGeometry.h"
#include "AutomaticSettingsWindow.h"
#include "Preference.h"
#include "stuff.h"
#include "MomentOfInertiaHelper.h"
#include "CollapsibleGroup.h"

using namespace fltk;
using namespace std;

const double TORAD = M_PI/180.0 ;

ArticulatedObjectWindow::ArticulatedObjectWindow(ArticulatedObject* artObj, int x, int y, int w, int h, const char* name) : ScrollGroup(x, y, w, h, name)
{
	this->begin();

	m_artObj = artObj;

	checkDisplayLinks = new CheckButton(10, 10, 75, 20, "Show Links");
	checkDisplayLinks->callback(displaylinks_cb, this);
	checkDisplayLinks->value(0);

	checkDisplayJoints = new CheckButton(85, 10, 75, 20, "Show Joints");
	checkDisplayJoints->callback(displayjoints_cb, this);
	checkDisplayJoints->value(0);

	checkDisplayBoundingBox = new CheckButton(170, 10, 75, 20, "Show Active");
	checkDisplayBoundingBox->callback(displayboundingbox_cb, this);
	checkDisplayBoundingBox->value(1);

	checkDisplayInertia = new CheckButton(255, 10, 15, 20, "Inertia");
	checkDisplayInertia->callback(displayInertia_cb, this);
	checkDisplayInertia->value(0);

	buttonKeyFrameEditor = new Button(280, 10, 60, 20, "KeyFrame");
	buttonKeyFrameEditor->callback(keyFrameEditor_button_cb, this);

	/*m_stateSaver = new Button(10, 35, 70, 20, "Save State");
	m_stateSaver->callback(stateSaver_button_cb, this);*/

	buttonPositionSaver = new Button(10, 35, 70, 20, "Save Position");
	buttonPositionSaver->callback(positionSaver_button_cb, this);

	buttonPositionLoader = new Button(85, 35, 70, 20, "Load Position");
	buttonPositionLoader->callback(positionLoader_button_cb, this);

	buttonAnimSaver = new Button(195, 35, 70, 20, "Save Anim");
	buttonAnimSaver->callback(animSaver_button_cb, this);

	buttonAnimLoader = new Button(270, 35, 70, 20, "Load Anim");
	buttonAnimLoader->callback(animLoader_button_cb, this);

	buttonVelocitySaver = new Button(10, 65, 70, 20, "Save Velocity");
	buttonVelocitySaver->callback(velocitySaver_button_cb, this);

	buttonVelocityLoader = new Button(85, 65, 70, 20, "Load Velocity");
	buttonVelocityLoader->callback(velocityLoader_button_cb, this);

	buttonSaveTopology = new Button(195, 65, 70, 20, "Save Topology");
	buttonSaveTopology->callback(saveTopology_button_cb, this);

	buttonLoadTopology = new Button(270, 65, 70, 20, "Load Topology");
	buttonLoadTopology->callback(loadTopology_button_cb, this);

	checkRecord = new CheckButton(10, 90, 120, 20, "Record during simulation");
	checkRecord->callback(this->performrecord_cb, this);

	checkPlayback = new CheckButton(150, 90, 120, 20, "Perform playback");
	checkPlayback->callback(this->performplayback_cb, this);

	fltk::PackedGroup* packGroup = new PackedGroup(10, 120, 340, 700);
	packGroup->begin();

	CollapsibleGroup* groupTransforms = new CollapsibleGroup(0, 0, 340, 200, "Joint");
	groupTransforms->box(fltk::BORDER_BOX);
	groupTransforms->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupTransforms->begin();

		m_jointList = new Choice(40, 5, 100, 20);
	//	m_jointList = new Choice(40, 0, 150, 20);
		m_jointList->callback(jointList_choice_cb, this);
		m_jointList->box(BORDER_BOX);

		buttonNewJoint = new Button(150, 5, 40, 20, "New");
		buttonNewJoint->callback(jointnew_cb, this);

		buttonEditJoint = new Button(200, 5, 40, 20, "Edit");
		buttonEditJoint->callback(jointedit_cb, this);

		buttonZeroPosition = new Button(250, 5, 80, 15, "Zero All");
		buttonZeroPosition->callback(zeroposition_cb, this);

		buttonZeroJointPosition = new Button(250, 25, 80, 15, "Zero Joint");
		buttonZeroJointPosition->callback(zerojointposition_cb, this);

		outputJointDescription = new Output(40, 25, 120, 15);
		outputJointDescription->color(fltk::GRAY75);
		outputJointDescription->box(fltk::NO_BOX);
		outputJointDescription->value("");

		buttonShowVelocities = new Button(260, 130, 60, 20, "Velocities");
		buttonShowVelocities->callback(velocities_cb, this);

		buttonShowAttachments = new Button(260, 155, 60, 20, "Attachments");
		buttonShowAttachments->callback(attachments_cb, this);

		buttonAutoLimits = new Button(260, 180, 60, 15, "Auto Limits");
		buttonAutoLimits->callback(autolimits_cb, this);

		inputRotate[0] = new ValueInput(80, 45, 40, 20, "Rotate X:");
		inputRotate[0]->callback(inputRotateX_input_cb, this);
		inputRotate[0]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
		inputRotate[0]->deactivate();

		sliderRotate[0] = new ValueSlider(130, 45, 120, 20);
		sliderRotate[0]->callback(sliderRotateX_slider_cb, this);
	//	sliderRotate[0]->type(HOR_NICE_SLIDER);
		sliderRotate[0]->value(0.0);
		sliderRotate[0]->step(0.01);
		sliderRotate[0]->deactivate();

	//	Output* labelLimits = new Output(260, 25, 30, 20);
	//	labelLimits->value("Limits");
	//	labelLimits->color(GRAY75);

		inputLimitLow[0] = new FloatInput(260, 45, 30, 20);
		inputLimitLow[0]->callback(limits_cb, this);
		inputLimitLow[0]->deactivate();
		inputLimitHigh[0] = new FloatInput(300, 45, 30, 20);
		inputLimitHigh[0]->callback(limits_cb, this);
		inputLimitHigh[0]->deactivate();

		inputRotate[1] = new ValueInput(80, 70, 40, 20, "Rotate Y:");
		inputRotate[1]->callback(inputRotateY_input_cb, this);
		inputRotate[1]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
		inputRotate[1]->deactivate();

		sliderRotate[1] = new ValueSlider(130, 70, 120, 20);
		sliderRotate[1]->callback(sliderRotateY_slider_cb, this);
	//	sliderRotate[1]->type(HOR_NICE_SLIDER);
		sliderRotate[1]->value(0.0);
		sliderRotate[1]->step(0.01);
		sliderRotate[1]->deactivate();

		inputLimitLow[1] = new FloatInput(260, 70, 30, 20);
		inputLimitLow[1]->callback(limits_cb, this);
		inputLimitLow[1]->deactivate();
		inputLimitHigh[1] = new FloatInput(300, 70, 30, 20);
		inputLimitHigh[1]->callback(limits_cb, this);
		inputLimitHigh[1]->deactivate();

		inputRotate[2] = new ValueInput(80, 95, 40, 20, "Rotate Z:");
		inputRotate[2]->callback(inputRotateZ_input_cb, this);
		inputRotate[2]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
		inputRotate[2]->deactivate();

		sliderRotate[2] = new ValueSlider(130, 95, 120, 20);
		sliderRotate[2]->callback(sliderRotateZ_slider_cb, this);
	//	sliderRotate[2]->type(HOR_NICE_SLIDER);
		sliderRotate[2]->value(0.0);
		sliderRotate[2]->step(0.01);
		sliderRotate[2]->deactivate();

		inputLimitLow[2] = new FloatInput(260, 95, 30, 20);
		inputLimitLow[2]->callback(limits_cb, this);
		inputLimitLow[2]->deactivate();
		inputLimitHigh[2] = new FloatInput(300, 95, 30, 20);
		inputLimitHigh[2]->callback(limits_cb, this);
		inputLimitHigh[2]->deactivate();

		inputTranslate[0] = new ValueInput(80, 125, 80, 20, "Translate X:");
		inputTranslate[0]->callback(inputTranslate_input_cb, this);
		inputTranslate[0]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
		inputTranslate[0]->deactivate();

		thumbWheelTranslate[0] = new ThumbWheel(170, 125, 80, 20);
		thumbWheelTranslate[0]->callback(ThumbWheelTranslate_ThumbWheel_cb, this);
		thumbWheelTranslate[0]->value(0.0);
		thumbWheelTranslate[0]->step(0.01);
		thumbWheelTranslate[0]->deactivate();

		inputTranslate[1] = new ValueInput(80, 150, 80, 20, "Translate Y:");
		inputTranslate[1]->callback(inputTranslate_input_cb, this);
		inputTranslate[1]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
		inputTranslate[1]->deactivate();

		thumbWheelTranslate[1] = new ThumbWheel(170, 150, 80, 20);
		thumbWheelTranslate[1]->callback(ThumbWheelTranslate_ThumbWheel_cb, this);
		thumbWheelTranslate[1]->value(0.0);
		thumbWheelTranslate[1]->step(0.01);
		thumbWheelTranslate[1]->deactivate();

		inputTranslate[2] = new ValueInput(80, 175, 80, 20, "Translate Z:");
		inputTranslate[2]->callback(inputTranslate_input_cb, this);
		inputTranslate[2]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
		inputTranslate[2]->deactivate();

		thumbWheelTranslate[2] = new ThumbWheel(170, 175, 80, 20);
		thumbWheelTranslate[2]->callback(ThumbWheelTranslate_ThumbWheel_cb, this);
		thumbWheelTranslate[2]->value(0.0);
		thumbWheelTranslate[2]->step(0.01);
		thumbWheelTranslate[2]->deactivate();

		for (int q = 0; q < 3; q++)
		{
			inputQuaternionAxis[q] = new FloatInput(80, 125 + 25 * q, 50, 20, q == 0? "Quaternion 1:" : q == 1? "     2:" : "      3:");
			inputQuaternionAxis[q]->callback(inputQuaternion_input_cb, this);
			inputQuaternionAxis[q]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
			inputQuaternionAxis[q]->deactivate();
			inputQuaternionAxis[q]->hide();
		}

		inputQuaternionAngle = new FloatInput(200, 125, 50, 20, "4:");
		inputQuaternionAngle->callback(inputQuaternion_input_cb, this);
		inputQuaternionAngle->value(0.0);
		inputQuaternionAngle->deactivate();
		inputQuaternionAngle->hide();

		groupTransforms->end();

	CollapsibleGroup* groupIK = new CollapsibleGroup(0, 0, 340, 95, "Inverse Kinematics");
	groupIK->box(fltk::BORDER_BOX);
	groupIK->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupIK->begin();

		choiceChains = new Choice(55, 18, 150, 20, "IK Chains");
		choiceChains->callback(chainchoice_cb, this);

		buttonActivateIK = new LightButton(30, 41, 100, 20, "Use IK");//
		buttonActivateIK->callback(activateIK_cb, this);
		buttonActivateIK->selection_color(fltk::GREEN);
		buttonActivateIK->value(0);
		buttonActivateIK->deactivate();

		checkButtonShowTarget = new CheckButton(30, 60, 30, 15, "Show IK Target");//
		checkButtonShowTarget->callback(showTarget_cb, this);
		checkButtonShowTarget->value(0);
		checkButtonShowTarget->deactivate();

		checkButtonShowChain = new CheckButton(30, 75, 30, 15, "Show Active Chain");//
		checkButtonShowChain->callback(showChain_cb, this);
		checkButtonShowChain->value(0);
		checkButtonShowChain->activate();

		inputNumIterations = new ValueInput(195, 58, 40, 20, "Iterations");
		inputNumIterations->callback(inputNumIterations_cb, this);
		inputNumIterations->step(1.0);
		inputNumIterations->value(5);
		inputNumIterations->deactivate();

		buttonAdd = new Button(245, 20, 80, 20, "Create Chain");
		buttonAdd->callback(addchain_cb, this);

		buttonEdit = new Button(245, 45, 80, 20, "Edit Chain");
		buttonEdit->callback(editchain_cb, this);
		buttonEdit->deactivate();

		buttonRemove = new Button(245, 70, 80, 20, "Remove Chain");
		buttonRemove->callback(removechain_cb, this);
		buttonRemove->deactivate();

	groupIK->end();

	CollapsibleGroup* groupGeometry = new CollapsibleGroup(0, 0, 340, 95, "Geometry");
	groupGeometry->box(fltk::BORDER_BOX);
	groupGeometry->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupGeometry->begin();

		choiceGeometry = new Choice(45, 20, 120, 20, "Display");
		choiceGeometry->callback(geometry_choice_cb, this);
		choiceGeometry->box(BORDER_BOX);

		choiceCollisionGeometry = new Choice(210, 20, 120, 20, "Collision");
		choiceCollisionGeometry->callback(geometryCollision_choice_cb, this);
		choiceCollisionGeometry->box(BORDER_BOX);

		choicePropGeometry = new Choice(45, 45, 120, 20, "Prop");
		choicePropGeometry->callback(geometryProp_choice_cb, this);
		choicePropGeometry->box(BORDER_BOX);

		sliderTransparency = new ValueSlider(75, 70, 80, 20, "Transparency");
		sliderTransparency->align(ALIGN_LEFT);
		sliderTransparency->callback(transparency_cb, this);
	//	sliderTransparency->type(HOR_NICE_SLIDER);
		sliderTransparency->range(0.0, 1.0);
		sliderTransparency->value(0.0);
		sliderTransparency->step(0.01);

		checkShowGeometryCollision = new CheckButton(180, 45, 200, 20, "Show Collision Geometry");
		checkShowGeometryCollision->callback(showcollisiongeometry_cb, this);

		checkShowAllGeometryCollision = new CheckButton(180, 70, 200, 20, "Show All Collision Geometry");
		checkShowAllGeometryCollision->callback(showallcollisiongeometry_cb, this);

		buttonAutoGeometry = new Button(210, 5, 100, 15, "Automatic Geometry");
		buttonAutoGeometry->callback(autogeometry_cb, this);
		
	groupGeometry->end();

	CollapsibleGroup* groupPhysicalProps = new CollapsibleGroup(0, 0, 340, 90, "Physical Properties");
	groupPhysicalProps->box(fltk::BORDER_BOX);
	groupPhysicalProps->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupPhysicalProps->begin();

		inputMass = new FloatInput(50, 20, 40, 20, "Mass");
		inputMass->callback(mass_cb, this);
		for (int x = 0; x < 3; x++)
		{
			inputMoments[x] = new FloatInput(50 + 40 * x, 40, 40, 20);
			inputMoments[x]->callback(moments_cb, this);
		}
		inputMoments[0]->label("Moments");

		for (int x = 0; x < 3; x++)
		{
			inputStiffness[x] = new FloatInput(220 + 35 * x, 20, 40, 20);
			inputStiffness[x]->callback(stiffdamp_cb, this);
			inputDamping[x] = new FloatInput(220 + 35 * x, 40, 40, 20);
			inputDamping[x]->callback(stiffdamp_cb, this);
		}

		inputStiffness[0]->label("Stiffness");
		inputDamping[0]->label("Damping");

		inputRestitution = new FloatInput(60, 65, 40, 20, "Restitution");
		inputRestitution->callback(restitution_cb, this);

		buttonAllRestitution = new Button(90, 65, 40, 20, "Set All");
		buttonAllRestitution->callback(restitutionall_cb, this);

		inputDensity = new FloatInput(200, 65, 40, 20, "Density");
		inputDensity->value(1.0);

		buttonAutomaticInertia = new Button(250, 65, 70, 20, "Auto Inertia");
		buttonAutomaticInertia->callback(automaticinertia_cb, this);

	groupPhysicalProps->end();

	curSphereChosen = -1;

	CollapsibleGroup* groupSpheres = new CollapsibleGroup(0, 0, 340, 200, "Collision Spheres");
	groupSpheres->box(fltk::BORDER_BOX);
	groupSpheres->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupSpheres->begin();

		buttonAutoSpheres = new Button(170, 5, 150, 15, "Automatic Collision Spheres");
		buttonAutoSpheres->callback(autospheres_cb, this);

		choiceSphere = new Choice(70, 20, 60, 20, "Sphere Num");
		choiceSphere->callback(this->choiceSphere_cb, this);

		for (int x = 0; x < 3; x++)
		{
			thumbWheelSphereTranslate[x] = new ThumbWheel(240, 50 + 30 * x, 80, 20);
			thumbWheelSphereTranslate[x]->callback(thumbWheelSphereTranslate_cb, this);
			thumbWheelSphereTranslate[x]->step(.01);
			thumbWheelSphereTranslate[x]->range(MINFLOAT, MAXFLOAT);

			inputSphereTranslate[x] = new ValueInput(180, 50 + 30 * x, 50, 20, x == 0 ? "Translate X" : x == 1 ? "Translate Y" : "Translate Z");
			inputSphereTranslate[x]->callback(inputSphereTranslate_input_cb, this);
			inputSphereTranslate[x]->step(.01);
			inputSphereTranslate[x]->range(MINFLOAT, MAXFLOAT);
		}

		thumbWheelSphereScale = new ThumbWheel(240, 140, 80, 20);
		thumbWheelSphereScale->callback(thumbWheelSphereScale_cb, this);
		thumbWheelSphereScale->step(.01);
		thumbWheelSphereScale->range(0, MAXFLOAT);
		inputSphereScale = new ValueInput(180, 140, 50, 20, "Scale");
		inputSphereScale->callback(inputSphereScale_input_cb, this);
		inputSphereScale->range(0, MAXFLOAT);
		inputSphereScale->step(.01);

		buttonAddSphere = new Button(10, 80, 90, 20, "Add Sphere");
		buttonAddSphere->callback(addSphere_cb, this);
		buttonRemoveSphere = new Button(10, 110, 90, 20, "Remove Sphere");
		buttonRemoveSphere->callback(removeSphere_cb, this);

		checkShowSpheres = new CheckButton(150, 20, 90, 20, "Show Spheres");
		checkShowSpheres->callback(toggleShowSpheres_cb, this);

		buttonSphereMaterial = new Button(240, 20, 80, 20, "Sphere Material");
		buttonSphereMaterial->callback(sphereColor_cb, this);

		buttonLoadSphere = new Button(10, 170, 70, 20, "Load Spheres");
		buttonLoadSphere->callback(loadSpheres_cb, this);
		buttonSaveSphere = new Button(90, 170, 70, 20, "Save Spheres");
		buttonSaveSphere->callback(saveSpheres_cb, this);

	groupSpheres->end();

	CollapsibleGroup* groupCollisionPoints = new CollapsibleGroup(0, 0, 340, 70, "Collision Points");
	groupCollisionPoints->box(fltk::BORDER_BOX);
	groupCollisionPoints->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupCollisionPoints->begin();

		checkDisplayMonitorPoints = new CheckButton(10, 20, 30, 20, "Display Points");
		checkDisplayMonitorPoints->callback(displaymonitorpoints_cb, this);
		checkDisplayMonitorPoints->value(0);
		checkDisplayMonitorPoints->deactivate();

		checkDisplayAllMonitorPoints = new CheckButton(10, 45, 30, 20, "Display All Points");
		checkDisplayAllMonitorPoints->callback(displayallmonitorpoints_cb, this);
		checkDisplayAllMonitorPoints->value(0);

		inputNumMonitorPoints = new FloatInput(180, 20, 40, 20, "Num Points");

		buttonAssignMonitorPoints = new Button(240, 20, 80, 20, "Assign Points");
		buttonAssignMonitorPoints->callback(assign_monitor_points_cb, this);

	groupCollisionPoints->end();


	packGroup->end();

	windowVelocity = new VelocityWindow(this, 350, 300, "Set Velocities");
	windowVelocity->hide();

	windowAttachments = new AttachmentWindow(this, 250, 330, "Attachments");
	windowAttachments->hide();

	windowEdit = new EditWindow(this->m_artObj, 100, 200, 280, 430, "Edit", EDIT_MODE);
	windowEdit->hide();

	windowNew = new EditWindow(this->m_artObj, 100, 200, 280, 430, "New", NEW_MODE);
	windowNew->hide();

	this->end();

	this->updateGUI();

	windowKeyFrameEditor = new KeyFrameEditorWindow(this, 150, 150, "KeyFrame Editor");
	windowKeyFrameEditor->hide();

	windowIKChain = new IKChainWindow(this, 250, 250, 450, 400, "IK Chains");
	windowIKChain->hide();

	windowAutoSettings = new AutomaticSettingsWindow(this->getArtObj(), 20, 20, 300, 300, "Automatic Geometry Settings");
	windowAutoSettings->hide();

	windowAutoLimits = new AutomaticLimitsWindow(this->getArtObj(), 20, 20, 300, 300, "Automatic Joint Limits");
	windowAutoLimits->hide();

}

ArticulatedObjectWindow::~ArticulatedObjectWindow()
{
	delete windowVelocity;
	delete windowAttachments;
    delete windowEdit;
	delete windowNew;

	delete windowIKChain;
	delete windowKeyFrameEditor;
	delete windowAutoSettings;
	delete windowAutoLimits;
}

void ArticulatedObjectWindow::show()
{
	updateGUI();
	ScrollGroup::show();
}


void ArticulatedObjectWindow::updateGUI()
{
	// retain the old joint choice
	int jointValue = this->m_jointList->value();

	int jointNum = jointValue - 1;

	if (jointNum >= this->m_artObj->getNumJoints())
		jointNum = this->m_artObj->getNumJoints() - 1;

	this->setJointChoices(jointNum);

	if (this->m_artObj->isRecording())
		this->checkRecord->value(true);
	else
		this->checkRecord->value(false);

	if (this->m_artObj->isPlayback())
		this->checkPlayback->value(true);
	else
		this->checkPlayback->value(false);

	this->checkShowAllGeometryCollision->value(this->m_artObj->isShowingCollisionGeometry());

	Link* link = NULL;
	if (jointNum >= 0 && !this->m_artObj->isEditMode())
	{
		Joint* joint = this->m_artObj->getJoint(jointNum);
		int numAxes = joint->getNumAxis();
		link = this->m_artObj->getLink(jointNum);
		string descr = "";
		int jointType = joint->getJointType();
		switch (jointType)
		{
		case J_FREE:
			descr.append("Free ");
			break;
		case J_PLANAR:
			descr.append("Planar ");
			break;
		case J_GIMBAL:
			descr.append("Gimbal ");
			break;
		case J_BALL:
			descr.append("Ball ");
			break;
		case J_UNIVERSAL:
			descr.append("Universal ");
			break;
		case J_PIN:
			descr.append("Pin ");
			break;
		case J_WELD:
			descr.append("Weld ");
			break;
		}
		int order = joint->determineRotationOrder();
		if (jointType == J_PIN)
		{
			switch (order)
			{
			case Matrix3x3::X:
				descr.append("X");
				break;
			case Matrix3x3::Y:
				descr.append("Y");
				break;
			case Matrix3x3::Z:
				descr.append("Z");
				break;
			}
		}
		else
		{
			switch (order)
			{
			case Matrix3x3::XYZ:
				descr.append("XYZ");
				break;
			case Matrix3x3::XZY:
				descr.append("XZY");
				break;
			case Matrix3x3::YXZ:
				descr.append("YXZ");
				break;
			case Matrix3x3::YZX:
				descr.append("YZX");
				break;
			case Matrix3x3::ZXY:
				descr.append("ZXY");
				break;
			case Matrix3x3::ZYX:
				descr.append("ZYX");
				break;
			case Matrix3x3::XY:
				descr.append("XY");
				break;
			case Matrix3x3::XZ:
				descr.append("XZ");
				break;
			case Matrix3x3::YX:
				descr.append("YX");
				break;
			case Matrix3x3::YZ:
				descr.append("YZ");
				break;
			case Matrix3x3::ZX:
				descr.append("ZX");
				break;
			case Matrix3x3::ZY:
				descr.append("ZY");
				break;
			}
		}
		outputJointDescription->activate();
		outputJointDescription->value(descr.c_str());

		this->checkDisplayMonitorPoints->activate();
		this->checkShowGeometryCollision->activate();
		this->choiceGeometry->activate();
		this->choiceCollisionGeometry->activate();
		this->choicePropGeometry->activate();
		this->inputNumMonitorPoints->activate();
		this->buttonAssignMonitorPoints->activate();
		this->inputNumMonitorPoints->activate();
		this->buttonLoadSphere->activate();
		this->sliderTransparency->activate();
		this->inputMass->activate();
		this->inputRestitution->activate();
		this->buttonAutomaticInertia->activate();
		this->inputDensity->activate();
		this->buttonAllRestitution->activate();
		for (int x = 0; x < 3; x++)
		{
			this->inputMoments[x]->activate();
			this->inputLimitLow[x]->activate();
			this->inputLimitHigh[x]->activate();
			if (x < numAxes || joint->getJointType() == J_BALL)
			{
				this->inputStiffness[x]->value(joint->getStiffness(x));
				this->inputDamping[x]->value(joint->getDamping(x));
				this->inputStiffness[x]->activate();
				this->inputStiffness[x]->show();
				this->inputDamping[x]->activate();
				this->inputDamping[x]->show();
			}
			else
			{
				this->inputStiffness[x]->deactivate();
				this->inputStiffness[x]->hide();
				this->inputDamping[x]->deactivate();
				this->inputDamping[x]->hide();
			}
		}
		

		this->inputNumMonitorPoints->value(link->getMonitorPoints()->m_NumPoints);

		this->checkDisplayMonitorPoints->value(link->isDisplayMonitorPoints() == true ? 1 : 0);
		this->checkShowGeometryCollision->value(link->isShowGeometryCollision() == true ? 1 : 0);
		// mass and moments
		this->inputMass->value(link->getMass());
		Vector moments;
		link->getMoments(moments);
		for (int x = 0; x < 3; x++)
			this->inputMoments[x]->value(moments[x]);
		this->inputRestitution->value(link->getRestitution());
		double axes[3][3];
		joint->getAxis(axes);
		double low, high;
		if (joint->getJointType() == J_BALL)
		{
			numAxes = 3;
			// set the XYZ values to the quaternion values
			Quaternion q(joint->getState(0), joint->getState(1), joint->getState(2), joint->getState(3));
			this->inputQuaternionAngle->value(q.data()[3]);
			Matrix3x3 matrix;
			q.toMatrix(matrix);
			VectorObj angles;
			matrix.matToEuler(Matrix3x3::XYZ, angles, true);
			this->inputQuaternionAngle->show();
			this->inputQuaternionAngle->activate();
			this->inputQuaternionAngle->value(q[3]);
			for (int x = 0; x < 3; x++)
			{
				this->inputQuaternionAxis[x]->show();
				this->inputQuaternionAxis[x]->activate();
				this->inputQuaternionAxis[x]->value(q.data()[x]);

				this->inputRotate[x]->value(angles[x] * 180.0 / M_PI);
				this->sliderRotate[x]->value(angles[x] * 180.0 / M_PI);

				this->inputTranslate[x]->deactivate();
				this->inputTranslate[x]->hide();
				this->thumbWheelTranslate[x]->deactivate();
				this->thumbWheelTranslate[x]->hide();
			}
			
		}
		else
		{
			for (int x = 0; x < 3; x++)
			{
				this->inputQuaternionAxis[x]->hide();
				this->inputQuaternionAxis[x]->deactivate();
				this->inputQuaternionAngle->hide();
				this->inputQuaternionAngle->deactivate();

				if (joint->getJointType() == J_SLIDER || joint->getJointType() == J_FREE || joint->getJointType() == J_PLANAR)
				{
					this->inputTranslate[x]->activate();
					this->inputTranslate[x]->show();
					this->thumbWheelTranslate[x]->activate();
					this->thumbWheelTranslate[x]->show();
				}
				else
				{
					this->inputTranslate[x]->deactivate();
					this->inputTranslate[x]->show();
					this->thumbWheelTranslate[x]->deactivate();
					this->thumbWheelTranslate[x]->show();
				}
			}
		}

		for (int x = 0; x < 3; x++)
		{
			this->inputLimitLow[x]->deactivate();
			this->inputLimitHigh[x]->deactivate();
		}

		for (int x = 0; x < numAxes; x++)
		{
			if (axes[x][0] == 1.0 && axes[x][1] == 0.0 && axes[x][2] == 0.0)
			{
				joint->getLimits(x, &low, &high);
				this->inputLimitLow[0]->value(low);
				this->inputLimitHigh[0]->value(high);
				this->inputLimitLow[0]->activate();
				this->inputLimitHigh[0]->activate();
			}
			else if (axes[x][0] == 0.0 && axes[x][1] == 1.0 && axes[x][2] == 0.0)
			{
				joint->getLimits(x, &low, &high);
				this->inputLimitLow[1]->value(low);
				this->inputLimitHigh[1]->value(high);
				this->inputLimitLow[1]->activate();
				this->inputLimitHigh[1]->activate();
			}
			else if (axes[x][0] == 0.0 && axes[x][1] == 0.0 && axes[x][2] == 1.0)
			{
				joint->getLimits(x, &low, &high);
				this->inputLimitLow[2]->value(low);
				this->inputLimitHigh[2]->value(high);
				this->inputLimitLow[2]->activate();
				this->inputLimitHigh[2]->activate();
			}
		}
		this->buttonShowVelocities->activate();

		// change the active link
		if (!this->windowNew->visible())
		{
			this->m_artObj->setActiveJoint(joint);
			this->m_artObj->setActiveLink(joint->getOutboardLink());
		}
		this->buttonEditJoint->activate();
		this->buttonNewJoint->activate();
	}
	else
	{
		this->checkShowGeometryCollision->deactivate();
		this->checkDisplayMonitorPoints->deactivate();
		this->choiceGeometry->deactivate();
		this->outputJointDescription->deactivate();
		this->outputJointDescription->value("");

		this->choiceCollisionGeometry->deactivate();
		this->choicePropGeometry->deactivate();
		this->inputNumMonitorPoints->deactivate();
		this->buttonAssignMonitorPoints->deactivate();
		this->inputNumMonitorPoints->deactivate();
		this->buttonLoadSphere->activate();
		this->sliderTransparency->deactivate();
		this->inputMass->deactivate();
		for (int x = 0; x < 3; x++)
		{
			this->inputMoments[x]->deactivate();
			this->inputLimitLow[x]->deactivate();
			this->inputLimitHigh[x]->deactivate();
			this->inputStiffness[x]->deactivate();
			this->inputDamping[x]->deactivate();
		}
		this->inputRestitution->deactivate();
		this->buttonAutomaticInertia->deactivate();
		this->inputDensity->deactivate();
		this->buttonAllRestitution->deactivate();
		if (this->m_artObj->getNumJoints() == 0)
			this->buttonShowVelocities->deactivate();
		else
			this->buttonShowVelocities->activate(); // always show this
		// change the active link
		if (!this->windowNew->visible())
		{
			this->m_artObj->setActiveJoint(NULL);
			this->m_artObj->setActiveLink(NULL);
		}
		this->buttonEditJoint->deactivate();
		// disable new button if no joint is selected
		// and at least one link/joint has already been created
		if (this->m_artObj->getNumJoints() > 0 && this->m_artObj->getActiveJoint() == NULL)
		{
			this->buttonNewJoint->deactivate();
		}
		else
		{
			this->buttonNewJoint->activate();
		}
	}

	this->checkDisplayJoints->value(this->m_artObj->isShowingJoints() == true ? 1 : 0);
	this->checkDisplayLinks->value(this->m_artObj->isShowingLinks() == true ? 1 : 0);

	// update the geometry & collision geometry choices
	this->choiceGeometry->clear();
	this->choiceCollisionGeometry->clear();
	this->choicePropGeometry->clear();

	this->choiceGeometry->add("No geometry");
	this->choiceCollisionGeometry->add("No geometry");
	this->choicePropGeometry->add("No prop");

	int numGeometries = dance::AllGeometry->size();
	this->choiceGeometry->value(0);
	this->choiceCollisionGeometry->value(0);
	this->choicePropGeometry->value(0);

	if (link != NULL)
	{
		for (int x = 0; x < numGeometries; x++)
		{
			DGeometry* geometry = (DGeometry*) dance::AllGeometry->get(x);

			// make sure that this geometry is not part of any link of any articulated object
			bool found = false;
			for (int s = 0; s < dance::AllSystems->size(); s++)
			{
				DSystem* sys = (DSystem*) dance::AllSystems->get(s);
				if (strcmp(sys->getType(), "ArticulatedObject") == 0)
				{
					ArticulatedObject* ao = (ArticulatedObject*) sys;
					Link** links = ao->getLinks();
					int numLinks = ao->getNumLinks();
					for (int l = 0; l < numLinks; l++)
					{
						if (links[l]->getGeometry() == geometry || links[l]->getGeometryCollision()== geometry)
						{
							found = true;
							break;
						}
					}
					if (found)
						break;
				}
			}
			// make sure that geometry isn't part of a composite geometry
			for (int c = 0; c < dance::AllGeometry->size(); c++)
			{
				CompositeGeometry* cgeometry = dynamic_cast<CompositeGeometry*>(dance::AllGeometry->get(c));
				if (cgeometry != NULL)
				{
					for (int a = 0; a < cgeometry->getNumGeometries(); a++)
					{
						if (cgeometry->getGeometry(a) == geometry)
						{
							found = true;
							break;
						}
					}
				}
				if (found)
					break;
			}

			if (link->getGeometry() == geometry)
			{
				this->choiceGeometry->add(geometry->getName());
				this->choiceGeometry->value(this->choiceGeometry->size() - 1);
			}
			else if (link->getGeometryCollision() == geometry)
			{
				this->choiceCollisionGeometry->add(geometry->getName());
				this->choiceCollisionGeometry->value(this->choiceCollisionGeometry->size() - 1);
			}
			else if (link->getGeometryProp() == geometry)
			{
				this->choicePropGeometry->add(geometry->getName());
				this->choicePropGeometry->value(this->choicePropGeometry->size() - 1);
			}
			else if (!found)
			{
				this->choiceGeometry->add(geometry->getName());
				this->choiceCollisionGeometry->add(geometry->getName());
				this->choicePropGeometry->add(geometry->getName());
			}
		}
	}

	// sphere info
	if (link != NULL)
	{
		if (link->getNumSpheres() > 0)
		{
			choiceSphere->clear();
			choiceSphere->activate();
			choiceSphere->add("--Choose Sphere--");
			for (int x = 0; x < link->getNumSpheres(); x++)
			{
				char buff[10];
				sprintf(buff, "%d", x + 1);
				choiceSphere->add(buff);
			}
			if (link->getNumSpheres() == MAXNUMSPHERES)
				buttonAddSphere->deactivate();
			if (curSphereChosen >= 0)
			{
				choiceSphere->value(curSphereChosen + 1);
				// place the sphere values in the appropriate widgets
				Vector sphereTrans;
				link->getSphereTranslation(curSphereChosen, sphereTrans[0], sphereTrans[1], sphereTrans[2]);
				for (int x = 0; x < 3; x++)
				{
					this->inputSphereTranslate[x]->value(sphereTrans[x]);
					inputSphereTranslate[x]->activate();
					this->thumbWheelSphereTranslate[x]->value(sphereTrans[x]);
					thumbWheelSphereTranslate[x]->activate();
				}
				double scale = link->getSphereScale(curSphereChosen);
				this->inputSphereScale->value(scale);
				this->inputSphereScale->activate();
				this->thumbWheelSphereScale->value(scale);
				this->thumbWheelSphereScale->activate();
				this->buttonRemoveSphere->activate();
			}
			else
			{
				for (int x = 0; x < 3; x++)
				{
					thumbWheelSphereTranslate[x]->deactivate();
					inputSphereTranslate[x]->deactivate();
					thumbWheelSphereScale->deactivate();
					inputSphereScale->deactivate();
				}
				buttonRemoveSphere->deactivate();
				if (link->getNumSpheres() < MAXNUMSPHERES)
					buttonAddSphere->activate();
				else
					buttonAddSphere->deactivate();
			}
		}
		else
		{
			choiceSphere->clear();
			choiceSphere->add("--No spheres--");
			choiceSphere->deactivate();
			for (int x = 0; x < 3; x++)
			{
				thumbWheelSphereTranslate[x]->deactivate();
				inputSphereTranslate[x]->deactivate();
				thumbWheelSphereScale->deactivate();
				inputSphereScale->deactivate();
			}
			buttonRemoveSphere->deactivate();
			buttonAddSphere->activate();
		}
	}
	else // no link chosen
	{
			choiceSphere->clear();
			choiceSphere->add("--Choose a joint--");
			choiceSphere->deactivate();
			for (int x = 0; x < 3; x++)
			{
				thumbWheelSphereTranslate[x]->deactivate();
				inputSphereTranslate[x]->deactivate();

				thumbWheelSphereScale->deactivate();
				inputSphereScale->deactivate();
			}
			buttonRemoveSphere->deactivate();
			buttonAddSphere->deactivate();
	}

	if (this->getArtObj()->isShowingSpheres())
		this->checkShowSpheres->value(1);
	else
		this->checkShowSpheres->value(0);


	// is ik mode enabled?
	if(this->getArtObj()->getInteractionMode() == IK_mode)
	{
		checkButtonShowTarget->activate();
		buttonActivateIK->value(true);
		//derek added
		inputNumIterations->activate();
	}
	else
	{
		checkButtonShowTarget->deactivate();
		buttonActivateIK->value(false);
		//derek added
		inputNumIterations->deactivate();
	}

	if(this->getArtObj()->isShowActiveIKChain())
		this->checkButtonShowChain->value(true);
	else
		this->checkButtonShowChain->value(false);

	if(this->getArtObj()->isShowActiveIKTarget())
		this->checkButtonShowTarget->value(true);
	else
		this->checkButtonShowTarget->value(false);

	// which ik chain is selected?
	int ikChainNum = this->getArtObj()->getActiveIKChain();
	setIKChainChoices(ikChainNum + 1);
	if(ikChainNum >= 0)
	{
		checkButtonShowChain->activate();
		buttonActivateIK->activate();
		buttonEdit->activate();
		buttonRemove->activate();
		inputNumIterations->activate();
		inputNumIterations->value(this->getArtObj()->getIKChain(ikChainNum)->getIKNumIterations());
	}
	else
	{
		checkButtonShowChain->deactivate();
		checkButtonShowTarget->deactivate();
		buttonActivateIK->deactivate();
		buttonEdit->deactivate();
		buttonRemove->deactivate();
		inputNumIterations->deactivate();
	}
}



void ArticulatedObjectWindow::setJointChoices(int num)
{
	if (m_artObj == NULL)
	{
		return;
	}

	m_jointList->clear();
	m_jointList->add("Choose a joint");

	Joint **joints = m_artObj->getJoints();
	int numJoints = m_artObj->m_numJoints;

	for (int j = 0; j < numJoints; j++)
	{
		m_jointList->add(joints[j]->getName());
	}

	m_jointList->value(num + 1);
	updateJointState();
}

void ArticulatedObjectWindow::updateJointState()
{
	int joint = (this->m_jointList->value()) - 1;

	this->inputRotate[0]->value(0);
	this->inputRotate[0]->deactivate();
	this->sliderRotate[0]->value(0);
	this->sliderRotate[0]->deactivate();

	this->inputRotate[1]->value(0);
	this->inputRotate[1]->deactivate();
	this->sliderRotate[1]->value(0);
	this->sliderRotate[1]->deactivate();

	this->inputRotate[2]->value(0);
	this->inputRotate[2]->deactivate();
	this->sliderRotate[2]->value(0);
	this->sliderRotate[2]->deactivate();

	this->inputTranslate[0]->value(0);
	this->inputTranslate[0]->deactivate();
	this->thumbWheelTranslate[0]->value(0);
	this->thumbWheelTranslate[0]->deactivate();

	this->inputTranslate[1]->value(0);
	this->inputTranslate[1]->deactivate();
	this->thumbWheelTranslate[1]->value(0);
	this->thumbWheelTranslate[1]->deactivate();

	this->inputTranslate[2]->value(0);
	this->inputTranslate[2]->deactivate();
	this->thumbWheelTranslate[2]->value(0);
	this->thumbWheelTranslate[2]->deactivate();

	// no joints were selected
	if (joint == -1)
	{
		//this->updateGUI();
		return;
	}

	Joint **joints = this->m_artObj->getJoints();

	double axis[3][3];
	int numaxis = joints[joint]->getAxis(axis);
	if (joints[joint]->getJointType() == J_BALL)
		numaxis = 3;

	int dofOffset = 0;

	// handle any translational components
	int order = joints[joint]->determineRotationOrder();
	int jointType = joints[joint]->getJointType();
	if (joint == 0)
	{
		double jpos[3];
		joints[joint]->getPosition(jpos);

		bool useX = false;
		bool useY = false;
		bool useZ = false;

		switch (jointType)
		{
		case J_FREE:
			useX = true;
			useY = true;
			useZ = true;
			break;
		case J_PLANAR:
			// first two axes are the translational ones
			if (order == Matrix3x3::XYZ || order == Matrix3x3::YXZ)
			{
				useX = true;
				useY = true;
			}
			else if (order == Matrix3x3::XZY || order == Matrix3x3::ZYX)
			{
				useX = true;
				useZ = true;
			}
			else if (order == Matrix3x3::YZX || order == Matrix3x3::ZYX)
			{
				useY = true;
				useZ = true;
			}
			break;
		default:
			// no translational parameters for other joints
			break;
		}

		if (useX)
		{
			this->inputTranslate[0]->value(jpos[0]);
			this->inputTranslate[0]->activate();
			this->thumbWheelTranslate[0]->value(jpos[0]);
			this->thumbWheelTranslate[0]->range(-1000, 1000);
			this->thumbWheelTranslate[0]->activate();
		}

		if (useY)
		{
			this->inputTranslate[1]->value(jpos[1]);
			this->inputTranslate[1]->activate();
			this->thumbWheelTranslate[1]->value(jpos[1]);
			this->thumbWheelTranslate[1]->range(-1000, 1000);
			this->thumbWheelTranslate[1]->activate();
		}

		if (useZ)
		{
			this->inputTranslate[2]->value(jpos[2]);
			this->inputTranslate[2]->activate();
			this->thumbWheelTranslate[2]->value(jpos[2]);
			this->thumbWheelTranslate[2]->range(-1000, 1000);
			this->thumbWheelTranslate[2]->activate();
		}

		dofOffset = 3;
	}

	if (jointType == J_BALL || jointType == J_FREE)
	{ // ball and free joints use XYZ axis. Extract euler parameters from quaternion
		int offset = 0;
		if (jointType == J_FREE)
			offset += 3;
		Quaternion q(joints[joint]->getState(0 + offset), joints[joint]->getState(1 + offset), joints[joint]->getState(2 + offset), joints[joint]->getState(3 + offset));
		Matrix3x3 matrix;
		q.toMatrix(matrix);
		VectorObj angles;
		if (jointType == J_FREE)
			matrix.matToEuler(Matrix3x3::XYZ, angles, true);
		else
			matrix.matToEuler(Matrix3x3::ZYX, angles, true);
		for (int d = 0; d < 3; d++)
		{
			double low, high;
			//double dof_value = joints[joint]->getDof(d);
			joints[joint]->getLimits(d, &low, &high);
			this->inputRotate[d]->range(low, high);
			this->inputRotate[d]->value(angles[d] * 180.0 / M_PI);
			this->inputRotate[d]->activate();

			this->sliderRotate[d]->range(low, high);
			this->sliderRotate[d]->value(angles[d] * 180.0 / M_PI);
			this->sliderRotate[d]->activate();
		}
	}
	else
	{
		for (int i = 0; i < numaxis; i++)
		{	
			int position = 0;
			if (axis[i][0] == 1.0)
				position = 0;
			else if (axis[i][1] == 1.0)
				position = 1;
			else if (axis[i][2] == 1.0)
				position = 2;

			if (jointType != J_PLANAR || (jointType == J_PLANAR && i == numaxis - 1))
			{
				double low, high;
				double dof_value = joints[joint]->getState(i) * 180.0 / M_PI;
				joints[joint]->getLimits(i, &low, &high);
				this->inputRotate[position]->range(low, high);
				this->inputRotate[position]->value(dof_value);
				this->inputRotate[position]->activate();

				this->sliderRotate[position]->range(low, high);
				this->sliderRotate[position]->value(dof_value);
				this->sliderRotate[position]->activate();

				this->m_dofRotIndex[position] = i + dofOffset;
			}
		}
	}

	Link* link = this->m_artObj->getLink(joint);
	this->checkDisplayMonitorPoints->value(link->isDisplayMonitorPoints()? 1 : 0);
	this->checkDisplayMonitorPoints->activate();

}

void ArticulatedObjectWindow::setIKChainChoices(int val)
{
	if(m_artObj == NULL)
		return ;

	choiceChains->clear();
	choiceChains->add("Choose an IK chain");

	int numChains = m_artObj->getNumIKChains();
	IKChain *ikChain = NULL;

	for(int i = 0; i < numChains; i++)
	{
		ikChain = m_artObj->getIKChain(i);
		choiceChains->add(ikChain->getName());
	}
    
	choiceChains->value(val);
}

ArticulatedObject* ArticulatedObjectWindow::getArtObj()
{
	return m_artObj;
}

void ArticulatedObjectWindow::geometry_choice_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int gid = sWin->choiceGeometry->value();
	int joint = (sWin->m_jointList->value()) - 1;
	Link* link = sWin->getArtObj()->getLink(joint);

	if (gid == 0) // choose 'No geometry'
	{
		link->replaceGeometry(NULL, true);
	}
	else
	{
		// determine which geometry was chosen
		Widget* widget = sWin->choiceGeometry->get_item();
		const char* geomName = widget->label();
		DGeometry* geometry = (DGeometry*) dance::AllGeometry->get((char*) geomName);
		if (geometry != NULL)
		{
			// set the geometry to the chosen geometry
			link->replaceGeometry(geometry, true);
		}
		else
		{
			danceInterp::OutputMessage("No geometry with name %s exists, please check code.", widget->label());
		}
	}

	sWin->updateGUI();

	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::geometryCollision_choice_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int gid = sWin->choiceCollisionGeometry->value();
	int joint = (sWin->m_jointList->value()) - 1;
	Link* link = sWin->getArtObj()->getLink(joint);

	if (gid == 0) // choose 'No geometry'
	{
		link->replaceGeometryCollision(NULL, true);
	}
	else
	{
		Widget* widget = sWin->choiceCollisionGeometry->get_item();
		const char* geomName = widget->label();
		DGeometry* geometry = (DGeometry*) dance::AllGeometry->get((char*) geomName);
		if (geometry != NULL)
		{
			// set the geometry to the chosen geometry
			link->replaceGeometryCollision(geometry, true);
			link->setShowGeometryCollision(true);
			link->setDisplayMonitorPoints(true);
			link->assignMonitorPointsCollision(10);
		}
		else
		{
			danceInterp::OutputMessage("No geometry with name %s exists, please check code.", widget->label());
		}
	}

	sWin->updateGUI();

	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::geometryProp_choice_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int gid = sWin->choicePropGeometry->value();
	int joint = (sWin->m_jointList->value()) - 1;
	Link* link = sWin->getArtObj()->getLink(joint);

	if (gid == 0) // choose 'No geometry'
	{
		link->replaceGeometryProp(NULL, true);
	}
	else
	{
		Widget* widget = sWin->choicePropGeometry->get_item();
		const char* geomName = widget->label();
		DGeometry* geometry = (DGeometry*) dance::AllGeometry->get((char*) geomName);
		if (geometry != NULL)
		{
			// set the geometry to the chosen geometry
			link->replaceGeometryProp(geometry, true);
			link->assignMonitorPointsProp(10);
		}
		else
		{
			danceInterp::OutputMessage("No geometry with name %s exists, please check code.", widget->label());
		}
	}

	sWin->updateGUI();

	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::jointList_choice_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	sWin->updateGUI();

	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::inputRotateX_input_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int joint = (sWin->m_jointList->value()) - 1;
	Joint **joints = sWin->m_artObj->getJoints();

	double dof_value = sWin->inputRotate[0]->value();
	sWin->sliderRotate[0]->value(dof_value);
	if (joints[joint]->getJointType() == J_BALL)
	{
		sWin->setStateFromEulerAngles(joint, dof_value, sWin->inputRotate[1]->value(), sWin->inputRotate[2]->value()); 
		Quaternion q;
		sWin->setQuaternionValuesFromEulerAngles(dof_value*TORAD, sWin->inputRotate[1]->value()*TORAD, sWin->inputRotate[2]->value()*TORAD, &q);
		for (int x = 0; x < 3; x++)
			sWin->inputQuaternionAxis[x]->value(q.data()[x]);
		sWin->inputQuaternionAngle->value(q[3]);
	}
	else
	{
		if (joint == 0)
			sWin->setStateFromEulerAngles(0, dof_value, sWin->inputRotate[1]->value(), sWin->inputRotate[2]->value()); 
		else
			joints[joint]->setDof(sWin->m_dofRotIndex[0], dof_value);
	}

	sWin->m_artObj->updateStateConfig();



	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::sliderRotateX_slider_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int joint = (sWin->m_jointList->value()) - 1;
	Joint **joints = sWin->m_artObj->getJoints();

	double dof_value = sWin->sliderRotate[0]->value();
	sWin->inputRotate[0]->value(dof_value);

	if (joints[joint]->getJointType() == J_BALL)
	{
		sWin->setStateFromEulerAngles(joint, dof_value, sWin->inputRotate[1]->value(), sWin->inputRotate[2]->value()); 
		Quaternion q;
		sWin->setQuaternionValuesFromEulerAngles(dof_value*TORAD, sWin->inputRotate[1]->value()*TORAD, sWin->inputRotate[2]->value()*TORAD, &q);
		for (int x = 0; x < 3; x++)
			sWin->inputQuaternionAxis[x]->value(q[x]);
		sWin->inputQuaternionAngle->value(q[3]);
	}
	else
	{
		if (joint == 0)
			sWin->setStateFromEulerAngles(0, dof_value, sWin->inputRotate[1]->value(), sWin->inputRotate[2]->value()); 
		else
			joints[joint]->setDof(sWin->m_dofRotIndex[0], dof_value);
	}

	sWin->m_artObj->updateStateConfig();



//	if (sWin->m_artObj->simulator != NULL)
//		sWin->m_artObj->simulator->SetStateFromObjectState(sWin->m_artObj);

//	sWin->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::inputRotateY_input_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int joint = (sWin->m_jointList->value()) - 1;
	Joint **joints = sWin->m_artObj->getJoints();

	double dof_value = sWin->inputRotate[1]->value();
	sWin->sliderRotate[1]->value(dof_value);

	if (joints[joint]->getJointType() == J_BALL)
	{
		sWin->setStateFromEulerAngles(joint, sWin->inputRotate[0]->value(), dof_value, sWin->inputRotate[2]->value()); 
		Quaternion q;
		//double torad = M_PI / 180.0 ;
		sWin->setQuaternionValuesFromEulerAngles(sWin->inputRotate[0]->value()*TORAD, dof_value*TORAD, sWin->inputRotate[2]->value()*TORAD, &q);
		for (int x = 0; x < 3; x++)
			sWin->inputQuaternionAxis[x]->value(q[x]);
		sWin->inputQuaternionAngle->value(q[3]);
	}
	else
	{
		if (joint == 0)
			sWin->setStateFromEulerAngles(0, sWin->inputRotate[0]->value(), dof_value, sWin->inputRotate[2]->value()); 
		else
			joints[joint]->setDof(sWin->m_dofRotIndex[1], dof_value);
	}

	sWin->m_artObj->updateStateConfig();

	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::sliderRotateY_slider_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int joint = (sWin->m_jointList->value()) - 1;
	Joint **joints = sWin->m_artObj->getJoints();

	double dof_value = sWin->sliderRotate[1]->value();
	sWin->inputRotate[1]->value(dof_value);

	if (joints[joint]->getJointType() == J_BALL)
	{
		sWin->setStateFromEulerAngles(joint, sWin->inputRotate[0]->value(), dof_value, sWin->inputRotate[2]->value()); 
		Quaternion q;
		sWin->setQuaternionValuesFromEulerAngles(sWin->inputRotate[0]->value()*TORAD, dof_value*TORAD, sWin->inputRotate[2]->value()*TORAD, &q);
		for (int x = 0; x < 3; x++)
			sWin->inputQuaternionAxis[x]->value(q[x]);
		sWin->inputQuaternionAngle->value(q[3]);
	}
	else
	{
		if (joint == 0)
			sWin->setStateFromEulerAngles(joint, sWin->inputRotate[0]->value(), dof_value, sWin->inputRotate[2]->value()); 
		else
			joints[joint]->setDof(sWin->m_dofRotIndex[1], dof_value);
	}

	sWin->m_artObj->updateStateConfig();

	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::inputRotateZ_input_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int joint = (sWin->m_jointList->value()) - 1;
	Joint **joints = sWin->m_artObj->getJoints();

	double dof_value = sWin->inputRotate[2]->value();
	sWin->sliderRotate[2]->value(dof_value);

	if (joints[joint]->getJointType() == J_BALL)
	{
		sWin->setStateFromEulerAngles(joint, sWin->inputRotate[0]->value(), sWin->inputRotate[1]->value(), dof_value); 
		Quaternion q;
		sWin->setQuaternionValuesFromEulerAngles(sWin->inputRotate[0]->value()*TORAD, sWin->inputRotate[1]->value()*TORAD, dof_value*TORAD, &q);
		for (int x = 0; x < 3; x++)
			sWin->inputQuaternionAxis[x]->value(q[x]);
		sWin->inputQuaternionAngle->value(q[3]);
	}
	else
	{
		if (joint == 0)
			sWin->setStateFromEulerAngles(0, sWin->inputRotate[0]->value(), sWin->inputRotate[1]->value(), dof_value); 
		else
			joints[joint]->setDof(sWin->m_dofRotIndex[2], dof_value);
	}

	sWin->m_artObj->updateStateConfig();

	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::sliderRotateZ_slider_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int joint = (sWin->m_jointList->value()) - 1;
	Joint **joints = sWin->m_artObj->getJoints();

	double dof_value = sWin->sliderRotate[2]->value();
	sWin->inputRotate[2]->value(dof_value);

	if (joints[joint]->getJointType() == J_BALL)
	{
		sWin->setStateFromEulerAngles(joint, sWin->inputRotate[0]->value(), sWin->inputRotate[1]->value(), dof_value); 
		Quaternion q;
		sWin->setQuaternionValuesFromEulerAngles(sWin->inputRotate[0]->value()*TORAD, sWin->inputRotate[1]->value()*TORAD, dof_value*TORAD, &q);
		for (int x = 0; x < 3; x++)
			sWin->inputQuaternionAxis[x]->value(q[x]);
		sWin->inputQuaternionAngle->value(q[3]);
	}
	else
	{
		if (joint == 0)
			sWin->setStateFromEulerAngles(0, sWin->inputRotate[0]->value(), sWin->inputRotate[1]->value(), dof_value); 
		else
			joints[joint]->setDof(sWin->m_dofRotIndex[2], dof_value);
	}

	sWin->m_artObj->updateStateConfig();



//	if (sWin->m_artObj->simulator != NULL)
//		sWin->m_artObj->simulator->SetStateFromObjectState(sWin->m_artObj);

//	sWin->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::translate(Joint* joint, double jpos[3])
{
	double axes[3][3];
	joint->getAxis(axes);

	// adjust for the inboard-to-joint vector
	Vector itoj;
	joint->getInbToJoint(itoj);
	VecSubtract(jpos, jpos, itoj);

	// if the joint has three translational components, use them
	int jointType = joint->getJointType();
	switch (jointType)
	{
	case J_PIN: // rotations only
		danceInterp::OutputMessage("Pin joint found, no translations are possible...");
		break;
	case J_BALL:
		danceInterp::OutputMessage("Ball joint found, no translations are possible...");
		break;
	case J_CYLINDER:
		danceInterp::OutputMessage("Cylinder joint found, no translations are possible...");
		break;
	case J_SLIDER:
		danceInterp::OutputMessage("Slider joint found, no translations are possible...");
		break;
	case J_FREE: // three translation parameters
		if (axes[0][0] == 1.0 && axes[0][1] == 0.0 && axes[0][2] == 0.0)
			joint->setState(0, jpos[0]);
		else if (axes[0][0] == 0.0 && axes[0][1] == 1.0 && axes[0][2] == 0.0)
			joint->setState(0, jpos[1]);
		else if (axes[0][0] == 0.0 && axes[0][1] == 0.0 && axes[0][2] == 1.0)
			joint->setState(0, jpos[2]);
		// second axis
		if (axes[1][0] == 1.0 && axes[1][1] == 0.0 && axes[1][2] == 0.0)
			joint->setState(1, jpos[0]);
		else if (axes[1][0] == 0.0 && axes[1][1] == 1.0 && axes[1][2] == 0.0)
			joint->setState(1, jpos[1]);
		else if (axes[1][0] == 0.0 && axes[1][1] == 0.0 && axes[1][2] == 1.0)
			joint->setState(1, jpos[2]);
		// third axis
		if (axes[2][0] == 1.0 && axes[2][1] == 0.0 && axes[2][2] == 0.0)
			joint->setState(2, jpos[0]);
		else if (axes[2][0] == 0.0 && axes[2][1] == 1.0 && axes[2][2] == 0.0)
			joint->setState(2, jpos[1]);
		else if (axes[2][0] == 0.0 && axes[2][1] == 0.0 && axes[2][2] == 1.0)
			joint->setState(2, jpos[2]);
		break;	
	case J_GIMBAL:
		danceInterp::OutputMessage("Gimbal joint found, no translations are possible...");
		break;
	case J_WELD:
		danceInterp::OutputMessage("Weld joint found, no translations are possible...");
		break;
	case J_PLANAR: // two translation parameters
		// determine the planar axes
		double axes[3][3];
		joint->getAxis(axes);
		// translate only the first two axes
		// first axis
		if (axes[0][0] == 1.0 && axes[0][1] == 0.0 && axes[0][2] == 0.0)
			joint->setState(0, jpos[0]);
		else if (axes[0][0] == 0.0 && axes[0][1] == 1.0 && axes[0][2] == 0.0)
			joint->setState(0, jpos[1]);
		else if (axes[0][0] == 0.0 && axes[0][1] == 0.0 && axes[0][2] == 1.0)
			joint->setState(0, jpos[2]);
		// second axis
		if (axes[1][0] == 1.0 && axes[1][1] == 0.0 && axes[1][2] == 0.0)
			joint->setState(1, jpos[0]);
		else if (axes[1][0] == 0.0 && axes[1][1] == 1.0 && axes[1][2] == 0.0)
			joint->setState(1, jpos[1]);
		else if (axes[1][0] == 0.0 && axes[1][1] == 0.0 && axes[1][2] == 1.0)
			joint->setState(1, jpos[2]);
		break;
	case J_BEARING:
		danceInterp::OutputMessage("Bearing joint found, no translations are possible...");
		break;
	case J_UNIVERSAL:
		danceInterp::OutputMessage("Universal joint found, no translations are possible...");
		break;
	case J_BUSHING:
		danceInterp::OutputMessage("Bushing joint found, no translations are possible...");
		break;
	}

	this->m_artObj->updateStateConfig();
//	if (this->m_artObj->simulator != NULL)
//		this->m_artObj->simulator->SetStateFromObjectState(this->m_artObj);
}

void ArticulatedObjectWindow::inputTranslate_input_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int joint = (sWin->m_jointList->value()) - 1;
	Joint **joints = sWin->m_artObj->getJoints();

	double jpos[3];
	jpos[0] = sWin->inputTranslate[0]->value();
	jpos[1] = sWin->inputTranslate[1]->value();
	jpos[2] = sWin->inputTranslate[2]->value();

	sWin->thumbWheelTranslate[0]->value(jpos[0]);
	sWin->thumbWheelTranslate[1]->value(jpos[1]);
	sWin->thumbWheelTranslate[2]->value(jpos[2]);

	sWin->translate(joints[joint], jpos);

//	sWin->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::ThumbWheelTranslate_ThumbWheel_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int joint = (sWin->m_jointList->value()) - 1;
	Joint **joints = sWin->m_artObj->getJoints();

	double jpos[3];
	jpos[0] = sWin->thumbWheelTranslate[0]->value();
	jpos[1] = sWin->thumbWheelTranslate[1]->value();
	jpos[2] = sWin->thumbWheelTranslate[2]->value();

	sWin->inputTranslate[0]->value(jpos[0]);
	sWin->inputTranslate[1]->value(jpos[1]);
	sWin->inputTranslate[2]->value(jpos[2]);

	sWin->translate(joints[joint], jpos);

//	sWin->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::positionLoader_button_cb(Widget* o, void* p)
{ 
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	const char* filename = fltk::file_chooser("Load Position",
					"{*.state}",
					(const char*) NULL,
					false);

	if (filename != NULL)
	{
		if (sWin->m_artObj != NULL)
		{
			sWin->m_artObj->loadStateConfig((char*)filename);
			sWin->m_jointList->value(0);

			sWin->inputRotate[0]->value(0);
			sWin->inputRotate[0]->deactivate();
			sWin->sliderRotate[0]->value(0);
			sWin->sliderRotate[0]->deactivate();

			sWin->inputRotate[1]->value(0);
			sWin->inputRotate[1]->deactivate();
			sWin->sliderRotate[1]->value(0);
			sWin->sliderRotate[1]->deactivate();

			sWin->inputRotate[2]->value(0);
			sWin->inputRotate[2]->deactivate();
			sWin->sliderRotate[2]->value(0);
			sWin->sliderRotate[2]->deactivate();

			sWin->inputTranslate[0]->value(0);
			sWin->inputTranslate[0]->deactivate();
			sWin->thumbWheelTranslate[0]->value(0);
			sWin->thumbWheelTranslate[0]->deactivate();

			sWin->inputTranslate[1]->value(0);
			sWin->inputTranslate[1]->deactivate();
			sWin->thumbWheelTranslate[1]->value(0);
			sWin->thumbWheelTranslate[1]->deactivate();

			sWin->inputTranslate[2]->value(0);
			sWin->inputTranslate[2]->deactivate();
			sWin->thumbWheelTranslate[2]->value(0);
			sWin->thumbWheelTranslate[2]->deactivate();
		}

		sWin->updateGUI();
		dance::AllViews->postRedisplay();
	}
}

void ArticulatedObjectWindow::positionSaver_button_cb(Widget* o, void* p)
{ 
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	const char* filename = fltk::file_chooser("Save Position",
					"{*.state}",
					(const char*) NULL,
					false);

	if (filename != NULL)
	{
		if (sWin->m_artObj != NULL)
		{
			sWin->m_artObj->saveStateConfig((char*)filename);
		}

		sWin->updateGUI();
	}
}

void ArticulatedObjectWindow::displaymonitorpoints_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;
	bool display = sWin->checkDisplayMonitorPoints->value() == 1? true : false;
	int joint = (sWin->m_jointList->value()) - 1;
	Link* link = sWin->m_artObj->getLink(joint);
	link->setDisplayMonitorPoints(display);

	sWin->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::displayallmonitorpoints_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;
	bool display = sWin->checkDisplayAllMonitorPoints->value();

	for (int x = 0; x < sWin->m_artObj->getNumJoints(); x++)
	{
		Link* link = sWin->m_artObj->getLink(x);
		link->setDisplayMonitorPoints(display);
	}
	
	sWin->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::displaylinks_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;
	bool val = sWin->checkDisplayLinks->value() == 1? true : false;
	ArticulatedObject* ao = sWin->getArtObj();
	if (ao != NULL)
	{
		ao->setShowingLinks(val);
		dance::AllViews->postRedisplay();
	}
	else
	{
		danceInterp::OutputMessage("No articulated object present - cannot toggle link display.");
	}

	sWin->updateGUI();
}

void ArticulatedObjectWindow::displayjoints_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;
	bool val = sWin->checkDisplayJoints->value() == 1? true : false;
	ArticulatedObject* ao = sWin->getArtObj();
	if (ao != NULL)
	{
		ao->setShowingJoints(val);
		dance::AllViews->postRedisplay();
	}
	else
	{
		danceInterp::OutputMessage("No articulated object present - cannot toggle joint display.");
	}

	sWin->updateGUI();
}

void ArticulatedObjectWindow::displayboundingbox_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;
	
	bool val = sWin->checkDisplayBoundingBox->value() == 1? true : false;
	ArticulatedObject* ao = sWin->getArtObj();
	if (ao != NULL)
	{
		ao->setShowingActiveBox(val);
		dance::AllViews->postRedisplay();
	}
	else
	{
		danceInterp::OutputMessage("No articulated object present - cannot toggle active link/joint display.");
	}

	sWin->updateGUI();
}

void ArticulatedObjectWindow::displayInertia_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	bool val = (1 == sWin->checkDisplayInertia->value()) ;
	ArticulatedObject* ao = sWin->getArtObj();
	if (ao != NULL)
	{
		ao->setIsShowingInertia(val);
		dance::AllViews->postRedisplay();
	}
	else
	{
		danceInterp::OutputMessage("No articulated object present - cannot toggle composite inertia display.");
	}
	sWin->updateGUI();
}


void ArticulatedObjectWindow::transparency_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;
	ArticulatedObject* ao = sWin->getArtObj();
	int numLinks = ao->getNumLinks();
	for (int l = 0; l < numLinks; l++)
	{
		Link* link = ao->getLink(l);
		DGeometry* geometry = link->getGeometry();
		if (geometry != NULL)
			geometry->setTransparency((float)sWin->sliderTransparency->value());
	}

	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::showcollisiongeometry_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;
	int joint = (sWin->m_jointList->value()) - 1;
	if (joint >= 0)
	{
		Link* link = sWin->m_artObj->getLink(joint);
		CheckButton* check = (CheckButton*) o;
		if (check->value() == 1)
			link->setShowGeometryCollision(true);
		else
			link->setShowGeometryCollision(false);
	}

	sWin->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::showallcollisiongeometry_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	sWin->m_artObj->setShowingCollisionGeometry(sWin->checkShowAllGeometryCollision->value());

	sWin->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::assign_monitor_points_cb(Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;
	
	int joint = (sWin->m_jointList->value()) - 1;
	if (joint >= 0)
	{
		Link* link = sWin->m_artObj->getLink(joint);
		int num = sWin->inputNumMonitorPoints->ivalue();
		if (link->isShowGeometryCollision())
			link->assignMonitorPointsCollision(num);
		else
			link->assignMonitorPoints(num);
	}

	sWin->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::setStateFromEulerAngles(int jointNum, double x, double y, double z)
{
	// produce a quaternion based on the proper Euler angles
	// let's assume an XYZ rotation order for now
	Joint* joint = m_artObj->getJoint(jointNum);
	int jointType = joint->getJointType();
	int order = joint->determineRotationOrder();
	Matrix3x3 matrix;
	Quaternion q;
	VectorObj angles(x * M_PI/180.0, y * M_PI/180.0, z * M_PI/180.0);

	switch (jointType)
	{
	case J_PIN:
		if (order == Matrix3x3::X)
			joint->setState(0, x * M_PI/180.0);
		else if (order == Matrix3x3::Y)
			joint->setState(0, y * M_PI/180.0);
		else if (order == Matrix3x3::Z)
			joint->setState(0, z * M_PI/180.0);
		else
			danceInterp::OutputMessage("Could not determine rotation order for pin joint '%s'...", joint->getName());
		break;
	case J_BALL:
		{
			this->setQuaternionValuesFromEulerAngles(angles[0], angles[1], angles[2], &q);
			joint->setState(0, q.data()[0]);
			joint->setState(1, q.data()[1]);
			joint->setState(2, q.data()[2]);
			joint->setState(3, q.data()[3]);
		}
		break;
	case J_GIMBAL:
		if (order == Matrix3x3::XYZ)
		{
			joint->setState(0, x * M_PI/180.0);
			joint->setState(1, y * M_PI/180.0);
			joint->setState(2, z * M_PI/180.0);
		}
		else if (order == Matrix3x3::XZY)
		{
			joint->setState(0, x * M_PI/180.0);
			joint->setState(1, z * M_PI/180.0);
			joint->setState(2, y * M_PI/180.0);
		}
		else if (order == Matrix3x3::YXZ)
		{
			joint->setState(0, y * M_PI/180.0);
			joint->setState(1, x * M_PI/180.0);
			joint->setState(2, z * M_PI/180.0);
		}
		else if (order == Matrix3x3::YZX)
		{
			joint->setState(0, y * M_PI/180.0);
			joint->setState(1, z * M_PI/180.0);
			joint->setState(2, x * M_PI/180.0);
		}
		else if (order == Matrix3x3::ZXY)
		{
			joint->setState(0, z * M_PI/180.0);
			joint->setState(1, x * M_PI/180.0);
			joint->setState(2, y * M_PI/180.0);
		}
		else if (order == Matrix3x3::ZYX)
		{
			joint->setState(0, z * M_PI/180.0);
			joint->setState(1, y * M_PI/180.0);
			joint->setState(2, x * M_PI/180.0);
		}
		break;
	case J_CYLINDER:
		break;
	case J_SLIDER:
		break;
	case J_FREE: // three translation parameters
		matrix.matFromEuler(Matrix3x3::XYZ, angles);
		q.fromMatrix(matrix);
		joint->setState(3, q.data()[0]);
		joint->setState(4, q.data()[1]);
		joint->setState(5, q.data()[2]);
		joint->setState(6, q.data()[3]);
		break;	
	case J_WELD:
		break;
	case J_PLANAR: // one rotational parameters
		if (order == Matrix3x3::YZX || order == Matrix3x3::ZYX)
			joint->setState(2, x * M_PI / 180.0);
		else if (order == Matrix3x3::XZY || order == Matrix3x3::ZXY)
			joint->setState(2, y * M_PI / 180.0);
		else if (order == Matrix3x3::YXZ || order == Matrix3x3::XYZ)
			joint->setState(2, z * M_PI / 180.0);
		else
			danceInterp::OutputMessage("Could not determine rotation order for pin joint '%s'...", joint->getName());
		break;
		break;
	case J_BEARING:
		break;
	case J_UNIVERSAL:
		if (order == Matrix3x3::XY)
		{
			joint->setState(0, x * M_PI/180.0);
			joint->setState(1, y * M_PI/180.0);
		}
		else if (order == Matrix3x3::XZ)
		{
			joint->setState(0, x * M_PI/180.0);
			joint->setState(1, z * M_PI/180.0);
		}
		else if (order == Matrix3x3::YX)
		{
			joint->setState(0, y * M_PI/180.0);
			joint->setState(1, x * M_PI/180.0);
		}
		else if (order == Matrix3x3::YZ)
		{
			joint->setState(0, y * M_PI/180.0);
			joint->setState(1, z * M_PI/180.0);
		}
		else if (order == Matrix3x3::ZX)
		{
			joint->setState(0, z * M_PI/180.0);
			joint->setState(1, x * M_PI/180.0);
		}
		else if (order == Matrix3x3::ZY)
		{
			joint->setState(0, z * M_PI/180.0);
			joint->setState(1, y * M_PI/180.0);
		}

		break;
	case J_BUSHING:
		break;
	}
}

void ArticulatedObjectWindow::inputSphereTranslate_input_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;
	int jointNum = win->m_jointList->value() - 1;
	Link* link = NULL;
	if (jointNum >= 0)
	{
		link = win->getArtObj()->getLink(jointNum);
		int sphereNum = win->choiceSphere->value() - 1;
		if (sphereNum >= 0 && sphereNum <= MAXNUMSPHERES)
		{
			link->setSphereTranslation(sphereNum,
										win->inputSphereTranslate[0]->value(),
										win->inputSphereTranslate[1]->value(),
										win->inputSphereTranslate[2]->value());  
			link->setSphereMatrix(sphereNum);
		}
	}
	win->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::thumbWheelSphereTranslate_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;
	int jointNum = win->m_jointList->value() - 1;
	Link* link = NULL;
	if (jointNum >= 0)
	{
		link = win->getArtObj()->getLink(jointNum);
		int sphereNum = win->choiceSphere->value() - 1;
		if (sphereNum >= 0 && sphereNum <= MAXNUMSPHERES)
		{
			link->setSphereTranslation(sphereNum, 
										win->thumbWheelSphereTranslate[0]->value(), 
										win->thumbWheelSphereTranslate[1]->value(), 
										win->thumbWheelSphereTranslate[2]->value());  
			link->setSphereMatrix(sphereNum);

		}
	}
	win->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::inputSphereScale_input_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;
	int jointNum = win->m_jointList->value() - 1;
	Link* link = NULL;
	if (jointNum >= 0)
	{
		link = win->getArtObj()->getLink(jointNum);
		int sphereNum = win->choiceSphere->value() - 1;
		if (sphereNum >= 0 && sphereNum <= MAXNUMSPHERES)
		{
			link->setSphereScale(sphereNum, win->inputSphereScale->value());
			link->setSphereMatrix(sphereNum);

		}
	}
	win->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::thumbWheelSphereScale_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;
	int jointNum = win->m_jointList->value() - 1;
	Link* link = NULL;
	if (jointNum >= 0)
	{
		link = win->getArtObj()->getLink(jointNum);
		int sphereNum = win->choiceSphere->value() - 1;
		if (sphereNum >= 0 && sphereNum <= MAXNUMSPHERES)
		{
			link->setSphereScale(sphereNum, win->thumbWheelSphereScale->value());
			link->setSphereMatrix(sphereNum);

		}
	}
	win->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::choiceSphere_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;
	Choice* choice = (Choice*) o;
	win->curSphereChosen = choice->value() - 1;

	win->updateGUI();
}

void ArticulatedObjectWindow::addSphere_cb(fltk::Widget* o, void* p)
{
	// determine which link is selected 
	ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;
	int jointNum = win->m_jointList->value() - 1;
	Link* link = NULL;
	if (jointNum >= 0)
	{
		link = win->getArtObj()->getLink(jointNum);
		int numSpheres = link->getNumSpheres();
		if (numSpheres < MAXNUMSPHERES)
		{
			link->setSphereTranslation(numSpheres, 0, 0, 0);
			link->setSphereScale(numSpheres, .1);
			link->setSphereMatrix(numSpheres);
			link->setNumSpheres(numSpheres + 1);
			win->curSphereChosen = numSpheres;
			win->getArtObj()->setShowingSpheres(true);
		}
		else
		{
			danceInterp::OutputMessage("Cannot add any more spheres. Link %s already has %d spheres.", link->getName(), link->getNumSpheres());
		}

	}
	else
	{
		danceInterp::OutputMessage("No link selected, cannot add sphere.");
	}

	win->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::removeSphere_cb(fltk::Widget* o, void* p)
{
	// determine which link is selected 
	ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;
	int jointNum = win->m_jointList->value() - 1;
	Link* link = NULL;
	if (jointNum >= 0)
	{
		link = win->getArtObj()->getLink(jointNum);
		int numSpheres = link->getNumSpheres();
		if (numSpheres == 0)
		{
			danceInterp::OutputMessage("No spheres present to remove from link %s.", link->getName());
		}
		else
		{
			// determine which sphere is to be erased
			if (win->curSphereChosen == numSpheres - 1)
			{ 
				// last sphere, decrement sphere count
				link->setNumSpheres(numSpheres - 1);
				win->curSphereChosen = win->curSphereChosen - 1;
			}
			else
			{
				// need to shift all other spheres down
				for (int x = win->curSphereChosen + 1; x < numSpheres - 1; x++)
				{
					Vector translation;
					link->getSphereTranslation(x, translation[0], translation[1], translation[2]);
					double scale = link->getSphereScale(x);
					link->setSphereTranslation(x - 1, translation[0], translation[1], translation[2]);
					link->setSphereScale(x - 1, scale);
					link->setSphereMatrix(x - 1);
				}
				link->setNumSpheres(numSpheres - 1);
				win->curSphereChosen = win->curSphereChosen - 1;
			}
		}
	}
	else
	{
		danceInterp::OutputMessage("No link selected, cannot add sphere.");
	}

	win->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::toggleShowSpheres_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;
	CheckButton* check = (CheckButton*) o;
	if (check->value() == 0)
		win->getArtObj()->setShowingSpheres(false);
	else
		win->getArtObj()->setShowingSpheres(true);

	win->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::loadSpheres_cb(fltk::Widget* o, void* p)
{
		ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;

		const char* last = Preference::getPreferenceValue("ArticulatedObject.lastloadedspheres");

		const char* filename = fltk::file_chooser("Load Spheres",
					"{*.sphere}",
					(const char*) last,
					false);

		if (filename != NULL)
		{
			win->getArtObj()->loadSpheres((char*)filename);
			win->getArtObj()->setShowingSpheres(true);
		}

		char buff[2048];
		convertbackslashes((char*) filename, buff);
		Preference::replacePreference("ArticulatedObject.lastloadedspheres", buff);
		dance::writePreferences();

}

void ArticulatedObjectWindow::saveSpheres_cb(fltk::Widget* o, void* p)
{
		ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;
		const char* last = Preference::getPreferenceValue("ArticulatedObject.lastsavedsheres");

		const char* filename = fltk::file_chooser("Save Spheres",
			"{*.sphere}",
					(const char*) last,
					false);

		if (filename != NULL)
		{
			win->getArtObj()->saveSpheres((char*)filename);

			char buff[2048];
			convertbackslashes((char*) filename, buff);
			Preference::replacePreference("ArticulatedObject.lastsavedspheres", buff);
			dance::writePreferences();
		}
}

void ArticulatedObjectWindow::sphereColor_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;
	Material* material = win->getArtObj()->getSphereMaterial();

	dance::rootWindow->materialWindow->setSelected(material);
	dance::rootWindow->materialWindow->setSelectMode(true);
	dance::rootWindow->materialWindow->exec(dance::rootWindow);
	Material* m = dance::rootWindow->materialWindow->getSelected();
	if (m != NULL)
	{
		win->getArtObj()->setSphereMaterial(m);
	}
	dance::AllViews->postRedisplay();
}


void ArticulatedObjectWindow::animSaver_button_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	const char* last = Preference::getPreferenceValue("ArticulatedObject.lastsavedanim");

	const char* filename = fltk::file_chooser("Save Animation",
					"{*.bvh}",
					(const char*) last,
					false);
	if (filename != NULL)
	{
        char absFileName[1024];
        // make sure that we are using the absolute path
#ifdef WIN32
		const char* f = fltk_filename_normalize(absFileName, 1024, filename, NULL);
		if (strcmp(f, filename) == 0)
			strcpy(absFileName, filename);

#else
        filename_absolute(absFileName, 1024, filename, NULL);
#endif

		if (sWin->m_artObj != NULL)
		{
            sWin->m_artObj->getAnimationSequence()->save((char*) absFileName);

			char buff[2048];
            convertbackslashes((char*) absFileName, buff);
			Preference::replacePreference("ArticulatedObject.lastsavedanim", buff);
			dance::writePreferences();

		}
	}
}

void ArticulatedObjectWindow::animLoader_button_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	const char* last = Preference::getPreferenceValue("ArticulatedObject.lastloadedanim");

	const char* filename = fltk::file_chooser("Load Animation",
					"{*.bvh}",
					(const char*) last,
					false);

	if (filename != NULL)
	{
		if (sWin->m_artObj != NULL)
		{
			sWin->m_artObj->setPlayback(true);
			sWin->m_artObj->getAnimationSequence()->load((char*) filename);
			sWin->m_artObj->setLastRecordTime(sWin->m_artObj->getAnimationSequence()->getEndTime());
			dance::AllSimulators->calculatePlaybackEndTime();

			char buff[2048];
			convertbackslashes((char*) filename, buff);
			Preference::replacePreference("ArticulatedObject.lastloadedanim", buff);
			dance::writePreferences();
		}
	}
}

void ArticulatedObjectWindow::mass_cb(fltk::Widget* o, void* p)
{
	FloatInput* input = (FloatInput*) o;
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int joint = (sWin->m_jointList->value()) - 1;
	Link* link = sWin->getArtObj()->getLink(joint);

	double val = input->fvalue();
	link->setMass(val);

	sWin->updateGUI();
}

void ArticulatedObjectWindow::moments_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int joint = (sWin->m_jointList->value()) - 1;
	Link* link = sWin->getArtObj()->getLink(joint);

	Vector moments;
	for (int x = 0; x < 3; x++)
		moments[x] = sWin->inputMoments[x]->fvalue();

	link->setMoments(moments);
	sWin->updateGUI();
}

void ArticulatedObjectWindow::zeroposition_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	sWin->m_artObj->setZeroState();

	sWin->updateGUI();

	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::zerojointposition_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	Joint* joint = sWin->m_artObj->getActiveJoint();
	if (joint != NULL)
	{
		joint->setZeroState();
		sWin->m_artObj->updateStateConfig();
	}

	sWin->updateGUI();

	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::limits_cb(fltk::Widget* o, void* p)
{
	//FloatInput* input = (FloatInput*) o;
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int j = (sWin->m_jointList->value()) - 1;

	Joint* joint = sWin->m_artObj->getJoint(j);
	int numAxes = joint->getNumAxis();
	if (joint->getJointType() == J_BALL)
		numAxes = 3;
	double axes[3][3];
	joint->getAxis(axes);
	for (int x = 0; x < numAxes; x++)
	{
		if (axes[x][0] == 1.0 && axes[x][1] == 0.0 && axes[x][2] == 0.0)
		{
			joint->setLimits(x, sWin->inputLimitLow[0]->fvalue(), sWin->inputLimitHigh[0]->fvalue());
			sWin->sliderRotate[0]->range(sWin->inputLimitLow[0]->fvalue(), sWin->inputLimitHigh[0]->fvalue());
			sWin->sliderRotate[0]->layout();
		}
		else if (axes[x][0] == 0.0 && axes[x][1] == 1.0 && axes[x][2] == 0.0)
		{
			joint->setLimits(x, sWin->inputLimitLow[1]->fvalue(), sWin->inputLimitHigh[1]->fvalue());
			sWin->sliderRotate[1]->range(sWin->inputLimitLow[1]->fvalue(), sWin->inputLimitHigh[1]->fvalue());
			sWin->sliderRotate[1]->layout();
		}
		else if (axes[x][0] == 0.0 && axes[x][1] == 0.0 && axes[x][2] == 1.0)
		{
			joint->setLimits(x, sWin->inputLimitLow[2]->fvalue(), sWin->inputLimitHigh[2]->fvalue());
			sWin->sliderRotate[2]->range(sWin->inputLimitLow[2]->fvalue(), sWin->inputLimitHigh[2]->fvalue());
			sWin->sliderRotate[2]->layout();
		}
	}

	sWin->updateGUI();
}

void ArticulatedObjectWindow::jointedit_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;

	if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_RUNNING)
	{
		fltk::alert("Please stop the simulation before editing the topology of %s.", win->m_artObj->getName());
		return;
	}

	if(win->windowNew->visible())
		win->windowNew->close_window(win->windowNew, win->windowNew);

	win->windowEdit->firstTime = true;

	//set mode of edit window
	win->windowEdit->setEditMode();
	//show edit window
	win->windowEdit->show();
	//set articulated object mode
	win->m_artObj->setInteractionMode(EDIT_mode);
	//disable current window while edit window shown
	win->deactivate();
}

void ArticulatedObjectWindow::jointnew_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* win = (ArticulatedObjectWindow*) p;

	if (dance::AllSimulators->getSimulationState() == dance::AllSimulators->STATE_RUNNING)
	{
		fltk::alert("Please stop the simulation before editing the topology of %s.", win->m_artObj->getName());
		return;
	}

	if (win->windowEdit->visible())
		win->windowEdit->close_window(win->windowEdit, win->windowEdit);

	dance::addInteraction(win->getArtObj());

	win->windowNew->firstTime = true;
	//set mode of new window
	win->windowNew->setNewMode();
	//show new window
	win->windowNew->show();
	//set articulated object mode
	win->m_artObj->setInteractionMode(EDIT_mode);
	//disable current window while new window shown
	win->deactivate();

	// determine the joint type
	int jointType = 0;
//	int whichJoint = win->choiceJointType->value();
/*	if (whichJoint == 0)
		jointType = J_WELD;
	else if (whichJoint == 1)
		jointType = J_PIN;
	else if (whichJoint == 2)
		jointType = J_UNIVERSAL;
	else if (whichJoint == 3)
		jointType = J_GIMBAL;
	else if (whichJoint == 4)
		jointType = J_BALL;
	else if (whichJoint == 5)
		jointType = J_FREE;
*/

	// if empty object, create temporary link of length 1
	if (win->m_artObj->getNumJoints() == 0)
	{
		jointType = J_FREE;

		// first link always created in global mode
		if (jointType == J_FREE)							// if free joint, CoM at root
		{
			win->windowNew->inputEFTranslate[1]->value(1.0);
			win->windowNew->inputCOMTranslate[2]->value(0.0);
		}
		else												// otherwise, CoM in the middle
		{
			win->windowNew->inputEFTranslate[1]->value(0.5);
			win->windowNew->inputCOMTranslate[2]->value(0.5);
		}

		win->windowNew->checkbuttonCMdefault->value(false);
		win->windowNew->inputTranslate_input_cb(win->windowNew->inputEFTranslate[1], win->windowNew);
	}
	else		// if object non-empty
	{
		jointType = J_BALL;

		// find the world position of the end effector of the current joint
		int jointNum = win->m_jointList->value() - 1;
		if (jointNum == -1)
			jointNum = win->m_artObj->getNumJoints() - 1;
		Joint* curJoint = win->m_artObj->getJoint(jointNum);

		Link* curLink = curJoint->getOutboardLink();
		Vector endEff;
		double matrix[4][4];
		Vector jpos;
		curLink->getTransMat(matrix);

		curLink->getEndEffector(endEff);

		if (win->windowNew->global)	// GLOBAL mode
		{
			endEff[1] += 1.0;							// set new link length to 1
			transformPoint_mat(endEff, matrix);		// change to world coord

			// place this joint 1.0 higher than that
			for (int x = 0; x < 3; x++)
			{
				win->windowNew->inputEFTranslate[x]->value(endEff[x]);

				win->windowNew->wheelEFTranslate[x]->value(endEff[x]);
			}
		}
		else	// LOCAL mode
		{
			setVector(jpos, 0, -0.5, 0);
			setVector(endEff, 0, 0.5, 0);			// set new link length to 1 (i.e. EndEffector to 0.5)

			// set joint position
			for (int x = 0; x < 3; x++)
			{
				win->windowNew->inputJointTranslate[x]->value(jpos[x]);
				win->windowNew->inputEFTranslate[x]->value(endEff[x]);
				win->windowNew->inputCOMTranslate[x]->value(0);

				win->windowNew->wheelJointTranslate[x]->value(jpos[x]);
				win->windowNew->wheelEFTranslate[x]->value(endEff[x]);
				win->windowNew->wheelCOMTranslate[x]->value(0);

			}
		}
					
		win->windowNew->checkbuttonCMdefault->value(true);
		win->windowNew->inputTranslate_input_cb(win->windowNew->inputEFTranslate[1], win->windowNew);
	}
}

void ArticulatedObjectWindow::stiffdamp_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	int j = (sWin->m_jointList->value()) - 1;

	Joint* joint = sWin->m_artObj->getJoint(j);

	int numAxes = joint->getNumAxis();
	if (joint->getJointType() == J_BALL)
		numAxes = 3;
	for (int a = 0; a < numAxes; a++)
	{
		joint->setStiffness(a, sWin->inputStiffness[a]->fvalue());
		if (joint->getMaxStiffness(a) < joint->getStiffness(a))
			joint->setMaxStiffness(a, joint->getStiffness(a));
		joint->setDamping(a, sWin->inputDamping[a]->fvalue());
		if (joint->getMaxDamping(a) < joint->getDamping(a))
			joint->setMaxDamping(a, joint->getDamping(a));
	}
}

void ArticulatedObjectWindow::velocitySaver_button_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	const char* filename = fltk::file_chooser("Save Velocity",
					"{*.dstate}",
					(const char*) NULL,
					false);

	if (filename != NULL)
	{
		if (sWin->m_artObj != NULL)
		{
			sWin->m_artObj->saveDStateConfig((char*)filename);
		}
	}
}

void ArticulatedObjectWindow::velocityLoader_button_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	const char* filename = fltk::file_chooser("Load Velocity",
					"{*.dstate}",
					(const char*) NULL,
					false);

	if (filename != NULL)
	{
                danceInterp::OutputMessage("Loading velocities from <%s>",
filename);
		sWin->m_artObj->loadDStateConfig((char*) filename);
	}
}

void ArticulatedObjectWindow::velocities_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	Preference::getWindowPreference("ArticulatedObject.velocitywindow", sWin->windowVelocity);

	int jointNum = (sWin->m_jointList->value()) - 1;
	if (jointNum >= 0)
	{
		Joint* joint = sWin->getArtObj()->getJoint(jointNum);
		sWin->windowVelocity->setJoint(joint);

		sWin->windowVelocity->show();
	}
	else
	{
		if (sWin->getArtObj()->getNumJoints() == 0)
		{
			fltk::alert("Velocities cannot be shown because this skeleton\nhas no joints. Please add a joint first.");
		}
		else
		{
			Joint* joint = sWin->getArtObj()->getJoint(0);
			sWin->windowVelocity->setJoint(joint);
			sWin->windowVelocity->show();
		}
	}

}

void ArticulatedObjectWindow::attachments_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	Preference::getWindowPreference("ArticulatedObject.attachmentwindow", sWin->windowAttachments);

	int jointNum = (sWin->m_jointList->value()) - 1;
	if (jointNum >= 0)
	{
		Joint* joint = sWin->getArtObj()->getJoint(jointNum);
		sWin->windowAttachments->setJoint(joint);

		sWin->windowAttachments->show();
	}
	else
	{
		if (sWin->getArtObj()->getNumJoints() == 0)
		{
			fltk::alert("Attachments cannot be shown because this skeleton\nhas no joints. Please add a joint first.");
		}
		else
		{
			Joint* joint = sWin->getArtObj()->getJoint(0);
			sWin->windowAttachments->setJoint(joint);
			sWin->windowAttachments->show();
		}
	}
}


void ArticulatedObjectWindow::selectJoint(int jointNum)
{
	if (m_jointList->children() > jointNum + 1)
	{
		m_jointList->value(jointNum + 1);
	}
}


void ArticulatedObjectWindow::loadTopology_button_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;


	const char* last = Preference::getPreferenceValue("ArticulatedObject.lastloadedtopology");

	const char* filename = fltk::file_chooser("Please choose an articulated object description file:", "{*.sd|*.bvh}", (const char*) last);
	if (filename != NULL)
	{
		char buff[2048];
		convertbackslashes((char*) filename, buff);
		Preference::replacePreference("ArticulatedObject.lastloadedtopology", buff);
		dance::writePreferences();

		string f(filename);
		unsigned int loc = f.rfind(".sd");
		if (loc != string::npos)
		{
			int ret = sWin->m_artObj->loadSdfast(buff);
			if (ret)
			{
				sWin->setJointChoices(-1);
				sWin->updateGUI();
			}
			else
			{
				fltk::alert("Could not load topology from file '%s'.", buff);
			}			
			return;
		}
		else
		{
			loc = f.rfind(".bvh");
			if (loc != string::npos)// bvh file
			{
				ifstream file(filename);
				Character* c = ParserBVH::parse("temptopologyloader", file);
				if (c != NULL)
				{
					const char* scaleStr = fltk::input("Scale character by?", "1.0");
					if (scaleStr)
					{
						delete c;
						return;
					}
					double scale = atof(scaleStr);
					if (scale <= 0.0)
						scale = 1.0;
					c->setScale(scale);

					ArticulatedObject* ao = ArticulatedObject::convertCharacterToArticulatedObject(c, (char*) c->getName());
					if (ao != NULL)
					{
						string sdfilename = sWin->getArtObj()->getName();
						sdfilename.append(".sd");
						ao->writeSdFile((char*) sdfilename.c_str());
						int ret = sWin->getArtObj()->loadSdfast((char*) sdfilename.c_str());
						if (ret)
						{
							sWin->setJointChoices(-1);
							sWin->updateGUI();
							string animfilename = sWin->getArtObj()->getName();
							animfilename.append(".bvh");
							ofstream animfile(animfilename.c_str());
							c->saveBVH(animfile);
							((CharacterAnimationSequence*) ao->getAnimationSequence())->load((char*) animfilename.c_str());
							fltk::alert("Topology has been loaded to articulated object '%s' and saved in file '%s'.\nThe scaled animation can be found in '%s'.", sWin->getArtObj()->getName(), sdfilename.c_str(), animfilename.c_str());
						}
						else
						{
							fltk::alert("Could not load topology from file '%s'.", filename);
						}			
						// delete the old .sd file
						dance::removeObject(ao);
					}
					delete c;
					return;
				}
				else
				{
					fltk::alert("Could not load topology from file '%s'.", filename);
				}
			}
		}
	}
}

void ArticulatedObjectWindow::saveTopology_button_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;

	const char* last = Preference::getPreferenceValue("ArticulatedObject.lastsavedtopology");

	const char* filename = fltk::file_chooser("Please choose a location to save the articulated object description file:", "{*.sd}", (const char*) last);
	if (filename != NULL)
	{
		int ret = sWin->m_artObj->writeSdFile((char*) filename);
		if (ret)
		{
			sWin->setJointChoices(-1);
			sWin->updateGUI();

			char buff[2048];
			convertbackslashes((char*) filename, buff);
			Preference::replacePreference("ArticulatedObject.lastsavedtopology", buff);
			dance::writePreferences();

		}
		else
		{
			fltk::alert("Could not save topology to file '%s'.", filename);
		}
	}
}



void ArticulatedObjectWindow::chainchoice_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow *sWin = (ArticulatedObjectWindow *)p;
	int ikChain = (sWin->choiceChains->value()) - 1;

//	danceInterp::OutputMessage("You chose ik chain %d", ikChain);

	if(ikChain == -1)
	{
		sWin->m_artObj->setActiveIKChain(-1);
		sWin->updateGUI();
		return ;
	}

	sWin->m_artObj->setActiveIKChain(ikChain);

/*	sWin->buttonEdit->activate();
	sWin->buttonRemove->activate();
	sWin->buttonActivate->activate();
	sWin->checkButtonShowChain->activate();
*/
	sWin->updateGUI();
}

void ArticulatedObjectWindow::addchain_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow *sWin = (ArticulatedObjectWindow *)p;

	sWin->windowIKChain->setIKChain(NULL);

	Preference::getWindowPreference("ArticulatedObject.ikchainwindow", sWin->windowIKChain);
	sWin->windowIKChain->show();
}

void ArticulatedObjectWindow::editchain_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow *sWin = (ArticulatedObjectWindow *)p;
	int activeChainID = sWin->m_artObj->getActiveIKChain();
	IKChain *activeChain = sWin->m_artObj->getIKChain(activeChainID);

	sWin->windowIKChain->setIKChain(activeChain);
	sWin->windowIKChain->show();
}

void ArticulatedObjectWindow::removechain_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow *sWin = (ArticulatedObjectWindow *)p;
	
	int chainID = sWin->choiceChains->value() - 1;
	if(chainID >= 0)
	{
		IKChain *chain = sWin->m_artObj->getIKChain(chainID);
		sWin->m_artObj->removeIKChain(chain->getName());
	}
}

void ArticulatedObjectWindow::showTarget_cb(fltk::Widget* o, void *p)
{
	ArticulatedObjectWindow *sWin = (ArticulatedObjectWindow *)p;
	if(sWin->checkButtonShowTarget->value())
	{
		sWin->m_artObj->setShowActiveIKTarget(true);
	}
	else
	{
		sWin->m_artObj->setShowActiveIKTarget(false);
	}
}

void ArticulatedObjectWindow::showChain_cb(fltk::Widget* o, void *p)
{
	ArticulatedObjectWindow *sWin = (ArticulatedObjectWindow *)p;
	if(sWin->checkButtonShowChain->value())
	{
		sWin->m_artObj->setShowActiveIKChain(true);
	}
	else
	{
		sWin->m_artObj->setShowActiveIKChain(false);
	}
}

void ArticulatedObjectWindow::activateIK_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow *sWin = (ArticulatedObjectWindow *)p;

	if (sWin->buttonActivateIK->value())
		sWin->m_artObj->setInteractionMode(IK_mode);
	else
		sWin->m_artObj->setInteractionMode(NO_mode);

	sWin->updateGUI();
}

void ArticulatedObjectWindow::inputNumIterations_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow*) p;
	int ikNum = sWin->m_artObj->getActiveIKChain();
	IKChain *chain = sWin->m_artObj->getIKChain(ikNum);
	
	double val = sWin->inputNumIterations->value();

	chain->setIKNumIterations(val);
	sWin->updateGUI();

}
void ArticulatedObjectWindow::keyFrameEditor_button_cb(fltk::Widget *o, void *p)
{
	ArticulatedObjectWindow *sWin = (ArticulatedObjectWindow *)p;
	
	if (!sWin->windowKeyFrameEditor->visible())
	{
		Preference::getWindowPreference("ArticulatedObject.keyframeeditorwindow", sWin->windowKeyFrameEditor);
		sWin->windowKeyFrameEditor->show();
	}
}

void ArticulatedObjectWindow::autogeometry_cb(fltk::Widget* o, void* p)
{ 
	ArticulatedObjectWindow *sWin = (ArticulatedObjectWindow *) p;

	sWin->windowAutoSettings->show();
}

void ArticulatedObjectWindow::autospheres_cb(fltk::Widget* o, void* p)
{ 
	ArticulatedObjectWindow *sWin = (ArticulatedObjectWindow *) p;

	const char* val = fltk::input("Proportions (1 = same as link length, .5 = half link length):", ".5");
	if (val != NULL)
	{
		double size = atof(val);
		ArticulatedObject* ao = sWin->getArtObj();
		// add a sphere for each link
		int numLinks = ao->getNumLinks();
		for (int l = 0; l < numLinks; l++)
		{
			Link* link = ao->getLink(l);
			// determine the size of the sphere
			Vector bodyToJoint;
			link->getParentJoint()->getBodyToJoint(bodyToJoint);
			Vector endEff;
			link->getEndEffector(endEff);
			Vector jointPos;
			link->getWorldCoord(jointPos, bodyToJoint);
			Vector endPos;
			link->getWorldCoord(endPos, endEff);
			double dist = VecDist(jointPos, endPos);

			if (dist < 10e-6)
			{
				continue;		
			}

			double radius = dist * size / 2.0;

			double overlap = .3;

			Vector normBodyToJoint;
			VecCopy(normBodyToJoint, bodyToJoint);
			VecNormalize(normBodyToJoint);
			// fill the link with spheres
			for (int x = 0; x < MAXNUMSPHERES && x < dist / radius / 2.0; x++)
			{

				Vector dir;
				VecNumMul(dir, normBodyToJoint, radius);
				Vector spherePosition = {bodyToJoint[0] - dir[0] + x * -2.0 * (1.0 - overlap) * dir[0], bodyToJoint[1] - dir[1] + x * -2.0 * (1.0 - overlap)* dir[1], bodyToJoint[2] - dir[2] + x * -2.0 * (1.0 - overlap) * dir[2] };
				link->setSphereTranslation(x, spherePosition[0], spherePosition[1], spherePosition[2]);
				link->setSphereScale(x, radius);
				link->setSphereMatrix(x);
				link->setNumSpheres(x + 1);
			}
		}
		ao->setShowingSpheres(true);
	}

	sWin->updateGUI();
	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::performrecord_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow *) p;

	sWin->m_artObj->setRecording(sWin->checkRecord->value());

	sWin->updateGUI();
}

void ArticulatedObjectWindow::performplayback_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow *) p;

	sWin->m_artObj->setPlayback(sWin->checkPlayback->value());

	sWin->updateGUI();
}

void ArticulatedObjectWindow::restitution_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow *) p;
	FloatInput* f = (FloatInput*) o;

	int joint = (sWin->m_jointList->value()) - 1;
	Joint **joints = sWin->m_artObj->getJoints();

	joints[joint]->getOutboardLink()->setRestitution(f->fvalue());

	sWin->updateGUI();
}

void ArticulatedObjectWindow::restitutionall_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow *) p;

	int ret = fltk::ask("Are you sure you want to set\nthe restitution for all links to %f?", sWin->inputRestitution->fvalue());
	if (ret)
	{
		for (int x = 0; x < sWin->m_artObj->getNumLinks(); x++)
			sWin->m_artObj->getLink(x)->setRestitution(sWin->inputRestitution->fvalue());
	}

	sWin->updateGUI();
}

void ArticulatedObjectWindow::automaticinertia_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow *) p;

	// get the geometry for the current joint
	int joint = (sWin->m_jointList->value()) - 1;
	Joint **joints = sWin->m_artObj->getJoints();

	// first check collision geometry
	double invLinkMat[4][4];

	DGeometry* geometry = joints[joint]->getOutboardLink()->getGeometryCollision();	

	if (geometry) 
	{
		joints[joint]->getOutboardLink()->getInvGeometryCollisionTransMat(invLinkMat);
		danceInterp::OutputMessage("Using collision geometry %s for inertia calculation.", geometry->getName());
	}
	else
	{
		// second check normal geometry
		geometry = joints[joint]->getOutboardLink()->getGeometry();
		if (geometry)
		{
			joints[joint]->getOutboardLink()->getInvGeometryTransMat(invLinkMat);
			danceInterp::OutputMessage("Using geometry %s for inertia calculation.", geometry->getName());

		}
		else
		{
			danceInterp::OutputMessage("Could not find geometry on link, cannot automatically calculate inertia. Add a geomery or collision geometry.\n");
			return;
		}
	}		

	double density = sWin->inputDensity->fvalue();

	// determine the moment of inertia
	double objectMat[4][4];
	geometry->getTransMatrix(objectMat);

	double worldMat[4][4];
	joints[joint]->getOutboardLink()->getWTransMat(worldMat);

	double temp[4][4];
	multArray4x4(temp, invLinkMat, worldMat);
	double temp2[4][4];
	multArray4x4(temp2, objectMat, temp);
	
	MomentOfInertiaHelper moiHelper;
	int ok = moiHelper.computeInertia(geometry, density, temp2);
	if (ok)
	{
		// set the mass
		joints[joint]->getOutboardLink()->setMass(moiHelper.mass);

		// set the inertia
		double moments[3];
		moments[0] = moiHelper.inertia[X][X];
		moments[1] = moiHelper.inertia[Y][Y];
		moments[2] = moiHelper.inertia[Z][Z];
		joints[joint]->getOutboardLink()->setMoments(moments);

		sWin->updateGUI();
	}
	else
	{
		danceInterp::OutputMessage("Inertia could not be computed properly. Old inertial values maintained.");
	}
}

void ArticulatedObjectWindow::autolimits_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow *) p;

	sWin->windowAutoLimits->show();

	sWin->updateGUI();
}

void ArticulatedObjectWindow::inputQuaternion_input_cb(fltk::Widget* o, void* p)
{
	ArticulatedObjectWindow* sWin = (ArticulatedObjectWindow *) p;

	int joint = (sWin->m_jointList->value()) - 1;
	Joint **joints = sWin->m_artObj->getJoints();

	if (joints[joint]->getJointType() != J_BALL)
	{
		danceInterp::OutputMessage("Joint is not a ball joint. Quaternions do not apply.");
		return;
	}

	Vector axis = { sWin->inputQuaternionAxis[0]->fvalue(), sWin->inputQuaternionAxis[1]->fvalue(), sWin->inputQuaternionAxis[2]->fvalue() };
	double angle = sWin->inputQuaternionAngle->fvalue();
	joints[joint]->setState(0, axis[0]);
	joints[joint]->setState(1, axis[1]);
	joints[joint]->setState(2, axis[2]);
	joints[joint]->setState(3, angle);

	sWin->m_artObj->updateStateConfig();

	Quaternion q(axis[0], axis[1], axis[2], angle);
	Matrix3x3 matrix;
	q.toMatrix(matrix);
	VectorObj angles;
	matrix.matToEuler(Matrix3x3::XYZ, angles, true);

	for (int x = 0; x < 3; x++)
	{
		sWin->inputRotate[x]->value(angles[x] * 180.0 / M_PI);
		sWin->sliderRotate[x]->value(angles[x]  * 180.0 / M_PI);
	}

	dance::AllViews->postRedisplay();
}

void ArticulatedObjectWindow::setQuaternionValuesFromEulerAngles(double x, double y, double z, Quaternion* q)
{
	Matrix3x3 xrot;
	xrot.setRotateMatrix(Matrix3x3::X, x);

	Matrix3x3 yrot;
	yrot.setRotateMatrix(Matrix3x3::Y, y);

	Matrix3x3 zrot;
	zrot.setRotateMatrix(Matrix3x3::Z, z);

	Matrix3x3 final;
	final = zrot * yrot * xrot; 

	q->fromMatrix(final);

	///// FOR debugging
	//VectorObj euler(x,y,z) ;
	//Matrix3x3 m; 
	//m.matFromEuler(Matrix3x3::XYZ,euler) ;
	//q->fromMatrix(m) ;
	//
	
	
}
