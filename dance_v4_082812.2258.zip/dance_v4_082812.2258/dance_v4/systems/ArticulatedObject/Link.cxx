/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "Link.h"
#include "defs.h"
#include "dance.h"
#include "danceInterp.h"
#include "DObjectList.h"
//#include "IndexedFaceSet.h"

#include "DSimulator.h"
#include "ViewManager.h"
#include "DView.h"
#include "GLutilities.h"
//#include "VCollide.h"
#include "ArticulatedObject.h"
#include "Joint.h"
#include "InertiaTensor.h"

#include <assert.h>
#include <fltk/glut.h>

////////////////////////////////
//// GLOBALS
////////////////////////////////

#define BINSIZE 100

// constructor that sets the link number too
Link::Link(int ln)
: m_isShowingInertia( false ),
  m_showGlobalAxes( false )
{
    m_linkNumber = ln ;
    sprintf(m_name, "link%u", ln) ;

    setArticulatedObject(NULL);
    parentLink = NULL ;
    parentJoint	= NULL ;
    m_numChildLinks = 0 ;

    setIdentMat(&m_transMat[0][0],4) ;
    setIdentMat(&m_invGeom[0][0],4) ;
    setIdentMat(&m_invGeomCollision[0][0],4) ;
    setIdentMat(&m_invGeomProp[0][0],4) ;
    invSmart4(m_invTransMat,m_transMat) ;
    m_endEffector[0] = m_endEffector[1] = m_endEffector[2] = 0.0;
	
	// Geometry properties.
    m_geom = NULL;
    m_geomScale[0] = m_geomScale[1] = m_geomScale[2] = 1.0;
    m_geomFix = false;

	// Collision geometry properties
	m_geomCollision = NULL;
    m_geomScaleCollision[0] = m_geomScaleCollision[1] = m_geomScaleCollision[2] = 1.0;
    m_geomFixCollision = false;

	// Prop geometry properties
	m_geomProp = NULL;
    m_geomScaleProp[0] = m_geomScaleProp[1] = m_geomScaleProp[2] = 1.0;
    m_geomFixProp = false;


	setShowGeometryCollision(false);

	// Viewing properties.
	m_DisplayGeometry = TRUE ;
	m_DisplayAxes = FALSE ;
	m_DisplayBoundingBox = FALSE;
	m_DisplayNormals = FALSE ;
	setDisplayMonitorPoints(false);

	m_Transparency = 0.0;

	// Mass Properties.
    m_Mass = 1.0 ;
    m_InerTensorIsDiagonal = 1;
	zeroVector(this->m_cm);

    for( int i = 0 ; i < 3 ; i++ )
	{
		for( int j = 0 ; j < 3 ; j++ )
		{
			if (i == j)
				m_InerTensor[i][j] = .1666 ; // start with inertia tensor of cube
			else
				m_InerTensor[i][j] = 0.0 ;
		}
	}   

	this->setNumSpheres(0);

	for (int x = 0; x < MAXNUMSPHERES; x++)
	{
		zeroVector(this->m_sphereTranslation[x]);
		this->m_sphereScale[x] = 1.0;
		setIdentMat(&this->m_sphereMatrix[x][0][0], 4);
	}

	this->setExplicitMonitorPoints(false);
	this->setRandomMonitorPoints(false);
	this->setExplicitMonitorPointsCollision(false);
	this->setRandomMonitorPointsCollision(false);

	this->setRestitution(.1);
	this->m_attachment = NULL;
	this->m_attachmentLinkNum = -1;
	this->m_attachmentStatic = NULL;
}

Link::~Link()
{
	// NOTE: Geometry deletion is handled by the Geometry instance itself. Do not
	// delete it twice here.

	// Remove references to link and parent joint from articulated object. We do
	// this here because it must be done for every link in subtree.
	int found = -1;
	Link **wlink = m_ao->getLinks();
	int numLinks = m_ao->getNumLinks();
	for (int i = 0; i < numLinks; i++)
		if (wlink[i] == this) {
			found = i;
			break;
		}

	assert(found != -1);
	Joint **wjoint = m_ao->getJoints();
	int numJoints = m_ao->getNumJoints();

	// Remove link and joint from articulated figure list.
	if (found < numLinks-1) { 
		memcpy(&wlink[found],&wlink[found+1],sizeof(Link *)*(numLinks-1-found));
		memcpy(&wjoint[found],&wjoint[found+1],sizeof(Joint *)*(numJoints-1-found));
	}
	m_ao->m_numJoints--;
	m_ao->m_numLinks--;
	
	// Remove parent joint and all its hooks.
	if (parentJoint)
		delete parentJoint;

	// Remove all child links.
	int numChildren = m_numChildLinks;
	for (int c = numChildren - 1; c >= 0; c--)
		delete childLink[c];
	m_numChildLinks = 0;
}


// writeSdFile():
// writes the info of a	link and its parent joint on sdfast format
// Question marks allow	for quantities to be modified at a later stage.
// NOTE: sdfast	uses the minus sign convention for off-diagonal	elements.
// this	routines assumes that the inertia tensor is already calculated
// properly.
int Link::writeSdFile(FILE *fp)
{
    int	i ;

    fprintf(fp,"body = %s ",getName()) ;
    if(	parentLink == NULL)
	fprintf(fp,"inb	= $ground ");
    else
	fprintf(fp,"inb	= %s ",	parentLink->getName()) ;

    if (parentJoint == NULL) return 0;

	switch (parentJoint->getJointType())
    {
		case J_PIN:
			fprintf(fp,"joint = pin\n")	;
			break ;
		case J_PLANAR:
			fprintf(fp,"joint = planar\n")	;
			break ;
		case J_BALL:
			fprintf(fp,"joint = ball\n") ;
			break ;
		case J_CYLINDER:
			fprintf(fp,"joint = cylinder\n") ;
			break ;
		case J_SLIDER:
			fprintf(fp,"joint = slider\n") ;
			break ;
		case J_FREE:
			fprintf(fp,"joint = free\n") ;
			break ;
		case J_GIMBAL:
			fprintf(fp,"joint = gimbal\n") ;
			break ;
		case J_UNIVERSAL:
			fprintf(fp,"joint = ujoint\n") ;
			break ;
		case J_BUSHING:
			fprintf(fp,"joint = bushing\n") ;
			break ;
		case J_BEARING:
			fprintf(fp,"joint = bearing\n") ;
			break ;
		case J_WELD:
			fprintf(fp,"joint = weld\n") ;
			break ;
		default:
			fprintf(fp,"Unkonw type of joint!\n") ;
			return ERR ;
    }
    fprintf(fp,"\tmass = %f\n",	m_Mass) ;
    fprintf(fp,"\tinertia = ") ;
    // print the inertia matrix. If the	matrix is diagonal
    // exploit it and print only the diagonal elements.
    // That makes the dynamics run faster.
    if (m_InerTensorIsDiagonal)
		fprintf(fp,"%f %f %f\n",m_InerTensor[0][0], m_InerTensor[1][1],m_InerTensor[2][2]) ;
    else
    {
		// sdfast follows the minus sign covention for non-diagonal elements
		fprintf(fp,"%f %f %f\n",m_InerTensor[0][0],m_InerTensor[0][1],m_InerTensor[0][2]) ;
		fprintf(fp,"\t\t%f %f %f\n",m_InerTensor[1][0],m_InerTensor[1][1],m_InerTensor[1][2])	;
		fprintf(fp,"\t\t%f %f %f\n",m_InerTensor[2][0],m_InerTensor[2][1],m_InerTensor[2][2])	;
    }

    Vector inbToJ ;
    Vector outToJ ;

	VecCopy(inbToJ, parentJoint->getInbToJoint());
    //if( parentJoint->inboardLink != NULL )
    //	rotPoint_mat4(inbToJ,parentJoint->inboardLink->m_transMat) ;
    if(	m_linkNumber == 0)
	fprintf(fp,"\tinbtojoint = %f %f %f\n", inbToJ[0], inbToJ[1],inbToJ[2]) ;
    else
	fprintf(fp,"\tinbtojoint = %f %f %f\n",	inbToJ[0], inbToJ[1],inbToJ[2])	;

	VecCopy(outToJ, parentJoint->getBodyToJoint()) ;
    //rotPoint_mat4(outToJ,parentJoint->outboardLink->m_transMat)	;
    fprintf(fp,"\tbodytojoint =	%f %f %f\n", outToJ[0],	outToJ[1], outToJ[2]) ;

    // print the line that will	allow the axis to be prescribed	if needed
    // by default no presecribed motion	is on
    int	ndof = parentJoint->getNumDof()	;
    for( i = 0 ; i < parentJoint->getNumDof() ;	i++ )
    {
	if( i == 0)
	    fprintf(fp,"\tprescribed = 0?") ;
	else
	    fprintf(fp," 0?") ;
	if( i == (ndof-1))
	    fprintf(fp,"\n") ;
    }



    // print the pin axis
	double axis[6][3];
	parentJoint->getAxis(axis);
	for( i = 0 ; i < parentJoint->getNumAxis(); i++)
		fprintf(fp,"\tpin = %f %f %f\n", axis[i][0], axis[i][1], axis[i][2]);

    return OK ;

}

// reads in the	link information and creates a new joint
// It follows only the format produced by the Link::writeSdFile()
Link *Link::readSdfast(FILE *fp)
{
    char line[MAX_LINE];
    char tok[MAX_LINE] ;
    char parent_name[MAX_LINE];
    char joint_type[MAX_LINE] ;
    bool found = false;
	int numAxis = 0, itype = 0;
    Vector bodyToJoint,	inbToJoint, axis[3] ;
    const char* types[12] = {"unknown","pin","ball","cylinder","slider","free",
		       "gimbal","weld","planar","bearing","ujoint","bushing"} ;

    while(!feof(fp) && (found == false))
    {
	fgets(line,MAX_LINE,fp)	;
	sscanf(line,"%s", tok) ;
	if(strcmp(tok,"body") == 0)
	{
	    if(sscanf(line,"body = %s inb = %s joint = %s", getName(),parent_name,
		      joint_type) != 3)
	    {
		danceInterp::OutputMessage("Can't find body line: %s",line) ;
		return NULL ;
	    }
	    else
		found =	TRUE ;
	}
    }

    if(	found != true) danceInterp::OutputMessage("Cannot find body!") ;
    // read mass
    found = FALSE ;
    while(!feof(fp) && (found == false))
    {
	fgets(line,MAX_LINE,fp)	;
	sscanf(line,"\t%s", tok) ;
	if(strcmp(tok,"mass") == 0)
	{
	    if(sscanf(line,"\tmass = %lf", &m_Mass) != 1)
	    {
		danceInterp::OutputMessage("Can't find mass line:%s",line) ;
		return NULL ;
	    }
	    else
		found =	TRUE ;
	}
    }
     if( found != true)	danceInterp::OutputMessage("Cannot find mass!") ;

    // read inertia
    int	alreadyRead = FALSE ;	// read	from inertia
    found = false ;
    while(!feof(fp) && (found == false))
    {
	fgets(line,MAX_LINE,fp)	;
	sscanf(line,"\t%s", tok) ;
	if(strcmp(tok,"inertia") == 0)
	{
	    if(sscanf(line,"\tinertia =	%lf %lf	%lf", &m_InerTensor[0][0],
		      &m_InerTensor[0][1],&m_InerTensor[0][2]) != 3)
	    {
			danceInterp::OutputMessage("Bad inertia line: %s\n",line) ;
			return NULL ;
	    }
	    fgets(line,MAX_LINE,fp) ;
	    alreadyRead	= TRUE ;
	    if(sscanf(line,"\t%lf %lf %lf", &m_InerTensor[1][0],&m_InerTensor[1][1],
		      &m_InerTensor[1][2]) == 3)
	    {
		m_InerTensorIsDiagonal = 0;
		fgets(line,MAX_LINE,fp)	;
		if(sscanf(line,"\t%lf %lf %lf",	&m_InerTensor[2][0],
			  &m_InerTensor[2][1],&m_InerTensor[2][2]) != 3)
		{
		    danceInterp::OutputMessage("Bad inertial values: %s\n",line) ;
		    return NULL	;
		}
		found =	TRUE ;
		alreadyRead = FALSE ;
	    }
	    else // The inertia tensor is a diagonal matrix with three moments of inertia.
	    {
		found =	TRUE ;
		// bring it in diagonal	form
		m_InerTensorIsDiagonal = 1;
		m_InerTensor[1][1] = m_InerTensor[0][1] ;
		m_InerTensor[2][2] = m_InerTensor[0][2] ;
		for(int i = 0 ; i < 3 ; i++ )
		    for (int j = 0 ; j < 3 ; j ++)
				if (i != j) m_InerTensor[i][j] = 0.0 ;
	    }	
	}
    }
    
    if( found != TRUE)	danceInterp::OutputMessage("Cannot find inertia!\n") ;
    
    // read inb	to joint
	int numFound = 0;
    found = false;
    while(!feof(fp) && (numFound != 2))
    {
	//danceInterp::OutputMessage("Reading inbtojoint\n") ;
	if( alreadyRead	== FALSE )
	{
	    fgets(line,MAX_LINE,fp) ;
	}
	else alreadyRead = FALSE ;
	sscanf(line,"\t%s", tok) ;
	char dummy[50] ;
	if( (strcmp(tok,"inbtojoint") == 0) || (strcmp(tok, "inbToJoint") == 0))
	{
	    numFound++  ;
	    //danceInterp::OutputMessage("This is |%s|",line) ;
	    //danceInterp::OutputMessage("Link number = %d\n", m_linkNumber) ;
	    if(sscanf(line,"\t%s = %lf %lf %lf", dummy,
		      &inbToJoint[0],&inbToJoint[1], &inbToJoint[2]) != 4)
	    {
		if(sscanf(line,"\t%s = %lf? %lf? %lf?", dummy,
			  &inbToJoint[0],&inbToJoint[1], &inbToJoint[2]) != 4)
		{
		    danceInterp::OutputMessage("Bad inbtojoint with link: %s\n",line);
		    return NULL	;
		}
	    }
	}
	else if( (strcmp(tok,"bodytojoint") == 0) || (strcmp(tok,"bodyToJoint") == 0) )
	{
	    numFound++ ;
	    if(sscanf(line,"\t%s = %lf	%lf %lf", dummy,
		      &bodyToJoint[0],&bodyToJoint[1], &bodyToJoint[2])	!= 4)
	    {
		danceInterp::OutputMessage("7:Wrong format of input file. Aborting!\n") ;
		return NULL ;
	    }
	}
    }
    if (numFound != 2)
	danceInterp::OutputMessage("WARNING: No inbtojoint or bodytojoint"
				"found for link %d\n", m_linkNumber) ;


    // find the	type of	the Joint

    found = false;
	numFound = 0;
    for(int i = J_UNDEF ; i <= J_BUSHING && (found	== FALSE) ; i++)
    {
		if( strcmp(joint_type,types[i])	== 0)
		{
			itype = i ;
			found = true;
			numFound = 1;
		}
    }

    if (found == false)
    {
		danceInterp::OutputMessage("Unknown	type of	joint! Aborting\n") ;
		return NULL ;
    }

    //-- read axis---
    // first see how many axis we expect
    switch(itype)
    {
		case J_PIN:
			numAxis =	1 ;
			break ;
		case J_PLANAR:
			numAxis = 3 ;
			break ;
		case J_FREE:
			numAxis =	3 ;
			break ;
		case J_BALL:
			numAxis =	0 ;
			break ;
		case J_GIMBAL:
			numAxis =	3;
			break;
		case J_UNIVERSAL:
			numAxis =	2 ;
			break ;
		case J_WELD :
			numAxis = 0 ;
			break ;
		default:
			danceInterp::OutputMessage("Not implemented yet!\n") ;
			break ;
    }


    // now read	them
    for (int i = 0 ; i < numAxis ; i++)
    {

		found =	false ;
		if (feof(fp))
			danceInterp::OutputMessage("END\n") ;
		while(!feof(fp)	&& (found == false))
		{
			fgets(line,MAX_LINE,fp) ;
			sscanf(line,"\t%s",	tok) ;
			// danceInterp::OutputMessage("|%s|",line) ;
			if(	strcmp(tok,"prescribed") == 0) // consume the prescribed motion	line
				continue ;
			if(strcmp(tok,"pin") == 0)
			{
				found =	true ;
				if(sscanf(line,"\tpin =	%lf %lf	%lf",&axis[i][0],&axis[i][1], &axis[i][2]) != 3)
				{
					danceInterp::OutputMessage("8:Wrong format of input file. Aborting!\n")	;
					return NULL	;
				}
			}
		}

		if (found == false)
		{
			danceInterp::OutputMessage("readSdfast:	missing	axis information! Aborting!\n")	;
			return NULL	;
		}
    }

    /****** Debugging **********
    danceInterp::OutputMessage("mass: %f\n", m_Mass) ;
    danceInterp::OutputMessage("axis read:\n") ;
    for( i = 0 ; i < numAxis ; i++ )
	danceInterp::OutputMessage("pin = %f %f %f\n", axis[i][0], axis[i][1], axis[i][2]) ;

    danceInterp::OutputMessage("inertia read:\n") ;
    for( i = 0 ; i < 3 ; i++ )
	danceInterp::OutputMessage("%f %f %f\n", m_InerTensor[i][0], m_InerTensor[i][1], m_InerTensor[i][2]) ;

    danceInterp::OutputMessage("Inboard = %s name =	%s joint type =	%s\n", parent_name, name, joint_type) ;
    *****************************/

    // ***********************************************************************
    // now all the information we need is found. Fill in all the proper	fields
    // and create the joint
    // ***********************************************************************


    // find and	set parent

    setParentLink(NULL)	;
    if(	strcmp(parent_name,"$ground") != 0)
    {
	Link **links = m_ao->getLinks() ;
	int i;
	for (i = 0 ; i < m_ao->getNumLinks() ; i++ )
	{
	    if(strcmp(links[i]->getName(), parent_name)	== 0 )
		setParentLink(links[i])	;
	}
	if (parentLink == NULL )
	{
	    danceInterp::OutputMessage("Couldn't find parent link with the name %s\n", parent_name)	;
	    return NULL	;
	}
    }

    // define the coordinate system
    Link *pl = getParentLink() ;
    CoordSystem	cs;
    setVector(cs.x, 1.0,0.0,0.0) ;
    setVector(cs.y, 0.0,1.0,0.0) ;
    setVector(cs.z, 0.0,0.0,1.0) ;
    VecSubtract(cs.origin, inbToJoint, bodyToJoint) ;

    // give the link an end effector.
    // A good guess is the -bodyToJoint 
    Vector endeff ;
    VecNumMul(endeff, bodyToJoint, -1) ;
    setEndEffector(endeff) ;

    if(	pl != NULL )
    {
	Vector parent_position ; pl->getPosition(parent_position) ;
	VecAdd(cs.origin, parent_position, cs.origin) ;
    }
    setCenterMass(m_transMat[3]) ;

    setTransMat(cs);

    // allocate	joint and fill in the fields
    // Caution!! All link fields must be properly set
    // to ensure that the joint	is created properly
    Joint *joint = new Joint;
    if(	joint == NULL)
    {
		danceInterp::OutputMessage("Cannot allocate joint!\n") ;
		return NULL ;
    }

    joint->create(m_ao->getNumJoints(), itype,pl, this) ;
	joint->setNumAxis(numAxis);
    for(int a = 0 ; a < numAxis ; a++)
	{
		joint->setAxis(a, axis[a]);
	}

	// Make special axes for BALL joint.
	if (itype == J_BALL)
	{
		Vector temp = {1.0, 0.0, 0.0};
		joint->setAxis(0, temp);
		temp[0] = 0.0; temp[1] = 1.0; temp[2] = 0.0;
		joint->setAxis(1, temp);
		temp[0] = 0.0; temp[1] = 0.0; temp[2] = 1.0;
		joint->setAxis(2, temp);
	}

	joint->setInbToJoint(inbToJoint);
	joint->setBodyToJoint(bodyToJoint);
    // add joint in the	articulated object
    m_ao->addJoint(joint);


    // set parent joint	for the	link
    setParentJoint(joint);

    danceInterp::OutputMessage("Read joint %s\n", joint->getName()) ;
    return this	;
}

//
//	mode: 1	for axes and origin, 2 for bounding box	of geometry,
//	      4	for bounding boxes for links, 8	for shadows, 16	for wire frame,
//	      32 for solid, 64 for monitor points
void Link::Display(int mode)
{
    glPushAttrib(GL_ENABLE_BIT);

	
	bool noskip = true ;
	if( mode & LDISPLAY_SELECTION )  noskip = false ;
    
	DGeometry* g = NULL;
	if (this->m_ao->isShowingCollisionGeometry() || this->isShowGeometryCollision())
	{
		g = m_geomCollision;
	}
	else
	{
		g = m_geom;
	}

	if( isShowingInertia() )
	{
		glPushMatrix() ;
		{
			glMultMatrixd(&m_transMat[0][0]);
			m_totalInertia.display( mode );
		}
		glPopMatrix();
	}

	if( m_showGlobalAxes )
	{
		Vector axes[3];
		static double origin[3] = {0.0,0.0,0.0};
		static double length = 0.1;
		glPushMatrix();
		{
			glTranslated( m_transMat[3][0], m_transMat[3][1], m_transMat[3][2] );
			glDisable( GL_LIGHTING );
			for( int i = 0; i < m_ao->getNumSimulators(); ++i )
			{
				DSimulator* sim = m_ao->getSimulator(i);
				if( !sim ) return;
				for( int j = 0; j < 3; ++j ) for( int k = 0; k < 3; ++k ) axes[j][k] = 0.0;
				sim->getGlobalAxes( getNumber(), axes );
				glColor3f(1.0,0.0,0.0);
				GLdrawVector(origin, axes[0], length);
				glColor3f(0.0,1.0,0.0);
				GLdrawVector(origin, axes[1], length);
				glColor3f(0.0,0.0,1.0);
				GLdrawVector(origin, axes[2], length);
			}
		}
		glPopMatrix();
		glPushMatrix();
		{
			glMultMatrixd(&m_transMat[0][0]);
			for( int i = 0; i < m_ao->getNumSimulators(); ++i )
			{
				DSimulator* sim = m_ao->getSimulator(i);
				if( !sim ) return;
				Vector linkAxes[3];
				sim->getComputedLinkAxes( getNumber(), linkAxes );

				length = 0.12;
				glColor3f(0.5,0.0,0.0);
				GLdrawVector(origin, linkAxes[0], length);
				glColor3f(0.0,0.5,0.0);
				GLdrawVector(origin, linkAxes[1], length);
				glColor3f(0.0,0.0,0.5);
				GLdrawVector(origin, linkAxes[2], length);
			}
		}
		glPopMatrix();
	}

	DGeometry* prop = this->getGeometryProp();
	if (g != NULL || prop != NULL)
	{
			
		// Do something if in collision.
/*		if (m_InCollision == TRUE && noskip)
		{
			glPushAttrib(GL_ENABLE_BIT);
			glDisable(GL_LIGHTING);
			glColor4f(1.0,0.0,0.0,1.0);
			displayBoundingBox(1.0,0.0,0.0,1.0);
			glPopAttrib();
		}
*/		
		glPushMatrix() ;
		glMultMatrixd(&m_transMat[0][0]);

		if (noskip)
		{
		    
			if (m_DisplayAxes) 
				displayAxes();
		    
			// Bounding box	is in world coordinates, don't multiply	again by m_transMat
			if (m_DisplayBoundingBox)
			{
				glPushAttrib(GL_ENABLE_BIT);
				glDisable(GL_LIGHTING);
				if (g != NULL)
					g->displayBoundingBox((float)0.0,(float)0.0,(float)0.7,(float)1.0);
				glPopAttrib();
			}
		}
	
		if (mode & (unsigned int) (LDISPLAY_WIRE | LDISPLAY_SOLID | LDISPLAY_COMPUTE_SHADOW_MAP |  LDISPLAY_USE_SHADOW_MAP ))
		{    
			if (fabs((double)m_Transparency) > 0.01)
			{			
				// Set blending parameters.
				glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				glEnable(GL_BLEND);
				
				// Adjust geometry transparency level.
				if (g != NULL)
					g->setTransparency(m_Transparency);
				if (prop != NULL)
					prop->setTransparency(m_Transparency);
			}
		    
			//MonitorPoints *mptsStruct = getMonitorPoints() ;
		    
			//glPointSize(4) ;
			//glBegin(GL_POINTS) ;
			//for( int i = 0 ; i < mptsStruct->m_NumPoints ; i++ )
			//{
			//	glColor3f(1.0, 0.0, 0.0) ;
			//	glVertex3dv(mptsStruct->m_Point[i]) ;
			//}
			//glEnd() ;
			//glPointSize(1) ;

			if (m_geomFix)
			{
				if (this->m_ao->isShowingCollisionGeometry() || this->isShowGeometryCollision())
					glScaled(m_geomScaleCollision[0], m_geomScaleCollision[1], m_geomScaleCollision[2]);						
				else
					glScaled(m_geomScale[0], m_geomScale[1], m_geomScale[2]);
			}
		    
			if (isDisplayMonitorPoints())
			{
				if (this->m_ao->isShowingCollisionGeometry() || this->isShowGeometryCollision())
					displayMonitorPointsCollision() ;
				else
					displayMonitorPoints() ;
			}
		    
			// display normals
			if (m_DisplayNormals && noskip)
			{
				if (g != NULL)
					g->displayNormals();
			}
		    
			// display object
			if( m_DisplayGeometry == TRUE )
			{
				glPushMatrix();
				if (this->m_ao->isShowingCollisionGeometry() || this->isShowGeometryCollision())
				{
					// multiply by inverse transformation matrix
					glMultMatrixd(&m_invGeomCollision[0][0]);
				}
				else
				{
					// multiply by inverse transformation matrix
					glMultMatrixd(&m_invGeom[0][0]);
				}
				//g->display(mode);
				if (g != NULL)
					g->output(mode);
				glPopMatrix();
				
				// display the prop
				if (this->getGeometryProp() != NULL)
				{
					glPushMatrix();
					glMultMatrixd(&m_invGeomProp[0][0]);
					prop->output(mode);
					glPopMatrix();
				}
			}
		    
			if (fabs((double)m_Transparency) > 0.01)
			{ 
				glDisable(GL_BLEND);
				if (g != NULL)
					g->setTransparency(0.0);
				if (prop != NULL)
					prop->setTransparency(0.0);
			}
		    
		}
		
		glPopMatrix() ;
    }

	// draw sphere
	if (this->getArticulatedObject()->isShowingSpheres())
	{
		glPushAttrib(GL_CURRENT_BIT);
		glEnable(GL_LIGHTING);
		this->getArticulatedObject()->getSphereMaterial()->setOpenGLMaterial();
//		glColor3fv(this->getArticulatedObject()->getSphereMaterial()->getDiffuseColor());
//		this->getArticulatedObject()->getSphereMaterial()->setOpenGLMaterial();
		glPushMatrix() ;
		glMultMatrixd(&m_transMat[0][0]);
		for (int s = 0; s < this->getNumSpheres(); s++)
		{
			glPushMatrix();
			glMultMatrixd(&m_sphereMatrix[s][0][0]);
			glutSolidSphere(1, 10, 10);
			glPopMatrix();
		}
		glPopMatrix();
		glPopAttrib();
	}

	if (m_geom == NULL || m_ao->isShowingLinks() == true) 
	{
		// No geometry, draw default geometry.
		double pos[3]; getPosition(pos);
	
		int lightsOn = glIsEnabled(GL_LIGHTING);
		if (lightsOn)
			glDisable(GL_LIGHTING);
		
		// Draw an end-effector
		if (noskip)
		{
			if (getNumChildLinks() == 0)
			{
/*				double pos[3], endeffector[3];
				getPosition(pos);
				getEndEffectorWC(endeffector);
				glLineWidth(2.0);
				glEnable(GL_LINE_STIPPLE);
				glLineStipple(1,0x00ff);
				glColor3f(1.0,0.0,1.0);
				glBegin(GL_LINES);
				glVertex3dv(pos);
				glVertex3dv(endeffector);
				glEnd();
				glDisable(GL_LINE_STIPPLE);
				glLineWidth(1.0);
*/
			}
		}

		glPushMatrix();
		glColor3d(0.4, 0.4, 0.4);
		glMultMatrixd(&m_transMat[0][0]);
		glutWireSphere(0.01, 10, 10);
		glPopMatrix();
	/*
		glDisable(GL_DEPTH_TEST);
		glDepthFunc(GL_ALWAYS);
		glPointSize(10.0);
		glColor3f(0.0f,1.0f,0.0f);
		glBegin(GL_POINTS);
		glVertex3dv(pos);
		glEnd();
		glDepthFunc(GL_LESS); // Default
	*/
	
    }

	glPopAttrib();


	/*
	// show the tetrahedron

	static double tetra[4][3] = {
		1.0, 1.0, 1.0, 
		1.0, -1.0, -1.0, 
		-1.0, -1.0, 1.0, 
		-1.0, 1.0, -1.0
	};



	glPushAttrib(GL_ENABLE_BIT | GL_DEPTH_BUFFER_BIT);
//	glDisable(GL_LIGHTING);
	glPushMatrix();
	glColor3f(1.0, 1.0, 0.0);
	double matrix[4][4];
	setIdentMat(&matrix[0][0], 0);
	this->getTransMat(matrix);
	for (int x = 0; x < 3; x++)
		matrix[3][x] = 0.0;
	glMultMatrixd(&matrix[0][0]);
	// scale by the size of the link
	this->getTransMat(matrix);
	Vector jointLoc = {0.0, 0.0, 0.0};
	this->getParentJoint()->getBodyToJoint(jointLoc);
	transformPoint_mat(jointLoc, matrix);
	Vector endEffector;
	this->getEndEffector(endEffector);
	transformPoint_mat(endEffector, matrix);
	Vector length;
	VecSubtract(length, endEffector, jointLoc);
	double max = abs(length[0]);
	if (max < abs(length[1])
		max = abs(length[1]);
	if (max < abs(length[2])
		max = abs(length[2]);
	glScalef(
	

	glRotated(-125.0, 0.0, 0.0, 1.0);
	glRotated(-45.0, 0.0, 1.0, 0.0);
	glutSolidTetrahedron();
	//glBegin(GL_LINE_STRIP);
	//glVertex3dv(tetra[1]);
	//glVertex3dv(tetra[2]);
	//glVertex3dv(tetra[3]);
	//glVertex3dv(tetra[0]);
	//glVertex3dv(tetra[3]);
	//glVertex3dv(tetra[2]);
	//glVertex3dv(tetra[0]);
	//glVertex3dv(tetra[1]);
	//glVertex3dv(tetra[3]);
	//glVertex3dv(tetra[0]);
	//glVertex3dv(tetra[2]);
	//glVertex3dv(tetra[1]);
	//glEnd();
	
	glPopMatrix();


	glPopAttrib();
*/
    
}

// calcBoundingBox:
//	Calculates bounding box	in world coordinates.
//
BoundingBox *Link::calcBoundingBox(BoundingBox *b)
{
    if(	m_geom != NULL )
    {
	// Take	geometry bounding box.
	m_geom->calcBoundingBox(b) ;
	
	if (m_geomFix)
	    b->scale(m_geomScale[0], m_geomScale[1], m_geomScale[2]);
	
	// Now we must adjust it via the m_transMat matrix.
	b->update(m_transMat);
	
	return b ;
    }
    else {
	double pos[3];
	memcpy(pos,m_transMat[3],3*sizeof(double));
	b->xMin	= pos[0]; b->xMax = pos[0];
	b->yMin	= pos[1]; b->yMax = pos[1];
	b->zMin	= pos[2]; b->zMax = pos[2];
	if (m_endEffector[0] < b->xMin) b->xMin =	m_endEffector[0];
	if (m_endEffector[1] < b->yMin) b->yMin =	m_endEffector[1];
	if (m_endEffector[2] < b->zMin) b->zMin =	m_endEffector[2];
	if (m_endEffector[0] > b->xMax) b->xMax =	m_endEffector[0];
	if (m_endEffector[1] > b->yMax) b->yMax =	m_endEffector[1];
	if (m_endEffector[2] > b->zMax) b->zMax =	m_endEffector[2];
	return b;
    }
}

void Link::displayBoundingBox(float r, float g,	float b, float a)
{
    calcBoundingBox(&boundingBox);
    boundingBox.display(r,g,b,a);
}


void Link::setPosition(double p[3])
{
    memcpy(m_transMat[3],p,3*sizeof(double));
    invSmart4(m_invTransMat,m_transMat) ;
}

// Retrieves a list of all children of this link.
int Link::getChildren()
{
	Link **wlink = getChildLinks();
	if (wlink) {
		for (int i =0; i < getNumChildLinks(); i++)
		{
			danceInterp::OutputListElement(wlink[i]->getName());
		}
	}
	return DANCE_OK;
}

void Link::getPosition(double p[3])
{
    memcpy(p,m_transMat[3],3*sizeof(double));
}

void Link::getAxes(double x[3],	double y[3], double z[3])
{
    for	(int i=0; i < 3; i++) {
	 x[i] =	m_transMat[i][0];
	 y[i] =	m_transMat[i][1];
	 z[i] =	m_transMat[i][2];
    }
}

void Link::getEndEffectorWC(double p[3])
{

    double p4[4];
	memcpy(p4,m_endEffector,3*sizeof(double));
	p4[3] = 1.0;
    double p4_t[4];
    double tm[4][4];

    if (m_ao->areLinksRelativeToParent() != true )
	{
		multArray(&p4_t[0],&p4[0],&m_transMat[0][0],1,4,4) ;
	}
    else
    {
		// compute the transf matrix that transforms points form the
		// local cs to the world cs
		getWTransMat(tm) ;
		multArray(&p4_t[0],&p4[0],&tm[0][0],1,4,4);
    }

    // Assumes homogeneous point w is 1.0
    memcpy(p,p4_t,3*sizeof(double));

}

void Link::setEndEffectorWC(double p[3])
{
	getLocalCoord(m_endEffector, p);
}

void Link::getTransMat(double m[4][4])
{
    for( int i = 0 ; i < 4 ; i++ )
	for( int j = 0 ; j < 4 ; j++ )
	    m[i][j] = m_transMat[i][j] ;
}


void Link::getInvTransMat(double m[4][4])
{
    for( int i = 0 ; i < 4 ; i++ )
	for( int j = 0 ; j < 4 ; j++ )
	    m[i][j] = m_invTransMat[i][j]	;
}

// PROC: getWTransMat()
// It calculates the transformation matrix that	transforms
// points form the link	cs to the world	cs.
// Works both when the links are and are  not considered relative to their parents.
void Link::getWTransMat(double tm[4][4])
{
    Link *pl, *lastPl ;
    double tm1[4][4] ;
    int	flip = 0 ;

    D2ArrayCopy(4,4,&tm[0][0], &m_transMat[0][0])	;


    if (m_ao->areLinksRelativeToParent() == true )
    {
		pl = getParentLink() ;
		while( pl != NULL )
		{
			if(	flip ==	0)
			{
				//multArray(&tm1[0][0],&tm[0][0],&pl->m_transMat[0][0],4,4,4) ;
				multArray4x4(tm1, tm, pl->m_transMat);
				flip = 1 ;
			}
			else
			{
				//multArray(&tm[0][0],&tm1[0][0],&pl->m_transMat[0][0],4,4,4) ;
				multArray4x4(tm, tm1, pl->m_transMat);
				
				flip = 0 ;
			}

			lastPl = pl;
			pl = pl->getParentLink() ;
			if (pl == NULL) // multiply by the global matrix if needed
			{
				if (lastPl->getArticulatedObject()->isUseGlobalMatrix())
				{
					double matrix[4][4];
					lastPl->getArticulatedObject()->getGlobalTransMatrix(matrix);
					if(	flip ==	0)
					{
						//multArray(&tm1[0][0],&tm[0][0],&matrix[0][0],4,4,4) ;
						multArray4x4(tm1, tm, matrix);
						flip = 1 ;
					}
					else
					{
						//multArray(&tm[0][0],&tm1[0][0],&matrix[0][0],4,4,4) ;
						multArray4x4(tm, tm1, matrix);
						flip = 0 ;
					}
				}
			}
		}
		if( flip == 1)
			D2ArrayCopy(4,4,&tm[0][0], &tm1[0][0]) ;
    }
}

void Link::getWTransMat(float tm[4][4])
{
	double t[4][4];
	getWTransMat(t);
	for (int i=0; i	< 4; i++)
	    for	(int j=0; j < 4; j++)
		 tm[i][j] = (float)t[i][j];
}

void Link::getOrientation(float	tm[4][4])
{
    double mat[4][4];
    getWTransMat(mat);
    // Remove translational component.
    mat[3][0] =	mat[3][1] = mat[3][2] =	0.0; mat[3][3] = 1.0;

    // Transfer	to a float.
    for	(int i=0; i < 4; i++)
	for (int j=0; j	< 4; j++)
	     tm[i][j] =	(float)mat[i][j];
}

void Link::getOrientation(double tm[4][4])
{
    getWTransMat(tm);
    // Remove translational component.
    tm[3][0] = tm[3][1]	= tm[3][2] = 0.0; tm[3][3] = 1.0;
}

void Link::getRotation(double tm[3][3])
{
    double mat[4][4];
    getWTransMat(mat);
    // Move to 3x3 matrix.
    for (int i = 0; i < 3; i++)
	for (int j = 0; j < 3; j++)
		tm[i][j] = mat[i][j];
}

void Link::setOrientation(int naxis, double v[3])
{
    double t[3];

    if (naxis >	2)
    {
	danceInterp::OutputMessage("setOrientation:	index out of bounds.\n") ;
	return;
    }
    VecCopy(t,v) ;
    VecNormalize(t) ;
    memcpy(m_transMat[naxis],t,3*sizeof(double));
}

void Link::getCoordSystem(CoordSystem *cs)
{
    memcpy(cs->x,m_transMat[0],3*sizeof(double));
    memcpy(cs->y,m_transMat[1],3*sizeof(double));
    memcpy(cs->z,m_transMat[2],3*sizeof(double));
    memcpy(cs->origin,m_transMat[3],3*sizeof(double));
}

void Link::setTransMat(double tm[4][4])
{
    int	i,j ;

    for( i = 0 ; i < 4 ; i++ )
	for( j = 0 ; j < 4 ; j++ )
	    m_transMat[i][j] = tm[i][j] ;
    /* calculate inverse too */
    invSmart4(m_invTransMat,m_transMat) ;
}

void Link::setTransMat(CoordSystem cs)
{
    memcpy(m_transMat[0],cs.x,3*sizeof(double));
    memcpy(m_transMat[1],cs.y,3*sizeof(double));
    memcpy(m_transMat[2],cs.z,3*sizeof(double));
    memcpy(m_transMat[3],cs.origin,3*sizeof(double));

    // calculate inverse too
    invSmart4(m_invTransMat,m_transMat) ;
}

void Link::setOrientation(double tm[4][4])
{
    int	i,j ;
    // ignore the translational	component
    for( i = 0 ; i < 3 ; i++ )
	for( j = 0 ; j < 3 ; j++ )
	    m_transMat[i][j] = tm[i][j] ;
}

// display a link hierarchy in which each link is considered
// relative to each parent link
void Link::displayTree(int mode)
{
    int	i ;

    glPushMatrix() ;		// the transformation matrix is	relative to
				// the previous	link
    glMultMatrixd(&m_transMat[0][0]) ;
    Display(mode)	;

    for( i = 0 ; i < m_numChildLinks ; i++ )
    {
	 childLink[i]->displayTree(mode) ;
     }

    glPopMatrix() ;
    return ;
}

// changeToLocal:
//	Recursively descends link and its children and changes transformation matrices to be
//	relative to its parent.
void Link::changeToLocal()
{
	double tm[4][4] ;

	for(int i = 0 ; i < m_numChildLinks ; i++)
		childLink[i]->changeToLocal() ;

    if(	parentLink != NULL )
    {
		// WC =	WP*PC -> PC = WP^(-1)*WC and all of this
		// transpose so	the other way around
		//multArray(&tm[0][0],&m_transMat[0][0],&parentLink->m_invTransMat[0][0],4,4,4) ;
		multArray4x4(tm,m_transMat, parentLink->m_invTransMat);

		// CAUTION: it has to be after so that the WP are valid
		// through out the whole recursion
		D2ArrayCopy(4,4,&m_transMat[0][0],&tm[0][0]) ;
		// calculate the inverse too
		invSmart4(m_invTransMat,m_transMat)	;
    }
}


// changeToGlobal:
//	Recursively descends link and its children and flattens the hierarchy so each link
//	has the stored global transformation matrix relative to the world.
void Link::changeToGlobal()
{
    double tm[4][4] ;
    int	i ;

    if (parentLink != NULL)
    {
		// WC =	WP*PC and after	transposition WC = PC*WP
		//multArray(&tm[0][0],&m_transMat[0][0],&parentLink->m_transMat[0][0],4,4,4) ;
		multArray4x4(tm, m_transMat, parentLink->m_transMat) ;
	
		// it has to be	right away, because it has to propagate
		// right away for the children
		D2ArrayCopy(4,4,&m_transMat[0][0],&tm[0][0]) ;
		invSmart4(m_invTransMat,m_transMat)	;
	}

    for(i = 0 ;	i < m_numChildLinks ; i++)
		childLink[i]->changeToGlobal() ;
}

void Link::getPoint(int	index, int modifier, double *point)
{
	double wpoint[3];
	switch(index) {
	   case	0:
		getPosition(wpoint);
	   break;
	   case	1:
		getEndEffectorWC(wpoint);
	   break;
	}
	memcpy(point,wpoint,3*sizeof(double));
}

// getLocalCoord:
//	Transforms a world point to local point
void Link::getLocalCoord(double	local[3], double world[3])
{
	double cm[3];
	getPosition(cm);
	VecSubtract(local,world,cm);
	rotPoint_mat4(local,m_invTransMat);
}

void Link::getLocalVector(double local[3], double world[3]) 
{
	VecCopy(local, world) ;
	rotPoint_mat4(local,m_invTransMat);
}

// getWorldCoord:
// Transforms a local point to its world point.
// The world and local can be the same pointer
void Link::getWorldCoord(double world[3], double local[3])
{
	if (this->getNumMonitorPoints() == 0)
    {
		double tm[4][4] ;
		VecCopy(world, local) ;
		getWTransMat(tm) ;
		transformPoint_mat(world,tm) ;
    }
    else
    {
//		DSimulator* simulator = m_ao->getSimulator(0);
//		if (simulator != NULL)
//		{
//			// Use the simulator to get the position information. Potentially more accurate.
//			simulator->GetPosition(m_linkNumber, local, world) ;
//		}
//		else
//		{
			double tm[4][4] ;
			VecCopy(world, local) ;
			getWTransMat(tm) ;
			transformPoint_mat(world,tm) ;
//		}
    }
}

// getWorldNormal:
//	Transforms the local normal to its orientation wrt world frame.
void Link::getWorldNormal(double world[3], double local[3])
{
    double tm[4][4] ;
    getWTransMat(tm) ;
    for (int i = 0; i < 3; i++)
	world[i] = local[0]*tm[0][i] +
	  local[1]*tm[1][i] +
	  local[2]*tm[2][i];
}

int Link::Command(int argc, char **argv)
{
    // check if	the arguments are valid
    if(	argc < 1)
    {
		danceInterp::OutputMessage("ERROR: Expected a command \n") ;
		return DANCE_ERROR ;
    }
    
    // parse the different commands
    int count = 0;
    
    // for compatability, "set" keyword no longer needed.
    if (strcmp(argv[count],"set") == 0) count = 1;
    
    if( (count == 1) && (argc == 1) )
    {
		danceInterp::OutputMessage("set what?\n") ;
		return DANCE_ERROR ;
    }
    // Assigns geometry instance to link.
    if( strcmp(argv[count], "geometry")	== 0 )
	{
		if (argc < 1)
		{
			danceInterp::OutputMessage("Usage: system %s link %s geometry <name> |world|", this->getArticulatedObject()->getName(), this->getName());
			return DANCE_ERROR;
		}
		DGeometry* geometry = dynamic_cast<DGeometry*>(dance::AllGeometry->get(argv[1]));
		if (geometry == NULL)
		{
			danceInterp::OutputMessage("Geometry %s does not exist, cannot be attached to link %s.", argv[1], this->getName());
			return DANCE_ERROR;
		}

		bool useWorldCoords = false;
		if (argc > 2)
		{
			if (strcmp(argv[2], "world") == 0)
				useWorldCoords = true;
		}

		this->replaceGeometry(geometry, useWorldCoords);
		return DANCE_OK;
    }
	else if (strcmp(argv[count], "collision_geometry") == 0 )
	{
		if (argc < 1)
		{
			danceInterp::OutputMessage("Usage: system %s link %s collision_geometry <name> |world|", this->getArticulatedObject()->getName(), this->getName());
			return DANCE_ERROR;
		}
		DGeometry* geometry = dynamic_cast<DGeometry*>(dance::AllGeometry->get(argv[1]));
		if (geometry == NULL)
		{
			danceInterp::OutputMessage("Geometry %s does not exist, cannot be attached to link %s as collision geometry.", argv[1], this->getName());
			return DANCE_ERROR;
		}

		bool useWorldCoords = false;
		if (argc > 2)
		{
			if (strcmp(argv[2], "world") == 0)
				useWorldCoords = true;
		}

		this->replaceGeometryCollision(geometry, useWorldCoords);
		return DANCE_OK;
	}
	else if (strcmp(argv[count], "prop_geometry") == 0 )
	{
		if (argc < 1)
		{
			danceInterp::OutputMessage("Usage: system %s link %s geometry_prop <name> |world|", this->getArticulatedObject()->getName(), this->getName());
			return DANCE_ERROR;
		}
		DGeometry* geometry = dynamic_cast<DGeometry*>(dance::AllGeometry->get(argv[1]));
		if (geometry == NULL)
		{
			danceInterp::OutputMessage("Geometry %s does not exist, cannot be attached to link %s as prop geometry.", argv[1], this->getName());
			return DANCE_ERROR;
		}

		bool useWorldCoords = false;
		if (argc > 2)
		{
			if (strcmp(argv[2], "world") == 0)
				useWorldCoords = true;
		}

		this->replaceGeometryProp(geometry, useWorldCoords);
		return DANCE_OK;
	}
	else if (strcmp(argv[count], "attachment") == 0 )
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: system %s link %s attachment <name> <linknum>", this->getArticulatedObject()->getName(), this->getName());
			return DANCE_ERROR;
		}
		ArticulatedObject* attachAO = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get(argv[1]));
		if (attachAO == NULL)
		{
			danceInterp::OutputMessage("ArticulatedObject %s does not exist, cannot be dynamically attached to link %s.", argv[1], this->getName());
			return DANCE_ERROR;
		}
		int linkNum = atof(argv[2]);
		if (linkNum < 0 || linkNum >= attachAO->getNumLinks())
		{
			danceInterp::OutputMessage("ArticulatedObject %s has %d links. Attachment requested link %d. Attachment not made.", attachAO->getName(), attachAO->getNumLinks(), linkNum);
			return DANCE_ERROR;
		}

		this->setAttachment(attachAO, linkNum);
		Link* otherLink = attachAO->getLink(linkNum);
		danceInterp::OutputMessage("Link %s has been dynamically attached to %s/%s.", this->getName(), attachAO->getName(), otherLink->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[count], "attachment_remove") == 0 )
	{
		if (this->m_attachment == NULL)
		{
			danceInterp::OutputMessage("No attachment to remove from link '%s'.", this->getName());
			return DANCE_ERROR;
		}

		ArticulatedObject* attachAO = this->m_attachment;
		this->setAttachment(NULL, -1);
		danceInterp::OutputMessage("Attachment '%s' had been removed from link '%s'.", attachAO->getName(), this->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[count], "attachment_static") == 0 )
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: system %s link %s attachment_static <name>", this->getArticulatedObject()->getName(), this->getName());
			return DANCE_ERROR;
		}
		DGeometry* attachGeom = dynamic_cast<DGeometry*>(dance::AllGeometry->get(argv[1]));
		if (attachGeom == NULL)
		{
			danceInterp::OutputMessage("Geometry %s does not exist, cannot be staticly attached to link %s.", argv[1], this->getName());
			return DANCE_ERROR;
		}

		this->setAttachmentStatic(attachGeom);
		danceInterp::OutputMessage("Link %s has been staticly attached to %s.", this->getName(), attachGeom->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[count], "attachment_static_remove") == 0 )
	{
		if (this->m_attachmentStatic == NULL)
		{
			danceInterp::OutputMessage("No static attachment to remove from link '%s'.", this->getName());
			return DANCE_ERROR;
		}

		DGeometry* attachGeom = this->getAttachmentStatic();
		this->setAttachmentStatic(NULL);
		danceInterp::OutputMessage("Static attachment '%s' had been removed from link '%s'.", attachGeom->getName(), this->getName());
		return DANCE_OK;
	}

	else if (strcmp(argv[count], "geometry_remove")	== 0 )
	{
		if (m_geom == NULL)
		{
			danceInterp::OutputMessage("No geometry to remove from link '%s'.", this->getName());
			return DANCE_ERROR;
		}
		DGeometry* geometry = m_geom;
		m_geom = NULL;
		setIdentMat(&m_invGeom[0][0], 4);
		m_geom->setVisible(true);
		danceInterp::OutputMessage("Geometry '%s' had been removed from link '%s'.", geometry->getName(), this->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[count], "geometry_collision_remove") == 0 )
	{
		if (m_geomCollision == NULL)
		{
			danceInterp::OutputMessage("No collision geometry to remove from link '%s'.", this->getName());
			return DANCE_ERROR;
		}
		DGeometry* geometry = m_geomCollision;
		m_geomCollision = NULL;
		setIdentMat(&m_invGeomCollision[0][0], 4);
		m_geomCollision->setVisible(true);
		danceInterp::OutputMessage("Collision geometry '%s' had been removed from link '%s'.", geometry->getName(), this->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[count], "geometry_prop_remove") == 0 )
	{
		if (m_geomProp == NULL)
		{
			danceInterp::OutputMessage("No prop to remove from link '%s'.", this->getName());
			return DANCE_ERROR;
		}
		DGeometry* geometry = m_geomProp;
		m_geomProp = NULL;
		setIdentMat(&m_invGeomProp[0][0], 4);
		m_geomProp->setVisible(true);
		danceInterp::OutputMessage("Prop geometry '%s' had been removed from link '%s'.", geometry->getName(), this->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "geom_inv_trans_matrix") == 0)
	{
		if (argc < 17)
		{
			// usage
			return DANCE_ERROR;
		}
		int count = 1;
		double matrix[4][4];
		for (int r = 0; r < 4; r++)
		{
			for (int c = 0; c < 4; c++)
			{
				matrix[r][c] = atof(argv[count]);
				count++;
			}
		}
		this->setInvGeometryTransMat(matrix);
		danceInterp::OutputMessage("Geometry transformation matrix for has been set.", this->getName());
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "collision_geom_inv_trans_matrix") == 0)
	{
		if (argc < 17)
		{
			// usage
			return DANCE_ERROR;
		}
		int count = 1;
		double matrix[4][4];
		for (int r = 0; r < 4; r++)
		{
			for (int c = 0; c < 4; c++)
			{
				matrix[r][c] = atof(argv[count]);
				count++;
			}
		}
		this->setInvGeometryCollisionTransMat(matrix);
		danceInterp::OutputMessage("Collision geometry transformation matrix for has been set.", this->getName());
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "prop_geom_inv_trans_matrix") == 0)
	{
		if (argc < 17)
		{
			// usage
			return DANCE_ERROR;
		}
		int count = 1;
		double matrix[4][4];
		for (int r = 0; r < 4; r++)
		{
			for (int c = 0; c < 4; c++)
			{
				matrix[r][c] = atof(argv[count]);
				count++;
			}
		}
		this->setInvGeometryPropTransMat(matrix);
		danceInterp::OutputMessage("Prop geometry transformation matrix for has been set.", this->getName());
		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}

    // Returns the list of immediate children of this link.
    else if (strcmp(argv[count], "children") == 0)
    {
    	if (argc-1 != count)
		{
			danceInterp::OutputMessage("ERROR: children accepts no extra arguments.");
			return DANCE_ERROR;
		}
		return getChildren();
    }
/*    else if (strcmp(argv[count],"collideID") == 0)
    {
		danceInterp::OutputResult("ID is %d\n",m_VCollideID);
    }
*/
    else if (strcmp(argv[count],"parentJoint") == 0)
    {
		Joint *joint = getParentJoint();
		assert(joint);
		danceInterp::OutputResult("%s", joint->getName());
		return DANCE_OK;
    }
    else if (strcmp(argv[count],"name") == 0)
    {
        if (argc-count-1 == 0)
            danceInterp::OutputResult("%s", getName());
        else
            setName(argv[count+1]);
    }
    else if (strcmp(argv[count],"boundingBox") == 0)
    {
		if (argc-1-count != 1)
		{
			if (m_DisplayBoundingBox == TRUE)
			danceInterp::OutputMessage("on");
			else 
			danceInterp::OutputMessage("off");
			return DANCE_OK;
		}
		if (strcmp(argv[count+1],"on") == 0)
			m_DisplayBoundingBox = TRUE;
		else
			m_DisplayBoundingBox = FALSE;
		if (dance::AllViews->getViewFocus())
			dance::AllViews->getViewFocus()->postRedisplay();
		return DANCE_OK;
    }
    else if (strcmp(argv[count],"displayGeometry") == 0)
    {
		if (argc-1-count != 1)
		{
			if (m_DisplayGeometry == TRUE)
			danceInterp::OutputResult("on");
			else 
			danceInterp::OutputResult("off");
			return DANCE_OK;
		}
		if (strcmp(argv[count+1],"on") == 0)
			m_DisplayGeometry = TRUE;
		else
			m_DisplayGeometry = FALSE;
		if (dance::AllViews->getViewFocus())
			dance::AllViews->getViewFocus()->postRedisplay();
		return DANCE_OK;
    }
	else if (strcmp(argv[count], "displayInertia") == 0)
	{		
		if (argc-1-count != 1)
		{
			if (m_isShowingInertia == true)
				danceInterp::OutputResult("on");
			else 
				danceInterp::OutputResult("off");
			return DANCE_OK;
		}
		if (strcmp(argv[count+1],"on") == 0)
			m_isShowingInertia = true;
		else
			m_isShowingInertia = false;
		if (dance::AllViews->getViewFocus())
			dance::AllViews->getViewFocus()->postRedisplay();
		return DANCE_OK;

	}
    else if (strcmp(argv[count],"normals") == 0)
    {
		if (argc-1-count != 1)
		{
			if (m_DisplayNormals == TRUE)
			danceInterp::OutputMessage("on");
			else 
			danceInterp::OutputMessage("off");
			return DANCE_OK;
		}
		if (strcmp(argv[count+1],"on") == 0)
			m_DisplayNormals = TRUE;
		else
			m_DisplayNormals = FALSE;
		
		if (dance::AllViews->getViewFocus())
			dance::AllViews->getViewFocus()->postRedisplay();
		return DANCE_OK;
    }
    else if (strcmp(argv[count],"axes") == 0)
    {
	if (argc-1-count != 1)
	{
	    if (m_DisplayAxes == TRUE)
		danceInterp::OutputMessage("on");
	    else 
		danceInterp::OutputMessage("off");
	    return DANCE_OK;
	}
	if (strcmp(argv[count+1],"on") == 0)
	    m_DisplayAxes = TRUE;
	else
	    m_DisplayAxes = FALSE;
	
	if (dance::AllViews->getViewFocus())
	    dance::AllViews->getViewFocus()->postRedisplay();
	return DANCE_OK;
    }
    else if (strcmp(argv[count],"resetInbAndOutb") == 0)
    {
	if (argc-1-count == 1) { // check flip
	    if (strcmp(argv[count+1],"flip") == 0) 
		resetInbAndOutb(1);
	}
	else
	    resetInbAndOutb();
	if (dance::AllViews->getViewFocus())
	    dance::AllViews->getViewFocus()->postRedisplay();
	return DANCE_OK;
    }
    else if( strcmp(argv[count], "toworld") == 0 )
    {
	if( argc-1-count == 3)
	{
	    Vector local ;
	    local[0] = atof(argv[count+1]) ;
	    local[1] = atof(argv[count+2]) ;
	    local[2] = atof(argv[count+3]) ;
	    Vector wpoint ;
	    getWorldCoord(wpoint, local) ;
	    danceInterp::OutputListElement("%lf", wpoint[0]) ;
	    danceInterp::OutputListElement("%lf", wpoint[1]) ;
	    danceInterp::OutputListElement("%lf", wpoint[2]) ;
	}
	else
	{
	    danceInterp::OutputResult("toworld: needs x y z") ;
	    return DANCE_ERROR ;
	}
    }
    else if (strcmp(argv[count],"transparency") == 0) 
    {
	if (argc-1-count != 1) 
	    danceInterp::OutputResult("%f",m_Transparency);
	else {
	    m_Transparency = (float)atof(argv[count+1]);
	    if (dance::AllViews->getViewFocus())
			dance::AllViews->getViewFocus()->postRedisplay();
	}
	return DANCE_OK;
    }
    else if (strcmp(argv[count],"mass") == 0) 
    {
		if (argc-1-count != 1)
			danceInterp::OutputResult("%f",m_Mass);
		else 
			this->setMass(atof(argv[count+1]));
		return DANCE_OK;
    }
    else if (strcmp(argv[count],"moments") == 0) 
    {
		if (argc-1-count != 3) {
			danceInterp::OutputListElement("%f",m_InerTensor[0][0]);
			danceInterp::OutputListElement("%f",m_InerTensor[1][1]);
			danceInterp::OutputListElement("%f",m_InerTensor[2][2]);
		}
		else {
			double moments[3];
			moments[0] = atof(argv[count+1]);
			moments[1] = atof(argv[count+2]);
			moments[2] = atof(argv[count+3]);
			setMoments(moments);
		}
	return DANCE_OK;
    }
	else if (strcmp(argv[count],"restitution") == 0) 
    {
		if(argc < count + 1)
		{
			danceInterp::OutputMessage("Usage: dance.system(\"%s\", \"link\", \"%s\", \"restitution\", <val>)", this->getArticulatedObject()->getName(), this->getName());
			return DANCE_ERROR;
		}
		this->setRestitution(atof(argv[count+1]));
		danceInterp::OutputMessage("Restitution for link %s has been set to %f", this->getName(), this->getRestitution());
		return DANCE_OK;
    }
	else if (strcmp(argv[count], "endeffector") == 0) 
    {
		if(argc < count + 3)
		{
			danceInterp::OutputMessage("Usage: dance.system(\"%s\", \"link\", \"%s\", \"endeffector\", <x>, <y>, <z>)", this->getArticulatedObject()->getName(), this->getName());
			return DANCE_ERROR;
		}
		Vector temp;
		for (int x = 0; x < 3; x++)
			temp[x] = atof(argv[count + x + 1]);
		this->setEndEffector(temp);
		danceInterp::OutputMessage("End effector for link %s has been set to (%f, %f, %f)", this->getName(), temp[0], temp[1], temp[2]);
		return DANCE_OK;
    }
    // Scales the geometry in this link.
    else if( strcmp(argv[count], "scale") == 0 )
    {
		if( m_geom == NULL )
		{
			danceInterp::OutputMessage("WARNING: no geometry present.\n") ;
			return DANCE_OK ;
		}
		double scaleX, scaleY, scaleZ ;
		int center = 0 ;
		if( (argc-1-count > 0 ) && (argc-1-count < 3)  )
		{
			double sc = atof(argv[count+1]);
			scaleX = sc ;
			scaleY = sc ;
			scaleZ = sc ;

			if( argc-1-count  == 2 ) center = atoi(argv[count+2]) ;
		}
		else if( (argc-1-count > 2 ) && (argc-1-count < 5) )
		{
			scaleX = atof(argv[count+1]);
			scaleY = atof(argv[count+2]);
			scaleZ = atof(argv[count+3]);
			if( argc-1-count == 4 )  center = atoi(argv[count+4]) ;
		}
		else
		{
			danceInterp::OutputMessage("ERROR: expected \"scale <scale factor>|"
				"<scale factorX factorY factorZ > [<around_center_flag>]\"\n") ;
			return DANCE_ERROR ;
		}
		this->m_geomScale[0] = scaleX ;
		this->m_geomScale[1] = scaleY ;
		this->m_geomScale[2] = scaleZ ;
		this->m_geomFix = true;
		//m_geom->Scale(scaleX, scaleY, scaleZ, center) ;
		return DANCE_OK ;
    }
    else if( strcmp(argv[count], "translate") == 0 )
    {
		if( m_geom == NULL )
		{
			danceInterp::OutputMessage("No geometry present!") ;
			return DANCE_OK ;
		}
		if( argc-1-count != 3)
		{
			danceInterp::OutputMessage("ERROR: expected \"translate <x y >\"") ;
			return DANCE_ERROR ;
		}
		if( m_geom == NULL ) 
		{
			danceInterp::OutputMessage("WARNING: Geometry is NULL.") ;
			return DANCE_OK ;
		}
		double x = atof(argv[count+1]);
		double y = atof(argv[count+2]);
		double z = atof(argv[count+3]);
		m_geom->Translate(x,y,z) ;
		dance::AllViews->postRedisplay();

		return DANCE_OK ;
    }
    else if( strcmp(argv[count], "fit") == 0 )
	{
		FitGeometryToLink(argc-1, &argv[1]) ;
		dance::AllViews->postRedisplay();
		return DANCE_OK ;
	}
    else if( strcmp(argv[count], "center") == 0 )
    {
		if( m_geom == NULL )
		{
			danceInterp::OutputMessage("No geometry present!") ;
			return DANCE_OK ;
		}
		m_geom->Center() ;
		dance::AllViews->postRedisplay();
		return DANCE_OK ;
    }
    else if( strcmp(argv[count], "assign_monitor_points") == 0 || strcmp(argv[count], "assign_monitor_points_random") == 0)
	{
		if( m_geom == NULL )
		{
			danceInterp::OutputMessage("WARNING: there is no geometry for link %s.\n",	getName()) ;
			return DANCE_OK ;
		}
		// if no additional parameters, assign the default monitor points
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: system %s link %s assign_monitor_points <num_points>\nsystem %s link %s assign_monitor_points <x1> <y1> <z1> <x2> <y2> <z2> <x...> <y...> <z...>", this->getArticulatedObject()->getName(), this->getName(), this->getArticulatedObject()->getName(), this->getName());
			return DANCE_ERROR;
		}
		else if (argc == 2)
		{
			int num = atoi(argv[1]);
			if (strcmp(argv[count], "assign_monitor_points_random") == 0)
			{
				assignMonitorPoints(num, true) ;
			}
			else
			{
				assignMonitorPoints(num, false) ;
			}
			danceInterp::OutputMessage("Assigned %d monitor points on link %s", num, this->getName());
			return DANCE_OK;
		}
		else
		{
			Vector *p ;
    
			// collect the monitor points from the command line
			int n =	(argc - 1) / 3 ;
			p =	new Vector[n];
			int i, j;
			for (j = 1, i = 0 ; i < n; i++, j +=3)
			{
				p[i][0]	= atof(argv[j])	;
				p[i][1]	= atof(argv[j+1]) ;
				p[i][2]	= atof(argv[j+2]) ;
			}
			this->assignMonitorPoints(p, n);
			danceInterp::OutputMessage("Assigned %d explicit monitor points on link %s", n, this->getName());
			delete [] p;

			return DANCE_OK;	
		}
	}
    else if( strcmp(argv[count], "assign_collision_monitor_points") == 0 || strcmp(argv[count], "assign_collision_monitor_points_random") == 0)
	{
		if( m_geomCollision == NULL )
		{
			danceInterp::OutputMessage("WARNING: there is no collision geometry for link %s.\n",	getName()) ;
			return DANCE_OK ;
		}

		// if no additional parameters, assign the default monitor points
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: system %s link %s assign_collision_monitor_points <num_points>\nsystem %s link %s assign_collision_monitor_points <x1> <y1> <z1> <x2> <y2> <z2> <x...> <y...> <z...>", this->getArticulatedObject()->getName(), this->getName(), this->getArticulatedObject()->getName(), this->getName());
			return DANCE_ERROR;
		}
		else if (argc == 2)
		{
			int num = atoi(argv[1]);
			if (strcmp(argv[count], "assign_collision_monitor_points_random") == 0)
				assignMonitorPointsCollision(num, true) ;
			else
				assignMonitorPointsCollision(num) ;
			danceInterp::OutputMessage("Assigned %d collision monitor points on link %s", num, this->getName());
			return DANCE_OK;
		}
		else
		{
			Vector *p ;

    
			// collect the monitor points from the command line
			int n =	argc / 3 ;
			p =	new Vector[n];
			int i, j;
			for (j = 0, i = 0 ; i < n ; i++, j +=3)
			{
				p[i][0]	= atof(argv[j])	;
				p[i][1]	= atof(argv[j+1]) ;
				p[i][2]	= atof(argv[j+2]) ;
			}
			this->assignMonitorPointsCollision(p, n);
			danceInterp::OutputMessage("Assigned %d explicit collision monitor points on link %s", n, this->getName());
			delete [] p;

			return DANCE_OK;	
		}
	}
	else if( strcmp(argv[count], "assign_prop_monitor_points") == 0 || strcmp(argv[count], "assign_prop_monitor_points_random") == 0)
	{
		if( m_geomProp == NULL )
		{
			danceInterp::OutputMessage("WARNING: there is no prop geometry for link %s.\n",	getName()) ;
			return DANCE_OK ;
		}

		// if no additional parameters, assign the default monitor points
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: system %s link %s assign_prop_monitor_points <num_points>\nsystem %s link %s assign_prop_monitor_points <x1> <y1> <z1> <x2> <y2> <z2> <x...> <y...> <z...>", this->getArticulatedObject()->getName(), this->getName(), this->getArticulatedObject()->getName(), this->getName());
			return DANCE_ERROR;
		}
		else if (argc == 2)
		{
			int num = atoi(argv[1]);
			if (strcmp(argv[count], "assign_prop_monitor_points_random") == 0)
				assignMonitorPointsProp(num, true) ;
			else
				assignMonitorPointsProp(num) ;
			danceInterp::OutputMessage("Assigned %d prop monitor points on link %s", num, this->getName());
			return DANCE_OK;
		}
		else
		{
			Vector *p ;

    
			// collect the monitor points from the command line
			int n =	argc / 3 ;
			p =	new Vector[n];
			int i, j;
			for (j = 0, i = 0 ; i < n ; i++, j +=3)
			{
				p[i][0]	= atof(argv[j])	;
				p[i][1]	= atof(argv[j+1]) ;
				p[i][2]	= atof(argv[j+2]) ;
			}
			this->assignMonitorPointsProp(p, n);
			danceInterp::OutputMessage("Assigned %d explicit prop monitor points on link %s", n, this->getName());
			delete [] p;

			return DANCE_OK;	
		}
	}
    else if( strcmp(argv[count], "rotate") == 0 )
	{
		rotateGeometry(argc-1, &argv[1]) ;
	}
    else if( strcmp(argv[count], "update_monitor_points") == 0 )
		getMonitorPointsFromGeom() ;
    else if (strcmp(argv[count], "writeTRI") == 0) 
	{
		char name[80];
		sprintf(name, "%s.tri", this->getName());
//		this->writeTRIFile(name);
//		danceInterp::OutputMessage("TRI file written for link %s at %s.\n", getName(), name);
	}
	else if (strcmp(argv[count], "sphere") == 0)
	{
		if (argc < 5)
		{
			danceInterp::OutputMessage("Usage: system %s link %s sphere <translationx> <translationy> <translationz> <scale>", 
									 this->m_ao->getName(), this->getName());
			return DANCE_ERROR;
		}
		int numSpheres = this->getNumSpheres();
		if (numSpheres >= MAXNUMSPHERES)
		{
			danceInterp::OutputMessage("Link %s already has %d spheres, please remove a sphere first.", this->getName(), numSpheres);
			return DANCE_OK;
		}
		int sphereNum = numSpheres;
		this->setSphereTranslation(sphereNum, atof(argv[1]), atof(argv[2]), atof(argv[3]));
		this->setSphereScale(sphereNum, atof(argv[4]));
		this->setSphereMatrix(sphereNum);
		this->setNumSpheres(numSpheres + 1);
		danceInterp::OutputMessage("Sphere matrix %d for link %s has been set.", sphereNum, this->getName());

		dance::AllViews->postRedisplay();
		return DANCE_OK;
	}
    else
		danceInterp::OutputMessage("USAGE: [set] geometry"
			"|boundingBox [on/off]"
			"|scale|make_triangle"
			"|assign_monitor_points"
			"|update_monitor_points"
			"|center|rotate|fit|attach")	;
    
    return DANCE_CONTINUE;
}

void Link::replaceGeometry(DGeometry* geometry, bool worldCoords)
{
	DGeometry* old = m_geom;

	this->setGeometry(geometry);

	if (m_geom == NULL)
	{
		if (old != NULL)
		{
			old->setVisible(true);
		}
		return;
	}

	// apply any transformation matrix to this geometry
//	if (geometry->useTransMatrix())
//		geometry->applyTransMatrix();


	// don't show the geometry in the standard geometry display loop
	geometry->setVisible(false);
	if (old != NULL && old != geometry)
		old->setVisible(true);

	if (worldCoords)
	{
		// compute the inverse tranformation matrix to place object into local coordinate system
		double worldTransMatrix[4][4];
		this->getWTransMat(worldTransMatrix);
		invSmart4(m_invGeom, worldTransMatrix);
	}
	else
	{
		setIdentMat(&m_invGeom[0][0], 4);
	}

    // calculate monitor points.
    getMonitorPointsFromGeom();
	
	dance::AllViews->postRedisplay();

}

void Link::replaceGeometryCollision(DGeometry* geometry, bool worldCoords)
{
	DGeometry* old = m_geomCollision;

	this->setGeometryCollision(geometry);

	if (m_geomCollision == NULL)
	{
		if (old != NULL)
			old->setVisible(true);

		return;
	}

	// apply any transformation matrix to this geometry
//	if (geometry->useTransMatrix())
//		geometry->applyTransMatrix();

	// don't show the geometry in the standard geometry display loop
	geometry->setVisible(false);
	if (old != NULL && old != geometry)
		old->setVisible(true);
	
	if (worldCoords)
	{
		// compute the inverse tranformation matrix to place object into local coordinate system
		double worldTransMatrix[4][4];
		this->getWTransMat(worldTransMatrix);
		invSmart4(m_invGeomCollision, worldTransMatrix);
	}
	else
	{
		setIdentMat(&m_invGeomCollision[0][0], 4);
	}

    // calculate monitor points.
    getMonitorPointsFromGeomCollision();

	dance::AllViews->postRedisplay();
}

void Link::replaceGeometryProp(DGeometry* geometry, bool worldCoords)
{
	DGeometry* old = m_geomProp;

	this->setGeometryProp(geometry);

	if (m_geomProp == NULL)
	{
		if (old != NULL)
			old->setVisible(true);

		return;
	}

	// apply any transformation matrix to this geometry
//	if (geometry->useTransMatrix())
//		geometry->applyTransMatrix();

	// don't show the geometry in the standard geometry display loop
	geometry->setVisible(false);
	if (old != NULL && old != geometry)
		old->setVisible(true);
	
	if (worldCoords)
	{
		// compute the inverse tranformation matrix to place object into local coordinate system
		double worldTransMatrix[4][4];
		this->getWTransMat(worldTransMatrix);
		invSmart4(m_invGeomProp, worldTransMatrix);
	}
	else
	{
		setIdentMat(&m_invGeomProp[0][0], 4);
	}

    // calculate monitor points.
    getMonitorPointsFromGeomProp();

	dance::AllViews->postRedisplay();
}
// PROC:   getMonitorPointFromGeom()
// DOES:   allocates space and gets the points from geometry.
//         The point are scaled appropriately by geom scale.
int Link::getMonitorPointsFromGeom()
{
	if (m_geom)
	{
		Vector *pts;
		int num	= m_geom->getMonitorPoints(&pts);
		if (num	> 0)
		{
		    if( m_monitorPoints.Allocate(num) == 0 )
		    {
				danceInterp::OutputMessage("Link::getMonitorPointsFromGeom: Cannot allocate memory!\n") ;
				return 0 ;
		    }
		    for	(int i = 0; i <	num ; i++)
				for (int j = 0;	j < 3; j++)
					m_monitorPoints.m_Point[i][j] = m_geomScale[j] * pts[i][j];

			// Added by AS 12/31/04 
			// multiply by inverse matrix to put points in local space
			for (int x = 0; x < num; x++)
				transformPoint_mat(m_monitorPoints.m_Point[x], m_invGeom);

			return(m_monitorPoints.m_NumPoints);
		}
	}
	return(0);
}

int Link::getMonitorPointsFromGeomCollision()
{
	if (m_geomCollision)
	{
		Vector *pts;
		int num	= m_geomCollision->getMonitorPoints(&pts);
		if (num	> 0)
		{
			if( this->m_monitorPointsCollision.Allocate(num) == 0 )
		    {
				danceInterp::OutputMessage("Link::getMonitorPointsFromGeomCollision: Cannot allocate memory!\n") ;
				return 0 ;
		    }
		
			for	(int i = 0; i <	num ; i++)
				for (int j = 0;	j < 3; j++)
					m_monitorPointsCollision.m_Point[i][j] = m_geomScaleCollision[j] * pts[i][j];

			// Added by AS 12/31/04
			// multiply by inverse matrix to put points in local space
			for (int x = 0; x < num; x++)
				transformPoint_mat(m_monitorPointsCollision.m_Point[x], this->m_invGeomCollision);

			return(m_monitorPointsCollision.m_NumPoints);
		}
	}
	return(0);
}


int Link::getMonitorPointsFromGeomProp()
{
	if (m_geomProp)
	{
		Vector *pts;
		int num	= m_geomProp->getMonitorPoints(&pts);
		if (num	> 0)
		{
			if( this->m_monitorPointsProp.Allocate(num) == 0 )
		    {
				danceInterp::OutputMessage("Link::getMonitorPointsFromGeomProp: Cannot allocate memory!\n") ;
				return 0 ;
		    }
		
			for	(int i = 0; i <	num ; i++)
				for (int j = 0;	j < 3; j++)
					m_monitorPointsProp.m_Point[i][j] = m_geomScaleProp[j] * pts[i][j];

			// Added by AS 12/31/04
			// multiply by inverse matrix to put points in local space
			for (int x = 0; x < num; x++)
				transformPoint_mat(m_monitorPointsProp.m_Point[x], this->m_invGeomProp);

			return(m_monitorPointsProp.m_NumPoints);
		}
	}
	return(0);
}

int Link::getMonitorPoints(Vector **pts)
{
	if( m_monitorPoints.m_NumPoints == 0 ) 
		pts = NULL ;
	else
		*pts = m_monitorPoints.m_Point;
	return m_monitorPoints.m_NumPoints;
}

int	Link::assignMonitorPoints(Vector* points, int numPoints)
{
	if (m_geom == NULL)
		return 0;

	int numAssigned = m_geom->assignMonitorPoints(numPoints, points);
	// get them in the link properly scaled
	getMonitorPointsFromGeom() ;

	this->setExplicitMonitorPoints(true);

	return numAssigned;
}

int Link::assignMonitorPoints(int numPoints, bool random)
{
    if (m_geom == NULL)
		return 0;
    
	int numAssigned = m_geom->assignMonitorPoints(numPoints, random) ;
	// get them in the link properly scaled
	getMonitorPointsFromGeom();

	this->setRandomMonitorPoints(random);
	this->setExplicitMonitorPoints(false);


	return numAssigned;
}

int	Link::assignMonitorPointsCollision(Vector* points, int numPoints)
{
	if (m_geomCollision == NULL)
		return 0;

	int numAssigned = m_geomCollision->assignMonitorPoints(numPoints, points);
	// get them in the link properly scaled
	getMonitorPointsFromGeomCollision() ;

	this->setExplicitMonitorPointsCollision(true);


	return numAssigned;
}

int Link::assignMonitorPointsCollision(int numPoints, bool random)
{
    if (m_geomCollision == NULL)
		return 0;
    
	int numAssigned = m_geomCollision->assignMonitorPoints(numPoints, random) ;
	// get them in the link properly scaled
	getMonitorPointsFromGeomCollision();

	this->setRandomMonitorPointsCollision(random);
	this->setExplicitMonitorPointsCollision(false);

	return numAssigned;
}

int	Link::assignMonitorPointsProp(Vector* points, int numPoints)
{
	if (m_geomProp == NULL)
		return 0;

	int numAssigned = m_geomProp->assignMonitorPoints(numPoints, points);
	// get them in the link properly scaled
	getMonitorPointsFromGeomProp() ;

	this->setExplicitMonitorPointsProp(true);


	return numAssigned;
}

int Link::assignMonitorPointsProp(int numPoints, bool random)
{
    if (m_geomCollision == NULL)
		return 0;
    
	int numAssigned = m_geomProp->assignMonitorPoints(numPoints, random) ;
	// get them in the link properly scaled
	getMonitorPointsFromGeomProp();

	this->setRandomMonitorPointsProp(random);
	this->setExplicitMonitorPointsProp(false);

	return numAssigned;
}

/*
int Link::assignMonitorPoints(
				int argc, char **argv)
{
    int	i,j ;
    int	n ;
    Vector *p ;


    if( m_geom == NULL )
    {
		danceInterp::OutputMessage("WARNING: there is no geometry for link %s.\n",	getName()) ;
		return DANCE_OK ;
    }
    
    if( argc <= 1 )
    {

		int npoints = 0 ;
		if( argc == 1 )
			npoints = atoi(argv[0]) ;
		danceInterp::OutputMessage("Creating default monitor points\n") ;
		// make the geometry monitor points
		m_geom->assignMonitorPoints(npoints) ;
		// get them in the link properly scaled
		getMonitorPointsFromGeom() ;
		return DANCE_OK ;
    }
 
	n =	argc / 3 ;
    if(	n < 1 )	return DANCE_OK ;
    p =	(Vector	*) malloc(n*sizeof(Vector)) ;
    for(j = 0, i = 0 ; i < n ; i++, j +=3)
    {
		p[i][0]	= atof(argv[j])	;
		p[i][1]	= atof(argv[j+1]) ;
		p[i][2]	= atof(argv[j+2]) ;
    }

    if(	m_geom->assignMonitorPoints(n,p) == n )
    {
		danceInterp::OutputMessage("Assigned %d monitor points.\n", n) ;
		getMonitorPointsFromGeom() ;
   		free(p)	;
		return DANCE_OK ;
    }
    else
    {
		free(p)	;
		return DANCE_ERROR ;
    }
}
*/

/*
int Link::assignMonitorPointsCollision(int argc, char **argv)
{
    int	i,j ;
    int	n ;
    Vector* p ;


    if( m_geomCollision == NULL )
    {
		danceInterp::OutputMessage("WARNING: there is no geometry for link %s.\n",	getName()) ;
		return DANCE_OK ;
    }
    
    if( argc <= 1 )
    {
		int npoints = 0 ;
		if( argc == 1 )
			npoints = atoi(argv[0]) ;
		danceInterp::OutputMessage("Creating default monitor points\n") ;
		// make the geometry monitor points
		m_geomCollision->assignMonitorPoints(npoints) ;
		// get them in the link properly scaled
		getMonitorPointsFromGeomCollision() ;
		return DANCE_OK ;
    }
 
	n =	argc / 3 ;
    if(	n < 1 )	return DANCE_OK ;
    p =	(Vector	*) malloc(n*sizeof(Vector)) ;
    for(j = 0, i = 0 ; i < n ; i++, j +=3)
    {
		p[i][0]	= atof(argv[j])	;
		p[i][1]	= atof(argv[j+1]) ;
		p[i][2]	= atof(argv[j+2]) ;
    }

    if(	m_geomCollision->assignMonitorPoints(n,p) == n )
    {
		danceInterp::OutputMessage("Assigned %d monitor points.\n", n) ;
		getMonitorPointsFromGeomCollision() ;
   		free(p)	;
		return DANCE_OK ;
    }
    else
    {
		free(p)	;
		return DANCE_ERROR ;
    }
}
*/

void Link::displayMonitorPoints()
{
    int lightOn = glIsEnabled(GL_LIGHTING) ;
    if( lightOn == GL_TRUE) glDisable(GL_LIGHTING) ;

    glColor4f(0.9f, 0.9f, 0.0f, 1.0f - m_Transparency);
    glPointSize(3.0);
    glBegin(GL_POINTS);

    for (int i = 0; i < m_monitorPoints.m_NumPoints; i++)
	{
   		glVertex3dv(m_monitorPoints.m_Point[i]);
	}

    glEnd();
    glPointSize(1.0);
    if( lightOn == GL_TRUE) glEnable(GL_LIGHTING) ;
}

void Link::displayMonitorPointsCollision()
{
    int lightOn = glIsEnabled(GL_LIGHTING) ;
    if( lightOn == GL_TRUE) glDisable(GL_LIGHTING) ;

    glColor4f(0.9f, 0.0f, 0.0f, 1.0f - m_Transparency);
    glPointSize(3.0);
    glBegin(GL_POINTS);

    for (int i = 0; i < m_monitorPointsCollision.m_NumPoints; i++) 
	{
   		glVertex3dv(m_monitorPointsCollision.m_Point[i]);
	}

    glEnd();
    glPointSize(1.0);
    if( lightOn == GL_TRUE) glEnable(GL_LIGHTING) ;
}

void Link::displayMonitorPointsProp()
{
    int lightOn = glIsEnabled(GL_LIGHTING) ;
    if( lightOn == GL_TRUE) glDisable(GL_LIGHTING) ;

    glColor4f(0.9f, 0.0f, 0.0f, 1.0f - m_Transparency);
    glPointSize(3.0);
    glBegin(GL_POINTS);

    for (int i = 0; i < m_monitorPointsProp.m_NumPoints; i++) 
	{
   		glVertex3dv(m_monitorPointsProp.m_Point[i]);
	}

    glEnd();
    glPointSize(1.0);
    if( lightOn == GL_TRUE) glEnable(GL_LIGHTING) ;
}


// resetInbAndOutb:
//	Takes account of geometry in a link and resets the inboard and outboard
//	(if applicable, otherwise the end effector) to be at the extreme ends of
//  the longest bounding box dimension of the geometry. If there is no geometry,
//  nothing is changed. 
//	
void Link::resetInbAndOutb(int flip)
{
	if (m_geom == NULL) return;

	BoundingBox box; m_geom->calcBoundingBox(&box);

	// Find the largest axis
	int largest = 0; double largestVal = box.xMax;
	double otherSide = box.xMin;
	if (box.yMax > largestVal) { 
		largest = 1; largestVal = box.yMax; otherSide = box.yMin;
	}
	if (box.zMax > largestVal) { 
		largest = 2; largestVal = box.zMax; otherSide = box.zMin;
	}

	// Find new world space positions of inboard and outboard joints.
	Joint *jnt = getParentJoint();
	assert(jnt);

	// If the flip flag is on, we reverse the inboard and outboard vectors to 
	if (flip) {
		double temp; temp = largestVal; 
		largestVal = otherSide;
		otherSide = temp;
	}
	
	double bodytojnt[3] = {0.0,0.0,0.0}; bodytojnt[largest] = largestVal;
	jnt->setBodyToJoint(bodytojnt);

	double inbtojnt[3] = {0.0,0.0,0.0}; inbtojnt[largest] = otherSide;
	
	
	if (getNumChildLinks() == 0) {
		// Adjust end-effector.
		setEndEffector(inbtojnt);
		return;
	}

	// Sets the inboard to joint for each child joint.
	Link **childlinks = getChildLinks();
	for (int i = 0; i < getNumChildLinks(); i++) {
		Link *child = childlinks[i];
		Joint *cjnt = child->getParentJoint();
		cjnt->setInbToJoint(inbtojnt);
	}

	// Update new joint configuration in articulated object.
	m_ao->updateStateConfig(-1);
}

// setMoments:
//		Builds an inertia tensor matrix as a diagonal matrix where the entries are the 
//		given moments of inertia. The products of inertia are zero.
//
void Link::setMoments(double moments[3]) 
{
	m_InerTensorIsDiagonal = 1;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++) {
			if (i == j)
				m_InerTensor[i][j] = moments[i];
			else
				m_InerTensor[i][j] = 0.0;
		}

	if (this->getArticulatedObject()->getNumSimulators() > 0)
	{
		for (int x = 0; x < this->getArticulatedObject()->getNumSimulators(); x++)
		{
			DSimulator* sim = (DSimulator*) this->getArticulatedObject()->getSimulator(x);
			sim->resetPhysicalProperties(this->getArticulatedObject());
		}
	}
}

void Link::getMoments(double moments[3])
{
	for (int x = 0; x < 3; x++)
		moments[x] = m_InerTensor[x][x];
}

void Link::setMass(double m)
{
	m_Mass = m;
	if (this->getArticulatedObject()->getNumSimulators() > 0)
	{
		for (int x = 0; x < this->getArticulatedObject()->getNumSimulators(); x++)
		{
			DSimulator* sim = (DSimulator*) this->getArticulatedObject()->getSimulator(x);
			sim->resetPhysicalProperties(this->getArticulatedObject());
		}
	}
}

double Link::getMass()
{
	return m_Mass;
}

void Link::displayAxes()
{
	glPushAttrib(GL_ENABLE_BIT);
			glDisable(GL_LIGHTING);
			double arrowLength = 1.0;
			DView *wview = dance::AllViews->getViewFocus();
			if (wview) {
				double pos[3]; getPosition(pos);		
				double win[3]; wview->getWindowCoords(pos,win);
				double worldwidth = wview->getFrustumWidth(win[2]);
				arrowLength = 0.05*worldwidth;
			}
			GLdrawAxes(arrowLength);
	glPopAttrib();
}

// scales the geometry such that the bounding box of the gometry fits the link size
void Link::FitGeometryToLink(int argc, char **argv)
{
    if( m_geom == NULL )
		return ;

    // center the geometry around its geometric center
    m_geom->Center() ;
    // get the BoundingBox of the geometry
    BoundingBox b ;
    m_geom->calcBoundingBox(&b) ;
    // Find the body to joint distance 
    Joint *jnt = getParentJoint();
    assert(jnt);
    Vector bodyToJ ;
    jnt->getBodyToJoint(bodyToJ) ;
    
    // find the direction of the bodyToJ
    Vector axis[3] = { {1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}} ;
    double max = 0 ;
    int dir = 0;
    for( int i = 0 ; i < 3 ; i++ )
    {
		double res ;
		if( (res = fabs(VecDotProd(bodyToJ, axis[i]))) > max ) 
		{
			dir = i ;
			max = res ;
		}
    }

    Vector endPoint ;
    if( getNumChildLinks() != 0 )
    {
		if( strcmp(getName(), "Hip") == 0 )
		{
			if( strcmp(childLink[0]->getName(), "Abdomen") == 0 )
			childLink[1]->getParentJoint()->getInbToJoint(endPoint) ;
			else
			childLink[0]->getParentJoint()->getInbToJoint(endPoint) ;
		}
		else
			childLink[0]->getParentJoint()->getInbToJoint(endPoint) ;
		// projected on the bodyToJoint direction
    }
    else
		getEndEffector(endPoint) ;
    
    double aMax, aMin ;
    switch (dir)
    {
	case 0: 
	    aMax = b.xMax ;
	    aMin = b.xMin ;
	    break ;
	case 1:
	    aMax = b.yMax ;
	    aMin = b.yMin ;
	    break ;
	case 2:
	    aMax = b.zMax ;
	    aMin = b.zMin ;
	    break ;
	default:
	    danceInterp::OutputMessage("ERROR: cannot determine the direction of body to joint!\n") ;
	    return ;
    }

    // compute the length of the link
    double lengthLink  = fabs(bodyToJ[dir] - endPoint[dir]) ;
    danceInterp::OutputMessage("bodyToJ[%d] = %lf endPoint[%d] = %lf\n", dir, bodyToJ[dir], dir, endPoint[dir]) ;
    double divisor ;
    divisor = (aMax-aMin) ;
    
    double scale = lengthLink / divisor  ;
    m_geomScale[0] *= scale ;
    m_geomScale[1] *= scale ;
    m_geomScale[2] *= scale ;
    m_geomFix = true;

    // FIXME: Why do we have geomScale / geomFix?  Shouldn't we just call Scale on the underlying
    // geometry object ? - Presents some problems for the SWIFT collision detection code... - Justin

    danceInterp::OutputMessage("Scale %lf\n", scale) ;
    // now move the geometry so that its middle
    // is in the middle of the link which is not neccessarily the
    // origin of the local coordinate system
    // Currently the geometric center of the geometry is 0,0,0 in local coordinates
    // which is not the middle of the geometry
    
    // the new bounding box is

    Vector middle ;
    setVector(middle, 0.0, 0.0, 0.0) ;
    // do not scale the aMax and aMin because the 
    // scale params are stored out of the vertices.
    // We still have the old value of the vertices.
    middle[dir] = -0.5*(aMax + aMin) ;
    m_geom->Translate(middle[0], middle[1], middle[2]) ;

    danceInterp::OutputMessage("middle: %lf %lf %lf\n", middle[0], middle[1], middle[2]) ;
    getMonitorPointsFromGeom(); // Recalculate monitor points.
}

void Link::WriteBVHFile(FILE *fp, int depth)
{
	char prfx[MAX_LINE] = "" ;
	
	if( parentJoint == NULL )
	{
		danceInterp::OutputMessage("ERROR: WriteBVHFile: link without a parent joint!\n") ;
		return ;
	}


	int i ;
	for( i = 1 ; i < depth ; i++ )
		strcat(prfx, "\t") ;

	if( depth == 1 )
	{
		fprintf(fp, "HIERARCHY\n") ;
		fprintf(fp, "ROOT %s\n", getName()) ;
	}
	else
	{
		fprintf(fp, "%sJOINT %s\n", prfx, getName()) ;
	}
	fprintf(fp, "%s{\n", prfx) ;

	// print the parameters of this link which are actually stored in the parent
	// joint. 
	parentJoint->writeBVHFile(fp, depth) ;
	
	if( m_numChildLinks == 0 )
	{
		fprintf(fp, "%s\tEnd Site\n", prfx) ;
		fprintf(fp, "%s\t{\n", prfx) ;
		fprintf(fp, "%s\t\tOFFSET %lf %lf %lf\n", prfx, m_endEffector[0], 
			m_endEffector[1], m_endEffector[2]) ;
		fprintf(fp, "%s\t}\n", prfx) ;
	}			
	// write the children 
	for( i = 0 ; i < m_numChildLinks ; i++ )
		childLink[i]->WriteBVHFile(fp, depth+1) ;

	fprintf(fp, "%s}\n", prfx) ;
	return ;
}

int Link::rotateGeometry(int argc, char **argv)
{
    if( (argc != 2 ) && (argc != 3))
    {
	danceInterp::OutputMessage("ERROR: Link::rotateGeometry: usage: 'rotate x|y|z degrees [<around center flag>]'.\n") ;
	return DANCE_ERROR ;
    }
    
    if( m_geom == NULL )
    {
	danceInterp::OutputMessage("ERROR: Link::rotateGeometry: no geometry present.\n") ;
	return DANCE_ERROR ;
    }
    
    int center = 0;
    if( argc == 3 )
		center = atoi(argv[2]) ;
    // if center is 1 then the rotation happens around the 
    // the center of the bounding box of the geometry
    // otherwise around the current origin (default)
    m_geom->Rotate(argv[0], atof(argv[1]), center) ;

    getMonitorPointsFromGeom();
    return DANCE_OK ;
}

void Link::getWorldVelocity(double worldvel[3], double local[3])
{
	if (m_ao->getNumSimulators() == 0)
	{
		worldvel[0] = worldvel[1] = worldvel[2] = 0.0;
	}
	else
	{
		DSimulator* simulator = m_ao->getSimulator(0);
		simulator->GetVel(m_linkNumber,local,worldvel);
    }
}

void Link::Highlight(float r, float g, float b, float a)
{
	double point[3];
	getEndEffectorWC(point);
	glPointSize(15.0);
	glPushAttrib(GL_ENABLE_BIT);
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glColor4f(r,g,b,a);
	glBegin(GL_POINTS);
	glVertex3dv(point);
	glEnd();
	glPointSize(1.0);
	
	glPopAttrib();
}

void Link::RemoveChildJoint(Joint *wjoint)
{
	if (wjoint == NULL) return;

	// Find wjoint amongst children joints.
	int n = getNumChildLinks();

	int found = -1;
	for (int i = 0; i < n; i++) {
		if (childLink[i]->parentJoint == wjoint) {
			found = i;
			break;
		}
	}

	
	if (found == -1) return; // Not found among links.

	// Now shift all the links over. No need to shift if entry is last in list.
	if (found < n-1)
		memcpy(&childLink[found],&childLink[found+1],sizeof(Link *)*(n-1-found));
	m_numChildLinks--;

}

void Link::DeleteChildren()
{
	int numChildren = m_numChildLinks;
	for (int i = numChildren - 1; i >= 0; i--)
		delete childLink[i];
//		DeleteChildLink(childLink[i]);
	m_numChildLinks = 0;
}

void Link::DeleteChildLink(Link *l)
{
	//find location of link in array
	int i;	
	for (i = 0; i < getNumChildLinks(); i++)
	{
		if (l == childLink[i])
			break;
	}

	//delete link
	delete childLink[i];
	
	//adjust array to remove holes
	for (int j = 0; j < getNumChildLinks() - i - 1; j++)
	{
		childLink[i + j] = childLink[i + j + 1];
	}

	m_numChildLinks--;

}

// uses the simulator instead of the links structure
void Link::getLocalCoordSim(double local[3], double world[3])
{
	if (m_ao->getNumSimulators() == 0)
	{
	}
	else
	{
		DSimulator* simulator = m_ao->getSimulator(0);
        Vector cmlocal = {0.0, 0.0, 0.0}, cm ;
        simulator->GetPosition(m_linkNumber, cmlocal, cm) ;
        VecSubtract(local, world, cm) ;

	// WORLDFRAME defined in DSimulator.h
        simulator->GetOrientation(WORLDFRAME, local, m_linkNumber, local) ;
	}
}

//  void Link::setPrevWTransMat()
//  {
//      getWTransMat(m_prevWTransMat) ;
//  }

//  // returns the prev position of a local point in world coordinates    
// void Link::getWPrevPos(Vector pointLocal, Vector prevPos)
//  {
//      VecCopy(prevPos, pointLocal) ;
//      transformPoint_mat(pointLocal, m_prevWTransMat) ;
//  }

// Returns the proper transformatin matrix for the geometry
// cause the geometry may be separate scaled using geomScale
void Link::getWTransMatGeom(double transMat[4][4])
{
    getWTransMat(transMat) ;
    if( m_geomFix == true) 
    {
	transMat[0][0] *= m_geomScale[0] ;
	transMat[1][1] *= m_geomScale[1] ;
	transMat[2][2] *= m_geomScale[2] ;
    }
}
    
void Link::GetRapidTriangle(int n, Vector v1, Vector v2, Vector v3)
{
    m_geom->GetRapidTriangle(n, v1, v2, v3) ;
    if( m_geomFix == true)
    {
	v1[0] *= m_geomScale[0] ;
	v2[0] *= m_geomScale[0] ;
	v3[0] *= m_geomScale[0] ;

	v1[1] *= m_geomScale[1] ;
	v2[1] *= m_geomScale[1] ;
	v3[1] *= m_geomScale[1] ;

	v1[2] *= m_geomScale[2] ;
	v2[2] *= m_geomScale[2] ;
	v3[2] *= m_geomScale[2] ;
    }
} 


bool Link::isDisplayMonitorPoints()
{
	return m_displayMonitorPoints;
}

void Link::setDisplayMonitorPoints(bool val)
{
	m_displayMonitorPoints = val;
}

void Link::getInerTensor(double tensor[3][3])
{
	for (int r = 0; r < 3; r++)
		for (int c = 0; c < 3; c++)
			tensor[r][c] = m_InerTensor[r][c];

}

bool Link::isShowGeometryCollision()
{
	return m_showCollisionGeometry;
}

void Link::setShowGeometryCollision(bool val)
{
	m_showCollisionGeometry = val;
}

MonitorPoints* Link::getMonitorPoints()
{
	if (this->m_geomCollision != NULL)
		return &m_monitorPointsCollision;
	else
		return &m_monitorPoints;
}

int Link::getNumMonitorPoints()
{
	if (this->m_geomCollision != NULL)
		return m_monitorPointsCollision.m_NumPoints;
	else
		return m_monitorPoints.m_NumPoints;
}

int Link::getNumMonitorPointsCollision()
{
	return m_monitorPointsCollision.m_NumPoints;
}

int	Link::getMonitorPointsCollision(Vector** pts)
{
	if( m_monitorPointsCollision.m_NumPoints == 0 ) 
		pts = NULL ;
	else
		*pts = m_monitorPointsCollision.m_Point;

	return m_monitorPointsCollision.m_NumPoints;
}

MonitorPoints* Link::getMonitorPointsCollision()
{
	return &m_monitorPointsCollision;
}

void Link::setName(const char* name)
{
		strcpy(m_name, name);
}

const char* Link::getName()
{
	return m_name;
}

ArticulatedObject* Link::getArticulatedObject()
{
	return m_ao;
}

void Link::setArticulatedObject(ArticulatedObject* ao)
{
	m_ao = ao;
}

void Link::setEndEffector(double* vec)
{
	VecCopy(this->m_endEffector, vec);
}

void Link::getEndEffector(double* vec)
{
	VecCopy(vec, this->m_endEffector);
}

void Link::setTransparency(float val)
{
	this->m_Transparency = val;
}

float Link::getTransparency()
{
	return this->m_Transparency;
}

void Link::setSphereTranslation(int num, double x, double y, double z)
{
	setVector(this->m_sphereTranslation[num], x, y, z);
}

void Link::setSphereScale(int num, double s)
{
	this->m_sphereScale[num] = s;
}

void Link::setSphereMatrix(int num)
{
	setIdentMat(&m_sphereMatrix[num][0][0], 4);
	
	// scaling
	m_sphereMatrix[num][0][0] = m_sphereMatrix[num][1][1] = m_sphereMatrix[num][2][2] = m_sphereScale[num];

	// translation
	m_sphereMatrix[num][3][0] = m_sphereTranslation[num][0];
	m_sphereMatrix[num][3][1] = m_sphereTranslation[num][1];
	m_sphereMatrix[num][3][2] = m_sphereTranslation[num][2];
}

void Link::getSphereMatrix(int num, double matrix[4][4])
{
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			matrix[r][c] = m_sphereMatrix[num][r][c];
}

void Link::setNumSpheres(int num)
{
	m_numSpheres = num;
}

int Link::getNumSpheres()
{
	return m_numSpheres;
}

void Link::getSphereTranslation(int num, double& x, double& y, double& z)
{
	x = this->m_sphereTranslation[num][0];
	y = this->m_sphereTranslation[num][1];
	z = this->m_sphereTranslation[num][2];
}

double Link::getSphereScale(int num)
{
	return this->m_sphereScale[num];
}

DGeometry* Link::getGeometry()
{
	return m_geom;
}

void Link::setGeometry(DGeometry* g, bool updateDependencies)
{
	if (updateDependencies)
	{
		if (g != m_geom && m_geom != NULL)
		{
			this->m_ao->removeDependency(m_geom);
		}
	}

	if (m_geom != NULL && m_geom->getDependenciesReverse()->size() == 0)
	{
		m_geom->setVisible(true);
	}

	if (g == NULL && m_geom != NULL)
	{
		//// releasing geometry to the where it was removed
		//double geomMatrix[4][4];
		//m_geom->getTransMatrix(geomMatrix);
		//Vector scaling; // determine the scaling factor of the geometry
		//m_geom->getScaling(scaling);
		//for (int x = 0; x < 3; x++) // undo the scaling
		//	geomMatrix[x][x] *= 1.0 / scaling[x];
		//double temp[4][4];
		//multArray4x4(temp, m_invGeom, geomMatrix);
		//double linkMatrix[4][4];
		//this->getWTransMat(linkMatrix);
		//double matrix[4][4];
		//multArray4x4(matrix, linkMatrix, temp);
		//// assign translation parameters
		//Vector translation;
		//for (int x = 0; x < 3; x++)
		//	translation[x] = matrix[3][x];
		//for (int x = 0; x < 3; x++) // redo the scaling
		//	matrix[x][x] *= scaling[x];

		//m_geom->decomposeTransformationMatrix();

		//m_geom->setTransMatrix(matrix);

	}

	m_geom = g;

	if (g != NULL)
	{
		g->setVisible(false);
	}

	if (updateDependencies)
	{
		if (g != NULL)
			this->m_ao->addDependency(g);
	}
}

DGeometry* Link::getGeometryCollision()
{
	return m_geomCollision;
}

void Link::setGeometryCollision(DGeometry* g, bool updateDependencies)
{
	if (updateDependencies)
	{
		if (g != m_geomCollision && m_geomCollision != NULL)
		{
			this->m_ao->removeDependency(m_geomCollision);
		}
	}

	if (m_geomCollision != NULL)
		m_geomCollision->setVisible(true);
	m_geomCollision = g;
	if (g != NULL)
		g->setVisible(false);

	if (updateDependencies)
	{
		if (g != NULL)
			this->m_ao->addDependency(g);
	}

}

DGeometry* Link::getGeometryProp()
{
	return m_geomProp;
}

void Link::setGeometryProp(DGeometry* g, bool updateDependencies)
{
	if (updateDependencies)
	{
		if (g != m_geomProp && m_geomProp != NULL)
		{
			this->m_ao->removeDependency(m_geomProp);
		}
	}

	if (m_geomProp != NULL)
		m_geomProp->setVisible(true);
	m_geomProp = g;
	if (g != NULL)
		g->setVisible(false);

	if (updateDependencies)
	{
		if (g != NULL)
			this->m_ao->addDependency(g);
	}
}

double* Link::getGeometryScale()
{
	return &this->m_geomScale[0];
}

void Link::setGeometryScale(double* scale)
{
	VecCopy(this->m_geomScale, scale);
}

double* Link::getGeometryCollisionScale()
{
	return &this->m_geomScaleCollision[0];
}

void Link::setGeometryCollisionScale(double* scale)
{
	VecCopy(this->m_geomScaleCollision, scale);
}

double* Link::getGeometryPropScale()
{
	return &this->m_geomScaleProp[0];
}

void Link::setGeometryPropScale(double* scale)
{
	VecCopy(this->m_geomScaleProp, scale);
}

void Link::getInvGeometryTransMat(double m[4][4])
{
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			m[r][c] = this->m_invGeom[r][c];
}

void Link::getInvGeometryCollisionTransMat(double m[4][4])
{
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			m[r][c] = this->m_invGeomCollision[r][c];
}

void Link::getInvGeometryPropTransMat(double m[4][4])
{
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			m[r][c] = this->m_invGeomProp[r][c];
}

void Link::setInvGeometryTransMat(double m[4][4])
{
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			this->m_invGeom[r][c] = m[r][c];
}

void Link::setInvGeometryCollisionTransMat(double m[4][4])
{
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			this->m_invGeomCollision[r][c] = m[r][c];
}

void Link::setInvGeometryPropTransMat(double m[4][4])
{
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			this->m_invGeomProp[r][c] = m[r][c];
}


void Link::setExplicitMonitorPoints(bool val)
{
	this->m_explicitMonitorPoints = val;
}

bool Link::isExplicitMonitorPoints()
{
	return this->m_explicitMonitorPoints;
}

void Link::setRandomMonitorPoints(bool val)
{
	this->m_randomMonitorPoints = val;
}

bool Link::isRandomMonitorPoints()
{
	return this->m_randomMonitorPoints;
}

void Link::setExplicitMonitorPointsCollision(bool val)
{
	this->m_explicitMonitorPointsCollision = val;
}

bool Link::isExplicitMonitorPointsCollision()
{
	return this->m_explicitMonitorPointsCollision;
}

void Link::setRandomMonitorPointsCollision(bool val)
{
	this->m_randomMonitorPointsCollision = val;
}

bool Link::isRandomMonitorPointsCollision()
{
	return this->m_randomMonitorPointsCollision;
}

void Link::setExplicitMonitorPointsProp(bool val)
{
	this->m_explicitMonitorPointsProp = val;
}

bool Link::isExplicitMonitorPointsProp()
{
	return this->m_explicitMonitorPointsProp;
}

void Link::setRandomMonitorPointsProp(bool val)
{
	this->m_randomMonitorPointsProp = val;
}

bool Link::isRandomMonitorPointsProp()
{
	return this->m_randomMonitorPointsProp;
}

void Link::copy(Link* link)
{
	// duplicates the link except for the link/joint connections

	// mass properties
	this->setMass(link->getMass());
	Vector moments;
	link->getMoments(moments);
	this->setMoments(moments);

	// transparency
	this->setTransparency(link->getTransparency());

	// geometry
	double* geomScale = link->getGeometryScale();
	VecCopy(m_geomScale, geomScale);
	if (m_geomScale[0] == 1.0 && m_geomScale[1] == 1.0 && m_geomScale[2] == 1.0)
		m_geomFix = false;
	else
		m_geomFix = true;
	DGeometry* geom = link->getGeometry();
	this->m_geom = geom;
	double invGeom[4][4];
	link->getInvGeometryTransMat(invGeom);
	for (int r = 0; r < 4; r++)
			for (int c = 0; c < 4; c++)
				this->m_invGeom[r][c] = invGeom[r][c];

	double* geomScaleCollsion = link->getGeometryCollisionScale();
	VecCopy(this->m_geomScaleCollision, geomScaleCollsion);
	if (m_geomScaleCollision[0] == 1.0 && m_geomScaleCollision[1] == 1.0 && m_geomScaleCollision[2] == 1.0)
		m_geomFixCollision = false;
	else
		m_geomFixCollision = true;
	DGeometry* geomCollision = link->getGeometryCollision();
	this->m_geomCollision = geomCollision;
	double invGeomCollision[4][4];
	link->getInvGeometryCollisionTransMat(invGeomCollision);
	this->setInvGeometryCollisionTransMat(invGeomCollision);

	// name
	this->setName(link->getName());

	// collision spheres
	m_numSpheres = link->getNumSpheres();
	for (int s = 0; s < m_numSpheres; s++)
	{
		double sphereMatrix[4][4];
		link->getSphereMatrix(s, sphereMatrix);
		for (int r = 0; r < 4; r++)
			for (int c = 0; c < 4; c++)
				this->m_sphereMatrix[s][r][c] = sphereMatrix[r][c];
	}

	// monitor points
	this->setDisplayMonitorPoints(link->isDisplayMonitorPoints());
	int numMonitorPoints = link->getNumMonitorPoints();
	Vector** oldmpts = NULL;
	link->getMonitorPoints(oldmpts);
	this->assignMonitorPoints(*oldmpts, numMonitorPoints);

	int numCollisionMonitorPoints = link->getNumMonitorPointsCollision();
	Vector** oldmptscollision = NULL;
	link->getMonitorPoints(oldmptscollision);
	this->assignMonitorPointsCollision(*oldmptscollision, numCollisionMonitorPoints);

	if (link->isExplicitMonitorPoints())
		this->setExplicitMonitorPoints(true);
	else
		this->setExplicitMonitorPoints(false);

	if (link->isRandomMonitorPoints())
		this->setRandomMonitorPoints(true);
	else
		this->setRandomMonitorPoints(false);

	if (link->isExplicitMonitorPointsCollision())
		this->setExplicitMonitorPointsCollision(true);
	else
		this->setExplicitMonitorPointsCollision(false);

	if (link->isRandomMonitorPointsCollision())
		this->setRandomMonitorPointsCollision(true);
	else
		this->setRandomMonitorPointsCollision(false);

	m_isShowingInertia = link->m_isShowingInertia;

}

void Link::accumTotalInertia( void )
{
	// Recursively accumulate all of the children's inertias
	m_totalInertia.clear();  // set to zero
	int childCount = getNumChildLinks();
	for( int i = 0; i < childCount; ++i )
	{
		Link* child = getChildLinks()[i];
		if( !child ) continue;

		// Recursive call
		child->accumTotalInertia();

		// get a copy of our child's D
		InertiaTensor childD = child->getTotalInertiaTensor();

		// Transform the child's D to our space
		double childToParentTransform[4][4];
		child->getTransMat( childToParentTransform );
		childD.transform( childToParentTransform );

		// add to our running total
		m_totalInertia += childD;
	}

	// Add in our own inertia
	double cmInertiaRaw[3][3];
	getInerTensor( cmInertiaRaw );
	Vector cm;
	getCenterMass( cm );
	InertiaTensor tmpInertia( cmInertiaRaw, getMass(), cm );

	m_totalInertia += tmpInertia;
}


const InertiaTensor& Link::getTotalInertiaTensor( void ) const
{
	return m_totalInertia;
}

void Link::setRestitution(double val)
{
	m_restitution = val;
}

double Link::getRestitution()
{
	return m_restitution;
}

void Link::setAttachment(ArticulatedObject* ao, int link, bool updateDependencies)
{
	if (updateDependencies)
	{
		if (this->m_attachment != NULL)
		{
			this->m_ao->removeDependency(this->m_attachment);
		}
	}

	m_attachment = ao;
	this->m_attachmentLinkNum = link;

	if (updateDependencies)
	{
		if (m_attachment != NULL)
		{
			this->m_ao->addDependency(this->m_attachment);
		}
	}
}

ArticulatedObject* Link::getAttachment(int& link)
{
	link = this->m_attachmentLinkNum;
	return m_attachment;
}

void Link::setAttachmentStatic(DGeometry* geom, bool updateDependencies)
{
	if (updateDependencies)
	{
		if (this->m_attachmentStatic != NULL)
		{
			this->m_ao->removeDependency(this->m_attachmentStatic);
		}
	}

	m_attachmentStatic = geom;

	if (updateDependencies)
	{
		if (m_attachment != NULL)
		{
			this->m_ao->addDependency(this->m_attachmentStatic);
		}
	}
}

DGeometry* Link::getAttachmentStatic()
{
	return m_attachmentStatic;
}

void Link::setIsShowingInertia( bool argVal )
{
	m_isShowingInertia = argVal;
}

bool Link::isShowingInertia( void ) const
{
	return m_isShowingInertia;
}

double Link::getParentCalculatedAngularAccel( Vector argAxis ) const
{
	if( !parentLink )
	{
		return 0;
	}
	Link* nonConstThis = (const_cast< Link* >(this));

	// Project the parent angular acceleration onto our axis and return the magnitude

	// Get global axes to project ang accel onto
	double m[4][4];
	nonConstThis->getWTransMat( m );
	Vector globalAxis;
	VecCopy( globalAxis, argAxis );
	rotPoint_mat4( globalAxis, m );
	VecNormalize( globalAxis );

	double parentAngularAccel = VecDotProd( globalAxis, parentLink->m_accumulatedAngularAccel ) ;
	//danceInterp::OutputMessage( "Link %s, axis %d has parent ang accel of %f", nonConstThis->getName(), argAxis, parentAngularAccel );
	return parentAngularAccel;
}

void Link::resetParentCalculatedAngularAccel( void )
{
	zeroVector( m_accumulatedAngularAccel );
}

void Link::accumCalculatedAngularAccel( Vector argEstimatedOmegaDot )
{
	if( parentLink )
	{
		VecAdd( m_accumulatedAngularAccel, m_accumulatedAngularAccel, parentLink->m_accumulatedAngularAccel );
	}
	VecAdd( m_accumulatedAngularAccel, m_accumulatedAngularAccel, argEstimatedOmegaDot );
}

