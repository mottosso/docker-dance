/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

***************************************************************
******General License Agreement and Lack of Warranty ***********
****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment
-----------------------------------------
AUTHOR:
Ari Shapiro (ashapiro@cs.ucla.edu)
ORIGINAL AUTHORS: 
Victor Ng (victorng@dgp.toronto.edu)
Petros Faloutsos (pfal@cs.ucla.edu)
CONTRIBUTORS:
Yong Cao (abingcao@cs.ucla.edu)
Paco Abad (fjabad@dsic.upv.es)
Brian Allen (vector@acm.org)
**********************************************************/

#include "InertiaTensor.h"

#include "GLutilities.h"

const double gblDefaultDisplayScale = 0.01;

InertiaTensor::InertiaTensor( void )
: m_tensor( 0, 0, 0, 0, 0, 0, 0, 0, 0 ),
  m_mass( 0 ),
  m_displayScale( 0.02 )
{
	m_centerOfMass[0] = 0;
	m_centerOfMass[1] = 0;
	m_centerOfMass[2] = 0;
}

InertiaTensor::InertiaTensor( const InertiaTensor& argFrom )
: m_tensor( argFrom.m_tensor ),
  m_mass( argFrom.m_mass ),
  m_displayScale( argFrom.m_displayScale )
{
	for( int i = 0; i < 3; ++i )
	{
		m_centerOfMass[i] = argFrom.m_centerOfMass[i];
	}
}

InertiaTensor::InertiaTensor( const Vector argBoxDimensionsMeters, 
							  const double& argDensityKgPerM3 )
: m_displayScale( 0.02 )
{
	m_centerOfMass[0] = 0;
	m_centerOfMass[1] = 0;
	m_centerOfMass[2] = 0;

	double volM3 = 1.0;
	for( int i = 0; i < 3; ++i )
	{
		volM3 *= argBoxDimensionsMeters[i];
	}
	m_mass = volM3 * argDensityKgPerM3;
	m_tensor.clear();

	// A box's inertia tensor:
	// I_x = 1/12 * ( y^2 + z^2 )   (symmetrically applied to y and z)
	// diagonals of tensor are 0, 4, 8
	// 1/12 = 0.083333333 
	m_tensor[0] = 0.083333333 
		* ( argBoxDimensionsMeters[1]*argBoxDimensionsMeters[1] 
		  + argBoxDimensionsMeters[2]*argBoxDimensionsMeters[2] );
	m_tensor[1] = 0.083333333 
		* ( argBoxDimensionsMeters[0]*argBoxDimensionsMeters[0] 
		  + argBoxDimensionsMeters[2]*argBoxDimensionsMeters[2] );
	m_tensor[2] = 0.083333333 
		* ( argBoxDimensionsMeters[0]*argBoxDimensionsMeters[0] 
		  + argBoxDimensionsMeters[1]*argBoxDimensionsMeters[1] );
}

InertiaTensor::InertiaTensor( const double argRawInertiaTensor[3][3], double argMass, Vector argCenterOfMass )
: m_mass( argMass ),
  m_displayScale( 0.02 )
{
	VecCopy( m_centerOfMass, argCenterOfMass );
	for( int i = 0; i < 3; ++i )
	{
		for( int j = 0; j < 3; ++j )
		{
			m_tensor[i][j] = argRawInertiaTensor[i][j];
		}
	}
}

const Matrix3x3& InertiaTensor::getInertia( void ) const
{
	return m_tensor;
}

void InertiaTensor::getInertia( Matrix3x3& outInertiaTensor ) const
{
	outInertiaTensor = m_tensor;
}

double InertiaTensor::getMass( void ) const
{
	return m_mass;
}

void InertiaTensor::getCenterOfMass( Vector& outCenterOfMass ) const
{
	VecCopy( outCenterOfMass, m_centerOfMass );
}

void InertiaTensor::transform( const double argTransformationMatrix[4][4] )
{
	// Rotate
	Matrix3x3 localRot;
	localRot.from4x4( argTransformationMatrix );
	Matrix3x3 localRotInv = localRot.transpose(); // transpose is inverse for rotation matrix
	Vector localTranslate;
	for( int i = 0; i < 3; ++i )
	{
		localTranslate[i] = argTransformationMatrix[3][i];
	}
	m_tensor = ( localRotInv * m_tensor * localRot );  // using "opengl" convention

	// rotate center of mass
	VecCopy( m_centerOfMass, ( localRotInv * m_centerOfMass).data() );  
	// note that using inverse because order of operation of * is determined by object (it's a member of Mat3x3)
	
	// translate center of mass
	for( int i = 0; i < 3; ++i )
	{
		m_centerOfMass[i] += localTranslate[i];
	}

	// Translate
	//////////////////////////////////////////////////////////////////////////
	// taken from Goldstein, "Classical Mechanics"
	double d = VecLength2( localTranslate );
	Matrix3x3 a2;
	a2.identity();
	a2 *= d;
	for( int i = 0; i < 3; ++i )
	{
		for( int j = 0; j < 3; ++j )
		{
			m_tensor[i][j] +=  m_mass * ( a2[i][j] - ( localTranslate[i] * localTranslate[j] ) );
		}
	}
}

void InertiaTensor::clear( void )
{
	m_tensor.clear();
	m_mass = 0;
	for( int i = 0; i < 3; ++i )
	{
		m_centerOfMass[i] = 0;
	}
}

double InertiaTensor::getMoment( const Vector argAxisOfRotation ) const
{
	return getMoment( argAxisOfRotation, m_centerOfMass );
}

double InertiaTensor::getMoment( const Vector argAxisOfRotation, const Vector argPointToRotateAbout ) const
{
	// moment = n dot I dot n
	double moment = 0;
	Vector n;
	VecCopy( n, argAxisOfRotation );
	VecNormalize( n );
	for( int i = 0; i < 3; ++i )
	{
		for( int j = 0; j < 3; ++j )
		{
			moment += m_tensor[i][j]*n[i]*n[j];
		}
	}

	// moment += mass * ( r cross n )^2
	Vector crossProd;
	Vector offset;
	for( int i = 0; i < 3; ++i ) offset[i] = argPointToRotateAbout[i] - m_centerOfMass[i];
	VecCrossProd( crossProd, offset, n );
	double dist2 = VecLength2( crossProd );
	moment += dist2 * m_mass;
	return moment;
}


void InertiaTensor::operator= ( const InertiaTensor& argFrom )
{
	m_tensor = argFrom.m_tensor;
	m_mass = argFrom.m_mass;
	VecCopy( m_centerOfMass, argFrom.m_centerOfMass );
	for( int i = 0; i < 3; ++i )
	{
		m_centerOfMass[i] = argFrom.m_centerOfMass[i];
	}
}

InertiaTensor InertiaTensor::operator+= ( const InertiaTensor& argOther ) 
{
	// tensors add component-wise
	double totalMass = m_mass + argOther.m_mass;
	for( int i = 0; i < 3; ++i )
	{
		m_centerOfMass[i] 
			= ( m_mass * m_centerOfMass[i] + argOther.m_mass * argOther.m_centerOfMass[i] )
			  / totalMass;
	}
	m_tensor += argOther.m_tensor;
	m_mass += argOther.m_mass;
	return *this;
}

InertiaTensor operator+ ( const InertiaTensor& argLHS, const InertiaTensor& argRHS ) 
{
	InertiaTensor retval;
	double totalMass = argRHS.m_mass + argLHS.m_mass;
	for( int i = 0; i < 3; ++i )
	{
		retval.m_centerOfMass[i] 
		= (argLHS.m_mass*argLHS.m_centerOfMass[i] 
		+ argRHS.m_mass*argRHS.m_centerOfMass[i])
		/ totalMass;
	}
	// tensors add component-wise
	retval.m_tensor = argLHS.m_tensor + argRHS.m_tensor;
	retval.m_mass = argLHS.m_mass + argRHS.m_mass;

	return retval;
}

void InertiaTensor::display( int argModeBitFlag ) const 
{
	if( m_mass <= 0 )
	{
		return;
	}

	glPointSize( 4 );
	glColor4d( 0.6, 0.2, 0.2, 0.2 );
	glBegin( GL_POINTS );
		glVertex3dv( m_centerOfMass );	
	glEnd();
	static GLubyte halftone[] = {
		0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55};
	glPolygonStipple( halftone );
	glPushMatrix();
	{

		glTranslated( m_centerOfMass[0], m_centerOfMass[1], m_centerOfMass[2] );
		double origin[3];
		double x[3];
		double y[3];
		double z[3];
		for( int i = 0; i < 3; ++i )
		{
			origin[i] = 0;
			x[i] = ( 0 == i );
			y[i] = ( 1 == i );
			z[i] = ( 2 == i );
		}
		glScaled( getMoment(x), getMoment(y), getMoment(z) );

		glEnable(GL_POLYGON_STIPPLE);

		static GLUquadricObj *sphere = gluNewQuadric();
		glPushMatrix();
		glTranslated(origin[0],origin[1],origin[2]);
		gluQuadricNormals(sphere,(GLenum) GLU_SMOOTH);
		gluSphere(sphere, m_mass * m_displayScale, 32, 32);
		glPopMatrix();

		glDisable(GL_POLYGON_STIPPLE);
	}
	glPopMatrix();
}

