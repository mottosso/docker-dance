/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

/**********************************************************
	(EditWindow) Authored by:
		Julia Uskolovsky (jusko@ucla.edu)
**********************************************************/

#include "EditWindow.h"
#include "dance.h"
#include "danceInterp.h"
#include "ViewManager.h"
#include "DView.h"
#include "Joint.h"
#include "Link.h"
#include <fltk/file_chooser.h>
#include <fltk/ask.h>
#include <queue>
#include "ArticulatedObjectWindow.h"

#define MAX_BRANCHING 10 

using namespace fltk;
using namespace std;

EditWindow::EditWindow(ArticulatedObject* artObj, int x, int y, int w, int h, const char* name, int winMode) : Window(x, y, w, h, name)
{
	oldTopology = NULL;
	this->ao = artObj;
	this->mode = winMode;

	zeroVector(zero);

	editJointMode = false;
	editJointTypeMode = false;
	editNameMode = false;
	editJointDOFMode = false;
        editJointDOFSelection = -1;

	firstTime = true;
	isModified = false;
	global = true;
	editSubtree = false;

	zeroVector(tempJpos);
	zeroVector(tempEF);
	zeroVector(tempCM);

	tempJointType = -1;

	this->callback(window_callback, this);

	this->begin();

	inputLinkJointName = new Input(190, 5, 80, 20, "Link/Joint Name");
	inputLinkJointName->callback(inputLinkJointName_cb, this);
	inputLinkJointName->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
	inputLinkJointName->activate();

	int delta = 10;
	
	Group* groupJointPos;
	groupJointPos = new Group(10, 35, 265, 105, "Joint Position");
	groupJointPos->box(fltk::BORDER_BOX);
	groupJointPos->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupJointPos->begin();
	
	choiceJointType = new Choice(80, 5, 80, 20);
	choiceJointType->align(ALIGN_LEFT);
	choiceJointType->callback(JointTypeChoice_cb, this);

	choiceJointDOF = new Choice(170, 5, 80, 20);
	choiceJointDOF->align(ALIGN_LEFT);
	choiceJointDOF->callback(JointDOFChoice_cb, this);


	char xyz[3][3] = { "X:", "Y:", "Z:"};
	for (int n = 0; n < 3; n++)
	{
		inputJointTranslate[n] = new FloatInput(20 + delta, 30 + 25 * n, 80, 20, strdup(xyz[n]));
		inputJointTranslate[n]->callback(inputTranslate_input_cb, this);
		inputJointTranslate[n]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
		inputJointTranslate[n]->deactivate();

		wheelJointTranslate[n] = new ThumbWheel(110 + delta + delta, 30 + 25 * n, 120, 20);
		wheelJointTranslate[n]->callback(wheelTranslate_ThumbWheel_cb, this);
		wheelJointTranslate[n]->value(0.0);
		wheelJointTranslate[n]->step(0.01);
		wheelJointTranslate[n]->range(MINFLOAT, MAXFLOAT);	
		wheelJointTranslate[n]->deactivate();
	}

	groupJointPos->end();


	Group* groupEndEffPos;
	groupEndEffPos = new Group(10, 145, 265, 95, "End Effector Offset");
	groupEndEffPos->box(fltk::BORDER_BOX);
	groupEndEffPos->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupEndEffPos->begin();
	
	checkbuttonEFLinkToChild = new CheckButton(170, 0, 80, 20, "Link with Child");
	checkbuttonEFLinkToChild->callback(checkbuttonEFLinkToChild_cb, this);
	checkbuttonEFLinkToChild->value(false);

	for (int n = 0; n < 3; n++)
	{
		inputEFTranslate[n] = new FloatInput(20 + delta, 20 + 25 * n, 80, 20, strdup(xyz[n]));
		inputEFTranslate[n]->callback(inputTranslate_input_cb, this);
		inputEFTranslate[n]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
		inputEFTranslate[n]->deactivate();

		wheelEFTranslate[n] = new ThumbWheel(110 + delta + delta, 20 + 25 * n, 120, 20);
		wheelEFTranslate[n]->callback(wheelTranslate_ThumbWheel_cb, this);
		wheelEFTranslate[n]->value(0.0);
		wheelEFTranslate[n]->step(0.01);
		wheelEFTranslate[n]->range(MINFLOAT, MAXFLOAT);	
		wheelEFTranslate[n]->deactivate();
	}
	groupEndEffPos->end();


	Group* groupCenMassPos;
	groupCenMassPos = new Group(10, 245, 265, 95, "Center of Mass Position");
	groupCenMassPos->box(fltk::BORDER_BOX);
	groupCenMassPos->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupCenMassPos->begin();
	
	checkbuttonCMdefault = new CheckButton(170, 0, 80, 20, "Default");
	checkbuttonCMdefault->callback(comDefault_cb, this);
	checkbuttonCMdefault->value(true);

	for (int n = 0; n < 3; n++)
	{
		inputCOMTranslate[n] = new FloatInput(20 + delta, 20 + 25 * n, 80, 20, strdup(xyz[n]));
		inputCOMTranslate[n]->callback(inputTranslate_input_cb, this);
		inputCOMTranslate[n]->when(WHEN_ENTER_KEY | WHEN_NOT_CHANGED);
		inputCOMTranslate[n]->deactivate();

		wheelCOMTranslate[n] = new ThumbWheel(110 + delta + delta, 20 + 25 * n, 120, 20);
		wheelCOMTranslate[n]->callback(wheelTranslate_ThumbWheel_cb, this);
		wheelCOMTranslate[n]->value(0.0);
		wheelCOMTranslate[n]->step(0.01);
		wheelCOMTranslate[n]->range(-10.0, 10.0);	
		wheelCOMTranslate[n]->deactivate();
	}

	groupCenMassPos->end();

	Group* groupCoordSys;
	groupCoordSys = new Group(15, 355, 100, 40, "Coordinate System");
	groupCoordSys->box(fltk::BORDER_BOX);
	groupCoordSys->align(ALIGN_TOP | ALIGN_LEFT);
	groupCoordSys->begin();

	radiobuttonGlobal = new RadioButton(5, 0, 50, 20, "Global");
	radiobuttonGlobal->callback(radiobuttonGlobal_cb, this);
	radiobuttonGlobal->setonly();

	radiobuttonLocal = new RadioButton(5, 20, 50, 20, "Local");
	radiobuttonLocal->callback(radiobuttonLocal_cb, this);

	groupCoordSys->end();

	if (mode == EDIT_MODE)
	{
		Group* groupEditMode = new Group(125, 355, 150, 40, "Edit Mode");
		groupEditMode->box(fltk::BORDER_BOX);
		groupEditMode->align(ALIGN_TOP | ALIGN_LEFT);
		groupEditMode->begin();

		radiobuttonActiveLink = new RadioButton(5, 0, 50, 20, "Change Link Only");
		radiobuttonActiveLink->callback(radiobuttonActiveLink_cb, this);
		radiobuttonActiveLink->setonly();

		radiobuttonSubtree = new RadioButton(5, 20, 50, 20, "Change Link and Children");
		radiobuttonSubtree->callback(radiobuttonSubtree_cb, this);

		groupEditMode->end();
	}

	// both modes: add "Cancel" button
	// edit mode: add "Change" and "Delete" buttons
	if (mode == EDIT_MODE)
	{

		buttonChange = new Button(10, 405, 80, 20, "Change");
		buttonChange->callback(buttonChange_cb, this);
		buttonChange->deactivate();

		buttonDelete = new Button(100, 405, 80, 20, "Delete");
		buttonDelete->callback(buttonDelete_cb, this);
		buttonDelete->deactivate();

		buttonCancelandReset = new Button(190, 405, 80, 20, "Cancel");
		buttonCancelandReset->callback(buttonCancelandReset_cb, this);
		buttonCancelandReset->activate();
		buttonCreate = NULL;
	}
	else if (mode == NEW_MODE)		// new mode: add "Create" button, add "Cancel" button
	{
		buttonCancelandReset = new Button(140, 405, 100, 20, "Cancel");
		buttonCancelandReset->callback(buttonCancelandReset_cb, this);
		buttonCancelandReset->activate();

		buttonCreate = new Button(15, 405, 100, 20, "Create");
		buttonCreate->callback(buttonCreate_cb, this);
		buttonCreate->deactivate();
		buttonChange = NULL;
		buttonDelete = NULL;
	}

	if (mode == NEW_MODE)
	{
		this->setFieldValue(this->inputJointTranslate, zero);
		this->setFieldValue(this->wheelJointTranslate, zero);

		this->setFieldValue(this->inputEFTranslate, zero);
		this->setFieldValue(this->wheelEFTranslate, zero);

		this->setFieldValue(this->inputCOMTranslate, zero);
		this->setFieldValue(this->wheelCOMTranslate, zero);
	}

	this->end();
}

EditWindow::~EditWindow()
{
	for (int n = 0; n < 3; n++)
	{
		delete inputEFTranslate[n];
		delete wheelEFTranslate[n];
		delete inputJointTranslate[n];
		delete wheelJointTranslate[n];
		delete inputCOMTranslate[n];
		delete wheelCOMTranslate[n];
	}
}

void EditWindow::show()
{
	this->updateGUI();

	Window::show();
}

void EditWindow::setNewMode()
{
	mode = NEW_MODE;
}

void EditWindow::setEditMode()
{
	mode = EDIT_MODE;
}

// called when window is closed
void EditWindow::close_window(fltk::Widget* o, void* p)
{
	window_callback(o, p);
}

// window_callback:
// if changes haven't been saved, queries user
// sets interaction mode for ArticulatedObject to INTERACT_NONE
// reactivates main window
void EditWindow::window_callback(Widget* widget, void* p) 
{
	EditWindow* win = (EditWindow*) p;

	if (win->ao->getNumJoints() != 0)
	{
		if (win->mode != NEW_MODE || win->buttonCreate->active() )
		{
			if (ask("Do you want to save your changes?"))		// pop up message (Save?)
			{
				if (win->mode == NEW_MODE)
					win->buttonCreate_cb(widget, p);

				if (win->mode == EDIT_MODE)
					win->buttonChange_cb(widget, p);
			}
			else	// if not saved, reset previous values
			{
				win->reset(widget, p);  
			}
		}
	}

	if (win->mode == EDIT_MODE)
		win->buttonDelete->activate();

	// if last created joint/link not saved, delete it
	if (win->mode == NEW_MODE)
	{
		if (win->isModified == true)
		{
			win->ao->setEmpty(false);

			win->deleteLinkJoint(win->ao->getActiveLink(), win->ao->getActiveJoint());
		}
		win->isModified = false;
	}

	win->setFieldValue(win->inputEFTranslate, win->zero);
	win->setFieldValue(win->wheelEFTranslate, win->zero);

	if (win->oldTopology != NULL)
		delete win->oldTopology;

	
	// hide current window
	((Window*)widget)->hide();

	// set articulated object mode
	win->ao->setInteractionMode(INTERACT_NONE);

	ArticulatedObjectWindow* aowin = (ArticulatedObjectWindow*) win->ao->getInterface();
	if (win->ao->getActiveJoint() != NULL)
		aowin->selectJoint(win->ao->getActiveJoint()->getJointNum());

	aowin->updateGUI();

	// reactivate parent window	
	aowin->activate();

	win->updateSimulators();

	dance::AllViews->postRedisplay();
}

void EditWindow::updateGUI()
{
	Vector jpos;
	Vector EFpos;
	Vector CMpos;

	// if original state of link, then store its values (joint pos, end eff, center of mass)
	if (firstTime && this->ao->getNumJoints() != 0 && mode == EDIT_MODE)
	{
		oldTopology = new Topology(this->ao);

		firstTime = false;
	}

	// present the joint choices
	int oldType = choiceJointType->value();

	choiceJointType->clear();
	choiceJointType->add("Weld");
	choiceJointType->add("Pin");
	choiceJointType->add("Universal");
	choiceJointType->add("Gimbal");
	choiceJointType->add("Ball");

	if (mode == EDIT_MODE && this->ao->getActiveJoint()->getJointNum() == 0)		// if root, then free joint
		choiceJointType->add("Free");
	else if (mode == NEW_MODE && this->ao->isEmpty() && (this->ao->getActiveJoint() == NULL || this->ao->getActiveJoint()->getJointNum() == 0))
		choiceJointType->add("Free");												// if creating first link, free joint type

	// set joint type menu option
	if (editJointTypeMode == false)
	{
		choiceJointDOF->clear();
		int order = 0;
		if (ao->getActiveJoint() != NULL)
			order = ao->getActiveJoint()->determineRotationOrder();

		
		int curType = 0;
		if (firstTime)
		{
			if (ao->getActiveLink() != NULL && ao->getActiveLink()->getParentJoint() != NULL && ao->isEmpty())
			{
				curType = ao->getActiveLink()->getParentJoint()->getJointType();
			}
			else
			{
				if (this->ao->getNumJoints() == 0)
					curType = J_FREE;
				else
					curType = J_BALL;
			}
		}
		else
		{
			if (ao->getActiveLink() != NULL)
				curType = ao->getActiveLink()->getParentJoint()->getJointType();
			else
			{
				if (oldType == 0)
					curType = J_WELD;
				else if (oldType == 1)
					curType = J_PIN;
				else if (oldType == 2)
					curType = J_UNIVERSAL;
				else if (oldType == 3)
					curType = J_GIMBAL;
				else if (oldType == 4)
					curType = J_BALL;
				else if (oldType == 5)
					curType = J_FREE;
				else
					danceInterp::OutputMessage("Unknown choice for joint type: %d", oldType);
			}
		}

		switch (curType)
		{
		case J_WELD:
			choiceJointType->value(0);
			break;
		case J_PIN:
			choiceJointType->value(1);
			choiceJointDOF->add("X");
			choiceJointDOF->add("Y");
			choiceJointDOF->add("Z");
			if (editJointDOFSelection > -1)
			{
				choiceJointDOF->value(editJointDOFSelection);
			}
			else
			{
				if (order == Matrix3x3::X)
					choiceJointDOF->value(0);
				else if (order == Matrix3x3::Y)
					choiceJointDOF->value(1);
				else if (order == Matrix3x3::Z)
					choiceJointDOF->value(2);
			}
			break;
		case J_UNIVERSAL:
			choiceJointType->value(2);
			choiceJointDOF->add("XY");
			choiceJointDOF->add("XZ");
			choiceJointDOF->add("YX");
			choiceJointDOF->add("YZ");
			choiceJointDOF->add("ZX");
			choiceJointDOF->add("ZY");
			if (editJointDOFSelection > -1)
			{
				choiceJointDOF->value(editJointDOFSelection);
			}
			else
			{
				if (order == Matrix3x3::XY)
					choiceJointDOF->value(0);
				else if (order == Matrix3x3::XZ)
					choiceJointDOF->value(1);
				else if (order == Matrix3x3::YX)
					choiceJointDOF->value(2);
				else if (order == Matrix3x3::YZ)
					choiceJointDOF->value(3);
				else if (order == Matrix3x3::ZX)
					choiceJointDOF->value(4);
				else if (order == Matrix3x3::ZY)
					choiceJointDOF->value(5);
			}
			break;
		case J_GIMBAL:
			choiceJointType->value(3);
			choiceJointDOF->add("XYZ");
			choiceJointDOF->add("XZY");
			choiceJointDOF->add("YXZ");
			choiceJointDOF->add("YZX");
			choiceJointDOF->add("ZXY");
			choiceJointDOF->add("ZYX");
			if (editJointDOFSelection > -1)
			{
				choiceJointDOF->value(editJointDOFSelection);
			}
			else
			{
				if (order == Matrix3x3::XYZ)
					choiceJointDOF->value(0);
				else if (order == Matrix3x3::XZY)
					choiceJointDOF->value(1);
				else if (order == Matrix3x3::YXZ)
					choiceJointDOF->value(2);
				else if (order == Matrix3x3::YZX)
					choiceJointDOF->value(3);
				else if (order == Matrix3x3::ZXY)
					choiceJointDOF->value(4);
				else if (order == Matrix3x3::ZYX)
					choiceJointDOF->value(5);
			}
			break;
		case J_BALL:
			choiceJointType->value(4);
			choiceJointDOF->add("XYZ");
			if (editJointDOFSelection > -1)
			{
				choiceJointDOF->value(editJointDOFSelection);
			}
			else
			{
				choiceJointDOF->value(0);
			}
			break;
		case J_FREE:
			choiceJointType->value(5);
			choiceJointDOF->add("XYZ");
			choiceJointDOF->add("XZY");
			choiceJointDOF->add("YXZ");
			choiceJointDOF->add("YZX");
			choiceJointDOF->add("ZXY");
			choiceJointDOF->add("ZYX");
			if (editJointDOFSelection > -1)
			{
				choiceJointDOF->value(editJointDOFSelection);
			}
			else
			{
				if (order == Matrix3x3::XYZ)
					choiceJointDOF->value(0);
				else if (order == Matrix3x3::XZY)
					choiceJointDOF->value(1);
				else if (order == Matrix3x3::YXZ)
					choiceJointDOF->value(2);
				else if (order == Matrix3x3::YZX)
					choiceJointDOF->value(3);
				else if (order == Matrix3x3::ZXY)
					choiceJointDOF->value(4);
				else if (order == Matrix3x3::ZYX)
					choiceJointDOF->value(5);
			}
			break;

		default:
			break;
		}
	}
	else
	{
		choiceJointDOF->clear();
		// joint and/or dof has been selected, show current values
		switch (editJointTypeSelection)
		{
		case 0: // WELD
			choiceJointType->value(0);
			break;
			break;
		case 1: // PIN
			choiceJointType->value(1);
			choiceJointDOF->add("X");
			choiceJointDOF->add("Y");
			choiceJointDOF->add("Z");
			choiceJointDOF->value(editJointDOFSelection);
			break;
		case 2: // UNIVERSAL
			choiceJointType->value(2);
			choiceJointDOF->add("XY");
			choiceJointDOF->add("XZ");
			choiceJointDOF->add("YX");
			choiceJointDOF->add("YZ");
			choiceJointDOF->add("ZX");
			choiceJointDOF->add("ZY");
			choiceJointDOF->value(editJointDOFSelection);
			break;
		case 3: // GIMBAL
			choiceJointType->value(3);
			choiceJointDOF->add("XYZ");
			choiceJointDOF->add("XZY");
			choiceJointDOF->add("YXZ");
			choiceJointDOF->add("YZX");
			choiceJointDOF->add("ZXY");
			choiceJointDOF->add("ZYX");
			choiceJointDOF->value(editJointDOFSelection);
			break;
		case 4: // BALL
			choiceJointType->value(4);
			choiceJointDOF->add("XYZ");
			choiceJointDOF->value(editJointDOFSelection);
			break;
		case 5: // FREE
			choiceJointType->value(5);
			choiceJointDOF->add("XYZ");
			choiceJointDOF->add("XZY");
			choiceJointDOF->add("YXZ");
			choiceJointDOF->add("YZX");
			choiceJointDOF->add("ZXY");
			choiceJointDOF->add("ZYX");
			choiceJointDOF->value(editJointDOFSelection);
			break;
		}
	}


	// if new mode: activate joint position for empty object, joint and endeff position otherwise
	if (mode == NEW_MODE)
	{	
		checkbuttonEFLinkToChild->deactivate();

		if (this->checkbuttonCMdefault->value() || this->radiobuttonLocal->value())
		{
			FieldDeactivate(wheelCOMTranslate);
			FieldDeactivate(inputCOMTranslate);
		}
		else
		{
			FieldActivate(wheelCOMTranslate);
			FieldActivate(inputCOMTranslate);
		}
		
		// activate Joint, End Effector, and Center of Mass fields
		if (this->ao->getNumJoints() == 0 || (this->ao->getNumJoints() == 1 && isModified == true))	
		{
			FieldActivate(wheelJointTranslate);
			FieldActivate(inputJointTranslate);

			FieldActivate(wheelEFTranslate);
			FieldActivate(inputEFTranslate);

			this->radiobuttonGlobal->deactivate();
			this->radiobuttonLocal->deactivate();

			if (ao->getNumJoints() == 0)
			{
				// set default root link name
				inputLinkJointName->value("Root_Link");

				// set all input values to zero
				setFieldValue(inputJointTranslate, zero);
				setFieldValue(wheelJointTranslate, zero);

				setFieldValue(inputEFTranslate, zero);
				setFieldValue(wheelEFTranslate, zero);

				setFieldValue(inputCOMTranslate, zero);
				setFieldValue(wheelCOMTranslate, zero);
			}
			else	// if object non-empty
			{
				if (this->editNameMode == false && this->isModified == false)
				{
					// set default link name to (1 + numberOfLinks)
					int numLinks = ao->getNumLinks();
					string tempName;
				    sprintf(&tempName[0], "link%d", numLinks);
					inputLinkJointName->value(&tempName[0]);
				}
				else if (editNameMode == false)
					inputLinkJointName->value(ao->getActiveLink()->getName());
				else
					inputLinkJointName->value(&tempName[0]);
			}
		}
		else	// activate only End Effector field and set joint position
		{
			this->radiobuttonGlobal->activate();

			if (this->isModified == false)
			{
				// set link name to current name or last edited name
				if (this->editNameMode == false)
				{
					int numLinks = ao->getNumLinks();
					string tempName;
				    sprintf(&tempName[0], "link%d", numLinks);
					inputLinkJointName->value(&tempName[0]);
				}
				else
					inputLinkJointName->value(&tempName[0]);

				Vector temp;
				this->ao->getActiveLink()->getEndEffector(temp);

				double matrix[4][4];
				ao->getActiveJoint()->getOutboardLink()->getWTransMat(matrix);
				transformPoint_mat(temp, matrix);

				// set joint position and com input to end effector position of previous link
				if (global)
				{
					setFieldValue(inputJointTranslate, temp);
					setFieldValue(wheelJointTranslate, temp);
				}
				else
				{
					Vector local_temp;
					ao->getActiveLink()->getLocalCoord(local_temp, temp);
					setFieldValue(inputJointTranslate, local_temp);
					setFieldValue(wheelJointTranslate, local_temp);
				}
	
				if (global)
				{
					setFieldValue(inputCOMTranslate, temp);
					setFieldValue(wheelCOMTranslate, temp);
				}
				else
				{
					setFieldValue(inputCOMTranslate, zero);
					setFieldValue(wheelCOMTranslate, zero);
				}

				if (global) // if global mode, set to position of previous end effector
				{
					setFieldValue(inputEFTranslate, temp);
					setFieldValue(wheelEFTranslate, temp);
				}
				else // if local mode, set end effector offset fields to zero
				{
					setFieldValue(inputEFTranslate, zero);
					setFieldValue(wheelEFTranslate, zero);
				}
			}
			else
			{
				// fill the input and wheel values
				double matrix[4][4];
				ao->getActiveLink()->getWTransMat(matrix);
				double invMatrix[4][4];
				ao->getActiveLink()->getInvTransMat(invMatrix);

				// joint position
				ao->getActiveJoint()->getPosition(jpos);
				if (!this->global)
					transformPoint_mat(jpos, invMatrix);
				setFieldValue(inputJointTranslate, jpos);
				setFieldValue(wheelJointTranslate, jpos);

				// center of mass
				ao->getActiveLink()->getPosition(CMpos);
				if (!this->global)
					transformPoint_mat(CMpos, invMatrix);
				setFieldValue(inputCOMTranslate, CMpos);
				setFieldValue(wheelCOMTranslate, CMpos);

				// end effector offset from joint
				this->ao->getActiveLink()->getEndEffector(EFpos); 
				if (this->global)
					transformPoint_mat(EFpos, matrix);
//				if (!this->global)
//					transformPoint_mat(EFpos, invMatrix);
				setFieldValue(inputEFTranslate, EFpos);
				setFieldValue(wheelEFTranslate, EFpos);
			}

			// deactivate joint position field
			FieldActivate(wheelJointTranslate);
			FieldActivate(inputJointTranslate);

			// activate end effector offset field
			FieldActivate(wheelEFTranslate);
			FieldActivate(inputEFTranslate);

			// activate end effector offset field
			if (this->checkbuttonCMdefault->value() || !this->global)
			{
				FieldDeactivate(wheelCOMTranslate);
				FieldDeactivate(inputCOMTranslate);
			}
			else
			{
				FieldActivate(wheelCOMTranslate);
				FieldActivate(inputCOMTranslate);
			}

			this->radiobuttonGlobal->activate();
			this->radiobuttonLocal->activate();
		}

		// if no changes have been made, deactivate create button
		if (isModified == false)
			buttonCreate->deactivate();
		else
			buttonCreate->activate();	// otherwise, activate
	}
	else if (mode == EDIT_MODE)
	{

		checkbuttonEFLinkToChild->activate();

		// if non empty object
		if (this->ao->getNumJoints() != 0)
		{
			this->radiobuttonGlobal->activate();
			// if empty or active link is root, deactivate local mode
			if (this->ao->getActiveLink()->getParentLink() == NULL)
			{
				global = true;
				this->radiobuttonGlobal->setonly();
				this->radiobuttonLocal->deactivate();
			}
			else
				this->radiobuttonLocal->activate();

			// set joint/link name field
			if (this->editNameMode == false)
				inputLinkJointName->value(ao->getActiveLink()->getName());
			else
				inputLinkJointName->value(&tempName[0]);


			// activate Joint, Center of Mass, and End Effector position groups
			FieldActivate(wheelJointTranslate);
			FieldActivate(inputJointTranslate);

			FieldActivate(wheelEFTranslate);
			FieldActivate(inputEFTranslate);

			// calculate COM automatically if 'default' is checked.
			// alternatively, don't show the COM if in local mode. COM is always 0,0,0
			if (this->checkbuttonCMdefault->value() || !this->global)
			{
				FieldDeactivate(wheelCOMTranslate);
				FieldDeactivate(inputCOMTranslate);
			}
			else
			{
				FieldActivate(wheelCOMTranslate);
				FieldActivate(inputCOMTranslate);
			}

			buttonCancelandReset->activate();
			buttonDelete->activate();
			radiobuttonGlobal->activate();

			// if empty or active link is root, deactivate local mode
			if (this->ao->getActiveLink()->getParentLink() == NULL)
				this->radiobuttonLocal->deactivate();
			else
				this->radiobuttonLocal->activate();

			choiceJointType->activate();			

			// fill the input and wheel values
			double matrix[4][4];
			ao->getActiveLink()->getWTransMat(matrix);
			double invMatrix[4][4];
			ao->getActiveLink()->getInvTransMat(invMatrix);

			// joint position
			ao->getActiveJoint()->getPosition(jpos);
			if (!this->global /* && ao->getActiveLink()->getParentLink() != NULL */)
				transformPoint_mat(jpos, invMatrix);				// change to local coordinates if !global and not parent link
			setFieldValue(inputJointTranslate, jpos);
			setFieldValue(wheelJointTranslate, jpos);

			// end effector offset from joint
			this->ao->getActiveLink()->getEndEffector(EFpos); 
			transformPoint_mat(EFpos, matrix);
			if (!this->global /* && ao->getActiveLink()->getParentLink() != NULL */)
				transformPoint_mat(EFpos, invMatrix);				// change to local coordinates if !global and not parent link
			setFieldValue(inputEFTranslate, EFpos);
			setFieldValue(wheelEFTranslate, EFpos);
			
			// center of mass position
			ao->getActiveLink()->getWorldCoord(CMpos, zero);
			if (!this->global /* && ao->getActiveLink()->getParentLink() != NULL */)
				transformPoint_mat(CMpos, invMatrix);				// change to local coordinates if !global and not parent link
			setFieldValue(inputCOMTranslate, CMpos);
			setFieldValue(wheelCOMTranslate, CMpos);


		}
		else		// if empty object
		{
			// deactivate Joint, Center of Mass, and End Effector position groups
			FieldDeactivate(wheelJointTranslate);
			FieldDeactivate(inputJointTranslate);

			FieldDeactivate(wheelEFTranslate);
			FieldDeactivate(inputEFTranslate);

			if (this->checkbuttonCMdefault->value() && !this->global)
			{
				FieldDeactivate(wheelCOMTranslate);
				FieldDeactivate(inputCOMTranslate);
			}
			else
			{
				FieldActivate(wheelCOMTranslate);
				FieldActivate(inputCOMTranslate);
			}

			// reset
			reset(NULL, this);

			buttonCancelandReset->deactivate();
			buttonDelete->deactivate();
			buttonChange->deactivate();
			radiobuttonGlobal->deactivate();
			radiobuttonLocal->deactivate();

			radiobuttonActiveLink->deactivate();
			radiobuttonSubtree->deactivate();
			choiceJointType->deactivate();			
		}

		if (this->ao->getNumJoints() == 0)
		{
			buttonChange->deactivate();
			buttonDelete->deactivate();
		}
		else if (editJointMode || editJointTypeMode || editNameMode || editJointDOFMode)	// if any changes have been made (positions, joint type, or name)
		{
			buttonChange->activate();
			buttonDelete->deactivate();
		}
		else
		{
			buttonChange->deactivate();
			buttonDelete->activate();
		}

		// if current window is hidden, reset CoM default button
		if (!this->visible())
			this->checkbuttonCMdefault->value(true);

	}
}

void EditWindow::inputLinkJointName_cb(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	win->editNameMode = true;
	win->tempName = win->inputLinkJointName->value();

	if (win->mode == NEW_MODE)
		win->buttonCreate->activate();
	else if (win->mode == EDIT_MODE)
		win->buttonChange->activate();
}

void EditWindow::buttonCancelandReset_cb(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	if (win->mode == EDIT_MODE)
	{
		win->buttonDelete->activate();
		win->reset(win, p);
	}

	if (win->mode == NEW_MODE)
	{
		if (win->isModified == true)
		{
			win->ao->setEmpty(false);
			win->deleteLinkJoint(win->ao->getActiveLink(), win->ao->getActiveJoint());
		}
		win->isModified = false;
	}

	win->setFieldValue(win->inputEFTranslate, win->zero);
	win->setFieldValue(win->wheelEFTranslate, win->zero);

	// hide current window
	((Window*)win)->hide();

	ArticulatedObjectWindow* aowin = (ArticulatedObjectWindow*) win->ao->getInterface();
	if (win->ao->getActiveJoint() != NULL)
		aowin->selectJoint(win->ao->getActiveJoint()->getJointNum());

	// set articulated object mode
	win->ao->setInteractionMode(INTERACT_NONE);

	aowin->updateGUI();

	// reactivate parent window	
	aowin->activate();

	dance::AllViews->postRedisplay();
/*
	win->reset(o, p);

	if (win->mode == EDIT_MODE)
		win->buttonDelete->activate();

	if (win->mode == NEW_MODE)
		win->buttonCreate->deactivate();

	dance::AllViews->postRedisplay();
	win->show();*/
}

void EditWindow::reset(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	if (mode == EDIT_MODE)
	{
		if (this->ao->getActiveJoint() != NULL)
		{
			this->buttonDelete->activate();
		}
		else	// if active joint does not exist
		{
			this->buttonDelete->deactivate();
			this->buttonChange->deactivate();

			delete oldTopology;
			oldTopology = NULL;
		}

		double* origState = new double[ao->getStateSize()];
		ao->getState(origState);

		ao->setZeroState();

		Link* prevLink = win->ao->getActiveLink();
		Joint* prevJoint = win->ao->getActiveJoint();
		// reset the joints according to the old topology
		for (int x = 0; x < win->ao->getNumJoints(); x++)
		{
			Link* curLink = win->ao->getLink(x);
			win->ao->setActiveLink(curLink);
			win->ao->setActiveJoint(curLink->getParentJoint());
			double* com = oldTopology->getCOM(x);
			double* endEff = oldTopology->getEndEff(x);
			double* joint = oldTopology->getJoint(x);

			if (win->checkbuttonCMdefault->value())
			{
				Vector CoM;

				// if free joint, center of mass at joint
				if (win->ao->getActiveJoint()->getJointType() == J_FREE)
					VecCopy(CoM, joint);
				else
				{
				//else center of mass in the middle
					VecAdd(CoM, joint, endEff);
					VecScale(CoM, 0.5);
				}
				win->deltaJointandEndEffectorPos(joint, endEff, CoM, false);
			}
			else
				win->deltaJointandEndEffectorPos(joint, endEff, com, false);

			Joint* curJoint = curLink->getParentJoint();
			int type = oldTopology->getJointType(x);
			if (type != curJoint->getJointType())
			{
				curJoint->changeType(type);
				// set the joint limits
				for (int x = 0; x < 3; x++)
					curJoint->setLimits(x, -180, 180);
			}
			int order = oldTopology->getDOF(x);
			if (curJoint->determineRotationOrder() != order)
			{
				curJoint->setRotationOrder(order);
			}
		}
		win->ao->setActiveLink(prevLink);
		win->ao->setActiveJoint(prevJoint);

		win->editJointTypeMode = false;

		ao->setState(origState);
		delete [] origState;
	}
	else if (mode == NEW_MODE)
	{
		win->deleteLinkJoint(win->ao->getActiveLink(), win->ao->getActiveJoint());
		win->isModified = false;
		win->updateGUI();
	}

	editJointMode = false;
	editNameMode = false;
	editJointDOFSelection = -1;
}

void EditWindow::radiobuttonGlobal_cb(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	win->global = true;
	win->updateGUI();
}

void EditWindow::radiobuttonLocal_cb(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	win->global = false;
	win->updateGUI();
}

void EditWindow::radiobuttonActiveLink_cb(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	win->editSubtree = false;
}

void EditWindow::radiobuttonSubtree_cb(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	win->editSubtree = true;
}

void EditWindow::JointTypeChoice_cb(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	win->editJointTypeMode = true;
	win->editJointDOFMode = true;

	win->editJointTypeSelection = win->choiceJointType->value();
	win->editJointDOFSelection = 0;

	ArticulatedObjectWindow* aowin = (ArticulatedObjectWindow*) win->ao->getInterface();
	if (win->ao->getActiveJoint() != NULL)
		aowin->selectJoint(win->ao->getActiveJoint()->getJointNum());
	win->isModified = true;

	Vector jpos;
	Vector EFpos;
	Vector CMpos;
	win->getFieldValue(win->inputJointTranslate, jpos);
	win->getFieldValue(win->inputEFTranslate, EFpos);
	win->getFieldValue(win->inputCOMTranslate, CMpos);
	
	if (win->choiceJointType->value() == 5) // if free joint, place the center of mass at joint
	{
		VecCopy(CMpos, jpos);
	}
	else // if not a FREE joint, plaace the center of mass halfway between the end effector and the joint if the COM is on the joint
	{
		if (fabs(VecDist(CMpos, jpos)) < 10e-6)
		{
			VecAdd(CMpos, jpos, EFpos);
			VecScale(CMpos, 0.5);
		}
	}
	win->deltaJointandEndEffectorPos(jpos, EFpos, CMpos, win->editSubtree);

	win->setFieldValue(win->inputJointTranslate, jpos);
	win->setFieldValue(win->inputEFTranslate, EFpos);
	win->setFieldValue(win->inputCOMTranslate, CMpos);
	win->setFieldValue(win->wheelJointTranslate, jpos);
	win->setFieldValue(win->wheelEFTranslate, EFpos);
	win->setFieldValue(win->wheelCOMTranslate, CMpos);

	win->updateGUI();
	dance::Refresh();
}

void EditWindow::JointDOFChoice_cb(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	win->editJointDOFMode = true;
	win->editJointDOFSelection = win->choiceJointDOF->value();
	ArticulatedObjectWindow* aowin = (ArticulatedObjectWindow*) win->ao->getInterface();
	aowin->selectJoint(win->ao->getActiveJoint()->getJointNum());

	win->updateGUI();
}

// buttonDelete_cb:
// delete's active link (in EDIT mode)
void EditWindow::buttonDelete_cb(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	// set to get new original values (of previous link)
	win->firstTime = true;

	danceInterp::OutputMessage("delete joint/link mode is now on");

	// delete link
	win->deleteLinkJoint(win->ao->getActiveLink(), win->ao->getActiveJoint());

	// reset fields
//	if (win->ao->getNumJoints() == 0)
//		win->reset(o, p);

	// hide current window
	((Window*)win)->hide();

	// set articulated object mode
	win->ao->setInteractionMode(INTERACT_NONE);

	//  reset all edit modes
	win->editJointTypeMode = false;
	win->editNameMode = false;
	win->editJointMode = false;

	ArticulatedObjectWindow* aowin = (ArticulatedObjectWindow*) win->ao->getInterface();
	if (win->ao->getActiveJoint() != NULL)
		aowin->selectJoint(win->ao->getActiveJoint()->getJointNum());

	// update parent window
	aowin->updateGUI();

	// reactivate parent window	
	aowin->activate();

	dance::AllViews->postRedisplay();
}

// buttonChange_cb:
// save changes made to joint/link position, joint type, and name
void EditWindow::buttonChange_cb(fltk::Widget* o, void* p)
{
	Vector jpos;
	Vector EFpos;
	Vector CMpos;

	EditWindow* win = (EditWindow*) p;

	// set current input values to "original" values
	win->getFieldValue(win->inputJointTranslate, jpos);
	win->getFieldValue(win->inputEFTranslate, EFpos);
	win->getFieldValue(win->inputCOMTranslate, CMpos);

	int jointSelection = win->choiceJointType->value();

	if (win->ao->getNumJoints() == 0 || (win->ao->getActiveJoint() != NULL && win->ao->getActiveJoint()->getJointNum() == 0)) // make sure this is the root joint
	{
		if (jointSelection == 5 && !VecEq(jpos, CMpos))
		{
//			int ret = fltk::ask("Open Dynamics Engine cannot support COM of free joint different than location of joint.\nWould you like to change the COM to match the joint position?");
//			if (ret)
//			{
				// keep the end effector in its same location while moving the COM
	//JU			VecCopy(CMpos, jpos);

			// if Center of Mass value set to default, put at joint for FREE joint, else put in the middle (btw joint and end effector position)
			// otherwise, use specified value
			if (win->checkbuttonCMdefault->value())
			{
				Vector CoM;

				// if free joint, center of mass at joint
				if (win->ao->getActiveJoint()->getJointType() == J_FREE)
					VecCopy(CoM, jpos);
				else
				{
				//else center of mass in the middle
					VecAdd(CoM, jpos, EFpos);
					VecScale(CoM, 0.5);
				}

				win->deltaJointandEndEffectorPos(jpos, EFpos, CoM, win->editSubtree);
			}
			else
				win->deltaJointandEndEffectorPos(jpos, EFpos, CMpos, win->editSubtree);
//			}
		}
	}

	//  if end effector offset in local mode, change to global
	if (!win->global)
	{
		double matrix[4][4];
		win->ao->getActiveJoint()->getOutboardLink()->getTransMat(matrix);
		transformPoint_mat(EFpos, matrix);
	}

	Joint* joint = win->ao->getActiveJoint();

	int value = win->choiceJointDOF->value();
	Vector xaxis = {1.0, 0.0, 0.0};
	Vector yaxis = {0.0, 1.0, 0.0};
	Vector zaxis = {0.0, 0.0, 1.0};

	// NEED TO FIX!
	// ODE cannot support a universal joint as a root joint due to limitations of hinge2 joints
	//if (jointSelection == 2 && joint->getJointNum() == 0)
	//{
	//	fltk::alert("Open Dynamics Engine cannot support a hinge2 (universal) joint as the root joint.\nA ball joint will be used instead.");
	//	jointSelection = 4;
	//}


	switch (jointSelection)
	{
		case 0:
			win->ao->getActiveLink()->getParentJoint()->changeType(J_WELD);
			break;
		case 1:
			win->ao->getActiveLink()->getParentJoint()->changeType(J_PIN);
			if (value == 0)  // X
			{
				joint->setAxis(0, xaxis);
			}
			else if (value == 1) // Y
			{
				joint->setAxis(0, yaxis);
			}
			else if (value == 2) // Z
			{
				joint->setAxis(0, zaxis);
			}
			joint->setLimits(0, -180, 180);
			break;
		case 2:
			win->ao->getActiveLink()->getParentJoint()->changeType(J_UNIVERSAL);
			if (value == 0)  // XY
			{
				joint->setAxis(0, xaxis);
				joint->setAxis(1, yaxis);
			}
			else if (value == 1) // XZ
			{
				joint->setAxis(0, xaxis);
				joint->setAxis(1, zaxis);
			}
			else if (value == 2) // YX
			{
				joint->setAxis(0, yaxis);
				joint->setAxis(1, xaxis);
			}
			else if (value == 3) // YZ
			{
				joint->setAxis(0, yaxis);
				joint->setAxis(1, zaxis);
			}
			else if (value == 4) // ZX
			{
				joint->setAxis(0, zaxis);
				joint->setAxis(1, xaxis);
			}
			else if (value == 5) // ZY
			{
				joint->setAxis(0, zaxis);
				joint->setAxis(1, yaxis);
			}
			joint->setLimits(0, -180, 180);
			joint->setLimits(1, -180, 180);
			break;
		case 3:
			win->ao->getActiveLink()->getParentJoint()->changeType(J_GIMBAL);
			if (value == 0)  // XYZ
			{
				joint->setAxis(0, xaxis);
				joint->setAxis(1, yaxis);
				joint->setAxis(2, zaxis);
			}
			else if (value == 1) // XZY
			{
				joint->setAxis(0, xaxis);
				joint->setAxis(1, zaxis);
				joint->setAxis(2, yaxis);
			}
			else if (value == 2) // YXZ
			{
				joint->setAxis(0, yaxis);
				joint->setAxis(1, xaxis);
				joint->setAxis(2, zaxis);
			}
			else if (value == 3) // YZX
			{
				joint->setAxis(0, yaxis);
				joint->setAxis(1, zaxis);
				joint->setAxis(2, xaxis);
			}
			else if (value == 4) // ZXY
			{
				joint->setAxis(0, zaxis);
				joint->setAxis(1, xaxis);
				joint->setAxis(2, yaxis);
			}
			else if (value == 5) // ZYX
			{
				joint->setAxis(0, zaxis);
				joint->setAxis(1, yaxis);
				joint->setAxis(2, xaxis);
			}
			joint->setLimits(0, -180, 180);
			joint->setLimits(1, -180, 180);
			joint->setLimits(2, -180, 180);
			break;
		case 4:
			win->ao->getActiveLink()->getParentJoint()->changeType(J_BALL);
			if (value == 0)  // XYZ
			{
				joint->setAxis(0, xaxis);
				joint->setAxis(1, yaxis);
				joint->setAxis(2, zaxis);
			}
			joint->setLimits(0, -180, 180);
			joint->setLimits(1, -180, 180);
			joint->setLimits(2, -180, 180);
			break;
		case 5:
			win->ao->getActiveLink()->getParentJoint()->changeType(J_FREE);
			if (value == 0)  // XYZ
			{
				joint->setAxis(0, xaxis);
				joint->setAxis(1, yaxis);
				joint->setAxis(2, zaxis);
			}
			else if (value == 1) // XZY
			{
				joint->setAxis(0, xaxis);
				joint->setAxis(1, zaxis);
				joint->setAxis(2, yaxis);
			}
			else if (value == 2) // YXZ
			{
				joint->setAxis(0, yaxis);
				joint->setAxis(1, xaxis);
				joint->setAxis(2, zaxis);
			}
			else if (value == 3) // YZX
			{
				joint->setAxis(0, yaxis);
				joint->setAxis(1, zaxis);
				joint->setAxis(2, xaxis);
			}
			else if (value == 4) // ZXY
			{
				joint->setAxis(0, zaxis);
				joint->setAxis(1, xaxis);
				joint->setAxis(2, yaxis);
			}
			else if (value == 5) // ZYX
			{
				joint->setAxis(0, zaxis);
				joint->setAxis(1, yaxis);
				joint->setAxis(2, xaxis);
			}
			joint->setLimits(0, -180, 180);
			joint->setLimits(1, -180, 180);
			joint->setLimits(2, -180, 180);
			break;
		default:
			break;
	}

	win->editJointTypeMode = false;
	win->editJointDOFMode = false;

	win->ao->getActiveJoint()->setName((char*)win->inputLinkJointName->value());
	win->ao->getActiveLink()->setName((char*)win->inputLinkJointName->value());
	win->editNameMode = false;

	win->editJointMode = false;
	win->editJointDOFMode = false;

	if (win->buttonDelete != NULL)
		win->buttonDelete->activate();
	if (win->buttonChange != NULL)
		win->buttonChange->deactivate();
	if (win->buttonCreate != NULL)
		win->buttonCreate->deactivate();


	win->isModified = false;
	win->ao->setEmpty(false);

	win->setFieldValue(win->inputEFTranslate, win->zero);
	win->setFieldValue(win->wheelEFTranslate, win->zero);
	win->ao->updateStateConfig();

	// hide current window
	((Window*)win)->hide();

	ArticulatedObjectWindow* aowin = (ArticulatedObjectWindow*) win->ao->getInterface();
	if (win->ao->getActiveJoint() != NULL)
		aowin->selectJoint(win->ao->getActiveJoint()->getJointNum());
	else
		aowin->selectJoint(0);

	// set articulated object mode
	win->ao->setInteractionMode(INTERACT_NONE);
	win->ao->recalculateStateSize();

	aowin->updateGUI();


	// reactivate parent window	
	aowin->activate();

	win->updateSimulators();

	dance::AllViews->postRedisplay();
}

// creates link in NEW MODE
void EditWindow::buttonCreate_cb(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	if (win->editNameMode && !win->isValidName(&win->tempName[0]))
	{
		alert("Joint/Link Name cannot include spaces");
		return;
	}

	//if (true) 
	//{
	//	win->buttonChange_cb(o,p);
	//	return;
	//}

	Vector CMpos, jpos, EFpos;
	// set current input values to "original" values
	win->getFieldValue(win->inputJointTranslate, jpos);
	win->getFieldValue(win->inputEFTranslate, EFpos);
	win->getFieldValue(win->inputCOMTranslate, CMpos);

	int jointSelection = win->choiceJointType->value();

	if (win->ao->getNumJoints() == 0 || (win->ao->getActiveJoint() != NULL && win->ao->getActiveJoint()->getJointNum() == 0)) // make sure this is the root joint
	{
		if (jointSelection == 5 && !VecEq(jpos, CMpos))
		{
//			int ret = fltk::ask("Open Dynamics Engine cannot support COM of free joint different than location of joint.\nWould you like to change the COM to match the joint position?");
//			if (ret)
//				VecCopy(CMpos, jpos);
		}
	}

	// set the joint type to that selected
	if (jointSelection == 0) // weld
	{
		win->ao->getActiveJoint()->setJointType(J_WELD);
	}
	else if (jointSelection == 1) // pin
	{
		win->ao->getActiveJoint()->setJointType(J_PIN);
	}
	else if (jointSelection == 2) // universal
	{
		win->ao->getActiveJoint()->setJointType(J_UNIVERSAL);
	}
	else if (jointSelection == 3) // gimbal
	{
		win->ao->getActiveJoint()->setJointType(J_GIMBAL);
	}
	else if (jointSelection == 4) // ball
	{
		win->ao->getActiveJoint()->setJointType(J_BALL);
	}
	else if (jointSelection == 5) // free
	{
		win->ao->getActiveJoint()->setJointType(J_FREE);
	}


	// set end effector for created link
	Vector temppos;
	win->ao->getActiveJoint()->getPosition(temppos);
	VecSubtract(temppos, win->tempEF, temppos);
	VecScale(temppos, 0.5);

	// save current link
	win->isModified = false;
	win->ao->setEmpty(false);

	win->ao->getActiveJoint()->setName((char*)win->inputLinkJointName->value());
	win->ao->getActiveLink()->setName((char*)win->inputLinkJointName->value());
	win->editNameMode = false;

	win->show();

	win->setFieldValue(win->inputEFTranslate, win->zero);
	win->setFieldValue(win->wheelEFTranslate, win->zero);

	// hide current window
	((Window*)win)->hide();

	ArticulatedObjectWindow* aowin = (ArticulatedObjectWindow*) win->ao->getInterface();
	if (win->ao->getActiveJoint() != NULL)
		aowin->selectJoint(win->ao->getActiveJoint()->getJointNum());
	else
		aowin->selectJoint(0);

	// set articulated object mode
	win->ao->setInteractionMode(INTERACT_NONE);

	aowin->updateGUI();

	// reactivate parent window	
	aowin->activate();

	win->updateSimulators();


	dance::AllViews->postRedisplay();
}

// isValidName:
// checks if given string is a valid joint/link name
// no spaces allowed
bool EditWindow::isValidName(char* name)
{
	int size = strlen(name);

	// if empty string, invalid
	if (size == 0)
		return false;
	
	char* pos = strstr(name, " ");

	// if not found then valid
	if (pos == NULL)
		return true;
	else	// otherwise invalid
		return false;
}

// inputJointTranslate_input_cb:
// processes change in joint position, end effector offset, and center of mass input fields (not thumbwheel)
void EditWindow::inputTranslate_input_cb(Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	win->editJointMode = true;

	// widget input/output values
	double jpos[3];
	double EFpos[3];
	double CMpos[3];

	// save values in thumbwheel to compare changes in values
	Vector j;
	Vector e;
	Vector c;
	if (dynamic_cast<FloatInput*>(o)) // user changed input fields directly
	{
		setVector(j, win->wheelJointTranslate[0]->value(), win->wheelJointTranslate[1]->value(), win->wheelJointTranslate[2]->value());
		setVector(e, win->wheelEFTranslate[0]->value(), win->wheelEFTranslate[1]->value(), win->wheelEFTranslate[2]->value());
		setVector(c, win->wheelCOMTranslate[0]->value(), win->wheelCOMTranslate[1]->value(), win->wheelCOMTranslate[2]->value());
		win->getFieldValue(win->inputJointTranslate, jpos);
		win->getFieldValue(win->inputEFTranslate, EFpos);
		win->getFieldValue(win->inputCOMTranslate, CMpos);
		// update thumbwheel values, if input values have been changes
		// save state of input fields (changed/not changed)
		if (!VecEq(jpos, j))
		{
			win->deltaJpos = true;
			win->setFieldValue(win->wheelJointTranslate, jpos);
		}
		else
			win->deltaJpos = false;

		if (!VecEq(EFpos, e))
		{
			win->deltaEFpos = true;
			win->setFieldValue(win->wheelEFTranslate, EFpos);
		}
		else
			win->deltaEFpos = false;

		if (!VecEq(CMpos, c))
		{
			win->deltaCMpos = true;
			win->setFieldValue(win->wheelCOMTranslate, CMpos);
		}
		else
			win->deltaCMpos = false;
	}
	else // user changed thumb wheels
	{
		// set wheel to corresponding values
		setVector(jpos, win->wheelJointTranslate[0]->value(), win->wheelJointTranslate[1]->value(), win->wheelJointTranslate[2]->value());
		setVector(EFpos, win->wheelEFTranslate[0]->value(), win->wheelEFTranslate[1]->value(), win->wheelEFTranslate[2]->value());
		setVector(CMpos, win->wheelCOMTranslate[0]->value(), win->wheelCOMTranslate[1]->value(), win->wheelCOMTranslate[2]->value());
		win->getFieldValue(win->inputJointTranslate, j);
		win->getFieldValue(win->inputEFTranslate, e);
		win->getFieldValue(win->inputCOMTranslate, c);
		// update input values, if thumbwheel values have changed
		// save state of input fields (changed/not changed)
		if (!VecEq(jpos, j))
		{
			win->deltaJpos = true;
			win->setFieldValue(win->inputJointTranslate, jpos);
		}
		else
			win->deltaJpos = false;

		if (!VecEq(EFpos, e))
		{
			win->deltaEFpos = true;
			win->setFieldValue(win->inputEFTranslate, EFpos);
		}
		else
			win->deltaEFpos = false;

		if (!VecEq(CMpos, c))
		{
			win->deltaCMpos = true;
			win->setFieldValue(win->inputCOMTranslate, CMpos);
		}
		else
			win->deltaCMpos = false;
	}

	// determine the joint type
	int jointType = 0;
	int whichJoint = win->choiceJointType->value();
	if (whichJoint == 0)
		jointType = J_WELD;
	else if (whichJoint == 1)
		jointType = J_PIN;
	else if (whichJoint == 2)
		jointType = J_UNIVERSAL;
	else if (whichJoint == 3)
		jointType = J_GIMBAL;
	else if (whichJoint == 4)
		jointType = J_BALL;
	else if (whichJoint == 5)
		jointType = J_FREE;


	// get input field values

	// if edit global mode, update joint/link values
	// if 'default' checked, assume CoM in the middle of joint and end effector (unless FREE joint  => CoM at joint)
	if (win->checkbuttonCMdefault->value() && win->global)			// if CoM set to default and global mode
	{
		// if root (FREE joint), then default CoM at joint position
//		if (((win->ao->getNumJoints() == 0) || (win->ao->getActiveJoint() != NULL && win->ao->getActiveJoint()->getJointNum() == 0))
//			&& (jointType == J_FREE ))
		if (jointType == J_FREE)
		{
			VecCopy(CMpos, jpos);
		}
		else // otherwise set in the middle of EF and JPOS
		{
			VecAdd(CMpos, EFpos, jpos);
			VecScale(CMpos, 0.5);
		}

		win->deltaCMpos = true;

		//set global/local CoM
		if (win->global/* || win->ao->getActiveLink()->getParentLink() == NULL*/)	// if global mode, or root link
		{
			win->setFieldValue(win->inputCOMTranslate, CMpos);
			win->setFieldValue(win->wheelCOMTranslate, CMpos);
		}
		else	// local (should always be zero)
		{
			Vector local_COM;
			win->ao->getActiveLink()->getLocalCoord(local_COM, CMpos);

			win->setFieldValue(win->inputCOMTranslate, local_COM);
			win->setFieldValue(win->wheelCOMTranslate, local_COM);
		}
	}

	if (win->ao->getNumJoints() == 0 || (win->ao->getActiveJoint() != NULL && win->ao->getActiveJoint()->getJointNum() == 0)) // make sure this is the root joint
	{
		if (jointType == 5 && !VecEq(jpos, CMpos))
		{
//			int ret = fltk::ask("Open Dynamics Engine cannot support COM of free joint different than location of joint.\nWould you like to change the COM to match the joint position?");
//			if (ret)
//				VecCopy(CMpos, jpos);
		}
	}

	if (win->mode == EDIT_MODE)
	{
		// if change in any of the 3 input fields, apply change
		if (win->deltaJpos || win->deltaEFpos || win->deltaCMpos)
		{
			double matrix [4][4];

			// if local mode, change points to global
			if (!win->global)
			{
				win->ao->getActiveLink()->getWTransMat(matrix);
				// change to global
				transformPoint_mat(EFpos, matrix);
				transformPoint_mat(jpos, matrix);
				transformPoint_mat(CMpos, matrix);
			}

			if (win->checkbuttonCMdefault->value())		// if default center of mass
			{
				// if free joint, center of mass at joint
				if (jointType == J_FREE)
					VecCopy(CMpos, jpos);
				else
				{
				//else center of mass in the middle
					VecAdd(CMpos, jpos, EFpos);
					VecScale(CMpos, 0.5);
				}
			}

			// save new values to temp		?????? NECESSARY?????
			//VecCopy(win->tempJpos, jpos);
			//VecCopy(win->tempEF, EFpos);
			//VecCopy(win->tempCM, CMpos);

			if (win->checkbuttonEFLinkToChild->value())
			{
			//	win->checkbuttonEFLinkToChild_cb(o, p);
					if (win->checkbuttonCMdefault->value())	// if checked
						{ 
							// link with child was just selected
							Link* link = win->ao->getActiveLink();

							Vector parentEF;
							link->getEndEffector(parentEF);

							// change the inboard-to-joint vector for any child bodies
							int numChildren = link->getNumChildLinks();
							Link** childLinks = link->getChildLinks();
							for (int x = 0; x < numChildren; x++)
							{
								Joint* childJoint = childLinks[x]->getParentJoint();
								
								childJoint->setInbToJoint(parentEF);

								win->ao->updateStateConfig();
								win->updateGUI();
							}
						}
						// if unchecked, do nothing
			}
			win->deltaJointandEndEffectorPos(jpos, EFpos, CMpos, win->editSubtree/*win->radiobuttonSubtree->value()*/);
		}
	}
	else if (win->mode == NEW_MODE)
	{
		// change to global
		if (!win->global)		// if creating NEW link in LOCAL mode
		{
			double matrix [4][4];

			if (win->isModified == false)		// create default link at EF of parent link with length 1
			{
				Vector parentEF;
				win->ao->getActiveLink()->getEndEffector(parentEF);
				win->ao->getActiveLink()->getWTransMat(matrix);

				if (jointType == J_FREE)		// if free joint, put center of mass at joint
				{
					VecCopy(jpos, parentEF);
					VecCopy(CMpos, parentEF);
					parentEF[1] += 1.0;
					VecCopy(EFpos, parentEF);
				}
				else							// otherwise, put center of mass in the middle
				{
					VecCopy(jpos, parentEF);
					parentEF[1] += 0.5;
					VecCopy(CMpos, parentEF);
					parentEF[1] += 0.5;
					VecCopy(EFpos, parentEF);
				}

				// change to global
				transformPoint_mat(EFpos, matrix);
				transformPoint_mat(jpos, matrix);
				transformPoint_mat(CMpos, matrix);
	
			}
			else		// edit values in LOCAL mode
			{
				double matrix[4][4];

				Vector parentEF;
				win->ao->getActiveLink()->getEndEffector(parentEF);
				win->ao->getActiveLink()->getWTransMat(matrix);

				// change to global
				transformPoint_mat(EFpos, matrix);
				transformPoint_mat(jpos, matrix);
				transformPoint_mat(CMpos, matrix);

				win->ao->setEmpty(false);
				win->deleteLinkJoint(win->ao->getActiveLink(), win->ao->getActiveJoint());
			}
		}

		if (win->checkbuttonCMdefault->value())		// if default center of mass
		{
			// if free joint, center of mass at joint
			if (jointType == J_FREE)
				VecCopy(CMpos, jpos);
			else
			{
			//else center of mass in the middle
				VecAdd(CMpos, jpos, EFpos);
				VecScale(CMpos, 0.5);
			}
		}

		if (win->isModified == true && win->global)
		{
				win->ao->setEmpty(false);
				win->deleteLinkJoint(win->ao->getActiveLink(), win->ao->getActiveJoint());
		}

		// save new values to temp
		VecCopy(win->tempJpos, jpos);
		VecCopy(win->tempEF, EFpos);
		VecCopy(win->tempCM, CMpos);

		// if current link not saved, delete
/*		if (win->isModified == true)
		{
			win->ao->setEmpty(false);
			win->deleteLinkJoint(win->ao->getActiveLink(), win->ao->getActiveJoint());
		}
*/
		win->isModified = true;

		Vector temppos;
		Vector tempef;

		// add new link
		if (win->ao->getNumJoints() == 0)
		{
			win->ao->setEmpty(true);

			win->ao->setRootNewJointPos(win->tempJpos);

			win->ao->setNewCMPos(win->tempCM);
			win->ao->setCMvalidity(true);

			VecCopy(tempef, win->tempEF);
			win->ao->setNewEndEffPos(tempef);
		}
		else
		{
//			if (win->global)
			{
				win->ao->setEmpty(false);
//				win->ao->setNewJointPos(win->tempJpos);
				win->ao->setNewJointPos(jpos);

//				win->ao->setNewCMPos(win->tempCM);
				win->ao->setNewCMPos(CMpos);
				win->ao->setCMvalidity(true);

				VecCopy(temppos, win->tempEF);
//				win->ao->setNewEndEffPos(temppos);
				win->ao->setNewEndEffPos(EFpos);

//		transformPoint_mat(EFpos, matrix);
//		transformPoint_mat(jpos, matrix);
//		transformPoint_mat(CMpos, matrix);
			}
/*			else
			{
				Vector tempJ;
				Vector tempE;
				VecCopy(tempJ, win->tempJpos);
				VecScale(tempJ, -1);
				VecCopy(tempE, win->tempEF);
				// convert local point to global
				win->ao->setEmpty(false);

				// calculate and set global joint position
				win->ao->getActiveLink()->getEndEffectorWC(win->tempJpos);
				win->ao->setNewJointPos(win->tempJpos);

				// calculate and set global center of mass
//				VecAdd(win->tempCM, win->tempJpos, tempJ);
				win->ao->setNewCMPos(win->tempCM);
				win->ao->setCMvalidity(false);

				// calculate and set global end effector
//				VecAdd(win->tempEF, win->tempJpos, tempJ);
//				VecAdd(win->tempEF, win->tempEF, tempE);
				win->ao->setNewEndEffPos(win->tempEF);

			}
*/		}	

		Vector axis1, axis2, axis3;
		int jointDOF = win->choiceJointDOF->value();
		if (jointType == J_WELD)
		{
		}
		else if (jointType == J_PIN)
		{
			if (jointDOF == 0) // X
				setVector(axis1, 1.0, 0.0, 0.0);
			else if (jointDOF == 1) // Y
				setVector(axis1, 0.0, 1.0, 0.0);
			else if (jointDOF == 2) // Z
				setVector(axis1, 0.0, 0.0, 1.0);
		}
		else if (jointType == J_UNIVERSAL)
		{
			if (jointDOF == 0) // XY
			{
				setVector(axis1, 1.0, 0.0, 0.0);
				setVector(axis2, 0.0, 1.0, 0.0);
			}
			else if (jointDOF == 1) // XZ
			{
				setVector(axis1, 1.0, 0.0, 0.0);
				setVector(axis2, 0.0, 0.0, 1.0);
			}
			else if (jointDOF == 2) // YX
			{
				setVector(axis1, 0.0, 1.0, 0.0);
				setVector(axis2, 1.0, 0.0, 0.0);
			}
			else if (jointDOF == 2) // YZ
			{
				setVector(axis1, 0.0, 1.0, 0.0);
				setVector(axis2, 0.0, 0.0, 1.0);
			}
			else if (jointDOF == 2) // ZX
			{
				setVector(axis1, 0.0, 0.0, 1.0);
				setVector(axis2, 1.0, 0.0, 0.0);
			}
			else if (jointDOF == 2) // ZY
			{
				setVector(axis1, 0.0, 0.0, 1.0);
				setVector(axis2, 0.0, 1.0, 0.0);
			}
		}
		else if (jointType == J_GIMBAL || jointType == J_BALL || jointType == J_FREE)
		{
			if (jointDOF == 0) // XYZ
			{
				setVector(axis1, 1.0, 0.0, 0.0);
				setVector(axis2, 0.0, 1.0, 0.0);
				setVector(axis3, 0.0, 0.0, 1.0);
			}
			else if (jointDOF == 1) // XZY
			{
				setVector(axis1, 1.0, 0.0, 0.0);
				setVector(axis2, 0.0, 0.0, 1.0);
				setVector(axis3, 0.0, 1.0, 0.0);
			}
			else if (jointDOF == 2) // YXZ
			{
				setVector(axis1, 0.0, 1.0, 0.0);
				setVector(axis2, 1.0, 0.0, 0.0);
				setVector(axis3, 0.0, 0.0, 1.0);
			}
			else if (jointDOF == 2) // YZX
			{
				setVector(axis1, 0.0, 1.0, 0.0);
				setVector(axis2, 0.0, 0.0, 1.0);
				setVector(axis3, 1.0, 0.0, 0.0);
			}
			else if (jointDOF == 2) // ZXY
			{
				setVector(axis1, 0.0, 0.0, 1.0);
				setVector(axis2, 1.0, 0.0, 0.0);
				setVector(axis3, 0.0, 1.0, 0.0);
			}
			else if (jointDOF == 2) // ZYX
			{
				setVector(axis1, 0.0, 0.0, 1.0);
				setVector(axis2, 0.0, 1.0, 0.0);
				setVector(axis3, 1.0, 0.0, 0.0);
			}
		}


		Joint* j = win->ao->HandleJointAdd(-1, jointType, axis1, axis2, axis3);
		win->ao->setCMvalidity(false);
		//  set added link to active
		win->ao->setActiveJoint(j);
		win->ao->setActiveLink(j->getOutboardLink());
	}

	// reset "changed" variables
	win->deltaJpos = false;
	win->deltaEFpos = false;
	win->deltaCMpos = false;

//	win->ao->setState(curState);

	dance::AllViews->postRedisplay();
	win->show();
}

// wheelJointTranslate_ThumbWheel_cb:
// processes change in joint position, end effector offset, and center of mass thumbwheel fields (not input)
void EditWindow::wheelTranslate_ThumbWheel_cb(Widget* o, void* p)
{
	EditWindow::inputTranslate_input_cb(o, p);
}

// redraws edited link and its children
// vector parameters are always in global mode
void EditWindow::deltaJointandEndEffectorPos(Vector jpos, Vector EFpos, Vector CMpos, bool moveChildren)
{
	// added by AS 9/7/05
	Link* link = this->ao->getActiveLink();
	Joint* joint = this->ao->getActiveJoint();

	// CHANGE CENTER OF MASS
	// determine the new transformation matrix
	double parentMatrix[4][4];
	if (link->getParentLink() != NULL)
		link->getParentLink()->getTransMat(parentMatrix);
	else
		setIdentMat(&parentMatrix[0][0], 4);
	// zero out translation
	parentMatrix[3][0] = 0;
	parentMatrix[3][1] = 0;
	parentMatrix[3][2] = 0;

	// include the rotations of the current joint
	Quaternion* q = joint->getQuaternion();
	Matrix3x3 localMatrix;
	q->toMatrix(localMatrix);
	double finalMatrix[4][4];
	multArray(&finalMatrix[0][0], &parentMatrix[0][0], localMatrix.getGlMatrix(), 4, 4, 4);

	// use rotation of parent matrix, add global position
	finalMatrix[3][0] = CMpos[0];
	finalMatrix[3][1] = CMpos[1];
	finalMatrix[3][2] = CMpos[2];
	// set transformation matrix
	link->setTransMat(finalMatrix);
	

	// CHANGE JOINT POSITION
	Vector localJointPos;
	VecCopy(localJointPos, jpos);

	link->getLocalCoord(localJointPos, jpos);

	// set the body to joint
//	joint->setBodyToJoint(localJointPos);
	joint->setPosition(jpos);
	// if there is a parent link, adjust the inboard-to-joint
	Link* parentLink = link->getParentLink();
	if (parentLink != NULL)
	{
		Vector zero = {0.0, 0.0, 0.0};
		Vector parentBodyWorld;
		parentLink->getWorldCoord(parentBodyWorld, zero);
		Vector parentBodyLocal;
		link->getLocalCoord(parentBodyLocal, parentBodyWorld);
		// calculate the inboard-to-joint
		Vector inbToJoint;
		VecSubtract(inbToJoint, localJointPos, parentBodyLocal);
		joint->setInbToJoint(inbToJoint);
	}

	// CHANGE END EFFECTOR
	// convert end effector to local coordinates
	Vector localEndEff;
	link->getLocalCoord(localEndEff, EFpos);
	// set the end effector on the link
	link->setEndEffector(localEndEff);

	if (!moveChildren)
	{
		// change the inboard-to-joint vector for any child bodies
		int numChildren = link->getNumChildLinks();
		Link** childLinks = link->getChildLinks();
		for (int x = 0; x < numChildren; x++)
		{
			Joint* childJoint = childLinks[x]->getParentJoint();
			// get the joint position of the child in child coordinates
			Vector childBodyToJoint;
			childJoint->getBodyToJoint(childBodyToJoint);
			// get the position of the COM of the current link in child coordinates
			Vector parentCOMLocal;
			childLinks[x]->getLocalCoord(parentCOMLocal, CMpos);
			// calculate the new inboard to joint value
			Vector childInboardToJoint;
			VecSubtract(childInboardToJoint, childBodyToJoint, parentCOMLocal);
			childJoint->setInbToJoint(childInboardToJoint);
		}
	}

	this->ao->updateStateConfig();
}

void EditWindow::setFieldValue(fltk::FloatInput** input, Vector v)
{
	for (int i = 0; i < 3; i++)
	{
		input[i]->value(v[i]);		
	}
}

void EditWindow::getFieldValue(fltk::FloatInput** input, Vector v)
{
	for (int i = 0; i < 3; i++)
	{
		v[i] = input[i]->fvalue();
	}
}

void EditWindow::setFieldValue(fltk::ThumbWheel** input, Vector v)
{
	for (int i = 0; i < 3; i++)
	{
		input[i]->value(v[i]);		
	}
}

void EditWindow::getFieldValue(fltk::ThumbWheel** input, Vector v)
{
	for (int i = 0; i < 3; i++)
	{
		v[i] = input[i]->value();
	}
}

void EditWindow::FieldDeactivate(fltk::FloatInput** input)
{
	for (int i = 0; i < 3; i++)
		input[i]->deactivate();
}

void EditWindow::FieldActivate(fltk::FloatInput** input)
{
	for (int i = 0; i < 3; i++)
		input[i]->activate();
}

void EditWindow::FieldDeactivate(fltk::ThumbWheel** input)
{
	for (int i = 0; i < 3; i++)
		input[i]->deactivate();
}

void EditWindow::FieldActivate(fltk::ThumbWheel** input)
{
	for (int i = 0; i < 3; i++)
		input[i]->activate();
}

// decides if current is in the subtree of activeL
bool EditWindow::isDescendantLink(Link* activeL, Link* current)
{
	if (current == activeL)
		return true;

	Link* tempParent;
	tempParent = current->getParentLink();
	
	// until reach parent of tree root or activeL
	while(!(tempParent == NULL || tempParent == activeL))
	{
		tempParent = tempParent->getParentLink();
	}
    
	if (tempParent == NULL)
		return false;
	else
		return true;
}

void EditWindow::comDefault_cb(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	if (win->checkbuttonCMdefault->value())
	{ // default was just selected, recalculate COM
		win->inputTranslate_input_cb(o, p);
	}
	else
	{
		win->updateGUI();
	}
}

void EditWindow::checkbuttonEFLinkToChild_cb(fltk::Widget* o, void* p)
{
	EditWindow* win = (EditWindow*) p;

	// window has been modified, activates the Change button
	win->isModified = true;

	win->inputTranslate_input_cb(o, p);

/*	if (win->checkbuttonCMdefault->value())	// if checked
	{ 
		// link with child was just selected
		Link* link = win->ao->getActiveLink();

		Vector parentEF;
		link->getEndEffector(parentEF);

		// change the inboard-to-joint vector for any child bodies
		int numChildren = link->getNumChildLinks();
		Link** childLinks = link->getChildLinks();
		for (int x = 0; x < numChildren; x++)
		{
			Joint* childJoint = childLinks[x]->getParentJoint();
			
			childJoint->setInbToJoint(parentEF);

			win->ao->updateStateConfig();
			win->updateGUI();
		}
	}
	// if unchecked, do nothing
*/
}

void EditWindow::updateSimulators()
{
	// update the simulators if necessary
	double origState[MAX_STATE];
	this->ao->getState(origState);

	this->ao->setZeroState();

	// remove any recorded motion
	this->ao->getAnimationSequence()->clear();

	int numSimulators = this->ao->getNumSimulators();
	for (int x = 0; x < numSimulators; x++)
	{
		DSimulator* sim = (DSimulator*) this->ao->getSimulator(x);
		sim->removeSystem(this->ao);
		sim->addSystem(this->ao);
	}

	this->ao->setState(origState);
}

void EditWindow::deleteLinkJoint(Link* link, Joint* joint)
{
	if (link == NULL)
		return;

	Link* parentLink = link->getParentLink();

	Joint* parentJoint = NULL;
	if (parentLink != NULL)
		parentJoint = parentLink->getParentJoint();

	int ret = this->ao->deleteLinkAndJoint(ao->getActiveLink(), ao->getActiveJoint());
	if (ret == 1)
	{
		fltk::alert("Parent link %s has children and cannot be deleted.\nPlease delete child links first.", ao->getActiveLink()->getName());
	}

	this->ao->setActiveLink(parentLink);
	this->ao->setActiveJoint(parentJoint);

	this->updateSimulators();
}


Topology::Topology(ArticulatedObject* ao)
{
	int size = ao->getNumLinks();

	double origState[MAX_STATE];
	ao->getState(origState);

	ao->setZeroState();

	globalCOM = new double[3 * size];
	globalEndEff = new double[3 * size];
	globalJoint = new double[3 * size];
	jointTypes = new int[size];
	dof = new int[size];

	for (int x = 0; x < size; x++)
	{
		Link* link = ao->getLink(x);
		double matrix[4][4];
		link->getWTransMat(matrix);

		// COM
		Vector zero = {0.0, 0.0, 0.0};
		transformPoint_mat(zero, matrix);
		VecCopy(&globalCOM[3 * x], zero);

		// end effector
		Vector endEff;
		link->getEndEffector(endEff);
		transformPoint_mat(endEff, matrix);
		VecCopy(&globalEndEff[3 * x], endEff);

		// joint
		Vector bodyToJoint;
		link->getParentJoint()->getBodyToJoint(bodyToJoint);
		transformPoint_mat(bodyToJoint, matrix);
		VecCopy(&globalJoint[3 * x], bodyToJoint);

		// joint type
		Joint* joint = link->getParentJoint();
		this->setJointType(x, joint->getJointType());

		// dof
		int order = joint->determineRotationOrder();
		this->setDOF(x, order);
	}

	ao->setState(origState);
}

Topology::~Topology()
{
	delete [] globalCOM;
	delete [] globalEndEff;
	delete [] globalJoint;
	delete [] jointTypes;
	delete [] dof;
}

double* Topology::getCOM(int num)
{
	return &globalCOM[num * 3];
}

double* Topology::getEndEff(int num)
{
	return &globalEndEff[num * 3];
}

double* Topology::getJoint(int num)
{
	return &globalJoint[num * 3];
}

void Topology::setCOM(int num, double* val)
{
	VecCopy(&globalCOM[num * 3], val);
}

void Topology::setEndEff(int num, double* val)
{
	VecCopy(&globalEndEff[num * 3], val);
}

void Topology::setJoint(int num, double* val)
{
	VecCopy(&globalJoint[num * 3], val);
}

void Topology::setJointType(int num, int type)
{
	jointTypes[num] = type;
}

int Topology::getJointType(int num)
{
	return jointTypes[num];
}

void Topology::setDOF(int num, int d)
{
	dof[num] = d;
}

int Topology::getDOF(int num)
{
	return dof[num];
}




