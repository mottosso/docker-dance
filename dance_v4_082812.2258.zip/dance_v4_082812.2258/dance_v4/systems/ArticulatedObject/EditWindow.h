/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

/**********************************************************
	(EditWindow) Authored by:
		Julia Uskolovsky (jusko@ucla.edu)
**********************************************************/

#ifndef _ARTOBJEDITWINDOW_H
#define _ARTOBJEDITWINDOW_H

#include <fltk/Window.h>

#include <fltk/Button.h>
#include <fltk/FileChooser.h>
#include <fltk/CheckButton.h>
#include <fltk/RadioButton.h>
#include <fltk/ValueInput.h>
#include <fltk/ThumbWheel.h>
#include <fltk/Output.h>
#include <fltk/ValueSlider.h>
#include <string>

#include "ArticulatedObject.h"

#define NEW_MODE 0
#define EDIT_MODE 1

class Topology
{
	public:
		Topology(ArticulatedObject* artObj);
		~Topology();

		double* getCOM(int num);
		double* getEndEff(int num);
		double* getJoint(int num);
		int getJointType(int num);
		int getDOF(int num);

		void setCOM(int num, double* val);
		void setEndEff(int num, double* val);
		void setJoint(int num, double* val);
		void setJointType(int num, int type);
		void setDOF(int num, int type);

	private:
		double* globalCOM;
		double* globalEndEff;
		double* globalJoint;
		int* jointTypes;
		int* dof;
};

class EditWindow : public fltk::Window
{
	public:
		EditWindow(ArticulatedObject* artObj, int x, int y, int w, int h, const char* name, int winMode);
		~EditWindow();

		void updateGUI();

		void show();

		ArticulatedObject* ao;

		fltk::Input* inputLinkJointName;
		
		fltk::RadioButton* radiobuttonGlobal;
		fltk::RadioButton* radiobuttonLocal;

		fltk::RadioButton* radiobuttonActiveLink;
		fltk::RadioButton* radiobuttonSubtree;

		fltk::Choice* choiceJointType;
		fltk::Choice* choiceJointDOF;

		fltk::Button* buttonCreate;
		fltk::Button* buttonChange;
		fltk::Button* buttonDelete;

		fltk::Button* buttonCancelandReset;
		fltk::CheckButton* checkbuttonCMdefault;
		fltk::CheckButton* checkbuttonEFLinkToChild;

		fltk::FloatInput* inputJointTranslate[3];
		fltk::ThumbWheel* wheelJointTranslate[3];

		fltk::FloatInput* inputEFTranslate[3];
		fltk::ThumbWheel* wheelEFTranslate[3];

		fltk::FloatInput* inputCOMTranslate[3];
		fltk::ThumbWheel* wheelCOMTranslate[3];

		void setNewMode();
		void setEditMode();

		void deltaJointandEndEffectorPos(Vector jpos, Vector EFpos, Vector CMpos, bool moveChildren);

		void deleteLinkJoint(Link* link, Joint* joint);
//		void updateLinkandParent(fltk::Widget* widget, void* p, Link* activeL, Joint* activeJ, Vector temp1, Vector temp2a, Vector temp2b, Vector temp3, int linknumEdited);

		static void close_window(fltk::Widget* o, void* p);
		void updateSimulators();

		Vector zero;

		bool editJointMode;		// indicated that current joint/link positions have been edited (not saved)
		bool editJointTypeMode;	// indicated if joint type has been changed (not saved)
		bool editJointDOFMode;	// indicated if joint dof has been changed (not saved)
		bool editNameMode;		// indicates if name has been changed (not saved)
		bool firstTime;	// indicates when the original joint/link position should be stored
		bool global;		// global/local mode of end effector offset
		bool editSubtree;	// indicates if translation of joint/link should apply to its subtree
		int editJointTypeSelection;
		int editJointDOFSelection;

		//temporary holders, used during position editing
		Vector tempJpos;
		Vector tempEF;
		Vector tempCM;

		//temporary joint/link value holders
		std::string tempName;
		int tempJointType;
		//indicates if the temp joint, end effector, and CoM are valid
		bool isModified;

		//keeps track of whether the given positions have been changed
		bool deltaJpos;
		bool deltaEFpos;
		bool deltaCMpos;

		Topology* oldTopology;

		//Window mode: EDIT or NEW
		int mode;

		int getJointSelected();
		bool isValidName(char* name);
		bool isDescendantLink(Link* activeL, Link* current);
		void setFieldValue(fltk::FloatInput** input, Vector v);
		void getFieldValue(fltk::FloatInput** input, Vector v);

		void setFieldValue(fltk::ThumbWheel** input, Vector v);
		void getFieldValue(fltk::ThumbWheel** input, Vector v);

		void FieldDeactivate(fltk::FloatInput** input);
		void FieldActivate(fltk::FloatInput** input);

		void FieldDeactivate(fltk::ThumbWheel** input);
		void FieldActivate(fltk::ThumbWheel** input);

		static void window_callback(fltk::Widget* widget, void* p);

		void reset(fltk::Widget* o, void* p);

		static void inputLinkJointName_cb(fltk::Widget* o, void* p);
		static void comDefault_cb(fltk::Widget* o, void* p);
		static void checkbuttonEFLinkToChild_cb(fltk::Widget* o, void* p);

		static void radiobuttonGlobal_cb(fltk::Widget* o, void* p);
		static void radiobuttonLocal_cb(fltk::Widget* o, void* p);
		
		static void radiobuttonActiveLink_cb(fltk::Widget* o, void* p);
		static void radiobuttonSubtree_cb(fltk::Widget* o, void* p);

		static void JointTypeChoice_cb(fltk::Widget* o, void* p);
		static void JointDOFChoice_cb(fltk::Widget* o, void* p);

		static void buttonChange_cb(fltk::Widget* o, void* p);
		static void buttonCreate_cb(fltk::Widget* o, void* p);
		static void buttonDelete_cb(fltk::Widget* o, void* p);
		static void buttonCancelandReset_cb(fltk::Widget* o, void* p);

		static void inputTranslate_input_cb(fltk::Widget* o, void* p);
		static void wheelTranslate_ThumbWheel_cb(fltk::Widget* o, void* p);
};


#endif

