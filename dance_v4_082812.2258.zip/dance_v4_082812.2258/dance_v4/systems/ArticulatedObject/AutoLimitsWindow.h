/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _AUTOMATICLIMITSWINDOW_
#define _AUTOMATICLIMITSWINDOW_

#include <fltk/Window.h>
#include <fltk/Browser.h>
#include <fltk/Button.h>
#include <fltk/Output.h>
#include "ArticulatedObject.h"

class JointLimits
{
	public:
		JointLimits();

		std::string jointName;
		Vector min;
		Vector max;
};

class AutomaticLimitsWindow : public fltk::Window
{
	public:
		AutomaticLimitsWindow(ArticulatedObject* ao, int x, int y, int w, int h, const char* name);

		void updateGUI();
	
		static void OkButton(fltk::Widget *o, void *p);
		static void CancelButton(fltk::Widget *o, void *p);
		static void AddFile(fltk::Widget *o, void *p);
		static void RemoveFile(fltk::Widget *o, void *p);

		fltk::Button* buttonOk;
		fltk::Button* buttonCancel;
		fltk::Button* buttonAddFile;
		fltk::Button* buttonRemoveFile;
		fltk::Browser* browserFiles;

		std::vector<std::string> filenames;

		ArticulatedObject* artObj;
		std::vector<JointLimits*> limits;



	private:
};

#endif
