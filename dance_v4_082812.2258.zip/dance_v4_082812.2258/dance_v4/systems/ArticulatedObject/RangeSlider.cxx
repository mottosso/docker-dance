/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
// RangeSlider.cxx
// author: Jonathan Garcia (jonathan.f.garcia@ucla.edu)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Library General Public
// License as published by the Free Software Foundation; either
// version 2 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Library General Public License for more details.
//
// You should have received a copy of the GNU Library General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
// USA.

#include "RangeSlider.h"
#include <fltk/Box.h>
#include <fltk/draw.h>
#include <fltk/events.h>
#include <stdio.h>
#include <stdlib.h>

using namespace fltk;

RangeSlider::RangeSlider(int X, int Y, int W, int H, const char *l)
: Group(X, Y, W, H, l)
{
	slider = NULL;

	int w = W/5;
	if (w > 60) w = 60;
	if (w < 35) w = 35;

	this->begin();
	input1 = new FloatInput(0,0,w,H, "Start Time:");
	input1->align(ALIGN_LEFT | ALIGN_TOP);
	input1->tooltip("Start Time: Set the start time of the animation.");
	input1->value(0.0000);
	input1->callback(input1_cb, this);

	input2 = new FloatInput(w,0,w,H, "Range Start:");
	input2->align(ALIGN_LEFT | ALIGN_TOP);
	input2->tooltip("Range Start Time: Set the start time of the range slider.");
	input2->value(0.0000);
	input2->callback(input2_cb, this);

	sliderGroup = new Group(w+w,0,W-w*4,H);

	input3 = new FloatInput(W-w-w,0,w,H, "Range End:");
	input3->align(ALIGN_LEFT | ALIGN_TOP);
	input3->tooltip("Range End Time: Set the end time of the range slider.");
	input3->value(1.0000);
	input3->callback(input3_cb, this);

	input4 = new FloatInput(W-w,0,w,H, "End Time:");
	input4->align(ALIGN_LEFT | ALIGN_TOP);
	input4->tooltip("End Time: Set the end time of the animation.");
	input4->value(1.0000);
	input4->callback(input4_cb, this);
	this->end();
	this->box(THIN_DOWN_BOX);

	_push_left = false;
	_push_right = false;
	_slider_pos = 0;
	_slider_size = slider_position(1.0) - slider_position(0.0);
	redraw();
}

/*!
  Format the passed value to show enough digits for the current
  step value. If the step has been set to zero then it does a %g
  format. If step is an integer it does %d format. Otherwise it does a
  %.nf format where n is enough digits to show the step, maximum of
  8. The characters are written into the passed buffer (which must be
  long enough, 40 characters is safe).
 */
int RangeSlider::format(char* buffer, double v)
{
	return sprintf(buffer, "%.4f", v);
}

void RangeSlider::slider_rect(Rectangle &r)
{
	r.set(sliderGroup->x(), sliderGroup->y(), sliderGroup->w(), sliderGroup->h());
	box()->inset(r);
}

void RangeSlider::slider_button_rect(Rectangle &r, bool whole)
{
	slider_rect(r);
	if (whole)	// return the entire area
	{
		r.move_x(_slider_pos);
		r.w(_slider_size);
	}
	else		// return only the area between the left & right button
	{
		r.move_x(_slider_pos + r.h());
		r.w(_slider_size - 2*r.h());
	}
}

void RangeSlider::left_button_rect(Rectangle &r)
{
	Rectangle s; slider_button_rect(s, false);
	slider_rect(r);
	r.move_x(_slider_pos + 3);
	r.move_y(3);
	r.w(s.h()-6);
	r.h(s.h()-6);
}

void RangeSlider::right_button_rect(Rectangle &r)
{
	Rectangle s; slider_button_rect(s, false);
	slider_rect(r);
    r.move_x(_slider_pos + _slider_size - s.h() + 3);
	r.move_y(3);
	r.w(s.h()-6);
	r.h(s.h()-6);
}

int RangeSlider::slider_position(double val)
{
	Rectangle s; slider_rect(s);
	double step = (input4->fvalue() - input1->fvalue()) / s.w();
	return (int)((val-input1->fvalue())/step);
}

double RangeSlider::slider_value(int pos)
{
	Rectangle s; slider_rect(s);
	double step = (input4->fvalue() - input1->fvalue()) / s.w();
	return input1->fvalue() + pos*step;
}

void RangeSlider::draw()
{
	Group::draw();
	
	drawstyle(style(), flags()|OUTPUT);
	Rectangle s; slider_button_rect(s, true);
	draw_glyph(0, s);

	Flags f1, f2;
	f1 = f2 = flags() | OUTPUT;
#ifdef WIN32
	if (_push_left) f1 |= STATE;
	if (_push_right) f2 |= STATE;
#else
	if (_push_left) f1 |= STATE;
	if (_push_right) f2 |= STATE;
#endif

	Rectangle l; left_button_rect(l);
	drawstyle(style(), f1);
	draw_glyph(0,l);

	Rectangle r; right_button_rect(r);
	drawstyle(style(), f2);
	draw_glyph(0,r);
}

int RangeSlider::handle(int event)
{
	const static int DRAG_NONE = 0;
	const static int DRAG_SCROLL = 1;
	const static int DRAG_LEFT_BUTTON = 2;
	const static int DRAG_RIGHT_BUTTON = 3;

	int ret = 0;
	static int oldx;
	static int dragging = DRAG_NONE;
	
	Rectangle r; slider_rect(r);
	Rectangle s; slider_button_rect(s, false);
	Rectangle lb; left_button_rect(lb);
	Rectangle rb; right_button_rect(rb);

	switch(event)
	{
		case PUSH:
		case RELEASE:
		case DRAG:
			if (event == PUSH)
			{
				oldx =  event_x();
				
				if (event_inside(s))
				{
					dragging = DRAG_SCROLL;
					ret = 1;
					break;
				}
				else if (event_inside(rb))
				{
					dragging = DRAG_RIGHT_BUTTON;
					_push_right = true;
					ret = 1;
					break;
				}
				else if (event_inside(lb))
				{
					dragging = DRAG_LEFT_BUTTON;
					_push_left = true;
					ret = 1;
					break;
				}
			}

			if (event == RELEASE)
			{
				_push_left = false;
				_push_right = false;
				dragging = DRAG_NONE;
				ret = 1;
				break;
			}
			
			if (dragging)
			{
				int oldsize = _slider_size;
				int oldpos = _slider_pos;
				int diff = event_x() - oldx;
				oldx = event_x();

				if (dragging == DRAG_SCROLL)
				{
					_slider_pos += diff;
					if (_slider_pos < 0)
						_slider_pos = 0;
					else if (_slider_pos > r.w() - _slider_size)
						_slider_pos = r.w() - _slider_size;
				}
				else if (dragging == DRAG_LEFT_BUTTON)
				{
					_slider_pos += diff;
					_slider_size -= diff;
					if (_slider_pos < 0)
					{
						_slider_pos = oldpos;
						_slider_size = oldsize;
					}
					else if (_slider_pos > rb.x() - r.x() - lb.w() - 12)
					{
						_slider_pos = oldpos;
						_slider_size = oldsize;
					}
					if (_slider_pos > r.w() - _slider_size)
					{
						_slider_pos = oldpos;
						_slider_size = oldsize;
					}
				}
				else if (dragging == DRAG_RIGHT_BUTTON)
				{
					_slider_size += diff;
					if (_slider_pos + _slider_size - rb.w() < _slider_pos + lb.w() + 18)
						_slider_size = oldsize;
					else if (_slider_pos > r.w() - _slider_size)
						_slider_size = oldsize;
				}

				char buf[128];
				format(buf, slider_value(_slider_pos));
				input2->value(atof(buf));

				format(buf, slider_value(_slider_pos+_slider_size));
				input3->value(atof(buf));

				if (slider != NULL)
				{
					slider->range(input2->fvalue(), input3->fvalue());
					slider->redraw();
				}

				ret = 1;
			}
		break;
	}

	redraw();
	if (!ret) return Group::handle(event);;
	return ret;
}

void RangeSlider::input1_cb(fltk::Widget*, void *v)
{
	RangeSlider *r = (RangeSlider*)v;
	char buf[128];
	double nv = r->input1->fvalue();
	if (nv < 0) nv = 0.0;
	
	r->format(buf, nv);
	r->input1->value(atof(buf));

	if (nv > r->input4->fvalue())
	{
		r->input2->value(atof(buf));
		r->format(buf, nv+1);
		r->input4->value(atof(buf));
		r->input3->value(atof(buf));
	}
	else if (nv > r->input3->fvalue())
	{
		r->input2->value(atof(buf));
		r->format(buf, nv+1);
		r->input3->value(atof(buf));
	}
	else if (nv > r->input2->fvalue())
	{
		r->input2->value(atof(buf));
	}
	
	// update slider position
	r->_slider_pos = r->slider_position(r->input2->fvalue());

	Rectangle lb; r->left_button_rect(lb);
	int ss = r->slider_position(r->input2->fvalue());
	int se = r->slider_position(r->input3->fvalue());
	r->_slider_size = se - ss;
	if (r->_slider_size < 2*lb.w()+18)
		r->_slider_size = 2*lb.w()+18;

	r->slider_rect(lb);
	if (r->_slider_size > lb.w())
	{
		r->_slider_size = lb.w();
		r->_slider_pos = 0;
	}

	if (r->_slider_pos > lb.w() - r->_slider_size)
		r->_slider_pos = lb.w() - r->_slider_size;

	r->redraw();

	if (r->slider != NULL)
	{
		r->slider->range(r->input2->fvalue(), r->input3->fvalue());
		r->slider->redraw();
	}
}

void RangeSlider::input2_cb(fltk::Widget*, void *v)
{
	RangeSlider *r = (RangeSlider*)v;
	char buf[128];
	double nv = r->input2->fvalue();
	if (nv < 0) nv = 0.0;

	r->format(buf, nv);
	r->input2->value(atof(buf));

	if (nv < r->input1->fvalue())
	{
		r->input1->value(atof(buf));
	}

	if (nv >r->input4->fvalue())
	{
		r->format(buf, nv+1);
		r->input4->value(atof(buf));
		r->input3->value(atof(buf));
	}
	else if (nv > r->input3->fvalue())
	{
		r->format(buf, nv+1);
		r->input4->value(atof(buf));
	}

	// update slider position
	r->_slider_pos = r->slider_position(nv);

	Rectangle lb; r->left_button_rect(lb);
	int ss = r->slider_position(r->input2->fvalue());
	int se = r->slider_position(r->input3->fvalue());
	r->_slider_size = se - ss;
	if (r->_slider_size < 2*lb.w()+18)
		r->_slider_size = 2*lb.w()+18;

	r->slider_rect(lb);
	if (r->_slider_size > lb.w())
	{
		r->_slider_size = lb.w();
		r->_slider_pos = 0;
	}

	if (r->_slider_pos > lb.w() - r->_slider_size)
		r->_slider_pos = lb.w() - r->_slider_size;

	r->redraw();

	if (r->slider != NULL)
	{
		r->slider->range(r->input2->fvalue(), r->input3->fvalue());
		r->slider->redraw();
	}
}

void RangeSlider::input3_cb(fltk::Widget*, void *v)
{
	RangeSlider *r = (RangeSlider*)v;
	char buf[128];
	double nv = r->input3->fvalue();
	if (nv < 0) nv = 0.0;

	r->format(buf, nv);
	r->input3->value(atof(buf));

	if (nv > r->input4->fvalue())
	{
		r->input4->value(atof(buf));
	}

	if (nv < r->input1->fvalue())
	{
		r->format(buf, nv-1);
		r->input1->value(atof(buf));
		r->input2->value(atof(buf));
	}
	else if (nv < r->input2->fvalue())
	{
		r->format(buf, nv-1);
		r->input2->value(atof(buf));
	}

	// update slider position
	r->_slider_pos = r->slider_position(r->input2->fvalue());

	Rectangle lb; r->left_button_rect(lb);
	int ss = r->slider_position(r->input2->fvalue());
	int se = r->slider_position(r->input3->fvalue());
	r->_slider_size = se - ss;
	if (r->_slider_size < 2*lb.w()+18)
		r->_slider_size = 2*lb.w()+18;

	r->slider_rect(lb);
	if (r->_slider_size > lb.w())
	{
		r->_slider_size = lb.w();
		r->_slider_pos = 0;
	}

	if (r->_slider_pos > lb.w() - r->_slider_size)
		r->_slider_pos = lb.w() - r->_slider_size;

	r->redraw();

	if (r->slider != NULL)
	{
		r->slider->range(r->input2->fvalue(), r->input3->fvalue());
		r->slider->redraw();
	}
}

void RangeSlider::input4_cb(fltk::Widget*, void *v)
{
	RangeSlider *r = (RangeSlider*)v;
	char buf[128];
	double nv = r->input4->fvalue();
	if (nv < 0) nv = 0.0;

	r->format(buf, nv);
	r->input4->value(atof(buf));

	if (nv < r->input1->fvalue())
	{
		r->input3->value(atof(buf));
		r->format(buf, nv-1);
		r->input1->value(atof(buf));
		r->input2->value(atof(buf));
	}
	else if (nv < r->input2->fvalue())
	{
		r->input3->value(atof(buf));
		r->format(buf, nv-1);
		r->input2->value(atof(buf));
	}
	else if (nv < r->input3->fvalue())
	{
		r->input3->value(atof(buf));
	}

	// update slider position
	r->_slider_pos = r->slider_position(r->input2->fvalue());

	Rectangle lb; r->left_button_rect(lb);
	int ss = r->slider_position(r->input2->fvalue());
	int se = r->slider_position(r->input3->fvalue());
	r->_slider_size = se - ss;
	if (r->_slider_size < 2*lb.w()+18)
		r->_slider_size = 2*lb.w()+18;

	r->slider_rect(lb);
	if (r->_slider_size > lb.w())
	{
		r->_slider_size = lb.w();
		r->_slider_pos = 0;
	}

	if (r->_slider_pos > lb.w() - r->_slider_size)
		r->_slider_pos = lb.w() - r->_slider_size;

	r->redraw();

	if (r->slider != NULL)
	{
		r->slider->range(r->input2->fvalue(), r->input3->fvalue());
		r->slider->redraw();
	}
}
