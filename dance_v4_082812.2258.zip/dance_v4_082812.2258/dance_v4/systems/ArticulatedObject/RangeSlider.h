/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
// RangeSlider.h
// author: Jonathan Garcia (jonathan.f.garcia@ucla.edu)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Library General Public
// License as published by the Free Software Foundation; either
// version 2 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Library General Public License for more details.
//
// You should have received a copy of the GNU Library General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
// USA.

#ifndef __RANGESLIDER_H__
#define __RANGESLIDER_H__

#include <fltk/Group.h>
#include <fltk/Scrollbar.h>
#include <fltk/FloatInput.h>
#include "TimeSlider.h"

class RangeSlider : public fltk::Group
{
	public:
		fltk::Group		 *sliderGroup;
		fltk::FloatInput *input1;
		fltk::FloatInput *input2;
		fltk::FloatInput *input3;
		fltk::FloatInput *input4;

		double minimum() { return input2->fvalue(); }
		double maximum() { return input3->fvalue(); }

		int handle(int event);
		void draw();

		fltk::Box* box() { return sliderGroup->box(); }
		void box(fltk::Box* box) { sliderGroup->box(box); }

		void time_slider(TimeSlider *t) { slider = t; }
		TimeSlider *time_slider() { return slider; }

		RangeSlider(int X, int Y, int W, int H, const char *l=0);

	private:
		TimeSlider *slider;

		bool _push_left;
		bool _push_right;
		int _slider_pos;	// position of left edge of slider
		int _slider_size;	// size (width) of the slider

		int format(char *buffer, double v);

		void slider_rect(fltk::Rectangle &rect);
		void slider_button_rect(fltk::Rectangle &rect, bool whole);
		void left_button_rect(fltk::Rectangle &rect);
		void right_button_rect(fltk::Rectangle &rect);
		int slider_position(double val);
		double slider_value(int pos);

		static void input1_cb(fltk::Widget*, void*);
		static void input2_cb(fltk::Widget*, void*);
		static void input3_cb(fltk::Widget*, void*);
		static void input4_cb(fltk::Widget*, void*);
};

#endif
