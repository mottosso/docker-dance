dance.instance("FieldActuator", "gravity")
dance.actuator("gravity", "apply", "all")
dance.showinterface("gravity")
