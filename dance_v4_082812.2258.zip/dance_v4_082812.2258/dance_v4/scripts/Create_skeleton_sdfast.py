# This procedure sets the joint limits

def setLimits(skelType, skelName) :
    if skelType == "skel18" :
        print("Now setting limits for " + skelName + "...")
        dance.system(skelName, "joint", "Trunk_comp", "dof", "0", "limits", "-45", "90")
        dance.system(skelName, "joint", "Trunk_comp", "dof", "1" , "limits", "-55", "55")
        dance.system(skelName, "joint", "Trunk_comp","dof", "2" , "limits", "-50", "50")

        dance.system(skelName, "joint", "Neck", "dof", "0" , "limits", "-50", "90")
        dance.system(skelName, "joint", "Neck", "dof", "1", "limits", "-50", "50")
        dance.system(skelName, "joint", "Neck", "dof", "2", "limits", "-80", "80")
            
        dance.system(skelName, "joint","Head_comp",  "dof", "0" , "limits", "-45", "45")

        dance.system(skelName, "joint", "Right_Shoulder",  "dof"," 0" , "limits", "-90", "90")
        dance.system(skelName, "joint", "Right_Shoulder",  "dof", "1" , "limits", "-80", "160")
        dance.system(skelName, "joint", "Left_Shoulder",  "dof"," 0", "limits", "-90", "90")
        dance.system(skelName, "joint", "Left_Shoulder",  "dof", "1" , "limits", "-160", "80")
                    
        dance.system(skelName, "joint", "Right_Forearm", "dof", "0" , "limits",  "-20", "120")
        dance.system(skelName, "joint", "Right_Forearm", "dof", "1" , "limits", "-40", "90")
        dance.system(skelName, "joint", "Left_Forearm", "dof", "0" , "limits", "-120", "20")
        dance.system(skelName, "joint", "Left_Forearm", "dof"," 1" , "limits", "-90", "40")

        dance.system(skelName, "joint", "Right_Hand",  "dof"," 0" , "limits", "-90", "90")
        dance.system(skelName, "joint", "Right_Hand",  "dof"," 1" , "limits", "-45", "45")
        dance.system(skelName, "joint", "Left_Hand",  "dof", "0" , "limits", "-90", "90")
        dance.system(skelName, "joint", "Left_Hand",  "dof", "1" , "limits", "-45", "45")

        dance.system(skelName, "joint", "Right_Thigh",  "dof", "0" , "limits", "-90", "90")
        dance.system(skelName, "joint", "Right_Thigh",  "dof", "1" , "limits", "-90", "20")
        dance.system(skelName, "joint", "Right_Thigh",  "dof", "2" , "limits", "-20", "20")

        dance.system(skelName, "joint", "Left_Thigh", "dof", "0" , "limits", "-90", "90")
        dance.system(skelName, "joint", "Left_Thigh", "dof", "1" , "limits", "-20", "90")
        dance.system(skelName, "joint", "Left_Thigh", "dof", "2" , "limits", "-20", "20")

        dance.system(skelName, "joint", "Right_Shin", "dof", "0" , "limits", "-20", "165")
        dance.system(skelName, "joint", "Left_Shin", "dof", "0" , "limits", "-20", "165")

        dance.system(skelName, "joint", "Right_Foot", "dof", "0" , "limits", "-45", "50")
        dance.system(skelName, "joint", "Right_Foot", "dof", "1" , "limits", "-2", "35")
        dance.system(skelName, "joint", "Left_Foot", "dof","0" , "limits", "-45", "50")
        dance.system(skelName, "joint", "Left_Foot", "dof", "1" , "limits", "-35", "2")
        dance.system(skelName, "joint", "Neck", "dof", "0" , "limits", "-50", "90")
    elif skelType == "robot" :
        dance.system(skelName, "joint", "Trunk_comp", "dof", "0", "limits", "-45", "90")

        dance.system(skelName, "joint", "Neck", "dof", "0" , "limits", "-50", "90")
            
        dance.system(skelName, "joint","Head_comp",  "dof", "0" , "limits", "-45", "45")

        dance.system(skelName, "joint", "Right_Shoulder",  "dof"," 0" , "limits", "-180", "90")
        dance.system(skelName, "joint", "Left_Shoulder",  "dof"," 0", "limits", "-180", "90")
                    
        dance.system(skelName, "joint", "Right_Forearm", "dof", "0" , "limits",  "-170", "120")
        dance.system(skelName, "joint", "Left_Forearm", "dof", "0" , "limits", "-170", "20")

        dance.system(skelName, "joint", "Right_Hand",  "dof"," 0" , "limits", "-90", "90")
        dance.system(skelName, "joint", "Left_Hand",  "dof", "0" , "limits", "-90", "90")

        dance.system(skelName, "joint", "Right_Thigh",  "dof", "0" , "limits", "-165", "45")

        dance.system(skelName, "joint", "Left_Thigh", "dof", "0" , "limits", "-165", "45")

        dance.system(skelName, "joint", "Right_Shin", "dof", "0" , "limits", "0", "165")
        dance.system(skelName, "joint", "Left_Shin", "dof", "0" , "limits", "0", "165")

        dance.system(skelName, "joint", "Right_Foot", "dof", "0" , "limits", "-45", "50")
        dance.system(skelName, "joint", "Left_Foot", "dof","0" , "limits", "-45", "50")
    else :
        print("Unknown skeleton type " + skelType)
        


def setUpSim(skelType, skelName) :
    print("Now adding the simulator for " + skelName + "...")
    dance.plugin("SdfastSimul")
    dance.instance("SdfastSimul", skelName + "sim")
    dance.simulator(skelName + "sim", "load", "skel18")
    dance.simulator(skelName + "sim", "system", skelName)


    dance.simulator(skelName + "sim", "timestep", 0.0001)
    dance.simulator(skelName + "sim", "usetimestep", "false")
#    dance.instance("ODESim", skelName + "sim", skelName)


    # set joint stiffness
    print("Now setting joint stiffness for " + skelName + "...")
    numlinks = int(dance.system(skelName, "show", "number_of_links"))
    i = 1 
    while (i < numlinks) :
         dance.system(skelName, "joint", str(i), "set", "stiff_damp", "4500", "1000")
         i = i + 1

def setUpSkelnosim(skelType, skelName) :
    print("Now creating skeleton " + skelName + " of type " + skelType + "...")
    dance.plugin("Model")
    dance.instance("ArticulatedObject", skelName)
    dance.system(skelName, "load", "sdfast", dance.dancedir() + "/sdfastobjs/" + skelType + "/" + skelType + ".sd")

    linklist = dance.system(skelName, "show", "links")
    numlinks = int(dance.system(skelName, "show", "number_of_links"))

    print("Now retrieving geometry for " + skelName + "...")

    # instantiate all the geometry
    geomList = ""
    for i in range(0, len(linklist.split())) :
        linkName = linklist.split()[i]
        fileName = dance.dancedir() + "/data/models/" + skelType + "/" + linkName + "_center.wrl"
        if linkName == "Left_Foot" or linkName == "Right_Foot" or linkName == "Head_comp" or linkName == "Right_Hand" or linkName == "Left_Hand" or linkName == "Hip" :
            fileName = dance.dancedir() + "/data/models/" + skelType + "/" + linkName + "_center_fix.wrl"

        if os.path.isfile(fileName) : 
            print("loading " + fileName)
            dance.instance("Model", skelName + "_" + linkName, fileName)
            dance.geometry(skelName + "_" + linkName, "scale", "2.6", "2.6", "2.6")
            
            if i > 0 :
                geomList = geomList + " "
            geomList = geomList + skelName + "_" + linkName
        else :
            print("File " + fileName + " does not exist.")

    linkList = dance.system(skelName, "show", "links")

    numGeoms = len(linkList.split())
    for i in range(0, numGeoms) :
        linkName = linkList.split()[i]
        geomName = geomList.split()[i]

        dance.system(skelName, "link", linkName, "geometry", geomName, "local")
        print("Connect " + linkName + " to " + skelName + "_" + geomName)
        #dance.system(skelName, "link", linkName, "scale", "2.6")

    if skelType == "robot" :
        # for robot only - rotate the geometries of the arms 
        dance.system(skelName,  "link","Left_Shoulder",  "rotate",  "z",  "-90")
        dance.system(skelName,  "link","Left_Forearm", "rotate",  "z",  "-90")
        dance.system(skelName,  "link","Right_Shoulder",  "rotate",  "z", "90")
        dance.system(skelName,  "link","Right_Forearm", "rotate",  "z",  "90")
        dance.system(skelName,  "link","Right_Hand",  "rotate",  "z",  "90")
        dance.system(skelName,  "link","Left_Hand",  "rotate",  "z",  "-90")

    print("Now hand-assigning monitor points for $skelName...")
    dance.system(skelName, "link", "Left_Foot", "assign_monitor_points",  "0", "0", "-0.1","-0.02", "0", "-0.095", "0.0", "-0.02", "-0.09", "-0.028", "-0.02", "-0.08", "-0.01", "-0.025", "0.135", "0.06", "-0.025", "0.1")
    dance.system(skelName, "link", "Right_Foot", "assign_monitor_points",  "0", "0", "-0.1", "0.02", "0", "-0.095", "0.0", "-0.02", "-0.09", "0.028", "-0.02", "-0.08", "0.01", "-0.025", "0.135", "-0.06", "-0.025", "0.1")
#    dance.system(skelName, "link", "Left_Hand", "assign_monitor_points",   "0.09", "-0.03", "-0.05", "0.11", "-0.03", "0.04", "0.05", "-0.055", "0.06", "-0.05", "-0.01", "0.03", "-0.05", "-0.01", "-0.03")
#    dance.system(skelName, "link", "Right_Hand", "assign_monitor_points", "-0.09", "-0.03", "-0.05", "-0.11", "-0.03", "0.04", "-0.05", "-0.055", "0.06", "0.05", "-0.01", "0.03", "0.05", "-0.01", "-0.03")
    dance.system(skelName, "link", "Left_Hand", "assign_monitor_points",   "10")
    dance.system(skelName, "link", "Right_Hand", "assign_monitor_points", "10")
    dance.system(skelName, "link", "Hip", "assign_monitor_points",  "0.03", "-0.11", "-0.03", "-0.03", "-0.11", "-0.03", "-0.045", "-0.065", "-0.041", "0.045", "-0.065", "-0.041", "-0.032", "0.07", "-0.041", "0.032", "0.07", "-0.041", "0.1", "0.1", "0.025", "-0.1", "0.1", "0.025", "0.12", "0.09", "0.04", "-0.12", "0.09", "0.04", "0.135", "0.04", "0.075", "-0.135", "0.04", "0.075") 
    dance.system(skelName, "link", "Neck", "assign_monitor_points",  "10")
    dance.system(skelName, "link", "Head_comp", "assign_monitor_points",  "50")
    dance.system(skelName, "link", "Left_Shoulder", "assign_monitor_points",  "50")
    dance.system(skelName, "link", "Right_Shoulder", "assign_monitor_points",  "50")
    dance.system(skelName, "link", "Left_Forearm", "assign_monitor_points",  "50")
    dance.system(skelName, "link", "Right_Forearm", "assign_monitor_points",  "50")
    dance.system(skelName, "link", "Left_Thigh", "assign_monitor_points",  "50")
    dance.system(skelName, "link", "Right_Thigh", "assign_monitor_points",  "50")
    dance.system(skelName, "link", "Left_Shin", "assign_monitor_points",  "50")
    dance.system(skelName, "link", "Right_Shin", "assign_monitor_points",  "50")
    dance.system(skelName, "link","Trunk_comp","assign_monitor_points",  "0.125", "-0.08", "0.11", "-0.125", "-0.08", "0.11", "0.0", "0.1", "0.09", "0.13", "0.041", "0.050", "-0.13", "0.041", "0.05", "0.12", "0.06", "-0.095", "-0.12", "0.06", "-0.095", "0.0", "0.09", "-0.1", "0.07", "0.18", "-0.09", "-0.07", "0.18", "-0.09", "0.14", "0.13", "-0.07", "-0.14", "0.13", "-0.07")
    dance.system(skelName, "link","Trunk_comp","assign_monitor_points",  "150")

    # set the limits
    print("Now setting limits for " + skelName)
    setLimits(skelType, skelName)

    # ik chains
    dance.system(skelName, "create_ik", "left arm")
    dance.system(skelName, "ik", "left arm", "add_joint", "Left_Shoulder")
    dance.system(skelName, "ik", "left arm", "add_joint", "Left_Forearm")
    dance.system(skelName, "ik", "left arm", "add_joint", "Left_Hand")
    dance.system(skelName, "create_ik", "right arm")
    dance.system(skelName, "ik", "right arm", "add_joint", "Right_Shoulder")
    dance.system(skelName, "ik", "right arm", "add_joint", "Right_Forearm")
    dance.system(skelName, "ik", "right arm", "add_joint", "Right_Hand")
    dance.system(skelName, "create_ik", "left leg")
    dance.system(skelName, "ik", "left leg", "add_joint", "Left_Thigh")
    dance.system(skelName, "ik", "left leg", "add_joint", "Left_Shin")
    dance.system(skelName, "ik", "left leg", "add_joint", "Left_Foot")
    dance.system(skelName, "create_ik", "right leg")
    dance.system(skelName, "ik", "right leg", "add_joint", "Right_Thigh")
    dance.system(skelName, "ik", "right leg", "add_joint", "Right_Shin")
    dance.system(skelName, "ik", "right leg", "add_joint", "Right_Foot")
    dance.system(skelName, "create_ik", "left arm with body")
    dance.system(skelName, "ik", "left arm with body", "add_joint", "Trunk_comp")
    dance.system(skelName, "ik", "left arm with body", "add_joint", "Left_Shoulder")
    dance.system(skelName, "ik", "left arm with body", "add_joint", "Left_Forearm")
    dance.system(skelName, "ik", "left arm with body", "add_joint", "Left_Hand")
    dance.system(skelName, "create_ik", "right arm with body")
    dance.system(skelName, "ik", "right arm with body", "add_joint", "Trunk_comp")
    dance.system(skelName, "ik", "right arm with body", "add_joint", "Right_Shoulder")
    dance.system(skelName, "ik", "right arm with body", "add_joint", "Right_Forearm")
    dance.system(skelName, "ik", "right arm with body", "add_joint", "Right_Hand")
    dance.system(skelName, "create_ik", "head")
    dance.system(skelName, "ik", "head", "add_joint", "Neck")
    dance.system(skelName, "ik", "head", "add_joint", "Head_comp")
    dance.system(skelName, "create_ik", "head with body")
    dance.system(skelName, "ik", "head with body", "add_joint", "Trunk_comp")
    dance.system(skelName, "ik", "head with body" , "add_joint", "Neck")
    dance.system(skelName, "ik", "head with body", "add_joint", "Head_comp")

def setUpSkel(skelType, skelName) :
	setUpSkelnosim(skelType, skelName)
	setUpSim(skelType, skelName)

dance.plugin("Cube")
dance.plugin("Sphere")

# construct a unique name
offset = 0
allplugins = dance.show()
basename = "skeleton"
name = basename
if len(allplugins) > 0 :
	found = 1
	x = 0
	while found > 0 :
		allsystems = allplugins.split(' ')
		found = allsystems.count(name)
		if (found > 0) :
			name = basename + repr(x)
			offset = offset + 1
			x = x + 1

setUpSkel("skel18", name)
dance.showinterface(name + "sim")
dance.showinterface(name)
dance.system(name, "setstate", 0, offset)

# load the sphere collision information
dance.system(name, "load_spheres", dance.dancedir() + "/scripts/tutorials/tutorial2data/man.sphere")
