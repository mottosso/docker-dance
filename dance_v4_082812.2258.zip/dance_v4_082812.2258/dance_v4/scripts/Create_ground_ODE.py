dance.plugin("Plane")
dance.instance("Plane", "plane")
dance.geometry("plane", "scale", 20, 20, 20)
dance.instance("ODECollision", "odecollision")
dance.actuator("odecollision", "apply_geometry", "plane")
dance.actuator("odecollision", "apply", "all")
# set a high friction
dance.actuator("odecollision", "param", "mu", 999.0000)
dance.showinterface("plane")
dance.showinterface("odecollision")


