# This procedure sets the joint limits

def setLimits(skelType, skelName) :
	
	print("Now setting limits for " + skelName + "...")
	dance.system(skelName, "joint", "Trunk_comp", "dof", "0", "limits", "-45", "90")
	dance.system(skelName, "joint", "Trunk_comp", "dof", "1" , "limits", "-55", "55")
	dance.system(skelName, "joint", "Trunk_comp","dof", "2" , "limits", "-50", "50")

	dance.system(skelName, "joint", "Neck", "dof", "0" , "limits", "-50", "90")
	dance.system(skelName, "joint", "Neck", "dof", "1", "limits", "-50", "50")
	dance.system(skelName, "joint", "Neck", "dof", "2", "limits", "-80", "80")
			
	dance.system(skelName, "joint","Head_comp",  "dof", "0" , "limits", "-45", "45")
	dance.system(skelName, "joint", "Right_Shoulder",  "dof"," 0" , "limits", "-90", "90")
	dance.system(skelName, "joint", "Right_Shoulder",  "dof", "1" , "limits", "-80", "120")
	dance.system(skelName, "joint", "Right_Shoulder",  "dof", "2" , "limits", "-40", "130")
	dance.system(skelName, "joint", "Left_Shoulder",  "dof"," 0", "limits", "-90", "90")
	dance.system(skelName, "joint", "Left_Shoulder",  "dof", "1" , "limits", "-120", "80")
	dance.system(skelName, "joint", "Left_Shoulder",  "dof", "2" , "limits", "-130", "40")
	dance.system(skelName, "joint", "Right_Forearm", "dof", "0" , "limits",  "-20", "120")
	dance.system(skelName, "joint", "Right_Forearm", "dof", "1" , "limits", "-40", "90")
	dance.system(skelName, "joint", "Left_Forearm", "dof", "0" , "limits", "-120", "20")
	dance.system(skelName, "joint", "Left_Forearm", "dof"," 1" , "limits", "-90", "40")
	dance.system(skelName, "joint", "Right_Hand",  "dof"," 0" , "limits", "-45", "45")
	dance.system(skelName, "joint", "Right_Hand",  "dof"," 1" , "limits", "-90", "90")
	dance.system(skelName, "joint", "Left_Hand",  "dof", "0" , "limits", "-45", "45")
	dance.system(skelName, "joint", "Left_Hand",  "dof", "1" , "limits", "-90", "90")
	dance.system(skelName, "joint", "Right_Thigh",  "dof", "0" , "limits", "-90", "90")
	dance.system(skelName, "joint", "Right_Thigh",  "dof", "1" , "limits", "-80", "20")
	dance.system(skelName, "joint", "Right_Thigh",  "dof", "2" , "limits", "-20", "20")
	dance.system(skelName, "joint", "Left_Thigh", "dof", "0" , "limits", "-90", "90")
	dance.system(skelName, "joint", "Left_Thigh", "dof", "1" , "limits", "-20", "80")
	dance.system(skelName, "joint", "Left_Thigh", "dof", "2" , "limits", "-20", "20")
	dance.system(skelName, "joint", "Right_Shin", "dof", "0" , "limits", "-20", "165")
	dance.system(skelName, "joint", "Left_Shin", "dof", "0" , "limits", "-20", "165")
	dance.system(skelName, "joint", "Right_Foot", "dof", "0" , "limits", "-45", "50")
	dance.system(skelName, "joint", "Right_Foot", "dof", "1" , "limits", "-2", "35")
	dance.system(skelName, "joint", "Left_Foot", "dof","0" , "limits", "-45", "50")
	dance.system(skelName, "joint", "Left_Foot", "dof", "1" , "limits", "-35", "2")   


def setJointStiffness(skelType, skelName) :
	print("Now setting stiffness/damping for " + skelName + "...")		
	dance.system(skelName, "joint", "Hip", "dof", 0, "stiff_damp_no_inertia_scale", 50.000000, 50.000000)
	dance.system(skelName, "joint", "Hip", "dof", 1, "stiff_damp_no_inertia_scale", 50.000000, 50.000000)
	dance.system(skelName, "joint", "Hip", "dof", 2, "stiff_damp_no_inertia_scale", 50.000000, 50.000000)

	dance.system(skelName, "joint", "Trunk_comp", "dof", 0, "stiff_damp_no_inertia_scale", 3000, 600)
	dance.system(skelName, "joint", "Trunk_comp", "dof", 1, "stiff_damp_no_inertia_scale", 3000, 600)
	dance.system(skelName, "joint", "Trunk_comp", "dof", 2, "stiff_damp_no_inertia_scale", 3000, 600)

	dance.system(skelName, "joint", "Neck", "dof", 0, "stiff_damp_no_inertia_scale", 150, 30)
	dance.system(skelName, "joint", "Neck", "dof", 1, "stiff_damp_no_inertia_scale", 150, 30)
	dance.system(skelName, "joint", "Neck", "dof", 2, "stiff_damp_no_inertia_scale", 150, 30)

	dance.system(skelName, "joint", "Head_comp", "dof", 0, "stiff_damp_no_inertia_scale", 150, 30)

	dance.system(skelName, "joint", "Left_Shoulder", "dof", 0, "stiff_damp_no_inertia_scale", 150, 30)
	dance.system(skelName, "joint", "Left_Shoulder", "dof", 1, "stiff_damp_no_inertia_scale", 150, 30) 
	dance.system(skelName, "joint", "Left_Shoulder", "dof", 2, "stiff_damp_no_inertia_scale", 150, 30) 

	dance.system(skelName, "joint", "Left_Forearm", "dof", 0, "stiff_damp_no_inertia_scale", 150, 30)
	dance.system(skelName, "joint", "Left_Forearm", "dof", 1, "stiff_damp_no_inertia_scale", 150, 30)

	dance.system(skelName, "joint", "Left_Hand", "dof", 0, "stiff_damp_no_inertia_scale", 10, 2)
	dance.system(skelName, "joint", "Left_Hand", "dof", 1, "stiff_damp_no_inertia_scale", 10, 2)

	dance.system(skelName, "joint", "Right_Shoulder", "dof", 0, "stiff_damp_no_inertia_scale", 150, 30)
	dance.system(skelName, "joint", "Right_Shoulder", "dof", 1, "stiff_damp_no_inertia_scale", 150, 30)
	dance.system(skelName, "joint", "Right_Shoulder", "dof", 2, "stiff_damp_no_inertia_scale", 150, 30)

	dance.system(skelName, "joint", "Right_Forearm", "dof", 0, "stiff_damp_no_inertia_scale", 150, 30)
	dance.system(skelName, "joint", "Right_Forearm", "dof", 1, "stiff_damp_no_inertia_scale", 150, 30)

	dance.system(skelName, "joint", "Right_Hand", "dof", 0, "stiff_damp_no_inertia_scale", 10, 2)
	dance.system(skelName, "joint", "Right_Hand", "dof", 1, "stiff_damp_no_inertia_scale", 10, 2)

	dance.system(skelName, "joint", "Left_Thigh", "dof", 0, "stiff_damp_no_inertia_scale", 900, 200)
	dance.system(skelName, "joint", "Left_Thigh", "dof", 1, "stiff_damp_no_inertia_scale", 900, 200)
	dance.system(skelName, "joint", "Left_Thigh", "dof", 2, "stiff_damp_no_inertia_scale", 900, 200)

	dance.system(skelName, "joint", "Left_Shin", "dof", 0, "stiff_damp_no_inertia_scale", 400, 30)
 
	dance.system(skelName, "joint", "Left_Foot", "dof", 0, "stiff_damp_no_inertia_scale", 30, 3)
	dance.system(skelName, "joint", "Left_Foot", "dof", 1, "stiff_damp_no_inertia_scale", 30, 3)
	
	dance.system(skelName, "joint", "Right_Thigh", "dof", 0, "stiff_damp_no_inertia_scale", 900, 200)
	dance.system(skelName, "joint", "Right_Thigh", "dof", 1, "stiff_damp_no_inertia_scale", 900, 200)
	dance.system(skelName, "joint", "Right_Thigh", "dof", 2, "stiff_damp_no_inertia_scale", 900, 200)

	dance.system(skelName, "joint", "Right_Shin", "dof", 0, "stiff_damp_no_inertia_scale", 400, 30)
 
	dance.system(skelName, "joint", "Right_Foot", "dof", 0, "stiff_damp_no_inertia_scale", 30, 3)
	dance.system(skelName, "joint", "Right_Foot", "dof", 1, "stiff_damp_no_inertia_scale", 30, 3)


def setUpSim(skelType, skelName) :
	print("Now adding the simulator for " + skelName + "...")
	dance.plugin("SdfastSimul")
#	dance.instance("SdfastSimul", skelName + "sim")
#	dance.simulator(skelName + "sim", "load", "skel18")
#	dance.plugin("SdfastSimul")
	dance.instance("ODESim", skelName + "sim")
	dance.simulator(skelName + "sim", "system", skelName)


#	dance.simulator(skelName + "sim", "timestep", 0.0001)
#	dance.simulator(skelName + "sim", "usetimestep", "false")
#	dance.instance("ODESim", skelName + "sim", skelName)


def setUpSkelnosim(skelType, skelName) :
	print("Now creating skeleton " + skelName + " of type " + skelType + "...")
	dance.plugin("Model")
	dance.instance("ArticulatedObject", skelName)
	dance.system(skelName, "load", "sdfast", dance.dancedir() + "/sdfastobjs/" + skelType + "/" + skelType + ".sd")

	linklist = dance.system(skelName, "show", "links")
	numlinks = int(dance.system(skelName, "show", "number_of_links"))

	print("Now retrieving geometry for " + skelName + "...")

	# instantiate all the geometry
	geomList = ""
	for i in range(0, len(linklist.split())) :
		linkName = linklist.split()[i]
		fileName = dance.dancedir() + "/data/models/" + skelType + "/" + linkName + "_center.wrl"
		if linkName == "Left_Foot" or linkName == "Right_Foot" or linkName == "Head_comp" or linkName == "Right_Hand" or linkName == "Left_Hand" or linkName == "Hip" :
			fileName = dance.dancedir() + "/data/models/" + skelType + "/" + linkName + "_center_fix.wrl"

		if os.path.isfile(fileName) : 
			print("loading " + fileName)
			dance.instance("Model", skelName + "_" + linkName, fileName)
			dance.geometry(skelName + "_" + linkName, "scale", "2.6", "2.6", "2.6")
			
			if i > 0 :
				geomList = geomList + " "
			geomList = geomList + skelName + "_" + linkName
		else :
			print("File " + fileName + " does not exist.")

	linkList = dance.system(skelName, "show", "links")

	numGeoms = len(linkList.split())
	for i in range(0, numGeoms) :
		linkName = linkList.split()[i]
		geomName = geomList.split()[i]

		dance.system(skelName, "link", linkName, "geometry", geomName, "local")
		print("Connect " + linkName + " to " + skelName + "_" + geomName)
		#dance.system(skelName, "link", linkName, "scale", "2.6")

	if skelType == "robot" :
		# for robot only - rotate the geometries of the arms 
		dance.system(skelName,  "link","Left_Shoulder",  "rotate",  "z",  "-90")
		dance.system(skelName,  "link","Left_Forearm", "rotate",  "z",  "-90")
		dance.system(skelName,  "link","Right_Shoulder",  "rotate",  "z", "90")
		dance.system(skelName,  "link","Right_Forearm", "rotate",  "z",  "90")
		dance.system(skelName,  "link","Right_Hand",  "rotate",  "z",  "90")
		dance.system(skelName,  "link","Left_Hand",  "rotate",  "z",  "-90")

	print("Now hand-assigning monitor points for $skelName...")
	dance.system(skelName, "link", "Left_Foot", "assign_monitor_points",  "0", "0", "-0.1","-0.02", "0", "-0.095", "0.0", "-0.02", "-0.09", "-0.028", "-0.02", "-0.08", "-0.01", "-0.025", "0.135", "0.06", "-0.025", "0.1")
	dance.system(skelName, "link", "Right_Foot", "assign_monitor_points",  "0", "0", "-0.1", "0.02", "0", "-0.095", "0.0", "-0.02", "-0.09", "0.028", "-0.02", "-0.08", "0.01", "-0.025", "0.135", "-0.06", "-0.025", "0.1")
#	dance.system(skelName, "link", "Left_Hand", "assign_monitor_points",   "0.09", "-0.03", "-0.05", "0.11", "-0.03", "0.04", "0.05", "-0.055", "0.06", "-0.05", "-0.01", "0.03", "-0.05", "-0.01", "-0.03")
#	dance.system(skelName, "link", "Right_Hand", "assign_monitor_points", "-0.09", "-0.03", "-0.05", "-0.11", "-0.03", "0.04", "-0.05", "-0.055", "0.06", "0.05", "-0.01", "0.03", "0.05", "-0.01", "-0.03")
	dance.system(skelName, "link", "Left_Hand", "assign_monitor_points",   "10")
	dance.system(skelName, "link", "Right_Hand", "assign_monitor_points", "10")
	dance.system(skelName, "link", "Hip", "assign_monitor_points",  "0.03", "-0.11", "-0.03", "-0.03", "-0.11", "-0.03", "-0.045", "-0.065", "-0.041", "0.045", "-0.065", "-0.041", "-0.032", "0.07", "-0.041", "0.032", "0.07", "-0.041", "0.1", "0.1", "0.025", "-0.1", "0.1", "0.025", "0.12", "0.09", "0.04", "-0.12", "0.09", "0.04", "0.135", "0.04", "0.075", "-0.135", "0.04", "0.075") 
	dance.system(skelName, "link", "Neck", "assign_monitor_points",  "10")
	dance.system(skelName, "link", "Head_comp", "assign_monitor_points",  "50")
	dance.system(skelName, "link", "Left_Shoulder", "assign_monitor_points",  "50")
	dance.system(skelName, "link", "Right_Shoulder", "assign_monitor_points",  "50")
	dance.system(skelName, "link", "Left_Forearm", "assign_monitor_points",  "50")
	dance.system(skelName, "link", "Right_Forearm", "assign_monitor_points",  "50")
	dance.system(skelName, "link", "Left_Thigh", "assign_monitor_points",  "50")
	dance.system(skelName, "link", "Right_Thigh", "assign_monitor_points",  "50")
	dance.system(skelName, "link", "Left_Shin", "assign_monitor_points",  "50")
	dance.system(skelName, "link", "Right_Shin", "assign_monitor_points",  "50")
	dance.system(skelName, "link","Trunk_comp","assign_monitor_points",  "0.125", "-0.08", "0.11", "-0.125", "-0.08", "0.11", "0.0", "0.1", "0.09", "0.13", "0.041", "0.050", "-0.13", "0.041", "0.05", "0.12", "0.06", "-0.095", "-0.12", "0.06", "-0.095", "0.0", "0.09", "-0.1", "0.07", "0.18", "-0.09", "-0.07", "0.18", "-0.09", "0.14", "0.13", "-0.07", "-0.14", "0.13", "-0.07")
	dance.system(skelName, "link","Trunk_comp","assign_monitor_points",  "150")

	# set the limits
	print("Now setting limits for " + skelName)
	setLimits(skelType, skelName)

	# ik chains
	dance.system(skelName, "create_ik", "left arm")
	dance.system(skelName, "ik", "left arm", "add_joint", "Left_Shoulder")
	dance.system(skelName, "ik", "left arm", "add_joint", "Left_Forearm")
	dance.system(skelName, "ik", "left arm", "add_joint", "Left_Hand")
	dance.system(skelName, "create_ik", "right arm")
	dance.system(skelName, "ik", "right arm", "add_joint", "Right_Shoulder")
	dance.system(skelName, "ik", "right arm", "add_joint", "Right_Forearm")
	dance.system(skelName, "ik", "right arm", "add_joint", "Right_Hand")
	dance.system(skelName, "create_ik", "left leg")
	dance.system(skelName, "ik", "left leg", "add_joint", "Left_Thigh")
	dance.system(skelName, "ik", "left leg", "add_joint", "Left_Shin")
	dance.system(skelName, "ik", "left leg", "add_joint", "Left_Foot")
	dance.system(skelName, "create_ik", "right leg")
	dance.system(skelName, "ik", "right leg", "add_joint", "Right_Thigh")
	dance.system(skelName, "ik", "right leg", "add_joint", "Right_Shin")
	dance.system(skelName, "ik", "right leg", "add_joint", "Right_Foot")
	dance.system(skelName, "create_ik", "left arm with body")
	dance.system(skelName, "ik", "left arm with body", "add_joint", "Trunk_comp")
	dance.system(skelName, "ik", "left arm with body", "add_joint", "Left_Shoulder")
	dance.system(skelName, "ik", "left arm with body", "add_joint", "Left_Forearm")
	dance.system(skelName, "ik", "left arm with body", "add_joint", "Left_Hand")
	dance.system(skelName, "create_ik", "right arm with body")
	dance.system(skelName, "ik", "right arm with body", "add_joint", "Trunk_comp")
	dance.system(skelName, "ik", "right arm with body", "add_joint", "Right_Shoulder")
	dance.system(skelName, "ik", "right arm with body", "add_joint", "Right_Forearm")
	dance.system(skelName, "ik", "right arm with body", "add_joint", "Right_Hand")
	dance.system(skelName, "create_ik", "head")
	dance.system(skelName, "ik", "head", "add_joint", "Neck")
	dance.system(skelName, "ik", "head", "add_joint", "Head_comp")
	dance.system(skelName, "create_ik", "head with body")
	dance.system(skelName, "ik", "head with body", "add_joint", "Trunk_comp")
	dance.system(skelName, "ik", "head with body" , "add_joint", "Neck")
	dance.system(skelName, "ik", "head with body", "add_joint", "Head_comp")

	# set joint stiffness
	setJointStiffness(skelType, skelName)
	# set joint stiffness
	#print("Now setting joint stiffness for " + skelName + "...")
	#numlinks = int(dance.system(skelName, "show", "number_of_links"))
	#i = 1 
	#while (i < numlinks) :
	#   dance.system(skelName, "joint", repr(i), "set", "stiff_damp", "1", ".2")
	#   i = i + 1


def setUpSkel(skelType, skelName) :
	setUpSkelnosim(skelType, skelName)
	setUpSim(skelType, skelName)

dance.plugin("Cube")
dance.plugin("Sphere")

# construct a unique name
offset = 0
allplugins = dance.show()
basename = "skeleton"
name = basename
if len(allplugins) > 0 :
	found = 1
	x = 0
	while found > 0 :
		allsystems = allplugins.split(' ')
		found = allsystems.count(name)
		if (found > 0) :
			name = basename + repr(x)
			offset = offset + 1
			x = x + 1
print("About to create ODE skeleton...")
setUpSkel("odeskel18", name)
dance.showinterface(name + "sim")
dance.showinterface(name)
dance.system(name, "setstate", 0, offset)

# load the sphere collision information
dance.system(name, "load_spheres", dance.dancedir() + "/scripts/tutorials/tutorial2data/man.sphere")

# load the other collisions
dance.instance("Cube", name + "_collisionTrunk")
dance.instance("Cube", name + "_collisionHip")
dance.instance("Capsule", name + "_collisionLeftThigh")
dance.instance("Capsule", name + "_collisionRightThigh")
dance.instance("Capsule", name + "_collisionLeftShin")
dance.instance("Capsule", name + "_collisionRightShin")
dance.instance("Capsule", name + "_collisionLeftShoulder")
dance.instance("Capsule", name + "_collisionRightShoulder")
dance.instance("Capsule", name +"_collisionLeftForearm")
dance.instance("Capsule", name + "_collisionRightForearm")
dance.instance("Cube", name + "_collisionLeftFoot")
dance.instance("Cube", name + "_collisionRightFoot")
dance.instance("Cube", name + "_collisionLeftHand")
dance.instance("Cube", name + "_collisionRightHand")
dance.instance("Sphere", name + "_collisionHead")
dance.geometry(name + "_collisionTrunk", "material", "default")
dance.geometry(name + "_collisionTrunk", "translate", 0.000000, 1.438784, 0.024595)
dance.geometry(name + "_collisionTrunk", "rotation", 0.000000, 0.000000, 0.000000)
dance.geometry(name + "_collisionTrunk", "scale", 0.307851, 0.390000, 0.172162)
dance.geometry(name + "_collisionTrunk", "transparency", 0.000000)
dance.geometry(name + "_collisionTrunk", "trans_matrix", 0.307851, 0.000000, 0.000000, 0.000000, 0.000000, 0.390000, 0.000000, 0.000000, 0.000000, 0.000000, 0.172162, 0.000000, 0.000000, 1.438784, 0.024595, 1.000000)
dance.geometry(name + "_collisionTrunk", "use_trans_matrix", "true")
dance.geometry(name + "_collisionTrunk", "material", "default")
dance.geometry(name + "_collisionTrunk", "solid")
dance.geometry(name + "_collisionTrunk", "visible", "false")
dance.geometry(name + "_collisionHip", "material", "default")
dance.geometry(name + "_collisionHip", "translate", 0.000000, 1.123379, 0.027738)
dance.geometry(name + "_collisionHip", "rotation", 0.000000, 0.000000, 0.000000)
dance.geometry(name + "_collisionHip", "scale", 0.271717, 0.221902, 0.138689)
dance.geometry(name + "_collisionHip", "transparency", 0.000000)
dance.geometry(name + "_collisionHip", "trans_matrix", 0.271717, 0.000000, 0.000000, 0.000000, 0.000000, 0.221902, 0.000000, 0.000000, 0.000000, 0.000000, 0.138689, 0.000000, 0.000000, 1.123379, 0.027738, 1.000000)
dance.geometry(name + "_collisionHip", "use_trans_matrix", "true")
dance.geometry(name + "_collisionHip", "material", "default")
dance.geometry(name + "_collisionHip", "solid")
dance.geometry(name + "_collisionHip", "visible", "false")
dance.geometry(name + "_collisionLeftThigh", "radius", 0.077000)
dance.geometry(name + "_collisionLeftThigh", "length", 0.281000)
dance.geometry(name + "_collisionLeftThigh", "translate", 0.098573, 0.812804, 0.000000)
dance.geometry(name + "_collisionLeftThigh", "rotation", 90.000000, 0.000000, 0.000000)
dance.geometry(name + "_collisionLeftThigh", "scale", 1.000000, 1.000000, 1.000000)
dance.geometry(name + "_collisionLeftThigh", "transparency", 0.000000)
dance.geometry(name + "_collisionLeftThigh", "trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, -1.000000, 0.000000, 0.000000, 0.098573, 0.812804, 0.000000, 1.000000)
dance.geometry(name + "_collisionLeftThigh", "use_trans_matrix", "true")
dance.geometry(name + "_collisionLeftThigh", "material", "default")
dance.geometry(name + "_collisionLeftThigh", "solid")
dance.geometry(name + "_collisionLeftThigh", "visible", "false")
dance.geometry(name + "_collisionRightThigh", "radius", 0.077000)
dance.geometry(name + "_collisionRightThigh", "length", 0.281000)
dance.geometry(name + "_collisionRightThigh", "translate", -0.098573, 0.812804, 0.000000)
dance.geometry(name + "_collisionRightThigh", "rotation", 90.000000, 0.000000, 0.000000)
dance.geometry(name + "_collisionRightThigh", "scale", 1.000000, 1.000000, 1.000000)
dance.geometry(name + "_collisionRightThigh", "transparency", 0.000000)
dance.geometry(name + "_collisionRightThigh", "trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, -1.000000, 0.000000, 0.000000, -0.098573, 0.812804, 0.000000, 1.000000)
dance.geometry(name + "_collisionRightThigh", "use_trans_matrix", "true")
dance.geometry(name + "_collisionRightThigh", "material", "default")
dance.geometry(name + "_collisionRightThigh", "solid")
dance.geometry(name + "_collisionRightThigh", "visible", "false")
dance.geometry(name + "_collisionLeftShin", "radius", 0.058000)
dance.geometry(name + "_collisionLeftShin", "length", 0.355000)
dance.geometry(name + "_collisionLeftShin", "translate", 0.084615, 0.374109, 0.022321)
dance.geometry(name + "_collisionLeftShin", "rotation", 90.000000, 0.000000, 0.000000)
dance.geometry(name + "_collisionLeftShin", "scale", 1.000000, 1.000000, 1.000000)
dance.geometry(name + "_collisionLeftShin", "transparency", 0.000000)
dance.geometry(name + "_collisionLeftShin", "trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, -1.000000, 0.000000, 0.000000, 0.084615, 0.374109, 0.022321, 1.000000)
dance.geometry(name + "_collisionLeftShin", "use_trans_matrix", "true")
dance.geometry(name + "_collisionLeftShin", "material", "default")
dance.geometry(name + "_collisionLeftShin", "solid")
dance.geometry(name + "_collisionLeftShin", "visible", "false")
dance.geometry(name + "_collisionRightShin", "radius", 0.058000)
dance.geometry(name + "_collisionRightShin", "length", 0.355000)
dance.geometry(name + "_collisionRightShin", "translate", -0.084615, 0.374109, 0.022321)
dance.geometry(name + "_collisionRightShin", "rotation", 90.000000, 0.000000, 0.000000)
dance.geometry(name + "_collisionRightShin", "scale", 1.000000, 1.000000, 1.000000)
dance.geometry(name + "_collisionRightShin", "transparency", 0.000000)
dance.geometry(name + "_collisionRightShin", "trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, -1.000000, 0.000000, 0.000000, -0.084615, 0.374109, 0.022321, 1.000000)
dance.geometry(name + "_collisionRightShin", "use_trans_matrix", "true")
dance.geometry(name + "_collisionRightShin", "material", "default")
dance.geometry(name + "_collisionRightShin", "solid")
dance.geometry(name + "_collisionRightShin", "visible", "false")
dance.geometry(name + "_collisionLeftForearm", "radius", 0.055000)
dance.geometry(name + "_collisionLeftForearm", "length", 0.168000)
dance.geometry(name + "_collisionLeftForearm", "translate", 0.594595, 1.582610, 0.012413)
dance.geometry(name + "_collisionLeftForearm", "rotation", 0.000000, 90.000000, 0.000000)
dance.geometry(name + "_collisionLeftForearm", "scale", 1.000000, 1.000000, 1.000000)
dance.geometry(name + "_collisionLeftForearm", "transparency", 0.000000)
dance.geometry(name + "_collisionLeftForearm", "trans_matrix", 0.000000, 0.000000, -1.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.594595, 1.582610, 0.012413, 1.000000)
dance.geometry(name + "_collisionLeftForearm", "use_trans_matrix", "true")
dance.geometry(name + "_collisionLeftForearm", "material", "default")
dance.geometry(name + "_collisionLeftForearm", "solid")
dance.geometry(name + "_collisionLeftForearm", "visible", "false")
dance.geometry(name + "_collisionRightForearm", "radius", 0.055000)
dance.geometry(name + "_collisionRightForearm", "length", 0.168000)
dance.geometry(name + "_collisionRightForearm", "translate", -0.594595, 1.582610, 0.012413)
dance.geometry(name + "_collisionRightForearm", "rotation", 0.000000, 90.000000, 0.000000)
dance.geometry(name + "_collisionRightForearm", "scale", 1.000000, 1.000000, 1.000000)
dance.geometry(name + "_collisionRightForearm", "transparency", 0.000000)
dance.geometry(name + "_collisionRightForearm", "trans_matrix", 0.000000, 0.000000, -1.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, -0.594595, 1.582610, 0.012413, 1.000000)
dance.geometry(name + "_collisionRightForearm", "use_trans_matrix", "true")
dance.geometry(name + "_collisionRightForearm", "material", "default")
dance.geometry(name + "_collisionRightForearm", "solid")
dance.geometry(name + "_collisionRightForearm", "visible", "false")
dance.geometry(name + "_collisionLeftFoot", "material", "default")
dance.geometry(name + "_collisionLeftFoot", "translate", 0.068881, 0.126568, 0.080543)
dance.geometry(name + "_collisionLeftFoot", "rotation", 0.000000, 0.000000, 0.000000)
dance.geometry(name + "_collisionLeftFoot", "scale", 0.093928, 0.028766, 0.247383)
dance.geometry(name + "_collisionLeftFoot", "transparency", 0.000000)
dance.geometry(name + "_collisionLeftFoot", "trans_matrix", 0.093928, 0.000000, 0.000000, 0.000000, 0.000000, 0.028766, 0.000000, 0.000000, 0.000000, 0.000000, 0.247383, 0.000000, 0.068881, 0.126568, 0.080543, 1.000000)
dance.geometry(name + "_collisionLeftFoot", "use_trans_matrix", "true")
dance.geometry(name + "_collisionLeftFoot", "material", "default")
dance.geometry(name + "_collisionLeftFoot", "solid")
dance.geometry(name + "_collisionLeftFoot", "visible", "false")
dance.geometry(name + "_collisionRightFoot", "material", "default")
dance.geometry(name + "_collisionRightFoot", "translate", -0.068881, 0.126568, 0.080543)
dance.geometry(name + "_collisionRightFoot", "rotation", 0.000000, 0.000000, 0.000000)
dance.geometry(name + "_collisionRightFoot", "scale", 0.093928, 0.028765, 0.247383)
dance.geometry(name + "_collisionRightFoot", "transparency", 0.000000)
dance.geometry(name + "_collisionRightFoot", "trans_matrix", 0.093928, 0.000000, 0.000000, 0.000000, 0.000000, 0.028765, 0.000000, 0.000000, 0.000000, 0.000000, 0.247383, 0.000000, -0.068881, 0.126568, 0.080543, 1.000000)
dance.geometry(name + "_collisionRightFoot", "use_trans_matrix", "true")
dance.geometry(name + "_collisionRightFoot", "material", "default")
dance.geometry(name + "_collisionRightFoot", "solid")
dance.geometry(name + "_collisionRightFoot", "visible", "false")
dance.geometry(name + "_collisionLeftHand", "material", "default")
dance.geometry(name + "_collisionLeftHand", "translate", 0.816688, 1.594455, 0.011724)
dance.geometry(name + "_collisionLeftHand", "rotation", 0.000000, 0.000000, 0.000000)
dance.geometry(name + "_collisionLeftHand", "scale", 0.153129, 0.046896, 0.140687)
dance.geometry(name + "_collisionLeftHand", "transparency", 0.000000)
dance.geometry(name + "_collisionLeftHand", "trans_matrix", 0.153129, 0.000000, 0.000000, 0.000000, 0.000000, 0.046896, 0.000000, 0.000000, 0.000000, 0.000000, 0.140687, 0.000000, 0.816688, 1.594455, 0.011724, 1.000000)
dance.geometry(name + "_collisionLeftHand", "use_trans_matrix", "true")
dance.geometry(name + "_collisionLeftHand", "material", "default")
dance.geometry(name + "_collisionLeftHand", "solid")
dance.geometry(name + "_collisionLeftHand", "visible", "false")
dance.geometry(name + "_collisionRightHand", "material", "default")
dance.geometry(name + "_collisionRightHand", "translate", -0.816688, 1.594460, 0.011724)
dance.geometry(name + "_collisionRightHand", "rotation", 0.000000, 0.000000, 0.000000)
dance.geometry(name + "_collisionRightHand", "scale", 0.153129, 0.046896, 0.140687)
dance.geometry(name + "_collisionRightHand", "transparency", 0.000000)
dance.geometry(name + "_collisionRightHand", "trans_matrix", 0.153129, 0.000000, 0.000000, 0.000000, 0.000000, 0.046896, 0.000000, 0.000000, 0.000000, 0.000000, 0.140687, 0.000000, -0.816688, 1.594460, 0.011724, 1.000000)
dance.geometry(name + "_collisionRightHand", "use_trans_matrix", "true")
dance.geometry(name + "_collisionRightHand", "material", "default")
dance.geometry(name + "_collisionRightHand", "solid")
dance.geometry(name + "_collisionRightHand", "visible", "false")
dance.geometry(name + "_collisionHead", "subdivisions", 20)
dance.geometry(name + "_collisionHead", "translate", 0.000000, 1.784282, 0.041495)
dance.geometry(name + "_collisionHead", "rotation", 0.000000, 0.000000, 0.000000)
dance.geometry(name + "_collisionHead", "scale", 0.130000, 0.130000, 0.130000)
dance.geometry(name + "_collisionHead", "transparency", 0.000000)
dance.geometry(name + "_collisionHead", "trans_matrix", 0.130000, 0.000000, 0.000000, 0.000000, 0.000000, 0.130000, 0.000000, 0.000000, 0.000000, 0.000000, 0.130000, 0.000000, 0.000000, 1.784282, 0.041495, 1.000000)
dance.geometry(name + "_collisionHead", "use_trans_matrix", "true")
dance.geometry(name + "_collisionHead", "material", "default")
dance.geometry(name + "_collisionHead", "solid")
dance.geometry(name + "_collisionHead", "visible", "false")

dance.geometry(name + "_collisionLeftShoulder", "radius", 0.060000)
dance.geometry(name + "_collisionLeftShoulder", "length", 0.180000)
dance.geometry(name + "_collisionLeftShoulder", "translate", 0.305000, 1.582610, 0.011932)
dance.geometry(name + "_collisionLeftShoulder", "rotation", 0.000000, 90.000000, 0.000000)
dance.geometry(name + "_collisionLeftShoulder", "scale", 1.000000, 1.000000, 1.000000)
dance.geometry(name + "_collisionLeftShoulder", "transparency", 0.000000)
dance.geometry(name + "_collisionLeftShoulder", "trans_matrix", 0.000000, 0.000000, -1.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.305000, 1.582610, 0.011932, 1.000000)
dance.geometry(name + "_collisionLeftShoulder", "use_trans_matrix", "true")
dance.geometry(name + "_collisionLeftShoulder", "material", "default")
dance.geometry(name + "_collisionLeftShoulder", "solid")
dance.geometry(name + "_collisionLeftShoulder", "visible", "false")
dance.geometry(name + "_collisionRightShoulder", "radius", 0.060000)
dance.geometry(name + "_collisionRightShoulder", "length", 0.180000)
dance.geometry(name + "_collisionRightShoulder", "translate", -0.305000, 1.582610, 0.011932)
dance.geometry(name + "_collisionRightShoulder", "rotation", 0.000000, 90.000000, 0.000000)
dance.geometry(name + "_collisionRightShoulder", "scale", 1.000000, 1.000000, 1.000000)
dance.geometry(name + "_collisionRightShoulder", "transparency", 0.000000)
dance.geometry(name + "_collisionRightShoulder", "trans_matrix", 0.000000, 0.000000, -1.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, -0.305000, 1.582610, 0.011932, 1.000000)
dance.geometry(name + "_collisionRightShoulder", "use_trans_matrix", "true")
dance.geometry(name + "_collisionRightShoulder", "material", "default")
dance.geometry(name + "_collisionRightShoulder", "solid")
dance.geometry(name + "_collisionRightShoulder", "visible", "false")


dance.system(name, "link", "Hip", "collision_geometry", name + "_collisionHip", "world")
dance.system(name, "link", "Hip", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Hip", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, -1.130990, -0.005200, 1.000000)
dance.system(name, "link", "Hip", "assign_collision_monitor_points", 0, 0, 0.135858, 1.23433, 0.0970822, 0.135858, 1.01243, 0.0970822, 0.135858, 1.23433, -0.0416066, 0.135858, 1.01243, -0.0416066, -0.135858, 1.23433, 0.0970822, -0.135858, 1.01243, 0.0970822, -0.135858, 1.23433, -0.0416066, -0.135858)

dance.system(name, "link", "Trunk_comp", "collision_geometry", name + "_collisionTrunk", "world")
dance.system(name, "link", "Trunk_comp", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Trunk_comp", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, -1.397840, -0.020100, 1.000000)
dance.system(name, "link", "Trunk_comp", "assign_collision_monitor_points", 0, 0, 0.153925, 1.63378, 0.110676, 0.153925, 1.24378, 0.110676, 0.153925, 1.63378, -0.0614865, 0.153925, 1.24378, -0.0614865, -0.153925, 1.63378, 0.110676, -0.153925, 1.24378, 0.110676, -0.153925, 1.63378, -0.0614865, -0.153925)

dance.system(name, "link", "Head_comp", "collision_geometry", name + "_collisionHead", "world")
dance.system(name, "link", "Head_comp", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Head_comp", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, -1.810512, -0.063000, 1.000000)
dance.system(name, "link", "Head_comp", "assign_collision_monitor_points", 0, 0, -0.0376726, 1.75464, -0.0793447, -0.0964165, 1.80873, 0.125197, -0.069803, 1.6752, 0.0528289, 0.0204785, 1.80032, -0.085876, 0.119234, 1.74379, 0.0737973, -0.100373, 1.83036, -0.0270765, -0.0543606, 1.71372, 0.136184, -0.119701, 1.7742, -0.00820298, -0.0657404, 1.8942, 0.0637899, 0.0729476)

dance.system(name, "link", "Left_Shoulder", "geometry", "skeleton_Left_Shoulder", "world")
dance.system(name, "link", "Left_Shoulder", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Left_Shoulder", "geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
dance.system(name, "link", "Left_Shoulder", "assign_monitor_points", 50)
dance.system(name, "link", "Left_Shoulder", "collision_geometry", name + "_collisionLeftShoulder", "world")
dance.system(name, "link", "Left_Shoulder", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Left_Shoulder", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.309400, -1.587000, -0.022700, 1.000000)
dance.system(name, "link", "Left_Shoulder", "assign_collision_monitor_points", 1.07119, 2.21251, 0.139138, 1.10666, 1.56494, 0.609449, -0.4691, 1.65075, 0.641318, 0.105901, 2.53155, 0.256608, 0.46265, 2.46459, 0.456076, -0.0917629, 0.956747, -0.65954, -0.646131, 1.60642, 0.319802, 1.01296, 2.19765, -0.335217, 0.159756, 2.45067, -0.462809, 0.941764, 2.16534, 0.516865)

dance.system(name, "link", "Left_Forearm", "geometry", "skeleton_Left_Forearm", "world")
dance.system(name, "link", "Left_Forearm", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Left_Forearm", "geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
dance.system(name, "link", "Left_Forearm", "assign_monitor_points", 50)
dance.system(name, "link", "Left_Forearm", "collision_geometry", name + "_collisionLeftForearm", "world")
dance.system(name, "link", "Left_Forearm", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Left_Forearm", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.579800, -1.590900, -0.024000, 1.000000)
dance.system(name, "link", "Left_Forearm", "assign_collision_monitor_points", 0.955131, 1.3771, 0.922237, 1.13316, 0.878347, 0.474968, 0.773164, 1.40662, -0.955648, -0.152406, 2.24469, -0.0478735, -0.0606128, 2.02862, -0.597323, 0.183369, 1.13666, -0.782583, 0.0586281, 1.50637, 0.853203, 1.44449, 1.31572, 0.466784, -0.154951, 0.922366, 0.0599549, 1.18846, 0.955808, 0.51684)

dance.system(name, "link", "Left_Hand", "collision_geometry", name + "_collisionLeftHand", "world")
dance.system(name, "link", "Left_Hand", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Left_Hand", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.782600, -1.594741, -0.024000, 1.000000)
dance.system(name, "link", "Left_Hand", "assign_collision_monitor_points", 0, 0, 0.893252, 1.6179, 0.0820676, 0.893252, 1.57101, 0.0820676, 0.893252, 1.6179, -0.0586197, 0.893252, 1.57101, -0.0586197, 0.740123, 1.6179, 0.0820676, 0.740123, 1.57101, 0.0820676, 0.740123, 1.6179, -0.0586197, 0.740123)

dance.system(name, "link", "Right_Shoulder", "geometry", "skeleton_Right_Shoulder", "world")
dance.system(name, "link", "Right_Shoulder", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Right_Shoulder", "geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
dance.system(name, "link", "Right_Shoulder", "assign_monitor_points", 50)
dance.system(name, "link", "Right_Shoulder", "collision_geometry", name + "_collisionRightShoulder", "world")
dance.system(name, "link", "Right_Shoulder", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Right_Shoulder", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.309400, -1.587000, -0.022700, 1.000000)
dance.system(name, "link", "Right_Shoulder", "assign_collision_monitor_points", -1.14952, 1.48952, 0.539308, -0.883747, 1.80901, 0.795382, -0.967139, 1.37548, -0.708255, 0.00799758, 1.0988, 0.829222, -0.854226, 1.19302, -0.72737, -0.0389579, 0.833949, -0.595297, 0.271946, 2.02509, -0.674611, -0.553072, 0.998696, 0.784916, -1.2255, 1.95117, 0.141711, -1.10687, 1.61309, 0.608655)

dance.system(name, "link", "Right_Forearm", "geometry", "skeleton_Right_Forearm", "world")
dance.system(name, "link", "Right_Forearm", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Right_Forearm", "geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
dance.system(name, "link", "Right_Forearm", "assign_monitor_points", 50)
dance.system(name, "link", "Right_Forearm", "collision_geometry", name + "_collisionRightForearm", "world")
dance.system(name, "link", "Right_Forearm", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Right_Forearm", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.579800, -1.590900, -0.024000, 1.000000)
dance.system(name, "link", "Right_Forearm", "assign_collision_monitor_points", -1.16339, 2.265, 0.471557, -0.0483263, 1.14882, -0.70412, -0.352303, 1.71935, -0.948106, -1.58867, 1.53722, -0.0863164, 0.095822, 0.90042, -0.228298, 0.162599, 2.02867, -0.464757, -0.819719, 0.776417, -0.534736, -0.951846, 1.19463, -0.8372, -0.0339328, 0.814163, -0.296048, -1.30144, 1.15424, 0.575325)

dance.system(name, "link", "Right_Hand", "collision_geometry", name + "_collisionRightHand", "world")
dance.system(name, "link", "Right_Hand", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Right_Hand", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.782600, -1.594741, -0.024000, 1.000000)
dance.system(name, "link", "Right_Hand", "assign_collision_monitor_points", 0, 0, -0.740123, 1.61791, 0.0820674, -0.740123, 1.57101, 0.0820674, -0.740123, 1.61791, -0.0586196, -0.740123, 1.57101, -0.0586196, -0.893253, 1.61791, 0.0820674, -0.893253, 1.57101, 0.0820674, -0.893253, 1.61791, -0.0586196, -0.893253)

dance.system(name, "link", "Left_Thigh", "geometry", "skeleton_Left_Thigh", "world")
dance.system(name, "link", "Left_Thigh", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Left_Thigh", "geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
dance.system(name, "link", "Left_Thigh", "assign_monitor_points", 50)
dance.system(name, "link", "Left_Thigh", "collision_geometry", name + "_collisionLeftThigh", "world")
dance.system(name, "link", "Left_Thigh", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Left_Thigh", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, -0.000000, 1.000000, 0.000000, 0.000000, -0.000000, -0.000000, 1.000000, 0.000000, -0.094900, -0.852441, -0.025300, 1.000000)
dance.system(name, "link", "Left_Thigh", "assign_collision_monitor_points", 0.870604, 0.770426, -0.634171, 0.845959, 0.151514, -0.0641083, -0.679571, 0.384435, -0.459339, -0.395524, -0.0465082, -0.132103, 0.395555, 1.12092, -0.903806, 0.803346, 0.352796, -0.540081, 0.274795, 0.0524695, -0.62517, -0.515473, 1.60165, -0.0258571, 0.721491, 0.533189, 0.730608, -0.290099, 1.48717, 0.627826)

dance.system(name, "link", "Left_Shin", "geometry", "skeleton_Left_Shin", "world")
dance.system(name, "link", "Left_Shin", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Left_Shin", "geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
dance.system(name, "link", "Left_Shin", "assign_monitor_points", 50)
dance.system(name, "link", "Left_Shin", "collision_geometry", name + "_collisionLeftShin", "world")
dance.system(name, "link", "Left_Shin", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Left_Shin", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, -0.000000, 1.000000, -0.000000, 0.000000, -0.000000, 0.000000, 1.000000, 0.000000, -0.070200, -0.398771, -0.035700, 1.000000)
dance.system(name, "link", "Left_Shin", "assign_collision_monitor_points", 0.0986913, 0.878734, -0.840903, 0.206625, -0.250246, 0.793875, 0.116961, -0.389421, 0.667283, -0.384979, 1.04613, 0.594924, -0.499025, 0.693366, -0.724297, 1.00338, 0.0320102, -0.174769, -0.50022, -0.160684, 0.63221, -0.389023, 0.486854, -0.851152, -0.641214, 1.04126, 0.189892, -0.511879, 0.586985, -0.751551)

dance.system(name, "link", "Left_Foot", "collision_geometry", name + "_collisionLeftFoot", "world")
dance.system(name, "link", "Left_Foot", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Left_Foot", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.062400, -0.138761, -0.070800, 1.000000)
dance.system(name, "link", "Left_Foot", "assign_collision_monitor_points", 0, 0, 0.115845, 0.140951, 0.204235, 0.115845, 0.112185, 0.204235, 0.115845, 0.140951, -0.0431483, 0.115845, 0.112185, -0.0431483, 0.0219166, 0.140951, 0.204235, 0.0219166, 0.112185, 0.204235, 0.0219166, 0.140951, -0.0431483, 0.0219166)

dance.system(name, "link", "Right_Thigh", "geometry", "skeleton_Right_Thigh", "world")
dance.system(name, "link", "Right_Thigh", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Right_Thigh", "geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
dance.system(name, "link", "Right_Thigh", "assign_monitor_points", 50)
dance.system(name, "link", "Right_Thigh", "collision_geometry", name + "_collisionRightThigh", "world")
dance.system(name, "link", "Right_Thigh", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Right_Thigh", "collision_geom_inv_trans_matrix", 1.000000, -0.000000, -0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, -0.000000, 1.000000, 0.000000, 0.094900, -0.852441, -0.025300, 1.000000)
dance.system(name, "link", "Right_Thigh", "assign_collision_monitor_points", 0.534686, 0.687054, -0.763656, 0.41642, 0.981096, -0.840512, -0.804092, 0.495394, -0.633636, -0.842919, 1.14097, 0.581599, -0.382062, 1.47935, -0.68946, -0.603276, 0.311084, -0.702533, -0.816423, 1.20476, -0.57538, 0.813253, 0.832041, 0.410127, -0.160603, -0.111597, -0.376344, 0.286708, 0.944046, 0.913419)

dance.system(name, "link", "Right_Shin", "geometry", "skeleton_Right_Shin", "world")
dance.system(name, "link", "Right_Shin", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Right_Shin", "geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
dance.system(name, "link", "Right_Shin", "assign_monitor_points", 50)
dance.system(name, "link", "Right_Shin", "collision_geometry", name + "_collisionRightShin", "world")
dance.system(name, "link", "Right_Shin", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Right_Shin", "collision_geom_inv_trans_matrix", 1.000000, -0.000000, -0.000000, 0.000000, 0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.070200, -0.398771, -0.035700, 1.000000)
dance.system(name, "link", "Right_Shin", "assign_collision_monitor_points", 0.661807, 0.435649, -0.640299, -0.895734, 0.646397, -0.495314, -0.622666, 0.350409, -0.820258, 0.839462, 0.175272, -0.304091, 0.00345183, 1.34143, -0.215447, 0.746103, -0.145116, 0.223101, 0.126756, -0.600119, -0.0564323, 0.52423, 0.148142, -0.738104, 0.15729, 1.07633, -0.647278, 0.666028, 0.910444, 0.408169)
dance.system(name, "link", "Right_Foot", "collision_geometry", name + "_collisionRightFoot", "world")
dance.system(name, "link", "Right_Foot", "scale", 1.000000, 1.000000, 1.000000)
dance.system(name, "link", "Right_Foot", "collision_geom_inv_trans_matrix", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.062400, -0.138761, -0.070800, 1.000000)
dance.system(name, "link", "Right_Foot", "assign_collision_monitor_points", 0, 0, -0.0219166, 0.140951, 0.204235, -0.0219166, 0.112185, 0.204235, -0.0219166, 0.140951, -0.0431481, -0.0219166, 0.112185, -0.0431481, -0.115845, 0.140951, 0.204235, -0.115845, 0.112185, 0.204235, -0.115845, 0.140951, -0.0431481, -0.115845)



# restitution
dance.system(name, "link", "Hip", "restitution", 0.500000)
dance.system(name, "link", "Trunk_comp", "restitution", 0.100000)
dance.system(name, "link", "Neck", "restitution", 0.100000)
dance.system(name, "link", "Head_comp", "restitution", 0.100000)
dance.system(name, "link", "Left_Shoulder", "restitution", 0.100000)
dance.system(name, "link", "Left_Forearm", "restitution", 0.100000)
dance.system(name, "link", "Left_Hand", "restitution", 0.100000)
dance.system(name, "link", "Right_Shoulder", "restitution", 0.100000)
dance.system(name, "link", "Right_Forearm", "restitution", 0.100000)
dance.system(name, "link", "Right_Hand", "restitution", 0.100000)
dance.system(name, "link", "Left_Thigh", "restitution", 0.100000)
dance.system(name, "link", "Left_Shin", "restitution", 0.100000)
dance.system(name, "link", "Left_Foot", "restitution", 0.100000)
dance.system(name, "link", "Right_Thigh", "restitution", 0.100000)
dance.system(name, "link", "Right_Shin", "restitution", 0.100000)
dance.system(name, "link", "Right_Foot", "restitution", 0.100000)







