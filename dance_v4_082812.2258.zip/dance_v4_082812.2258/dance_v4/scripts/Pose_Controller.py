dance.plugin("PDController")
dance.instance("PosePDController", "pose_controller")
dance.showinterface("pose_controller")

