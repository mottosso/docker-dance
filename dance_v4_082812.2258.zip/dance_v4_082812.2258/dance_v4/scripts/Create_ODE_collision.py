dance.plugin("Plane")

# construct a unique name
offset = 0
allplugins = dance.show()
basename = "plane"
name = basename
if len(allplugins) > 0 :
	found = 1
	x = 0
	while found > 0 :
		allsystems = allplugins.split(' ')
		found = allsystems.count(name)
		if (found > 0) :
			name = basename + repr(x)
			offset = offset + 1
			x = x + 1


dance.instance("ODECollision", name)
dance.showinterface(name)
