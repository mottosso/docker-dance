Motion capture is available at:

http://mocap.cs.cmu.edu/

