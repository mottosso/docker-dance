# reset the scene
dance.reset()

# set the camera
dance.view("view_perspective", "projtype", "persp")
dance.view("view_perspective", "orientation", 0.627902, 0.000000, 0.778292, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, -0.778292, 0.000000, 0.627902, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
dance.view("view_perspective", "distance", 28.343081)
dance.view("view_perspective", "target", 0.096149, 1.089283, 0.114043)
dance.view("view_perspective", "pan", 0.000000, 0.000000)
dance.view("view_perspective", "background", 0.700000, 0.700000, 0.700000, 1.000000)
dance.view("view_perspective", "clipBounds", -0.865219, 0.865219, -0.794920, 0.794920, 14.171540, 42.514621)
dance.view("view_perspective", "grid", "off")

# add the skeleton
dance.load(dance.dancedir() + "/scripts/Create_skeleton_ODE.py")

# add the ground
dance.load(dance.dancedir() + "/scripts/Create_ground_ODE.py")

# add gravity
dance.load(dance.dancedir() + "/scripts/Create_gravity.py")

# load the skeleton's initial position
dance.system("skeleton", "load", "state", dance.dancedir() + "/scripts/tutorials/tutorial3data/slightbend_ode.state")

# load the sphere collision plugin
dance.instance("ODECollision", "collide")
dance.actuator("collide", "apply", "all")
dance.showinterface("collide")

# create a pose controller
dance.instance("PosePDController", "pose_controller")
dance.actuator("pose_controller", "apply", "skeleton")
dance.showinterface("pose_controller")

dance.instance("SensorSkel18", "sensor")
dance.generic("sensor", "system", "skeleton")

dance.actuator("pose_controller", "load_pose", dance.dancedir() + "/scripts/tutorials/tutorial2data/arms_down.state")
dance.actuator("pose_controller", "load_pose", dance.dancedir() + "/scripts/tutorials/tutorial2data/bend.state")
dance.actuator("pose_controller", "load_pose", dance.dancedir() + "/scripts/tutorials/tutorial2data/block_face.state")
dance.actuator("pose_controller", "load_pose", dance.dancedir() + "/scripts/tutorials/tutorial2data/jumping_jack.state")
dance.actuator("pose_controller", "load_pose", dance.dancedir() + "/scripts/tutorials/tutorial2data/bend_down.state")
dance.actuator("pose_controller", "desired_pose", "arms_down")

# load some control scripts
dance.actuator("pose_controller", "load_pose", dance.dancedir() + "/run/Ragdoll.py", "Ragdoll", "scriptable")
dance.actuator("pose_controller", "load_pose", dance.dancedir() + "/run/PointLineTest.py", "PointLineTest", "scriptable")

dance.actuator("pose_controller", "desired_pose", "PointLineTest")

# set the initial stiffness & damping for the pose controller
dance.actuator("pose_controller", "ks", ".3")
dance.actuator("pose_controller", "kd", ".3")

dance.view("view_perspective", "set", "double", "dollyrate", 0.02)
dance.view("view_perspective", "attrinfo", "dollyrate", "priority", 80)
dance.view("view_perspective", "set", "double", "far", 1000)
dance.view("view_perspective", "attrinfo", "far", "priority", 60)
dance.view("view_perspective", "set", "double", "fov", 54.43)
dance.view("view_perspective", "attrinfo", "fov", "priority", 40)
dance.view("view_perspective", "set", "double", "near", 0.1)
dance.view("view_perspective", "attrinfo", "near", "priority", 50)
dance.view("view_perspective", "set", "double", "panrate", 0.5)
dance.view("view_perspective", "attrinfo", "panrate", "priority", 90)
dance.view("view_perspective", "set", "double", "posx", 3.73612)
dance.view("view_perspective", "attrinfo", "posx", "priority", 10)
dance.view("view_perspective", "set", "double", "posy", 1.69023)
dance.view("view_perspective", "attrinfo", "posy", "priority", 11)
dance.view("view_perspective", "set", "double", "posz", 1.23368)
dance.view("view_perspective", "attrinfo", "posz", "priority", 12)
dance.view("view_perspective", "set", "int", "shadowmapsize", 512)
dance.view("view_perspective", "attrinfo", "shadowmapsize", "priority", 140)
dance.view("view_perspective", "set", "bool", "showcamera", "false")
dance.view("view_perspective", "attrinfo", "showcamera", "priority", 96)
dance.view("view_perspective", "set", "bool", "showtarget", "false")
dance.view("view_perspective", "attrinfo", "showtarget", "priority", 95)
dance.view("view_perspective", "set", "double", "targetx", -0.00723788)
dance.view("view_perspective", "attrinfo", "targetx", "priority", 20)
dance.view("view_perspective", "set", "double", "targety", 0.936239)
dance.view("view_perspective", "attrinfo", "targety", "priority", 21)
dance.view("view_perspective", "set", "double", "targetz", 0.0177211)
dance.view("view_perspective", "attrinfo", "targetz", "priority", 22)
dance.view("view_perspective", "set", "matrix", "transform", 5.97819e-322, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
dance.view("view_perspective", "attrinfo", "transform", "hidden", "true", "priority", 100)
dance.view("view_perspective", "set", "vec3", "up", 0, 1, 0)
dance.view("view_perspective", "attrinfo", "up", "priority", 30)
dance.view("view_perspective", "set", "bool", "useshadows", "false")
dance.view("view_perspective", "attrinfo", "useshadows", "priority", 130)
dance.view("view_perspective", "set", "bool", "visible", "true")
dance.view("view_perspective", "attrinfo", "visible", "locked", "true", "priority", 10)
dance.view("view_perspective", "set", "double", "zoomrate", 50)
dance.view("view_perspective", "attrinfo", "zoomrate", "priority", 70)
dance.view("view_top", "set", "double", "dollyrate", 0.1)
dance.view("view_top", "attrinfo", "dollyrate", "priority", 10)
dance.view("view_top", "set", "double", "panrate", 0.001)
dance.view("view_top", "attrinfo", "panrate", "priority", 10)
dance.view("view_top", "set", "bool", "visible", "true")
dance.view("view_top", "attrinfo", "visible", "locked", "true", "priority", 10)
dance.view("view_top", "set", "double", "zoomrate", 0.01)
dance.view("view_top", "attrinfo", "zoomrate", "priority", 10)
dance.view("view_top", "projtype", "top")
dance.view("view_top", "orientation", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
dance.view("view_top", "distance", 56.609915)
dance.view("view_top", "target", 0.000000, 0.832324, 0.000000)
dance.view("view_top", "pan", 0.000000, 0.000000)
dance.view("view_top", "background", 0.630000, 0.630000, 0.630000, 1.000000)
dance.view("view_top", "clipBounds", -30.808117, 30.808117, -28.304958, 28.304958, -28.304958, 28.304958)
dance.view("view_top", "grid", "on")
dance.view("view_top", "gridColor", 0.500000, 0.500000, 0.500000)
dance.view("view_top", "gridHighlightColor", 0.000000, 0.000000, 0.000000)
dance.view("view_top", "shadows", "off")
dance.view("view_top", "solids", "on")
dance.view("view_right", "set", "double", "dollyrate", 0.1)
dance.view("view_right", "attrinfo", "dollyrate", "priority", 10)
dance.view("view_right", "set", "double", "panrate", 0.001)
dance.view("view_right", "attrinfo", "panrate", "priority", 10)
dance.view("view_right", "set", "bool", "visible", "true")
dance.view("view_right", "attrinfo", "visible", "locked", "true", "priority", 10)
dance.view("view_right", "set", "double", "zoomrate", 0.01)
dance.view("view_right", "attrinfo", "zoomrate", "priority", 10)
dance.view("view_right", "projtype", "right")
dance.view("view_right", "orientation", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
dance.view("view_right", "distance", 56.609915)
dance.view("view_right", "target", 0.000000, 0.832324, 0.000000)
dance.view("view_right", "pan", 0.000000, 0.000000)
dance.view("view_right", "background", 0.630000, 0.630000, 0.630000, 1.000000)
dance.view("view_right", "clipBounds", -30.808117, 30.808117, -28.304958, 28.304958, -28.304958, 28.304958)
dance.view("view_right", "grid", "on")
dance.view("view_right", "gridColor", 0.500000, 0.500000, 0.500000)
dance.view("view_right", "gridHighlightColor", 0.000000, 0.000000, 0.000000)
dance.view("view_right", "shadows", "off")
dance.view("view_right", "solids", "on")
dance.view("view_front", "set", "double", "dollyrate", 0.1)
dance.view("view_front", "attrinfo", "dollyrate", "priority", 10)
dance.view("view_front", "set", "double", "panrate", 0.001)
dance.view("view_front", "attrinfo", "panrate", "priority", 10)
dance.view("view_front", "set", "bool", "visible", "true")
dance.view("view_front", "attrinfo", "visible", "locked", "true", "priority", 10)
dance.view("view_front", "set", "double", "zoomrate", 0.01)
dance.view("view_front", "attrinfo", "zoomrate", "priority", 10)
dance.view("view_front", "projtype", "front")
dance.view("view_front", "orientation", 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000, 1.000000)
dance.view("view_front", "distance", 56.609915)
dance.view("view_front", "target", 0.000000, 0.832324, 0.000000)
dance.view("view_front", "pan", 0.000000, 0.000000)
dance.view("view_front", "background", 0.630000, 0.630000, 0.630000, 1.000000)
dance.view("view_front", "clipBounds", -30.808117, 30.808117, -28.304958, 28.304958, -28.304958, 28.304958)
dance.view("view_front", "grid", "on")
dance.view("view_front", "gridColor", 0.500000, 0.500000, 0.500000)
dance.view("view_front", "gridHighlightColor", 0.000000, 0.000000, 0.000000)
dance.view("view_front", "shadows", "off")
dance.view("view_front", "solids", "on")

dance.simul("-setSimulationTimeStep", .001)









