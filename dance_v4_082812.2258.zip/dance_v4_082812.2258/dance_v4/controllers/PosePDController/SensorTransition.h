#ifndef SENSORTRANSITION_H
#define SENSORTRANSITION_H

#include "Transition.h"
#include "PoseInterpreter.h"
#include "PoseData.h"
#include <vector>
#include <string>

#ifdef _DEBUG
 #undef _DEBUG
#ifdef __APPLE__
 #include <Python/python.h>
#else
 #include <Python.h>
#endif // __APPLE__
 #define _DEBUG
 #undef _CRT_MANIFEST_RETAIL
#else
#ifdef __APPLE__
 #include <Python/python.h>
#else
 #include "Python.h"
#endif // __APPLE__
#endif


#ifdef WIN32
#ifdef _POSEENTRY
#ifndef POSEENTRY
#define POSEENTRY __declspec(dllexport)
#endif
#else
#define POSEENTRY __declspec(dllimport)
#endif
#else
#ifndef POSEENTRY
#define POSEENTRY
#endif
#endif

class POSEENTRY SensorTransition : public Transition
{
public:
	SensorTransition(Pose* source, Pose* destination, char* file);
	~SensorTransition();
	void copy(SensorTransition* orig);
	bool check(PoseData* pdata);
	bool parse();
	bool makeScript();

	char* getFileName();
	void setFileName(char* name);

	std::vector<std::string> commands;
	
private:
	char filename[512];
	std::string pythonScript;
	PyObject* code;

};

#endif

