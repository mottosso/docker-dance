#include "DOFWindow.h"

using namespace fltk;

DOFWindow::DOFWindow(int x, int y, int w, int h, char* name) : Window(x, y, w, h, name)
{
}

