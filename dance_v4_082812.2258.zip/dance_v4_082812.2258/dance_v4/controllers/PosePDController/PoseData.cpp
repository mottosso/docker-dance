#include "PoseData.h"
#include "PosePDController.h"
#include "PoseInterpreter.h"

PoseInterpreter* PoseData::interpreter = NULL;

PoseData::PoseData(Sensor *s, PosePDController* c)
{
	if (PoseData::interpreter == NULL)
	{
		PoseData::interpreter = new PoseInterpreter(s, c);
		PoseData::interpreter->Init();
		this->setPoseInterpreter(PoseData::interpreter);
	}
	setStartTime(-1.0);
}

PoseData::~PoseData()
{
	if (PoseData::interpreter != NULL)
	{
		PoseData::interpreter->controller = NULL;
		delete PoseData::interpreter;
		PoseData::interpreter = NULL;
	}

}

void PoseData::setStartTime(double time)
{
	this->startTime = time;
	if (this->interpreter != NULL) 
		this->interpreter->controller->setLocalTime(time);
}

double PoseData::getStartTime()
{
	return this->startTime;
}

void PoseData::setCurrentTime(double time)
{
	this->currentTime = time;
}

double PoseData::getCurrentTime()
{
	return this->currentTime;
}

PoseInterpreter* PoseData::getPoseInterpreter()
{
	return PoseData::interpreter;
}

void PoseData::setPoseInterpreter(PoseInterpreter* i)
{
	PoseData::interpreter = i;
}
