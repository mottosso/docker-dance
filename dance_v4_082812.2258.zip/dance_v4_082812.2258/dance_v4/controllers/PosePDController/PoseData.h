#ifndef POSEDATA_H
#define POSEDATA_H

class PosePDController;
class Sensor;
class PoseInterpreter;

/// PoseData is used primarily to provide access to a singleton PoseInterpreter
class PoseData
{
public:
	PoseData(Sensor* s, PosePDController* c);
	~PoseData();
	void setStartTime(double time);
	double getStartTime();
	void setCurrentTime(double time);
	double getCurrentTime();

	static PoseInterpreter* getPoseInterpreter();
	static void setPoseInterpreter(PoseInterpreter* i);

private:
	double startTime;
	double currentTime;
	static PoseInterpreter* interpreter;
};

#endif

