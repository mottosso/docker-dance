/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef _POSEGROUP_H
#define _POSEGROUP_H

#include "Pose.h"
#include "Transition.h"
#include "TimeTransition.h"
#include "SensorTransition.h"
#include "ArticulatedObject.h"
#include <vector>

#ifdef WIN32
#ifdef _POSEENTRY
#ifndef POSEENTRY
#define POSEENTRY __declspec(dllexport)
#endif
#else
#define POSEENTRY __declspec(dllimport)
#endif
#else
#ifndef POSEENTRY
#define POSEENTRY
#endif
#endif

class POSEENTRY PoseGroup
{
	public:
		PoseGroup();
		~PoseGroup();

		bool parse(std::ifstream &file);
		bool write(std::ofstream &file, char* filename, ArticulatedObject* ao);
		void addPose(Pose* p);
		void addPose(Pose* p, int num);
		void removePose(Pose* p);
		void removePose(int num);
		void swapPoses(int pose1, int pose2);
		void insertPose(Pose* p, int num);
		Pose* getPose(int num);
		int getNumPoses();
		int getDesiredPoseIndex();
		void setDesiredPoseIndex(int index);
		void copy(PoseGroup* psq);
		void insert(PoseGroup* psq, int index);

		void addTransition(Transition* t);
		void addTransition(Transition* t, int num);
		void removeTransition(Transition* t);
		void removeTransition(int num);
		void insertTransition(Transition* t, int num);
		Transition* getTransition(int num);
		int getNumTransitions();
		int getNumTransitions(Pose* p);
		Transition* getTransition(Pose* p, int num);
		

	private:
		std::vector<Transition*> transitions;
		std::vector<Pose*> poses;
		int m_desiredPoseIndex;

};

#endif
