/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "PosePDControllerWindow.h"
#include "PosePDController.h"
#include "PDController.h"
#include "danceInterp.h"
#include <fltk/file_chooser.h>
#include <fltk/ask.h>
#include "AnimatablePose.h"
#include "ScriptablePose.h"
#include "dance.h"
#include "DSimulatorManager.h"
#include "Joint.h"

using namespace fltk;
using namespace std;

PosePDControllerWindow::PosePDControllerWindow(PosePDController* c, int x, int y, int width, int height, const char* name) : ScrollGroup(x, y, width, height, strdup(name))
{
	controller = c;

	this->begin();

	choiceAO = new Choice(110, 10, 150, 20, "Articulated Object");
	choiceAO->callback(this->SelectAOCB, this);

	browserPoses = new Browser(20, 45, 100, 150, "Poses ");
	browserPoses->callback(PoseSelectCB, this);

	Group* groupPoseControl = new Group(150, 35, 200, 70);
	groupPoseControl->box(fltk::BORDER_BOX);
	groupPoseControl->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupPoseControl->begin();

	buttonLoadPose = new Button(10, 10, 80, 20, "Load Pose");
	buttonLoadPose->callback(LoadPoseCB, this);

	buttonLoadPoseCurrent = new Button(100, 10, 95, 20, "Load Current Pose");
	buttonLoadPoseCurrent->callback(LoadPoseCurrentCB, this);

	buttonRemovePose = new Button(10, 40, 80, 20, "Remove Pose");
	buttonRemovePose->callback(RemovePoseCB, this);

	buttonSetSkeletonToPose = new Button(100, 40, 95, 20, "Set To Pose");
	buttonSetSkeletonToPose->callback(SetSkeletonToPoseCB, this);

	groupPoseControl->end();

	Group* groupBackgroundPoseControl = new Group(20, 200, 120, 125);
	groupBackgroundPoseControl->box(fltk::BORDER_BOX);
	groupBackgroundPoseControl->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupBackgroundPoseControl->begin();

	browserBackgroundPoses = new Browser(10, 15, 100, 50, "Background Control");
	browserBackgroundPoses->callback(BackgroundPoseSelectCB, this);

	buttonLoadBackgroundPose = new Button(10, 70, 50, 20, "Load");
	buttonLoadBackgroundPose->callback(LoadBackgroundPoseCB, this);

	buttonRemoveBackgroundPose = new Button(10, 95, 50, 20, "Remove");
	buttonRemoveBackgroundPose->callback(RemoveBackgroundPoseCB, this);

	buttonReloadBackgroundPose = new Button(70, 70, 40, 15, "Reload");
	buttonReloadBackgroundPose->callback(this->ReloadBackgroundScriptCB, this);

	groupBackgroundPoseControl->end();

	Group* groupKsKd = new Group(150, 110, 200, 90);
	groupKsKd->box(fltk::BORDER_BOX);
	groupKsKd->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupKsKd->begin();

	inputStrength = new FloatInput(10, 10, 40, 20);
	inputStrength->callback(InputStrengthCB, this);

	wheelStrength = new ThumbWheel(50, 10, 30, 20, "Strength");
	wheelStrength->step(.1);
	// set the value according to the PD Controller
	wheelStrength->value(c->getKS());
	wheelStrength->minimum(0.0);
	wheelStrength->maximum(1000000.0);
	wheelStrength->callback(StrengthCB, this);

	inputDamping = new FloatInput(100, 10, 40, 20);
	inputDamping->callback(InputDampingCB, this);
	wheelDamping = new ThumbWheel(150, 10, 30, 20, "Damping");
	wheelDamping->step(.1);
	// set the value according to the PD Controller
	wheelDamping->value(c->getKD());
	wheelDamping->minimum(0);
	wheelDamping->maximum(1000000.0);
	wheelDamping->callback(DampingCB, this);

	checkCriticallyDamped = new CheckButton(10, 45, 100, 20, "Critically Damped");
	checkCriticallyDamped->callback(CriticalDampingCB, this);

	checkTotalInertia = new CheckButton( 112, 45, 50, 20, "Total Inertia" );
	checkTotalInertia->callback(TotalInertiaCB, this);
		
	checkJointLimits = new CheckButton(10, 70, 100, 20, "Maintain joint limits with springs");
	checkJointLimits->callback(JointLimitsCB, this);

	groupKsKd->end();

	inputMaxTorque = new FloatInput(210, 210, 40, 20, "Max Torque");
	inputMaxTorque->callback(MaxTorqueCB, this);

	inputMaxVelocity = new FloatInput(300, 210, 40, 20, "Max Vel");
	inputMaxVelocity->callback(MaxVelocityCB, this);

	choiceDriveType = new Choice(210, 245, 120, 20, "Drive Type" );
	choiceDriveType->callback( DriveTypeCB, this );
	for( int i = (int)StartDriveType; i < (int)EndDriveType; ++i )
	{
		choiceDriveType->add( PDController::getDriveTypeNames()[i], this );
	}

	checkUseControlEvents = new CheckButton(210, 270, 80, 20, "Non-linear editor");
	checkUseControlEvents->callback(this->UseControlEventsCB, this);

	checkAutonomousControl = new CheckButton(160, 210, 80, 20, "Use autonomous control");
	checkAutonomousControl->callback(this->UseAutonomousControlCB, this);
	checkAutonomousControl->hide();

	// GUI for static poses
	groupStaticPose = new Group(60, 560, 200, 90, "Static Poses");
	groupStaticPose->box(fltk::BORDER_BOX);
	groupStaticPose->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupStaticPose->begin();

	buttonPoseDot[0] = new Button(75, 10, 40, 20, "1");
	buttonPoseDot[1] = new Button(120, 25, 40, 20, "2");
	buttonPoseDot[2] = new Button(75, 40, 40, 20, "3");
	buttonPoseDot[3] = new Button(30, 25, 40, 20, "4");

	for (int x = 0; x < 4; x++)
		buttonPoseDot[x]->callback(PoseDotCB, this);

	checkPoseMode = new CheckButton(10, 65, 40, 20, "Interpolate Poses");
	checkPoseMode->callback(InterpolateCB, this);

	buttonClearPoseDots = new Button(150, 65, 40, 20, "Clear");
	buttonClearPoseDots->callback(ClearPoseDots, this);

	groupStaticPose->end();

	// GUI for animatable poses
	groupAnimatablePose = new Group(20, 560, 270, 125, "Animatable Poses");
	groupAnimatablePose->box(fltk::BORDER_BOX);
	groupAnimatablePose->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupAnimatablePose->begin();

	outputClipLength = new FloatInput(60, 20, 40, 20, "Clip Length");
	outputClipLength->color(fltk::GRAY75);
	outputCurrentClipTime = new FloatInput(150, 20, 40, 20, "Clip Time");
	outputCurrentClipTime->color(fltk::GRAY75);
	inputOffset = new FloatInput(60, 45, 40, 20, "Clip Offset");
	buttonResetOffset = new Button(180, 20, 80, 20, "Reset Offset");
	buttonResetOffset->callback(ResetAnimPoseOffsetCB, this);
	sliderAnimation = new ValueSlider(110, 45, 150, 20);
	sliderAnimation->callback(AnimationPreviewCB, this);
	checkFixRoot = new CheckButton(10, 70, 80, 20, "Fix root");
	checkFixRoot->callback(FixRootCB, this);
	inputRootKS = new FloatInput(90, 70, 40, 20, "KS");
	inputRootKS->callback(this->RootKSKDCB, this);
	inputRootKD = new FloatInput(150, 70, 40, 20, "KD");
	inputRootKD->callback(this->RootKSKDCB, this);
	checkKinematic = new CheckButton(10, 95, 40, 20, "Kinematic");
	checkKinematic->callback(KinematicCB, this);

	groupAnimatablePose->end();

	groupScriptablePose = new Group(60, 560, 200, 120, "Scriptable Poses");
	groupScriptablePose->box(fltk::BORDER_BOX);
	groupScriptablePose->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupScriptablePose->begin();

	buttonReloadScript = new Button(10, 80, 80, 20, "Reload Script");
	buttonReloadScript->callback(ReloadScriptCB, this);
	
	outputScript = new Output(10, 20, 180, 20);
	outputScript->color(fltk::GRAY75); 

	groupScriptablePose->end();


	ArticulatedObject* ao = (ArticulatedObject*) this->controller->getAppliedObject(0);
	windowPose = new PoseWindow(this->controller, ao, 60, 350, 200, 200, "Current Pose");

	this->end();

	//windowPose = new PoseWindow(this->controller, ao, 100, 100, 300, 300, "Current Pose");
	//windowPose->hide();

	windowNLE = new NonLinearEditorWindow(this, 640, 150, "Controller Non-Linear Editor");
	windowNLE->hide();

	nleEditor = &c->getControllerModel();

	EditorWidget* editorWidget = windowNLE->getEditorWidget();
	editorWidget->setModel(nleEditor);

	this->updateGUI();
}

PosePDControllerWindow::~PosePDControllerWindow()
{
	if (this->windowPose != NULL)
		delete this->windowPose;

	delete this->windowNLE->getEditorWidget();
	delete this->windowNLE;

	//if (this->windowPoseEditor != NULL)
	//	delete this->windowPoseEditor;
}

void PosePDControllerWindow::show()
{
	this->updateGUI();
	Group::show();
}


void PosePDControllerWindow::updateGUI()
{
	// make sure that the pose window has the same parent as this window
//	Window* myParent = this->window();
//	Window* poseParent = windowPose->window();

//	if (myParent != poseParent)
//		windowPose->child_of(myParent);

	choiceAO->clear();
	choiceAO->add("Choose an articulated object");
	for (int x = 0; x < dance::AllSystems->size(); x++)
	{
		ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get(x));
		if (ao == NULL)
		{
			// ignore, not an articulated object
		}
		else
		{
			choiceAO->add(ao->getName());
		}
	}

	if (this->controller->getNumAppliedObjects() == 0)
	{
		// deactivate everything
		browserPoses->deactivate();
		buttonLoadPose->deactivate();
		buttonLoadPoseCurrent->deactivate();
		buttonRemovePose->deactivate();
		wheelStrength->deactivate();
		wheelDamping->deactivate();
		inputStrength->deactivate();
		inputDamping->deactivate();
		this->checkCriticallyDamped->deactivate();
		checkTotalInertia->deactivate();
		inputMaxTorque->deactivate();
		inputMaxVelocity->deactivate();
		checkAutonomousControl->deactivate();
		checkJointLimits->deactivate();
		checkUseControlEvents->deactivate();
		
		groupAnimatablePose->deactivate();
		outputClipLength->deactivate();
		outputCurrentClipTime->deactivate();
		inputOffset->deactivate();
		buttonResetOffset->deactivate();
		buttonSetSkeletonToPose->deactivate();
		choiceDriveType->deactivate();
		sliderAnimation->deactivate();

		windowPose->deactivate();
		this->checkPoseMode->deactivate();
		this->setStaticPoseControls(false);
		this->setDynamicPoseControls(false);
		this->setScriptablePoseControls(false);
	}
	else
	{
		// choose the appropriate articulated object
		ArticulatedObject* ao = (ArticulatedObject*) this->controller->getAppliedObject(0);

		for (int x = 0; x < choiceAO->size(); x++)
		{
			Widget* w = choiceAO->child(x);
			if (strcmp(ao->getName(), w->label()) == 0)
			{
				choiceAO->value(x);
				break;
			}
		}

		browserPoses->activate();
		buttonLoadPose->activate();
		buttonLoadPoseCurrent->activate();
		buttonRemovePose->activate();
		wheelStrength->activate();
		wheelDamping->activate();
		inputStrength->activate();
		inputDamping->activate();
		this->checkCriticallyDamped->activate();
		checkTotalInertia->activate();
		inputMaxTorque->activate();
		inputMaxVelocity->activate();
		checkAutonomousControl->activate();
		checkJointLimits->activate();
		checkUseControlEvents->activate();

		groupAnimatablePose->activate();
		outputClipLength->activate();
		outputCurrentClipTime->activate();
		inputOffset->activate();
		buttonResetOffset->activate();
		buttonSetSkeletonToPose->activate();
		choiceDriveType->activate();
		sliderAnimation->activate();

		windowPose->activate();


		wheelStrength->value(this->controller->getKS());
		wheelDamping->value(this->controller->getKD());
		inputStrength->value(this->controller->getKS());
		inputDamping->value(this->controller->getKD());
		if (this->controller->isCriticallyDamped())
		{
			this->checkCriticallyDamped->value(true);
			checkTotalInertia->activate();
			checkTotalInertia->value( this->controller->isUsingTotalInertia() );
			this->inputDamping->deactivate();
			this->wheelDamping->deactivate();
		}
		else
		{
			this->checkCriticallyDamped->value(false);
			checkTotalInertia->deactivate();
			this->inputDamping->activate();
			this->wheelDamping->activate();
		}

		inputMaxTorque->value(this->controller->getMaxTorque());
		inputMaxVelocity->value( controller->getMaxVelocity() );

		checkJointLimits->value(controller->isMaintainJointLimits());
		choiceDriveType->value( (int) controller->getDriveType() );
		checkUseControlEvents->value( (int) controller->isUseControlEvents());

		// change labels based on drive type
		if( VelocityDrive == controller->getDriveType() )
		{
			wheelStrength->label( "Velocity" );
			checkCriticallyDamped->value( false );
			checkCriticallyDamped->deactivate();
			checkTotalInertia->deactivate();
			wheelDamping->activate();
			inputDamping->activate();
		}
		else
		{
			wheelStrength->label( "Strength" );
			checkCriticallyDamped->activate();
			if( checkCriticallyDamped->value() )
			{
				checkTotalInertia->activate();
				wheelDamping->deactivate();
				inputDamping->deactivate();
			}
			else
			{
				checkTotalInertia->deactivate();
				wheelDamping->activate();
				inputDamping->activate();
			}
		}
		wheelDamping->label( "Damping" );
		inputMaxTorque->label( "Max Torque" );
		inputMaxVelocity->label( "Max Vel" );

		// remove the poses from the browser
		this->browserPoses->clear();

		// add the poses to the browser
		int numPoses = this->controller->getNumPoses();
		for (int x = 0; x < numPoses; x++)
		{
			Pose* p = this->controller->getSelectedPose(x);
			AnimatablePose* p1 = dynamic_cast<AnimatablePose*>(p);
			if (p1 != NULL)
			{
				string str = p->getName().c_str();
				str.append("*");
				if (p1->isKinematic())
					str.append("(k)");
				browserPoses->add(str.c_str());
			}
			else
			{
				browserPoses->add(p->getName().c_str());
			}
		}
		browserPoses->select(this->controller->getDesiredPoseIndex());

		AnimatablePose* animPose = dynamic_cast<AnimatablePose*>(this->controller->getTargetPose());
		if (animPose == NULL)
		{
			ScriptablePose* scriptPose = dynamic_cast<ScriptablePose*>(this->controller->getTargetPose());
			if (scriptPose == NULL)
			{
				this->setStaticPoseControls(true);
				this->setDynamicPoseControls(false);
				this->setScriptablePoseControls(false);
			}
			else
			{
				this->setStaticPoseControls(false);
				this->setDynamicPoseControls(false);
				this->setScriptablePoseControls(true);
			}
		}
		else
		{
			this->setStaticPoseControls(false);
			this->setDynamicPoseControls(true);
			this->setScriptablePoseControls(false);
		}
		
		// set the pose in the pose window if appropriate
		windowPose->setPose(this->controller->getTargetPose());

		if (this->controller->getAutonomousController() == NULL)
		{
			this->checkAutonomousControl->deactivate();
		}
		else
		{
			this->checkAutonomousControl->activate();
			if (this->controller->isUseAutonomousControl())
			{
				this->checkAutonomousControl->value(true);
			}
			else
			{
				this->checkAutonomousControl->value(false);
			}
		}

		// set the background poses
		this->browserBackgroundPoses->clear();

		// add the background poses to the browser
		int numBackgroundPoses = this->controller->getNumBackgroundPoses();
		for (int x = 0; x < numBackgroundPoses; x++)
		{
			Pose* p = this->controller->getSelectedBackgroundPose(x);
			AnimatablePose* p1 = dynamic_cast<AnimatablePose*>(p);
			if (p1 != NULL)
			{
				string str = p->getName().c_str();
				str.append("*");
				if (p1->isKinematic())
					str.append("(k)");
				this->browserBackgroundPoses->add(str.c_str());
			}
			else
			{
				browserBackgroundPoses->add(p->getName().c_str());
			}
		}
		browserBackgroundPoses->select(this->controller->getBackgroundPoseIndex());

		ScriptablePose* backScriptPose = dynamic_cast<ScriptablePose*>(this->controller->getTargetBackgroundPose());
		if (backScriptPose != NULL)
			buttonReloadBackgroundPose->activate();
		else
			buttonReloadBackgroundPose->deactivate();


		windowPose->redraw();
	}

}

void PosePDControllerWindow::setStaticPoseControls(bool val)
{
	if (val)
	{
		groupStaticPose->show();
	}
	else
	{
		groupStaticPose->hide();
	}
}

void PosePDControllerWindow::setDynamicPoseControls(bool val)
{
	if (val)
	{
		groupAnimatablePose->show();
		AnimatablePose* animPose = dynamic_cast<AnimatablePose*>(this->controller->getTargetPose());
		if (animPose != NULL)
		{
			this->inputOffset->value(animPose->getTimeOffset());
			this->outputClipLength->value(animPose->getAnimation()->getEndTime());
			this->outputCurrentClipTime->value(animPose->getLocalTime());
			this->sliderAnimation->range(animPose->getAnimation()->getStartTime(), animPose->getAnimation()->getEndTime());
			this->checkKinematic->activate();
			this->checkKinematic->value(animPose->isKinematic());
			//this->sliderAnimation->value(animPose->getLocalTime());
			if (animPose->isFixRoot())
			{
				this->checkFixRoot->value(true);
				this->inputRootKS->activate();
				this->inputRootKD->activate();
				double ks, kd;
				animPose->getRootKSKD(ks, kd);
				this->inputRootKS->value(ks);
				this->inputRootKD->value(kd);
				this->checkKinematic->deactivate();
			}
			else
			{
				this->checkFixRoot->value(false);
				this->inputRootKS->deactivate();
				this->inputRootKD->deactivate();
				this->checkKinematic->activate();
			}
		}
	}
	else
	{
		groupAnimatablePose->hide();
	}
}

void PosePDControllerWindow::setScriptablePoseControls(bool val)
{
	if (val)
	{
		this->groupScriptablePose->show();
		ScriptablePose* scriptablePose = dynamic_cast<ScriptablePose*>(this->controller->getTargetPose());
		if (scriptablePose != NULL)
		{
			this->outputScript->value(dance::convertPathToAbsolutePath(scriptablePose->getFileName()).c_str());
		}
	}
	else
	{
		this->groupScriptablePose->hide();
	}
}

Pose* PosePDControllerWindow::loadPose(char* filename, ArticulatedObject* ao)
{
	if (filename != NULL)
	{
		std::ifstream file(filename, ios::in);
		if (!file.good())
		{
			fltk::alert("Pose file '%s' is not valid.\n", filename);
			return NULL;
		}

		// is this a single pose, animated pose or pose sequence?
		Pose* p;
		string strfile = filename;
		int pos = strfile.find_last_of(".bvh");
		if (pos == strfile.size() - 1)
		{
			ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(this->controller->getAppliedObject(0));
			p = new AnimatablePose(ao, MAX_STATE);
		}
		else 
		{
			pos = strfile.find_last_of(".ani");
			if (pos == strfile.size() - 1)
			{
				ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(this->controller->getAppliedObject(0));
				p = new AnimatablePose(ao, MAX_STATE);
			}
			else
			{
				int pos = strfile.find_last_of(".py");
				if (pos == strfile.size() - 1)
				{
					p = new ScriptablePose(MAX_STATE);
				}
				else
				{
					p = new Pose(MAX_STATE);
				}
			}
		}
		bool success = p->parse(file);
		
		if (!success)
		{
			danceInterp::OutputMessage("File %s could not be properly parsed.", filename);
			delete p;
			file.close();
			return NULL;
		}
		p->setFileName(strfile);

		ScriptablePose* scriptp = dynamic_cast<ScriptablePose*>(p);
		// make sure that the DOF of the pose match that of the character
		if (scriptp == NULL && p->getSize() != ao->getStateSize())
		{
			fltk::alert("Poses do not match character. Pose contains %d DOF, character has %d DOF.", p->getSize(), ao->getStateSize());
			return NULL;
		}

		// extract the file name to use as a default name for the motion capture character
		int dotpos = strfile.find_last_of(".");
		int slashPos = strfile.find_last_of("\\");
		int slash2Pos = strfile.find_last_of("/");
		if (slashPos > slash2Pos)
			slash2Pos = slashPos;

		char* buff = NULL;
		bool conflict = true;
		while (conflict)
		{
			conflict = false;
			buff = (char*) fltk::input("Please enter the name of this pose:", strfile.substr(slash2Pos + 1, dotpos - (slash2Pos + 1)).c_str());

			if (buff == NULL || strlen(buff) == 0)
			{
				delete p;
				file.close();
				return NULL;
			}
			// make sure there is no name conflict
			for (int x = 0; x < this->controller->getNumPoses(); x++)
			{
				Pose* otherPose = this->controller->getSelectedPose(x);
				if (strcmp(otherPose->getName().c_str(), buff) == 0)
				{
					fltk::alert("Pose named '%s' already exists. Please choose another name.", buff);
					conflict = true;
				}
			}
			for (int x = 0; x < this->controller->getNumBackgroundPoses(); x++)
			{
				Pose* otherPose = this->controller->getSelectedBackgroundPose(x);
				if (strcmp(otherPose->getName().c_str(), buff) == 0)
				{
					fltk::alert("Pose named '%s' already exists. Please choose another name.", buff);
					conflict = true;
				}
			}
		}

		file.close();
		p->setName(string(buff));

		return p;
	}
	else
	{
		return NULL;
	}

}



void PosePDControllerWindow::PoseSelectCB(Widget *w, void *data)
{
	Browser* browser = (Browser*) w;
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	int toggled = browser->value();
	int selected = browser->selected(toggled);
	if (selected == 1)
		window->controller->setDesiredPoseIndex(toggled);
	else
		window->controller->setDesiredPoseIndex(-1);

	window->updateGUI();
}

void PosePDControllerWindow::BackgroundPoseSelectCB(fltk::Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	int toggled = window->browserBackgroundPoses->value();
	int selected = window->browserBackgroundPoses->selected(toggled);
	if (selected == 1)
		window->controller->setBackgroundPoseIndex(toggled);
	else
		window->controller->setBackgroundPoseIndex(-1);

	window->updateGUI();

}

void PosePDControllerWindow::LoadPoseCB(Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	ArticulatedObject* ao = (ArticulatedObject*) window->controller->getAppliedObject(0);
	if (ao == NULL)
	{
		fltk::alert("No articulated object found.\nPlease connect to an articulated object\nto load a pose.");
		return;
	}


	char* filename = (char *) file_chooser("Please choose a pose file:", "{*.state|*.bvh|*.psq|*.py}", NULL);

	if (filename != NULL)
	{
		Pose* p = window->loadPose(filename, ao);
		if (p != NULL)
		{
			danceInterp::OutputMessage("Pose #%d - '%s' added...", window->controller->getNumPoses(), p->getName().c_str());
			window->controller->addPose(p);
			window->controller->setDesiredPoseIndex(window->controller->getNumPoses() - 1);
			window->updateGUI();
		}
	}

}

void PosePDControllerWindow::LoadBackgroundPoseCB(Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	ArticulatedObject* ao = (ArticulatedObject*) window->controller->getAppliedObject(0);
	if (ao == NULL)
	{
		fltk::alert("No articulated object found.\nPlease connect to an articulated object\nto load a pose.");
		return;
	}

	char* filename = (char *) file_chooser("Please choose a pose file:", "{*.state|*.bvh|*.psq|*.py}", NULL);

	if (filename != NULL)
	{
		Pose* p = window->loadPose(filename, ao);
		if (p != NULL)
		{
			danceInterp::OutputMessage("Pose #%d - '%s' added...", window->controller->getNumPoses(), p->getName().c_str());
			window->controller->addBackgroundPose(p);
			window->controller->setBackgroundPoseIndex(window->controller->getNumBackgroundPoses() - 1);
			window->updateGUI();
		}
	}

}

void PosePDControllerWindow::RemovePoseCB(Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;
	Browser* browser = window->browserPoses;

	int toggled = browser->value();
	Pose* p = window->controller->getSelectedPose(toggled);
	window->controller->removePose(p);
	browser->remove(toggled);
	window->updateGUI();
}

void PosePDControllerWindow::RemoveBackgroundPoseCB(Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;
	Browser* browser = window->browserBackgroundPoses;

	int toggled = browser->value();

	Pose* p = window->controller->getSelectedBackgroundPose(toggled);
	window->controller->removeBackgroundPose(p);

	browser->remove(toggled);
	window->updateGUI();
}



void PosePDControllerWindow::LoadPoseCurrentCB(fltk::Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	// obtain the pose from the current state
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(window->controller->getAppliedObject(0));
	if (ao == NULL)
		return;

	Pose* p = new Pose(MAX_STATE);

	int stateSize = ao->getStateSize();
	double* state = new double[stateSize];
	ao->getState(state);

	for (int x = 0; x < stateSize; x++)
		p->setDOF(x, state[x]);

	delete state;

	const char* buff;
	bool conflict = true;
	while (conflict)
	{
		conflict = false;

		buff = fltk::input("Please enter the name of this pose:");
		if (buff == NULL || strlen(buff) == 0)
		{
			delete p;
			return;
		}
		// make sure there is no name conflict
		for (int x = 0; x < window->controller->getNumPoses(); x++)
		{
			Pose* otherPose = window->controller->getSelectedPose(x);
			if (strcmp(otherPose->getName().c_str(), buff) == 0)
			{
				fltk::alert("Pose named '%s' already exists. Please choose another name.", buff);
				conflict = true;
			}
		}
	}

	p->setName(string(buff));
	danceInterp::OutputMessage("Pose #%d - '%s' added...", window->controller->getNumPoses(), p->getName().c_str());
	window->controller->addPose(p);
	window->updateGUI();
}

void PosePDControllerWindow::StrengthCB(Widget *w, void *data)
{
	ThumbWheel* wheel = (ThumbWheel*) w;
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	double value = wheel->value();
	window->controller->setKS(value);
	window->inputStrength->value(value);
}

void PosePDControllerWindow::DampingCB(Widget *w, void *data)
{
	ThumbWheel* wheel = (ThumbWheel*) w;
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	double value = wheel->value();
	window->controller->setKD(value);
	window->inputDamping->value(value);
}

void PosePDControllerWindow::InputStrengthCB(Widget *w, void *data)
{
	FloatInput* input = (FloatInput*) w;
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	double value = input->fvalue();
	window->controller->setKS(value);
	window->wheelStrength->value(value);
}

void PosePDControllerWindow::InputDampingCB(Widget *w, void *data)
{
	FloatInput* input = (FloatInput*) w;
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	double value = input->fvalue();
	window->controller->setKD(value);
	window->wheelDamping->value(value);
}

void PosePDControllerWindow::ResetAnimPoseOffsetCB(fltk::Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	AnimatablePose* targetPose = dynamic_cast<AnimatablePose*>(window->controller->getTargetPose());

	if (targetPose->isKinematic())
	{
		double* oldOffset = NULL;
		
		ArticulatedObject* ao = (ArticulatedObject*) window->controller->getAppliedObject(0);

		// set the blend pose
		double poseData[MAX_STATE];
		ao->getState(poseData);
		targetPose->setBlendPoseData(poseData);

		Joint* rootJoint = ao->getJoint(0);
		int type = rootJoint->getJointType();
		switch (type)
		{
		case J_FREE:
			
			break;
		case J_PLANAR:
			// get the positional offset
			double pos[2];
			pos[0] = rootJoint->getState(0);
			pos[1] = rootJoint->getState(1);
			double animPos[2];
			targetPose->setLocalTime(0.0);
			animPos[0] = targetPose->getDOF(0);
			animPos[1] = targetPose->getDOF(1);
			// apply this offset to the kinematic pose

			oldOffset = targetPose->getOffset();
			double offset[3];
			offset[0] = pos[0] - animPos[0] + oldOffset[0];
			offset[1] = pos[1] - animPos[1] + oldOffset[1];
			offset[2] = 0.0; // no rotational offset
			targetPose->setOffset(offset);
		default:
			break;
		}
		targetPose->setHasBlendPose(true);
	}
	targetPose->setTimeOffset(dance::AllSimulators->getCurrentTime());
	targetPose->setLocalTime(0.0);

	window->updateGUI();
}

void PosePDControllerWindow::PoseDotCB(Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	Button* button = (Button*) w;

	int num = atoi(button->label());

	// does the pose already exist at that location?
	if (window->controller->getPoseDot(num - 1) == NULL)
		window->controller->setPoseDot(num - 1, window->controller->getSelectedPose(window->controller->getDesiredPoseIndex()));
	else
		window->controller->setPoseDot(num - 1, NULL);

	window->updateGUI();
}

void PosePDControllerWindow::ClearPoseDots( fltk::Widget* widget, void* data )
{
	PosePDControllerWindow* win = (PosePDControllerWindow*) data;

	win->controller->clearPoseDots();

	win->windowPose->redraw();
}


void PosePDControllerWindow::UseAutonomousControlCB(fltk::Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;
 
	window->controller->setUseAutonomousControl(window->checkAutonomousControl->value());
 
	window->updateGUI();
}


void PosePDControllerWindow::InterpolateCB(Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	CheckButton* check = (CheckButton*) w;

	if (check->value())
	{
		window->windowPose->setPoseMode(true);

	}
	else
	{
		window->windowPose->setPoseMode(false);
	}
}

void PosePDControllerWindow::SelectAOCB(fltk::Widget *w, void *data)
{
	PosePDControllerWindow* win = (PosePDControllerWindow*) data;

	Widget* widget = win->choiceAO->child(win->choiceAO->value());

	DSystem* sys = (DSystem*) dance::AllSystems->get((char*) widget->label());
	if (sys != NULL)
	{
		win->controller->setAppliedObject(sys);
		win->windowPose->setArticulatedObject((ArticulatedObject*) sys);
	}
	else
	{
		if (win->controller->getNumAppliedObjects() > 0)
		{
			DSystem* sys = win->controller->getAppliedObject(0);
			win->controller->removeAppliedObject(sys);
		}
	}

	win->updateGUI();
}

void PosePDControllerWindow::MaxTorqueCB(fltk::Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;
	FloatInput* input = (FloatInput*) w;
	window->controller->setMaxTorque(input->fvalue());
	window->updateGUI();
}

void PosePDControllerWindow::MaxVelocityCB(fltk::Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;
	FloatInput* input = (FloatInput*) w;
	window->controller->setMaxVelocity(input->fvalue());
	window->updateGUI();
}

void PosePDControllerWindow::SetSkeletonToPoseCB(Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	int selected = window->browserPoses->value();
	if (selected == -1)
		return;

	Pose* p = window->controller->getSelectedPose(window->browserPoses->value());
	if( !p )
	{
		// can occur if user hits "Set to Pose" with no poses available
		window->updateGUI();
		return;
	}

	DSystem* sys = window->controller->getAppliedObject(0);
	double state[MAX_STATE];
	if (sys != NULL)
	{
		for (int x = 0; x < p->getSize() && x < MAX_STATE; x++)
		{
			state[x] = p->getDOF(x);
		}
		sys->setState(state);
	}

	window->updateGUI();
}

void PosePDControllerWindow::JointLimitsCB(Widget *w, void *data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;

	window->controller->setMaintainJointLimits(window->checkJointLimits->value());

	window->updateGUI();
}

void PosePDControllerWindow::CriticalDampingCB(fltk::Widget* widget, void* data)
{
	PosePDControllerWindow* window = (PosePDControllerWindow*) data;
	window->controller->setCriticalDamping(window->checkCriticallyDamped->value());
	window->updateGUI();
}

void PosePDControllerWindow::TotalInertiaCB( fltk::Widget* widget, void* data )
{
	PosePDControllerWindow* win = (PosePDControllerWindow*) data;
	win->controller->setUsingTotalInertia( win->checkTotalInertia->value() );
	win->updateGUI();
}

void PosePDControllerWindow::DriveTypeCB( fltk::Widget* widget, void* data )
{
	PosePDControllerWindow* win = (PosePDControllerWindow*) data;
	win->controller->setDriveType( win->choiceDriveType->item()->label() );
	win->updateGUI();
}

void PosePDControllerWindow::AnimationPreviewCB( fltk::Widget* widget, void* data )
{
	PosePDControllerWindow* win = (PosePDControllerWindow*) data;

	double time = win->sliderAnimation->value();

	AnimatablePose* animPose = dynamic_cast<AnimatablePose*>(win->controller->getTargetPose());
	if (animPose != NULL)
	{
		animPose->setLocalTime(time);
		win->windowPose->setPose(win->controller->getTargetPose());
		win->windowPose->redraw();
	}
}

void PosePDControllerWindow::FixRootCB( fltk::Widget* widget, void* data )
{
	PosePDControllerWindow* win = (PosePDControllerWindow*) data;

	AnimatablePose* animPose = dynamic_cast<AnimatablePose*>(win->controller->getTargetPose());
	if (animPose != NULL)
	{
		animPose->setFixRoot(win->checkFixRoot->value());
	}

	win->updateGUI();
}

void PosePDControllerWindow::RootKSKDCB( fltk::Widget* widget, void* data )
{
	PosePDControllerWindow* win = (PosePDControllerWindow*) data;

	AnimatablePose* animPose = dynamic_cast<AnimatablePose*>(win->controller->getTargetPose());
	if (animPose != NULL)
	{
		animPose->setRootKSKD(win->inputRootKS->fvalue(), win->inputRootKD->fvalue());
	}

	win->updateGUI();
}

void PosePDControllerWindow::KinematicCB( fltk::Widget* widget, void* data )
{
	PosePDControllerWindow* win = (PosePDControllerWindow*) data;

	AnimatablePose* animPose = dynamic_cast<AnimatablePose*>(win->controller->getTargetPose());
	if (animPose != NULL)
	{
		animPose->setKinematic(win->checkKinematic->value());
	}

	win->updateGUI();
}

void PosePDControllerWindow::UseControlEventsCB( fltk::Widget* widget, void* data )
{
	PosePDControllerWindow* win = (PosePDControllerWindow*) data;

	CheckButton* check = (CheckButton*) widget;
	win->controller->setUseControlEvents(check->value());
	if (win->controller->isUseControlEvents())
		win->windowNLE->show();
	else
		win->windowNLE->hide();

	win->updateGUI();
}


void PosePDControllerWindow::ReloadScriptCB(Widget *w, void *data)
{
	PosePDControllerWindow* win = (PosePDControllerWindow*) data;

	ScriptablePose* origScript = dynamic_cast<ScriptablePose*>(win->controller->getSelectedPose(win->controller->getDesiredPoseIndex()));

	if (origScript != NULL)
	{
		ifstream file(origScript->getFileName().c_str());
		bool ok = origScript->parse(file, NULL);
		if (!ok)
		{
			fltk::alert("Problem parsing file. Please check code.");
		}
		else
		{
			file.close();
			// reload the target pose as well
			ScriptablePose* targetScript = dynamic_cast<ScriptablePose*>(win->controller->getTargetPose());
			if (targetScript != NULL)
			{
				ifstream file2(targetScript->getFileName().c_str());
				bool ok = targetScript->parse(file2, NULL);
				if (!ok)
				{
					fltk::alert("Problem parsing target file. Please check code.");
				}
			}
			fltk::alert("Script reloaded!");
		}

	}
	else
	{
		fltk::alert("Not a scriptable pose!");
	}
	
}

void PosePDControllerWindow::ReloadBackgroundScriptCB(Widget *w, void *data)
{
	PosePDControllerWindow* win = (PosePDControllerWindow*) data;

	ScriptablePose* origScript = dynamic_cast<ScriptablePose*>(win->controller->getSelectedBackgroundPose(win->controller->getBackgroundPoseIndex()));

	if (origScript != NULL)
	{
		ifstream file(origScript->getFileName().c_str());
		bool ok = origScript->parse(file, NULL);
		if (!ok)
		{
			fltk::alert("Problem parsing file. Please check code.");
		}
		else
		{
			file.close();
			// reload the target pose as well
			ScriptablePose* targetScript = dynamic_cast<ScriptablePose*>(win->controller->getTargetBackgroundPose());
			if (targetScript != NULL)
			{
				ifstream file2(targetScript->getFileName().c_str());
				bool ok = targetScript->parse(file2, NULL);
				if (!ok)
				{
					fltk::alert("Problem parsing target file. Please check code.");
				}
			}
			fltk::alert("Script reloaded!");
		}

	}
	else
	{
		fltk::alert("Not a scriptable pose!");
	}
}




