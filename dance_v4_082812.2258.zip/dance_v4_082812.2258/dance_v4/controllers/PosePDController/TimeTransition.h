#ifndef TIMETRANSITION_H
#define TIMETRANSITION_H

#include "Transition.h"

#ifdef WIN32
#ifdef _POSEENTRY
#ifndef POSEENTRY
#define POSEENTRY __declspec(dllexport)
#endif
#else
#define POSEENTRY __declspec(dllimport)
#endif
#else
#ifndef POSEENTRY
#define POSEENTRY
#endif
#endif

class POSEENTRY TimeTransition : public Transition
{
public:
	TimeTransition(Pose* source, Pose* destination);
	~TimeTransition();
	bool check(PoseData* pdata);
	void copy(TimeTransition* orig);
	void setTime(double timeVal);
	double getTime();
private:
	double time;

};



#endif
