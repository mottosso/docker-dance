#include "ControlEventManager.h"

ControlEventManager::ControlEventManager()
{
}

void ControlEventManager::addControlEvent(ControlEvent* event)
{
	for (std::vector<ControlEvent*>::iterator iter = events.begin(); 
		iter != events.end(); 
		iter++)
	{
		if ((*iter)->getStartTime() < (*iter)->getStartTime())
		{
			events.insert(iter, event);
			return;
		}
	}
	events.push_back(event);
}

ControlEvent* ControlEventManager::getControlEventByTime(double time)
{
	for (int x = 0; x < events.size(); x++)
	{
		if (time > events[x]->getStartTime() && 
			(x == events.size() - 1 || time < events[x + 1]->getStartTime()))
			return events[x];
	}

	if (events.size() > 0)
		return events[events.size() - 1];
	else
		return NULL;
}

ControlEvent* ControlEventManager::getControlEvent(int num)
{
	if (num >= 0 && num < events.size())
		return events[num];
	else
		return NULL;
}

void ControlEventManager::removeAllEvents()
{
	for (int x = 0; x < events.size(); x++)
		delete events[x];

	events.clear();
}

int ControlEventManager::getNumControlEvents()
{
	return events.size();
}
