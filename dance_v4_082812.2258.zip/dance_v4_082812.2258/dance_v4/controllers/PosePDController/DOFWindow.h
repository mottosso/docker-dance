#ifndef _DOFWINDOW_H
#define _DOFWINDOW_H

#include <fltk/Window.h>

class DOFWindow : fltk::Window
{
	public:
		DOFWindow(int x, int y, int w, int h, char* name);


};
#endif

