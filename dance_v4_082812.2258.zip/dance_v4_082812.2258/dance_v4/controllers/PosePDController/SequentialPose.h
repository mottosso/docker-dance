/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _SEQUENTIALPOSE_H
#define _SEQUENTIALPOSE_H

#include "Pose.h"
#include "PoseGroup.h"
#include "PoseData.h"
//#include "PoseInterpreter.h"

class SequentialPose : public Pose
{
public:
	SequentialPose(int numDOF);
	~SequentialPose();

	void setPoseGroup(PoseGroup* seq);
	PoseGroup* getPoseGroup();

	double getDOF(int index, PoseData* pdata);
	
	double getStartTime();
	void setStartTime(double time);

	void setLocalTime(double time);
	double getLocalTime();

	void setTimeOffset(double timeOffset);
	double getTimeOffset();

	void setInterpolation(bool val);
	bool getInterpolation();
	void setLoop(bool val);
	bool getLoop();

	void loadFile(char* filename);
	bool parse(std::ifstream &file, PoseData *pdata);
	void copy(SequentialPose* pose);

	void setCurrentPose(Pose* p);
	Pose* getCurrentPose();

	//static int regfoo(lua_State* L);
	//static bool sensorfoo(double num);



private:
	double startTime;
	bool interpolation;
	PoseGroup* poseSequence;
	bool loop;
	double localTime;
	double timeOffset;
	Pose* currentPose;
	//static PoseInterpreter* interpreter;
};


#endif
