#ifndef _CONTROLEVENTMANAGER_
#define _CONTROLEVENTMANAGER_

#include "ControlEvent.h"
#include <vector>

class ControlEventManager
{
	public:
		ControlEventManager();

		void addControlEvent(ControlEvent* event);
		ControlEvent* getControlEventByTime(double time);
		ControlEvent* getControlEvent(int num);
		void removeAllEvents();

		int getNumControlEvents();

	private:
		std::vector<ControlEvent*> events;
};
#endif