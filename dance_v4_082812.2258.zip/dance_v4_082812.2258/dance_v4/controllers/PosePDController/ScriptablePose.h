#ifndef _SCRIPTABLEPOSE_H
#define _SCRIPTABLEPOSE_H


#ifdef _DEBUG
 #undef _DEBUG
#ifdef __APPLE__
 #include <Python/python.h>
#else
 #include <Python.h>
#endif // __APPLE__
 #define _DEBUG
 #undef _CRT_MANIFEST_RETAIL
#else
#ifdef __APPLE__
 #include <Python/python.h>
#else
 #include "Python.h"
#endif // __APPLE__
#endif


#include "Pose.h"

#include <vector>

class PoseData;

/// Placeholder "pose" that holds a python script.
/// The class allows the script to appear in the list of possible poses
/// maintained by PosePDController.
class ScriptablePose : public Pose
{
public:
	ScriptablePose(int numDOF);
	virtual ~ScriptablePose();

	virtual bool parse(std::ifstream &file, PoseData* pdata = NULL);
	bool makeScript();
	void copy(ScriptablePose* pose);
	
	virtual bool start(double time, PosePDController *s);
	virtual bool step(double time);
	virtual bool stop(double time);
	virtual double success( void );

	/// Call the python function with the argument name.  Returns true on success.
	bool callPythonVersion( char *argFunctionName );

	/// Call a python function that returns a double.  In case of an error,
	/// a message is printed and 0.0 is returned.
	double callPythonDoubleFunction( char* argFunctionName );
	
	void flush();
	void setPythonController(PyObject *pc) { m_pythonController = pc ;} ;
	PyObject* getPythonController(void) { return m_pythonController;}  ;
	PyObject* callPythonProxy( const char *func ) ;

	friend class PoseInterpreter;
private:
	std::vector<Pose*> poseList;
	std::string script;
	PyObject *pDict ;
	PyObject *pModule ;
	/// Top level module 
	PyObject *pMainModule ; 
	/// Top level dictionary 
	PyObject *pMainDictionary ;
	PyObject *m_pythonController ;  //< this is the Python Object with the methods start, stop, success
	
};

#endif
