#include "ControlEventManagerWindow.h"
#include <fltk/ask.h>
#include <fltk/file_chooser.h>
#include "PosePDController.h"
#include "PosePDControllerWindow.h"
#include "dance.h"
#include <sstream>

using namespace fltk;

ControlEventManagerWindow::ControlEventManagerWindow(PosePDControllerWindow* pwin, int x, int y, int w, int h, char* name) : Window(w, h, name)
{
	poseWin = pwin;
	this->begin();
	
	this->browserEvents = new Browser(10, 20, 200, 200, "Events");

	this->buttonAddBefore = new Button(10, 230, 60, 20, "Add Before");
	this->buttonAddBefore->callback(AddEventBeforeCB, this);

	this->buttonAddAfter = new Button(80, 230, 60, 20, "Add After");
	this->buttonAddAfter->callback(AddEventAfterCB, this);

	this->buttonRemove = new Button(150, 230, 60, 20, "Remove");
	this->buttonRemove->callback(RemoveEventCB, this);

	this->buttonRemoveAll = new Button(220, 230, 60, 20, "Remove All");
	this->buttonRemoveAll->callback(RemoveAllEventsCB, this);

	this->end();
}

void ControlEventManagerWindow::updateGUI()
{
	this->browserEvents->clear();
	int numEvents = poseWin->controller->getControlEventManager()->getNumControlEvents();
	for (int x = 0; x < numEvents; x++)
	{
		ControlEvent* ce = poseWin->controller->getControlEventManager()->getControlEvent(x);
		std::stringstream sstr;
		sstr << ce->getName() << " " << ce->getStartTime() << " - " << ce->getEndTime() << std::endl;
		this->browserEvents->add(sstr.str().c_str());
	}
}

ControlEvent* ControlEventManagerWindow::createPoseEvent(Pose* p)
{
	if (p != NULL)
	{
		ControlEvent* ce = NULL;
		AnimatablePose* animPose = dynamic_cast<AnimatablePose*>(p);
		if (animPose)
		{
			AnimatablePoseEvent* event = new AnimatablePoseEvent();
			event->setAnimatablePose(animPose);
			event->setName((char*) animPose->getName().c_str());
			ce = event;
		}
		else 
		{
			ScriptablePose* scriptPose = dynamic_cast<ScriptablePose*>(p);
			if (scriptPose)
			{
				ScriptablePoseEvent* event = new ScriptablePoseEvent();
				event->setScriptablePose(scriptPose);
				event->setName((char*) scriptPose->getName().c_str());
				ce = event;
			}
			else
			{
				StaticPoseEvent* event = new StaticPoseEvent();
				event->setPose1(p);
				event->setInterpolation(1.0);
				event->setName((char*) p->getName().c_str());
				ce = event;
			}
		}
	
		ce->setKS(this->poseWin->controller->getKS());
		ce->setKD(this->poseWin->controller->getKD());

		// set some dummy times
		ce->setStartTime(dance::AllSimulators->getCurrentTime());
		ce->setEndTime(ce->getStartTime() + 1.0);

		return ce;
	}

	return NULL;
}

void ControlEventManagerWindow::AddEventBeforeCB(fltk::Widget* widget, void* data)
{
	ControlEventManagerWindow* win = (ControlEventManagerWindow*) widget;

	ControlEventManagerWindow* window = (ControlEventManagerWindow*) data;

	ArticulatedObject* ao = (ArticulatedObject*) window->poseWin->controller->getAppliedObject(0);
	if (ao == NULL)
	{
		fltk::alert("No articulated object found.\nPlease connect to an articulated object\nto load a pose.");
		return;
	}

	const char* filename = file_chooser("Please choose a pose file:", "{*.state|*.bvh|*.psq|*.py}", NULL);

	if (filename != NULL)
	{
		Pose* p = window->poseWin->loadPose((char*)filename, ao);
		ControlEvent* event = window->createPoseEvent(p);
		if (event != NULL)
		{
			window->poseWin->controller->getControlEventManager()->addControlEvent(event);
			window->updateGUI();
		}
		else
		{
			fltk::alert("Control event could not be loaded.");
		}
	}
}

void ControlEventManagerWindow::AddEventAfterCB(fltk::Widget* widget, void* data)
{
	ControlEventManagerWindow* win = (ControlEventManagerWindow*) widget;
}

void ControlEventManagerWindow::RemoveEventCB(fltk::Widget* widget, void* data)
{
	ControlEventManagerWindow* win = (ControlEventManagerWindow*) widget;
}

void ControlEventManagerWindow::RemoveAllEventsCB(fltk::Widget* widget, void* data)
{
	ControlEventManagerWindow* win = (ControlEventManagerWindow*) widget;
}

void ControlEventManagerWindow::SetKSCB(fltk::Widget* widget, void* data)
{
	ControlEventManagerWindow* win = (ControlEventManagerWindow*) widget;
}

void ControlEventManagerWindow::SetKDCB(fltk::Widget* widget, void* data)
{
	ControlEventManagerWindow* win = (ControlEventManagerWindow*) widget;
}

void ControlEventManagerWindow::SetCriticalDampingCB(fltk::Widget* widget, void* data)
{
	ControlEventManagerWindow* win = (ControlEventManagerWindow*) widget;
}
