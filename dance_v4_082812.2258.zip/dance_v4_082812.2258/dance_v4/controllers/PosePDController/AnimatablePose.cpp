/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "AnimatablePose.h"
#include "KeyFrame.h"
#include "matrix3x3.h"
#include "danceInterp.h"
#include "Joint.h"

AnimatablePose::AnimatablePose(ArticulatedObject* ao, int size) : Pose(size)
{
	this->m_ao = ao;
    this->m_timeOffset = 0.0;
   
	this->m_animSeq = new CharacterAnimationSequence(ao);
	this->m_animSeqOrig = new CharacterAnimationSequence(ao);

    zeroVector(m_offset);
    zeroVector(m_orientation);

	this->m_localTime = 0.0;
	setKinematic(false);
	setKinematicBlendTime(1.0);
	this->setHasBlendPose(false);
	this->setFixRoot(false);
	this->setRootKSKD(100, 10);
}

AnimatablePose::~AnimatablePose()
{
	delete this->m_animSeq;
	delete this->m_animSeqOrig;
}


void AnimatablePose::setAnimation(CharacterAnimationSequence* anim)
{
	this->m_animSeq->copy(anim);
	this->m_animSeqOrig->copy(this->m_animSeq);
}

CharacterAnimationSequence* AnimatablePose::getAnimation()
{
	return this->m_animSeq;
}

bool AnimatablePose::loadAnimation(std::ifstream &file)
{
	this->m_animSeq->clear();
	if (this->m_animSeq->loadBVH(file, -1, 99999999) != -1)
	{
		// make a copy for changing the motion
		m_animSeqOrig->clear();
		this->m_animSeqOrig->copy(this->m_animSeq);
		setVector(m_offset, 0, 0, 0);
		setVector(m_orientation, 0, 0, 0);
		return true;
	}
	else
	{
		return false;
	}
}

void AnimatablePose::deleteAnimation()
{
	this->m_animSeq->clear();
	this->m_animSeqOrig->clear();
}

void AnimatablePose::setTimeOffset(double timeOffset)
{
	m_timeOffset = timeOffset;
}

double AnimatablePose::getTimeOffset()
{
	return m_timeOffset;
}

double* AnimatablePose::getOffset()
{
	return &m_offset[0];
}

void AnimatablePose::setOffset(double* offset)
{
	// restore the original animation and offset from there
	this->m_animSeq->clear();
	this->m_animSeq->copy(this->m_animSeqOrig);

	KeyFrame* keyframe = m_animSeq->getKeyFrame(m_animSeq->getStartTime());
	int order = Matrix3x3::XYZ; // GET THE PROPER ORDER FROM THE ARTOBJ
	while (keyframe != NULL)
	{
		switch (order)
		{
			case Matrix3x3::XYZ:
				keyframe->setParam(0, keyframe->getParam(0) + offset[0]);
				keyframe->setParam(1, keyframe->getParam(1) + offset[1]);
				keyframe->setParam(2, keyframe->getParam(2) + offset[2]);
				break;
			case Matrix3x3::XZY:
				keyframe->setParam(0, keyframe->getParam(0) + offset[0]);
				keyframe->setParam(1, keyframe->getParam(1) + offset[2]);
				keyframe->setParam(2, keyframe->getParam(2) + offset[1]);
				break;
			case Matrix3x3::YXZ:
				keyframe->setParam(0, keyframe->getParam(0) + offset[1]);
				keyframe->setParam(1, keyframe->getParam(1) + offset[0]);
				keyframe->setParam(2, keyframe->getParam(2) + offset[2]);
				break;
			case Matrix3x3::YZX:
				keyframe->setParam(0, keyframe->getParam(0) + offset[1]);
				keyframe->setParam(1, keyframe->getParam(1) + offset[2]);
				keyframe->setParam(2, keyframe->getParam(2) + offset[0]);
				break;
			case Matrix3x3::ZXY:
				keyframe->setParam(0, keyframe->getParam(0) + offset[2]);
				keyframe->setParam(1, keyframe->getParam(1) + offset[0]);
				keyframe->setParam(2, keyframe->getParam(2) + offset[1]);
				break;
			case Matrix3x3::ZYX:
				keyframe->setParam(0, keyframe->getParam(0) + offset[2]);
				keyframe->setParam(1, keyframe->getParam(1) + offset[1]);
				keyframe->setParam(2, keyframe->getParam(2) + offset[0]);
				break;
		}

		keyframe = keyframe->getNext();
	}

	VecCopy(m_offset, offset);
}

double* AnimatablePose::getOrientation()
{
	return &m_orientation[0];
}

void AnimatablePose::setOrientation(double* orientation)
{
	// make sure that the first seven parameters are: transX transY transZ quat1 quat2 quat3 quat4
	if (this->m_animSeq->getNumKeyFrames() > 0)
	{
		KeyFrame* startFrame = this->m_animSeq->getKeyFrame(this->m_animSeq->getStartTime());
		if (startFrame->getNumParams() < 7)
		{
			danceInterp::OutputMessage("Key frames only have %d parameters, need 3 translation & 1 quaternion. Orientation not performed.");
			return;
		}
	}

	// restore the original animation and orient from there
	this->m_animSeq->clear();
	this->m_animSeq->copy(this->m_animSeqOrig);

	Vector origOrient;
	VecCopy(origOrient, orientation);
	// convert degrees -> radians
	for (int x = 0; x < 3; x++)
		orientation[x] = orientation[x] * M_PI / 180.0;
	Matrix3x3 matrix;
	VectorObj rotation(orientation[0], orientation[1], orientation[2]);
	matrix.matFromEuler(Matrix3x3::XYZ, rotation);
	Quaternion quat;
	quat.fromMatrix(matrix);

	int numFrames = m_animSeq->getNumKeyFrames();

	KeyFrame* keyframe = m_animSeq->getKeyFrame(m_animSeq->getStartTime());
	int counter = 0; 
	while (keyframe != NULL)
	{
		// obtain the keyframe rotation matrix
		Vector cur;
		cur[0] = keyframe->getParam(3);
		cur[1] = keyframe->getParam(4);
		cur[2] = keyframe->getParam(5);
		VectorObj rotation(cur[0], cur[1], cur[2]);
		Matrix3x3 m;
		m.matFromEuler(Matrix3x3::XYZ, rotation);
		Quaternion q;
		q.fromMatrix(m);

		Quaternion tmp;
		tmp.multiply(&quat, &q);
		tmp.normalize();

		// extract the new rotations
		VectorObj newrotation;
		Matrix3x3 m2;
		tmp.toMatrix(m2);
		m2.matToEuler(Matrix3x3::XYZ, newrotation);
		keyframe->setParam(3, newrotation[0]);
		keyframe->setParam(4, newrotation[1]);
		keyframe->setParam(5, newrotation[2]);

		// orient the translation
		Matrix3x3 matrix;
		quat.toMatrix(matrix);
		VectorObj v(keyframe->getParam(0), keyframe->getParam(1), keyframe->getParam(2));
		VectorObj v2 = matrix * v;
		keyframe->setParam(0, v2[0]);
		keyframe->setParam(1, v2[1]);
		keyframe->setParam(2, v2[2]);

		keyframe = keyframe->getNext();
		counter ++;
	}

	VecCopy(m_orientation, origOrient);
}

void AnimatablePose::setLocalTime(double time)
{
	this->m_localTime = time;
	// get the keyframed pose and set the pose state accordingly
	KeyFrame* kf = this->m_animSeq->getKeyFrame(m_localTime);
	if (kf == NULL)
	{
		return;
	}
	else
	{
		kf->getParams(this->dof);
	}
}

double AnimatablePose::getLocalTime()
{
	return this->m_localTime;
}

bool AnimatablePose::parse(std::ifstream &file, PoseData* pdata)
{
	bool ok = loadAnimation(file);
	if (ok)
	{
		KeyFrame* kf = this->m_animSeq->getKeyFrameByIndex(0);
		if (kf != NULL)
		{
			size = kf->getNumParams();
		}
	}
	return ok;
}

void AnimatablePose::copy(AnimatablePose* pose)
{
	pose->setAnimation(this->getAnimation());
	pose->setTimeOffset(this->getTimeOffset());
	pose->setOffset(this->getOffset());
	pose->setOrientation(this->getOrientation());
	pose->setLocalTime(this->getLocalTime());
	pose->setKinematic(this->isKinematic());
	pose->setFixRoot(this->isFixRoot());
	pose->setRootKSKD(this->m_rootKS, this->m_rootKD);
}

bool AnimatablePose::isKinematic()
{
	return m_isKinematic;
}

void AnimatablePose::setKinematic(bool val)
{
	m_isKinematic = val;
}

void AnimatablePose::setKinematicBlendTime(double time)
{
	m_kinematicBlend = time;
}

double AnimatablePose::getKinematicBlendTime()
{
	return m_kinematicBlend;
}

double AnimatablePose::getDOF(int index, PoseData* pdata)
{
	double state[MAX_STATE];
	m_animSeq->interpolate(getLocalTime(), state);
	return state[index];


/*	m_animSeq->getEndTi
	double temp = Pose::getDOF(index);

	if (this->hasBlendPose())
	{
		if (getLocalTime() < getKinematicBlendTime())
		{
			// linearly blend the poses 
			if (index < 3) // ignore translational components
			{
				Joint* rootJoint = m_ao->getJoint(0);
				int jointType = rootJoint->getJointType();
				switch (jointType)
				{
					case J_FREE:
						return temp;
					case J_PLANAR:
						if (index < 2) // only first two are translational parameters
							return temp;
					default:
						break;
				}
			}

			double blendRatio = getLocalTime() / getKinematicBlendTime();

			temp = blendRatio * temp + (1.0 - blendRatio) * m_blendPoseData[index];
		}
	}
		
	return temp;
*/
}

void AnimatablePose::setBlendPoseData(double* blendPoseData)
{
	for (int x = 0; x < this->getSize(); x++)
		m_blendPoseData[x] = blendPoseData[x];
}

double* AnimatablePose::getBlendPoseData()
{
	return &m_blendPoseData[0];
}

void AnimatablePose::setHasBlendPose(bool val)
{
	this->m_hasBlendPose = val;
}

bool AnimatablePose::hasBlendPose()
{
	return this->m_hasBlendPose;
}

void AnimatablePose::setFixRoot(bool val)
{
	this->m_isFixRoot= val;
}

bool AnimatablePose::isFixRoot()
{
	return this->m_isFixRoot;
}

void AnimatablePose::setRootKSKD(double ks, double kd)
{
	this->m_rootKS = ks;
	this->m_rootKD = kd;
}

void AnimatablePose::getRootKSKD(double& ks, double& kd)
{
	ks = this->m_rootKS;
	kd = this->m_rootKD;
}



