/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin, 
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "PoseWindow.h"

#ifdef WIN32
#include <windows.h>
#endif

#include "opengl.h"
#include "PosePDControllerWindow.h"
#include "PosePDController.h"
#include "ArticulatedObject.h"
#include "Pose.h"
#include "Link.h"
#include "Joint.h"
#include "dance.h"
#include "ViewManager.h"

PoseWindow::PoseWindow(PosePDController* c, ArticulatedObject* orig, int x, int y, int w, int h, char* name) : GlWindow(x, y, w, h, name)
{
	controller = c;

	origAO = orig;
	if (origAO != NULL)
	{
		// copy the topology of the current articulated object
		ao = new ArticulatedObject();
		ao->setName("Posing Skeleton");
		ao->copy(orig);
		dance::AllSimulators->removeAllCallbacks(ao);
	
		copyGeometry(origAO);
		
	}
	else
	{
		ao = NULL;
	}

	poseMode = false;

	if (ao != NULL)
		ao->setZeroState();
	resetCamera();
}

PoseWindow::~PoseWindow()
{
	// remove geometry dependencies if present
	if (ao != NULL)
	{
		DObjectRefList* deps = ao->getDependencies();
		int numDeps = deps->size();
		for (int x = numDeps - 1; x >= 0; x--)
		{
			DObject* object = deps->get(x);
			ao->removeDependency(object);
		}

		DObjectRefList* revdeps = ao->getDependencies();
		int numRevDeps = revdeps->size();
		for (int x = numRevDeps - 1; x >= 0; x--)
		{
			DObject* object = revdeps->get(x);
			ao->removeDependencyReverse(object);
		}

		delete ao;
	}
}

void PoseWindow::copyGeometry(ArticulatedObject* orig)
{
	if (orig == NULL)
		return;

	// copy the geometry 
	int numLinks = orig->getNumLinks();
	for (int x = 0; x < numLinks; x++)
	{
		Link* origLink = orig->getLink(x);
		Link* link = ao->getLink(x);
		if( link && origLink )
		{
			DGeometry* geometry = origLink->getGeometry();
			link->setGeometry(geometry);
			link->setGeometryScale(origLink->getGeometryScale());
			double m[4][4];
			origLink->getInvGeometryTransMat(m);
			link->setInvGeometryTransMat(m);
		}
	}
}

void PoseWindow::setArticulatedObject(ArticulatedObject* orig)
{
	if (ao != NULL)
		delete ao;

	ao = new ArticulatedObject();
	ao->setName("Posing Skeleton");
	ao->copy(orig);

	this->copyGeometry(orig);

	double state[MAX_STATE];
	ao->getState(state);
	ao->setZeroState();
	BoundingBox box;
	ao->calcBoundingBox(&box);	

	setVector(objectCenter, 
				(box.xMax - box.xMin) / 2.0, 
				(box.yMax - box.yMin) / 2.0, 
				(box.zMax - box.zMin) / 2.0);
	resetCamera();
	ao->setState(state);
}

ArticulatedObject* PoseWindow::getArticulatedObject()
{
	return ao;
}


void PoseWindow::resetCamera()
{
	if (ao == NULL)
		return;

	BoundingBox box;
	if (ao != NULL)
		ao->calcBoundingBox(&box);	

//	setVector(objectCenter, 
//				(box.xMax - box.xMin) / 2.0, 
//				(box.yMax - box.yMin) / 2.0, 
//				(box.zMax - box.zMin) / 2.0);

	double xSpan = box.xMax - box.xMin;
	double ySpan = box.yMax - box.yMin;
	double zSpan = box.zMax - box.zMin;


	if (xSpan > ySpan)
	{
		if (xSpan > zSpan)
		{
			objectSize = xSpan;
			largestDim = 0;
		}
		else
		{
			objectSize = zSpan;
			largestDim = 2;
		}
	}
	else
	{
		if (ySpan > zSpan)
		{
			objectSize = ySpan;
			largestDim = 1;
		}
		else
		{
			objectSize = zSpan;
			largestDim = 2;
		}
	}

	// look at the middle of the body of the articulated object
	fov = 45;
	Vector zero = {0.0, 0.0, 0.0};
	if (ao != NULL)
	{
		BoundingBox box;
		ao->calcBoundingBox(&box);

		setVector(objectCenter, 
					(box.xMax + box.xMin) / 2.0, 
					(box.yMax + box.yMin) / 2.0, 
					(box.zMax + box.zMin) / 2.0);
	}
	else
	{
		setVector(objectCenter, 0.0, 0.0, 0.0);
	}
	double dist = objectSize / ( 2 * atan((fov / 2.0)  * M_PI / 180.0));

	// look at the center of the object
	// this is determined by finding the largest dimension and looking at the middle
	Vector lookAtCenter;
	zeroVector(lookAtCenter);
	lookAtCenter[largestDim] += objectSize / 2.0; 
	setVector(camera, lookAtCenter[0] + objectCenter[0], lookAtCenter[1] + objectCenter[1], lookAtCenter[2] + dist + objectCenter[2]);
}

void PoseWindow::initLights()
{
	float position[4] = {0.0f, 2.0f, 8.0f, 1.0};
	float diffuse[4] = {.2f, .2f, .2f, 2.0f};
	float specular[4] = {.1f, .1f, .1f, 1.0f};
	float ambient[4] = {.1f, .1f, .1f, 1.0f};

	glLightfv(GL_LIGHT0, GL_POSITION, position); 
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);

	glEnable(GL_LIGHT0);

	float position2[4] = {0.0f, 100.0f, 100.0f, 1.0f};
	float diffuse2[4] = {.1f, .1f, .1f, 1.0f};
	float specular2[4] = {.1f, .1f, .1f, 1.0f};
	float ambient2[4] = {.1f, .1f, .1f, 1.0f};

	glLightfv(GL_LIGHT1, GL_POSITION, position2); 
	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse2);
	glLightfv(GL_LIGHT1, GL_SPECULAR, specular2);
	glLightfv(GL_LIGHT1, GL_AMBIENT, ambient2);

	glEnable(GL_LIGHT1);
}

void PoseWindow::setPose(Pose* pose)
{
	if (pose == NULL)
		return;

	if (ao == NULL)
		return;

	// set the state of the pose preview art obj
	double* state = new double[ao->getStateSize()];

	for (int x = 0; x < ao->getStateSize(); x++)
	{
		state[x] = pose->getDOF(x);
//		danceInterp::OutputMessage("State %d] %6.2f", x, state[x]);
	}

	// eliminate any global translation
	Joint* rootJoint = ao->getJoint(0);
	// added 5/7/06, vector@cs.ucla.edu - crashing on simple two-link test with root under pose control
	if( rootJoint )
	{
		int jointType = rootJoint->getJointType();
		if (jointType == J_FREE)
		{
			state[0] = state[1] = state[2] = 0.0;
		}
		else if (jointType == J_PLANAR)
		{
			state[0] = state[1] = 0.0;
		}
		else
		{
		}
	}
	else
	{
		danceInterp::OutputMessage( "Error: PoseWindow::setPose(): ArticulatedObject has no root joint." );
	}

	ao->setState(state);

	delete state;
	
	// make sure that the geometry has been copied
	this->copyGeometry(origAO);

//	resetCamera();
	this->redraw();


}

void PoseWindow::draw()
{
	float bcolor[4];
	if (dance::AllViews->getViewFocus() != NULL)
	{
		dance::AllViews->getViewFocus()->getBackgroundColor(bcolor);
	}
	else
	{
		bcolor[0] = bcolor[1] = bcolor[2] = bcolor[3] = 0.0;
	}
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(bcolor[0], bcolor[1], bcolor[2], bcolor[3]);
	initLights();

	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glEnable(GL_LIGHTING);

	// split the screen
	glViewport(0, 0, w(), h());
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluPerspective(fov, w() / h(), 0, 10);

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	gluLookAt(camera[0], camera[1], camera[2], objectCenter[0], objectCenter[1], objectCenter[2], 0, 1, 0);

	HMatrix arcrot;
	arcBall.value(arcrot);
	glMultMatrixf((float *)arcrot);

	if (ao != NULL)
		ao->output(LDISPLAY_SOLID);

	if (arcBall.isDrag())
		arcBall.draw();

	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();

	// check the pose dots
	int numPoseDots = controller->getNumPoseDots();

	if (numPoseDots > 0)
	{
		glViewport(0, 0, w(), h());
		glMatrixMode(GL_PROJECTION);
		glPushMatrix();
		glLoadIdentity();
		glOrtho(-1.0,1.0,-1.0,1.0,-1.0,100.0);

		glMatrixMode(GL_MODELVIEW);
		glPushMatrix();
		glLoadIdentity();
		
		glPushAttrib(GL_LIGHTING_BIT | GL_COLOR_BUFFER_BIT);
		glDisable(GL_LIGHTING);

		float dist = .8f;
		for (int x = 0; x < 4; x++)
		{
			Pose* poseDot = controller->getPoseDot(x);
			if (poseDot != NULL)
			{
				glPushMatrix();
				switch (x)
				{
				case 0:
					glTranslatef(0.0f, dist, 0.0f);
					break;
				case 1:
					glTranslatef(dist, 0.0f, 0.0f);
					break;
				case 2:
					glTranslatef(0.0f, -dist, 0.0f);
					break;
				case 3:
					glTranslatef(-dist, 0.0f, 0.0f);
				default:
					break;
				}
				glColor3f(1.0f, 1.0f, 0.0f);
				glScalef(.005f, .005f, .005f);
				glBegin(GL_LINE_LOOP);
				for (int c = 0; c < 360; c++)   
				{
					GLdouble degInRad = c * M_PI / 180.0;
					glVertex2d(cos(degInRad) * 20, sin(degInRad) * 20);
				}
				glEnd();
				glPopMatrix();
			}
		}
		glPopAttrib();

		glPopMatrix();
		glMatrixMode(GL_PROJECTION);
		glPopMatrix();
		glMatrixMode(GL_MODELVIEW);

		if (this->isPoseMode())
		{
			glMatrixMode(GL_PROJECTION);
			glPushMatrix();
			glLoadIdentity();
			glOrtho(0.0, (double) w(), (double) h(), 0.0, -1.0, 100.0);
	
			glPushAttrib(GL_LIGHTING_BIT | GL_COLOR_BUFFER_BIT | GL_POINT_BIT);
			glDisable(GL_LIGHTING);
			glPointSize(10.0);
			glMatrixMode(GL_MODELVIEW);
			glPushMatrix();
			glLoadIdentity();
			glColor3f(1.0f, 1.0f, 0.0f);
			glBegin(GL_POINTS);
			glVertex2d(lastX, lastY);
			glEnd();

			glPopMatrix();

			glMatrixMode(GL_PROJECTION);
			glPopMatrix();

			glPopAttrib();

		}
		

	}
}

int PoseWindow::handle(int event)
{
	float width;
	float height;
	HVect arccoords;
	float mousex;
	float mousey;
	int button;

	if (ao == NULL)
		return GlWindow::handle(event);

	if (!poseMode) // cameral mode, events affect camera movement
	{
		switch (event)
		{
			case fltk::KEY:
				switch (fltk::event_key())
				{
					case fltk::SpaceKey:
						arcBall.init();
						arcBall.update();
						this->redraw();

						return 1;
						break;
					default:
						break;
				}
				break;

			case fltk::PUSH:
				mousex = (float) fltk::event_x();
				mousey = (float) fltk::event_y();

				if (fltk::event_button() == 3)
				{
					arcBall.init();
					arcBall.update();
					this->redraw();
					return 1;
				}
		
				arcBall.useSet(BodyAxes);

				width = (float) this->w();
				height = (float) this->h();
				arccoords.x = 2.0f * mousex / width - 1.0f;
				arccoords.y = -2.0f * mousey / height + 1.0f;
				arcBall.mouse(arccoords);
				arcBall.update();
				arcBall.beginDrag();
				this->redraw();
				return 1;
				break;

			case fltk::RELEASE:
				arcBall.endDrag();

				this->redraw();
				return 1;
				break;

			case fltk::MOVE:
			case fltk::DRAG:
				button = fltk::event_button();
				if (button == 1 && arcBall.isDrag())
				{
					mousex = (float) fltk::event_x();
					mousey = (float) fltk::event_y();

					width = (float) this->w();
					height = (float) this->h();
					arccoords.x = 2.0f * mousex / width - 1.0f;
					arccoords.y = -2.0f * mousey / height + 1.0f;
					arcBall.mouse(arccoords);
					arcBall.update();
					this->redraw();
					return 1;
				}
				break;
			case fltk::FOCUS:
				break;
			case fltk::ENTER:
				break;
			default:
				mousex = (float) fltk::event_x();
				mousey = (float) fltk::event_y();
				break;
		}
	}
	else // pose mode, interpolate poses
	{
		double interpolation;
		Pose* pose1;
		Pose* pose2;
		Pose* finalPose;
		double quadrantMinX;
		double quadrantMaxX;
		double quadrantMinY;
		double quadrantMaxY;
		double leftright;
		double updown;
		int quadrant = 0;
		double quadrantWidth = w() / 4.0;
		double quadrantHeight = h() / 4.0;

		switch (event)
		{
			case fltk::KEY:
				break;

			case fltk::PUSH:
			case fltk::DRAG:

				mousex = (float) fltk::event_x();
				mousey = (float) fltk::event_y();

				if (mousex < 0)
					mousex = 0;
				if (mousex > w())
					mousex = w();
				if (mousey < 0)
					mousey = 0;
				if (mousey > h())
					mousey = h();
				lastX = mousex;
				lastY = mousey;

				// determine which quadrant we have clicked on 

				if (mousex < w() / 2.0)
				{
					if (mousey < h() / 2.0)
					{
						quadrant = 4;
						quadrantMinX = 0;
						quadrantMaxX = w() / 2;
						quadrantMinY = 0;
						quadrantMaxY = h() / 2;

					}
					else
					{
						quadrant = 3;
						quadrantMinX = 0;
						quadrantMaxX = w() / 2;
						quadrantMinY = h() / 2;
						quadrantMaxY = h();

					}
				}
				else
				{
					if (mousey < h() / 2.0)
					{
						quadrant = 1;
						quadrantMinX = w() / 2;
						quadrantMaxX = w();
						quadrantMinY = 0;
						quadrantMaxY = h() / 2;
					}
					else
					{
						quadrant = 2;
						quadrantMinX = w() / 2;
						quadrantMaxX = w();
						quadrantMinY = h() / 2;
						quadrantMaxY = h();

					}
				}




				finalPose = new Pose(this->getArticulatedObject()->getStateSize());
				switch (quadrant)
				{
				case 1:
					pose1 = controller->getPoseDot(0);
					pose2 = controller->getPoseDot(1);
					leftright = 1.0 - ((mousex - quadrantMinX) / quadrantWidth);
					updown = 1.0 - ((mousey - quadrantMinY) / quadrantHeight);
					interpolation = (leftright + updown) * .5;
					if (interpolation < 0.0)
						interpolation = 0.0;
					else if (interpolation > 1.0)
						interpolation = 1.0;
					Pose::interpolate(this->getArticulatedObject(), pose1, interpolation, pose2, finalPose);
					break;
				case 2:
					pose1 = controller->getPoseDot(1);
					pose2 = controller->getPoseDot(2);
					leftright = ((mousex - quadrantMinX) / quadrantWidth);
					updown = 1.0 - ((mousey - quadrantMinY) / quadrantHeight);
					interpolation = (leftright + updown) * .5;
					if (interpolation < 0.0)
						interpolation = 0.0;
					else if (interpolation > 1.0)
						interpolation = 1.0;
					Pose::interpolate(this->getArticulatedObject(), pose1, interpolation, pose2, finalPose);
					break;
				case 3:
					pose1 = controller->getPoseDot(2);
					pose2 = controller->getPoseDot(3);
					leftright = ((mousex - quadrantMinX) / quadrantWidth);
					updown = ((mousey - quadrantMinY) / quadrantHeight);
					interpolation = (leftright + updown) * .5;
					if (interpolation < 0.0)
						interpolation = 0.0;
					else if (interpolation > 1.0)
						interpolation = 1.0;
					Pose::interpolate(this->getArticulatedObject(), pose1, interpolation, pose2, finalPose);
					break;
				case 4:
					pose1 = controller->getPoseDot(3);
					pose2 = controller->getPoseDot(0);
					leftright = 1.0 - ((mousex - quadrantMinX) / quadrantWidth);
					updown = ((mousey - quadrantMinY) / quadrantHeight);
					interpolation = (leftright + updown) * .5;
					if (interpolation < 0.0)
						interpolation = 0.0;
					else if (interpolation > 1.0)
						interpolation = 1.0;
					Pose::interpolate(this->getArticulatedObject(), pose1, interpolation, pose2, finalPose);
					break;
				default:
					break;
				}

				this->setPose(finalPose);
				controller->setTargetPose(finalPose);
				//danceInterp::OutputMessage("Mouse (x, y): %f, %f", mousex, mousey);

				delete finalPose;
				return 1;

				break;

			case fltk::RELEASE:
				break;

			case fltk::MOVE:
			case fltk::FOCUS:
				break;
			case fltk::ENTER:
				break;
			default:
				mousex = (float) fltk::event_x();
				mousey = (float) fltk::event_y();
				break;
		}
		return 1;
	}

	return GlWindow::handle(event);
}

void PoseWindow::setPoseMode(bool val)
{
	poseMode = val;
}

bool PoseWindow::isPoseMode()
{
	return poseMode;
}

