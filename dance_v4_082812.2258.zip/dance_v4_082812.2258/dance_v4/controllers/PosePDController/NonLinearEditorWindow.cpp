#include "NonLinearEditorWindow.h"
#include <fltk/Group.h>
#include <fltk/Button.h>
#include <iostream>
#include <vector>
#include "PoseBlock.h"
#include "PosePDControllerWindow.h"
#include "PosePDController.h"
#include "AnimatablePose.h"
#include "ScriptablePose.h"

using namespace fltk;

NonLinearEditorWindow::NonLinearEditorWindow(PosePDControllerWindow* posePDWin, int w, int h, char* name) :
Window(w, h, name)
{
	posePDWindow = posePDWin;

	this->begin();

	Group* topGroup = new Group(10, 0, w - 10, 30, "Controllers");
	topGroup->begin();

		buttonAddTrack = new Button(0, 0, 80, 20, "Add Track");
		buttonAddTrack->callback(AddTrackCB, this);

		buttonDeleteTrack = new Button(80, 0, 80, 20, "Delete Track");
		buttonDeleteTrack->callback(DeleteTrackCB, this);
  
        buttonTrackUp = new Button(160, 0, 20, 20, "@90>");
        buttonTrackUp->callback(MoveTrackUpCB, this);
        
        buttonTrackDown = new Button(180, 0, 20, 20, "@90<");
        buttonTrackDown->callback(MoveTrackDownCB, this);	
  
        buttonAddBlock = new Button(220, 0, 80, 20, "Add Block");
		buttonAddBlock->callback(AddBlockCB, this);

		buttonDeleteBlock = new Button(300, 0, 80, 20, "Delete Block");
		buttonDeleteBlock->callback(DeleteBlockCB, this);

		buttonBlockLeft = new Button(390, 0, 20, 20, "@<");
		buttonBlockLeft->callback(MoveBlockLeftCB, this);

		buttonBlockRight = new Button(410, 0, 20, 20, "@>");
		buttonBlockRight->callback(MoveBlockRightCB, this);

		buttonBlockUp = new Button(430, 0, 20, 20, "@90>");
		buttonBlockUp->callback(MoveBlockUpCB, this);

		buttonBlockDown = new Button(450, 0, 20, 20, "@90<");
		buttonBlockDown->callback(MoveBlockDownCB, this);
		
		Group* topSizer = new Group(470, 0, 10, 0);

	topGroup->end();
	topGroup->resizable(topSizer);
 
	Group* bottomGroup = new Group(0, 30, w - 10, h - 40);
	bottomGroup->begin();

		Group* leftGroup = new Group(0, 0, w - 210, h - 30);
		leftGroup->begin();

			nleWidget = new EditorWidget(0, 0, w - 230, h - 40, "");
			nleWidget->box(fltk::BORDER_BOX);

		leftGroup->end();
		leftGroup->resizable(nleWidget);

		Group* rightGroup = new Group(w - 210, 0, 200, h - 40, "Controller Info");
		rightGroup->box(fltk::BORDER_BOX);
		rightGroup->begin();

            inputTrackName = new Input(80, 10, 110, 20, "Track Name");
            inputTrackName->callback(changeTrackNameCB, this);
                
            inputBlockName = new Input(80, 35, 110, 20, "Block Name");
            inputBlockName->callback(changeBlockNameCB, this);
        
            inputBeginTime = new FloatInput(80, 60, 90, 20, "Begin Time");
            inputBeginTime->callback(changeStartTimeCB, this);
        
            inputEndTime = new FloatInput(80, 85, 90, 20, "End Time");
            inputEndTime->callback(changeEndTimeCB, this);

            Group* rightSizer = new Group(80, 110, 90, 20);
      
		rightGroup->end();
		rightGroup->resizable(rightSizer);

	bottomGroup->end();
	bottomGroup->resizable(leftGroup);

	this->end();

	this->resizable(bottomGroup);

	updateGUI();
}

int NonLinearEditorWindow::handle(int event)
{
	switch (event)
	{
		case fltk::KEY:
			{
				switch (fltk::event_key())
				{
				case fltk::DeleteKey:
					DeleteBlockCB(buttonDeleteBlock, this);
					break;
				default:
					break;
				}
			}
			break;
		default:
			break;
	}

	return  Window::handle(event);
}

void NonLinearEditorWindow::show()
{
    updateGUI();
    
    Window::show();   
}
      
void NonLinearEditorWindow::draw()
{
    NonLinearEditorModel* model = nleWidget->getModel();
    if (model)
    {
        if (model->isModelChanged())
        {
            updateGUI();
            model->setModelChanged(false);
        }
    }
    
    Window::draw();   
}

EditorWidget* NonLinearEditorWindow::getEditorWidget()
{
	return nleWidget;
}

void NonLinearEditorWindow::updateGUI()
{
	NonLinearEditorModel* model = nleWidget->getModel();
	if (!model)
		return;
 
	bool found = false;
	// activate the inputs based on the selected block
    Track* track = this->getSelectedTrack();
    if (track)
    {
        std::string trackName = track->getName();
        inputTrackName->value(trackName.c_str());
        inputTrackName->activate();
        
        buttonAddTrack->activate();        
        buttonDeleteTrack->activate();
        
        if (model->getTrackIndex(track) > 0)
            buttonTrackUp->activate();
        else
            buttonTrackUp->deactivate();
            
        if (model->getTrackIndex(track) < model->getNumTracks() - 1)
            buttonTrackDown->activate();
        else
            buttonTrackDown->deactivate();
        
        
    }
    else
    {
        inputTrackName->value("");
        inputTrackName->deactivate();
        
        buttonAddTrack->activate();        
        buttonDeleteTrack->deactivate();
        
        buttonTrackUp->deactivate();
        buttonTrackDown->deactivate();
    }
        
	Block* block = this->getSelectedBlock();
	if (block && block->isSelected())
	{     
		std::string name = block->getName();
		double startTime = block->getStartTime();
		double endTime = block->getEndTime();
		inputBlockName->value(name.c_str());
		inputBeginTime->value(startTime);
		inputEndTime->value(endTime);
        inputBlockName->activate();
		inputBeginTime->activate();
		inputEndTime->activate();
		buttonDeleteBlock->activate();

		buttonBlockLeft->activate();
		buttonBlockRight->activate();
		buttonBlockUp->activate();
		buttonBlockDown->activate();
		
		// disable the block move left if the block 
		// is the first block in the track
		if (block->getTrack()->getFirstBlock() == block)
		{
			buttonBlockLeft->deactivate();
		}

		// disable the block move right if the block 
		// is the last block in the track
		if (block->getTrack()->getLastBlock() == block)
		{
			buttonBlockRight->deactivate();
		}

		// disable the block move up if the block 
		// is on the first track
		if (block->getTrack() == model->getTrack(0))
		{
			buttonBlockUp->deactivate();
		}

		// block move down is always valid - if
		// no tracks exist below, one will be 
		// automatically created

	}
	else
	{
        inputBlockName->value("");
        inputBlockName->deactivate();
        inputBeginTime->value(0.0);
		inputBeginTime->deactivate();
        inputEndTime->value(0.0);
        inputEndTime->deactivate();
		buttonDeleteBlock->deactivate();
		if (model->getNumTracks() == 0)
		{
			this->buttonAddBlock->deactivate();
		}
		else
		{
			this->buttonAddBlock->activate();
		}

		buttonBlockLeft->deactivate();
		buttonBlockRight->deactivate();
		buttonBlockUp->deactivate();
		buttonBlockDown->deactivate();


	}
 

}

void NonLinearEditorWindow::changeStartTimeCB(fltk::Widget* widget, void* data)
{
	NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;

	Block* block = win->getSelectedBlock();
	if (block)
	{
		block->setStartTime(win->inputBeginTime->fvalue());
	}
	win->updateGUI();
	win->redraw();
}

void NonLinearEditorWindow::changeEndTimeCB(fltk::Widget* widget, void* data)
{
	NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;

	Block* block = win->getSelectedBlock();
	if (block)
	{
		block->setEndTime(win->inputEndTime->fvalue());
	}
	win->updateGUI();
	win->redraw();
}

void NonLinearEditorWindow::changeTrackNameCB(fltk::Widget* widget, void* data)
{
    NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;

    Track* track = win->getSelectedTrack();
    if (track)
    {
        track->setName(win->inputTrackName->value());
    }
    
    win->updateGUI();
    win->redraw();
}


void NonLinearEditorWindow::changeBlockNameCB(fltk::Widget* widget, void* data)
{
	NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;

	Block* block = win->getSelectedBlock();
	if (block)
	{
        block->setName(win->inputBlockName->value());
	}
	win->updateGUI();
	win->redraw();
}

void NonLinearEditorWindow::AddTrackCB(fltk::Widget* widget, void* data)
{
	NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;

	std::string trackName = win->nleWidget->getModel()->getUniqueTrackName();

	Track* track = new Track();
	track->setName(trackName);
	win->nleWidget->getModel()->addTrack(track);
	// select only this track
	for (int t  = 0; t < win->nleWidget->getModel()->getNumTracks(); t++)
	{
		Track* otherTrack = win->nleWidget->getModel()->getTrack(t);
		if (otherTrack != track)
			otherTrack->setSelected(false);
		else
			otherTrack->setSelected(true);
	}

	win->redraw();
}

void NonLinearEditorWindow::DeleteTrackCB(fltk::Widget* widget, void* data)
{
	NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;

    NonLinearEditorModel* model = win->nleWidget->getModel();

    Track* track = win->getSelectedTrack();
    if (!track)
        return;
    
    int trackNum = model->getTrackIndex(track);            
    model->removeTrack(track);
    
    // select another track
    if (model->getNumTracks() > 0)
    {
        if (trackNum == model->getNumTracks())
            model->getTrack(model->getNumTracks() - 1)->setSelected(true);
        else
            model->getTrack(trackNum)->setSelected(true);
    }
	
	win->redraw();
}

void NonLinearEditorWindow::MoveTrackUpCB(fltk::Widget* widget, void* data)
{
    NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;
    
    for (int t = 0; t < win->nleWidget->getModel()->getNumTracks(); t++)
    {        
        Track* track = win->nleWidget->getModel()->getTrack(t);
        if (track == win->getSelectedTrack())
        {
            if (t > 0)
            {
                win->nleWidget->getModel()->switchTracks(t, t - 1);
                break;
            }
        }
        
    }
    
    win->redraw();    
}

void NonLinearEditorWindow::MoveTrackDownCB(fltk::Widget* widget, void* data)
{
    NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;
    
    for (int t = 0; t < win->nleWidget->getModel()->getNumTracks(); t++)
    {        
        Track* track = win->nleWidget->getModel()->getTrack(t);
        if (track == win->getSelectedTrack())
        {
            if (t < win->nleWidget->getModel()->getNumTracks() - 1)
            {
                win->nleWidget->getModel()->switchTracks(t, t + 1);
                break;
            }
        }
        
    }
    
    win->redraw();    
    
}


void NonLinearEditorWindow::AddBlockCB(fltk::Widget* widget, void* data)
{
	NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;

	// find the selected track
	for (int t = 0; t < win->nleWidget->getModel()->getNumTracks(); t++)
	{
		Track* track = win->nleWidget->getModel()->getTrack(t);
		if (track->isSelected())
		{
			int selectedIndex = win->posePDWindow->controller->getDesiredPoseIndex();
			PoseBlock* poseBlock = NULL;
			PoseBlockParameters* poseParameters = NULL;
			if (selectedIndex >= 0)
			{
				Pose* p = win->posePDWindow->controller->getSelectedPose(selectedIndex);			

				AnimatablePose* animPose = dynamic_cast<AnimatablePose*>(p);
				ScriptablePose* scriptPose = dynamic_cast<ScriptablePose*>(p);

				if (animPose)
				{
					AnimatablePoseBlock* animPoseBlock = new AnimatablePoseBlock();
					poseParameters = new AnimatablePoseBlockParameters();
					poseBlock = animPoseBlock;
				}
				else if (scriptPose)
				{
					ScriptablePoseBlock* scriptPoseBlock = new ScriptablePoseBlock();
					poseParameters = new ScriptablePoseBlockParameters();				
					poseBlock = scriptPoseBlock;
				}
				else
				{
					// not scriptable or animatable - regular pose
					PoseBlock* normalPoseBlock = new PoseBlock();
					poseParameters = new PoseBlockParameters();
					poseBlock = normalPoseBlock;
				}

				poseBlock->setName(p->getName());
				poseBlock->setPose(p);

				poseBlock->setStartTime(track->getLastBlockTime());
				poseBlock->setEndTime(poseBlock->getStartTime() + 1.0);

				poseParameters->setGlobalKS(win->posePDWindow->controller->getKS());
				poseParameters->setGlobalKD(win->posePDWindow->controller->getKD());
				poseParameters->setUseCriticalDamping(win->posePDWindow->controller->isCriticallyDamped());
				poseBlock->setPoseBlockParameters(poseParameters);
				track->addBlock(poseBlock);
			}
			
		}
	}
	win->redraw();
}

void NonLinearEditorWindow::DeleteBlockCB(fltk::Widget* widget, void* data)
{
	NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;

	// find and remove the selected blocks
	std::vector<Block*> blocksToDelete;
	for (int t = 0; t < win->nleWidget->getModel()->getNumTracks(); t++)
	{
		Track* track = win->nleWidget->getModel()->getTrack(t);
		for (int b = 0; b < track->getNumBlocks(); b++)
		{
			Block* block = track->getBlock(b);
			if (block->isSelected())
			{
				blocksToDelete.push_back(block);
			}
		}
	}

	for (int x = 0; x < blocksToDelete.size(); x++)
	{
		Track* track = blocksToDelete[x]->getTrack();
		track->removeBlock(blocksToDelete[x]);
	}

	win->redraw();

}

Block* NonLinearEditorWindow::getSelectedBlock()
{
	NonLinearEditorModel* model = nleWidget->getModel();
	if (!model)
		return NULL;

	// activate the inputs based on the selected block
	for (int t = 0; t < model->getNumTracks(); t++)
	{
		Track* track = model->getTrack(t);
		for (int b = 0; b < track->getNumBlocks(); b++)
		{
			Block* curBlock = track->getBlock(b);
			if (curBlock->isSelected())
			{
				return curBlock;
			}
		}
	}
	return NULL;
}

Track* NonLinearEditorWindow::getSelectedTrack()
{
    NonLinearEditorModel* model = nleWidget->getModel();
    if (!model)
        return NULL;

    // activate the inputs based on the selected block
    for (int t = 0; t < model->getNumTracks(); t++)
    {
        Track* track = model->getTrack(t);
        if (track->isSelected())
            return track;
    }
    return NULL;
}


void NonLinearEditorWindow::MoveBlockLeftCB(fltk::Widget* widget, void* data)
{
	NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;

	// switch the block with the block to the left
	Block* block = win->getSelectedBlock();
	if (block)
	{
		Track* track = block->getTrack();
		Block* prevBlock = track->getPrevBlock(block);
		if (prevBlock)
		{
			double startTime1 = prevBlock->getStartTime();
			double endTime1 = prevBlock->getEndTime();
			double startTime2 = block->getStartTime();
			double endTime2 = block->getEndTime();

			block->setStartTime(startTime1);
			block->setEndTime(startTime1 + (endTime2 - startTime2));
			prevBlock->setStartTime(block->getEndTime());
			prevBlock->setEndTime(block->getEndTime() + (endTime1 - startTime1));
		}
	}

	win->redraw();
}

void NonLinearEditorWindow::MoveBlockRightCB(fltk::Widget* widget, void* data)
{	
	NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;

	// switch the block with the block to the right
	Block* block = win->getSelectedBlock();
	if (block)
	{
		Track* track = block->getTrack();
		Block* nextBlock = track->getNextBlock(block);
		if (nextBlock)
		{
			double startTime1 = nextBlock->getStartTime();
			double endTime1 = nextBlock->getEndTime();
			double startTime2 = block->getStartTime();
			double endTime2 = block->getEndTime();

			nextBlock->setStartTime(startTime2);
			nextBlock->setEndTime(startTime2 + (endTime1 - startTime1));
			block->setStartTime(nextBlock->getEndTime());
			block->setEndTime(nextBlock->getEndTime() + (endTime2 - startTime2));
		}
	}

	win->redraw();
}

void NonLinearEditorWindow::MoveBlockUpCB(fltk::Widget* widget, void* data)
{
	NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;

	Block* block = win->getSelectedBlock();
	Track* track =  block->getTrack();

	NonLinearEditorModel* model = win->nleWidget->getModel();

	Track* prevTrack = NULL;

	for (int t = 0; t < model->getNumTracks(); t++)
	{
		Track* curTrack = model->getTrack(t);
		if (curTrack == track)
			break;

		prevTrack = curTrack;
	}

	if (prevTrack != NULL)
	{
		track->releaseBlock(block);
		prevTrack->addBlock(block);
		prevTrack->fitBlocks();
	}

	win->redraw();
}

void NonLinearEditorWindow::MoveBlockDownCB(fltk::Widget* widget, void* data)
{
	NonLinearEditorWindow* win = (NonLinearEditorWindow*) data;

	Block* block = win->getSelectedBlock();
	Track* track =  block->getTrack();

	NonLinearEditorModel* model = win->nleWidget->getModel();

	Track* nextTrack = NULL;

	bool getNext = false;
	for (int t = 0; t < model->getNumTracks(); t++)
	{
		Track* curTrack = model->getTrack(t);
		if (getNext)
		{
			nextTrack = curTrack;
			break;
		}
		if (curTrack == track)
		{
			getNext = true;
		}
	}

	if (nextTrack == NULL)
	{
		nextTrack = new Track();
		nextTrack->setName(model->getUniqueTrackName());
		model->addTrack(nextTrack);
	}

	if (nextTrack != NULL)
	{
		track->releaseBlock(block);
		nextTrack->addBlock(block);
		nextTrack->fitBlocks();
	}

	win->redraw();
}
