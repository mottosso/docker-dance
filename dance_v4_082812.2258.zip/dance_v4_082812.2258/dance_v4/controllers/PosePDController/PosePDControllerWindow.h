/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _POSEPDCONTROLLERWINDOW_H
#define _POSEPDCONTROLLERWINDOW_H

#include <fltk/Window.h>
#include <fltk/ScrollGroup.h>
#include <fltk/Browser.h>
#include <fltk/Button.h>
#include <fltk/Choice.h>
#include <fltk/Output.h>
#include <fltk/CheckButton.h>
#include <fltk/GlWindow.h>
#include <fltk/ValueSlider.h>
#include <fltk/ThumbWheel.h>
#include "NonLinearEditorWindow.h"
#include "Nle.h"
#include "PoseWindow.h"

class PosePDController;

class PosePDControllerWindow : public fltk::ScrollGroup
{
public:
	PosePDControllerWindow (PosePDController* c, int x, int y, int width, int height, const char* name);
	~PosePDControllerWindow();

	void show();

	void updateGUI();

	void setStaticPoseControls(bool val);
	void setDynamicPoseControls(bool val);
	void setScriptablePoseControls(bool val);

	Pose* loadPose(char* name, ArticulatedObject* ao);

	static void PoseSelectCB(fltk::Widget *w, void *data);
	static void BackgroundPoseSelectCB(fltk::Widget *w, void *data);
	static void LoadPoseCB(fltk::Widget *w, void *data);
	static void LoadBackgroundPoseCB(fltk::Widget *w, void *data);
	static void LoadPoseCurrentCB(fltk::Widget *w, void *data);
	static void RemovePoseCB(Widget *w, void *data);
	static void RemoveBackgroundPoseCB(Widget *w, void *data);
	static void StrengthCB(fltk::Widget *w, void *data);
	static void DampingCB(fltk::Widget *w, void *data);
	static void InputStrengthCB(fltk::Widget *w, void *data);
	static void InputDampingCB(fltk::Widget *w, void *data);
	static void ResetAnimPoseOffsetCB(fltk::Widget *w, void *data);
	static void UseAutonomousControlCB(fltk::Widget *w, void *data);
	static void PoseDotCB(Widget *w, void *data);
	static void ClearPoseDots(Widget *w, void *data);
	static void InterpolateCB(Widget *w, void *data);
	static void SliderCB(fltk::Widget *w, void *data);
	static void SelectAOCB(fltk::Widget* widget, void* data);
	static void MaxTorqueCB(fltk::Widget *w, void *data);
	static void MaxVelocityCB(fltk::Widget* w, void* data);
	static void SetSkeletonToPoseCB(Widget *w, void *data);
	static void JointLimitsCB(Widget *w, void *data);
	static void CriticalDampingCB(fltk::Widget* widget, void* data);
	static void TotalInertiaCB( fltk::Widget* widget, void* data );
	static void DriveTypeCB( fltk::Widget* widget, void* data );
	static void PreviewPoseCB(Widget *w, void *data);
	static void AnimationPreviewCB(Widget *w, void *data);
	static void FixRootCB(Widget *w, void *data);
	static void RootKSKDCB(Widget *w, void *data);
	static void ReloadScriptCB(Widget *w, void *data);
	static void ReloadBackgroundScriptCB(Widget *w, void *data);
	static void KinematicCB(Widget *w, void *data);
	static void UseControlEventsCB(fltk::Widget *w, void *data);

	PosePDController* controller;

	fltk::Choice* choiceAO;
	fltk::Browser* browserPoses;
	fltk::Browser* browserBackgroundPoses;
	fltk::Button* buttonLoadPose;
	fltk::Button* buttonLoadPoseCurrent;
	fltk::Button* buttonRemovePose;
	fltk::Button* buttonLoadBackgroundPose;
	fltk::Button* buttonRemoveBackgroundPose;
	fltk::Button* buttonReloadBackgroundPose;
	fltk::FloatInput* inputStrength;
	fltk::FloatInput* inputDamping;
	fltk::ThumbWheel* wheelStrength;
	fltk::ThumbWheel* wheelDamping;
	fltk::CheckButton* checkAutonomousControl;
	fltk::CheckButton* checkJointLimits;
	fltk::CheckButton* checkCriticallyDamped;
	fltk::CheckButton* checkTotalInertia;
	fltk::Choice* choiceDriveType;
	fltk::CheckButton* checkUseControlEvents;
	
	fltk::FloatInput* inputMaxTorque;
	fltk::FloatInput* inputMaxVelocity;
	fltk::Button* buttonResetOffset;
	fltk::Button* buttonSetSkeletonToPose;

	PoseWindow* windowPose;

	// static pose GUI
	fltk::Group* groupStaticPose;
	fltk::Button* buttonPoseDot[4];
	fltk::Button* buttonClearPoseDots;
	fltk::CheckButton* checkPoseMode;

	// animatable pose GUI
	fltk::Group* groupAnimatablePose;
	fltk::FloatInput* outputClipLength;
	fltk::FloatInput* outputCurrentClipTime;
	fltk::FloatInput* inputOffset;
	fltk::CheckButton* checkFixRoot;
	fltk::FloatInput* inputRootKS;
	fltk::FloatInput* inputRootKD;
	fltk::ValueSlider* sliderAnimation;
	fltk::CheckButton* checkKinematic;

	// scriptable pose GUI
	fltk::Group* groupScriptablePose;
	fltk::Button* buttonReloadScript;
	fltk::Output* outputScript;

	NonLinearEditorWindow* windowNLE;
	NonLinearEditorModel* nleEditor;
};
#endif
