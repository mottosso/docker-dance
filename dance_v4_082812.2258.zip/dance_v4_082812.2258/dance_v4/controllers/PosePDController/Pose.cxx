/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "Pose.h"

#include <string>
#include <stdlib.h>
#include "danceInterp.h"
#include "ArticulatedObject.h"
#include "Joint.h"
#include "Quaternion.h"
#include "PoseData.h"

using namespace std;

Pose::Pose(int s)
: name( "unknown" )
{
	size = s;
	dof = new double[size];
	ks = new double[size];
	kd = new double[size];
	//defaultDOF = new double[size];
	defaultKs = new bool[size];
	defaultKd = new bool[size];
	dofInUse = new bool[size];
	dofParameter = new int[size];

	defaultKsVal = 0.0;
	defaultKdVal = 0.0;

	for (int x = 0; x < size; x++)
	{
		this->setDOF(x, 0.0);
		this->setKs(x, defaultKsVal);
		this->setKd(x, defaultKdVal);
		this->setDefaultKs(x, false);
		this->setDefaultKd(x, false);
		this->setDOFInUse(x, true);
		this->setDOFParameter(x, 0);
	}
	setStartTime(0) ;
	setTransTime(-100) ;
}

Pose::~Pose()
{
	delete [] dof;
	delete [] ks;
	delete [] kd;
	delete [] dofInUse;
	delete [] dofParameter;
	delete [] defaultKs;
	delete [] defaultKd;

}

void Pose::setName(const std::string& n)
{
	name = n;
}

const std::string& Pose::getName( void )
{
	return name;
}

void Pose::setFileName(const std::string& name)
{
	filename = name;
}

const std::string& Pose::getFileName( void )
{
	return filename;
}

bool Pose::parse(std::ifstream &file, PoseData* pdata)
{
	// check to make sure we have properly opened the file
	if (!file.good())
	{
		return false;
	}

	bool isKsKd = false;
	int indexDOF = 0;
	int indexKs = 0;
	int indexKd = 0;
	char line[4096];
	while(!file.eof() && file.good())
	{
		file.getline(line, 4096, '\n');
		string str = line;
		int curPos = 0;
		int spacePos;

		if (str.size() == 0) // ignore blank lines
			continue;
		if (str.find_first_of('#') == 0) // ignore comment lines
			continue;
		if (str.find_first_of('!') == 0) // for ks and kd values
		{
			while(!file.eof() && file.good())
			{
				// ks and kd's
				file.getline(line, 4096, '\n');
				str = line;
				int count = 0;
				curPos = 0;
				double value;
				bool valid = false;
				while ((spacePos = str.find_first_of(" ", curPos)) != string::npos)
				{
					string token = str.substr(curPos, spacePos - curPos);
					if (token.size() == 0)
					{
						curPos++;
						continue;
					}

					if ((token.compare("?") == 0)  || (token.compare("+") == 0) || (token.compare("-") == 0))
					{
						if (count %2 == 0)
							value = defaultKsVal;
						else
							value = defaultKdVal;

						valid = false;
					}
					else
					{
						value = atof(token.c_str());
						valid = true;
					}

					if (count % 2 == 0)
					{
						this->setKs(indexKs, value);
						this->setDefaultKs(indexKs, valid);
						indexKs++;
					}
					else
					{
						this->setKd(indexKd, value);
						this->setDefaultKd(indexKd, valid);
						indexKd++;
					}
					curPos = spacePos + 1;
					count++;
				}
				//get the last token
				string lastToken = str.substr(curPos, str.size() - curPos);
				if (lastToken.size() == 0)
				{
					curPos++;
					continue;
				}

				if ((lastToken.compare("?") == 0)  || (lastToken.compare("+") == 0) || (lastToken.compare("-") == 0))
				{
					if (count % 2 == 0)
						value = defaultKsVal;
					else
						value = defaultKdVal;

					valid = false;
				}
				else
				{
					value = atof(lastToken.c_str());
					valid = true;
				}

				if (count % 2 == 0)
				{
					this->setKs(indexKs, value);
					this->setDefaultKs(indexKs, valid);
					indexKs++;
				}
				else
				{
					this->setKd(indexKd, value);
					this->setDefaultKd(indexKd, valid);
					indexKd++;
				}
			}

			if (indexDOF != indexKs || indexDOF != indexKd)
			{
				danceInterp::OutputMessage("Ks and Kd not matched with number of DOFs");
				return false;
			}
			size = indexDOF;
			return true;
		}
		//for joint DOF values
		while ((spacePos = str.find_first_of(" ", curPos)) != string::npos)
		{
			string token = str.substr(curPos, spacePos - curPos);
			if (token.size() == 0)
			{
				curPos++;
				continue;
			}
			if (token.compare("?") == 0)
			{
				this->setDOFInUse(indexDOF, false);
				this->setDOF(indexDOF, 0.0);
			//	this->setDefault(this->defaultDOF, indexDOF, 0.0);
			}
			else if (token.compare("+") == 0) // pose modifier - positive
			{
				this->setDOFParameter(indexDOF, 1);
				this->setDOF(indexDOF, 0.0);
			//	this->setDefault(this->defaultDOF, indexDOF, 0.0);
			}
			else if (token.compare("-") == 0) // pose modifier - negative
			{
				this->setDOFParameter(indexDOF, -1);
				this->setDOF(indexDOF, 0.0);
			//	this->setDefault(this->defaultDOF, indexDOF, 0.0);
			}
			else
			{
				this->setDOF(indexDOF, atof(token.c_str()));
			//	this->setDefault(this->defaultDOF, indexDOF, atof(token.c_str()));
			}
			indexDOF++;
			if (indexDOF >= this->getSize())
				return true;
			curPos = spacePos + 1;
		}
		// get the last token
		string lastToken = str.substr(curPos, str.size() - curPos);
		if (lastToken.size() == 0)
		{
			curPos++;
			continue;
		}
		if (lastToken.compare("?") == 0)
		{
			this->setDOFInUse(indexDOF, false);
			this->setDOF(indexDOF, 0.0);
			//this->setDefault(this->defaultDOF, indexDOF, 0.0);
			indexDOF++;
		}
		else if (lastToken.compare("+") == 0) // pose modifier - positive
		{
			this->setDOFParameter(indexDOF, 1);
			this->setDOF(indexDOF, 0.0);
		//	this->setDefault(this->defaultDOF, indexDOF, 0.0);
		}
		else if (lastToken.compare("-") == 0) // pose modifier - negative
		{
			this->setDOFParameter(indexDOF, -1);
			this->setDOF(indexDOF, 0.0);
		//	this->setDefault(this->defaultDOF, indexDOF, 0.0);
		}
		else if (lastToken.compare(" ") != 0 && lastToken.compare("\t") != 0)
		{
			this->setDOF(indexDOF, atof(lastToken.c_str()));
		//	this->setDefault(this->defaultDOF, indexDOF, atof(lastToken.c_str()));
			indexDOF++;
		}

		if (indexDOF >= this->getSize())
		{
			size = indexDOF;
			return true;
		}
	}

	size = indexDOF;

	if (isKsKd == false)
	{
		for (int i = 0; i < size; i++)
		{
			this->setDefaultKs(i, false);
			this->setDefaultKd(i, false);
			this->setKs(i, defaultKsVal);
			this->setKd(i, defaultKdVal);
		}
	}
	return true;
}

int Pose::getSize( void )
{
	return size;
}

void Pose::resetSize(int s)
{
	size = s;
}

double Pose::getDOF(int index, PoseData* pdata)
{
	return dof[index];
}

void Pose::setDOF(int index, double val)
{
	dof[index] = val;
}

double Pose::getKs(int index)
{
	return ks[index];
}

void Pose::setKs(int index, double val)
{
	ks[index] = val;
}

double Pose::getKd(int index)
{
	return kd[index];
}

void Pose::setKd(int index, double val)
{
	kd[index] = val;
}

void Pose::setDefaultKs(int index, bool val)
{
	defaultKs[index] = val;
}

void Pose::setDefaultKd(int index, bool val)
{
	defaultKd[index] = val;
}

void Pose::setDefaultKd(double val)
{
	this->defaultKdVal = val;
}

void Pose::setDefaultKs(double val)
{
	this->defaultKsVal = val;
}

bool Pose::getDefaultKs(int index)
{
	return defaultKs[index];
}

bool Pose::getDefaultKd(int index)
{
	return defaultKd[index];
}

double Pose::getDefaultKsVal( void )
{
	return this->defaultKsVal;
}

double Pose::getDefaultKdVal( void )
{
	return this->defaultKdVal;
}

void Pose::setParameters( void )
{
	for (int i = 0; i < this->size; i++)
	{
		this->setDOF(i, 0.0);
		this->setDefaultKs(i, true);
		this->setDefaultKd(i, true);
		this->setKs(i, this->defaultKsVal);
		this->setKd(i, this->defaultKdVal);
	}
}

bool Pose::isDOFInUse(int index)
{
	return dofInUse[index];
}

void Pose::setDOFInUse(int index, bool val)
{
	dofInUse[index] = val;
}


void Pose::copy(Pose* pose)
{
	int size = pose->getSize();
	for (int x = 0; x < size; x++)
	{
		double val = this->getDOF(x);
		pose->setDOF(x, val);

		val = this->getKs(x);
		pose->setKs(x, val);

		val = this->getKd(x);
		pose->setKd(x, val);

		bool b = this->isDOFInUse(x);
		pose->setDOFInUse(x, b);

		b = this->getDefaultKd(x);
		pose->setDefaultKd(x, b);
	
		b = this->getDefaultKs(x);
		pose->setDefaultKs(x, b);

		pose->setDefaultKs(this->getDefaultKsVal());
		pose->setDefaultKd(this->getDefaultKdVal());

		int rel = this->getDOFParameter(x);
		pose->setDOFParameter(x, rel);
	}
	pose->setName(this->getName());
	pose->setFileName(this->getFileName());
}

bool Pose::isPartialPose()
{
	int size = this->getSize();
	for (int x = 0; x < size; x++)
	{
		if (!this->isDOFInUse(x))
			return true;
	}

	return false;
}

bool Pose::isParameterizedPose()
{
	int size = this->getSize();
	for (int x = 0; x < size; x++)
	{
		if (this->getDOFParameter(x) != 0)
			return true;
	}

	return false;
}


int Pose::getDOFParameter(int index)
{
	return this->dofParameter[index];
}

void Pose::setDOFParameter(int index, int val)
{
	this->dofParameter[index] = val;
}

void Pose::dumpPose()
{
	danceInterp::OutputMessage("Name: %s", getName().c_str()) ;
	danceInterp::OutputMessage("Transition Time: %lf", getTransTime()) ;
	for (int x = 0; x < this->size; x++)
	{
		danceInterp::OutputMessage("%d) %f", x, this->getDOF(x));
	}
}

void Pose::interpolate(ArticulatedObject* ao, Pose* pose1, double amount, Pose* pose2, Pose* output)
{
	if (output == NULL)
		return;

	if (pose1 == NULL && pose2 == NULL)
		return;

	if (pose1 == NULL)
	{
		pose2->copy(output);
		return;
	}
	else if (pose2 == NULL)
	{
		pose1->copy(output);
		return;
	}

	int stateSize = ao->getStateSize();

	// for now, perform linear interpolation
	for (int x = 0; x < stateSize; x++)
	{
		if (pose1 == NULL)
			output->setDOF(x, pose2->getDOF(x));
		else if (pose2 == NULL)
			output->setDOF(x, pose1->getDOF(x));
		else
			output->setDOF(x, pose1->getDOF(x) * amount + pose2->getDOF(x) * (1.0 - amount));
	}

	if (true)
		return;

	Joint** joint = ao->getJoints();

	double* data1 = new double[stateSize];
	for (int x = 0; x < stateSize; x++)
	{
		data1[x] = pose1->getDOF(x);
	}

	double* data2 = new double[stateSize];
	for (int x = 0; x < stateSize; x++)
	{
		data2[x] = pose2->getDOF(x);
	}

	int count = 0 ;
	int numJoints = ao->getNumJoints();
	for (int i = 0; i < numJoints; i++)
	{
		int startCount = count;
		// obtain the quaternion of the first keyframe
		int jointStateSize = joint[i]->getStateSize(); 
		for (int j = 0; j < jointStateSize; j++)
		{
			if (j < jointStateSize - 1)
				joint[i]->setState(j, data1[count], true);
			else
				joint[i]->setState(j, data1[count], false);
			count++;
		}
		Quaternion q1(joint[i]->getQuaternion());

		count = startCount;
		// obtain the quaternion of the second keyframe
		for (int j = 0; j < jointStateSize; j++)
		{
			if (j < jointStateSize - 1)
				joint[i]->setState(j, data2[count], true);
			else
				joint[i]->setState(j, data2[count], false);
			count++;
		}
		Quaternion q2(joint[i]->getQuaternion());

		Quaternion q3;
		q1.Slerp(&q2, amount, &q3);

		joint[i]->setQuaternion(&q3);

		if (i == 0)
		{
			if (joint[i]->getJointType() == J_FREE)
			{ // first 3 parameters are XYZ position and require linear interpolation
				for (int x = 0; x < 3; x++)
				{
					joint[i]->setState(x, (data1[x] * (1.0 - amount)) + (data2[x] * amount));
				}
			}
			else if (joint[i]->getJointType() == J_PLANAR)
			{ // first 2 parameters are YZ position and require linear interpolation
				for (int x = 0; x < 2; x++)
				{
					joint[i]->setState(x, (data1[x] * (1.0 - amount)) + (data2[x] * amount));
				}
			}
		}
	}
	ao->updateStateConfig();

	// retrieve the data
	count = 0;
	for (int i = 0; i < numJoints; i++)
	{
		int jointStateSize = joint[i]->getStateSize(); 
		for (int j = 0; j < jointStateSize; j++)
		{
			output->setDOF(count, joint[i]->getState(j));
			count++;
		}
	}
}

/// Creates a new file with the given filename containing 
/// the joint angle values (dof) of this pose, but *not*
/// storing any other data, such as ks[], kd[], whether the 
/// DOF is "in use" or other data.
void Pose::writePose(ArticulatedObject* ao, std::string filename)
{
	if (ao == NULL)
	{
		danceInterp::OutputMessage("No articulated object sent, pose %s not written to a file.", name.c_str());
		return ;
	}

	ofstream file(filename.c_str());
	Joint** joints = ao->getJoints();
	int numJoints = ao->getNumJoints();
	int cur = 0;

	file << "# Pose " << this->getName() << "\n";
	file << "# automatically generated by PosePDController\n";
	for (int j = 0; j < numJoints; j++)
	{
		int stateSize = joints[j]->getStateSize();
		for (int s = 0; s < stateSize; s++)
		{
			file << this->getDOF(cur + s) << "  ";
		}
		cur += stateSize;
		file << "\n";
	}
	file << "\n";

	file.close();
}


