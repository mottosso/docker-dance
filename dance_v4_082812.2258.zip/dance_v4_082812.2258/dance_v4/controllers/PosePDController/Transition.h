#ifndef TRANSITION_H
#define TRANSITION_H

#include "Pose.h"
#include "PoseData.h"

#ifdef WIN32
#ifdef _POSEENTRY
#ifndef POSEENTRY
#define POSEENTRY __declspec(dllexport)
#endif
#else
#define POSEENTRY __declspec(dllimport)
#endif
#else
#ifndef POSEENTRY
#define POSEENTRY
#endif
#endif

class POSEENTRY Transition
{
public:
	Transition(Pose* source, Pose* destination);
	virtual ~Transition();

	Pose* getSource();
	Pose* getDestination();
	void setSource(Pose* source);
	void setDestination(Pose* destination);

	virtual void copy(Transition* transition);
	virtual bool check(PoseData* pdata);

protected:
	Pose* sourcePose;
	Pose* destinationPose;
};

#endif

