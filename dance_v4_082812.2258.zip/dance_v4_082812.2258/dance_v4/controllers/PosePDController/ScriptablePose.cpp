#include "ScriptablePose.h"

#ifdef __APPLE__
#include "Python/compile.h"
#include "Python/eval.h"
#else
#include "compile.h"
#include "eval.h"
#endif

#include "danceInterp.h"
#include "dance.h"

#include <fstream>

#ifndef Py_CLEAR
#define Py_CLEAR(op)                            \
        do {                                    \
                if (op) {                       \
                        PyObject *tmp = (PyObject *)(op);       \
                        (op) = NULL;            \
                        Py_DECREF(tmp);         \
                }                               \
        } while (0)
#endif


PyMethodDef myfunctions[] =
{
	{NULL, NULL}
};


static PyObject *wrapCPointer(void *s)
{
	PyObject *p = PyCObject_FromVoidPtr((void *) s, NULL) ;
	return p ;
}



ScriptablePose::ScriptablePose(int numDOF) : Pose(numDOF)
{
	this->script.clear();

	setController( NULL );
	this->pDict = NULL ;
	this->pModule = NULL ;
	this->filename = "" ;
	this->pMainModule = NULL ;
	this->pMainDictionary = NULL ;
	this->setPythonController(NULL) ;
}

ScriptablePose::~ScriptablePose()
{
	
	this->script.clear();

	/// Do not delete the modules
	//Py_XDECREF(this->pDict) ;
	//Py_XDECREF(this->pModule) ;

	for (int i = 0; i < this->poseList.size(); i++)
	{
		delete poseList[i];
	}
	this->poseList.clear();
}

void ScriptablePose::flush()
{
	this->script.clear();
	PyErr_Clear();
}

bool ScriptablePose::parse(std::ifstream &file, PoseData* pdata)
{
	this->script = "";
	char line[4096];
	while(!file.eof() && file.good())
	{
		file.getline(line, 4096, '\n');
		std::string line2 = line;
		line2 += "\n";
		this->script += line2;
	}

	bool result = this->makeScript();
	return result;
}

bool ScriptablePose::makeScript()
{

	/// Set up the module:
	///			register the functions and create a new module
    this->pModule = Py_InitModule( (char *) name.c_str(), myfunctions );

    /// retrieve the local dictionary (namespace)
    this->pDict = PyModule_GetDict(this->pModule) ;
	
	/// retrieve the global dictionary (namespace) so we have access to dance functions
	this->pMainModule     = PyImport_AddModule( "__main__" );
	this->pMainDictionary = PyModule_GetDict( pMainModule );

	
	////run the script
	PyObject *p = PyRun_String((char *) this->script.c_str(),Py_file_input,  this->pMainDictionary, this->pDict) ;
	PyErr_Print();
	PyErr_Clear();
	if (p == NULL)
	{
		// this error seems to occur the second time the script is loaded
		danceInterp::OutputMessage("Error running the controller script '%s'.", this->filename.c_str());
		PyErr_Print();
		PyErr_Clear();
		return false;
	}
	Py_XDECREF(p);


	return true ;
}

bool ScriptablePose::callPythonVersion( char *func )
{
	bool res = true ;
	PyObject *pArgs= NULL, *pValue=NULL ;
	pArgs = PyTuple_New(1);
	PyObject *thisPython = wrapCPointer(this) ;


	/// PyTuple_SetItem takes ownership of the elements not of pArgs, 
	/// so DO NOT CALL XDECREF on the elements such as thisPython
	
	PyTuple_SetItem(pArgs, 0, thisPython);
	
		
		
	PyObject *pfunc = Py_BuildValue("s",func) ;
	PyObject *pp = this->getPythonController() ;
	pValue = PyObject_CallMethod(pp, func, "(O)", thisPython);
	if( !pValue )
	{	
		PyObject* p = PyRun_String("sys.stderr.flush()\n",Py_file_input,  this->pMainDictionary, this->pDict) ;
		PyObject *exception, *err, *tb;
		PyErr_Fetch( &exception, &err, &tb );
		if (err)
			Py_INCREF(err);
		if (exception)
			Py_INCREF(exception);
		if (tb)
			Py_INCREF(exception);
		danceInterp::OutputMessage("Script error in %s/%s() in file %s", this->getName().c_str(), func, this->getFileName().c_str()) ;
		PyObject *f = PySys_GetObject("stderr");
		int errorNum = PyTraceBack_Print(tb, f);
		if (err)
			Py_DECREF(err);
		if (exception)
			Py_DECREF(exception);
		if (tb)
			Py_DECREF(exception);
		PyErr_Print(); // Print error message from python
		PyErr_Clear(); // Clear the error so that it doesn't persist
		return false;
	}
	Py_XDECREF(pValue);
	Py_XDECREF(pArgs);
	Py_XDECREF(pfunc);
	res = true ;
	return res ;
}



/// Call a function in python.
///
/// wraps this into an opaque pointer and passes it to the 
/// function "func" in the script.
PyObject *ScriptablePose::callPythonProxy( const char *func )
{
	PyObject *pFunc=NULL  ;

	/// now call the  function in the script
	pFunc = PyObject_GetAttrString(this->pModule, (char*) func);
	/// pFunc is a new reference
	if (pFunc && PyCallable_Check(pFunc)) {
		PyObject *pArgs= NULL, *pValue=NULL ;
		pArgs = PyTuple_New(1);
		PyObject *thisPython = wrapCPointer(this) ;
		
		/// PyTuple_SetItem takes ownership of the elements not of pArgs, 
		/// so DO NOT CALL XDECREF on the elements such as thisPython
		PyTuple_SetItem(pArgs, 0, thisPython);
		
		pValue = PyObject_CallObject(pFunc, pArgs);
		if( !pValue )
		{
			danceInterp::OutputMessage("ERROR: callPythonProxy() error in function %s script!", func) ;
			PyObject *p = PyRun_String("sys.stderr.flush()\n",Py_file_input,  this->pMainDictionary, this->pDict) ;
			PyErr_Print(); // Print error message from python
			PyErr_Clear(); // Clear the error so that it doesn't persist
		}
		this->setPythonController(pValue) ;
		Py_XDECREF(pArgs);
	}
	
	Py_XDECREF(pFunc);
	return getPythonController() ;
}


double ScriptablePose::callPythonDoubleFunction( char *argPythonFunction )
{
	bool res = true ;
	double outRetVal = 0.0;
	PyObject *pFunc=NULL  ;
	if( !argPythonFunction )
	{
		danceInterp::OutputMessage( "ScriptablePose::callPythonDoubleFunction() passed a null function name." );
	}
	PyObject *pArgs= NULL, *pValue=NULL ;
	pArgs = PyTuple_New(1);
	PyObject *thisPython = wrapCPointer(this) ;
	PyTuple_SetItem(pArgs, 0, thisPython);
	PyObject *pfunc = Py_BuildValue("s",argPythonFunction) ;
	PyObject *pp = getPythonController() ;
	if( !pp )
	{
		danceInterp::OutputMessage("ERROR: ScriptablePose's Python Controller (m_pythonController) is null!" );
		return 0.0;
	}
	pValue = PyObject_CallMethod(pp, argPythonFunction, "(O)", thisPython);
	if( !pValue )
	{
		danceInterp::OutputMessage("Error: callPythonDoubleFunction() in function %s script!", argPythonFunction) ;
		PyObject *p = PyRun_String("sys.stderr.flush()\n",Py_file_input,  this->pMainDictionary, this->pDict) ;
		PyErr_Print(); // Print error message from python
		PyErr_Clear(); // Clear the error so that it doesn't persist
	}
	else
	{
		outRetVal = PyFloat_AsDouble( pValue );
	}
	Py_XDECREF(pValue);
	Py_XDECREF(pArgs);
	Py_XDECREF(pfunc);
	return outRetVal ;
}

/// This is a c++-wrapper for the start function in the python script.
// Also stores m_posePDController
bool ScriptablePose::start(double time, PosePDController *pdc)
{
	/// store the m_posePDController pointer which is used by start, stop and step
	
	setController( pdc );
	if( m_pythonController != NULL )
	{
		Py_DECREF(m_pythonController) ;
		m_pythonController = NULL ;

	}
	if( getPythonController() == NULL )
	{
		char proxy[200] = "" ;
		sprintf(proxy,"new%s", this->name.c_str()) ;
		PyObject *pValue = this->callPythonProxy(proxy) ;
		if( !pValue )
		{
			danceInterp::OutputMessage("ERROR: instance() -- script name is %s, but no factory method named %s found.", this->name.c_str(), proxy) ;
			return false ;
		}
		//m_pythonController = pValue;  //< added Dex
		//Py_DECREF(pValue) ;
	}
	return this->callPythonVersion("start") ;
}

/// This is a c++-wrapper for the step function in the python script.
bool ScriptablePose::stop(double time)
{
	return this->callPythonVersion("stop") ;
}

/// This is a c++-wrapper for the stepfunction in the python script.
bool ScriptablePose::step(double time)
{
	return this->callPythonVersion("step") ;
}

double ScriptablePose::success( void )
{
	return callPythonDoubleFunction( "success" );
}


/// Copies the fields of this into target
void ScriptablePose::copy(ScriptablePose* target)
{
	target->script = this->script;

	target->name = this->name;

	target->filename = this->filename;
	target->pDict = this->pDict ;
	target->pModule = this->pModule ;
	if( this->pModule)
		Py_INCREF(this->pModule) ;
	if( this->pDict)
		Py_INCREF(this->pDict) ;

	// run the standard parse command
	// instead of parsing the text that was copied
	std::string absFilename = dance::convertPathToAbsolutePath(filename);
	std::ifstream file(absFilename.c_str(), std::ios::in);
	if (!file.good())
	{
     danceInterp::OutputMessage("Pose file '%s' is not valid, attempting to parse script.\n", this->filename.c_str());
		target->makeScript() ;		
	}
	else
	{
		bool success = target->parse(file);
		if (!success)
		{
      danceInterp::OutputMessage("Problem parsing script %s.", this->filename.c_str());
		}
	}

	target->setStartTime(this->getStartTime()) ;

}
