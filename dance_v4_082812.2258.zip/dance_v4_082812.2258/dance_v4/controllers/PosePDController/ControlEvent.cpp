#include "ControlEvent.h"

ControlEvent::ControlEvent()
{
	startTime = -1.0;
	endTime = -1.0;
}

double ControlEvent::getStartTime()
{
	return startTime;
}

double ControlEvent::getEndTime()
{
	return endTime;
}

void ControlEvent::setStartTime(double t)
{
	startTime = t;
}

void ControlEvent::setEndTime(double t)
{
	endTime = t;
}

void ControlEvent::setName(char* n)
{
	name = n;
}

char* ControlEvent::getName()
{
	return (char*) name.c_str();
}

void ControlEvent::setKS(double value)
{
	ks = value;
}

double ControlEvent::getKS()
{
	return ks;
}

void ControlEvent::setKD(double value)
{
	kd = value;
}

double ControlEvent::getKD()
{
	return kd;
}

StaticPoseEvent::StaticPoseEvent()
{
	pose1 = NULL;
	pose2 = NULL;
}

void StaticPoseEvent::setPose1(Pose* p)
{
	pose1 = p;
}

Pose* StaticPoseEvent::getPose1()
{
	return pose1;
}

void StaticPoseEvent::setPose2(Pose* p)
{
	pose2 = p;
}

Pose* StaticPoseEvent::getPose2()
{
		return pose2;
}

void StaticPoseEvent::setInterpolation(double interp)
{
	interpolation = interp;
}

double StaticPoseEvent::getInterpolation()
{
	return interpolation;
}

AnimatablePoseEvent::AnimatablePoseEvent()
{
	animatablePose = NULL;
}


void AnimatablePoseEvent::setAnimatablePose(AnimatablePose* p)
{
	animatablePose = p;
}

AnimatablePose* AnimatablePoseEvent::getAnimatablePose()
{
	return animatablePose;
}

ScriptablePoseEvent::ScriptablePoseEvent()
{
	scriptablePose = NULL;
}

void ScriptablePoseEvent::setScriptablePose(ScriptablePose* p)
{
	scriptablePose = p;
}

ScriptablePose* ScriptablePoseEvent::getScriptablePose()
{
	return scriptablePose;
}

