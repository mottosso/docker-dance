#include "PoseBlock.h"

int PoseBlock::lastID = 1;

PoseBlockParameters::PoseBlockParameters()
{
	setGlobalKS(1.0);
	setGlobalKD(.2);
	setUseCriticalDamping(true);
}

void PoseBlockParameters::setGlobalKS(double val)
{
	globalKS = val;
}

double PoseBlockParameters::getGlobalKS()
{
	return globalKS;
}

void PoseBlockParameters::setGlobalKD(double val)
{
	globalKD = val;
}

double PoseBlockParameters::getGlobalKD()
{
	return globalKD;
}

void PoseBlockParameters::setUseCriticalDamping(bool val)
{
	useCriticalDamping = val;
}

bool PoseBlockParameters::isUseCriticalDamping()
{
	return useCriticalDamping;
}

AnimatablePoseBlockParameters::AnimatablePoseBlockParameters() : PoseBlockParameters()
{
};

ScriptablePoseBlockParameters::ScriptablePoseBlockParameters() : PoseBlockParameters()
{
};


PoseBlock::PoseBlock()
{
	setPose(NULL);
	setPoseBlockParameters(NULL);
	id = lastID;
	lastID++;
}

int PoseBlock::getID()
{
	return id;
}

void PoseBlock::setPose(Pose* p)
{
	pose = p;
}

Pose* PoseBlock::getPose()
{
	return pose;
}

void PoseBlock::setPoseBlockParameters(PoseBlockParameters* params)
{
	parameters = params;
}


PoseBlockParameters* PoseBlock::getPoseBlockParameters()
{
	return parameters;
}

AnimatablePoseBlock::AnimatablePoseBlock() : PoseBlock()
{
}

ScriptablePoseBlock::ScriptablePoseBlock() : PoseBlock()
{
}

ControllerTrack::ControllerTrack() : Track()
{
}

ControllerEditorModel::ControllerEditorModel() : NonLinearEditorModel()
{
}
