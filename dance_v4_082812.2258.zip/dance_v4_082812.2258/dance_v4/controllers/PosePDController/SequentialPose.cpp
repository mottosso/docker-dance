/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "SequentialPose.h"
#include "danceInterp.h"
#include <fltk/file_chooser.h>
#include <fstream>

using namespace fltk;
using namespace std;

//PoseInterpreter* SequentialPose::interpreter = NULL;

SequentialPose::SequentialPose(int numDOF) : Pose(numDOF)
{
	this->setStartTime(0.0);
	this->poseSequence = NULL;
	this->setTimeOffset(0.0);
	this->setLocalTime(0.0);
	this->setLoop(false);
	this->setInterpolation(false);

}

SequentialPose::~SequentialPose()
{
	delete poseSequence;
	currentPose = NULL;
}

double SequentialPose::getDOF(int index, PoseData* pdata)
{
	if (getPoseGroup() == NULL)
		return 0.0;

	if (pdata == NULL)
		return 0.0;

	//determine which pose to use
	//1 second transition time

	int numTransitions = this->getPoseGroup()->getNumTransitions(this->currentPose);

	for (int i = 0 ; i < numTransitions; i++)
	{
		Transition* t = this->poseSequence->getTransition(this->getCurrentPose(), i);
		if (t == NULL)
			continue;

		if (t->check(pdata) == true)	
		{
			this->setCurrentPose(t->getDestination());
			pdata->setStartTime(pdata->getCurrentTime());

			break;
		}
	}

	return this->getCurrentPose()->getDOF(index);
}

void SequentialPose::setStartTime(double time)
{
	startTime = time;
}

double SequentialPose::getStartTime()
{
	return startTime;
}

void SequentialPose::setInterpolation(bool val)
{
	interpolation = val;
}

bool SequentialPose::getInterpolation()
{
	return interpolation;
}

void SequentialPose::loadFile(char* filename)
{
	//char* filename = fltk::file_chooser("Load Pose Sequence", "{*.psq}", "poseSequences/", true);

	if (filename != NULL)
	{
		int poses;
		char statename[256];
		char stateFileName[256];
		int length = strlen(filename);
		ifstream fp(filename);
		if (!fp.good())
		{
			danceInterp::OutputMessage("Cannot open %s.", filename) ;
			return;
		}

		//remove previous poses and remove the .psq from the filename
		filename[length-4] = '\0';
		strcat(filename, "_");

		fp.ignore(6, ' ');
		fp >> poses ;
		fp.ignore(1, '\n');
		for (int i = 0; i < poses; i++)
		{
			Pose* p = new Pose(100);
			fp.getline(statename, 256, '\n');
			strcpy(stateFileName, filename);
			strcat(stateFileName, statename);
			strcat(stateFileName, ".STATE");

			ifstream fp2(stateFileName);
			
			if (!fp2.good())
			{
				danceInterp::OutputMessage("Cannot open %s.", stateFileName) ;
				fp2.close();
				fp.close();
				return;
			}
			
			bool success = p->parse(fp2);
			if (!success)
			{
				danceInterp::OutputMessage("File %s could not be properly parsed.", stateFileName);
				delete p;
				fp2.close();
				fp.close();
				return;
			}
			p->setName(statename);

			getPoseGroup()->addPose(p);

			fp2.close();
		}
		fp.close();
	}

}

void SequentialPose::setPoseGroup(PoseGroup* seq)
{
	poseSequence = seq;
}

PoseGroup* SequentialPose::getPoseGroup()
{
	return poseSequence;
}

void SequentialPose::setLoop(bool val)
{
	loop = val;
}

bool SequentialPose::getLoop()
{
	return loop;
}

void SequentialPose::setLocalTime(double time)
{
	localTime = time;
}

double SequentialPose::getLocalTime()
{
	return localTime;
}

bool SequentialPose::parse(std::ifstream &file, PoseData *pdata)
{
	PoseGroup* ps = new PoseGroup();
	bool success = ps->parse(file);
	if (success)
	{
		if (ps->getNumPoses() > 0)
		{
			this->resetSize(ps->getPose(0)->getSize());
		}
		
		this->setPoseGroup(ps);
		this->setCurrentPose(ps->getPose(0));

		//load the sensor files
		for (int i = 0; i < this->getPoseGroup()->getNumTransitions(); i++)
		{
			bool sensorSuccess;
			SensorTransition* sensor = dynamic_cast<SensorTransition*> (this->getPoseGroup()->getTransition(i));
			
			if (sensor != NULL)
			{
				sensorSuccess = sensor->parse();
				if (!sensorSuccess)
				{
					delete ps;
					return false;
				}
			}
		}

		return true;
	}
	else
	{
		delete ps;
		return false;
	}
	

}

void SequentialPose::copy(SequentialPose* pose)
{
	PoseGroup* origPsq = this->getPoseGroup();
	PoseGroup* psq = NULL;
	if (origPsq != NULL)
	{
		psq = new PoseGroup();
		origPsq->copy(psq);
	}
	pose->setCurrentPose(this->getCurrentPose());
	pose->setInterpolation(this->getInterpolation());
	pose->setLoop(this->getLoop());
	pose->setLocalTime(this->getLocalTime());
	pose->setPoseGroup(psq);
	pose->setName(this->getName());
	pose->setFileName(this->getFileName());
}

void SequentialPose::setTimeOffset(double offset)
{
	timeOffset = offset;
}

double SequentialPose::getTimeOffset()
{
	return timeOffset;
}

void SequentialPose::setCurrentPose(Pose* p)
{
	this->currentPose = p;
}

Pose* SequentialPose::getCurrentPose()
{
	return this->currentPose;
}

//int SequentialPose::regfoo(lua_State* L)
//{
//	double num = lua_tonumber(PoseData::getPoseInterpreter()->L, lua_gettop(PoseData::getPoseInterpreter()->L));
//
//	if (sensorfoo(num) == true)
//		lua_pushnumber(PoseData::getPoseInterpreter()->L, 1);
//	else
//		lua_pushnumber(PoseData::getPoseInterpreter()->L, 0);
//
//	return 1;
//}
//
//bool SequentialPose::sensorfoo(double num)
//{
//	if (num < 500)
//		return true;
//	else
//		return false;
//}
