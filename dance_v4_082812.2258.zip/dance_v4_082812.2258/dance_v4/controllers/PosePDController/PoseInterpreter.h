#ifndef POSEINTERPRETER_H
#define POSEINTERPRETER_H

#include "danceInterp.h"
#include "IKChain.h"

#ifdef _DEBUG
 #undef _DEBUG
#ifdef __APPLE__
 #include <Python/python.h>
#else
 #include <Python.h>
#endif // __APPLE__
 #define _DEBUG
 #undef _CRT_MANIFEST_RETAIL
#else
#ifdef __APPLE__
 #include <Python/python.h>
#else
 #include "Python.h"
#endif // __APPLE__
#endif


#include "Pose.h"
class PosePDController;
class Sensor;

class PoseInterpreter
{
public:
	PoseInterpreter(Sensor* s, PosePDController* c);
	~PoseInterpreter();

	void Init();
	void controllerInit();

	static PyObject* scriptError(std::string function, const char *format, ...);
	static PyObject* scriptError(std::string function);

	//wrapper functions
	static PyObject* getTime(PyObject* self, PyObject* args);
	static PyObject* getTimeStep(PyObject* self, PyObject* args);
	static PyObject* getPosition(PyObject* self, PyObject* args);
	static PyObject* getVelocity(PyObject* self, PyObject* args);
	static PyObject* getAngularVelocity(PyObject* self, PyObject* args);
	static PyObject* getRotationAxis(PyObject* self, PyObject* args);
	static PyObject* getCenterMass(PyObject* self, PyObject* args);
	static PyObject* isLinkOnGround(PyObject *self, PyObject* args);
	static PyObject* isLinkColliding(PyObject* self, PyObject* args);
	static PyObject* getCMVelocity(PyObject* self, PyObject* args);
	static PyObject* setParam(PyObject* self, PyObject* args);
	static PyObject* getFacing(PyObject* self, PyObject* args);
	static PyObject* getUpVector(PyObject* self, PyObject* args);
	static PyObject* printString(PyObject* self, PyObject* args);
	static PyObject* printValueDouble(PyObject* self, PyObject* args);
	static PyObject* printValueInt(PyObject* self, PyObject* args);
	//static PyObject* addDictionaryInt(PyObject* self, PyObject* args);
	//static PyObject* addDictionaryDouble(PyObject* self, PyObject* args);
	//static PyObject* addDictionaryDict(PyObject* self, PyObject* args);
	//static PyObject* addDictionaryObject(PyObject* self, PyObject* args);

	static PyObject* setPythonController(PyObject* self, PyObject* args) ;
	static PyObject* getLerpJointFromStates(PyObject* self, PyObject* args) ;
	static PyObject* interpolatePoses(PyObject* self, PyObject* args);
	static PyObject* setJointValuesFromCurrentState(PyObject* self, PyObject* args);
	static PyObject* loadPose(PyObject* self, PyObject* args);
	static PyObject* setPose(PyObject* self, PyObject* args);
	static PyObject* setDefaultPose(PyObject* self, PyObject* args);
	static PyObject* initPose(PyObject* self, PyObject* args);
	static PyObject* extractPose(PyObject* self, PyObject* args);
	static PyObject* computeCM(PyObject* self, PyObject* args);
	static PyObject* getIndxFirstConDof(PyObject* self, PyObject* args);
	static PyObject* getStateSize(PyObject* self, PyObject* args);
    static PyObject* getState(PyObject* self, PyObject* args);
    static PyObject* getNumJoints(PyObject* self, PyObject* args);
    static PyObject* getJointStateSize(PyObject* self, PyObject* args);
    static PyObject *getEulerFromBall(PyObject* self, PyObject* args);
	static PyObject* getOrientation(PyObject* self, PyObject* args);
	static PyObject* getCMRelativeDistance(PyObject* self, PyObject* args);
	static PyObject* magic(PyObject* self, PyObject* args);
	static PyObject* magicBody(PyObject* self, PyObject* args);
	static PyObject* magicBodyToBody(PyObject* self, PyObject* args);
	static PyObject* magicTorque(PyObject* self, PyObject* args);
	static PyObject* isPoseSet(PyObject* self, PyObject* args);
	static PyObject* reachOffset(PyObject* self, PyObject* args);
	static PyObject* reach(PyObject* self, PyObject* args);
	static PyObject* reachObject(PyObject* self, PyObject* args);
	static PyObject* reachLink(PyObject* self, PyObject* args);
	static PyObject* getPositionObject(PyObject* self, PyObject* args);
	static PyObject* getPositionLink(PyObject* self, PyObject* args);
	static PyObject* getJointPosition(PyObject* self, PyObject* args);
	static PyObject* attachLink(PyObject* self, PyObject* args);
	static PyObject* detachLink(PyObject* self, PyObject* args);
	static PyObject* isAttached(PyObject* self, PyObject* args); 
	static PyObject* setJoint1(PyObject* self, PyObject* args);
	static PyObject* setJoint2(PyObject* self, PyObject* args);
	static PyObject* setJoint3(PyObject* self, PyObject* args);
	static PyObject* setJoint4(PyObject* self, PyObject* args);
	static PyObject* setJoint4Euler(PyObject* self, PyObject* args);
	static PyObject* setJointKsKd1(PyObject* self, PyObject* args);
	static PyObject* setJointKsKd2(PyObject* self, PyObject* args);
	static PyObject* setJointKsKd3(PyObject* self, PyObject* args);
	static PyObject* setJointKsKd4(PyObject* self, PyObject* args);
	static PyObject* setFootFlat(PyObject* self, PyObject* args);
	static PyObject* getWorldZeroXYZAngles(PyObject* self, PyObject* args);
	static PyObject* getListOfPoses(PyObject* self, PyObject* args);
	static PyObject* setTargetPose(PyObject* self, PyObject* args);
	static PyObject* setTargetPoseByName(PyObject* self, PyObject* args);
	static PyObject* getNearestPointOnSupportPolygon(PyObject* self, PyObject* args);
	static PyObject* getDistToSupportPolygon(PyObject* self, PyObject* args);
	static PyObject* getWorldQuaternion(PyObject* self, PyObject* args);
	static PyObject* getJointFromPose(PyObject* self, PyObject* args);
	static PyObject* applyImpulseToLink(PyObject* self, PyObject* args);
    static PyObject* setLinkKinematic(PyObject* self, PyObject* args);   	

	static PyObject* getVelocityObj(PyObject* self, PyObject* args);
    static PyObject* attachLinkStatic(PyObject* self, PyObject* args);
    static PyObject* attachLinkAO(PyObject* self, PyObject* args);
    static PyObject* detachLinkStatic(PyObject* self, PyObject* args);
    static PyObject* detachLinkAO(PyObject* self, PyObject* args);
    static PyObject* isAttachedStatic(PyObject* self, PyObject* args);
    static PyObject* isAttachedAO(PyObject* self, PyObject* args);


	static PyObject* getControlParam( PyObject* self, PyObject* args );
	static PyObject* getControlParams( PyObject* self, PyObject* args );
	static PyObject* setControlParam( PyObject* self, PyObject* args );

	static PyObject* getNumCollisionPoints( PyObject* self, PyObject* args );
	static PyObject* getCollisionPoint( PyObject* self, PyObject* args );
	static PyObject* getLinkPointWorld( PyObject* self, PyObject* args );
	static PyObject* getLinkPointLocal( PyObject* self, PyObject* args );

	static PyObject* getSimIndex(PyObject* self, PyObject* args) ;

	static PyObject* noise( PyObject* self, PyObject* args );
	static PyObject* setControlUpdateFrequency( PyObject* self, PyObject* args );
	static PyObject* getControlUpdateFrequency( PyObject* self, PyObject* args );

	static PyObject* addPoint( PyObject* self, PyObject* args );
	static PyObject* removePoint( PyObject* self, PyObject* args );
	static PyObject* addLine( PyObject* self, PyObject* args );
	static PyObject* removeLine( PyObject* self, PyObject* args );
	static PyObject* clearGraphics( PyObject* self, PyObject* args );

	static void computeFastIK(PosePDController *p, char* ikName, Vector goal, double distance, double elbowDirX,
		double elbowDirY, double elbowDirZ,
		double ofx=0.0, double ofy=0.0, double ofz=0.0, bool useOffset=false);
	static void computeIK(PosePDController *p, char* ikName, Vector goal, int numSteps, double stepDivision);
	static bool getObject(char* name, Vector pos);
	static bool getLink(char* objectName, int linkNum, Vector pos);
	static bool getLink(char* objectName, char* linkName, Vector pos);
	
	static void setQuaternionStateFromEulerAngles(double* oldstate, Vector angles, double* newstate, Joint* joint);


	static bool getObjectVel(char* name, Vector vel);

	static Sensor* sensor;
	static PyObject *pdict;
	PyObject *pm;
	static PosePDController* controller;
	
	//static bool computed;
	static double reachValues[10][50];
	static Vector oldReach;

private:
	
	
};

#endif
