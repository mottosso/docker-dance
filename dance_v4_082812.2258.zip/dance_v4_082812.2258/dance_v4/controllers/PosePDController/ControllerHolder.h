#ifndef CONTROLLERHOLDER_H
#define CONTROLLERHOLDER_H

#ifdef WIN32
#ifdef _POSEENTRY
#ifndef POSEENTRY
#define POSEENTRY __declspec(dllexport)
#endif
#else
#define POSEENTRY __declspec(dllimport)
#endif
#else
#ifndef POSEENTRY
#define POSEENTRY
#endif
#endif

class PosePDController;

/// Interface for classes responsible for holding a PosePDController.
/// \sa Pose
/// \todo The stop/start/step be broken out, they are not specifically related to PPDC
class POSEENTRY ControllerHolder {
public:
	ControllerHolder( PosePDController* arg = 0 )
		: m_posePDController( arg )
	{ }
	virtual ~ControllerHolder() {}
	virtual bool start(double time, PosePDController *s) { return true ;}
	virtual bool stop(double time) { return true ;}
	virtual bool step(double time) {return true;} 

	PosePDController *getController() { return m_posePDController;} 
	void setController(PosePDController *p) { m_posePDController = p;} 

protected:
	PosePDController *m_posePDController ;
} ;

#endif
