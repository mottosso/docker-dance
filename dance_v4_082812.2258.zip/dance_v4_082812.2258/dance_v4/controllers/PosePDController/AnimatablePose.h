/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _ANIMATABLEPOSE_H
#define _ANIMATABLEPOSE_H

#include "Pose.h"
#include "ArticulatedObject.h"
#include "CharacterAnimationSequence.h"

class AnimatablePose : public Pose
{

	public:
		AnimatablePose(ArticulatedObject* ao, int size);
		~AnimatablePose();

		bool parse(std::ifstream &file, PoseData* pdata = NULL);

		void setAnimation(CharacterAnimationSequence* anim);
		CharacterAnimationSequence* getAnimation();
		bool loadAnimation(std::ifstream &file);
		void deleteAnimation();

		void setTimeOffset(double timeOffset);
		double getTimeOffset();

		double* getOffset();
		void setOffset(double* offset);
		double* getOrientation();
		void setOrientation(double* offset);

		void setLocalTime(double time);
		double getLocalTime();

		void copy(AnimatablePose* pose);

		bool isKinematic();
		void setKinematic(bool val);

		void setKinematicBlendTime(double time);
		double getKinematicBlendTime();

		double getDOF(int index, PoseData* pdata = NULL);

		void setBlendPoseData(double* blendPoseData);
		double* getBlendPoseData();
		void setHasBlendPose(bool val);
		bool hasBlendPose();

		void setFixRoot(bool val);
		bool isFixRoot();

		void setRootKSKD(double ks, double kd);
		void getRootKSKD(double& ks, double& kd);

	private:
		CharacterAnimationSequence* m_animSeq;
		CharacterAnimationSequence* m_animSeqOrig;
		double m_timeOffset;
		Vector m_offset;
		Vector m_orientation;
		double m_localTime; // with respect to the saved animation
		ArticulatedObject* m_ao;
		bool m_isKinematic;
		double m_kinematicBlend;
		double m_blendPoseData[MAX_STATE];
		bool m_hasBlendPose;
		bool m_isFixRoot;
		double m_rootKS;
		double m_rootKD;
};
#endif
