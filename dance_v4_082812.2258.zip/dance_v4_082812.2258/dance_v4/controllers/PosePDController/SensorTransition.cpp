#include "SensorTransition.h"
#include "dance.h"
#include "DSimulatorManager.h"
#include <fstream>
#ifdef __APPLE__
#include "Python/compile.h"
#include "Python/eval.h"
#else
#include "compile.h"
#include "eval.h"
#endif

using namespace std;

SensorTransition::SensorTransition(Pose* source, Pose* destination, char* file) : Transition(source, destination)
{
	strcpy(filename, file);
	pythonScript = "";
	code = NULL;
}

SensorTransition::~SensorTransition()
{
	//if (this->code != NULL)
	//	Py_XDECREF(this->code);
	//this->code = NULL;
}

void SensorTransition::copy(SensorTransition* orig)
{
	orig->setSource(this->getSource());
	orig->setDestination(this->getDestination());
	orig->setFileName(this->getFileName());
	
	for (int i = 0; i < this->commands.size(); i++)
	{
		orig->commands.push_back(this->commands[i]);
	}
	orig->pythonScript = this->pythonScript;
	orig->code = this->code;
}

bool SensorTransition::check(PoseData* pdata)
{
	//This load file and run should only be called once. check will take take what has already been opened previously (sensor information)
	//and evaulate whether or not the sensor transition has occurred. Consider moving this function to poseInterpreter.cpp or even constructor
	//of this sensorTransition.cpp

	if (this->code == NULL)
		return false;

	int val;
	PyEval_EvalCode((PyCodeObject *) this->code, pdata->getPoseInterpreter()->pdict, pdata->getPoseInterpreter()->pdict) ;
	PyObject* p = PyDict_GetItemString(pdata->getPoseInterpreter()->pdict, "result");
	PyArg_Parse(p,"(i)",&val) ;

	if (val == 1)
			return true;
	else
			return false;
}

bool SensorTransition::parse()
{
	std::ifstream file(this->filename, ios::in);
	if (!file.good())
	{
		return false;
	}

	char line[4096];
	while(!file.eof() && file.good())
	{
		file.getline(line, 4096, '\n');
		std::string line2 = line;
		line2 += "\n";
		commands.push_back((line2));
	}

	bool result = this->makeScript();
	return result;
}

bool SensorTransition::makeScript()
{
	//have checks
	for (int i = 0; i < commands.size(); i++)
	{
		this->pythonScript = this->pythonScript + commands[i];
	}

	this->code = Py_CompileString(this->pythonScript.c_str(), "<embed>", Py_file_input);
	if (this->code == NULL)
		return false;
	else
		return true;
}

char* SensorTransition::getFileName()
{
	return this->filename;
}

void SensorTransition::setFileName(char* name)
{
	strcpy(this->filename, name);
}

