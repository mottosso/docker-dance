#include "TimeTransition.h"
#include "dance.h"
#include "DSimulatorManager.h"

TimeTransition::TimeTransition(Pose* source, Pose* destination) : Transition(source, destination)
{
	this->setTime(0.0);
}

TimeTransition::~TimeTransition()
{
	this->setTime(0.0);
}
void TimeTransition::copy(TimeTransition* orig)
{
	orig->setTime(this->getTime());
	orig->setSource(this->getSource());
	orig->setDestination(this->getDestination());
}

void TimeTransition::setTime(double timeVal)
{
	this->time = timeVal;
}

double TimeTransition::getTime()
{
	return this->time;
}

bool TimeTransition::check(PoseData* pdata)
{
	if (pdata == NULL)
		return false;

	if (dance::AllSimulators->getCurrentTime() - pdata->getStartTime() >= this->getTime())
	{
		danceInterp::OutputMessage("Pose check is true\n");
		return true;
	}
	else
		return false;
}
