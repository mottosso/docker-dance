#ifndef _POSEBLOCK_
#define _POSEBLOCK_

#include "Nle.h"
#include "Pose.h"

class PoseBlockParameters
{
	public:
		PoseBlockParameters();

		virtual void setGlobalKS(double val);
		virtual double getGlobalKS();
		virtual void setGlobalKD(double val);
		virtual double getGlobalKD();
		virtual void setUseCriticalDamping(bool val);
		virtual bool isUseCriticalDamping();

	private:
		double globalKS;
		double globalKD;
		bool useCriticalDamping;
};

class AnimatablePoseBlockParameters : public PoseBlockParameters
{
	public:
		AnimatablePoseBlockParameters();


	private:
};

class ScriptablePoseBlockParameters : public PoseBlockParameters
{
	public:
		ScriptablePoseBlockParameters();


	private:
};

class PoseBlock : public Block
{
	public:
		PoseBlock();
		
		virtual void setPose(Pose* pose);
		virtual Pose* getPose();

		virtual PoseBlockParameters* getPoseBlockParameters();
		virtual void setPoseBlockParameters(PoseBlockParameters* params);

		int getID();
	
	protected:
		Pose* pose;
		PoseBlockParameters* parameters;

	private:
		static int lastID;
		int id;
		
};

class AnimatablePoseBlock : public PoseBlock
{
	public:
		AnimatablePoseBlock();
};

class ScriptablePoseBlock : public PoseBlock
{
	public: 
		ScriptablePoseBlock();

};

class ControllerTrack : public Track
{
	public:
		ControllerTrack();

	private:
};

class ControllerEditorModel : public NonLinearEditorModel
{
	public:
		ControllerEditorModel();

	private:

};

#endif
