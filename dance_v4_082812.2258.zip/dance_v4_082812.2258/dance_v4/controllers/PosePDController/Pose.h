/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef POSE_H
#define POSE_H

#include "ControllerHolder.h"
#include "AppraisableActuator.h"

#include <fstream>

class PoseData;
class ArticulatedObject;

/*
#ifdef WIN32
#ifdef _POSEENTRY
#ifndef POSEENTRY
#define POSEENTRY __declspec(dllexport)
#endif
#else
#define POSEENTRY __declspec(dllimport)
#endif
#else
#ifndef POSEENTRY
#define POSEENTRY
#endif
#endif
*/

class PosePDController ;

/// The Pose class is responsible for simple storage of the
/// data responsible for a character's pose.  The most important
/// data are the positions of joint angles, recorded in Pose
/// as the values of each degree of freedom (DoF).
/// Additional data held by Pose are the spring constants, default 
/// spring constants, whether a DoF is "in use" (ie, if characters  
/// should derive this DoF from this pose or not).
/// The Pose is responsible for its file persistence via parse() and writePose().
//class POSEENTRY Pose : public ControllerHolder, public AppraisableActuator
class Pose : public ControllerHolder, public AppraisableActuator
{
	public:
		/// Creates the pose with "size" degrees-of-freedom. 
		Pose(int size);
		Pose( const Pose& argPose ); //< not defined-- prevent copy constructor
		Pose& operator=( const Pose& argPose ); //< not defined-- prevent assignment op
		virtual ~Pose();

		void setName(const std::string& name);
		const std::string& getName( void );
		void setFileName(const std::string& name);
		const std::string& getFileName();

		/// Sets this pose according to the values in the specified file.
		///
		/// if ks is specified, the ks and default ks are set to that value.
		/// if kd is specified, the kd and default kd are set to that value.
		/// DoF interpretation depends on the initial character:
		///  ?  means the DoF is not in use, and it's value is set to zero.
		///  +  means that the provided DoF value is ignored and the pose's value set to 0, with the "DOFParameter" set to +1
		///  -  means the same, but the DoFParameter is set to -1
		///  no initial character uses the DoF value directly for the pose.
		///  
		/// PoseData is an unused parameter.
		virtual bool parse(std::ifstream &file, PoseData* pdata = NULL);

		/// Creates a new file with the given filename containing 
		/// the joint angle values (dof) of this pose, but *not*
		/// storing any other data, such as ks[], kd[], whether the 
		/// DOF is "in use" or other data.
		void writePose(ArticulatedObject* ao, std::string filename);
		virtual int getSize( void );
		virtual void resetSize(int s);
		virtual double getDOF(int index, PoseData* pdata = NULL);
		virtual void setDOF(int index, double val);
		virtual bool isDOFInUse(int index);
		virtual void setDOFInUse(int index, bool val);

		/// if any "DOFParameter" is non-zero, the pose is considered parameterized
		virtual int getDOFParameter(int index);

		/// if any "DOFParameter" is non-zero, the pose is considered parameterized
		virtual void setDOFParameter(int index, int val);
		virtual bool isPartialPose( void );
		virtual bool isParameterizedPose( void );
		virtual void copy(Pose* pose);

		/// Displays the DoF values of this pose to the Output Window.
		virtual void dumpPose();
		void setTransTime(double t) { m_transTime = t ;} ;
		void setStartTime(double t) { m_startTime = t ;} ;
		double getTransTime(void) { return m_transTime ;} ;
		double getStartTime(void) { return m_startTime ;} ;

		static void interpolate(ArticulatedObject* ao, Pose* pose1, double amount, Pose* pose2, Pose* output);
		
		void setParameters( void );
		virtual double getKs(int index);
		virtual void setKs(int index, double val);
		virtual double getKd(int index);
		virtual void setKd(int index, double val);
		void setDefaultKs(int index, bool val);
		void setDefaultKd(int index, bool val);
		bool getDefaultKs(int index);
		bool getDefaultKd(int index);

		void setDefaultKs(double val);
		void setDefaultKd(double val);
		double getDefaultKsVal();
		double getDefaultKdVal();

	protected:
		double* ks; //< Owned
		double* kd; //< Owned
		double* dof; //< Owned

		double defaultKsVal;
		double defaultKdVal;
		bool* defaultKs; //< Owned
		bool* defaultKd; //< Owned
		bool* dofInUse; //< Owned
		int* dofParameter; //< Owned
		int size;
		std::string name;
		std::string filename;
		double m_transTime ;
		double m_startTime ;
};

#endif
