#ifndef _CONTROLEVENT_
#define _CONTROLEVENT_

#include "Pose.h"
#include "AnimatablePose.h"
#include "ScriptablePose.h"

class ControlEvent
{
	public:
		ControlEvent();

		void setStartTime(double t);
		double getStartTime();
		void setEndTime(double t);
		double getEndTime();
		void setKS(double value);
		double getKS();
		void setKD(double value);
		double getKD();
		void setName(char* n);
		char* getName();

	private:
		double startTime;
		double endTime;
		double ks;
		double kd;
		std::string name;

};

class StaticPoseEvent : public ControlEvent
{
	public:
		StaticPoseEvent();
		void setPose1(Pose* p);
		Pose* getPose1();
		void setPose2(Pose* p);
		Pose* getPose2();
		void setInterpolation(double interp);
		double getInterpolation();

	private:
		Pose* pose1;
		Pose* pose2;
		double interpolation;
};

class AnimatablePoseEvent : public ControlEvent
{
	public:
		AnimatablePoseEvent();
		void setAnimatablePose(AnimatablePose* p);
		AnimatablePose* getAnimatablePose();

	private:
		AnimatablePose* animatablePose;
};

class ScriptablePoseEvent : public ControlEvent
{
	public:
		ScriptablePoseEvent();
		void setScriptablePose(ScriptablePose* p);
		ScriptablePose* getScriptablePose();

	private:
		ScriptablePose* scriptablePose;
};
#endif