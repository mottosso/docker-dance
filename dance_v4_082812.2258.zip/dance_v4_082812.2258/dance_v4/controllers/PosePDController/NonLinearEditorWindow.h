#ifndef _NONLINEAREDITORWINDOW_
#define _NONLINEAREDITORWINDOW_

#include <fltk/Window.h>
#include <fltk/FloatInput.h>
#include <fltk/Input.h>
#include <fltk/Button.h>
#include <fltk/LightButton.h>
#include "NleWidget.h"

class PosePDControllerWindow;

class NonLinearEditorWindow : public fltk::Window
{
	public:
		NonLinearEditorWindow(PosePDControllerWindow* posePDWindow, int w, int h, char* name);
		
		int handle(int event);
        void show();      
        void draw();
        
        
		EditorWidget* getEditorWidget();
		Block* getSelectedBlock();
        Track* getSelectedTrack();
  

		void updateGUI();

		static void changeStartTimeCB(fltk::Widget* widget, void* data);
		static void changeEndTimeCB(fltk::Widget* widget, void* data);
        static void changeTrackNameCB(fltk::Widget* widget, void* data);
        static void changeBlockNameCB(fltk::Widget* widget, void* data);

		static void AddTrackCB(fltk::Widget* widget, void* data);
		static void DeleteTrackCB(fltk::Widget* widget, void* data);
        static void MoveTrackUpCB(fltk::Widget* widget, void* data);
        static void MoveTrackDownCB(fltk::Widget* widget, void* data);

		static void AddBlockCB(fltk::Widget* widget, void* data);
		static void DeleteBlockCB(fltk::Widget* widget, void* data);

		static void MoveBlockLeftCB(fltk::Widget* widget, void* data);
		static void MoveBlockRightCB(fltk::Widget* widget, void* data);
		static void MoveBlockUpCB(fltk::Widget* widget, void* data);
		static void MoveBlockDownCB(fltk::Widget* widget, void* data);

		EditorWidget* nleWidget;

	private:
		fltk::FloatInput* inputBeginTime;
		fltk::FloatInput* inputEndTime;
        fltk::Input* inputTrackName;
        fltk::Input* inputBlockName;
		fltk::Button* buttonAddTrack;
		fltk::Button* buttonDeleteTrack;
        fltk::LightButton* buttonActivateTrack;
        fltk::Button* buttonAddBlock;
        fltk::Button* buttonDeleteBlock;
		fltk::Button* buttonBlockLeft;
		fltk::Button* buttonBlockRight;
		fltk::Button* buttonBlockUp;
		fltk::Button* buttonBlockDown;
        fltk::Button* buttonTrackUp;
        fltk::Button* buttonTrackDown;

		PosePDControllerWindow* posePDWindow;

};
#endif
