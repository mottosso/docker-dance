#include "PoseInterpreter.h"
#include "PosePDController.h"
#include <fltk/file_chooser.h>
#include "Pose.h"
#include "ScriptablePose.h"
#include "ArticulatedObject.h"
#include "Link.h"
#include "Joint.h"
#include "dance.h"
#include "Sensor.h"
#include "myvec.h"
#include "srs.h"
#include "noise.h"

Sensor* PoseInterpreter::sensor = NULL;
PosePDController* PoseInterpreter::controller = NULL;
PyObject* PoseInterpreter::pdict = NULL;
//std::vector<Pose*> PoseInterpreter::poseList;
//bool PoseInterpreter::computed = false;
double PoseInterpreter::reachValues[10][50];

void vcopy(float t[3], Vector s)
{
	t[0] = s[0] ;
	t[1] = s[1] ;
	t[2] = s[2] ;
}

void vcopy(Vector t, float s[3])
{
	t[0] = s[0] ;
	t[1] = s[1] ;
	t[2] = s[2] ;
}



PyMethodDef g_functions[] =
{
	{ "getTime", PoseInterpreter::getTime, METH_VARARGS, "() returns time" },
	{ "getTimeStep", PoseInterpreter::getTimeStep, METH_VARARGS, "() returns the current time step" },
	{ "getPosition", PoseInterpreter::getPosition, METH_VARARGS, "(pose, bodyNum) returns position (float[3])"},
	{ "getVelocity", PoseInterpreter::getVelocity, METH_VARARGS, "(pose, bodyNum) returns velocity (float[3])"},
	{ "getAngularVelocity", PoseInterpreter::getAngularVelocity, METH_VARARGS, "(pose, bodyNum) returns the angular velocity (float[3])"},
	{ "getRotationAxis", PoseInterpreter::getRotationAxis, METH_VARARGS, "(pose, bodyNum) returns the axis of rotation of a body (float[3])"},
	{ "getCenterMass", PoseInterpreter::getCenterMass, METH_VARARGS, "(pose) returns center of mass (float[3])"},
	{ "isLinkOnGround", PoseInterpreter::isLinkOnGround, METH_VARARGS, "(pose, bodyNum) returns if link is on the ground (bool)"},
	{ "isLinkColliding", PoseInterpreter::isLinkColliding, METH_VARARGS, "(pose, bodyNum) returns if link is in collision (bool)"},
	{ "getCMVelocity", PoseInterpreter::getCMVelocity, METH_VARARGS, "(pose) gets center of mass velocity (float[3])"},
	{ "getVelocityObj", PoseInterpreter::getVelocityObj, METH_VARARGS, "(string) gets velocity of an object by name (float[3])"},
	{ "setParam", PoseInterpreter::setParam, METH_VARARGS, "(pose, bodyNum, index, dof, ks, kd) set control parameters ()"},
	{ "getFacing", PoseInterpreter::getFacing, METH_VARARGS, "(pose) get facing for root/hip (float[3])"},
	{ "getUpVector", PoseInterpreter::getUpVector, METH_VARARGS, "(pose) get up vector for root/hip (float[3])"},
	{ "printString", PoseInterpreter::printString, METH_VARARGS, "(string) prints the input ()"},
	{ "printValueDouble", PoseInterpreter::printValueDouble, METH_VARARGS, "(floatvalue) or (floatvalue1, floatvalue2, floatvalue3) prints the input double or vector ()"},
	{ "printValueInt", PoseInterpreter::printValueInt, METH_VARARGS, "(intvalue) prints the input integer ()"},
	{ "getWorldQuaternion", PoseInterpreter::getWorldQuaternion, METH_VARARGS, "(pose, bodyNum) returns the orientation quaternion of link "
					"with respect to the world (float[4])"},
	{"setJointValuesFromCurrentState", PoseInterpreter::setJointValuesFromCurrentState, METH_VARARGS, 
					"(pose, jointNum) sets the control values for the joint from the current state ()"},
	//{ "addDictionaryInt", PoseInterpreter::addDictionaryInt, METH_VARARGS, "adds integer variables to the dictionary"},
	//{ "addDictionaryDouble", PoseInterpreter::addDictionaryDouble, METH_VARARGS, "adds double variables to the dictionary"},
	//{ "addDictionaryDict", PoseInterpreter::addDictionaryDict, METH_VARARGS, "adds a dictionary variable to the dictionary"},
	//{ "addDictionaryObject", PoseInterpreter::addDictionaryObject, METH_VARARGS, "adds an object variable to the dictionary"},
	//{ "loadPose", PoseInterpreter::loadPose, METH_VARARGS, "loads the pose specified by file"},
	//{ "setPose", PoseInterpreter::setPose, METH_VARARGS, "set the pose"}, 
	//{ "initPose", PoseInterpreter::initPose, METH_VARARGS, "init the parameters of a new pose of default values"},
	//{ "extractPose", PoseInterpreter::extractPose, METH_VARARGS, "Creates a new pose with the arg name using the current state.  Returns the index of the new pose."},
	//{ "isPoseSet", PoseInterpreter::isPoseSet, METH_VARARGS, "checks to see if the pose specified is set as the ao"},
	{ "getLerpJointFromStates", PoseInterpreter::getLerpJointFromStates,METH_VARARGS, "(pose, jointNum, state1[], state2[], interpolation) interpolate the joint values (float[])"},
	{ "interpolatePoses", PoseInterpreter::interpolatePoses, METH_VARARGS, "(pose, poseindex1, poseindex2, interpolation) interpolate the given poses and set the control values ()"},
	{ "getIndxFirstConDof", PoseInterpreter::getIndxFirstConDof, METH_VARARGS, "(pose) gets the index of the first controllable degree of freedom (int)"},
	{ "getStateSize", PoseInterpreter::getStateSize, METH_VARARGS, "(pose) gets the skeleton state size (int)"},
    { "getNumJoints", PoseInterpreter::getNumJoints, METH_VARARGS, "(pose) gets the number of joints/links (int)"},
    { "getJointStateSize", PoseInterpreter::getJointStateSize, METH_VARARGS, "(pose, jointNum) gets the number of joints/links (int)"},
    { "getState", PoseInterpreter::getState, METH_VARARGS, "(pose, stateIndex) gets the state value of a degree of freedom (float)"}, 
	{ "getEulerFromBall", PoseInterpreter::getEulerFromBall, METH_VARARGS, "(pose, jointNum, XYZorder) gets an euler decomposition of the orientation (float[3])"}, 
	{ "getOrientation", PoseInterpreter::getOrientation, METH_VARARGS, "(pose, bodyNum, vecx, vecy, vecz, targetBody) transforms a vector in body coordinates to world coordinates (float[3])"},
	{ "getCMRelativeDistance", PoseInterpreter::getCMRelativeDistance, METH_VARARGS, "(pose) gets the distance between the center of mass and the support polygon (float[3])"},
	{ "magic", PoseInterpreter::magic, METH_VARARGS, "(pose, x, y, z) adds force to counteract current velocity in direction indicated by x, y, z ()"},
	{ "magicBody", PoseInterpreter::magicBody, METH_VARARGS, "(pose, bodyNum, x, y, z) adds force to counteract body's velocity in direction indicated by x, y, z ()"},
	{ "magicBodyToBody", PoseInterpreter::magicBodyToBody, METH_VARARGS, "(pose, bodyNum, x, y, z, objectName) adds force to counteract body's velocity in direction indicated by x, y, z relative to otherBody ()"},
	{ "magicTorque", PoseInterpreter::magicTorque, METH_VARARGS, "(pose, bodyNum, x, y, z, objectName) adds torque to counteract body's angular velocity in direction indicated by x, y, z ()"},
	{ "reachOffset", PoseInterpreter::reachOffset, METH_VARARGS, "(pose, ikName, x, y, z, distance, elbowDirX, elbowDirY, elbowDirZ, offsetX, offsetY, offsetZ) sets IK chain to x,y,z location with given elbow direction and offset from end effector ()"}, 
	{ "reach", PoseInterpreter::reach, METH_VARARGS, "(pose, ikName, x, y, z, distance, elbowDirX, elbowDirY, elbowDirZ) sets IK chain to x,y,z location with given elbow direction ()"}, 
	{ "reachObject", PoseInterpreter::reachObject, METH_VARARGS,  "(pose, ikName, objectName, distance, x, y, z) sets IK chain to location indicated by objectName with given elbow direction ()"}, 
	{ "reachLink", PoseInterpreter::reachLink, METH_VARARGS, "(pose, ikName, objectName, linkName, elbowDirX, elbowDirY, elbowDirZ) sets IK chain to location indicated by linkName with given elbow direction ()"}, 
	{ "getPositionObject", PoseInterpreter::getPositionObject, METH_VARARGS, "(objectName) returns object position (float[3])"},
	{ "attachLink", PoseInterpreter::attachLink, METH_VARARGS, "(pose, linkNum, geometryName) attaches a link to static geometry ()"},
	{ "detachLink", PoseInterpreter::detachLink, METH_VARARGS, "(pose, linkNum, geometryName) detaches a link from geometry ()"},
	{ "isAttached", PoseInterpreter::isAttached, METH_VARARGS, "(pose, linkNum, geometryName) checks to see if given link is attached (int)"},
	{ "attachLinkStatic", PoseInterpreter::attachLinkStatic, METH_VARARGS, "(pose, linkNum, geometryName) attaches a link to static geometry ()"},
	{ "attachLinkAO", PoseInterpreter::attachLinkAO, METH_VARARGS, "(pose, linkNum, targetSkeleton, targetLink) attaches a link to another link on a different skeleton ()"},
	{ "detachLinkStatic", PoseInterpreter::detachLinkStatic, METH_VARARGS, "(pose, linkNum, geometryName) detaches a link from static geometry ()"},
	{ "detachLinkAO", PoseInterpreter::detachLinkAO, METH_VARARGS, "(pose, linkNum, targetSkeleton, targetLink) dettaches a link to another link on a different skeleton ()"},
	{ "isAttachedStatic", PoseInterpreter::isAttachedStatic, METH_VARARGS, "(pose, linkNum, geometryName) checks to see if given link is attached to static geometry ()"},
	{ "isAttachedAO", PoseInterpreter::isAttachedAO, METH_VARARGS, "(pose, linkNum, targetSkeleton, targetLink) checks to see if given link is attached to a particular link on another skeleton ()"},
	{ "getPositionLink", PoseInterpreter::getPositionLink, METH_VARARGS, "(objectName, linkNum) gets a link's position (float[3])"},
	{ "getJointPosition", PoseInterpreter::getJointPosition, METH_VARARGS, "(pose, jointNum) gets a joint's position (float[3])"},
	{ "getSimIndex", PoseInterpreter::getSimIndex, METH_VARARGS, "(pose, linkIndex, dofIndex) given the link and dof index it returns the equivalent simulator index (integer)"},
	{ "setJoint1", PoseInterpreter::setJoint1, METH_VARARGS, "(pose, jointNumber, position) sets the joint position in radians of a pin joint ()"},
	{ "setJoint2", PoseInterpreter::setJoint2, METH_VARARGS, "(pose, jointNumber, position1, position2) sets the joint position in radians of a universal joint ()"},
	{ "setJoint3", PoseInterpreter::setJoint3, METH_VARARGS, "(pose, jointNumber, position1, position2, position3) sets the joint position of a gimbal joint ()"},
	{ "setJoint4", PoseInterpreter::setJoint4, METH_VARARGS, "(pose, jointNumber, q1, q2, q3, q4) sets the joint position of a ball joint as quaternion values ()"},
	{ "setJoint4Euler", PoseInterpreter::setJoint4Euler, METH_VARARGS, "(pose, jointNumber, x, y, z sets the joint position of a ball joint as Euler values in radians ()"},
	{ "setJointKsKd1", PoseInterpreter::setJointKsKd1, METH_VARARGS, "(pose, jointNum, ks, kd) sets the ks and kd of a pin joint ()"},
	{ "setJointKsKd2", PoseInterpreter::setJointKsKd2, METH_VARARGS, "(pose, jointNum, ks1, kd1, ks2, kd2) sets the ks and kd of a universal joint ()"},
	{ "setJointKsKd3", PoseInterpreter::setJointKsKd3, METH_VARARGS, "(pose, jointNum, ks1, kd1, ks2, kd2, ks3, kd3) sets the ks and kd of a gimbal joint ()"},
	{ "setJointKsKd4", PoseInterpreter::setJointKsKd4, METH_VARARGS, "(pose, jointNum, ks1, kd1, ks2, kd2, ks3, kd3) sets the ks and kd of a gimbal joint ()"},
	{ "getControlParam", PoseInterpreter::getControlParam, METH_VARARGS, "(pose, linkNum, dofNum, param) get a single control param by linkNum, dof, param (0=driveType,1=v,2=ks,3=kd,4=maxTorque) (float)"},
	{ "setControlParam", PoseInterpreter::setControlParam, METH_VARARGS, "(pose, linkNum, dofNum, param, value) set a single control param by linkNum, dof, param (0=driveType,1=v,2=ks,3=kd,4=maxTorque) and value ()"},
	{ "getControlParams", PoseInterpreter::getControlParams, METH_VARARGS, "(pose, linkNum, dof) get the control params by linkNum, dof, returns an array holding values ([DriveType,v,KS,KD,MaxTorque])"},
	{ "noise", PoseInterpreter::noise, METH_VARARGS, "(key) returns one-dimensional Perlin noise (float)"},
	{ "setControlUpdateFrequency", PoseInterpreter::setControlUpdateFrequency, METH_VARARGS, "(pose, rate) sets the number of timesteps per control execution ()"},
	{ "getControlUpdateFrequency", PoseInterpreter::getControlUpdateFrequency, METH_VARARGS, "(pose) gets the number of timesteps per control execution (float)"},
	{ "setFootFlat",PoseInterpreter::setFootFlat, METH_VARARGS, "(pose, linkNum, eulerOrder) sets control parameters so that the foot is flat ()"},
	{ "getWorldZeroXYZAngles", PoseInterpreter::getWorldZeroXYZAngles, METH_VARARGS, "(pose, linkNum) returns an array of XYZ euler angles that will make the arg link's world orientation zero.(x, y, z)" },
	{ "setTargetPose", PoseInterpreter::setTargetPose, METH_VARARGS, "(pose, poseNum) sets the current pose to the given index (starting with 0) ()"},
	{ "setTargetPoseByName", PoseInterpreter::setTargetPoseByName, METH_VARARGS, "(pose, poseName) Sets the current pose to pose with the indicated name ()"},
	{ "getJointFromPose", PoseInterpreter::getJointFromPose, METH_VARARGS, "(pose, poseIndex, jointIndex) gets a joint position from the indicated pose (float[numDof])."},
	{ "setPythonController", PoseInterpreter::setPythonController, METH_VARARGS, "(pose, self) Sets the active scriptable controller."},
	{ "getNearestPointOnSupportPolygon", PoseInterpreter::getNearestPointOnSupportPolygon, METH_VARARGS, "(pose) returns a 3-element array containing the point on the support polygon closest to the character's ground-projected center of mass (float[3])."},
	{ "getDistToSupportPolygon", PoseInterpreter::getDistToSupportPolygon, METH_VARARGS, "(pose) returns the (signed) distance from the character's ground-projected center of mass to the closest point on the support polygon.  The distance if positive if the CM is inside the support polygon. (float[3])"},	
	{ "applyImpulseToLink", PoseInterpreter::applyImpulseToLink, METH_VARARGS, "(pose, bodyNum, x, y, z) apply an impulse to the skeleton's link in direction x, y, z ()"},
	{ "setLinkKinematic", PoseInterpreter::setLinkKinematic, METH_VARARGS, "(pose, bodyNum, x, y, z, q1, q2, q3, q4) sets a body in kinematic mode to position x,y,z and orientation q1,q2,q3,q4 ()"},	
	{ "addPoint", PoseInterpreter::addPoint, METH_VARARGS, "(pose, name, x, y, z) or (pose, name, x, y, z, colorr, colorg, colorb) draws a point on the screen at location x, y, z ()"},
	{ "removePoint", PoseInterpreter::removePoint, METH_VARARGS, "(pose, name) removes point with given name from the screen ()"},
	{ "addLine", PoseInterpreter::addLine, METH_VARARGS, "(pose, name, fromx, fromy, fromz, tox, toy, toz) or (pose, name, fromx, fromy, fromz, tox, toy, toz, colorr, colorg, colorb)draws a line on the screen at from fromx, fromy, fromz to tox, toy, toz()"},
	{ "removeLine", PoseInterpreter::removeLine, METH_VARARGS, "(pose, name) removes a line with given name from the screen ()"},
	{ "clearGraphics", PoseInterpreter::clearGraphics, METH_VARARGS, "(pose) removes all points, lines and graphical shapes."},

	{ "getNumCollisionPoints", PoseInterpreter::getNumCollisionPoints, METH_VARARGS, "(pose, linkNum) gets the number of collision points on a link (int)"},
	{ "getCollisionPoint", PoseInterpreter::getCollisionPoint, METH_VARARGS, "(pose, linkNum, pointNum) gets the position of a particular collision point on a link (float[3])"},
	{ "getLinkPointWorld", PoseInterpreter::getLinkPointWorld, METH_VARARGS, "(pose, linkNum, x, y, z) gets the position of a point on a link in world space (float[3])"},
	{ "getLinkPointLocal", PoseInterpreter::getLinkPointLocal, METH_VARARGS, "(pose, linkNum, x, y, z) gets the position of a point on a link in local space (float[3])"},
	

	{NULL, NULL}
};





/// Gets the pose pointer from the python object
/// that contains the PosePDController pointer
static Pose *getPoseFromPPointer(PyObject *p)
{
	void *ptemp = PyCObject_AsVoidPtr(p) ;
	if( ptemp == NULL ) return NULL ;

	return (Pose *) ptemp ;
}

/// Gets the controller pointer from the python object
/// that contains the PosePDController pointer
static PosePDController *getPDCfromPPointer(PyObject *p)
{
	void *ptemp = PyCObject_AsVoidPtr(p) ;
	if( ptemp == NULL ) return NULL ;

	PosePDController *s = (PosePDController *) ((Pose *) ptemp)->getController() ;
	return s ;
}

/// Shortcut function. Gets the sensor pointer from the python object
/// that contains the pose pointer
static Sensor *getSensorFromPPointer(PyObject *p)
{
	void *ptemp = PyCObject_AsVoidPtr(p) ;
	if( ptemp == NULL ) return NULL ;

	PosePDController *pdc = (PosePDController *) ((Pose *) ptemp)->getController() ;

	if( !pdc )
	{
		danceInterp::OutputMessage("ERROR: No controller present!") ;
		return NULL ;
	}
	else
		return pdc->getSensor() ;
}

static bool getPointersFromPython(PyObject *pp, PosePDController **pdc, Sensor **s)
{
	void *ptemp = PyCObject_AsVoidPtr(pp) ;
	if( ptemp == NULL ) 
	{
		danceInterp::OutputMessage("getPointersFromPython: pointer to PyObject passed was null.  Aborting.") ;
		return false ;
	}

	*pdc = (PosePDController *) ((Pose *) ptemp)->getController() ;
	if( *pdc == NULL )
	{
		danceInterp::OutputMessage("getPointersFromPython: No PosePDController present") ;
		return false ;
	}

	*s = (*pdc)->getSensor() ;
	if( !(*s) )
	{
		danceInterp::OutputMessage("getPointersFromPython: PoseController %s has no sensor present", (*pdc)->getName()) ;
		return false ;

	}
	return true ;
}

PoseInterpreter::PoseInterpreter(Sensor *s, PosePDController* c)
{
	this->sensor = s;
	this->pdict = NULL;
	this->pm = NULL;
	this->controller = c;
	//this->computed = false;
	//this->poseList = NULL;
}

PoseInterpreter::~PoseInterpreter()
{
	this->pdict = NULL;
	this->pm = NULL;

	if (PoseInterpreter::sensor != NULL)
		PoseInterpreter::sensor = NULL;

	//for (int i = 0; i < this->poseList.size(); i++)
	//{
	//	delete poseList[i];
	//}
	//this->poseList.clear();
}

void PoseInterpreter::Init()
{

    // register the functions
    this->pm = Py_InitModule( "PoseInterpreter", g_functions );
	
    
	/// retrieve the main module and dictionary
	PyObject *pMainModule     = PyImport_AddModule( "__main__" );
	PyObject *pMainDictionary = PyModule_GetDict( pMainModule );

	PyObject *p1 = PyRun_String(
		"import PoseInterpreter as pi\n",Py_file_input,pMainDictionary,pMainDictionary) ;	

}

void PoseInterpreter::controllerInit()
{	
	//PyDict_Clear(this->pdict);
	//this->pm = Py_InitModule( "PoseIntepreter", g_functions );
	//this->pdict = PyModule_GetDict(pm) ;

	//PyDict_SetItemString(this->pdict, "__builtins__", PyEval_GetBuiltins());
	//PyDict_SetItemString(this->pdict, "init", Py_BuildValue("i", 1));
//for (int i = 0; i < PoseInterpreter::poseList.size(); i++)
//{
//	delete PoseInterpreter::poseList[i];
//}
//PoseInterpreter::poseList.clear();

	//PoseInterpreter::computed = false;
}

PyObject* PoseInterpreter::scriptError(std::string function)
{
	return scriptError(function, "");
}

PyObject* PoseInterpreter::scriptError(std::string function, const char *format, ...)
{
	if (format != "")
		danceInterp::OutputMessage(format);

	PyErr_Print();
	PyErr_Clear();
	return Py_BuildValue("");
}

//C++ wrapper functions
PyObject* PoseInterpreter::getTime(PyObject *self, PyObject *args)
{
	double result = dance::AllSimulators->getCurrentTime();
	return Py_BuildValue("d", result);
}

PyObject* PoseInterpreter::getTimeStep(PyObject *self, PyObject *args)
{
	double result = dance::AllSimulators->getSimulationTimeStep();
	return Py_BuildValue("d", result);
}


PyObject* PoseInterpreter::getPosition(PyObject *self, PyObject *args)
{
	std::string funcName = "getPosition()";
	double value;
	Vector v;

	PyObject *cPointer ;
	int ok = PyArg_Parse(args, "(Od)", &cPointer, &value);

	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(cPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	s->getPosition(value, v);
	return Py_BuildValue("[ddd]", v[0], v[1], v[2]);
}

PyObject* PoseInterpreter::getVelocity(PyObject *self, PyObject *args)
{
	std::string funcName = "getVelocity()";
	int bodyNum;
	Vector v;

	PyObject *cPointer ;
	int ok = PyArg_Parse(args, "(Oi)",&cPointer, &bodyNum);
	if (!ok)
		return scriptError(funcName);
  
	Sensor *s = getSensorFromPPointer(cPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	s->getVelocity(bodyNum, v);
	return Py_BuildValue("[ddd]", v[0], v[1], v[2]);
}

PyObject* PoseInterpreter::getAngularVelocity(PyObject *self, PyObject *args)
{
	std::string funcName = "getAngularVelocity()";
	int bodyNum;
	Vector v;

	PyObject *cPointer ;
	int ok = PyArg_Parse(args, "(Oi)",&cPointer, &bodyNum);
	if (!ok)
		return scriptError(funcName);
  
	Sensor *s = getSensorFromPPointer(cPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	s->getAngularVelocity(bodyNum, v);
	return Py_BuildValue("[ddd]", v[0], v[1], v[2]);
}

PyObject* PoseInterpreter::getRotationAxis(PyObject *self, PyObject *args)
{
	std::string funcName = "getRotationAxis()";
	int bodyNum;
	Vector v;

	PyObject *cPointer ;
	int ok = PyArg_Parse(args, "(Oi)",&cPointer, &bodyNum);
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(cPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");
	
	Link* link = ao->getLink(bodyNum);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", bodyNum);

	// get the angular velocity
	s->getAngularVelocity(bodyNum, v);
	VectorObj angVel(v[0], v[1], v[2]);

	// get the moment of inertia
	double inertia[3][3];
	link->getInerTensor(inertia);
	// calculate the current moment of inertia
	
	Vector axis;
	setVector(axis, 0, 1, 0);
	
	double origTensorMatrix[3][3];
	link->getInerTensor(origTensorMatrix);
	Vector com;
	link->getCenterMass(com);
	InertiaTensor inertiaTensor(origTensorMatrix, link->getMass(), com);
	double worldMatrix[4][4];
	link->getWTransMat(worldMatrix);
	inertiaTensor.transform(worldMatrix);
	Matrix3x3 tensor3x3 = inertiaTensor.getInertia();
	VectorObj rotationAxis = tensor3x3 * angVel;
	VectorObj normRotationAxis = rotationAxis.normalize();

	return Py_BuildValue("[ddd]", normRotationAxis[0], normRotationAxis[1], normRotationAxis[2]);
}

PyObject* PoseInterpreter::getSimIndex(PyObject *self, PyObject *args)
{
	std::string funcName = "getSimIndex()";

	PyObject *cPointer ;
	int linkIndex, dofIndex;
	int ok = PyArg_ParseTuple(args, "Oii", &cPointer, &linkIndex, &dofIndex);
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(cPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");

	int index = sim->GetIndex(linkIndex,dofIndex) ;
	return Py_BuildValue("i",index) ;
}



PyObject* PoseInterpreter::setPythonController(PyObject* self, PyObject* args)
{
	std::string funcName = "setPythonController()";

	PyObject *pPointer, *pcontroller ;
	int ok = PyArg_ParseTuple(args, "OO", &pPointer, &pcontroller) ;
	if (!ok)
		return scriptError(funcName);

	Pose *p = getPoseFromPPointer(pPointer) ;
	if( !p ) return Py_BuildValue("");

	ScriptablePose *sp = (ScriptablePose *) p ;
	sp->setPythonController(pcontroller) ;

	return Py_BuildValue("");
}


/// Provides a single value from the Control Params.
/// Arguments: linkIdx, dofIdx, paramIdx
/// paramIdx is:
///  0 - driveType, int
///  1 - v, double
///  2 - ks, double
///  3 - kd, double
///  4 - maxTorque, double
PyObject* PoseInterpreter::getControlParam( PyObject* self, PyObject* args )
{
	std::string funcName = "getControlParam()";
	int linkIndex, dofIndex, paramIndex;

	PyObject *pPointer ;
	int ok = PyArg_ParseTuple(args, "Oiii", &pPointer, &linkIndex, &dofIndex, &paramIndex);
	if (!ok)
		return scriptError(funcName);

	PosePDController *pdc ;
	Sensor *s ;
	if( !getPointersFromPython(pPointer, &pdc, &s) ) return Py_BuildValue("");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");

	int simIndex = sim->GetIndex(linkIndex,dofIndex) ;
	if( simIndex < 0 )
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	int aoIndex = pdc->convertIndexSimtoAO( simIndex );
	if( aoIndex < 0 )
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	PDParams& pdp = pdc->getPDParams( aoIndex );

	switch( paramIndex )
	{
	case 0:
		return Py_BuildValue( "i", pdp.driveType );
		break;
	case 1:
		return Py_BuildValue( "d", pdp.v );
		break;
	case 2:
		return Py_BuildValue( "d", pdp.ks );
		break;
	case 3:
		return Py_BuildValue( "d", pdp.kd );
		break;
	case 4:
		return Py_BuildValue( "d", pdp.maxTorque );
		break;
	default:
		danceInterp::OutputMessage("PoseInterpreter::getControlParam: index out of bounds!") ;
		return Py_BuildValue("") ;
	}
}


/// getControlParam provides a copy of the controller's "m_param" array.
/// Caution: this is relatively inefficient.  See getControlParam() for a faster version.
/// Expected inputs are ( int jointIndex, int dofIndex )
/// All joints have four dofIndecies, but most only use a subset.  E.g., pin joints use only one.
/// The returned PDParams structure is provided as a python Array object
/// with indices for the PDParams fields:
/// DriveType -- the type of drive used by this joint.  Only meaningful for the first DOF of a joint.
///           -- possible values are defined in PDParams.h as:  
///           -- PositionDrive=0, VelocityDrive=1, SpringDrive=2 (default), TorqueDrive=3, TimeSpringDrive=4
/// V         -- the "value" for the joint.  Angular position for SpringDrives, desired torque 
///           -- for TorqueDrives, and desired velocity for VelocityDrives, and the time to pose for TimeSpringDrive.
/// KS        -- only used for SpringDrives, the proportional spring constant (aka, K_p)
/// KS        -- only used for SpringDrives, the damping constant
/// MaxTorque -- the maximum torque to be applied, superceeding other parameters.
PyObject* PoseInterpreter::getControlParams( PyObject* self, PyObject* args )
{
	std::string funcName = "getControlParams()";

	int linkIndex, dofIndex;
	PyObject *pPointer ;

	int ok = PyArg_ParseTuple(args, "Oii", &pPointer, &linkIndex, &dofIndex);
	if (!ok)
		return scriptError(funcName);

	PosePDController *pdc ;
	Sensor *s ;
	if( !getPointersFromPython(pPointer, &pdc, &s) ) return Py_BuildValue("");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");

	int simIndex = sim->GetIndex( linkIndex, dofIndex ) ;
	int aoIndex = pdc->convertIndexSimtoAO( simIndex );
	PDParams& pdp = pdc->getPDParams( aoIndex );

	return Py_BuildValue("[i,d,d,d,d]",
		pdp.driveType,
		pdp.v,
		pdp.ks,
		pdp.kd,
		pdp.maxTorque
	) ;	
}

/// Sets a single value in the Control Params.
/// Arguments: linkIdx, dofIdx, paramIdx, newValue
/// paramIdx is:
///  0 - driveType, int
///  1 - v, double
///  2 - ks, double
///  3 - kd, double
///  4 - maxTorque, double
PyObject* PoseInterpreter::setControlParam( PyObject* self, PyObject* args )
{
	std::string funcName = "setControlParam()";

	int linkIndex, dofIndex, paramIndex;
	double value;
	PyObject *pPointer ;
	int ok = PyArg_ParseTuple(args, "Oiiid", &pPointer, &linkIndex, &dofIndex, &paramIndex, &value );
	if (!ok)
		return scriptError(funcName);

	PosePDController *pdc ;
	Sensor *s ;
	if( !getPointersFromPython(pPointer, &pdc, &s) ) 
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");

	int simIndex = sim->GetIndex(linkIndex,dofIndex) ;
	if( simIndex < 0 )
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue( "" );
	}
	int aoIndex = pdc->convertIndexSimtoAO( simIndex );
	if( aoIndex < 0 )
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue( "" );
	}
	PDParams& pdp = pdc->getPDParams( aoIndex );

	switch( paramIndex )
	{
	case 0:
		pdp.driveType = (DriveType)((int)value);
		break;
	case 1:
		pdp.v = value;
		break;
	case 2:
		pdp.ks = value;
		break;
	case 3:
		pdp.kd = value;
		break;
	case 4:
		pdp.maxTorque = value;
		break;
	}
	//danceInterp::OutputMessage("value in control paramas %f", pdp.v) ;
	return Py_BuildValue( "" );
}


PyObject* PoseInterpreter::setJointValuesFromCurrentState(PyObject *self, PyObject *args)
{
	std::string funcName = "setJointValuesFromCurrentState()";

	PyObject *pPointer ;
	int jointNumber ;
	int ok = PyArg_Parse(args, "(Oi)", &pPointer, &jointNumber ) ;
	if (!ok)
		return scriptError(funcName);

	// get pointer and check for errors
	Pose *p = getPoseFromPPointer(pPointer) ;
	if( !p )
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::setJointValuesFromCurrentState() could not obtain pose from posePointer argument." );
		return Py_BuildValue("");
	}
	PosePDController *pdc = p->getController() ;
	if( !pdc )
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::setJointValuesFromCurrentState() could not obtain PosePDController from pose." );
		return Py_BuildValue("");
	}
	Sensor *s = pdc->getSensor() ;
	if( !s ) 
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::setJointValuesFromCurrentState() could not obtain Sensor from PosePDController." );
		return Py_BuildValue("");
	}

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator *sim = ao->getSimulator(0) ;
	if( !sim ) 
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::setJointValuesFromCurrentState() could not obtain Simulator from Sensor." );
		return Py_BuildValue("");
	}

	Joint *joint = ao->getJoint(jointNumber) ;
	if( ! joint )
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::setJointValuesFromCurrentState() could not obtain"
			"joint from Articulated Object." );
		return Py_BuildValue("");
	}

	// get the starting index of the joint
	int startIndex = ao->getStateMapping(jointNumber, 0);
	// make sure that the joint is a ball joint
	for( int i = 0 ; i < joint->getStateSize() ; i++)
	{
		pdc->setParam(startIndex+i, joint->getState(i));
	}
	return Py_BuildValue("");
}

PyObject* PoseInterpreter::getCenterMass(PyObject *self, PyObject *args)
{
	std::string funcName = "getCenterMass()";

	PyObject *pPointer ;
	int ok = PyArg_ParseTuple(args, "O", &pPointer) ;
	if (!ok)
	if (!ok)
		return scriptError(funcName);

	PosePDController *pdc ;
	Sensor *s ;
	if( !getPointersFromPython(pPointer, &pdc, &s) ) 
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	Vector v;
	s->getCenterMass(v);

	return Py_BuildValue("[ddd]", v[0], v[1], v[2]);
}

PyObject* PoseInterpreter::isLinkOnGround(PyObject *self, PyObject *args)
{
	std::string funcName = "isLinkOnGround()";

	int value;
	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Oi)", &pPointer, &value);
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	bool result = s->isLinkOnGround(value);
	if (result == true)
		value = 1;
	else
		value = 0;

	return Py_BuildValue("i", value);
	
}
	
PyObject* PoseInterpreter::isLinkColliding(PyObject *self, PyObject *args)
{
	std::string funcName = "isLinkColliding()";

	double value;
	int boolean;
	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Od)", &pPointer, &value);
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	bool result = s->isLinkColliding(value);
	if (result == true)
		boolean = 1;
	else
		boolean = 0;

	return Py_BuildValue("i", boolean);
}

PyObject* PoseInterpreter::getCMVelocity(PyObject *self, PyObject *args)
{
	std::string funcName = "getCMVelocity()";

	PyObject *pPointer ;
	int ok = PyArg_ParseTuple(args, "O", &pPointer) ;
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	Vector v;
	s->getCMVelocity(v);

	return Py_BuildValue("[ddd]", v[0], v[1], v[2]);
}

PyObject* PoseInterpreter::getFacing(PyObject* self, PyObject* args)
{
	std::string funcName = "getFacing()";

	PyObject *pPointer ;
	int ok = PyArg_ParseTuple(args, "O", &pPointer) ;
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	Vector v;
	s->getFacing(v);
	
	return Py_BuildValue("[ddd]", v[0], v[1], v[2]);
}

PyObject* PoseInterpreter::getUpVector(PyObject* self, PyObject* args)
{
	std::string funcName = "getUpVector()";

	PyObject *pPointer ;
	int ok = PyArg_ParseTuple(args, "O", &pPointer) ;
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	Vector v;
	s->getUpVector(v);

	return Py_BuildValue("[ddd]", v[0], v[1], v[2]);
}

PyObject* PoseInterpreter::computeCM(PyObject* self, PyObject* args)
{
	std::string funcName = "computeCM()";

	PyObject *pPointer ;
	int ok = PyArg_ParseTuple(args, "O", &pPointer) ;
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	Vector v;
	s->computeCM(v);

	return Py_BuildValue("[ddd]", v[0], v[1], v[2]);
}

PyObject* PoseInterpreter::getIndxFirstConDof(PyObject* self, PyObject* args)
{
	std::string funcName = "getIndxFirstConDof()";

	PyObject *pPointer ;
	int ok = PyArg_ParseTuple(args, "O", &pPointer) ;
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	int val = s->getIndxFirstConDof();

	return Py_BuildValue("i", val);
}

PyObject* PoseInterpreter::getStateSize(PyObject* self, PyObject* args)
{
	std::string funcName = "getStateSize()";

	PyObject *pPointer ;
	int ok = PyArg_ParseTuple(args, "O", &pPointer) ;
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	int val = s->getStateSize();

	return Py_BuildValue("i", val);
}

PyObject* PoseInterpreter::getNumJoints(PyObject* self, PyObject* args)
{
	std::string funcName = "getNumJoints()";

    PyObject *pPointer ;
    int ok = PyArg_ParseTuple(args, "O", &pPointer) ;
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

    int val = s->getNumJoints();

    return Py_BuildValue("i", val);
}

PyObject* PoseInterpreter::getJointStateSize(PyObject* self, PyObject* args)
{
	std::string funcName = "getJointStateSize()";

    PyObject *pPointer ;
    int jointNum;
    int ok = PyArg_ParseTuple(args, "Oi", &pPointer, &jointNum) ;
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	int numJoints = s->getNumJoints();
    if (jointNum < 0 || jointNum == numJoints)
    {
        danceInterp::OutputMessage("Joint index %d not valid. Only %d joints.", jointNum, numJoints);
        PyErr_Print();
        PyErr_Clear();
        return  Py_BuildValue("");
    }
    
    DSystem* sys = s->getSystem();
    ArticulatedObject* artObj = dynamic_cast<ArticulatedObject*>(sys);
    
    Joint* joint = artObj->getJoint(jointNum);
    
    int val = joint->getStateSize();

    return Py_BuildValue("i", val);
}



PyObject* PoseInterpreter::getState(PyObject* self, PyObject* args)
{
	std::string funcName = "getState()";

	int index;
	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Oi)", &pPointer, &index);
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	double val = s->getState(index);
	return Py_BuildValue("d", val);
}

PyObject* PoseInterpreter::getEulerFromBall(PyObject* self, PyObject* args)
{
	std::string funcName = "getEulerFromBall()";

	int jnum, order;
	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Oii)", &pPointer, &jnum, &order);
	if (!ok)
		return scriptError(funcName);

	danceInterp::OutputMessage("ERROR: FUNCTION NOT IMPLEMENTED YET") ;
	assert( false );
	double euler[3] = { 0, 0, 0 }  ;
	//s->getEulerFromBall(jnum, order, euler);
	return Py_BuildValue("[ddd]", euler[0], euler[1], euler[2]);
}

PyObject* PoseInterpreter::getOrientation(PyObject* self, PyObject * args)
{
	std::string funcName = "getOrientation()";

	Vector v1, v2;
	double source, target;

	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Oidddi)", &pPointer, &source, &v1[0], &v1[1], &v1[2], &target);
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	s->getOrientation(source, v1, target, v2);
	return Py_BuildValue("[ddd]", v1[0], v1[1], v1[2]);

}

PyObject* PoseInterpreter::setParam(PyObject* self, PyObject* args)
{
	std::string funcName = "setParam()";

	int index;
	double position, ks, kd;
	PyObject *pPointer ;
	int ok = PyArg_ParseTuple(args, "Oiddd", &pPointer, &index, &position, &ks, &kd);
	if (!ok)
		return scriptError(funcName);
 
	PosePDController *pdc = getPDCfromPPointer(pPointer) ;
	pdc->setParam(index, position, ks, kd);
	return Py_BuildValue("");
}

PyObject* PoseInterpreter::getCMRelativeDistance(PyObject* self, PyObject* args)
{
	std::string funcName = "getCMRelativeDistance()";

	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(O)", &pPointer );
	if (!ok)
		return scriptError(funcName);
	
	Vector dist;
	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	s->getCMRelativeDistance(dist);

	return Py_BuildValue("[ddd]", dist[0], dist[1], dist[2]);
}

//just for testing. will slow down the sim step
PyObject* PoseInterpreter::printString(PyObject* self, PyObject* args)
{
	std::string funcName = "printString()";

	char* message;
	int ok = PyArg_Parse(args, "(s)", &message);
	if (!ok)
		return scriptError(funcName);


	if (ok)
		danceInterp::OutputMessage("%s", message);
	return Py_BuildValue("");
}

//PyObject* PoseInterpreter::addDictionaryInt(PyObject* self, PyObject* args)
//{
//	
//	char* value;
//	int num;
//	int ok = PyArg_Parse(args, "(si)", &value, &num);
//	if (ok)
//	{
//		PyObject* tmp = Py_BuildValue("i", num);
//		PyDict_SetItemString(PoseInterpreter::pdict, value, tmp);
//	}
//	else
//	{
//		PyErr_Print();
//		PyErr_Clear();
//	}
//	return Py_BuildValue("");
//}

//PyObject* PoseInterpreter::addDictionaryDouble(PyObject* self, PyObject* args)
//{
//	if (PoseInterpreter::sensor == NULL || PoseInterpreter::controller == NULL)
//		return Py_BuildValue("");
//
//	char* value;
//	double num;
//	int ok = PyArg_Parse(args, "(sd)", &value, &num);
//	if (ok)
//	{
//		PyObject* tmp = Py_BuildValue("d", num);
//		PyDict_SetItemString(PoseInterpreter::pdict, value, tmp);
//	}
//	else
//	{
//		PyErr_Print();
//		PyErr_Clear();
//	}
//	return Py_BuildValue("");
//}
//
//PyObject* PoseInterpreter::addDictionaryDict(PyObject* self, PyObject* args)
//{
//	if ( PoseInterpreter::controller == NULL )
//		return Py_BuildValue("");
//
//	char* name;
//	PyObject* dict;
//
//	// don't actually "parse" the dictionary, just get a pointer to it
//	int ok = PyArg_ParseTuple(args, "sO", &name, &dict );
//	if (ok)
//	{
//		PyObject* tmp = PyDict_Copy(dict);
//		if( !tmp )
//		{
//			PyErr_Print();
//			PyErr_Clear();
//		}
//		else
//		{
//			PyDict_SetItemString(PoseInterpreter::pdict, name, tmp);
//		}
//	}
//	else
//	{
//		PyErr_Print();
//		PyErr_Clear();
//	}
//	return Py_BuildValue("");
//}
//
//PyObject* PoseInterpreter::addDictionaryObject(PyObject* self, PyObject* args)
//{
//	if ( PoseInterpreter::controller == NULL )
//		return Py_BuildValue("");
//
//	char* name;
//	PyObject* obj;
//
//	// don't actually "parse" the dictionary, just get a pointer to it
//	int ok = PyArg_ParseTuple(args, "sO", &name, &obj );
//	if (ok)
//	{
//		PyDict_SetItemString(PoseInterpreter::pdict, name, obj);
//	}
//	else
//	{
//		PyErr_Print();
//		PyErr_Clear();
//	}
//	return Py_BuildValue("");
//}
//

PyObject* PoseInterpreter::printValueInt(PyObject* self, PyObject* args)
{
	std::string funcName = "printValueInt()";

	int value;

	int ok = PyArg_Parse(args, "(i)", &value);
	if (!ok)
		return scriptError(funcName);

	if (ok)
		danceInterp::OutputMessage("%i", value);
	return Py_BuildValue("");
}

PyObject* PoseInterpreter::printValueDouble(PyObject* self, PyObject* args)
{
	std::string funcName = "printValueDouble()";

	double v0, v1, v2, value;
	int ok = PyArg_Parse(args, "(d)", &value);
	if (!ok)
		return scriptError(funcName);

	if (ok)
	{
		danceInterp::OutputMessage("%f", value);
		return Py_BuildValue("");
	}
	else
	{
		//PyErr_Print();
		PyErr_Clear();
		//return Py_BuildValue("");

		int ok2 = PyArg_Parse(args, "(ddd)", &v0, &v1, &v2);
		if (ok2)
			danceInterp::OutputMessage("%f %f %f", v0, v1, v2);
		else
		{
			PyErr_Print();
			PyErr_Clear();   
		}
	}
	return Py_BuildValue("");
}

PyObject* PoseInterpreter::loadPose(PyObject* self, PyObject* args)
{
	std::string funcName = "loadPose()";

	//need something to indicate false

	PyObject *pPointer ;
	char* filename;
	int ok = PyArg_Parse(args, "(Os)", &pPointer, &filename);
	if (!ok)
		return scriptError(funcName);

	ScriptablePose *pose = (ScriptablePose *) getPoseFromPPointer(pPointer) ;
	if( !pose)  return Py_BuildValue("");


	std::string strfile = filename;
	std::ifstream file(filename, std::ios::in);
	if (!file.good())
	{
		danceInterp::OutputMessage("Pose file '%s' is not valid.\n", filename);
		return Py_BuildValue("");
	}
	Pose* p = new Pose(MAX_STATE);
	p->setDefaultKs(pose->getController()->getKS());
	p->setDefaultKd(pose->getController()->getKD());

	bool success = p->parse(file);

	if (success == false)
	{
		delete p;
		return Py_BuildValue("d", -1.0);
	}

	int dotpos = strfile.find_last_of(".");
	int slashPos = strfile.find_last_of("\\");
	int slash2Pos = strfile.find_last_of("/");
	if (slashPos > slash2Pos)
		slash2Pos = slashPos;

	std::string name = strfile.substr(slash2Pos + 1, dotpos - (slash2Pos + 1));
	p->setName(name);

	double index  = pose->poseList.size();
	pose->poseList.push_back(p);
	
	return Py_BuildValue("d", index);
}

PyObject* PoseInterpreter::setPose(PyObject* self, PyObject* args)
{
	std::string funcName = "setPose()";

	int index;
	char* filename;
	std::string name = "";

	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Oi)", &pPointer, &index);
	if (!ok)
	{
		PyErr_Clear();
		int okString = PyArg_Parse(args, "(Os)", &pPointer, &filename);
		if (!ok && !okString)
			return scriptError(funcName);

		name = filename;
	}

	ScriptablePose *pose = (ScriptablePose *) getPoseFromPPointer(pPointer) ;
	if( !pose)  return Py_BuildValue("");

	Pose* p = 0;
	if (name != "")
	{
		for (int i = 0; i < pose->poseList.size(); i++)
		{
			std::string poseName = pose->poseList[i]->getName();
			if (poseName == name)
			{
				p = pose->poseList[i];
				break;
			}
		}
	}
	else
	{
		if ( (index < 0) || (index >= pose->poseList.size()) )
		{
			return Py_BuildValue("");
		}
		p = pose->poseList[index];
	}

	if (p == NULL)
	{
		return Py_BuildValue("");
	}
	int size = p->getSize();
	for (int i = 0; i < size; i++)
	{
		double ks = p->getKs(i);
		double kd = p->getKd(i);
		double position = p->getDOF(i);

		pose->getController()->setParam(i, position, ks, kd);
	}

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::isPoseSet(PyObject* self, PyObject* args)
{
	std::string funcName = "isPoseSet()";

	PyObject *pPointer ;
	double index;
	char* filename;
	std::string name = "";
	int okDouble = PyArg_Parse(args, "(Od)", &pPointer, &index);
	if (!okDouble)
	{
		PyErr_Clear();
		int okString = PyArg_Parse(args, "(Os)", &pPointer, &filename);
		if (!okDouble && !okString)
			return scriptError(funcName);

		name = filename;
	}

	ScriptablePose *pose = (ScriptablePose *) getPoseFromPPointer(pPointer) ;
	if( !pose)  return Py_BuildValue("");

	ArticulatedObject* ao = (ArticulatedObject*) pose->getController()->getSensor()->getSystem();


	Pose* p;
	if (name != "")
	{
		for (int i = 0; i < pose->poseList.size(); i++)
		{
			std::string poseName = pose->poseList[i]->getName();
			if (poseName == name)
			{
				p = pose->poseList[i];
				break;
			}
		}
	}
	else
	{
		if (index <= -1)
			return Py_BuildValue("");

		p = pose->poseList[index];
	}

	if (p == NULL)
		return Py_BuildValue("");

	for (int i = 7; i < ao->getStateSize(); i++)
	{
		double val1, val2, difference;
		val1 = ao->getState(i);
		val2 = p->getDOF(i);
		if (val2 == 0.0)
			continue;

		difference = abs(val1 - val2);
		if (difference > 0.15)
			return Py_BuildValue("i", 0);
	}
	return Py_BuildValue("i", 1);
}

PyObject* PoseInterpreter::initPose(PyObject* self, PyObject* args)
{
	std::string funcName = "initPose()";

	char* poseName;
	int index;
	double position, ks, kd;
	PyObject *pPointer ;

	int ok = PyArg_Parse(args, "(Osiddd)", &pPointer, &poseName, &index, &position, &ks, &kd);
	if (!ok)
		return scriptError(funcName);

	ScriptablePose *spose = (ScriptablePose *) getPoseFromPPointer(pPointer) ;
	if( !spose)  return Py_BuildValue("");
	PosePDController *pdc = spose->getController() ;
	if(!pdc) return Py_BuildValue("");
	Sensor *s = spose->getController()->getSensor() ;
	if(!s) return Py_BuildValue("");
	
	std::string name = poseName;

	for (int i = 0; i < spose->poseList.size(); i++)
	{
		Pose* p = spose->poseList[i];
		if (p->getName() == name)
		{
			p->setDOF(index, position);
			p->setKs(index, ks);
			p->setKd(index, kd);
			return Py_BuildValue("");
		}
	}
	//pose does not exist
	int size = s->getStateSize();
	Pose* pose = new Pose(size);
	pose->setDefaultKs(pdc->getKS());
	pose->setDefaultKd(pdc->getKD());
	pose->setParameters();
	pose->setName(name);
	pose->setDOF(index, position);
	pose->setKs(index, ks);
	pose->setKd(index, kd);
	spose->poseList.push_back(pose);
	return Py_BuildValue("");
}

PyObject* PoseInterpreter::extractPose(PyObject* self, PyObject* args)
{
	std::string funcName = "extractPose()";

	ArticulatedObject* ao = (ArticulatedObject*) PoseInterpreter::sensor->getSystem();
	char* poseName;
	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Os)", &pPointer, &poseName);
	if (!ok)
		return scriptError(funcName);

	ScriptablePose *pose = (ScriptablePose *) getPoseFromPPointer(pPointer) ;
	if( !pose)  return Py_BuildValue("");
	PosePDController *pdc = pose->getController() ;
	if(!pdc) return Py_BuildValue("");
	Sensor *s = pose->getController()->getSensor() ;
	if(!s) return Py_BuildValue("");

	std::string name = poseName;
	for (int i = 0; i < pose->poseList.size(); i++)
	{
		if (name == pose->poseList[i]->getName())
		{
			danceInterp::OutputMessage("Pose name %s already exists", poseName);
			return Py_BuildValue("(d)", -1);
		}
	}
	int size = s->getStateSize();
	Pose* p = new Pose(size);
	for (int i = 0; i < ao->getStateSize(); i++)
	{
		p->setDOF(i, ao->getState(i));
		p->setKs(i, pdc->getKS());
		p->setKd(i, pdc->getKD());
	}
	p->setDefaultKs(pdc->getKS());
	p->setDefaultKd(pdc->getKD());
	p->setName(name);
	
	int numPose = pose->poseList.size();
	pose->poseList.push_back(p);
	return Py_BuildValue("i", numPose);
}


PyObject* PoseInterpreter::magic(PyObject* self, PyObject* args)
{	
	std::string funcName = "magic()";

	double x, y, z;
	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Oddd)", &pPointer, &x, &y, &z);
	if (!ok)
		return scriptError(funcName);
	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");

	Vector v = {0.0, 0.0, 0.0};
	Vector force;

	Vector CMVel;
	s->getCMVelocity(CMVel);

	Link* link = ao->getLink(0);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", 0);

	double mass = link->getMass();
	double timeStep = sim->getTimeStep();
	force[0] = (-1 * mass * CMVel[0]* x) / timeStep;
	force[1] = (-1 * mass * CMVel[1]* y) / timeStep;
	force[2] = (-1 * mass * CMVel[2]* z) / timeStep;
	sim->PointForce(0, v, force);
	return Py_BuildValue("");
}



PyObject* PoseInterpreter::applyImpulseToLink(PyObject* self, PyObject* args)
{
	std::string funcName = "applyImpulseToLink()";

	double x, y, z;
	int bodyNum;
	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Oiddd)", &pPointer, &bodyNum, &x, &y, &z);
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");

	Vector v = {0.0, 0.0, 0.0};
	Vector force;
	Link* link = ao->getLink(0);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", 0);

	double timeStep = sim->getTimeStep();
	force[0] = (x) / timeStep;
	force[1] = (y) / timeStep;
	force[2] = (z) / timeStep;
	sim->PointForce(bodyNum, v, force);
	return Py_BuildValue("");
}

PyObject* PoseInterpreter::magicBody(PyObject* self, PyObject* args)
{
	std::string funcName = "magicBody()";

	double x, y, z;
	int bodyNum;
	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Oiddd)", &pPointer, &bodyNum, &x, &y, &z);
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");

	Vector v = {0.0, 0.0, 0.0};
	Vector force, Vel;
	Link* link = ao->getLink(bodyNum);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", bodyNum);

	double mass = link->getMass();
	double timeStep = sim->getTimeStep();

	s->getVelocity(bodyNum, Vel);
	force[0] = (-1 * mass * Vel[0]* x) / timeStep;
	force[1] = (-1 * mass * Vel[1]* y) / timeStep;
	force[2] = (-1 * mass * Vel[2]* z) / timeStep;
	sim->PointForce(bodyNum, v, force);
	return Py_BuildValue("");
}

PyObject* PoseInterpreter::setLinkKinematic( PyObject* self, PyObject* args )
{
	std::string funcName = "setLinkKinematic()";

	int linkIndex;
	double x, y, z, q1, q2, q3, q4;
	PyObject *pPointer ;
	int ok = PyArg_ParseTuple(args, "Oiddddddd", &pPointer, &linkIndex, &x, &y, &z, &q1, &q2, &q3, &q4);
	if (!ok)
		return scriptError(funcName);
	PosePDController *pdc ;
	Sensor *s ;
	if( !getPointersFromPython(pPointer, &pdc, &s) ) 
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");
	
	int simIndex = sim->GetIndex(linkIndex, 0) ;
	if( simIndex < 0 )
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue( "" );
	}
	int aoIndex = pdc->convertIndexSimtoAO( simIndex );
	if( aoIndex < 0 )
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue( "" );
	}
	PDParams& pdp = pdc->getPDParams( aoIndex );

	pdp.kinematic = true;
	pdp.kinematicPos[0] = x;
	pdp.kinematicPos[1] = y;
	pdp.kinematicPos[2] = z;
	pdp.kinematicOrient[0] = q1;
	pdp.kinematicOrient[1] = q2;
	pdp.kinematicOrient[2] = q3;
	pdp.kinematicOrient[3] = q4;

	return Py_BuildValue( "" );
}


PyObject* PoseInterpreter::magicBodyToBody(PyObject* self, PyObject* args)
{
	std::string funcName = "magicBodyToBody()";

	double x, y, z;
	int bodyNum;
	PyObject *pPointer ;
	char* otherObjectName;
	int ok = PyArg_Parse(args, "(Oiddds)", &pPointer, &bodyNum, &x, &y, &z, &otherObjectName);
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");


	DObject* otherObject = (DObject*)dance::AllSystems->get( otherObjectName );
	Vector parentVel = {0,0,0};
	Vector localZero = {0,0,0};
	otherObject->getWorldVelocity( parentVel, localZero ); 

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");

	Vector v = {0.0, 0.0, 0.0};
	Vector force, Vel;
	Link* link = ao->getLink(bodyNum);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", bodyNum);
	double mass = link->getMass();
	double timeStep = sim->getTimeStep();

	s->getVelocity(bodyNum, Vel);
	VecScale( parentVel, -1.0 );
	VecAdd( Vel, Vel, parentVel );
	force[0] = (-1 * mass * Vel[0]* x) / timeStep;
	force[1] = (-1 * mass * Vel[1]* y) / timeStep;
	force[2] = (-1 * mass * Vel[2]* z) / timeStep;
	sim->PointForce(bodyNum, v, force);
	return Py_BuildValue("");
}



PyObject* PoseInterpreter::magicTorque(PyObject* self, PyObject* args)
{
	std::string funcName = "magicTorque()";

	double x, y, z;
	int bodyNum;
	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Oiddd)",  &pPointer, &bodyNum, &x, &y, &z);
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");
	
	//Vector pos;
	Vector force;
	Vector angVel;
	//Link* link = ao->getLink(bodyNum);
	//link->getPosition(pos);

	//const InertiaTensor& d = link->getTotalInertiaTensor();
	//Matrix3x3 totalInertia; 
	//d.getInertia( totalInertia );

	//Vector lclAxisOfRotation = {0.0, 0.0, 0.0};
	//Vector offsetOfRotation = {0.0, 0.0, 0.0};

	//sim->GetVectorToWorld(bodyNum, lclAxisOfRotation, pos);
	//d.getMoment( lclAxisOfRotation, offsetOfRotation );

//	double mass = link->getMass();
	double timeStep = sim->getTimeStep();

	s->getAngularVelocity(bodyNum, angVel);
	force[0] = (-10 *  angVel[0]* x) *timeStep;
	force[1] = (-10 *  angVel[1]* y) * timeStep;
	force[2] = (-10 *  angVel[2]* z) * timeStep;
	
	sim->BodyTorque(bodyNum, force);

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::reachOffset(PyObject* self, PyObject* args)
{
	std::string funcName = "reachOffset()";

	double x, y, z;
	char* ikName;
	double distance;
	double elbowDirX, elbowDirY, elbowDirZ;
	double ofx, ofy, ofz ;
	PyObject *controllerPyObject;

	int ok = PyArg_Parse(args, "(Osdddddddddd)", &controllerPyObject, &ikName, &x, &y, &z, &distance, 
		                 &elbowDirX, &elbowDirY, &elbowDirZ, &ofx, &ofy, &ofz);
	if (!ok)
		return scriptError(funcName);

	PosePDController *pdc = getPDCfromPPointer(controllerPyObject) ;
	if( pdc == NULL )
	{
		danceInterp::OutputMessage("reachOffset: No PosePDController present") ;
		return Py_BuildValue("");
	}

	Vector goal;
	setVector(goal, x, y, z);
//	PoseInterpreter::computeIK(ikName, goal, numSteps, stepDivision);
	PoseInterpreter::computeFastIK(pdc, ikName, goal, distance, elbowDirX, elbowDirY, elbowDirZ, ofx, ofy, ofz, true);

	return Py_BuildValue("");
	
}



PyObject* PoseInterpreter::reach(PyObject* self, PyObject* args)
{
	std::string funcName = "reach()";

	double x, y, z;
	char* ikName;
	double distance;
	double elbowDirX, elbowDirY, elbowDirZ;
	PyObject *controllerPyObject ;

	int ok = PyArg_Parse(args, "(Osddddddd)", &controllerPyObject, &ikName, &x, &y, &z, &distance, &elbowDirX, &elbowDirY, &elbowDirZ);
	if (!ok)
		return scriptError(funcName);

	PosePDController *pdc = getPDCfromPPointer(controllerPyObject) ;
	if( pdc == NULL )
	{
		danceInterp::OutputMessage("reach: No PosePDController present") ;
		return Py_BuildValue("");
	}

	Vector goal;
	setVector(goal, x, y, z);
//	PoseInterpreter::computeIK(ikName, goal, numSteps, stepDivision);
	PoseInterpreter::computeFastIK(pdc,ikName, goal, distance, elbowDirX, elbowDirY, elbowDirZ);

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::reachObject(PyObject* self, PyObject* args)
{
	std::string funcName = "reachObject()";	
	
	char* objectName;
	char* ikName;
	double distance;
	double elbowDirX, elbowDirY, elbowDirZ;

	PyObject *controllerPyObject ;
	int ok = PyArg_Parse(args, "(Ossdddd)", &controllerPyObject, &ikName, &objectName, &distance, &elbowDirX, &elbowDirY, &elbowDirZ);
	if (!ok)
		return scriptError(funcName);

	PosePDController *pdc = getPDCfromPPointer(controllerPyObject) ;
	if( pdc == NULL )
	{
		danceInterp::OutputMessage("reachObject: No PosePDController present") ;
		return Py_BuildValue("");
	}

	Vector v;
	if (PoseInterpreter::getObject(objectName, v))
	{
	//	PoseInterpreter::computeIK(ikName, v, numSteps, stepDivision);

		PoseInterpreter::computeFastIK(pdc, ikName, v, distance, elbowDirX, elbowDirY, elbowDirZ);
	}

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::reachLink(PyObject* self, PyObject* args)
{
	std::string funcName = "reachLink()";	
	
	char* objectName;
	char* ikName;
	char* linkName;
	double distance;
	double elbowDirX, elbowDirY, elbowDirZ;
	PyObject *controllerPyObject;

	int ok = PyArg_Parse(args, "(Osssdddd)", &controllerPyObject, &ikName, &objectName, &linkName, &distance, &elbowDirX, &elbowDirY, &elbowDirZ);
	if (!ok)
		return scriptError(funcName);

	PosePDController *pdc = getPDCfromPPointer(controllerPyObject) ;
	if( pdc == NULL )
	{
		danceInterp::OutputMessage("reachLink: No PosePDController present") ;
		return Py_BuildValue("");
	}

	Vector v;
	if (PoseInterpreter::getLink(objectName, linkName, v))
	{
		//PoseInterpreter::computeIK(ikName, v, numSteps, stepDivision);
		PoseInterpreter::computeFastIK(pdc, ikName, v, distance, elbowDirX, elbowDirY, elbowDirZ);
	}

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::getPositionObject(PyObject* self, PyObject* args)
{
	std::string funcName = "getPositionObject()";	

	char* objectName;

	int ok = PyArg_Parse(args, "(s)", &objectName);
	if (!ok)
		return scriptError(funcName);

	Vector v;
	if (PoseInterpreter::getObject(objectName, v))
		return Py_BuildValue("[ddd]", v[0], v[1], v[2]);

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::getPositionLink(PyObject* self, PyObject* args)
{
	std::string funcName = "getPositionLink()";	

	char* objectName;
	int linkNum;

	int ok = PyArg_Parse(args, "(si)", &objectName, &linkNum);
	if (!ok)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	Vector v;
	if (PoseInterpreter::getLink(objectName, linkNum, v))
		return Py_BuildValue("[ddd]", v[0], v[1], v[2]);

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::getJointPosition(PyObject* self, PyObject* args)
{
	std::string funcName = "getJointPosition()";	

	int jNum;
	PyObject *pPointer ;
	
	int ok = PyArg_Parse(args, "(Oi)",&pPointer, &jNum);
	if (!ok)
		return scriptError(funcName);

	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	Joint* joint = ao->getJoint(jNum);
	if (joint == NULL)
		return Py_BuildValue("");

	Vector v;
	joint->getPosition(v);
	return Py_BuildValue("[ddd]", v[0], v[1], v[2]);

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::attachLink(PyObject* self, PyObject* args)
{
	std::string funcName = "attachLink()";	

	char* geomName;
	int linkNum;
	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Ois)", &pPointer, &linkNum, &geomName);
	if (!ok)
		return scriptError(funcName);

	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}
	
	for (int i = 0; i < dance::AllGeometry->size(); i++)
	{
		DGeometry* geom = dynamic_cast<DGeometry*>(dance::AllGeometry->get(i));
		if (geom == NULL)
			continue;

		if (strcmp(geom->getName(), geomName) != 0)
			continue;

		Joint* joint = ao->getJoint(linkNum);
		if (joint == NULL)
			return Py_BuildValue("");

		joint->getOutboardLink()->setAttachmentStatic(geom);
		break;
	}

	ao->getSimulator(0)->checkAttachments();
	return Py_BuildValue("");
}

PyObject* PoseInterpreter::detachLink(PyObject* self, PyObject* args)
{
	std::string funcName = "detachLink()";	

	char* geomName;
	int linkNum;
	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Ois)", &pPointer, &linkNum, &geomName);
	if (!ok)
		return scriptError(funcName);

	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

	for (int i = 0; i < dance::AllGeometry->size(); i++)
	{
		DGeometry* geom = dynamic_cast<DGeometry*>(dance::AllGeometry->get(i));
		if (geom == NULL)
			continue;

		if (strcmp(geom->getName(), geomName) != 0)
			continue;

		Joint* joint = ao->getJoint(linkNum);
		if (joint == NULL)
			return Py_BuildValue("");

		joint->getOutboardLink()->setAttachmentStatic(NULL);
		break;
	}

	ao->getSimulator(0)->checkAttachments();

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::isAttached(PyObject* self, PyObject* args)
{
	std::string funcName = "isAttached()";	

	PyObject *pPointer ;
	char* geomName;
	int linkNum;
	int ok = PyArg_Parse(args, "(Ois)", &pPointer,  &linkNum, &geomName);
	if (!ok)
		return scriptError(funcName);

	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

	Link* link = ao->getLink(linkNum);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", linkNum);

	DGeometry* geom = (DGeometry*) dance::AllGeometry->get(geomName);
	if (geom == NULL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	if (link->getAttachmentStatic() == geom)
	{
		return Py_BuildValue("i", 1);
	}
	else
	{
		return Py_BuildValue("i", 0);
	}
}

PyObject* PoseInterpreter::setJoint4Euler(PyObject* self, PyObject* args)
{
	std::string funcName = "setJoint4Euler()";	

	PyObject *pPointer ;
	double val[3];
	int jointNum;
	int ok = PyArg_Parse(args, "(Oiddd)", &pPointer, &jointNum, &val[0], &val[1], &val[2]); // quaternion setting in Euler angles
	if (!ok)
		return scriptError(funcName);
	
	PosePDController *pdc;
	Sensor *s ;
	if( !getPointersFromPython(pPointer, &pdc, &s)) return Py_BuildValue("");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	// make sure the joint exists
	Joint* joint = ao->getJoint(jointNum);
	if (joint == NULL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// make sure that the joint is a ball joint
	if (joint->getJointType() != J_BALL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// covert Euler angles to matrix, then to quaternion
	// convert back to quaternion
	Matrix3x3 xrot;
	xrot.setRotateMatrix(Matrix3x3::X, val[0]);
	Matrix3x3 yrot;
	yrot.setRotateMatrix(Matrix3x3::Y, val[1]);
	Matrix3x3 zrot;
	zrot.setRotateMatrix(Matrix3x3::Z, val[2]);
	Matrix3x3 final;
	final = xrot * yrot * zrot;
	Quaternion qFinal;
	qFinal.fromMatrix(final);

	// get the starting index of the joint
	int startIndex = ao->getStateMapping(jointNum, 0);
	pdc->setParam(startIndex, qFinal[0]);
	pdc->setParam(startIndex + 1, qFinal[1]);
	pdc->setParam(startIndex + 2, qFinal[2]);
	pdc->setParam(startIndex + 3, qFinal[3]);

	return Py_BuildValue("");
}



PyObject* PoseInterpreter::setJoint4(PyObject* self, PyObject* args)
{
	std::string funcName = "setJoint4()";	

	PyObject *pPointer ;
	double val[4];
	int jointNum;
	int ok = PyArg_Parse(args, "(Oidddd)", &pPointer, &jointNum, &val[0], &val[1], &val[2], &val[3]); // quaternion setting
	if (!ok)
		return scriptError(funcName);
	
	PosePDController *pdc;
	Sensor *s ;
	if( !getPointersFromPython(pPointer, &pdc, &s)) return Py_BuildValue("");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	// make sure the joint exists
	Joint* joint = ao->getJoint(jointNum);
	if (joint == NULL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// make sure that the joint is a ball joint
	if (joint->getJointType() != J_BALL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// get the starting index of the joint
	int startIndex = ao->getStateMapping(jointNum, 0);
	pdc->setParam(startIndex, val[0]);
	pdc->setParam(startIndex + 1, val[1]);
	pdc->setParam(startIndex + 2, val[2]);
	pdc->setParam(startIndex + 3, val[3]);

	return Py_BuildValue("");
}


PyObject* PoseInterpreter::setJointKsKd3(PyObject* self, PyObject* args)
{
	std::string funcName = "setJointKsKd3()";	

	PyObject *pPointer ;
	double ks[3];
	double kd[3];
	int jointNum;
	int ok = PyArg_Parse(args, "(Oidddddd)", &pPointer, &jointNum, &ks[0], &kd[0], &ks[1], &kd[1], &ks[2], &kd[2]);
	if (!ok)
		return scriptError(funcName);
	
	PosePDController *pdc;
	Sensor *s ;
	if( !getPointersFromPython(pPointer, &pdc, &s)) return Py_BuildValue("");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	// make sure the joint exists
	Joint* joint = ao->getJoint(jointNum);
	if (joint == NULL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// make sure that the joint is a gimbal joint
	if (joint->getJointType() != J_GIMBAL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// get the starting index of the joint
	int startIndex = ao->getStateMapping(jointNum, 0);
	pdc->setParamKSKD(startIndex, ks[0], kd[0]);
	pdc->setParamKSKD(startIndex + 1, ks[1], kd[1]);
	pdc->setParamKSKD(startIndex + 2, ks[2], kd[2]);

	return Py_BuildValue("");
}


PyObject* PoseInterpreter::setJointKsKd4(PyObject* self, PyObject* args)
{
	std::string funcName = "setJointKsKd4()";

	PyObject *pPointer ;
	double ks[3];
	double kd[3];
	int jointNum;
	int ok = PyArg_Parse(args, "(Oidddddd)", &pPointer, &jointNum, &ks[0], &kd[0], &ks[1], &kd[1], &ks[2], &kd[2]);
	if (!ok)
		return scriptError(funcName);

	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

	// make sure the joint exists
	Joint* joint = ao->getJoint(jointNum);
	if (joint == NULL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// make sure that the joint is a ball joint
	if (joint->getJointType() != J_BALL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// get the starting index of the joint
	int startIndex = ao->getStateMapping(jointNum, 0);
	pdc->setParamKSKD(startIndex, ks[0], kd[0]);
	pdc->setParamKSKD(startIndex + 1, ks[1], kd[1]);
	pdc->setParamKSKD(startIndex + 2, ks[2], kd[2]);

	return Py_BuildValue("");
}


PyObject* PoseInterpreter::setJoint3(PyObject* self, PyObject* args)
{
	std::string funcName = "setJoint3()";
	
	PyObject *pPointer ;
	double val[3];
	int jointNum;
	int ok = PyArg_Parse(args, "(Oiddd)", &pPointer, &jointNum, &val[0], &val[1], &val[2]); // gimbal setting
	if (!ok)
		return scriptError(funcName);

	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

	// make sure the joint exists
	Joint* joint = ao->getJoint(jointNum);
	if (joint == NULL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// make sure that the joint is a gimbal joint
	if (joint->getJointType() != J_GIMBAL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// get the starting index of the joint
	int startIndex = ao->getStateMapping(jointNum, 0);
	pdc->setParam(startIndex, val[0]);
	pdc->setParam(startIndex + 1, val[1]);
	pdc->setParam(startIndex + 2, val[2]);

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::setJoint2(PyObject* self, PyObject* args)
{
	std::string funcName = "setJoint2()";

	PyObject *pPointer ;
	double val[2];
	int jointNum;
	int ok = PyArg_Parse(args, "(Oidd)", &pPointer, &jointNum, &val[0], &val[1]); // universal setting
	if (!ok)
		return scriptError(funcName);
	
	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}
	
	// make sure the joint exists
	Joint* joint = ao->getJoint(jointNum);
	if (joint == NULL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// make sure that the joint is a universal joint
	if (joint->getJointType() != J_UNIVERSAL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// get the starting index of the joint
	int startIndex = ao->getStateMapping(jointNum, 0);
	pdc->setParam(startIndex, val[0]);
	pdc->setParam(startIndex + 1, val[1]);

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::setJointKsKd2(PyObject* self, PyObject* args)
{
	std::string funcName = "setJointKsKd2()";

	PyObject *pPointer ;
	double ks[2];
	double kd[2];
	int jointNum;
	int ok = PyArg_Parse(args, "(Oidddd)", &pPointer, &jointNum, &ks[0], &kd[0], &ks[1], &kd[1]);
	if (!ok)
		return scriptError(funcName);

	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

	// make sure the joint exists
	Joint* joint = ao->getJoint(jointNum);
	if (joint == NULL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// make sure that the joint is a universal joint
	if (joint->getJointType() != J_UNIVERSAL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// get the starting index of the joint
	int startIndex = ao->getStateMapping(jointNum, 0);
	pdc->setParamKSKD(startIndex, ks[0], kd[0]);
	pdc->setParamKSKD(startIndex + 1, ks[1], kd[1]);

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::setTargetPose(PyObject* self, PyObject* args)
{
	std::string funcName = "setTargetPose()";

	PyObject *pPointer ;
	int poseNumber;
	int ok = PyArg_Parse(args, "(Oi)", &pPointer, &poseNumber); 
	if (!ok)
		return scriptError(funcName);
	if( !pPointer )
	{
		danceInterp::OutputMessage( "PoseInterpreter::setTargetPose passed a null \"pose\" object.  Aborting." );
		return Py_BuildValue("");
	}

	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

	Pose *pose = pdc->getSelectedPose(poseNumber) ; // gets the pose based on index
													// "selected" is misleading
	pdc->setDesiredPoseIndex( poseNumber );
	if( pose )
	{
		pdc->setTargetPose(pose) ;
	}
	return Py_BuildValue("");
}

PyObject* PoseInterpreter::setTargetPoseByName(PyObject* self, PyObject* args)
{
	std::string funcName = "setTargetPoseByName()";

	PyObject *pPointer ;
	char* poseName = 0;
	int ok = PyArg_Parse(args, "(Os)", &pPointer, &poseName); 
	if (!ok)
		return scriptError(funcName);

	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

	Pose *pose = pdc->getPoseByName(poseName) ; // gets the pointer to pose 
	// "selected" is misleading
	if( pose )
	{
		pdc->setTargetPose(pose) ;
	}
	else
	{
		danceInterp::OutputMessage( "Warning: setTargetPoseByName(\"%s\") couldn't find pose by that name.", poseName ? poseName : "" );
	}
	return Py_BuildValue("");
}


PyObject* PoseInterpreter::setJoint1(PyObject* self, PyObject* args)
{
	std::string funcName = "setJoint1()";

	PyObject *pPointer ;
	double val;
	int jointNum;
	int ok = PyArg_Parse(args, "(Oid)", &pPointer, &jointNum, &val); // pin setting
	if (!ok)
		return scriptError(funcName);

	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}	

	// make sure the joint exists
	Joint* joint = ao->getJoint(jointNum);
	if (joint == NULL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// make sure that the joint is a pin joint
	if (joint->getJointType() != J_PIN)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// get the starting index of the joint
	int startIndex = ao->getStateMapping(jointNum, 0);
	pdc->setParam(startIndex, val);

	return Py_BuildValue("");
}

PyObject* PoseInterpreter::setJointKsKd1(PyObject* self, PyObject* args)
{
	std::string funcName = "setJointKsKd1()";

	PyObject *pPointer ;
	double ks[2];
	double kd[2];
	int jointNum;
	int ok = PyArg_Parse(args, "(Oidd)", &pPointer, &jointNum, &ks[0], &kd[0]);
	if (!ok)
		return scriptError(funcName);

	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

	// make sure the joint exists
	Joint* joint = ao->getJoint(jointNum);
	if (joint == NULL)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// make sure that the joint is a pin joint
	if (joint->getJointType() != J_PIN)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	// get the starting index of the joint
	int startIndex = ao->getStateMapping(jointNum, 0);
	pdc->setParamKSKD(startIndex, ks[0], kd[0]);

	return Py_BuildValue("");
}


void PoseInterpreter::setQuaternionStateFromEulerAngles(double* oldstate, Vector angledelta, double* newstate, Joint* joint)
{
	// convert quaternion to Euler angles
	Quaternion curq(oldstate[0], oldstate[1], oldstate[2], oldstate[3]);
	Matrix3x3 matrix;
	curq.toMatrix(matrix);
	VectorObj obj;
	matrix.matToEuler(Matrix3x3::XYZ, obj, false);

	// make sure that limits have not been exceeded
	for (int e = 0; e < 3; e++)
	{
		obj[e] += angledelta[e];
		double low, high;
		joint->getLimits(e, &low, &high);
		low = low * M_PI / 180;
		high = high * M_PI / 180;
		if( obj[e] >= (high - 0.009))
			obj[e] = high - 0.009;
		if( obj[e] <= (low + 0.009))
			obj[e] = low + 0.009;
	}
	// convert back to quaternion
	Matrix3x3 xrot;
	xrot.setRotateMatrix(Matrix3x3::X, obj[0]);
	Matrix3x3 yrot;
	yrot.setRotateMatrix(Matrix3x3::Y, obj[1]);
	Matrix3x3 zrot;
	zrot.setRotateMatrix(Matrix3x3::Z, obj[2]);
	Matrix3x3 final;
	final = xrot * yrot * zrot;
	Quaternion qFinal;
	qFinal.fromMatrix(final);

	for (int x = 0; x < 4; x++)
	{
		newstate[x] = qFinal[x];
	}
}

PyObject* PoseInterpreter::noise( PyObject* self, PyObject* args )
{
	std::string funcName = "noise()";

	float key = 0;
	int ok = PyArg_Parse(args, "(f)", &key );
	if (!ok)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("f", 0.0 );
	}
	double val = danceNoise::noise1( key );
	return Py_BuildValue( "f", val );
}


PyObject* PoseInterpreter::getControlUpdateFrequency( PyObject* self, PyObject* args )
{
	std::string funcName = "getControlUpdateFrequency()";

	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(O)", &pPointer );
	if (!ok)
	{
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("i", 0 );
	}
	PosePDController *pdc =getPDCfromPPointer(pPointer) ;
	return Py_BuildValue( "f", pdc->getControlUpdateFrequency() );
}

PyObject* PoseInterpreter::setControlUpdateFrequency( PyObject* self, PyObject* args )
{
	std::string funcName = "setControlUpdateFrequency()";
	
	float rate = 0;
	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(Of)", &pPointer, &rate );
	if (!ok)
		return scriptError(funcName);
	PosePDController *pdc =getPDCfromPPointer(pPointer) ;
	if (pdc)
		pdc->setControlUpdateFrequency( rate );
	return Py_BuildValue( "" );
}


/// computeFastIK: based on the IKAN implementation by UPENN
///
/// Works only for:
///		arms aligned with the x axis with degrees of freedom in the following order:
///		Shouder Ball, Forearm XY, Wrist YZ
///
///		legs aligend with the -y axis with degrees of freedom in the following order:
///		Thigh Ball, Knee XY, Foot XZ
///
/// The IKAN implementation is tricky. Here are how thinks work.
/// A right arm aligned with the -x axis is intuitively set up and solved.
/// A left arm aligned with the x axis needs care. The results we get correspond to right arm aligned
/// with x. We need to transform the results so that they can be used for a left hand. To do this
/// we need to reflect them. We do this by rotating the R1 matrix by 180 degrees around x. Then we reflect
/// rangle to -rangle and we are done. I am not yet sure about the wrist angle.
///  A tricky point: since our character is not symmetric we want to prereflect the distances (dist)
/// to avoid an offset error.
/// To implement a leg we set up right hand aligned with -z, transform the goal into the IK coordiante
/// system, solve this and then bring the results  the leg system (aligned with -y).
void PoseInterpreter::computeFastIK( PosePDController *pdc, char* ikName, Vector goal, double distance, 
									double elbowDirX, double elbowDirY, double elbowDirZ,
									double ofx, double ofy, double ofz, bool useOffset)
{
	std::string funcName = "computeFastIK()";

	Sensor *s = pdc->getSensor() ;
	if( !s )
	{
		danceInterp::OutputMessage("PoseInterpreter::computeFastIK: Controller %s has no sensor present", pdc->getName()) ;
		return ;
	}

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return;

	IKChain* ik = ao->getIKChain(ikName);
	if (ik == NULL)
	{
		danceInterp::OutputMessage("IK Chain does not exist");
		return;
	}

	// make sure that chain is compatible with 3-1-3
	if (ik->getNumJoints() != 3)
	{
		danceInterp::OutputMessage("IK Chain %s does not have 3 joints.", ik->getName());
		return;
	}

	// set the goal for visualization purposes
	pdc->setPoint(3, goal[0], goal[1], goal[2]) ;

	Joint* first = ik->getJoint(0);
	Joint* second = ik->getJoint(1);
	Joint* third = ik->getJoint(2);

	// check to see if joint is close enough to target
	Vector endEffLocation;
	third->getOutboardLink()->getEndEffector(endEffLocation);
	Vector currentLoc;
	third->getOutboardLink()->getWorldCoord(currentLoc, endEffLocation);
	if (VecDist(currentLoc, goal) < distance) // end effector is close enough to target
		return;

	if (first->getJointType() != J_BALL)
	{
		danceInterp::OutputMessage("Joint %s of IK Chain %s is not a ball joint.", first->getName(), ik->getName());
		return;
	}
	if (second->getJointType() != J_UNIVERSAL && ik->getJoint(1)->getJointType() != J_PIN )
	{
		danceInterp::OutputMessage("Joint %s of IK Chain %s is not a pin or universal joint.", ik->getJoint(1)->getName(), ik->getName());
		return;
	}

	if (third->getJointType() != J_UNIVERSAL && ik->getJoint(2)->getJointType() != J_BALL)
	{
		danceInterp::OutputMessage("Joint %s of IK Chain %s is not a ball or universal joint.", ik->getJoint(2)->getName(), ik->getName());
		return;
	}

	// determine if the IK is the left linkage or right linkage
	bool isLeftArm = false;
	bool isRightArm = false;
	bool isLeg = false;
	if (strcmp(ik->getName(), "left arm") == 0)
	{
		isLeftArm = true;
	}
	else if (strcmp(ik->getName(), "right arm") == 0)
	{
		isRightArm = true;
	}
	else if (strstr(ik->getName(), "leg") != NULL )
	{
		isLeg = true;
	}

	// set up the IK chain
	SRS ikan;

	ikmatrix R1, R2, S, T, G, Ry, U, IKToParent, ParentToIK;

	cpmatrix(R1,idmat) ;
	cpmatrix(R2,idmat) ;
	cpmatrix(Ry,idmat) ;
	cpmatrix(S,idmat) ;
	cpmatrix(T,idmat) ;

	float x[3] = {1,0,0} ; 
	float y[3] = {0,1,0} ; 
	ikmatrix Rx90, Rx90m, Ry90, Ry90m ;
	if( isLeg )
	{
		rotation_axis_to_matrix(x, (float) (M_PI / 2.0), Rx90);
		rotation_axis_to_matrix(y, (float) (-M_PI / 2.0), Ry90m);
		rotation_axis_to_matrix(x, (float) (-M_PI / 2.0), Rx90m);
		rotation_axis_to_matrix(y, (float) (M_PI / 2.0), Ry90);
		matmult(IKToParent, Rx90m, Ry90m) ;
		matmult(ParentToIK, Ry90, Rx90) ;
	}
	
	Vector dist;

	Vector btoj;
	Vector inb;

	// get length from first joint to second joint
	first->getBodyToJoint(btoj);
	VecScale(btoj, -1.0);
	second->getInbToJoint(inb);
	VecAdd(dist, btoj, inb);
	if( isLeg )
	{
		float distTemp1[3], distTemp2[3] ;
		vcopy(distTemp1, dist) ;
		vecmult(distTemp2, distTemp1, ParentToIK) ;
		vcopy(dist, distTemp2) ;
	}
	if( isLeftArm )
		set_translation(T, dist[0], -dist[1], -dist[2]);
	else
		set_translation(T, dist[0], dist[1], dist[2]);

	// get length from second joint to third joint
	second->getBodyToJoint(btoj);
	VecScale(btoj, -1.0);
	ik->getJoint(2)->getInbToJoint(inb);
	VecAdd(dist, btoj, inb);
	if( isLeg )
	{
		float distTemp1[3], distTemp2[3] ;
		vcopy(distTemp1, dist) ;
		vecmult(distTemp2, distTemp1, ParentToIK) ;
		vcopy(dist, distTemp2) ;
	}
	if( isLeftArm )
		set_translation(S, dist[0], -dist[1], -dist[2]);
	else
		set_translation(S, dist[0], dist[1], dist[2]);
	
	// get length from third joint to end effector
	third->getBodyToJoint(btoj);
	VecScale(btoj, -1.0);
	Vector endEff;
	third->getOutboardLink()->getEndEffector(endEff);
	VecAdd(dist, btoj, endEff);
	if( isLeg )
	{
		float distTemp1[3], distTemp2[3] ;
		vcopy(distTemp1, dist) ;
		vecmult(distTemp2, distTemp1, ParentToIK) ;
		vcopy(dist, distTemp2) ;
	}
	if( isLeftArm )
		set_translation(U, dist[0], -dist[1], -dist[2]);
	else
		set_translation(U, dist[0], dist[1], dist[2]);

	
	Link* parentLink = first->getInboardLink(); 

	float p[3] = {0,-1,0}; // not used unless elbow position is targeted.  ignored for now
	float a[3]; // elbow pointing axis

	// put pointing axis in root joint's parent coordinate
	a[0] = elbowDirX ;
	a[1] = elbowDirY ;
	a[2] = elbowDirZ ;
	Vector atemp1, atemp1Local ;
	vcopy(atemp1,a) ;
	parentLink->getLocalVector(atemp1Local, atemp1) ;
	vcopy(a,atemp1Local) ;
	if( isLeg )
	{
		float atemp[3] ;
		atemp[0] = a[0] ;
		atemp[1] = a[1] ;
		atemp[2] = a[2] ;
		vecmult(a, atemp, ParentToIK) ;
	}
	
	ikan.init(T, S, a, p) ;
	ikan.ProjectOn(); 

	

	// create the goal matrix
	cpmatrix(G,idmat);
 
	// put goal in local position of root joint's parent 
	
	Vector goalIK;
	Vector firstInboardToJoint;
	first->getInbToJoint(firstInboardToJoint);
	parentLink->getLocalCoord(goalIK, goal);
	// make the root sit at zero
	VecSubtract(goalIK, goalIK, firstInboardToJoint);

	ikmatrix EE ;
	cpmatrix(EE,idmat) ;
	Vector goalIKref;
	VecCopy( goalIKref, goalIK );
	float goalIKrefIK[3] ;
	if( isLeg )
	{
		float goalIKreftemp[3] ;
		// transform the target to IK coordinates
		vcopy( goalIKreftemp, goalIKref );
		vecmult(goalIKrefIK,goalIKreftemp,ParentToIK) ;
		if( useOffset ) 
		{
			float temp1[3] = {ofx, ofy, ofz}, temp2[3] ;
			vecmult(temp2, temp1, ParentToIK) ;
			set_translation(EE, temp2[0],temp2[1], temp2[2]);
		}
	}
	else
	{
		goalIKrefIK[0] = goalIKref[0] ;
		goalIKrefIK[1] = goalIKref[1] ;
		goalIKrefIK[2] = goalIKref[2] ;
		if( useOffset ) 
		{
			if( isLeftArm )
				set_translation(EE, ofx, -ofy, -ofz);
			else
				set_translation(EE, ofx, ofy, ofz);
		}
	}
	// set goal to be at end effector
	
	set_translation(G, goalIKrefIK[0], goalIKrefIK[1], goalIKrefIK[2]);
	


	float rangle;
	int feasible ;
	if( !useOffset )
		feasible = ikan.SetGoal(G, rangle);
	else
		feasible = ikan.SetGoalPos(goalIKrefIK, EE, rangle) ;
	if (!feasible)
	{
		danceInterp::OutputMessage("No solution found\n");
		return;
	}
	else
	{
		float pos[3];
	
		if (isLeftArm)
		{
			//ikan.AngleToPos(M_PI, pos);
			ikan.AngleToPos(0, pos);
		}
		else if( isRightArm || isLeg)
		{
			ikan.AngleToPos(0, pos);
		}
		if(!useOffset )
			ikan.SolveR1R2(pos, R1, R2);
		else
			ikan.SolveR1(pos, R1);
//	    ikan.SolveR1R2(rangle, R1, R2);
	    //ikan.SolveR1(pos, R1);
	}

	if (isLeftArm)
	{
		float xaxis[] = {1, 0, 0};
		ikmatrix R1Temp, Xrot;
		cpmatrix(R1Temp, R1);
		rotation_axis_to_matrix(xaxis, (float) M_PI, Xrot);
		hmatmult(R1, Xrot, R1Temp); 
		rangle = -rangle ;
	}



	if( isLeg )
	{
		ikmatrix R1w, R2w, Ryw ;

		// transform the IK results to world results
		matmult(R1w, R1, IKToParent) ;
		matmult(R1, ParentToIK, R1w) ;

		matmult(Ryw, Ry, IKToParent) ; 
		matmult(Ry, ParentToIK, Ryw) ; 

		matmult(R2w, R2, IKToParent) ;
		matmult(R2, ParentToIK, R2w) ;
	}


//////////////////////////////////

// -----------------------------------------------------------------------------------------------------------------------
// display the shoulder joint, elbow joint and wrist joint
// shoulder joint is at a fixed location
	Vector shoulderLocation = {R1[3][0], R1[3][1], R1[3][2]};
	VecAdd(shoulderLocation, shoulderLocation, firstInboardToJoint);
	Vector wShoulderLocation;
	parentLink->getWorldCoord(wShoulderLocation, shoulderLocation);
	pdc->setPoint(0, wShoulderLocation[0], wShoulderLocation[1], wShoulderLocation[2]);

// elbow joint is determined by multiplying shoulder rotation by T matrix
	double elbowPosMatrix[4][4];
	double Tmatrix[4][4];
	double R1matrix[4][4];
	for (int r = 0; r < 4; r++)
	{
		for (int c = 0; c < 4; c++)
		{
			Tmatrix[r][c] = T[r][c];
			R1matrix[r][c] = R1[r][c];
		}
	}
	multArray4x4(elbowPosMatrix, Tmatrix, R1matrix);
	Vector elbowPos = {elbowPosMatrix[3][0], elbowPosMatrix[3][1], elbowPosMatrix[3][2]};
	VecAdd(elbowPos, elbowPos, firstInboardToJoint);
	Vector wElbowLocation;
	parentLink->getWorldCoord(wElbowLocation, elbowPos);
	pdc->setPoint(1, wElbowLocation[0], wElbowLocation[1], wElbowLocation[2]);

// wrist joint is determined by ...
	double wristPosMatrix[4][4];
	rotation_axis_to_matrix(y, rangle, Ry);

	double RYmatrix[4][4];
	double Smatrix[4][4];
	double R2matrix[4][4];
	for (int r = 0; r < 4; r++)
	{
		for (int c = 0; c < 4; c++)
		{
			RYmatrix[r][c] = Ry[r][c];
			Smatrix[r][c] = S[r][c];
			R2matrix[r][c] = R2[r][c];
		}
	}

	double temp[4][4];
	double temp2[4][4];
	multArray4x4(temp, RYmatrix, elbowPosMatrix);
	multArray4x4(temp2, Smatrix, temp);
	multArray4x4(wristPosMatrix, R2matrix, temp2);

	Vector wristPos = {wristPosMatrix[3][0], wristPosMatrix[3][1], wristPosMatrix[3][2]};
	VecAdd(wristPos, wristPos, firstInboardToJoint);
	Vector wWristLocation;
	parentLink->getWorldCoord(wWristLocation, wristPos);
	pdc->setPoint(2, wWristLocation[0], wWristLocation[1], wWristLocation[2]);

// display the goal point
	Vector wGoalLocation;
	Vector localGoalIK;
	VecCopy(localGoalIK, goalIK);
	VecAdd(localGoalIK, localGoalIK, firstInboardToJoint);
	parentLink->getWorldCoord(wGoalLocation, localGoalIK);
	pdc->setPoint(3, wGoalLocation[0], wGoalLocation[1], wGoalLocation[2]);

	pdc->setMatrix(R1matrix);


// -----------------------------------------------------------------------------------------------------------------------

	

	// matrix for first joint
	Matrix3x3 m1(R1);  // Matrix3x3 is ROW-Major order, but R1 is in COLUMN-major, 
	// so we transpose (by inverting the quat)
	
	Quaternion qFinal;
	qFinal.fromMatrix(m1);
	// needed because using Matrix3x3 inverts
	qFinal.invert();

	VectorObj euler;
//	double limits[3][2];

	// decompose into Euler angles
/*	Matrix3x3 finalMatrix1;
	qFinal.toMatrix(finalMatrix1);
	finalMatrix1.matToEuler(Matrix3x3::XYZ, euler, false);
	// get the low and high limits
	for (int l = 0; l < 3; l++)
	{
		first->getLimits(l, &limits[l][0] , &limits[l][1]);
		limits[l][0] *= M_PI / 180.0;
		limits[l][1] *= M_PI / 180.0;
		if (limits[l][0] > euler[l])
			euler[l] = limits[l][0];
		if (limits[l][1] < euler[l])
			euler[l] = limits[l][1];
	}
	// reconstruct matrix from Euler angles
	Matrix3x3 xrot;
	xrot.setRotateMatrix(Matrix3x3::X, euler[0]);
	Matrix3x3 yrot;
	yrot.setRotateMatrix(Matrix3x3::Y, euler[1]);
	Matrix3x3 zrot;
	zrot.setRotateMatrix(Matrix3x3::Z, euler[2]);
	Matrix3x3 final;
	final = xrot * yrot * zrot;
	qFinal.fromMatrix(final);
*/

	double ks = pdc->getKS();
	double kd = pdc->getKD();

	// set first joint to PD params
	for (int d = 0; d < first->getStateSize(); d++)
	{
		int index = ao->getStateMapping(first->getJointNum(), d);
		//pdc->setParam(index, qFinal[d], ks, kd);
		pdc->setParam(index, qFinal[d]);
		//// FOR DEBUGGING
		//if( d == (first->getStateSize() - 1) )
		//	first->setState(d, qFinal[d], 0) ;
		//else
		//	first->setState(d, qFinal[d], 1) ;
	}


	//second->getLimits(0, &limits[0][0], &limits[0][1]);
	//limits[0][0] *= M_PI / 180.0;
	//limits[0][1] *= M_PI / 180.0;

	//if (limits[0][0] > rangle)
	//	rangle = limits[0][0];
	//if (limits[0][1] < rangle)
	//	rangle = limits[0][1];
	// set second joint to PD params
	
	int index = ao->getStateMapping(second->getJointNum(), 0);
	if( isLeg)
	{
		pdc->setParam(index+1, 0.0) ;  // ks, kd);
		pdc->setParam(index, rangle) ; //ks, kd);
		//// FOR DEBUGGING
		//second->setState(1,0,1) ;
		//second->setState(0,rangle,0) ;
	}
	else
	{
		pdc->setParam(index, 0.0) ; // , ks, kd);
		pdc->setParam(index + 1, rangle) ; // , ks, kd);
		//// FOR DEBUGGING
		//second->setState(0,0,1) ;
		//second->setState(1,rangle,0) ;
	}

	

	// matrix for third joint
	Matrix3x3 m2(R2);
//	Quaternion q2;
	m2.transpose();
//	q2.fromMatrix(m2);
//	q2.invert();
//	q2.toMatrix(m2);


	// decompose matrix to YZ rotations
	if( isLeg )
		m2.matToEuler2D(Matrix3x3::XZ, euler, false);
	else
		m2.matToEuler2D(Matrix3x3::YZ, euler, false);

	//for (int l = 0; l < 2; l++)
	//{
	//	first->getLimits(l, &limits[l][0], &limits[l][1]);
	//	limits[l][0] *= M_PI / 180.0;
	//	limits[l][1] *= M_PI / 180.0;
	//	if (limits[l][0] > euler[l])
	//		euler[l] = limits[l][0];
	//	if (limits[l][1] < euler[l])
	//		euler[l] = limits[l][1];
	//}
	for (int d = 0; d < 2; d++)
	{
		int index = ao->getStateMapping(third->getJointNum(), d);
//		pdc->setParam(index, euler[d], ks, kd);
		// keep hand at zero in local frame
	//	pdc->setParam(index, 0.0, ks, kd);
	}
	//// FOR DEBUGGING
	//third->setState(0,0,1) ;
	//third->setState(1,0,0) ;
	//ao->saveStateConfig("ik_debug.state") ;
}


//Non Scripting Functions
void PoseInterpreter::computeIK(PosePDController *pdc, char* ikName, Vector goal, int numSteps, double stepDivision)
{
	std::string funcName = "computeIK()";

	ArticulatedObject* ao = (ArticulatedObject*)pdc->getSensor()->getSystem();
	if (ao == NULL)
		return;

	IKChain* ik = ao->getIKChain(ikName);
	if (ik == NULL)
	{
		danceInterp::OutputMessage("IK Chain %s does not exist", ikName);
		return;
	}

	//if (PoseInterpreter::computed == true)
	//{
	//	double ks = pdc->getKS();
	//	double kd = pdc->getKD();
	//	int ikIndex = 0;
	//	for (int j = 0; j < ik->getNumJoints(); j++)
	//	{
	//		Joint* joint = ik->getJoint(j);
	//		for (int d = 0; d < joint->getStateSize(); d++)
	//		{
	//			int index = ao->getStateMapping(joint->getJointNum(), d);
	//			pdc->setParam(index, reachValues[ao->getIKChainNum(ik)][ikIndex], ks, kd);
	//			ikIndex++;
	//		}
	//	}
	//	return;
	//}

	bool early;

	ik->init();
	ik->setGoal(goal);

	double oldstate[MAX_STATE];
	ao->getState(oldstate);

	// calcual
	double dtheta[50];
	ik->setIKStepDivision(stepDivision);
	int result = ik->computeStep(1, early, dtheta); 
	for(int i=0;  result == IKChain::IK_GOAL_NOT_REACHED && i < numSteps; i++)
	{
		double low, high;
		double val;
		int count = 0;

		// update joints' states
		int numJoints = ik->getNumJoints();
		for(int x = 0; x < numJoints; x++)
		{
			Joint *joint = ik->getJoint(x);
			if (joint->getJointType() == J_BALL)
			{
				Vector angledelta = { dtheta[count], dtheta[count + 1], dtheta[count + 2] };
				double newstate[4];
				setQuaternionStateFromEulerAngles(joint->getQuaternion()->data(), angledelta, newstate, joint);
				for (int s = 0; s < 4; s++)
				{
					if (s != 3)
						joint->setState(s, newstate[s], 1);
					else
						joint->setState(s, newstate[s]);
				}

				count += 3;
			}
			else // universal, pin or gimbal joints
			{
				for (int y = 0; y < joint->getNumDof(); y++)
				{
					joint->getLimits(y, &low, &high);
					low = low * M_PI / 180;
					high = high * M_PI / 180;
					val = joint->getState(y) + dtheta[count++];
					if( val >= (high-0.009))
						val = high-0.009;
					if( val <= (low+0.009))
						val = low+0.009;
					if (y == joint->getNumDof() - 1)
						joint->setState(y, val);
					else
						joint->setState(y, val, true);
				}
			}
		}
	 
		ao->updateStateConfig();
		ik->computeStep(numSteps, early, dtheta);
	}

	int ikIndex = 0;
	for (int j = 0; j < ik->getNumJoints(); j++)
	{
		Joint* joint = ik->getJoint(j);
		for (int d = 0; d < joint->getStateSize(); d++)
		{
			PoseInterpreter::reachValues[ao->getIKChainNum(ik)][ikIndex] = joint->getState(d);
			ikIndex++;
		}
	}
	ao->setState(oldstate);

	// if goal not reached, ik should return as-close-as-possible configurations
	ikIndex = 0;
	for (int j = 0; j < ik->getNumJoints(); j++)
	{
		Joint* joint = ik->getJoint(j);
		double ks = pdc->getKS();
		double kd = pdc->getKD();
		for (int d = 0; d < joint->getStateSize(); d++)
		{
			int index = ao->getStateMapping(joint->getJointNum(), d);
			pdc->setParam(index, PoseInterpreter::reachValues[ao->getIKChainNum(ik)][ikIndex], ks, kd);
			ikIndex++;
		}
	}
	//if (result == IKChain::IK_GOAL_REACHED)
	//	PoseInterpreter::computed = true;
}

bool PoseInterpreter::getObject(char* name, Vector pos)
{
	DGeometry* geom = (DGeometry*) dance::AllGeometry->get(name);
	if (geom != NULL)
	{
		geom->getCenter(pos);
		return true;
	}
	else
	{
		DSystem* sys = (DSystem*) dance::AllSystems->get(name);
		if (sys != NULL)
		{
			ArticulatedObject* ao = dynamic_cast<ArticulatedObject*> (sys);
			if (ao != NULL)
			{
				Link* link = ao->getLink(0);
				if (link != NULL)
				{
					link->getPosition(pos);
					return true;
				}
			}
		}
		danceInterp::OutputMessage("Object %s does not exist", name);
		return false;
	}
}

bool PoseInterpreter::getLink(char* objectName, int linkNum, Vector pos)
{
	DSystem* sys = (DSystem*) dance::AllSystems->get(objectName);
	if (sys != NULL)
	{
		ArticulatedObject* ao = dynamic_cast<ArticulatedObject*> (sys);
		if (ao != NULL)
		{
			Link* link = ao->getLink(linkNum);
			if (link != NULL)
			{
				link->getPosition(pos);
				return true;
			}
		}
	}
	danceInterp::OutputMessage("Link not found");
	return false;
}

bool PoseInterpreter::getLink(char* objectName, char* linkName, Vector pos)
{
	DSystem* sys = (DSystem*) dance::AllSystems->get(objectName);
	if (sys != NULL)
	{
		ArticulatedObject* ao = dynamic_cast<ArticulatedObject*> (sys);
		if (ao != NULL)
		{
			Link* link = ao->getLink(linkName);
			if (link != NULL)
			{
				link->getPosition(pos);
				return true;
			}
		}
	}
	danceInterp::OutputMessage("Link not found");
	return false;
}



PyObject* PoseInterpreter::getVelocityObj(PyObject *self, PyObject *args)
{
	std::string funcName = "getVelocityObj()";

    char* objName;
    Vector v;

    int ok = PyArg_Parse(args, "(s)", &objName);
	if (!ok)
		return scriptError(funcName);
 
    PoseInterpreter::getObjectVel(objName, v);
    return Py_BuildValue("[ddd]", v[0], v[1], v[2]);
}



PyObject* PoseInterpreter::getNearestPointOnSupportPolygon(PyObject* self, PyObject* args)
{
	std::string funcName = "getNearestPointOnSupportPolygon()";

	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(O)", &pPointer );
	if (!ok)
		return scriptError(funcName);


	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	Vector cm;
	Vector nearestPt;
	s->getCenterMass( cm );
	double dist = s->computeNearestPointOnSupportPolygon( nearestPt, cm );
	return Py_BuildValue("[ddd]", nearestPt[0], nearestPt[1], nearestPt[2] );
}

PyObject* PoseInterpreter::getDistToSupportPolygon(PyObject* self, PyObject* args)
{
	std::string funcName = "getDistToSupportPolygon()";

	PyObject *pPointer ;
	int ok = PyArg_Parse(args, "(O)", &pPointer );
	if (!ok)
		return scriptError(funcName);


	Sensor *s = getSensorFromPPointer(pPointer) ;
	if (!s)
		return scriptError(funcName, "No sensor found.");

	Vector cm;
	Vector nearestPt;
	s->getCenterMass( cm );
	double dist = s->computeNearestPointOnSupportPolygon( nearestPt, cm );
	return Py_BuildValue("d", dist );
}


PyObject* PoseInterpreter::attachLinkStatic(PyObject* self, PyObject* args)
{
	std::string funcName = "attachLinkStatic()";

	PyObject *pPointer ;
    char* geomName;
    int linkNum;
    int ok = PyArg_Parse(args, "(Ois)", &pPointer, &linkNum, &geomName);
	if (!ok)
		return scriptError(funcName);


	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

    for (int i = 0; i < dance::AllGeometry->size(); i++)
    {
        DGeometry* geom = dynamic_cast<DGeometry*>(dance::AllGeometry->get(i));
        if (geom == NULL)
            continue;

        if (strcmp(geom->getName(), geomName) != 0)
            continue;

        Joint* joint = ao->getJoint(linkNum);
        if (joint == NULL)
            return Py_BuildValue("");

        joint->getOutboardLink()->setAttachmentStatic(geom);
        break;
    }

    ao->getSimulator(0)->checkAttachments();
    return Py_BuildValue("");
}

/// setFootFlat 
/// Takes a link number and an euler decomposition (according to Matrix3x3)
/// and sets ups the controller parameters so that the given link has identiry orientation
/// with respect to the world.
PyObject* PoseInterpreter::setFootFlat(PyObject* self, PyObject* args)
{
	std::string funcName = "setFootFlat()";

	PyObject *pPointer ;
    
	int linkNumber, eulerOrder ;
    int ok = PyArg_Parse(args, "(Oii)", &pPointer, &linkNumber, &eulerOrder ) ;
 	if (!ok)
		return scriptError(funcName);


	// get pointer and check for errors
	Pose *p = getPoseFromPPointer(pPointer) ;
	if( !p ) return Py_BuildValue("");
	PosePDController *pdc = p->getController() ;
	Sensor *s = pdc->getSensor() ;
	if( !s ) return Py_BuildValue("");
	if( !pdc ) return Py_BuildValue("");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	Link *link = ao->getLink(linkNumber) ;
	Link *pLink = link->getParentLink() ;
	float tm[4][4] ;
	pLink->getWTransMat(tm) ;
	Quaternion quat ;
	quat.fromMatrix(tm) ;
	quat.normalize() ;
	Matrix3x3 temp ;
	quat.toMatrix(temp) ;
	quat.invert() ;
	quat.normalize() ;
	Matrix3x3 tm33 ;
	quat.toMatrix(tm33) ;
	
	VectorObj euler ;

	Matrix3x3 tt = temp*tm33 ;




	tm33.matToEuler2D(eulerOrder, euler, false);
	for (int d = 0; d < 2; d++)
	{
		int index = ao->getStateMapping(link->getParentJoint()->getJointNum(), d);
		PDParams& pdParams = pdc->getPDParams( index );
		pdParams.driveType = VelocityDrive ;
		pdParams.v = euler[d];
		pdc->setPDParams( index, pdParams );
		
	}
	int index = ao->getStateMapping(link->getParentJoint()->getJointNum(), 0);
	//danceInterp::OutputMessage(" foot x angle %f state %f", euler[0], link->getParentJoint()->getState(0)) ;
   
	return Py_BuildValue("");
}


/// res must be preallocated. Sequence is  freed.
int getDoublesFromSequence(PyObject *s, double *res)
{
	int size = PySequence_Fast_GET_SIZE(s) ;
	for( int i = 0 ; i < size ; i++ )
	{
		PyObject *fitem ;
		PyObject *item = PySequence_Fast_GET_ITEM(s,i) ;
		if( !item ) {
			//Py_DECREF(s) ;
			return 0 ;
		}
		fitem = PyNumber_Float(item) ;
		if( !fitem)
		{
			//Py_DECREF(s) ;
			PyErr_SetString(PyExc_TypeError, "al items must be numbers") ;
			return 0 ;
		}
		Py_DECREF(fitem) ;
		res[i] = PyFloat_AS_DOUBLE(fitem) ;
		//Py_DECREF(s) ;
	}
	return 1 ;
}

PyObject* PoseInterpreter::getLerpJointFromStates(PyObject* self, PyObject* args)
{
	std::string funcName = "getLerpJointFromStates()";

	PyObject *pPointer;
	double jointState1[7], jointState2[7] ;
	int jointIdx ;
	double t;
	int ok ;
	int size = 0 ;
	PyObject *s1, *s2 ;



	ok = PyArg_Parse(args, "(OiOOd)",&pPointer, &jointIdx, &s1,&s2,&t) ;
	
	if (!ok)
		return scriptError(funcName);

	s1 = PySequence_Fast(s1,"argument must be iterable") ;
	if( !s1 ) 
		return Py_BuildValue("");

	s2 = PySequence_Fast(s2,"argument must be iterable") ;
	if( !s2 ) 
		return Py_BuildValue("");

	int size1 = PySequence_Fast_GET_SIZE(s1) ; // sequence is FREED
	int size2 = PySequence_Fast_GET_SIZE(s2) ; // sequence is FREED
	if( size1 != size2)
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::getLerpJointFromStates() size mismatch." );
		return Py_BuildValue("");
	}
	else size = size1 ;
	
	getDoublesFromSequence(s1, jointState1) ;
	getDoublesFromSequence(s2, jointState2) ;
	Py_DECREF(s1) ;
	Py_DECREF(s2) ;
	
	/**
	if( ok )
	{
		size = 1 ;
	}
	else
	{
		ok = PyArg_Parse(args, "(Oi(dd)(dd)d)",&jointState1[0], &jointState1[1], &jointState2[0], &jointState2[1],&t) ;
		if( ok ) size = 2 ;
		else
		{
			ok = PyArg_Parse(args, "(Oi(ddd)(ddd)d)",&pPointer, &jointIdx,
				&jointState1[0], &jointState1[1], &jointState1[2],
				&jointState2[0], &jointState2[1], &jointState2[2],
				&t) ;
			if( ok) size = 3 ;
			else
			{
				ok = PyArg_Parse(args, "(Oi(dddd)(dddd)d)",&pPointer, &jointIdx,
					&jointState1[0], &jointState1[1], &jointState1[2], &jointState1[3],
					&jointState2[0], &jointState2[1], &jointState2[2], &jointState2[3],
					&t
					) ;
				if( ok ) size = 4 ;
				else
				{
					ok = PyArg_Parse(args, "(Oi(ddddddd)(ddddddd)d)",&pPointer, &jointIdx,
						&jointState1[0], &jointState1[1], &jointState1[2], &jointState1[3], &jointState1[4], &jointState1[5], &jointState1[6],
						&jointState2[0], &jointState2[1], &jointState2[2], &jointState2[3],	&jointState2[4], &jointState2[5], &jointState2[6],
						&t) ;
					if( ok ) size = 7 ;
					else
					{

						PyErr_Print();
						PyErr_Clear();
						return Py_BuildValue("");
					}
				}
			}
		}
	}
	**/

	// get pointer and check for errors
	Pose *p = getPoseFromPPointer(pPointer) ;
	if( !p )
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::getLerpJointFromStates() could not obtain pose from posePointer argument." );
		return Py_BuildValue("");
	}
	PosePDController *pdc = p->getController() ;
	if( !pdc )
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::getLerpJointFromStates() could not obtain PosePDController from pose." );
		return Py_BuildValue("");
	}
	Sensor *s = pdc->getSensor() ;
	if( !s ) 
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::getLerpJointFromStates() could not obtain Sensor from PosePDController." );
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	double res[7] ;
	for( int i = 0; i < size; ++i )
	{
		res[i] = jointState1[i] *(1-t)+ jointState2[i]*t ;
	}
	switch (size ){
		case 1:
			return Py_BuildValue("[d]", res[0]);
			break ;
		case 2:
			return Py_BuildValue("[dd]", res[0],res[1]);
			break ;
		case 3:
			return Py_BuildValue("[ddd]", res[0],res[1], res[2]);
			break ;
		case 4: 
			return Py_BuildValue("[dddd]", res[0],res[1], res[2], res[3]);
			break ;
		case 7:
			return Py_BuildValue("[ddddddd]", res[0],res[1], res[2], res[3], res[4], res[5], res[6]);
			break ;
		default:
			return Py_BuildValue("");
			break ;
	}
}

PyObject* PoseInterpreter::getJointFromPose(PyObject* self, PyObject* args)
{
	std::string funcName = "getJointFromPose()";

	PyObject *pPointer ;
	int jointIdx ;
	int poseIdx;
	int ok = PyArg_Parse(args, "(Oii)", &pPointer, &poseIdx, &jointIdx ) ;
	if (!ok)
		return scriptError(funcName);


	// get pointer and check for errors
	Pose *p = getPoseFromPPointer(pPointer) ;
	if( !p )
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::getJointFromPose() could not obtain pose from posePointer argument." );
		return Py_BuildValue("");
	}
	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

	Pose* pose = pdc->getSelectedPose( poseIdx );
	if( !pose )
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::getJointFromPose() could not find pose by index %d.", poseIdx );
		return Py_BuildValue("");
	}
	Joint* joint = ao->getJoint( jointIdx );

	double res[7] = {0,0,0,0,0,0,0};
	for( int i = 0; i < joint->getStateSize(); ++i )
	{
		int idx = ao->getStateMapping( jointIdx, i );
		res[i] = pose->getDOF( idx );
	}
	switch (joint->getStateSize() ){
		case 1:
			return Py_BuildValue("[d]", res[0]);
			break ;
		case 2:
			return Py_BuildValue("[dd]", res[0],res[1]);
			break ;
		case 3:
			return Py_BuildValue("[ddd]", res[0],res[1], res[2]);
			break ;
		case 4: 
			return Py_BuildValue("[dddd]", res[0],res[1], res[2], res[3]);
			break ;
		case 7:
			return Py_BuildValue("[ddddddd]", res[0],res[1], res[2], res[3], res[4], res[5], res[6]);
			break ;
		default:
			return Py_BuildValue("");
			break ;
	}
}

PyObject *PoseInterpreter::interpolatePoses(PyObject* self, PyObject* args)
{
	std::string funcName = "interpolatePoses()";

	PyObject *pPointer ;
	int poseIdx1, poseIdx2;
	double t ;
	int ok = PyArg_Parse(args, "(Oiid)", &pPointer, &poseIdx1, &poseIdx2, &t ) ;
	if (!ok)
		return scriptError(funcName);


	// get pointer and check for errors
	Pose *p = getPoseFromPPointer(pPointer) ;
	if( !p )
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::interpolatePoses() could not obtain pose from posePointer argument." );
		return Py_BuildValue("");
	}
	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

	Pose* pose1 = pdc->getSelectedPose( poseIdx1 );
	Pose* pose2 = pdc->getSelectedPose( poseIdx2 );
	if( (!pose1) || (!pose2))
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::interpolatePoses() no such poses!" );
		return Py_BuildValue("");
	}
		
	int stateSize = ao->getStateSize();

	// for now, perform linear interpolation
	for (int x = 0; x < stateSize; x++)
	{
		double res = pose1->getDOF(x) * (1.0-t) + pose2->getDOF(x) *t ;
		pdc->setParam(x, res) ;
	}
	return Py_BuildValue("");

}


PyObject* PoseInterpreter::getWorldQuaternion(PyObject* self, PyObject* args)
{
	std::string funcName = "getWorldQuaternion()";

	PyObject *pPointer ;
	int linkNumber ;
	int ok = PyArg_Parse(args, "(Oi)", &pPointer, &linkNumber ) ;
	if (!ok)
		return scriptError(funcName);


	// get pointer and check for errors
	Pose *p = getPoseFromPPointer(pPointer) ;
	if( !p )
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::getWorldQuaternion() could not obtain pose from posePointer argument." );
		return Py_BuildValue("");
	}
	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

	Link *pLink = ao->getLink(linkNumber) ;
	if( !pLink ) 
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::getWorldQuaternion() could not get link from Articulated Object." );
		return Py_BuildValue("");
	}

	float tm[4][4] ;
	pLink->getWTransMat(tm) ;
	Quaternion quat ;
	quat.fromMatrix(tm) ;
	quat.normalize() ;
	if( quat[0] < 0 ) 
	{
		quat[0] = -quat[0] ;
		quat[1] = -quat[1] ;
		quat[2] = -quat[2] ;
		quat[3] = -quat[3] ;
	}

	return Py_BuildValue("[dddd]",quat[3], quat[0], quat[1], quat[2]) ;

}


PyObject* PoseInterpreter::getWorldZeroXYZAngles(PyObject* self, PyObject* args)
{
	std::string funcName = "getWorldZeroXYZAngles()";

	PyObject *pPointer ;

	int linkNumber ;
	int ok = PyArg_Parse(args, "(Oi)", &pPointer, &linkNumber ) ;
	if (!ok)
		return scriptError(funcName);


	// get pointer and check for errors
	Pose *p = getPoseFromPPointer(pPointer) ;
	if( !p )
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::getWorldZeroXYZAngles() could not obtain pose from posePointer argument." );
		return Py_BuildValue("");
	}
	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}
	Link *link = ao->getLink(linkNumber) ;
	if( !link ) 
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::getWorldZeroXYZAngles() could not obtain link %d from Articulated Object.", linkNumber );
		return Py_BuildValue("");
	}
	Link *pLink = link->getParentLink() ;
	if( !pLink ) 
	{
		danceInterp::OutputMessage( "Error: PoseInterpreter::getWorldZeroXYZAngles() could not obtain parent link of link %d.", linkNumber );
		return Py_BuildValue("");
	}
	float tm[4][4] ;
	pLink->getWTransMat(tm) ;
	Quaternion quat ;
	quat.fromMatrix(tm) ;
	quat.normalize() ;
	Matrix3x3 temp ;
	quat.toMatrix(temp) ;
	quat.invert() ;
	quat.normalize() ;
	Matrix3x3 tm33 ;
	quat.toMatrix(tm33) ;

	// Decompose to Euler angles with XYZ order
	VectorObj euler ;
	Matrix3x3 tt = temp*tm33 ;
	tm33.matToEuler( Matrix3x3::XYZ, euler, false);
	int index = ao->getStateMapping(link->getParentJoint()->getJointNum(), 0);
	return Py_BuildValue("[ddd]", euler[0], euler[1], euler[2] );
}


PyObject* PoseInterpreter::attachLinkAO(PyObject* self, PyObject* args)
{
	std::string funcName = "attachLinkAO()";

	PyObject *pPointer ;
    char* targetName;
    char* targetLink;
    int linkNum;
    int ok = PyArg_Parse(args, "(Oiss)", &pPointer, &linkNum, &targetName, &targetLink);
	if (!ok)
		return scriptError(funcName);


	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

    DSystem* sys = (DSystem*) dance::AllSystems->get(targetName);
    if (sys == NULL)
        return Py_BuildValue("");
    ArticulatedObject* attachAO = dynamic_cast<ArticulatedObject*>(sys);
    if (attachAO == NULL)
        return Py_BuildValue("");

    Joint* joint = ao->getJoint(linkNum);
    if (joint == NULL)
        return Py_BuildValue("");

    Link* tLink = attachAO->getLink(targetLink);
    if (tLink == NULL)
        return Py_BuildValue("");

    joint->getOutboardLink()->setAttachment(attachAO, tLink->getNumber());
    ao->getSimulator(0)->checkAttachments();
    return Py_BuildValue("");
}

PyObject* PoseInterpreter::detachLinkStatic(PyObject* self, PyObject* args)
{
	std::string funcName = "detachLinkStatic()";

	PyObject *pPointer ;
	char* geomName;
    int linkNum;
    int ok = PyArg_Parse(args, "(Ois)", &pPointer, &linkNum, &geomName);
	if (!ok)
		return scriptError(funcName);

	
	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

    for (int i = 0; i < dance::AllGeometry->size(); i++)
    {
        DGeometry* geom = dynamic_cast<DGeometry*>(dance::AllGeometry->get(i));
        if (geom == NULL)
            continue;

        if (strcmp(geom->getName(), geomName) != 0)
            continue;

        Joint* joint = ao->getJoint(linkNum);
        if (joint == NULL)
            return Py_BuildValue("");

        joint->getOutboardLink()->setAttachmentStatic(NULL);
        break;
    }

    ao->getSimulator(0)->checkAttachments();

    return Py_BuildValue("");
}

PyObject* PoseInterpreter::detachLinkAO(PyObject* self, PyObject* args)
{
	std::string funcName = "detachLinkAO()";

	PyObject *pPointer ;
    char* targetName;
    char* targetLink;
    int linkNum;
    int ok = PyArg_Parse(args, "(Oiss)", &pPointer, &linkNum, &targetName, &targetLink);
	if (!ok)
		return scriptError(funcName);


	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

    Link* link = ao->getLink(linkNum);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", linkNum);

    DSystem* sys = (DSystem*) dance::AllSystems->get(targetName);
    if (sys == NULL)
        return Py_BuildValue("");

    ArticulatedObject* targetAO = dynamic_cast<ArticulatedObject*>(sys);
    if (targetAO == NULL)
        return Py_BuildValue("");

    Link* tLink = targetAO->getLink(targetLink);
    if (tLink == NULL)
        return Py_BuildValue("");

    link->setAttachment(NULL, -1);

    ao->getSimulator(0)->checkAttachments();

    return Py_BuildValue("");
}

PyObject* PoseInterpreter::isAttachedStatic(PyObject* self, PyObject* args)
{
	std::string funcName = "isAttachedStatic()";

	PyObject *pPointer ;
    char* geomName;
    int linkNum;
    int ok = PyArg_Parse(args, "(Ois)", &pPointer, &linkNum, &geomName);
	if (!ok)
		return scriptError(funcName);

	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}
   
	Link* link = ao->getLink(linkNum);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", linkNum);

    DGeometry* geom = (DGeometry*) dance::AllGeometry->get(geomName);
    if (geom == NULL)
    {
        PyErr_Print();
        PyErr_Clear();
        return Py_BuildValue("");
    }

    if (link->getAttachmentStatic() == geom)
    {
        return Py_BuildValue("i", 1);
    }
    else
    {
        return Py_BuildValue("i", 0);
    }
}

PyObject* PoseInterpreter::isAttachedAO(PyObject* self, PyObject* args)
{
 	std::string funcName = "isAttachedAO()";

	PyObject *pPointer ;
	char* targetName;
    char* targetLink;
    int linkNum;
    int ok = PyArg_Parse(args, "(Oiss)", &pPointer, &linkNum, &targetName, &targetLink);
 	if (!ok)
		return scriptError(funcName);

	
	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(pdc->getAppliedObject(0));
    if (ao == NULL)
	{
		danceInterp::OutputMessage("No ArticulatedObject found. Cannot attachLinkStatic().");
		PyErr_Print();
		PyErr_Clear();
        return Py_BuildValue("");
	}

    DSystem* sys = (DSystem*) dance::AllSystems->get(targetName);
    if (sys == NULL)
        return Py_BuildValue("");

    ArticulatedObject* targetAO = dynamic_cast<ArticulatedObject*>(sys);
    if (targetAO == NULL)
        return Py_BuildValue("");

	Link* link = ao->getLink(linkNum);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", linkNum);

    Link* tLink = targetAO->getLink(targetLink);
    if (tLink == NULL)
        return Py_BuildValue("");

    int checkLink;
    ArticulatedObject* aoTarget = link->getAttachment(checkLink);

    if (link->getAttachment(checkLink) == targetAO)
    {
        if (checkLink == tLink->getNumber())
            return Py_BuildValue("i", 1);
        else
            return Py_BuildValue("i", 0);
    }
    else
    {
        return Py_BuildValue("i", 0);
    }
}


bool PoseInterpreter::getObjectVel(char* name, Vector vel)
{
    DSystem* sys = (DSystem*) dance::AllSystems->get(name);
    if (sys != NULL)
    {
        ArticulatedObject* ao = dynamic_cast<ArticulatedObject*> (sys);
        if (ao != NULL)
        {
            //DSimulator* simulator = dynamic_cast<Dsimulator*>(ao->getSimulator(0));
            DSimulator* simulator = ao->getSimulator(0);
            if (simulator != NULL)
            {
                Vector zero = {0,0,0};
                simulator->GetVel(0, zero, vel);
                return true;
            }
        }
        return false;
    }
    danceInterp::OutputMessage("Object %s does not exist", name);
    return false;
}

PyObject* PoseInterpreter::addPoint(PyObject* self, PyObject* args)
{
 	std::string funcName = "addPoint()";

	PyObject *pPointer;
	char* pointName;
	double x = 0;
	double y = 0;
	double z = 0;

	int ok = PyArg_Parse(args, "(Osddd)", &pPointer, &pointName, &x, &y, &z);
	if (ok)
	{
		// get pointer and check for errors
		Pose *p = getPoseFromPPointer(pPointer) ;
		if( !p )
		{
			danceInterp::OutputMessage( "Error: addPoint() could not obtain pose from posePointer argument." );
			return Py_BuildValue("");
		}
		PosePDController* pdc = getPDCfromPPointer(pPointer);
		if (!pdc)
		{
			danceInterp::OutputMessage("No controller found. Cannot addPoint().");
			PyErr_Print();
			PyErr_Clear();
			return Py_BuildValue("");
		}

		DrawPoint dp;
		dp.location[0] = x;
		dp.location[1] = y;
		dp.location[2] = z;

		pdc->addDrawPoint(pointName, dp);
		return Py_BuildValue("");
	}
	else
	{
		PyErr_Clear();
		Vector color;
		ok = PyArg_Parse(args, "(Osdddddd)", &pPointer, &pointName, &x, &y, &z, &color[0], &color[1], &color[2]);
		if (ok)
		{
					// get pointer and check for errors
			Pose *p = getPoseFromPPointer(pPointer) ;
			if( !p )
			{
				danceInterp::OutputMessage( "Error: addPoint() could not obtain pose from posePointer argument." );
				return Py_BuildValue("");
			}
			PosePDController* pdc = getPDCfromPPointer(pPointer);
			if (!pdc)
			{
				danceInterp::OutputMessage("No controller found. Cannot addPoint().");
				PyErr_Print();
				PyErr_Clear();
				return Py_BuildValue("");
			}

			DrawPoint dp;
			dp.location[0] = x;
			dp.location[1] = y;
			dp.location[2] = z;
			dp.color[0] = color[0];
			dp.color[1] = color[1];
			dp.color[2] = color[2];

			pdc->addDrawPoint(pointName, dp);
			return Py_BuildValue("");

		}
		else
		{
			PyErr_Print();
			PyErr_Clear();
			return Py_BuildValue("");
		}
	}
	
}

PyObject* PoseInterpreter::removePoint(PyObject* self, PyObject* args)
{
 	std::string funcName = "removePoint()";

	PyObject *pPointer;
	char* lineName;

	int ok = PyArg_Parse(args, "(Os)", &pPointer, &lineName);
	if (!ok)
		return scriptError(funcName);

	// get pointer and check for errors
	Pose *p = getPoseFromPPointer(pPointer) ;
	if( !p )
	{
		danceInterp::OutputMessage( "Error: removePoint() could not obtain pose from posePointer argument." );
		return Py_BuildValue("");
	}
	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot removePoint().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	pdc->removeDrawPoint(lineName);
	return Py_BuildValue("");
}

PyObject* PoseInterpreter::addLine(PyObject* self, PyObject* args)
{
 	std::string funcName = "addLine()";

	PyObject *pPointer;
	char* lineName;
	double fromx = 0;
	double fromy = 0;
	double fromz = 0;
	double tox = 0;
	double toy = 0;
	double toz = 0;

	int ok = PyArg_Parse(args, "(Osdddddd)", &pPointer, &lineName, &fromx, &fromy, &fromz, &tox, &toy, &toz);
	if (ok)
	{
		// get pointer and check for errors
		Pose *p = getPoseFromPPointer(pPointer) ;
		if( !p )
		{
			danceInterp::OutputMessage( "Error: addLine() could not obtain pose from posePointer argument." );
			return Py_BuildValue("");
		}
		PosePDController* pdc = getPDCfromPPointer(pPointer);
		if (!pdc)
		{
			danceInterp::OutputMessage("No controller found. Cannot addLine().");
			PyErr_Print();
			PyErr_Clear();
			return Py_BuildValue("");
		}

		DrawLine line;
		line.from[0] = fromx;
		line.from[1] = fromy;
		line.from[2] = fromz;
		line.to[0] = tox;
		line.to[1] = toy;
		line.to[2] = toz;
		
		pdc->addDrawLine(lineName, line);
		return Py_BuildValue("");
	}
	else
	{
		PyErr_Clear();
		Vector color;
		ok = PyArg_Parse(args, "(Osddddddddd)", &pPointer, &lineName, &fromx, &fromy, &fromz, &tox, &toy, &toz, &color[0], &color[1], &color[2]);
		if (ok)
		{
			// get pointer and check for errors
			Pose *p = getPoseFromPPointer(pPointer) ;
			if( !p )
			{
				danceInterp::OutputMessage( "Error: addLine() could not obtain pose from posePointer argument." );
				return Py_BuildValue("");
			}
			PosePDController* pdc = getPDCfromPPointer(pPointer);
			if (!pdc)
			{
				danceInterp::OutputMessage("No controller found. Cannot addLine().");
				PyErr_Print();
				PyErr_Clear();
				return Py_BuildValue("");
			}

			DrawLine line;
			line.from[0] = fromx;
			line.from[1] = fromy;
			line.from[2] = fromz;
			line.to[0] = tox;
			line.to[1] = toy;
			line.to[2] = toz;
			line.color[0] = color[0];
			line.color[1] = color[1];
			line.color[2] = color[2];
			
			pdc->addDrawLine(lineName, line);
			return Py_BuildValue("");

		}
		else
		{
			PyErr_Print();
			PyErr_Clear();
			return Py_BuildValue("");
		}
	}
}

PyObject* PoseInterpreter::removeLine(PyObject* self, PyObject* args)
{
 	std::string funcName = "removeLine()";

	PyObject *pPointer;
	char* lineName;

	int ok = PyArg_Parse(args, "(Os)", &pPointer, &lineName);
	if (!ok)
		return scriptError(funcName);

	// get pointer and check for errors
	Pose *p = getPoseFromPPointer(pPointer) ;
	if( !p )
	{
		danceInterp::OutputMessage( "Error: removeLine() could not obtain pose from posePointer argument." );
		return Py_BuildValue("");
	}
	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot removeLine().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	pdc->removeDrawLine(lineName);
	return Py_BuildValue("");	
}

PyObject* PoseInterpreter::clearGraphics(PyObject* self, PyObject* args)
{
 	std::string funcName = "clearGraphics()";

	PyObject *pPointer;

	int ok = PyArg_Parse(args, "(O)", &pPointer);
	if (!ok)
		return scriptError(funcName);

	// get pointer and check for errors
	Pose *p = getPoseFromPPointer(pPointer) ;
	if( !p )
	{
		danceInterp::OutputMessage( "Error: clearGraphics() could not obtain pose from posePointer argument." );
		return Py_BuildValue("");
	}
	PosePDController* pdc = getPDCfromPPointer(pPointer);
	if (!pdc)
	{
		danceInterp::OutputMessage("No controller found. Cannot clearGraphics().");
		PyErr_Print();
		PyErr_Clear();
		return Py_BuildValue("");
	}

	pdc->removeAllGraphics();
	return Py_BuildValue("");	
}

PyObject* PoseInterpreter::getNumCollisionPoints( PyObject* self, PyObject* args )
{
 	std::string funcName = "getNumCollisionPoints()";

	int linkIndex;
	PyObject *pPointer ;

	int ok = PyArg_ParseTuple(args, "Oi", &pPointer, &linkIndex);
	if (!ok)
		return scriptError(funcName);



	PosePDController *pdc ;
	Sensor *s ;
	if( !getPointersFromPython(pPointer, &pdc, &s) ) return Py_BuildValue("");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");

	Link* link = ao->getLink(linkIndex);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", linkIndex);

	DGeometry* geom = link->getGeometryCollision();
	if (geom == NULL)
	{
		geom = link->getGeometry();
	}
	if (geom == NULL)
	{
		danceInterp::OutputMessage("No geometry found on link %s.", link->getName());
		return Py_BuildValue("");
	}

	int numMonitorPoints = geom->getNumMonitorPoints();

	return Py_BuildValue("i", numMonitorPoints);
}

PyObject* PoseInterpreter::getCollisionPoint( PyObject* self, PyObject* args )
{
	std::string funcName = "getCollisionPoint()";

	int linkIndex, pointIndex;
	PyObject *pPointer ;

	int ok = PyArg_ParseTuple(args, "Oii", &pPointer, &linkIndex, &pointIndex);
	if (!ok)
		return scriptError(funcName);



	PosePDController *pdc ;
	Sensor *s ;
	if( !getPointersFromPython(pPointer, &pdc, &s) ) return Py_BuildValue("");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");;

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");

	Link* link = ao->getLink(linkIndex);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", linkIndex);

	DGeometry* geom = link->getGeometryCollision();
	if (geom == NULL)
	{
		geom = link->getGeometry();
	}
	if (geom == NULL)
	{
		danceInterp::OutputMessage("No geometry found on link %s.", link->getName());
		return Py_BuildValue("");
	}

	int numMonitorPoints = geom->getNumMonitorPoints();
	if (pointIndex >= numMonitorPoints) 
	{
		danceInterp::OutputMessage("Cannot access point %d. Only %d points.", pointIndex, numMonitorPoints);
		return Py_BuildValue("");
	}

	Vector* pts;
	geom->getMonitorPoints(&pts);

	return Py_BuildValue("[ddd]", pts[pointIndex][0], pts[pointIndex][1], pts[pointIndex][2]);
}

PyObject* PoseInterpreter::getLinkPointWorld( PyObject* self, PyObject* args )
{
	std::string funcName = "getLinkPointWorld()";

	int linkIndex;
	PyObject *pPointer ;
	Vector point;

	int ok = PyArg_ParseTuple(args, "Oiddd", &pPointer, &linkIndex, &point[0], &point[1], &point[2]);
	if (!ok)
		return scriptError(funcName);

	PosePDController *pdc ;
	Sensor *s ;
	if( !getPointersFromPython(pPointer, &pdc, &s) ) return Py_BuildValue("");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");
	
	Link* link = ao->getLink(linkIndex);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", linkIndex);

	Vector worldPoint;
	link->getWorldCoord(worldPoint, point);
	
	return Py_BuildValue("[ddd]", worldPoint[0], worldPoint[1], worldPoint[2]);
}

PyObject* PoseInterpreter::getLinkPointLocal( PyObject* self, PyObject* args )
{
	std::string funcName = "getLinkPointLocal()";

	int linkIndex;
	PyObject *pPointer ;
	Vector point;

	int ok = PyArg_ParseTuple(args, "Oiddd", &pPointer, &linkIndex, &point[0], &point[1], &point[2]);
	if (!ok)
		return scriptError(funcName);

	PosePDController *pdc ;
	Sensor *s ;
	if( !getPointersFromPython(pPointer, &pdc, &s) ) return Py_BuildValue("");

	ArticulatedObject* ao = (ArticulatedObject*) s->getSystem();
	if (!ao)
		return scriptError(funcName, "No ArticulatedObject found.");

	DSimulator* sim = ao->getSimulator(0);
	if (!sim)
		return scriptError(funcName, "No Simulator found.");
	
	Link* link = ao->getLink(linkIndex);
	if (!link)
		return scriptError(funcName, "No link found at index %d.", linkIndex);

	Vector localPoint;
	link->getLocalCoord(localPoint, point);
	
	return Py_BuildValue("[ddd]", localPoint[0], localPoint[1], localPoint[2]);
}
