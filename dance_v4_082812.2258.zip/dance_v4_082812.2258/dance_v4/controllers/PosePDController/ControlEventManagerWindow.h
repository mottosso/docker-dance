#ifndef _CONTROLEVENTMANAGERWINDOW_
#define _CONTROLEVENTMANAGERWINDOW_

#include <fltk/Window.h>
#include <fltk/Button.h>
#include <fltk/Input.h>
#include <fltk/CheckButton.h>
#include <fltk/Browser.h>

#include "ControlEventManager.h"
class PosePDControllerWindow;

class ControlEventManagerWindow : public fltk::Window
{
	public:
		ControlEventManagerWindow(PosePDControllerWindow* pwin, int x, int y, int w, int h, char* name);

		void updateGUI();

		PosePDControllerWindow* poseWin;
		static void AddEventBeforeCB(fltk::Widget* widget, void* data);
		static void AddEventAfterCB(fltk::Widget* widget, void* data);
		static void RemoveEventCB(fltk::Widget* widget, void* data);
		static void RemoveAllEventsCB(fltk::Widget* widget, void* data);
		static void SetKSCB(fltk::Widget* widget, void* data);
		static void SetKDCB(fltk::Widget* widget, void* data);
		static void SetCriticalDampingCB(fltk::Widget* widget, void* data);

		ControlEvent* createPoseEvent(Pose* p);

		fltk::Button* buttonAddBefore;
		fltk::Button* buttonAddAfter;
		fltk::Button* buttonRemove;
		fltk::Button* buttonRemoveAll;
		fltk::Input* inputKS;
		fltk::Input* inputKD;
		fltk::CheckButton* checkCriticalDamping;

		fltk::Browser* browserEvents;
};

#endif