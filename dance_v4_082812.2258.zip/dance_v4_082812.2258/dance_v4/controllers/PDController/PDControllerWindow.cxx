/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "PDControllerWindow.h"
#include "PDController.h"
#include <fltk/ask.h>
#include "dance.h"

using namespace fltk;

PDControllerWindow::PDControllerWindow(PDController* c, int x, int y, int w, int h, const char* name) : Group(x, y, w, h, name)
{
	this->controller = c;

	this->begin();

	choiceAO = new Choice(110, 10, 150, 20, "Articulated Object");
	choiceAO->callback(this->SelectAOCB, this);

	Group* groupKsKd = new Group(10, 40, 300, 140);
	groupKsKd->box(fltk::BORDER_BOX);
	groupKsKd->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupKsKd->begin();

	inputStrength = new FloatInput(60, 10, 40, 20, "Strength");
	inputStrength->callback(StrengthCB);
	
	wheelStrength = new ThumbWheel(100, 10, 30, 20);
	wheelStrength->step(.1);
	// set the value according to the PD Controller
	wheelStrength->value(c->getKS());
	wheelStrength->range(0.0, 100000.0);
	wheelStrength->callback(StrengthCB, this);

	inputDamping = new FloatInput(190, 10, 40, 20, "Damping");
	inputDamping->callback(DampingCB);

	wheelDamping = new ThumbWheel(230, 10, 30, 20);
	wheelDamping->step(.1);
	// set the value according to the PD Controller
	wheelDamping->value(c->getKD());
	wheelDamping->range(0.0, 100000.0);
	wheelDamping->callback(DampingCB, this);

	this->checkCriticallyDamped = new CheckButton(10, 35, 100, 20, "Critical Damping");
	this->checkCriticallyDamped->callback(CriticalDampingCB, this);

	checkMaintainLimits = new CheckButton(120, 35, 100, 20, "Maintain joint limits");
	checkMaintainLimits->callback(MaintainLimitsCB, this);

	checkExponentialSprings = new CheckButton(10, 60, 100, 20, "Use Exponential Springs");
	checkExponentialSprings->callback(UseExponentialSpringsCB, this);

	inputMaxTorque = new FloatInput(220, 60, 60, 20, "Max Torque");
	inputMaxTorque->callback(MaxTorqueCB, this);

	inputLinearKS = new FloatInput(80, 85, 30, 20, "Linear Spring KS");
	inputLinearKS->callback(SpringKSKDCB, this);
	inputLinearKD = new FloatInput(200, 85, 30, 20, "Linear Spring KD");
	inputLinearKD->callback(SpringKSKDCB, this);

	inputExponentialKS = new FloatInput(80, 110, 30, 20, "Exp Spring KS");
	inputExponentialKS->callback(SpringKSKDCB, this);
	inputExponentialKD = new FloatInput(200, 110, 30, 20, "Ex Spring KD");
	inputExponentialKD->callback(SpringKSKDCB, this);

	groupKsKd->end();

	checkRagdoll = new CheckButton(10, 190, 100, 20, "Ragdoll Settings");
	checkRagdoll->callback(RagdollCB, this);

	buttonRagdollSettings = new Button(130, 190, 60, 20, "Set Ragdoll");
	buttonRagdollSettings->callback(RagdollSettingsCB, this);

	buttonUseCurrentPose = new Button(10, 215, 100, 20, "Use current pose");
	buttonUseCurrentPose->callback(UseCurrentPoseCB, this);


	this->end();

	this->updateGUI();
}

void PDControllerWindow::show()
{
	this->updateGUI();
	Group::show();
}


void PDControllerWindow::updateGUI()
{
	choiceAO->clear();
	choiceAO->add("Choose an articulated object");
	for (int x = 0; x < dance::AllSystems->size(); x++)
	{
		ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get(x));
		if (ao == NULL)
		{
			// ignore, not an articulated object
		}
		else
		{
			choiceAO->add(ao->getName());
		}
	}

	if (this->controller->getNumAppliedObjects() == 0)
	{
		// deactivate everything
		this->checkExponentialSprings->deactivate();
		this->checkMaintainLimits->deactivate();
		this->checkExponentialSprings->deactivate();
		this->inputMaxTorque->deactivate();
		this->inputStrength->deactivate();
		this->wheelStrength->deactivate();
		this->inputDamping->deactivate();
		this->wheelDamping->deactivate();
		this->checkCriticallyDamped->deactivate();
		this->buttonUseCurrentPose->deactivate();
		this->checkRagdoll->deactivate();
		this->buttonRagdollSettings->deactivate();
		this->inputLinearKS->deactivate();
		this->inputLinearKD->deactivate();
		this->inputExponentialKS->deactivate();
		this->inputExponentialKD->deactivate();
	}
	else
	{
		this->inputLinearKS->activate();
		this->inputLinearKD->activate();
		this->inputExponentialKS->activate();
		this->inputExponentialKD->activate();
		this->checkMaintainLimits->activate();
		this->inputMaxTorque->activate();
		this->inputStrength->activate();
		this->wheelStrength->activate();
		this->inputDamping->activate();
		this->wheelDamping->activate();
		this->checkCriticallyDamped->activate();
		this->buttonUseCurrentPose->activate();
		this->checkRagdoll->activate();
		this->buttonRagdollSettings->activate();
		// choose the appropriate articulated object
		ArticulatedObject* ao = (ArticulatedObject*) this->controller->getAppliedObject(0);

		for (int x = 0; x < choiceAO->size(); x++)
		{
			Widget* w = choiceAO->child(x);
			if (strcmp(ao->getName(), w->label()) == 0)
			{
				choiceAO->value(x);
				break;
			}
		}

		double strength = this->controller->getKS();
		double damping = this->controller->getKD();
		this->inputStrength->value(strength);
		this->wheelStrength->value(strength);
		this->inputDamping->value(damping);
		this->wheelDamping->value(damping);
		if (this->controller->isCriticallyDamped())
		{
			this->inputDamping->deactivate();
			this->wheelDamping->deactivate();
		}
		else
		{
			this->inputDamping->activate();
			this->wheelDamping->activate();
		}

		if (controller->isExponentialJointLimitSprings())
		{
			this->checkExponentialSprings->value(1);
		}
		else
		{
			this->checkExponentialSprings->value(0);
		}

		if (controller->isMaintainJointLimits())
		{
			this->checkMaintainLimits->value(1);
			this->checkExponentialSprings->activate();
		}
		else
		{
			this->checkMaintainLimits->value(0);
			this->checkExponentialSprings->deactivate();
		}

		this->inputMaxTorque->value(controller->getMaxTorque());
		if (this->checkRagdoll->value())
		{
			this->checkMaintainLimits->deactivate();
			this->checkExponentialSprings->deactivate();
			this->inputMaxTorque->deactivate();
			this->wheelStrength->deactivate();
			this->wheelDamping->deactivate();
			this->buttonUseCurrentPose->deactivate();
			this->checkRagdoll->activate();
			this->buttonRagdollSettings->deactivate();
		}

		this->inputLinearKS->value(this->controller->getLinearSpringStiffness());
		this->inputLinearKD->value(this->controller->getLinearSpringDamping());
		this->inputExponentialKS->value(this->controller->getExponentialSpringStiffness());
		this->inputExponentialKD->value(this->controller->getExponentialSpringDamping());

	}

}

void PDControllerWindow::MaintainLimitsCB(fltk::Widget* widget, void* data)
{
	PDControllerWindow* win = (PDControllerWindow*) data;
	CheckButton* check = (CheckButton*) widget;

	if (check->value() == 1)
		win->controller->setMaintainJointLimits(true);
	else
		win->controller->setMaintainJointLimits(false);

	win->updateGUI();
}

void PDControllerWindow::UseExponentialSpringsCB(fltk::Widget* widget, void* data)
{
	PDControllerWindow* win = (PDControllerWindow*) data;
	CheckButton* check = (CheckButton*) widget;

	if (check->value() == 1)
		win->controller->setExponentialJointLimitSprings(true);
	else
		win->controller->setExponentialJointLimitSprings(false);

	win->updateGUI();
}

void PDControllerWindow::StrengthCB(Widget *w, void *data)
{
	PDControllerWindow* window = (PDControllerWindow*) data;
	if (window->inputStrength == w)
		window->wheelStrength->value(window->inputStrength->fvalue());
	else
		window->inputStrength->value(window->wheelStrength->value());

	double value = window->inputStrength->fvalue();
	window->controller->setKS(value);
}

void PDControllerWindow::DampingCB(Widget *w, void *data)
{
	PDControllerWindow* window = (PDControllerWindow*) data;
	if (window->inputStrength == w)
		window->wheelDamping->value(window->inputDamping->fvalue());
	else
		window->inputDamping->value(window->wheelDamping->value());

	double value = window->inputDamping->fvalue();
	window->controller->setKD(value);
}

void PDControllerWindow::UseCurrentPoseCB(fltk::Widget *w, void *data)
{
	PDControllerWindow* window = (PDControllerWindow*) data;

	window->controller->useCurrentPose();

	fltk::alert("%s will now use the current orientation as a PD target.", window->controller->getName());
}

void PDControllerWindow::MaxTorqueCB(fltk::Widget *w, void *data)
{
	PDControllerWindow* window = (PDControllerWindow*) data;

	FloatInput* input = (FloatInput*) w;
	
	window->controller->setMaxTorque(input->fvalue());

	window->updateGUI();
}

void PDControllerWindow::RagdollCB(fltk::Widget *w, void *data)
{
	PDControllerWindow* win = (PDControllerWindow*) data;

	// ragdolls need joint limits in place with small ks and kd parameters
	double ks, kd;
	win->controller->getRagdollSettings(ks, kd);
	win->controller->setKS(ks);
	win->controller->setKD(kd);
	win->controller->setMaintainJointLimits(true);
	win->controller->setExponentialJointLimitSprings(true);

	win->updateGUI();
}


void PDControllerWindow::RagdollSettingsCB(fltk::Widget *w, void *data)
{
	PDControllerWindow* win = (PDControllerWindow*) data;

	double ks = win->wheelStrength->value();
	double kd = win->wheelDamping->value();

	win->controller->setRagdollSettings(ks, kd);
	fltk::alert("Ragdolls will now use ks = %6.4f, kd=%6.4f", ks, kd);

	win->updateGUI();
}

void PDControllerWindow::SelectAOCB(fltk::Widget *w, void *data)
{
	PDControllerWindow* win = (PDControllerWindow*) data;

	Widget* widget = win->choiceAO->child(win->choiceAO->value());

	DSystem* sys = (DSystem*) dance::AllSystems->get((char*) widget->label());
	if (sys != NULL)
	{
		win->controller->setAppliedObject(sys);
	}
	else
	{
		if (win->controller->getNumAppliedObjects() > 0)
		{
			DSystem* sys = win->controller->getAppliedObject(0);
			win->controller->removeAppliedObject(sys);
		}
	}

	win->updateGUI();
}

void PDControllerWindow::SpringKSKDCB(fltk::Widget* widget, void* data)
{
	PDControllerWindow* win = (PDControllerWindow*) data;

	win->controller->setLinearSpringStiffness(win->inputLinearKS->fvalue());
	win->controller->setLinearSpringDamping(win->inputLinearKD->fvalue());
	win->controller->setExponentialSpringStiffness(win->inputExponentialKS->fvalue());
	win->controller->setExponentialSpringDamping(win->inputExponentialKD->fvalue());

	win->updateGUI();
}

void PDControllerWindow::CriticalDampingCB(fltk::Widget* widget, void* data)
{
	PDControllerWindow* win = (PDControllerWindow*) data;

	win->controller->setCriticalDamping(win->checkCriticallyDamped->value());

	win->updateGUI();

}


