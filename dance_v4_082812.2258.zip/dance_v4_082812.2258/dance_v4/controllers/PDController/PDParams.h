/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef PDPARAMS_H
#define PDPARAMS_H

#include <limits>

// See DriveTypeName initialization in PDController.cxx

const double gblDefaultMaxTorque = 1e40;

enum DriveType 
{ 
	StartDriveType, 
	PositionDrive = 0,	// Position constraints.  Use v.
	VelocityDrive,		// Velocity constraints.  Uses vel, maxTorque.
	SpringDrive,		// PD control.  Uses v, ks, kd, maxTorque.
	TorqueDrive,		// Direct torque control.  Uses v and maxTorque.
	TimeSpringDrive,	// PD control.  Uses v as the time to zero the error.
	PerJointType,		// "Dummy" type indicating that each joint can have it's own drive type. 
	EndDriveType,		// Placeholder for end of enum
};


class PDParams
{
	public:
		PDParams( void ) :
            driveType( SpringDrive ), 
			v( 0 ), 
			dv( 0 ), 
			ks( 0 ), 
			kd( 0 ), 
			maxTorque( gblDefaultMaxTorque ), 
			kinematic(false)
        {
            for (int p = 0; p < 3; p++)
                kinematicPos[p] = 0;
            for (int p = 0; p < 3; p++)
                kinematicOrient[p] = 0;
            kinematicOrient[3] = 1.0;
        }

		// copy operator
		PDParams& operator=( const PDParams& p )
		{
			if( this == &p ) return *this;  // make sure these aren't the same object
			driveType = p.driveType;
			v = p.v;
			dv = p.dv;
			ks = p.ks;
			kd = p.kd;
			maxTorque = p.maxTorque;
			  kinematic = p.kinematic;
            for (int i = 0; i < 3; i++)
                kinematicPos[i] = p.kinematicPos[i];
            for (int i = 0; i < 4; i++)
                kinematicOrient[i] = p.kinematicOrient[i];
			return *this;
		}

		DriveType driveType; //< the "type" of drive to drive the joint being controlled.  Determines the interpretation of other PDParam vars.
							 //< Since all degrees of freedom of a joint must use the same drive type,
							 //< only the joint's first PDParam entry is used to specify the driveType. 
		double v;		//< desired "value", angular position in radians for SpringDrives, 
						//  the desired torque to be applied for TorqueDrives, and the 
		double dv;		//< desired first-derivative of the value, angular velocity for SpringDrives.
		double ks;		//< spring constant with SpringDrive, and velocity with VelocityDrive
		double kd;		//< damping constant with SpringDrive, and velocity damping with VelocityDrive
		double maxTorque;  //< max torque to be applied, used with all drive types. ( maxTorque =< 0, defaults to infinity )

		bool kinematic;  // set to true if this body is set to kinematic mode
        double kinematicPos[3];    //  desired kinematic position
        double kinematicOrient[3]; // desired kinematic orientation
};

#endif
