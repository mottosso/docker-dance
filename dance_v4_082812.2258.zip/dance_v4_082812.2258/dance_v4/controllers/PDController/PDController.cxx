/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos
DANCE
Dynamic ANimation and Control Environment
 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************
This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 
Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.
Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */
/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos
	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "PDController.h"
#include "PDControllerWindow.h"
#include "danceInterp.h"
#include "dance.h"
#include "DSimulator.h"
#include "Joint.h"
#include "Link.h"
#include "Quaternion.h"
#include "assert.h"
#include <sstream>
#include <cstdio>
using namespace fltk;
const double epsilon = 0.00001;
const char* DriveTypeName[] = 
{ 
	"Position", 
	"Velocity", 
	"Spring",
	"Torque",
	"TimeSpring",
	"Per Joint",
	"\0"
};
PlugIn* Proxy()
{
	return (new PDController(NULL));
}
PlugIn* PDController::create(int argc, char **argv)
{
	PDController *f = NULL;
	if (argc >= 1)
	{
		ArticulatedObject* ao = (ArticulatedObject*) dance::AllSystems->get(argv[0]);
		if (ao == NULL)
		{
			danceInterp::OutputMessage("ArticulatedObject %s was not found...", argv[0]);
			return NULL;
		}
		f = new PDController(ao);
	}
	else
	{
		f = new PDController();
	}
    
    if (f == NULL )
    {
		danceInterp::OutputMessage("Cannot allocate memory!\n") ;
		return NULL ;
	}
    return f ;
}
PDController::PDController()
: m_isUsingBackwardEuler( false ),
  m_substeps( 1 ),
  m_aoDriveType( SpringDrive ),
  m_lastControlUpdate( -999.0 ),
  m_controlUpdateRate( .00001 ),
  m_jointRecorded( "" ),
  m_jointrecordedAxis( 0 ),
  m_useMocap( false ),
  m_loadMocap( false ),
  windowCount( 0 ),
  keyFrame( 0 )
{
	m_pdControllerWindow = NULL;
	setKS(1.0);
	setKD(.1);
	setExponentialJointLimitSprings(true);
	setMaintainJointLimits(false);
	setMaxTorque(2000);
	setMaxVelocity( 2000 );
	setRagdollSettings(0, .1);
	this->setLinearSpringStiffness(10.0);
	this->setLinearSpringDamping(1.0);
	this->setExponentialSpringStiffness(10.0);
	this->setExponentialSpringDamping(1.0);
	this->setEulerAngleParameterization(true);
	dance::AllSimulators->addSimStartCB(this, -1, this->simstart);
	this->resetPDParams();
	this->setCriticalDamping(true);
	this->setTension(5.0);
	this->setUseTension(false);
	this->setUsingTotalInertia(false);
	m_useGyroAdj = false ;
	zeroVector(dummyRoot);
}
PDController::PDController(ArticulatedObject* ao)
: m_isUsingBackwardEuler( false ),
  m_substeps( 1 ),
  m_aoDriveType( SpringDrive ),
  m_useGyroAdj( false ),
  m_lastControlUpdate( -999 ),
  m_controlUpdateRate( .00001 ),
  m_jointRecorded( "" ),
  m_jointrecordedAxis( 0 ),
  m_useMocap( false ),
  m_loadMocap( false ),
  windowCount( 0 ),
  keyFrame( 0 )
{
	m_pdControllerWindow = NULL;
	setKS(1.0);
	setKD(.1);
	if (ao != NULL)
	{
		this->setAppliedObject(ao);
		m_aoStateSize = ao->getStateSize();
		resetPDParams();
	}
	setExponentialJointLimitSprings(true);
	setMaintainJointLimits(false);
	setMaxTorque(2000);
	setMaxVelocity( 2000 );
	setRagdollSettings(0.0, 0.0);
	this->setLinearSpringStiffness(10.0);
	this->setLinearSpringDamping(1.0);
	this->setExponentialSpringStiffness(10.0);
	this->setExponentialSpringDamping(1.0);
	this->setTension(5.0);
	this->setUseTension(false);
	this->setUsingTotalInertia(false);
	this->setCriticalDamping(true);
	
	dance::AllSimulators->addSimStartCB(this, -1, this->simstart);
	this->resetPDParams();
}
PDController::~PDController()
{
	if (this->m_pdControllerWindow != NULL)
		delete m_pdControllerWindow;
}
int PDController::commandPlugIn(int argc, char **argv)
{
	int ret = DActuator::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;
	if( strcmp(argv[0], "use_exp_springs") == 0 )
	{
		if( argc < 2 )
		{
			danceInterp::OutputMessage("Usage: use_exp_springs <true|false>") ;
			return DANCE_ERROR;
		}
		else
		{
			if (strcmp(argv[1], "true") == 0)
			{
				setExponentialJointLimitSprings(true);
				danceInterp::OutputMessage("Exponential springs will be used to enforce limits.");
				return DANCE_OK;
			}
			else if (strcmp(argv[1], "false") == 0)
			{
				setExponentialJointLimitSprings(false);
				danceInterp::OutputMessage("Linear springs will be used to enforce limits.");
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Usage: use_exp_springs <true|false>") ;
				return DANCE_ERROR;
			}
		}
	}
	if( strcmp(argv[0], "use_gyro_adj") == 0 )
	{
		if( argc < 2 )
		{
			danceInterp::OutputMessage("Usage: use_gyro_adj <true|false>") ;
			return DANCE_ERROR;
		}
		else
		{
			if (strcmp(argv[1], "true") == 0)
			{
				m_useGyroAdj = true ;
				danceInterp::OutputMessage("GyroAdj is on.");
				return DANCE_OK;
			}
			else if (strcmp(argv[1], "false") == 0)
			{
				m_useGyroAdj = false ;
				danceInterp::OutputMessage("GyroAdj is off.");
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Usage: use_gyro_adj <true|false>") ;
				return DANCE_ERROR;
			}
		}
	}
	else if( strcmp(argv[0], "maintain_limits") == 0 )
	{
		if( argc < 2 )
		{
			danceInterp::OutputMessage("Usage: maintain_limits <true|false>") ;
			return DANCE_ERROR;
		}
		else
		{
			if (strcmp(argv[1], "true") == 0)
			{
				this->setMaintainJointLimits(true);
				danceInterp::OutputMessage("Joint limits will be enforced.");
				return DANCE_OK;
			}
			else if (strcmp(argv[1], "false") == 0)
			{
				this->setMaintainJointLimits(false);
				danceInterp::OutputMessage("Joint limits will not be enforced.");
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Usage: maintain_limits <true|false>") ;
				return DANCE_ERROR;
			}
		}
	}
	else if( strcmp(argv[0], "ragdoll") == 0 )
	{
		if( argc < 3 )
		{
			danceInterp::OutputMessage("Usage: ragdoll <ks> <kd>") ;
			return DANCE_ERROR;
		}
		else
		{
			double ks = atof(argv[1]);
			double kd = atof(argv[2]);
			this->setRagdollSettings(ks, kd);
			danceInterp::OutputMessage("Ragdoll settings are now %6.4f, %6.4f", ks, kd);
			return DANCE_OK;
		}
	}
	else if( strcmp(argv[0], "max_torque") == 0 )
	{
		if( argc < 2 )
		{
			danceInterp::OutputMessage("Usage: max_torque <val>") ;
			return DANCE_ERROR;
		}
		else
		{
			double max = atof(argv[1]);
			this->setMaxTorque(max);
			danceInterp::OutputMessage("Max torque is now %f.", this->getMaxTorque());
			return DANCE_OK;
		}
	}
	else if( 0 == strcmp(argv[0], "max_velocity") )
	{
		if( argc < 2 )
		{
			danceInterp::OutputMessage( "Usage: max_velocity <val>" ) ;
			return DANCE_ERROR;
		}
		else
		{
			double max = atof( argv[1] );
			setMaxVelocity( max );
			danceInterp::OutputMessage( "Max velocity is now %f.", getMaxVelocity() );
			return DANCE_OK;
		}
	}
	else if (strcmp(argv[0], "use_current_pose") == 0)
	{ // extract the current pose from the articulated object
		this->useCurrentPose();
		danceInterp::OutputMessage("PD Controller %s now set to current pose as target pose.", this->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "ks") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: actuator %s ks <val>", this->getName());
			return DANCE_ERROR;
		}
		double ks = atof(argv[1]);
		this->setKS(ks);
		danceInterp::OutputMessage("KS is now %f", this->getKS());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "kd") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: actuator %s kd <val>", this->getName());
			return DANCE_ERROR;
		}
		double kd = atof(argv[1]);
		this->setKD(kd);
		danceInterp::OutputMessage("KD is now %f", this->getKD());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "linearks") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: actuator %s linearks <val>", this->getName());
			return DANCE_ERROR;
		}
		double ks = atof(argv[1]);
		this->setLinearSpringStiffness(ks);
		danceInterp::OutputMessage("Linear spring KS is now %f", this->getLinearSpringStiffness());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "linearkd") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: actuator %s linearkd <val>", this->getName());
			return DANCE_ERROR;
		}
		double kd = atof(argv[1]);
		this->setLinearSpringDamping(kd);
		danceInterp::OutputMessage("Linear spring KD is now %f", this->getLinearSpringDamping());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "exponentialks") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: actuator %s exponentialks <val>", this->getName());
			return DANCE_ERROR;
		}
		double ks = atof(argv[1]);
		this->setExponentialSpringStiffness(ks);
		danceInterp::OutputMessage("Exponential spring KS is now %f", this->getExponentialSpringStiffness());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "exponentialkd") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: actuator %s exponentialkd <val>", this->getName());
			return DANCE_ERROR;
		}
		double kd = atof(argv[1]);
		this->setLinearSpringDamping(kd);
		danceInterp::OutputMessage("Exponential spring KD is now %f", this->getExponentialSpringDamping());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "params_v") == 0)
	{
		for (int x = 1; x < argc; x++)
		{
			double val = atof(argv[x]);
			this->m_params[x - 1].v = val;
		}
		danceInterp::OutputMessage("Loaded %d pd control values.", argc - 1);
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "params_ks") == 0)
	{
		for (int x = 1; x < argc; x++)
		{
			double val = atof(argv[x]);
			this->m_params[x - 1].ks = val;
		}
		danceInterp::OutputMessage("Loaded %d pd control values ks.", argc - 1);
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "params_kd") == 0)
	{
		for (int x = 1; x < argc; x++)
		{
			double val = atof(argv[x]);
			this->m_params[x - 1].kd = val;
		}
		danceInterp::OutputMessage("Loaded %d pd control values kd.", argc - 1);
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "tension") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: tension <val>");
			return DANCE_ERROR;
		}
		double t = atof(argv[1]);
		this->setTension(t);
		danceInterp::OutputMessage("Tension is now %f", this->getTension());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "usetension") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: usetension <true> <false>");
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "true") == 0)
		{
			this->setUseTension(true);
			danceInterp::OutputMessage("Tension will be used.");
		}
		else
		{
			this->setUseTension(false);
			danceInterp::OutputMessage("Tension will not be used.");
		}
		return DANCE_OK;
	}
	else if ( strcmp( argv[0], "critically_damped") == 0 )
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: critically_damped <true> <false>");
			return DANCE_ERROR;
		}
		bool val = (strcmp(argv[1], "true") == 0);
		setCriticalDamping( val );
		if (val)
		{
			danceInterp::OutputMessage("Setting critically damped to true.");
		}
		else
		{
			danceInterp::OutputMessage("Setting critically damped to false.");
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "use_total_inertia") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: use_total_inertia <true> <false>");
			return DANCE_ERROR;
		}
		bool shouldUseTotalInertia = (strcmp(argv[1], "true") == 0);
		this->setUsingTotalInertia(shouldUseTotalInertia);
		if (shouldUseTotalInertia)
		{
			danceInterp::OutputMessage("Critical damping will now use the Total Inertia.");
		}
		else
		{
			danceInterp::OutputMessage("Critical damping will no longer use the Total Inertia.");
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "drive_type") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: drive_type <%s>.  Current drive is %s", (getAllDriveTypesNames()).c_str(), (getDriveTypeName()).c_str() );
			return DANCE_ERROR;
		}
		setDriveType( argv[1] );
		danceInterp::OutputMessage("drive_type is now %s", (getDriveTypeName()).c_str() );
		return DANCE_OK;
	}
	else if( strcmp( argv[0], "record_joint" ) == 0 )
	{
		if( argc < 3 )
		{
			danceInterp::OutputMessage( "Usage: record_joint <joint name> <axis index>.  Current joint being recorded is \"%s\" axis %d.",
				m_jointRecorded.empty() ? "none" : m_jointRecorded.c_str(), m_jointrecordedAxis );
			return DANCE_ERROR;
		}
		m_jointRecorded = argv[1];
		if( m_jointRecorded == "none" )
		{
			m_jointRecorded.clear();
		}
		m_jointrecordedAxis = atoi( argv[2] );
		danceInterp::OutputMessage( "Now recording joint \"%s\" axis %d.",
			m_jointRecorded.empty() ? "none" : m_jointRecorded.c_str(), m_jointrecordedAxis );
		return DANCE_OK;
	}
	else if( strcmp( argv[0], "use_backwards_euler" ) == 0 )
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: use_backwards_euler <true> <false>");
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "true") == 0)
		{
			this->setUsingBackwardEuler( true );
			danceInterp::OutputMessage("Backwards Euler will be used.");
		}
		else
		{
			this->setUseTension(false);
			danceInterp::OutputMessage("Backwards Euler will not be used.");
		}
		return DANCE_OK;		
	}
	else if( strcmp( argv[0], "use_mocap" ) == 0 )
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: use_mocap <true> <false>");
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "true") == 0)
		{
			m_useMocap = true;;
			danceInterp::OutputMessage("Mocap will be used.");
		}
		else
		{
			m_useMocap = false;
			danceInterp::OutputMessage("Mocap will not be used.");
		}
		return DANCE_OK;		
	}
	else if( strcmp( argv[0], "load_mocap" ) == 0 )
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: load_mocap <true> <false>");
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "true") == 0)
		{
			m_loadMocap = true;;
			danceInterp::OutputMessage("Mocap will be loaded.");
		}
		else
		{
			m_loadMocap = false;
			danceInterp::OutputMessage("Mocap will not be loaded.");
		}
		return DANCE_OK;		
	}
	else if (strcmp(argv[0], "substeps") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: substeps <int val>" );
			return DANCE_ERROR;
		}
		int substeps = atoi( argv[1] );
		setSubsteps( substeps );
		danceInterp::OutputMessage("Now using %d substeps", getSubsteps() );
		return DANCE_OK;
	}
	return DANCE_CONTINUE;
}
void PDController::useCurrentPose()
{
	// extract the current pose from the articulated object
	if (this->getNumAppliedObjects() > 0)
	{
		ArticulatedObject* ao = (ArticulatedObject*) this->getAppliedObject(0);
		double* state = new double[ao->getStateSize()];
		ao->getState(state);
		for (int x = 0; x < ao->getStateSize(); x++)
		{
			this->m_params[x].v = state[x];
			//this->m_params[x].ks = this->getKS();
			//this->m_params[x].kd = this->getKD();
		}
		delete state;
	}
}
void PDController::ExertLoad(DSystem *sys, DSimulator* sim, double time, double dt, double *state, double *dstate)
{
	if( !isEnabled )
		return ;
	if (!isInApplyList(sys))
		return ;
	
	ArticulatedObject* ao = (ArticulatedObject*) sys;
	applyPDParams(time, ao, state, dstate);
	
	applyState(sim, ao, state, dstate);
	if (this->isMaintainJointLimits())
	{
		maintainLimits(sim, ao, state, dstate);
	}
}
void PDController::applyPDParams(double time, ArticulatedObject* ao, double *state, double *dstate)
{
	// this method should be overridden by parent controllers
}
void PDController::resetPDParams()
{
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(this->getAppliedObject(0));
	int size = MAX_STATE;
	if (ao != NULL)
		ao->getStateSize();
	for (int i = 0; i < size; i++)
	{
		m_params[i].v = 0.0;
		m_params[i].ks = this->getKS();
		m_params[i].kd = this->getKD();
	}
}
Widget* PDController::getInterface()
{
	if (m_pdControllerWindow == NULL)
	{
		m_pdControllerWindow = new PDControllerWindow(this, 0, 0, 300, 500, this->getName());
	}
	return m_pdControllerWindow;
}
/// Ensure that the m_params is within the joint limits
void PDController::honorLimits( DSimulator* argSim, ArticulatedObject* argAO )
{
	Joint **joint = argAO->getJoints();
	for(int j = 0; j < argAO->getNumJoints(); j++ )
	{
		int numAxes = 0;
		switch (joint[j]->getJointType())
		{
		case J_FREE:
		case J_PLANAR:
			numAxes = 0;
			break;
		case J_BALL:
		case J_GIMBAL:
			numAxes = 3;
			break;
		case J_UNIVERSAL:
			numAxes = 2;
			break;
		case J_PIN:
			numAxes = 1;
			break;
		}
		VectorObj eulerAngles;
		if (joint[j]->getJointType() == J_BALL)
		{
			int indx = argSim->GetIndex(j, 0);
			Quaternion q(m_params[indx].v, m_params[indx + 1].v, m_params[indx + 2].v, m_params[indx + 3].v );
			q.normalize() ;
			Matrix3x3 matrix;
			q.toMatrix(matrix);
			matrix.matToEuler(Matrix3x3::XYZ, eulerAngles, false);
		}
		for (int a = 0; a < numAxes; a++ )
		{
			int indx = argSim->GetIndex(j,a);
			double low, high;
			joint[j]->getLimits(a, &low, &high) ;
			low = low * M_PI / 180.0;
			high = high * M_PI / 180.0;
			double desired = m_params[indx].v;
			if (joint[j]->getJointType() == J_BALL)
			{
				desired = eulerAngles[a];
			}
			const double epsilon = 0.001;
			if ( (high - low) > ( 2.0 * epsilon ) )
			{
				if ( desired > high )
				{
					m_params[indx].v = high - epsilon;
				} 
				else if( desired < low )
				{
					m_params[indx].v = low + epsilon;
				}
			}
		} //foreach axes
	} //foreach joint
}

void PDController::applyState(DSimulator *sim, ArticulatedObject* ao, double *state, double *dstate)
{
	// applies the values of the PD parameters as torques via PD equation: 
	// torque = ks * (desired_position - current_position) - kd * (angular_velocity)
	double torq = 0 ;
	Joint **joint = ao->getJoints();
	//$$$$$HACK --
	ArticulatedObject* dummyAo = (ArticulatedObject*) dance::AllSystems->get("dummyStretch");
	if (m_loadMocap == true && m_useMocap == true)
	{
		dummyAo->getAnimationSequence()->load("C:/Documents and Settings/Derek/My Documents/dance_v3/run/trackMocap.bvh");
		m_loadMocap = false;
		dummyAo->getAnimationSequence()->getKeyFrameByIndex(0);
	}
	double dt = dance::AllSimulators->getSimulationTimeStep();
	double windowSize = getKS();
	double currTime = dance::AllSimulators->getCurrentTime();
	double targetTime = currTime + windowSize;
	double* nextDummyState = NULL;
	static int flag = 0;
	//std::vector< double > nextDummyState;
	if (m_useMocap)
	{
		//nextDummyState = new double[dummyAo->getStateSize()];
//		dummyAo->getState( nextDummyState );
		if (currTime < 2.210)
	{
			dummyAo->setState(currTime + windowSize);
	}
		//nextDummyState = new double[dummyAo->getStateSize()];
		//double countTime = windowCount * windowSize;
		//if (countTime - currTime < dt)
		//{
		//	//keyFrame = currTime + windowSize;
		//	dummyAo->setState( targetTime + dt);
		//	//dummyAo->getState( nextDummyState );
		//	dummyAo->setState( targetTime );
		//
		////	dummyAo->getState( staticWindowState );
		//	windowCount++;
		//}
	}
	//$$$$$ -- HACK
	// State of dummy AO after this point is the current window
//	dummyAo->setState( staticWindowState );
	if( isUsingTotalInertia() )
	{
		// TODO - reset the root of the skeleton 
		ao->calcTotalInertia();
		// Zero the acceleration accumulation buffers
		for(int i = 0; i < ao->getNumLinks(); i++ )
		{
			ao->getLink(i)->resetParentCalculatedAngularAccel();
		}
	}
	honorLimits( sim, ao );
	double stiffness = 0.0;
	double damping = 0.0;
	FILE* jointFile = 0;
	for(int j = 0; j < ao->getNumJoints(); j++ )
	{
		bool isRecordJoint = false;
		if( !m_jointRecorded.empty() )
		{
			if( 0 == m_jointRecorded.compare( joint[j]->getName() ) )
			{
				if( !jointFile )
				{
					// Open joint file
					std::stringstream filename;
					filename << "JointData_" << m_jointRecorded << ".dat";
					jointFile = fopen( filename.str().c_str(), "a" );  // appending
				}
				isRecordJoint = true;
			}
		}
		int jointParamsIndex = this->convertIndexSimtoAO(sim->GetIndex(j, 0));
		int type = joint[j]->getJointType();
		Link* link = joint[j]->getOutboardLink();

		// if the body is set to kinematic mode, create a spring that
		// will draw the body towards the desired location
		int sindex = sim->GetIndex(j, 0);
		int aindex = this->convertIndexSimtoAO(sindex);
		PDParams& pdp = m_params[aindex];
		if (pdp.kinematic)
		{
			sim->SetPosition(j, &pdp.kinematicPos[0]);
			Quaternion quat(pdp.kinematicOrient[0], pdp.kinematicOrient[1], pdp.kinematicOrient[2], pdp.kinematicOrient[3]);
			Matrix3x3 mat;
			quat.toMatrix(mat);
			double m[3][3];
			for (int r = 0; r < 3; r++)
				for (int c = 0; c < 3; c++)
					m[r][c] = mat[r][c];
			sim->SetOrientation(j, m);
			continue;
		}

		const InertiaTensor& d = link->getTotalInertiaTensor();
		Matrix3x3 totalInertia; 
		d.getInertia( totalInertia );
		DriveType jointDriveType = m_aoDriveType;
		if( jointDriveType == PerJointType )
		{
			jointDriveType = m_params[jointParamsIndex].driveType;
		}
		if (type ==	J_FREE)
		{
			
		}
		else if (type == J_PLANAR)
		{
			assert(false) ;
		}
		else if (type == J_SLIDER)
		{
			assert(false) ;
		}
		else if (type == J_UNIVERSAL || type == J_PIN || type == J_GIMBAL)
		{
			//////////////////////////////////////////////////////////////////////////
			// Beginning of Pin/Universal/Gimbal Joints
			//////////////////////////////////////////////////////////////////////////
			Vector targetVel;
			Vector maxTorque;
			zeroVector( targetVel );
			for (int a = 0; a < joint[j]->getStateSize(); a++ )
			{
				int simIndex = sim->GetIndex(j, a) ;
				int aoIndex = this->convertIndexSimtoAO(simIndex);
				PDParams& pdp = m_params[aoIndex];
				
				maxTorque[a] = std::min( getMaxTorque(), pdp.maxTorque );
				
				double curstate = state[simIndex];
				if (curstate > 2 * M_PI)
					curstate -= 2 * M_PI;
				else if (curstate < -M_PI)
					curstate += 2 * M_PI;
				
				if (m_params[aoIndex].v > 2 * M_PI)
					m_params[aoIndex].v -= 2 * M_PI;
				else if (m_params[aoIndex].v < -M_PI)
					m_params[aoIndex].v += 2 * M_PI;
				//////////////////////////////////////////////////////////////////////////
				// Compute the moment of inertia
				double moment = 0; // set immediately below by either total moment or local moment
				if( isUsingTotalInertia() )
				{
					// Compute the moment around this joint's a-th axis
					// index a into axes is the current axes in joint-local coords
					double axes[3][3];
					joint[j]->getAxis(axes);
					Vector lclAxisOfRotation;
					for( int i = 0; i < 3; ++i ) lclAxisOfRotation[i] = axes[a][i];
					Vector offsetOfRotation;
					joint[j]->getBodyToJoint( offsetOfRotation );
					moment = d.getMoment( lclAxisOfRotation, offsetOfRotation );
				}
				else 
				{
					// not using composite inertia, so sample the local inertia
					double* inertia = joint[j]->getOutboardLink()->getInerTensor();
					int order = joint[j]->determineRotationOrder();
					moment = computeLocalMoment( type, order, inertia, a );
				}
				//////////////////////////////////////////////////////////////////////////
				// Compute Stiffness constant
				if( TimeSpringDrive == jointDriveType )
				{
					//double timeToReachPose = getKS();  // overloading interface of "stiffness" for time info
					double timeToReachPose = pdp.ks;
					// $$$$$HACK -- 
					if (m_useMocap == true)
					{
						timeToReachPose = windowSize;
					}
					computeTimedSpringConstants( stiffness, damping, moment, timeToReachPose );
				} 
				else
				{
					// not-time-spring drives, so compute stiffness and damping from parameters
						stiffness = joint[j]->getStiffness(a);
					//stiffness = m_params[aoIndex].ks;
						stiffness = stiffness * getKS();
					//stiffness = stiffness * m_params[aoIndex].ks;  
					//////////////////////////////////////////////////////////////////////////
					// Compute Damping constant
					if( isCriticallyDamped() )
					{
						bool isLimitSpringConstants = false;
						// compute critically damped kd based on moment
						damping = 2.0 * sqrt( stiffness * getKS() * moment );
					}
					else
					{
							damping = joint[j]->getDamping(a);
						//damping = m_params[aoIndex].kd;
							damping = damping * getKD();
						//damping = damping * m_params[aoIndex].kd; ;
					}
				}
				//////////////////////////////////////////////////////////////////////////
				double diff = m_params[aoIndex].v - curstate ;
				if (m_useMocap)
				{
					diff = dummyAo->getState(aoIndex);
				}
				if (diff < -M_PI)
					diff += 2 * M_PI;
				else if (diff > M_PI)
					diff -= 2 * M_PI;
				if( SpringDrive == jointDriveType || TimeSpringDrive == jointDriveType )
				{
					if (this->isCriticallyDamped() && !isUsingTotalInertia())
					{
						torq = stiffness * diff - damping * dstate[simIndex] ;
					}
					else
					{
						torq = stiffness * pdp.ks * diff - damping * pdp.kd * dstate[simIndex] ;
					}
				}
				if( VelocityDrive == jointDriveType )
				{
					double velocityScale = getKS() * pdp.ks;
					double dampingFactor = getKD() * pdp.kd;
					targetVel[a] = clampVelocity( velocityScale * diff - dampingFactor * dstate[simIndex] );
				}
				if( TorqueDrive == jointDriveType )
				{
					torq = pdp.v;
				}
				//////////////////////////////////////////////////////////////////////////
				// Apply the drive (per-axis)
				// Torque-based drives  (constraint drives are handled below)
				if( TimeSpringDrive == jointDriveType || SpringDrive == jointDriveType || TorqueDrive == jointDriveType )
				{
					double axes[3][3];
					link->getParentJoint()->getAxis( axes );
					//double parentTorque = link->getParentCalculatedAngularAccel( a ) * d.getMoment( axes[a] );  // f = m a
					//torq -= parentTorque;
					torq = clampTorque( torq ); // clamp to AO limit
					torq = std::max( -pdp.maxTorque, torq );
					torq = std::min(  pdp.maxTorque, torq );
					if( isUsingTotalInertia() )
					{
						//link->accumCalculatedAngularAccel( a, torq / moment );
						//link->accumCalculatedAngularAccel( torq / moment );
					}
					sim->GeneralizedForce( j, a, torq );
					if( isRecordJoint && (m_jointrecordedAxis == a) && jointFile )
					{
						fprintf( jointFile, "%s\t%d\t%f\t%f\t%f\t%f\t%f\t\n", m_jointRecorded.c_str(), a, dance::AllSimulators->getCurrentTime(), sim->getTimeStep(), torq, stiffness, damping);//, parentTorque );
					}
				}
			} // loop on axes
			//////////////////////////////////////////////////////////////////////////
			// Apply the drive (once for all axes)
			// Constraint-based drives
			if( VelocityDrive == jointDriveType )
			{
				Vector dampingVector;
				zeroVector( dampingVector );
				Vector stiffnessVector;
				zeroVector( stiffnessVector );
				// NOTE: it is reasonable to scale max torque by the stiffness of the joint
				sim->SetupVelocityDrive( j, stiffnessVector, dampingVector, maxTorque );
				sim->ApplyVelocityDrive( j, targetVel );
 			}
			else
			{
				deactivateVelocityDrive(sim, j);
			}
			if( PositionDrive == jointDriveType )
			{
				danceInterp::OutputMessage( "PositionDrive not implemented for Pin/Uni/Gimbal joints.\n" );
				// TODO: implement position drives
			}
			//////////////////////////////////////////////////////////////////////////
			// End of Pin/Universal/Gimbal Joints
			//////////////////////////////////////////////////////////////////////////
		}
		else if (type == J_BALL || m_useMocap) // as per Michael Neff's suggestion
		{
			//////////////////////////////////////////////////////////////////////////
			// Start of Ball Joints.
			//	Ball joints are broken out separately because their state is stored as 
			//  quaternions, which compute the error term differently from simple 
			//	angles.  A suggested refactoring is to eliminate the duplication 
			//	between this block and the Pin/Uni/Gimbal joint block above.  
			//////////////////////////////////////////////////////////////////////////
			// use the largest stiffness and damping term
			stiffness = 0;
			damping = 0;
			double ballStiffness[3];
			double ballDamping[3];
			// Stiffness and Damping are defined for each of the three
			// directions that torque will be applied.
			// The value used is the joint's times the controller param value.
			for( int i = 0; i < 3; ++i )
			{
				double jointStiff = joint[j]->getStiffness(i);
				double jointDamp = joint[j]->getDamping(i);
				int simIndex = sim->GetIndex(j, i) ;
				int aoIndex = this->convertIndexSimtoAO(simIndex);
				
				//double jointStiff = m_params[aoIndex].ks;
				//double jointDamp = m_params[aoIndex].kd;
				
				//ballStiffness[i] = m_params[aoIndex].ks;
				//ballDamping[i] = m_params[aoIndex].kd;
					ballStiffness[i] = jointStiff * getKS();
					ballDamping[i] = jointDamp * getKD();
				}
			// note that gain values for ball joints need to be scaled since the magnitude
			// of the error is different for angle rates (gimbal, pin, universal joints)
			// than for quaternion values (ball joints)
//			stiffness *= M_PI * 15;
//			damping *= M_PI * 15;			
			int sindex = sim->GetIndex(j, 0);
			int aindex = this->convertIndexSimtoAO(sindex);
			int rotationOrder = joint[j]->determineRotationOrder();
//			int dummyAIndex = this->getDummyMappings(sindex);
			// create the desired rotation
			//$$$$$HACK --
			Quaternion desiredQuat, currentQuat;
			if (m_useMocap == true)
			{
				currentQuat.set(state[sindex], state[sindex + 1], state[sindex + 2], state[sindex + 3]);
				desiredQuat = dummyAo->getJoint(j)->getQuaternion();
				assert( abs( desiredQuat.length() - 1.0 ) < 0.1 );
			}
			else
			{
				currentQuat.set(state[sindex], state[sindex + 1], state[sindex + 2], state[sindex + 3]);
				desiredQuat.set(m_params[aindex].v, m_params[aindex + 1].v, m_params[aindex + 2].v, m_params[aindex + 3].v);
				
			}
			
			//$$$$$ -- HACK 
			currentQuat.normalize();
			desiredQuat.normalize();
			/// Compute the error in orientation error = deisred*inv(current)
			/// sort of equivalent to dx = xdesired - xcurrent in terms of position
			Quaternion qError;
			qError.error( desiredQuat, currentQuat);
			qError.normalize() ;
			double sign = qError[3] > 0? 1.0 : -1.0;
			
			// compensate for gyroscopic effects
			double* inertia = joint[j]->getOutboardLink()->getInerTensor();
			Vector adj;
			adj[0] = (inertia[8] - inertia[4]) * dstate[sindex + 1] * dstate[sindex + 2];
			adj[1] = (inertia[0] - inertia[8]) * dstate[sindex + 2] * dstate[sindex];
			adj[2] = (inertia[4] - inertia[0]) * dstate[sindex] * dstate[sindex + 1];
			if( isUsingTotalInertia() && m_useGyroAdj )
			{
				// Update Gyroscopic/Coriolis adjustment for new inertia tensor
				// including the off-diagonal terms
				adj[0] = (totalInertia[2][2] - totalInertia[1][1]) * dstate[sindex + 1] * dstate[sindex + 2];
				adj[0] += totalInertia[1][2] * ( dstate[sindex + 1] * dstate[sindex + 1] - dstate[sindex + 2] * dstate[sindex + 2] );
				adj[0] += dstate[sindex] * ( dstate[sindex + 2] * totalInertia[0][1] + dstate[sindex + 1] * totalInertia[0][2] );
				adj[1] = (totalInertia[0][0] - totalInertia[2][2]) * dstate[sindex + 2] * dstate[sindex];
				adj[1] += totalInertia[0][2] * ( dstate[sindex + 2] * dstate[sindex + 2] - dstate[sindex] * dstate[sindex] );
				adj[1] += dstate[sindex + 1] * ( dstate[sindex + 2] * totalInertia[0][1] + dstate[sindex] * totalInertia[1][2] );
				adj[2] = (totalInertia[1][1] - totalInertia[0][0]) * dstate[sindex] * dstate[sindex + 1];
				adj[2] += totalInertia[0][1] * ( dstate[sindex] * dstate[sindex] - dstate[sindex + 1] * dstate[sindex + 1] );
				adj[2] += dstate[sindex + 2] * ( dstate[sindex] * totalInertia[1][2] + dstate[sindex + 1] * totalInertia[0][2] );
			}
			Vector targetVelocity;
			Vector targetTorque;
			for (int x = 0; x < 3; x++)
			{
				double moment = 0; // set immediately below by either total moment
				if (this->isCriticallyDamped())
				{
					bool isLimitSpringConstants = false;
					if( this->isUsingTotalInertia() )
					{
						Vector lclAxisOfRotation;
						for( int i = 0; i < 3; ++i ) lclAxisOfRotation[i] = ( x == i );
						Vector offsetOfRotation;
						joint[j]->getBodyToJoint( offsetOfRotation );
						moment = d.getMoment( lclAxisOfRotation, offsetOfRotation );
						if( moment < 0 )
						{
							danceInterp::OutputMessage( "Illegal moment of inertia, axis %d: %f.  Moment=%f, link=%s", x, ballDamping[x], moment, link->getName() );
						}
					}
					else 
					{
						// not using total inertia control
						moment = inertia[x * 3 + x];
					}
					// critically damped spring

					ballDamping[x] = 2.0 * sqrt( ballStiffness[x] * getKS() * moment );
					double maxK = 2.0 * moment / sim->getTimeStep();
					if( isLimitSpringConstants )
					{
						if( ballDamping[x] > maxK )
						{
							danceInterp::OutputMessage( "Warning: Critically damped Kd exceeds stability limit, capping to limit. (%f)", maxK );
							ballDamping[x] = maxK; 
						}
						if( ballStiffness[x] > maxK )
						{
							danceInterp::OutputMessage( "Warning: Ks exceeds stability limit, capping to limit. (%f)", maxK );
							ballStiffness[x] = maxK; 
						}
					}
				}
				PDParams& pdp = m_params[aindex + x];
				if (m_useMocap)
				{
					// Compute Target Velocity 
					// This should be filled in from m_params, but don't have it yet
					Quaternion nextDesiredQuat;
					//nextDesiredQuat.set(nextDummyState[sindex], nextDummyState[sindex + 1], nextDummyState[sindex + 2], nextDummyState[sindex + 3]);
					//Quaternion v;
					//v.error( nextDesiredQuat, desiredQuat );
					//v.normalize();
					//pdp.dv = ( 2.0 * v[x] ) / dt;
				}
				// convert to radians
//				double theta = 2.0 * qError[x];
				double theta = qError[x];
				pdp.dv = 0.0;
				double omega = dstate[sindex + x] - pdp.dv;  // angular vel around axis x
				if( VelocityDrive == jointDriveType )
				{
					// Modulate by the GUI entry for global KD modifier.
					double velocityScale = getKS() * pdp.ks;
					double dampingFactor = getKD() * pdp.kd;
					targetVelocity[x] = clampVelocity( velocityScale * theta - dampingFactor * omega );
				}
				else if( SpringDrive == jointDriveType || TimeSpringDrive == jointDriveType )
				{
					stiffness = 0;
					damping = 0;
					if( TimeSpringDrive == jointDriveType )
					{
						double timeToReachPose = getKS();  // overloading interface of "stiffness" for time info
 						if( timeToReachPose < 0.0001 ) 
						{
							timeToReachPose = pdp.ks;
						}
						
						// $$$$$HACK -- 
						if (m_useMocap == true)
						{
							timeToReachPose = windowSize;
						}
						computeTimedSpringConstants( stiffness, damping, moment, timeToReachPose );
					} 
					else
					{
						if (this->isCriticallyDamped() && !isUsingTotalInertia())
						{
							stiffness = ballStiffness[x];
							damping = ballDamping[x];
						}
						else
						{
							stiffness = ballStiffness[x] * pdp.ks;
							damping = ballDamping[x] * pdp.kd;
						}
					}
					if( isUsingBackwardsEuler() )
					{
						double m = (moment != 0) ? moment : link->getMass();
						double angVelocity = omega ; // omega is the vel error, but the target velocity is assumed to be zero in this code!
						torq = computeTorqueBackwardsEuler( ballStiffness[x], ballDamping[x], sim->getTimeStep(), m, theta, omega, omega );
					}
					else if( getSubsteps() >= 1 )
					{
						double m = (moment != 0) ? moment : link->getMass();
						double dt = sim->getTimeStep();
						torq = computeSubstepTorque( m, currentQuat, desiredQuat, dstate, sindex, x, stiffness, damping, dt );
					}
					else
					{
						//  The normal PD Controller (forward euler)
						torq = stiffness * theta - damping * omega;
					}
					if( isCriticallyDamped() )
					{
						Link* link = joint[j]->getOutboardLink();
						//torq -= parentTorque[x];
					}
					const double allowedError = stiffness / ( M_PI / 4.0 );
					static double prevTorq[1024];
					double thisPrevTorq = prevTorq[ 3 * j + x ];
					prevTorq[ 3 * j + x ] = torq;
					if (this->isCriticallyDamped())
					{
						// Gyroscopic adjustment
						torq += adj[x];
					}
					if (fabs(torq) > 10e-8)
					{
						torq = clampTorque(torq);
					}
					else
					{
						torq = 0;
					}
				}
				else if( TorqueDrive == jointDriveType )
				{
					torq = pdp.v;
				}
				//////////////////////////////////////////////////////////////////////////
				// Apply the drive
				// Torque-based drives
				if( SpringDrive == jointDriveType || TorqueDrive == jointDriveType || TimeSpringDrive == jointDriveType )
				{
					torq = clampTorque( torq ); // clamp to AO limit
					torq = std::max( -pdp.maxTorque, torq );
					torq = std::min(  pdp.maxTorque, torq );
					sim->GeneralizedForce(j, x, torq );
					targetTorque[x] = torq;
					if( isRecordJoint && ( m_jointrecordedAxis == x ) && jointFile )
					{
						fprintf( jointFile, "%s\t%d\t%f\t%f\t%f\t%f\t%f\n", m_jointRecorded.c_str(), x, dance::AllSimulators->getCurrentTime(), sim->getTimeStep(), torq, stiffness, damping );
					}
				}
			}
			//////////////////////////////////////////////////////////////////////////
			// Apply the drive
			// Constraint-based drives
			if( VelocityDrive == jointDriveType )
			{
				Vector maxTorque;
				// NOTE: it would be reasonable to scale max torque by DOF stiffness
				//setVector(maxTorque, getMaxTorque(), getMaxTorque(), getMaxTorque() ); //ballStiffness[0], ballStiffness[1], ballStiffness[2] );
				setVector( maxTorque, std::min( getMaxTorque(), m_params[aindex].maxTorque ), 
									  std::min( getMaxTorque(), m_params[aindex+1].maxTorque ), 
									  std::min( getMaxTorque(), m_params[aindex+2].maxTorque ) );
				sim->SetupVelocityDrive( j, ballStiffness, ballDamping, maxTorque );
				sim->ApplyVelocityDrive( j, targetVelocity );
			}
			else
			{
				deactivateVelocityDrive(sim, j);
			}
			if( PositionDrive == jointDriveType )
			{
				danceInterp::OutputMessage( "PositionDrive not implemented for ball joints.\n" );
			}
		} // End if ( type == BALL )
	} // End loop over every Joint j
	if( jointFile )
	{
		fclose( jointFile );
	}
	if (m_useMocap)
	{
		//dummyAo->setState(currTime);
		//dummyAo->setState(currTime + windowSize);
		Joint* rootJoint = dummyAo->getJoint(0);
		Vector currRoot, root;
		currRoot[0] = rootJoint->getState(0);
		currRoot[1] = rootJoint->getState(1);
		currRoot[2] = rootJoint->getState(2);
		if (currTime == 0.0)
		{
			VecCopy(dummyRoot, currRoot);
		}
		VecSubtract(root, currRoot, dummyRoot);
		ao->getJoint(0)->setQuaternion(dummyAo->getJoint(0)->getQuaternion());
		ao->getJoint(0)->setState(0, root[0]);
		ao->getJoint(0)->setState(1, root[1]);
		ao->getJoint(0)->setState(2, root[2]);
		
		for (int j = 10; j < ao->getNumJoints(); j++)
		{	
			ao->getJoint(j)->setQuaternion(dummyAo->getJoint(j)->getQuaternion());
		}
		ao->getJoint(2)->setQuaternion(dummyAo->getJoint(2)->getQuaternion());
		ao->getJoint(3)->setQuaternion(dummyAo->getJoint(3)->getQuaternion());
		ao->updateStateConfig();
		sim->SetStateFromObjectState( ao, false );
		
	}
	if (nextDummyState != NULL)
		delete [] nextDummyState;
}

void PDController::LogR(double w[3], Matrix3x3 m)
{
	double _eps = 10e-7;
        double theta = 0.5 * (m[0][0] + m[1][1] + m[2][2] - 1.0);
        if ( fabs(theta) > 1.0 - _eps )
        {
                w[0] = w[1] = w[2] = 0.0;
                return;
        }
        theta = acos(theta);
        double cof = theta / (2.0 * sin(theta));
        w[0] = cof * (m[2][1] - m[1][2]);
        w[1] = cof * (m[0][2] - m[2][0]);
        w[2] = cof * (m[1][0] - m[0][1]);
}
void PDController::setLinearSpringStiffness(double ks)
{
	this->m_linearSpringStiff = ks;
}
double PDController::getLinearSpringStiffness()
{
	return this->m_linearSpringStiff;
}
void PDController::setLinearSpringDamping(double kd)
{
	this->m_linearSpringDamp = kd;
}
double PDController::getLinearSpringDamping()
{
	return this->m_linearSpringDamp;
}
void PDController::setExponentialSpringStiffness(double ks)
{
	this->m_exponentialSpringStiff = ks;
}
double PDController::getExponentialSpringStiffness()
{
	return this->m_exponentialSpringStiff;
}
void PDController::setExponentialSpringDamping(double kd)
{
	this->m_exponentialSpringDamp = kd;
}
double PDController::getExponentialSpringDamping()
{
	return this->m_exponentialSpringDamp;
}
void PDController::maintainLimits(DSimulator *sim, ArticulatedObject* ao, double *state, double *dstate)
{
	Joint **joint = ao->getJoints();
	for(int j = 0; j < ao->getNumJoints(); j++ )
	{
		int numAxes = 0;
		switch (joint[j]->getJointType())
		{
		case J_FREE:
		case J_PLANAR:
			numAxes = 0;
		break;
		case J_BALL:
		case J_GIMBAL:
			numAxes = 3;
		break;
		case J_UNIVERSAL:
			numAxes = 2;
		break;
		case J_PIN:
			numAxes = 1;
		break;
		}
		VectorObj eulerAngles;
		if (joint[j]->getJointType() == J_BALL)
		{
			int indx = sim->GetIndex(j, 0);
			Quaternion q(state[indx], state[indx + 1], state[indx + 2], state[indx + 3]);
			q.normalize() ;
			Matrix3x3 matrix;
			q.toMatrix(matrix);
			matrix.matToEuler(Matrix3x3::XYZ, eulerAngles, false);
		}
		for (int a = 0; a < numAxes; a++ )
		{
			int indx = sim->GetIndex(j,a);
			double linSpringStiff = this->getLinearSpringStiffness();
			double linSpringDamp = this->getLinearSpringDamping();
			double expSpringStiff =  this->getExponentialSpringStiffness();
			double expSpringDamp =  this->getExponentialSpringDamping() ;
			double low, high, diff ;
			joint[j]->getLimits(a, &low, &high) ;
			low = low * M_PI / 180.0;
			high = high * M_PI / 180.0;
			double st = state[indx];// * 180.0 / M_PI ; // transform to degrees
			if (joint[j]->getJointType() == J_BALL)
				st = eulerAngles[a];
			if (st > 2 * M_PI || st < -2 * M_PI)
			{
				int temp = (int) (st / (2.0 ));
				st = st - 2.0  * (double) temp;
			}
			double torq = 0.0;
			if (st < low)
			{
				diff = st  - low ;
				if (this->isExponentialJointLimitSprings())
					torq = expSpringStiff * (exp(abs(expSpringStiff*diff)) - 1 ) - expSpringDamp*dstate[indx] ;
				else
					torq = linSpringStiff * diff - linSpringDamp*dstate[indx] ;
				//if( torq > 0.0 ) // avoid sticky effect
				sim->GeneralizedForce(j, a, clampTorque(torq));
			}
			else if (st > high)
			{
				diff = high  - st  ;
				if (this->isExponentialJointLimitSprings())
					torq = expSpringStiff*(exp(expSpringStiff*diff) - 1 ) - expSpringDamp*dstate[indx] ;
				else
					torq = linSpringStiff * diff - linSpringDamp*dstate[indx] ;
				//if( torq > 0.0 ) // avoid sticky effect
				sim->GeneralizedForce(j, a, clampTorque(torq));
			}
		}
	}
}
int PDController::convertIndexAOtoSim(int in)
{
	return aoToSimMap[in];
}
int PDController::convertIndexSimtoAO(int in)
{
	return simToAOMap[in];
}
void  PDController::onDependencyRemoval(DObject* obj)
{
	DActuator::onDependencyRemoval(obj);
}
void PDController::setKS(double val)
{
	m_ks = val;
	useCurrentPose();
}
void PDController::setKD(double val)
{
	m_kd = val;
	useCurrentPose();
}
double PDController::getKS()
{
	return m_ks;
}
double PDController::getKD()
{
	return m_kd;
}
void PDController::setMaintainJointLimits(bool val)
{
	this->m_isMaintainLimits = val;
}
bool PDController::isMaintainJointLimits()
{
	return this->m_isMaintainLimits;
}
void PDController::setExponentialJointLimitSprings(bool val)
{
	this->m_isExpSprings = val;
}
bool PDController::isExponentialJointLimitSprings()
{
	return this->m_isExpSprings;
}
void PDController::createStateMapping()
{
	if (this->getNumAppliedObjects() == 0)
		return;
	ArticulatedObject* ao = (ArticulatedObject*) this->getAppliedObject(0);
	DSimulator* sim = ao->getSimulator(0);
	if (ao == NULL || sim == NULL)
		return;
	Joint** joints = ao->getJoints();
	if (ao == NULL || sim == NULL)
		return;
	int count = 0;
	for	(int i = 0; i < ao->getNumJoints(); i++)
	{
		int dof = joints[i]->getStateSize();
		for (int n	= 0; n < dof; n++)
		{
			int simIndex = sim->GetIndex(i, n);
			aoToSimMap[count] = simIndex;
			simToAOMap[simIndex] = count;
			count++;
		}
	}
}
int PDController::getDummyMappings(int val)
{
	return dummyAOMap[val];
}
void PDController::makeDummyMappings(ArticulatedObject* ao)
{
	ArticulatedObject* appliedAO = (ArticulatedObject*) this->getAppliedObject(0);
	DSimulator* sim = appliedAO->getSimulator(0);
	if (ao == NULL || sim == NULL)
		return;
	Joint** joints = ao->getJoints();
	int count = 0;
	for (int i = 0; i < ao->getNumJoints(); i++)
	{
		int dof = joints[i]->getStateSize();
		count += dof;
		dummyAOMap[i] = count;
	}
}
void PDController::simstart(DObject* data, double time)
{
	PDController* pd = (PDController*) data;
	pd->createStateMapping();
	pd->useCurrentPose();
	pd->setLocalTime(dance::AllSimulators->getCurrentTime());
}
void PDController::setMaxTorque(double val)
{
	this->m_maxTorque = val;
}
double PDController::getMaxTorque()
{
	return this->m_maxTorque;
}
void PDController::setMaxVelocity( double val )
{
	m_maxVelocity = val;
}
double PDController::getMaxVelocity( void ) const
{
	return m_maxVelocity;
}
void PDController::setRagdollSettings(double ks, double kd)
{
	m_ragdollKS = ks;
	m_ragdollKD = kd;
}
void PDController::getRagdollSettings(double& ks, double& kd)
{
	ks = m_ragdollKS;
	kd = m_ragdollKD;
}
int PDController::getNumPluginDependents()
{
	return 1;
}
const char* PDController::getPluginDependent(int num)
{
	if (num == 0)
		return "ArticulatedObject";
	else
		return NULL;
}
void PDController::save(int mode, std::ofstream& file)
{
	char buff[2048];
	if (mode == 0)
	{
		file << "dance.instance(\"PDController\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
		// ks
		sprintf(buff, "\"ks\", \"%f\"", this->getKS());
		pythonSave(file, buff);
		// kd
		sprintf(buff, "\"kd\", \"%f\"", this->getKD());
		pythonSave(file, buff);
		
		// linear ks
		sprintf(buff, "\"linearks\", \"%f\"", this->getLinearSpringStiffness());
		pythonSave(file, buff);
		// linear kd
		sprintf(buff, "\"linearkd\", \"%f\"", this->getLinearSpringDamping());
		pythonSave(file, buff);
		
		// exponential ks
		sprintf(buff, "\"exponentialks\", \"%f\"", this->getExponentialSpringStiffness());
		pythonSave(file, buff);
		// exponential kd
		sprintf(buff, "\"exponentialkd\", \"%f\"", this->getExponentialSpringDamping());
		pythonSave(file, buff);
		// maintain limits
		if (this->isMaintainJointLimits())
		{
			sprintf(buff, "\"maintain_limits\", \"true\"");
			pythonSave(file, buff);
		}
		else
		{
			sprintf(buff, "\"maintain_limits\", \"false\"");
			pythonSave(file, buff);
		}
		// max torque
		sprintf(buff, "\"max_torque\", %f", this->getMaxTorque());
		pythonSave(file, buff);
		// use exponential springs 
		if (this->isExponentialJointLimitSprings())
		{
			sprintf(buff, "\"use_exp_springs\", \"true\"");
			pythonSave(file, buff);
		}
		else
		{
			sprintf(buff, "\"use_exp_springs\", \"false\"");
			pythonSave(file, buff);
		}
		// ragdoll settings
		double ks, kd;
		this->getRagdollSettings(ks, kd);
		sprintf(buff, "\"ragdoll\", %6.4f, %6.4f", ks, kd);
		pythonSave(file, buff);
		// tension
		if (this->isUseTension())
		{
			sprintf(buff, "\"usetension\", \"true\"");
		}
		else
		{
			sprintf(buff, "\"usetension\", \"false\"");
		}
		pythonSave(file, buff);
		// tension value
		sprintf(buff, "\"tension\", \"%f\"", this->getTension());
		pythonSave(file, buff);
		// use total inertia
		sprintf(buff, "\"use_total_inertia\", \"%s\"", ( this->isUsingTotalInertia() ? "true" : "false" ) );
		pythonSave(file, buff);
		// drive type (Position, Velocity or Torque)
		sprintf(buff, "\"drive_type\", \"%s\"", getDriveTypeName().c_str() );
		pythonSave(file, buff);
	}
	else if (mode == 2)
	{
		// parameter settings
		ArticulatedObject* ao = (ArticulatedObject*) this->getAppliedObject(0);
		if (ao != NULL)
		{
			char temp[128];
			std::string params = "\"params_v\"";
			for (int x = 0; x < ao->getStateSize(); x++)
			{
				sprintf(temp, ", %8.4f", m_params[x].v);
				params.append(temp);
			}
			pythonSave(file, (char*) params.c_str());
			std::string ks = "\"params_ks\"";
			for (int x = 0; x < ao->getStateSize(); x++)
			{
				sprintf(temp, ", %8.4f", m_params[x].ks);
				ks.append(temp);
			}
			pythonSave(file, (char*) ks.c_str());
			std::string kd = "\"params_kd\"";
			for (int x = 0; x < ao->getStateSize(); x++)
			{
				sprintf(temp, ", %8.4f", m_params[x].kd);
				kd.append(temp);
			}
			pythonSave(file, (char*) kd.c_str());
		}
	}
	DActuator::save(mode, file);
}
void PDController::setEulerAngleParameterization(bool val)
{
	m_useEulerAngleParamterization = val;
}
bool PDController::isEulerAngleParameterization()
{
	return m_useEulerAngleParamterization;
}
/// Never seem to be called from anywhere. -- Petros 12/21/06
void PDController::constructRotation(int jointType, int order, double* state, Quaternion* quat)
{
	Matrix3x3 rot;
	switch (jointType)
	{
	case J_FREE:
		{
			quat->set(state[0], state[1], state[2], state[3]);
		}
		break;
	case J_BALL:
		{
			quat->set(state[0], state[1], state[2], state[3]);
		}
		break;
	case J_GIMBAL:
		{
			Matrix3x3 rotX;
			Matrix3x3 rotY;
			Matrix3x3 rotZ;
			switch (order)
			{
			case Matrix3x3::XYZ:
				rotX.setRotateMatrix(Matrix3x3::X, state[0]);
				rotY.setRotateMatrix(Matrix3x3::Y, state[1]);
				rotZ.setRotateMatrix(Matrix3x3::Z, state[2]);
				rot = rotX * rotY * rotZ;
				break;
			case Matrix3x3::XZY:
				rotX.setRotateMatrix(Matrix3x3::X, state[0]);
				rotZ.setRotateMatrix(Matrix3x3::Z, state[1]);
				rotY.setRotateMatrix(Matrix3x3::Y, state[2]);
				rot = rotX * rotZ * rotY;
				break;
			case Matrix3x3::YXZ:
				rotY.setRotateMatrix(Matrix3x3::Y, state[0]);
				rotX.setRotateMatrix(Matrix3x3::X, state[1]);
				rotZ.setRotateMatrix(Matrix3x3::Z, state[2]);
				rot = rotY * rotX * rotZ;
				break;
			case Matrix3x3::YZX:
				rotY.setRotateMatrix(Matrix3x3::Y, state[0]);
				rotZ.setRotateMatrix(Matrix3x3::Z, state[1]);
				rotX.setRotateMatrix(Matrix3x3::X, state[2]);
				rot = rotY * rotZ * rotX;
				break;
			case Matrix3x3::ZXY:
				rotZ.setRotateMatrix(Matrix3x3::Z, state[0]);
				rotX.setRotateMatrix(Matrix3x3::X, state[1]);
				rotY.setRotateMatrix(Matrix3x3::Y, state[2]);
				rot = rotZ * rotX * rotY;
				break;
			case Matrix3x3::ZYX:
				rotZ.setRotateMatrix(Matrix3x3::Z, state[0]);
				rotY.setRotateMatrix(Matrix3x3::Y, state[1]);
				rotX.setRotateMatrix(Matrix3x3::X, state[2]);
				rot = rotZ * rotY * rotX;
				break;
			}
		}
		break;
	case J_UNIVERSAL:
		{
			Matrix3x3 rotX;
			Matrix3x3 rotY;
			Matrix3x3 rotZ;
			switch (order)
			{
			case Matrix3x3::XY:
				rotX.setRotateMatrix(Matrix3x3::X, state[0]);
				rotY.setRotateMatrix(Matrix3x3::Y, state[1]);
				rot = rotX * rotY;
				break;
			case Matrix3x3::XZ:
				rotX.setRotateMatrix(Matrix3x3::X, state[0]);
				rotZ.setRotateMatrix(Matrix3x3::Z, state[1]);
				rot = rotX * rotZ;
				break;
			case Matrix3x3::YX:
				rotY.setRotateMatrix(Matrix3x3::Y, state[0]);
				rotX.setRotateMatrix(Matrix3x3::X, state[1]);
				rot = rotY * rotX;
				break;
			case Matrix3x3::YZ:
				rotY.setRotateMatrix(Matrix3x3::Y, state[0]);
				rotZ.setRotateMatrix(Matrix3x3::Z, state[1]);
				rot = rotY * rotZ;
				break;
			case Matrix3x3::ZX:
				rotZ.setRotateMatrix(Matrix3x3::Z, state[0]);
				rotX.setRotateMatrix(Matrix3x3::X, state[1]);
				rot = rotZ * rotX;
				break;
			case Matrix3x3::ZY:
				rotZ.setRotateMatrix(Matrix3x3::Z, state[0]);
				rotY.setRotateMatrix(Matrix3x3::Y, state[1]);
				rot = rotZ * rotY;
				break;
			default:
				break;
			}
		}
		break;
	case J_PIN:
		{
			rot.setRotateMatrix(order, state[0]);
		}
		break;
	}
	if( (jointType != J_FREE) && (jointType != J_BALL))
	{
		quat->fromMatrix(rot);
	}
	quat->normalize() ;
}
double PDController::clampTorque(double torque)
{
	if (torque > this->getMaxTorque())
		return this->getMaxTorque();
	else if (torque < -this->getMaxTorque())
		return -this->getMaxTorque();
	else
		return torque;
}
double PDController::clampVelocity( double argVelocity, double argLimitFactor )
{
	double limit = std::abs( getMaxVelocity() * argLimitFactor );
	double vel = std::max<double>( argVelocity, -limit );
	return std::min<double>( vel, limit );
}
void PDController::setLocalTime(double time)
{
	m_localTime = time;
}
double PDController::getLocalTime()
{
	return m_localTime;
}
bool PDController::isCriticallyDamped()
{
	return m_criticallyDamped;
}
void PDController::setCriticalDamping(bool val)
{
	m_criticallyDamped = val;
}
bool PDController::isUsingTotalInertia(void)
{
	return m_usingTotalInertia;
}
void PDController::setUsingTotalInertia(bool val)
{
	m_usingTotalInertia = val;
}
bool PDController::isUsingBackwardsEuler(void)
{
	return m_isUsingBackwardEuler;
}
void PDController::setUsingBackwardEuler(bool val)
{
	m_isUsingBackwardEuler = val;
}
int PDController::getSubsteps( void )
{
	return m_substeps;
}
void PDController::setSubsteps( int val )
{
	m_substeps = val;
}
void PDController::setTension(double t)
{
	m_tension = t;
}
double PDController::getTension()
{
	return m_tension;
}
bool PDController::isUseTension()
{
	return this->m_useTension;
}
void PDController::setUseTension(bool val)
{
	this->m_useTension = val;
}
DriveType PDController::getDriveType( void ) const
{
	return m_aoDriveType;
}
std::string PDController::getDriveTypeName( void ) const
{
	return DriveTypeName[ m_aoDriveType ];
}
void PDController::setDriveType( DriveType arg )
{
	m_aoDriveType = arg;
}
void PDController::setDriveType( const std::string& argNewDriveType )
{
	for( int i = (int)StartDriveType; i < (int)EndDriveType; ++i )
	{
		if( argNewDriveType == DriveTypeName[i] )
		{
			m_aoDriveType = (DriveType)i;
			break;
		}
	}
}
std::string PDController::getAllDriveTypesNames( void )
{
	std::string retVal;
	for( int i = (int)StartDriveType; i < (int)EndDriveType; ++i )
	{
		retVal += DriveTypeName[i];
		if( (i+1) != (int)EndDriveType )
		{
			retVal += ", ";
		}
	}
	return retVal;
}
const char** PDController::getDriveTypeNames( void )
{
	return DriveTypeName;
}
double PDController::computeLocalMoment( int argJointType, int argRotAxesOrder, double* argInertia, int argAxis )
{
	double outMoment = 0;
	if (argJointType == J_PIN)
	{
		if (argRotAxesOrder == Matrix3x3::X)
		{
			outMoment = argInertia[0];
		}
		else if (argRotAxesOrder == Matrix3x3::Y)
		{
			outMoment = argInertia[4];
		}
		else if (argRotAxesOrder == Matrix3x3::Z)
		{
			outMoment = argInertia[8];
		}
	}
	else if (argJointType == J_UNIVERSAL)
	{
		if (argRotAxesOrder == Matrix3x3::XY)
		{
			if (argAxis == 0)
				outMoment = argInertia[0];
			else
				outMoment = argInertia[4];
		}
		else if (argRotAxesOrder == Matrix3x3::XZ)
		{
			if (argAxis == 0)
				outMoment = argInertia[0];
			else
				outMoment = argInertia[8];
		}
		else if (argRotAxesOrder == Matrix3x3::YX)
		{
			if (argAxis == 0)
				outMoment = argInertia[4];
			else
				outMoment = argInertia[0];
		}
		else if (argRotAxesOrder == Matrix3x3::YZ)
		{
			if (argAxis == 0)
				outMoment = argInertia[4];
			else
				outMoment = argInertia[8];
		}
		else if (argRotAxesOrder == Matrix3x3::ZX)
		{
			if (argAxis == 0)
				outMoment = argInertia[8];
			else
				outMoment = argInertia[0];
		}
		else if (argRotAxesOrder == Matrix3x3::ZY)
		{
			if (argAxis == 0)
				outMoment = argInertia[8];
			else
				outMoment = argInertia[4];
		}
	}
	else if (argJointType == J_GIMBAL)
	{
		if (argRotAxesOrder == Matrix3x3::XYZ)
		{
			if (argAxis == 0)
				outMoment = argInertia[0];
			else if (argAxis == 1)
				outMoment = argInertia[4];
			else
				outMoment = argInertia[8];
		}
		else if (argRotAxesOrder == Matrix3x3::XZY)
		{
			if (argAxis == 0)
				outMoment = argInertia[0];
			else if (argAxis == 1)
				outMoment = argInertia[8];
			else
				outMoment = argInertia[4];
		}
		else if (argRotAxesOrder == Matrix3x3::YXZ)
		{
			if (argAxis == 0)
				outMoment = argInertia[4];
			else if (argAxis == 1)
				outMoment = argInertia[0];
			else
				outMoment = argInertia[8];
		}
		else if (argRotAxesOrder == Matrix3x3::YZX)
		{
			if (argAxis == 0)
				outMoment = argInertia[4];
			else if (argAxis == 1)
				outMoment = argInertia[8];
			else
				outMoment = argInertia[0];
		}
		else if (argRotAxesOrder == Matrix3x3::ZXY)
		{
			if (argAxis == 0)
				outMoment = argInertia[8];
			else if (argAxis == 1)
				outMoment = argInertia[0];
			else
				outMoment = argInertia[4];
		}
		else if (argRotAxesOrder == Matrix3x3::ZYX)
		{
			if (argAxis == 0)
				outMoment = argInertia[8];
			else if (argAxis == 1)
				outMoment = argInertia[4];
			else
				outMoment = argInertia[0];
		}
	}
	return outMoment;
}
void PDController::deactivateVelocityDrive( DSimulator * sim, int j )
{
	Vector zero;
	zeroVector( zero );
	sim->SetupVelocityDrive( j, zero, zero, zero );
	sim->ApplyVelocityDrive( j, zero );
}
PDParams& PDController::getPDParams( int argSimIndex )
{
	int aoIndex = convertIndexSimtoAO( argSimIndex );
	return m_params[aoIndex];
}
void PDController::setPDParams( int argSimIndex, const PDParams& argParams )
{
	int aoIndex = convertIndexSimtoAO( argSimIndex );
	PDParams& p = m_params[aoIndex];
	p = argParams;
}
void PDController::setControlUpdateFrequency( double rate )
{
	m_controlUpdateRate = rate;
	m_lastControlUpdate = -999;
}
double PDController::getControlUpdateFrequency( void )
{
	return m_controlUpdateRate;
}
void PDController::setLastControlUpdate( float val )
{
	m_lastControlUpdate = val;
}
int PDController::getLastControlUpdate( void )
{
	return m_lastControlUpdate;
}
double PDController::computeSubstepTorque( double argMoment, const Quaternion& argCurrentQuat, const Quaternion& argDesiredQuat, double * argDstate, int argSindex, int argAxis, double argKs, double argKd, double argDt )
{
	double mInv = 1.0 / argMoment;
	int substeps = getSubsteps();
	double frac = 1.0/(double)substeps;
	Quaternion currentQuatSS( const_cast< Quaternion* >(&argCurrentQuat) );
	//double Xn = 2.0 * currentQuat[x];
	//double Xd = 2.0 * pdp.v; //2.0 * desiredQuat[x];
	const int stateIndex = argSindex + argAxis;
	double Xstart = 2.0 * argCurrentQuat[argAxis];
	double omegaStart = argDstate[stateIndex];
	double XnVel = argDstate[stateIndex];
	double XdVel = 0; //mparams[];
	const double& dt = argDt;
	const double subDt = dt * frac;
	
	double Xn = 0;
	for( int i = 0; i < substeps; ++i )
	{
		double offset = double(substeps - i);
		Quaternion errorQuat;
		errorQuat.error( argDesiredQuat, currentQuatSS);
		errorQuat.normalize();
		double errorRad = 2.0 * errorQuat[argAxis];
		Xn = currentQuatSS[argAxis] * 2.0;
		double thetaSubstepRad = errorRad / offset;
		double omegaSubstep = (XnVel - XdVel) / offset;
		double torque = ( argKs * thetaSubstepRad - argKd * omegaSubstep );
		double accel = mInv * torque;
		XnVel = XnVel + accel * subDt;
		Xn = Xn + XnVel * subDt;
		currentQuatSS[argAxis] = Xn / 2.0;
		currentQuatSS.normalize();
	}
	// forward dynamic simulation has suggested currentQuatSS[x] as the position to reach in this timestep
	// so we compute the amount of torque needed to reach that position in the next timestep
	double k = 2.0 / ( dt * dt );
	double accel = k * ( Xn - Xstart - (omegaStart * dt));
	double torque = argMoment * accel;
	return torque;
}
void PDController::computeTimedSpringConstants( double &ks, double &kd, double argMoment, double argTime )
{
	// Time to error reduction is specified in t
	double dt = argTime; // $$ How should this come in via interface?  pdp.ks?
	double n = 4.0;  // number of time-constants to elapse in the allotted total time
	double tau = dt / n; 
	kd = 2.0 * argMoment / tau;
	ks = argMoment / ( tau * tau );
}
double computeTorqueBackwardsEuler( double argKS, double argKD, double argTimeStep, double argMoment, double argTheta, double argOmega, double argVel )
{
	const double dt = argTimeStep;
	// Roughly based off Wu's 2003 GDC presentation -- but his derivation looks broken.
	// this is a different derivation in the same spirit
	// in particular, his derivation eliminated m(!) as well
	// as the argVel term.
	const double g = 1.0 / ( 1.0 - ( argKD - argKS * dt ) * dt * dt );
	const double gmks = g * argMoment * argKS;
	const double gmkd = g * argMoment * argKD;
	return gmks * (argTheta + argVel * dt) - gmkd * argOmega;
}
