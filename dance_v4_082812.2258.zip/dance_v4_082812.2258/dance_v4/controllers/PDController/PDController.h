/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef	PDCONTROLLER_H
#define PDCONTROLLER_H

#include "AppraisableActuator.h"
#include "PDParams.h"
#include "ArticulatedObject.h"
#include <string>

class PDControllerWindow;

#ifdef WIN32
#ifndef PDCONTROLLER_EXPORTS
#define	DLLPDCONTROLLER __declspec(dllexport)
#else
#define	DLLPDCONTROLLER __declspec(dllimport)
#endif
#else
#define DLLPDCONTROLLER 
#endif

class DLLPDCONTROLLER PDController : public AppraisableActuator
{
	public:
		PlugIn* create(int argc, char **argv);
		PDController();
		PDController(ArticulatedObject* ao);
		~PDController();

		void ExertLoad(DSystem *ao, DSimulator* simulator, double time, double dt, double *state, double *dstate);
		int commandPlugIn(int argc, char **argv);
		fltk::Widget* getInterface();

		virtual void applyPDParams(double time, ArticulatedObject* ao, double *state, double *dstate);
		virtual void resetPDParams();

		void setMaintainJointLimits(bool val);
		bool isMaintainJointLimits();
		void setExponentialJointLimitSprings(bool val);
		bool isExponentialJointLimitSprings();

		void useCurrentPose();
		void setKS(double val);
		void setKD(double val);
		double getKS();
		double getKD();

		void makeDummyMappings(ArticulatedObject* ao);
		int getDummyMappings(int val);

		bool isUsingTotalInertia( void );
		void setUsingTotalInertia(bool val);

		bool isUsingBackwardsEuler( void );
		void setUsingBackwardEuler( bool val );

		void setSubsteps( int val );
		int getSubsteps( void );

		void setRagdollSettings(double ks, double kd);
		void getRagdollSettings(double& ks, double& kd);

		void setLinearSpringStiffness(double ks);
		double getLinearSpringStiffness();
		void setLinearSpringDamping(double kd);
		double getLinearSpringDamping();
		void setExponentialSpringStiffness(double ks);
		double getExponentialSpringStiffness();
		void setExponentialSpringDamping(double kd);
		double getExponentialSpringDamping();

		void setEulerAngleParameterization(bool val);
		bool isEulerAngleParameterization();

		void setMaxTorque(double val);
		double getMaxTorque();

		void onDependencyRemoval(DObject* obj);

		int getNumPluginDependents();
		const char* getPluginDependent(int num);

		void save(int mode, std::ofstream& file);

		void setLocalTime(double time);
		double getLocalTime();

		void setTension(double t);
		double getTension();
		void setUseTension(bool val);
		bool isUseTension();

		double getMaxVelocity( void ) const;
		void setMaxVelocity( double arg );

		DriveType getDriveType( void ) const;
		std::string getDriveTypeName( void ) const;
		void setDriveType( DriveType arg );
		void setDriveType( const std::string& argNewDriveType );
		static const char** getDriveTypeNames( void );
		bool isCriticallyDamped();
		void setCriticalDamping(bool val);

		void setControlUpdateFrequency( double freq );
		double getControlUpdateFrequency( void );

		void setLastControlUpdate( float val );
		int getLastControlUpdate( void );

		friend class PoseInterpreter;

	protected:
		void applyState(DSimulator *sim, ArticulatedObject* ao, double *state, double *dstate);

		void computeTimedSpringConstants( double &ks, double &kd, double argMoment, double argTime );
		double computeSubstepTorque( double argMoment, const Quaternion& argCurrentQuat, const Quaternion& argDesiredQuat, double * argDstate, int argSindex, int argAxis, double argKs, double argKd, double argDt );
		void deactivateVelocityDrive( DSimulator * sim, int j );
		double computeLocalMoment( int argJointType, int argRotAxesOrder, double* argInertia, int argAxis );
		void maintainLimits(DSimulator *sim, ArticulatedObject* ao, double *state, double *dstate);
		int convertIndexAOtoSim(int in);
		int convertIndexSimtoAO(int in);
		void createStateMapping();
		void honorLimits( DSimulator* argSim, ArticulatedObject* argAO );

		void LogR(double w[3], Matrix3x3 m);

		int aoToSimMap[MAX_STATE];
		int simToAOMap[MAX_STATE];

		int dummyAOMap[MAX_STATE];

		PDControllerWindow* m_pdControllerWindow;
		PDParams m_params[MAX_STATE];
		int m_aoStateSize;

		// direct access to the PDParams structure
		PDParams& getPDParams( int index );
		void setPDParams( int index, const PDParams& argParams );
	private:
		static void simstart(DObject* data, double time);
		void constructRotation(int jointType, int order, double* state, Quaternion* quat);
		double clampTorque(double torque);
		double clampVelocity( double argVelocity, double argLimitFactor = 1.0 );
		std::string getAllDriveTypesNames( void );

		bool m_isExpSprings;
		bool m_isMaintainLimits;
		double m_ks;
		double m_kd;
		double m_maxTorque;
		double m_ragdollKS;
		double m_ragdollKD;
		double m_linearSpringStiff;
		double m_linearSpringDamp;
		double m_exponentialSpringStiff;
		double m_exponentialSpringDamp;
		bool m_useEulerAngleParamterization;
		double m_localTime;
		bool m_criticallyDamped;
		bool m_usingTotalInertia;
		bool m_isUsingBackwardEuler;
		int m_substeps;
		double m_tension;
		bool m_useTension;
		bool m_useGyroAdj;
		bool m_useMocap;
		DriveType m_aoDriveType;
		double m_maxVelocity;
		int m_lastControlUpdate;
		float m_controlUpdateRate;

		std::string m_jointRecorded;  //< the name of the joint to record values to a corresponding file, toggled with script "record_joint" command
		int m_jointrecordedAxis; //< which axis to record

		bool m_loadMocap;
		Vector dummyRoot;
		int windowCount;
		double keyFrame;
} ;

/// Free function that computes the torque of a spring using an implicit formulation
double computeTorqueBackwardsEuler( double argKS, double argKD, double argTimeStep, double argMoment, double argTheta, double argOmega, double argVel );


#endif

