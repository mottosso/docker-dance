/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "TestControllerWindow.h"
#include <fltk/Group.h>
#include <fltk/CheckButton.h>
#include <fltk/Widget.h>
#include <fltk/ask.h>
#include "dance.h"
#include "ViewManager.h"
#include "TestController.h"
#include "Sensor.h"

using namespace fltk;

TestControllerWindow::TestControllerWindow(TestController* c, int x, int y, int w, int h, const char* name) : Group(x, y, w, h, name)
{
	controller = c;

	this->begin();

	pdWidgets = new GroupAppliedSystems(c, 10, 10, 300, 80, "Articulated Object");
	pdWidgets->setApplyOneOnly(true);

	choiceSensor = new Choice(100, 100, 150, 20, "Sensor");
	choiceSensor->callback(SensorCB, this);

	this->end();

	this->updateGUI();
}

void TestControllerWindow::show()
{
	this->updateGUI();

	Group::show();
}

void TestControllerWindow::updateGUI()
{
	pdWidgets->updateGUI();

	choiceSensor->activate();
	// add all sensors
	choiceSensor->clear();
	choiceSensor->add("Choose a sensor");
	bool found = false;
	for (int x = 0; x < dance::AllGenericPlugins->size(); x++)
	{
		Sensor* sensor = dynamic_cast<Sensor*>(dance::AllGenericPlugins->get(x));
		if (sensor != NULL)
		{
			choiceSensor->add(sensor->getName(), 0, SensorCB, this, 0);
			if (this->controller->getSensor() == sensor)
			{
				choiceSensor->value(x + 1);
				found = true;
			}
		}
	}
	if (!found)
		choiceSensor->value(0);
}

void TestControllerWindow::SensorCB(fltk::Widget* widget, void* data)
{
	TestControllerWindow* win = (TestControllerWindow*) data;

	Choice* choice = (Choice*) widget;
	int which = choice->value();
	
	DObject* obj = dance::AllGenericPlugins->get((char*) choice->child(which)->label());
	if (obj == NULL)
	{
		danceInterp::OutputMessage("No object named '%s' found.", widget->label());
		return;
	}

	Sensor* skelsensor = dynamic_cast<Sensor*>(obj);
	if (skelsensor == NULL)
	{
		danceInterp::OutputMessage("Object '%s' is not a Sensor.", obj->getName());
		return;
	}

	win->controller->setSensor(skelsensor);

	win->updateGUI();

}





