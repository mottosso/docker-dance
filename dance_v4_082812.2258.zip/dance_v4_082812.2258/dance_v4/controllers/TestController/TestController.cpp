/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "TestController.h"
#include <cmath>
#include "dance.h"
#include "danceInterp.h"
#include "PDController.h"
#include "TestControllerWindow.h"
#include "SensorSkeleton.h"
#include "matrix3x3.h"

PlugIn* Proxy()
{
	return new TestController();
}

PlugIn *TestController::create(int argc, char **argv)
{
    TestController *c = new TestController ;

    if (c == NULL )
    {
		danceInterp::OutputMessage("Cannot allocate memory!\n") ;
		return NULL ;
    }
    return c ;
}

TestController::TestController()
{
    setName("noname") ;
	this->testControllerWindow = NULL;
	m_sensor = NULL;
}

TestController::~TestController()
{
	if (this->testControllerWindow != NULL)
		delete testControllerWindow;
}

int TestController::commandPlugIn(int argc,char **argv)
{
	int ret = PDController::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

    if( strcmp(argv[0], "param") == 0 )
    {
		danceInterp::OutputMessage("Entered a parameter!");
		return DANCE_OK;
	}
    else if( strcmp(argv[0], "sensor") == 0 )
    {
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.generic(\"%s\", \"sensor\", \"<skeletonsensor>\")");
			return DANCE_ERROR;
		}
		DObject* obj = dance::AllGenericPlugins->get(argv[1]);
		if (obj == NULL)
		{
			danceInterp::OutputMessage("Cannot find a sensor named '%s'.", argv[1]);
			return DANCE_ERROR;
		}
		Sensor* sensor = dynamic_cast<Sensor*>(obj);
		if ( sensor == NULL )
		{
			danceInterp::OutputMessage("Object '%s' is not a sensor.", obj->getName());
			return DANCE_ERROR;
		}
		this->setSensor( sensor );
		danceInterp::OutputMessage("Controller '%s' is now using sensor '%s'.", this->getName(), sensor->getName());
		if (this->testControllerWindow != NULL)
			this->testControllerWindow->updateGUI();
		return DANCE_OK;
	}

	return DANCE_CONTINUE;
}

// override this method to control the skeleton
void TestController::applyPDParams(double time, ArticulatedObject* ao, double *state, double *dstate)
{
	// the following are the controllable DOF for standard ODE skeleton:
	// (these values will vary according to the topology of the skeleton)
	static int trunkI = 7;
	static int trunkJ = 8;
	static int trunkK = 9;
	static int trunkW = 10;

	static int neckI = 11;
	static int neckJ = 12;
	static int neckK = 13;
	static int neckW = 14;

	static int headX = 15;

	static int lshoulderI = 16;
	static int lshoulderJ = 17;
	static int lshoulderK = 18;
	static int lshoulderW = 19;
	
	static int lforearmY = 20;
	static int lforearmX = 21;

	static int lhandY = 22;
	static int lhandZ = 23;

	static int rshoulderI = 24;
	static int rshoulderJ = 25;
	static int rshoulderK = 26;
	static int rshoulderW = 27;
	
	static int rforearmY = 28;
	static int rforearmX = 29;

	static int rhandY = 30;
	static int rhandZ = 31;

	static int lthighI = 32;
	static int lthighJ = 33;
	static int lthighK = 34;
	static int lthighW = 35;

	static int lshinX = 36;

	static int lfootX = 37;
	static int lfootZ = 38;

	static int rthighI = 39;
	static int rthighJ = 40;
	static int rthighK = 41;
	static int rthighW = 42;

	static int rshinX = 43;

	static int rfootX = 44;
	static int rfootZ = 45;

	/* 	To move to a particular position, set the v (position in radians), ks (stiffness) and kd (damping)
		parameters on the m_params[] array.

		For example, to rotate the left thigh around the x-axis to 90 degrees, use:
			int lThighX = this->convertIndexSimtoAO(sim->GetIndex(Left_Thigh, Left_Thigh_x));
			m_params[sim->GetIndex(Left_Thigh,Left_Thigh_x)].v = 3.14159;
			m_params[sim->GetIndex(Left_Thigh,Left_Thigh_x)].ks = 4.0;
			m_params[sim->GetIndex(Left_Thigh,Left_Thigh_x)].kd = 1.0;

		Note that the index for DOF from the simulator may be different from the index
		into the ArticulatedObject (depending upon the simulator used). Thus, it is a good
		idea to convert the simulator index into the ArticulatedObject index via 
		the convertIndexSimToAO() method.

	*/

	DSimulator *sim = ao->getSimulator(0);

	// move to zero position
	int stateSize = ao->getStateSize();
	for (int x = 0; x < stateSize; x++)
	{
		m_params[x].v = 0.0;
		m_params[x].ks = 1.0;
		m_params[x].kd = 1.0;
	}
	// since a quaternion in a zero state is <0,0,0,1>, we must set all quaternion w values to one
	m_params[trunkW].v = 1.0;
	m_params[neckW].v = 1.0;
	m_params[lshoulderW].v = 1.0;
	m_params[rshoulderW].v = 1.0;
	m_params[lthighW].v = 1.0;
	m_params[rthighW].v = 1.0;

	// bring arms down to side
	// ball joints must be specified as quaternions
	// left shoulder
	Matrix3x3 lshldrMat; // to simplify, specify rotations in XYZ
	lshldrMat.setRotateMatrix(Matrix3x3::Z, -80 * M_PI / 180.0); // here an 80 degree rotation around Z
	Quaternion lshlderQuat; 
	lshlderQuat.fromMatrix(lshldrMat); // convert from matrix to a quaternion
	m_params[lshoulderI].v = lshlderQuat[0]; // assign the quaternion values
	m_params[lshoulderJ].v = lshlderQuat[1]; // assign the quaternion values
	m_params[lshoulderK].v = lshlderQuat[2]; // assign the quaternion values
	m_params[lshoulderW].v = lshlderQuat[3]; // assign the quaternion values

	// right shoulder
	Matrix3x3 rshldrMat; // to simplify, specify rotations in XYZ
	rshldrMat.setRotateMatrix(Matrix3x3::Z, 80 * M_PI / 180.0); // here an -80 degree rotation around Z
	Quaternion rshlderQuat; 
	rshlderQuat.fromMatrix(rshldrMat); // convert from matrix to a quaternion
	m_params[rshoulderI].v = rshlderQuat[0]; // assign the quaternion values
	m_params[rshoulderJ].v = rshlderQuat[1]; // assign the quaternion values
	m_params[rshoulderK].v = rshlderQuat[2]; // assign the quaternion values
	m_params[rshoulderW].v = rshlderQuat[3]; // assign the quaternion values

	// bend both knees to 10 degree angle
	m_params[rshinX].v = 10.0 * M_PI / 180.0;
	m_params[lshinX].v = 10.0 * M_PI / 180.0;
	
	// use the sensors to determine action
	if (this->getSensor() == NULL || (this->getSensor() != NULL && this->getSensor()->getSystem() == NULL)) 
	{ // no sensor information present
		
		return;
	}
	else // sensors are present
	{
		Vector velocityCOM;
		this->getSensor()->getCMVelocity(velocityCOM); // which way are we falling?
		if (velocityCOM[2] < 0) // falling forward
		{
			// bend the trunk backwards slightly
			Matrix3x3 trunkMat; // to simplify, specify rotations in XYZ
			trunkMat.setRotateMatrix(Matrix3x3::X, 10 * M_PI / 180.0); // here an 10 degree rotation around X
			Quaternion trunkQuat; 
			trunkQuat.fromMatrix(trunkMat); // convert from matrix to a quaternion
			m_params[trunkI].v = trunkQuat[0]; // assign the quaternion values
			m_params[trunkJ].v = trunkQuat[1]; // assign the quaternion values
			m_params[trunkK].v = trunkQuat[2]; // assign the quaternion values
			m_params[trunkW].v = trunkQuat[3]; // assign the quaternion values

			// bend the knees more depending upon how fast we are moving forward
			if (velocityCOM[2] < -.4)
			{
				m_params[rshinX].v = 30.0 * M_PI / 180.0;
				m_params[lshinX].v = 30.0 * M_PI / 180.0;
			}
		}
		else if (velocityCOM[2] > 0) // falling backwards
		{
			// bend the trunk forwards slightly
			Matrix3x3 trunkMat; // to simplify, specify rotations in XYZ
			trunkMat.setRotateMatrix(Matrix3x3::X, -10 * M_PI / 180.0); // here an -10 degree rotation around X
			Quaternion trunkQuat; 
			trunkQuat.fromMatrix(trunkMat); // convert from matrix to a quaternion
			m_params[trunkI].v = trunkQuat[0]; // assign the quaternion values
			m_params[trunkJ].v = trunkQuat[1]; // assign the quaternion values
			m_params[trunkK].v = trunkQuat[2]; // assign the quaternion values
			m_params[trunkW].v = trunkQuat[3]; // assign the quaternion values

			// bend the knees less depending upon how fast we are moving backwards
			if (velocityCOM[2] > .4)
			{
				m_params[rshinX].v = 0.0 * M_PI / 180.0;
				m_params[lshinX].v = 0.0 * M_PI / 180.0;
			}


		}

	}
}

void TestController::setSensor(Sensor* sensor)
{
	if (m_sensor != NULL)
		this->removeDependency(m_sensor);

	m_sensor = sensor;
	if (m_sensor != NULL)
		this->addDependency(m_sensor);
}

Sensor* TestController::getSensor()
{
	return m_sensor;
}

void TestController::onDependencyRemoval(DObject* obj)
{
}

fltk::Widget* TestController::getInterface()
{
	if (testControllerWindow == NULL)
	{
		testControllerWindow = new TestControllerWindow(this, 10, 10, 300, 400, this->getName());
	}

	return testControllerWindow;
}

void TestController::save(int mode, std::ofstream& file)
{
	char buff[512];

	if (mode == 0) // object instantiation
	{
		file << "dance.instance(\"TestController\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1) // parameter setting
	{
		PDController::save(mode, file);
	}
	else if (mode == 2) // object dependencies
	{
		PDController::save(mode, file);

		if (this->getSensor() != NULL)
		{
			sprintf(buff, "\"sensor\", \"%s\"", this->getSensor()->getName());
			pythonSave(file, buff);	
		}
	}
}

int TestController::getNumPluginDependents()
{
	return 3;
}

const char* TestController::getPluginDependent(int num)
{
	if (num == 0)
		return "ArticulatedObject";
	else if (num == 1)
		return "PDController";
	else if (num == 2)
		return "SensorSkeleton";
	else
		return NULL;
}

