/**************************************************************************
	D.A.N.C.E.
	Dynamic AnimatioN and Control Environment
	----------------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
-----------------------------------------------
	
 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

 This software is distributed for noncommercial use in the hope that it will 
 be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
 to anyone for the consequences	of using it or for whether it serves any 
 particular purpose or works at all. No warranty is made about the software 
 or its performance. Commercial use is prohibited.
***************************************************************************/

#ifndef _ODESIM_
#define _ODESIM_

#include "defs.h"
#include "DSimulator.h"
#include "ArticulatedObject.h"

#ifndef dDOUBLE
#define dDOUBLE
#endif
#include <ode/ode.h>
#include <deque>
#include <vector>

#ifdef dSINGLE
#define ITSSINGLE
#else
#define ITSDOUBLE
#endif

class ODESimWindow;

#ifdef WIN32
#ifndef ODESIM_EXPORTS
#define	DLLODESIM __declspec(dllexport)
#else
#define	DLLODESIM __declspec(dllimport)
#endif
#else
#define DLLODESIM 
#endif

class DLLODESIM ODESim : public DSimulator {
  
 public:
  
	ODESim();
	~ODESim();

	int  commandPlugIn(
				int argc, char **argv);

	PlugIn* create(int argc, char **argv);

	void SetTime(double currentTime);
	double GetTime();

	int Step(DSystem *sys, double destinationTime);
	int Start(double time);
	int Stop();

	void saveSystemState(double time);

	void output(int mode);

	void PointForce(int group, double *point, double *force);
	void PointForce(DSystem* system, double *point, double *force);
	void FieldForce(double *force);
    void GeneralizedForce(int group, int subgroup, double magnitude);
	void BodyTorque(int group, double *torque) ;

	virtual void SetupVelocityDrive( int group, Vector argSpring, Vector argDamping, Vector argMaxForce );
	virtual void ApplyVelocityDrive( int group, Vector argTargetAngularVelocity );

	int GetPosition(DSystem *sys, double *localPoint, double *position);
	int GetLocalPosition(int group, double *localPoint, double *position);

	void GetVel(DSystem *sys, double *localPoint, int index, double *vel);
	void GetVel(DSystem *sys, double *localPoint, double *vel);
	void GetVel(int group, double *point, double *vel);
	double* GetVel();

	void GetAngVel(int group, double *vel);

	void GetAcc(int group, double *point, double *acc);
    void GetAcc(DSystem *sys, double *localPoint, double *acc);

	int getStateSize();
	int GetIndex(int group, int subgroup);

	int SetStateFromObjectState(DSystem* system, bool setVelocities = true, bool useCurrent = false);
	int SetObjectStateFromState(DSystem* system, bool setVelocities = true);

	int GetOrientation(int group, double *localPoint, int targetGroup, double *rotated);
    int GetPosition(int group, double *localPoint, double *position);

	int SetOrientation(int group, double orientation[3][3]);
	int SetPosition(int group, double *position);

	void addSystem(DSystem* system);

	void resetPhysicalProperties(DSystem* system);

	void setShowBodyPositions(bool val);
	bool isShowBodyPositions();

	void setShowAttachments(bool val);
	bool isShowAttachments();

	void setUseJointLimits(bool val);
	bool isUseJointLimits();

	void setUseStepFast(bool val);
	bool isUseStepFast();

	void setStepFastIterations(int num);
	int getStepFastIterations();

	void setWorldERP(double val);
	double getWorldERP();
	void setWorldCFM(double val);
	double getWorldCFM();

	void setContactMaxCorrectingVel( double val );
	double getContactMaxCorrectingVel( void );

	bool writeODESourceCode(char* filename, ArticulatedObject* ao);

	void save(int mode, std::ofstream& file);
	fltk::Widget* getInterface();

	int getNumPluginDependents();
	const char* getPluginDependent(int num);

	dBodyID getODEBodyID(int num);
	dJointID getODEJointID(int num);
	dWorldID getODEWorldID();

	void getGlobalAxes( int group, Vector outAxes[3] );
	void getComputedLinkAxes( int group, Vector outAxes[] );

	void checkAttachments();

	/// Call to add the applied torques to running totals
	virtual void accumulateTorques( void );

	/// Provides a single joint's applied torque
	virtual void acquireTorque( Vector outTorque, int argGroupId /*Joint*/ );
	
	/// Allows retrieval of the torques applied since last zeroTorques()
	virtual void acquireTorques( std::vector<double>& outTorques /* treated as state space */ );
	
	/// Reset all the accumulated torques to zero.  Call once per controller update.
	virtual void zeroTorques( void );
        void showParameters();

 protected:

	void createAttachments();
  
	static void afterAllSteps(DObject* object, double time);
	void convertLinkLocalToJointEuler( int group, Vector outJointEuler, Vector argLinkLocal ) const;

	void ApplyJointLimits(DSystem* system);
	int getBodyIndexFromSystem(Link* link);
	void initializeStateMapping();
	void setIndexMapping();
	void calculateState(bool calculateVelocities = true);
	void applyJointLimits();
	void initializeWorld();
	void cleanUpTempJoints();

	/// Create an amotor on the Ball joint.  Used for limits and for velocity drives.
	dJointID createAMotorBall( Joint* joint, dBodyID inLinkID, dBodyID outLinkID );

	double* lastPosition;
	static dWorldID world;
	static bool stepPerformed;
	std::vector<dBodyID> bodies;
	std::vector<dJointID> joints;
	std::vector<dJointID> tempJoints;
	//std::vector<dJointID> secondaryJoints;
	std::vector<dJointID> motorAngles;
	std::vector<int> bodiesWithForce;
	std::vector<dJointID> attachments;
	ArticulatedObject* ao;
	int aoindex[MAX_LINKS][6];
	double state[MAX_STATE];
	double dstate[MAX_STATE];

private:
	void getJointMatrix(Joint* joint, double matrix[4][4]);
	void getGlobalJointMatrix(Joint* joint, double matrix[4][4]);
	void setOrderedParameters3(int order, double* to, double* from);
	void setOrderedParameters2(int order, double* to, double* from);
	void setOrderedParameters1(int order, double* to, double* from);

	/// Release all Amotors (motorAngles collection)
	void clearAmotors( void );

	/// Use ODE Feedback to calculate the applied torque on this joint
	void accumulateAmotorTorque( int argAmotorIdx );
	void accumulateJointTorque( int argGroupIdx );
	/// Record the given torque on the given joint (aka group) id
	void accumulateTorque( int argJointIdx, double argX, double argY, double argZ );

	double holdMatrix[MAX_LINKS][4][4];

	ArticulatedObject* attachTest;
	double m_dt;
	double m_time;
	ODESimWindow* m_odeWindow;
	bool m_isShowBodyPositions;
	double m_angVelDamping;
	bool m_useStepFast;
	int m_stepFastIterations;
	double m_worldERP;
	double m_worldCFM;
	double m_contactMaxCorrectingVel;
	bool m_isUseJointLimits;
	bool m_isShowAttachments;

	Vector rootJoint;

	CharacterAnimationSequence anim;

	// Per-frame joint torques
	double m_jointTorques[ MAX_JOINTS * 3 ];
};


#endif
