/**************************************************************************
	D.A.N.C.E.
	Dynamic AnimatioN and Control Environment
	----------------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
-----------------------------------------------
	
 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

 This software is distributed for noncommercial use in the hope that it will 
 be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
 to anyone for the consequences	of using it or for whether it serves any 
 particular purpose or works at all. No warranty is made about the software 
 or its performance. Commercial use is prohibited.
***************************************************************************/

#include "ODESim.h"
#include "danceInterp.h"
#include <string>
#include "dance.h"
#include "DActuator.h"
#include "ArticulatedObject.h"
#include "Joint.h"
#include "Link.h"
#include "ODESimWindow.h"
#include "AnimationSequence.h"
#include "KeyFrame.h"
#include <iostream>
#include <fstream>

#include <string>
#include <map>
#include <vector>
#include <cassert>

dWorldID ODESim::world = NULL;
bool ODESim::stepPerformed = false;

using namespace std;

void printMat44(double a[4][4])
{
	int i	;

	for( i = 0 ; i < 4 ; i++)
		    danceInterp::OutputMessage("%lf %lf %lf %lf ", a[i][0],a[i][1], a[i][2], a[i][3]) ;
		
	return ;
}

PlugIn* Proxy()
{
  return new ODESim();
}

PlugIn* ODESim::create(int argc, char **argv)
{
  
	ODESim* sim = new ODESim();
	if (argc >= 1)
	{
		DSystem *ao = (DSystem *) dance::AllSystems->get(argv[0]) ;

		if( ao == NULL ) 
		{
			danceInterp::OutputMessage("No such object: %s", argv[0]) ;
			return NULL ;
		}
		sim->addSystem(ao);
	}

	return sim;
}

ODESim::ODESim() : DSimulator()
{
    this->setType("ODESim");
	ao = NULL;
	m_odeWindow = NULL;
	lastPosition = NULL;

	initializeStateMapping();
	setShowBodyPositions(false);

	setUseStepFast(false);
	setStepFastIterations(3);

	this->setWorldERP(.2);
	this->setWorldCFM(10e-10);
	setContactMaxCorrectingVel( dInfinity );
	m_time = 0.0;
	setUseJointLimits(true);
        setShowAttachments(false);

	initializeWorld();

	for (int x = 0; x < MAX_LINKS; x++)
		setIdentMat(&holdMatrix[x][0][0], 4);

	dance::AllSimulators->addSimStepCB(this, 999999999, afterAllSteps);
}

ODESim::~ODESim()
{  
	
	// remove the old joints
	for (vector<dJointID>::iterator iter = joints.begin(); iter != joints.end(); iter++)
	{
		if (*iter != NULL)
		{
			// remove feedback
			delete dJointGetFeedback(*iter);
			// destroy joint
			dJointDestroy(*iter);
	}
	}
	joints.clear();

	clearAmotors();

	// remove the attachments
	for (vector<dJointID>::iterator iter = attachments.begin(); iter != attachments.end(); iter++)
	{
		if (*iter != NULL)
			dJointDestroy(*iter);
	}
	attachments.clear();

	// remove the bodies
	for (vector<dBodyID>::iterator iter = bodies.begin(); iter != bodies.end(); iter++)
	{
		dBodyDestroy(*iter);
	}
	bodies.clear();
	
	// destroy the world only if there are no more ODE simulators around
	bool found = false;
	for (int x = 0; x < dance::AllSimulators->size(); x++)
	{
		ODESim* odeSim = dynamic_cast<ODESim*>(dance::AllSimulators->get(x));
		if (odeSim != NULL)
		{
			if (odeSim != this)
			{
				found = true;
				break;
			}
		}
	}
	if (!found && world != NULL)
	{
		dWorldDestroy(world);
		world = NULL;
	}

	if (lastPosition != NULL)
		delete [] lastPosition;

	if (this->m_odeWindow != NULL)
		delete m_odeWindow;
}

int ODESim::commandPlugIn(int argc, char **argv)
{
	int ret = DSimulator::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

	if (strcmp(argv[0], "load_ao_params") == 0)
	{

		ArticulatedObject* artObj = dynamic_cast<ArticulatedObject*>(m_systems.get(0));

		// create the last angle vectors and store them with the joints
		int numJoints = joints.size();
		if (lastPosition == NULL)
			lastPosition = new double[numJoints * 3];
		for (int x = 0; x < numJoints * 3; x++)
		{
			lastPosition[x] = 0.0;
		}

		double state[MAX_STATE];
		artObj->getState(state);
		this->SetStateFromObjectState(artObj);
		artObj->setState(state);
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "show_body_positions") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: simulator %s show_body_positions <true|false>", this->getName());
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "true") == 0)
		{
			this->setShowBodyPositions(true);
			danceInterp::OutputMessage("simulator %s body positions will now be shown.", this->getName());
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "false") == 0)
		{
			this->setShowBodyPositions(false);
			danceInterp::OutputMessage("simulator %s body positions will no longer be shown.", this->getName());
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Usage: simulator %s show_body_positions <on|off>", this->getName());
			return DANCE_ERROR;
		}
	}
	else if (strcmp(argv[0], "use_step_fast") == 0 || strcmp(argv[0], "use_quick_step") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: simulator %s use_step_fast <true|false>", this->getName());
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "true") == 0)
		{
			this->setUseStepFast(true);
			danceInterp::OutputMessage("Simulator %s is now using step fast.", this->getName());
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "false") == 0)
		{
			this->setUseStepFast(false);
			danceInterp::OutputMessage("Simulator %s is not using step fast.", this->getName());
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Usage: simulator %s use_step_fast <true|false>", this->getName());
			return DANCE_ERROR;
		}

	}
	else if (strcmp(argv[0], "use_joint_limits") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: simulator %s use_joint_limits <true|false>", this->getName());
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "true") == 0)
		{
			this->setUseJointLimits(true);
			danceInterp::OutputMessage("Simulator %s is now using ODE joint limits.", this->getName());
			return DANCE_OK;
		}
		else if (strcmp(argv[1], "false") == 0)
		{
			this->setUseJointLimits(false);
			danceInterp::OutputMessage("Simulator %s is not using ODE joint limits.", this->getName());
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Usage: simulator %s use_joint_limits <true|false>", this->getName());
			return DANCE_ERROR;
		}

	}
	else if (strcmp(argv[0], "step_fast_iterations") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: simulator %s step_fast_iterations <num>", this->getName());
			return DANCE_ERROR;
		}
		int numIterations = atoi(argv[1]);
		this->setStepFastIterations(numIterations);
		danceInterp::OutputMessage("Simulator %s is now using %d iterations.", this->getName(), this->getStepFastIterations());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "world_erp") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: simulator %s world_erp <erp>", this->getName());
			return DANCE_ERROR;
		}
		double erp = atof(argv[1]);
		this->setWorldERP(erp);
		danceInterp::OutputMessage("Simulator %s is now using world ERP of %f.", this->getName(), this->getWorldERP());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "world_cfm") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: simulator %s world_cfm <erp>", this->getName());
			return DANCE_ERROR;
		}
		double cfm = atof(argv[1]);
		this->setWorldCFM( cfm );
		danceInterp::OutputMessage("Simulator %s is now using world CFM of %f.", this->getName(), this->getWorldCFM());
		return DANCE_OK;
	}
	else if (strcmp( argv[0], "max_contact_vel" ) == 0)
	{
		if( argc < 2)
		{
			danceInterp::OutputMessage("Usage: simulator %s max_contact_vel <vel>", this->getName());
			return DANCE_ERROR;
		}
		double maxVel = atof( argv[1] );
		setContactMaxCorrectingVel( maxVel );
		danceInterp::OutputMessage( "Simulator %s is now using world contact max correcting velocity of %f.", getName(), getContactMaxCorrectingVel() );
		return DANCE_OK;
	}
	else if (strcmp( argv[0], "show_parameters" ) == 0)
	{
                showParameters();
		return DANCE_OK;
        }

	return DANCE_CONTINUE;
}

void ODESim::SetTime(double ct)
{
	m_time = ct;
}

int ODESim::Step(DSystem* sys, double dTime)
{ 
	this->stepPerformed = false;

	if (!this->isActive())
		return 0;

	int numAOs = this->getNumSystems();
	if (numAOs == 0)
		return 0;

	ArticulatedObject* artObj = (ArticulatedObject*) this->getSystem(0);
	if (artObj == NULL)
		return 0;


	for (unsigned int x = 0; x < bodiesWithForce.size(); x++)
		bodiesWithForce[x] = 0;
	
	double dt = this->getTimeStep();

	//double mainDt = dance::AllSimulators->getSimulationTimeStep();

	this->ApplyActuatorForces(artObj, dTime, dt, state, dstate);

/*
	// determine if any joint angles violate their constraints
	Joint** aojoints = ((ArticulatedObject*) sys)->getJoints();
	int numJoints = ((ArticulatedObject*) sys)->getNumJoints();
	bool violation = false;
	for (int j = 0; j < numJoints; j++)
	{
		int numAxes = aojoints[j]->getNumAxis();
		double axis[3][3];
		aojoints[j]->getAxis(axis);
		for (int a = 0; a < numAxes; a++)
		{
			double low;
			double high;
			aojoints[j]->getLimits(a, &low, &high);
			double val = state[this->GetIndex(j, a)];
			// convert state from radians to degrees
			val = val * 180.0 / 3.14159;
			if (val < low || val > high)
			{
				danceInterp::OutputMessage("%f: Joint %d (%s) axis %d violating limits: %f (%f to %f)...", this->GetTime(), j, aojoints[j]->getName(), a, val, low, high);
				violation = true;
			}
		}
		
	}
	// dump the state
	if (false) //(violation)
		for (int x = 0; x < ((ArticulatedObject*) sys)->GetStateSize(); x++)
			danceInterp::OutputMessage("Time %f) [%d] %f", this->GetTime(), x, state[x]);
*/

	return 1;
}


void ODESim::afterAllSteps(DObject* object, double time)
{
	ODESim* sim = (ODESim*) object;

	if (!sim->stepPerformed)
	{
		if (sim->isUseStepFast())
			dWorldQuickStep(sim->world, sim->getTimeStep());
		else
			dWorldStep(sim->world, sim->getTimeStep());

		sim->stepPerformed = true;
	}
}

double ODESim::GetTime()
{  
  return m_time;
}

int ODESim::Start(double t)
{    
    // make sure ODE will be deterministic
    dRandSetSeed(0);

	static bool initOnce = false;
	if (!initOnce)
	{
		dInitODE2(0);
		initOnce = true;
	}

	anim.clear();

// 	// copy the state of association systems to the ODE state
	int numSystems = m_systems.size();
	for (int x = 0; x < numSystems; x++)
	{
		ArticulatedObject* artObj = dynamic_cast<ArticulatedObject*>(m_systems.get(x));

		// create the last angle vectors and store them with the joints
		int numJoints = joints.size();
		if (lastPosition == NULL)
			lastPosition = new double[numJoints * 3];
		for (int x = 0; x < numJoints * 3; x++)
		{
			lastPosition[x] = 0.0;
		}

		this->SetStateFromObjectState(artObj);
		this->applyJointLimits();
	}

	// enable or disable bodies and joints
    for (unsigned int b = 0; b < bodies.size(); b++)
    {
        dBodyEnable(bodies[b]);
    }
	
	m_time = t;

	this->createAttachments();
 
    // make sure that the force/torque accumulators are zero
    for (unsigned int b = 0; b < bodies.size(); b++)
    {
        const dReal* forceAccum = dBodyGetForce (bodies[b]);
        const dReal* torqueAccum = dBodyGetTorque (bodies[b]);
        
        if (fabs(forceAccum[0] + forceAccum[1] + forceAccum[2]) > .001 ||
            fabs(torqueAccum[0] + torqueAccum[1] + torqueAccum[2]) > .001)
        {
            danceInterp::OutputMessage("Force/torque accumulator for %s: (%f, %f, %f) (%f, %f, %f)", 
                                        forceAccum[0], forceAccum[1], forceAccum[2],
                                        torqueAccum[0], torqueAccum[1], torqueAccum[2]);
        }
    }

	return 1;
}

int ODESim::Stop()
{
  
	int numSystems = m_systems.size();
	for (int x = 0; x < numSystems; x++)
	{
	}
  return 1;
}

void ODESim::checkAttachments()
{ 
	// reconcile current attachments known by simulator with those
	// indicated by skeletons and objects
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(this->getSystem(0));
	if (ao != NULL)
	{
		for (int x = 0; x < ao->getNumLinks(); x++)
		{
			Link* link = ao->getLink(x);
			int attachNum;
			ArticulatedObject* attachao = link->getAttachment(attachNum);
			if (attachao != NULL)
			{
				// check to see if attachment exists in simulator
				// get the simulator
				ODESim* othersim = dynamic_cast<ODESim*>(attachao->getSimulator(0));
				if (othersim != NULL)
				{
					// get the other body
					dBodyID otherBody = othersim->getODEBodyID(attachNum);

					// get this body
					dBodyID body = bodies[x];

					if (body == otherBody)
					{
						danceInterp::OutputMessage("ODE Problem:: Cannot afix same body to itself.");
						continue;
					}

					// check for attached joint - does it exist?
					bool found = false;
					for (unsigned int a = 0; a < attachments.size(); a++)
					{
						// check ODE to see if this joint is the joint 
						// that attaches body to otherBody
						dBodyID first = dJointGetBody(attachments[a], 0);
						dBodyID second = dJointGetBody(attachments[a], 1);
						if ((first == body && second == otherBody) || (first == otherBody && second == body))
						{
							found = true;
							break;
						}
					}
					if (!found)
					{
						// create the joint
						dJointID attachJoint = dJointCreateFixed(world, 0);						
						dJointAttach(attachJoint, otherBody, body);
						dJointSetFixed(attachJoint);
					}
				}
			}
			else
			{ // no attachments, make sure none exist, remove from simulator if necessary
				bool found = false;
				// get this body
				dBodyID body = bodies[x];
				vector<dJointID>::iterator iter;
				int a = 0;
				for (iter = attachments.begin(); iter != attachments.end(); iter++)
				{
					// check ODE to see if this joint is the joint 
					// that attaches body to otherBody
					dBodyID first = dJointGetBody(attachments[a], 0);
					dBodyID second = dJointGetBody(attachments[a], 1);
					if (first == body || second == body)
					{
						found = true;
						break;
					}
					a++;
				}
				
				if (found)
				{
					// destroy the joint
					dJointDestroy(attachments[a]);
					attachments.erase(iter);
				}
			}

			DGeometry* geom = link->getAttachmentStatic();
			if (geom != NULL)
			{
				// get this body
				dBodyID body = bodies[x];

				bool found = false;
				for (unsigned int a = 0; a < attachments.size(); a++)
				{
					// check ODE to see if this joint is the joint 
					// that attaches body to static geometry
					dBodyID second = dJointGetBody(attachments[a], 1);
					if (second == body)
					{
						found = true;
						break;
					}
				}
				if (!found)
				{
					// create a weld joint between the body and the world
					dJointID attachJoint = dJointCreateFixed(world, 0);
					dJointAttach(attachJoint, NULL, body);
					dJointSetFixed(attachJoint);
					attachments.push_back(attachJoint);
				}
			}
			else
			{
				bool found = false;
				// get this body
				dBodyID body = bodies[x];
				vector<dJointID>::iterator iter;
				int a = 0;
				for (iter = attachments.begin(); iter != attachments.end(); iter++)
				{
					// check ODE to see if this joint is the joint 
					// that attaches body to otherBody
					dBodyID first = dJointGetBody(attachments[a], 0);
					dBodyID second = dJointGetBody(attachments[a], 1);
					if (second == body && first == 0)
					{
						found = true;
						break;
					}
					a++;
				}
				
				if (found)
				{
					// destroy the joint
					dJointDestroy(attachments[a]);
					attachments.erase(iter);
				}

			}
		}
	}
}



void ODESim::createAttachments()
{
	// add inter-skeleton attachments
	// first, remove the old joint attachments
	for (vector<dJointID>::iterator iter = attachments.begin(); iter != attachments.end(); iter++)
	{
		if (*iter != NULL)
			dJointDestroy(*iter);
	}
	attachments.clear();

	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(this->getSystem(0));
	if (ao != NULL)
	{
		// dynamic attachements to other bodies
		for (int x = 0; x < ao->getNumLinks(); x++)
		{
			Link* link = ao->getLink(x);
			int attachNum;
			ArticulatedObject* attachao = link->getAttachment(attachNum);
			if (attachao != NULL) 
			{ // has attachment, verify that simulator is in sync
				// get the simulator
				ODESim* othersim = dynamic_cast<ODESim*>(attachao->getSimulator(0));
				if (othersim != NULL)
				{
					// get the other body
					dBodyID otherBody = othersim->getODEBodyID(attachNum);

					// get this body
					dBodyID body = bodies[x];

					if (body == otherBody)
					{
						danceInterp::OutputMessage("ODE Problem:: Cannot afix same body to itself.");
						continue;
					}

					// create a weld joint between the two bodies
					dJointID attachJoint = dJointCreateFixed(world, 0);
                    // get the position of the joint     
					dJointAttach(attachJoint, otherBody, body);
					dJointSetFixed(attachJoint);
					attachments.push_back(attachJoint);
				}
				else
				{
					danceInterp::OutputMessage("Cannot attach joint to skeleton %s since it doesn't use the same simulator (ODE).", attachao->getName());
				}
			}
			
			DGeometry* geom = link->getAttachmentStatic();
			if (geom != NULL)
			{
				// get this body
				dBodyID body = bodies[x];

				// create a weld joint between the body and the world
				dJointID attachJoint = dJointCreateFixed(world, 0);
				dJointAttach(attachJoint, NULL, body);
				dJointSetFixed(attachJoint);
				attachments.push_back(attachJoint);
			}
		}
	}

}

void ODESim::output(int mode)
{
	if (isShowBodyPositions())
	{
	// display the location of the rigid bodies
		glPushAttrib(GL_LIGHTING_BIT | GL_DEPTH_BUFFER_BIT);
		glEnable(GL_DEPTH_TEST);
		glPointSize(7.0);

		glColor3f(1.0, 0.0, 0.0);
		glDisable(GL_LIGHTING);
		glPushMatrix();
		glBegin(GL_POINTS);
		vector<dBodyID>::iterator iter;
		int count = 0;
		for (iter = bodies.begin(); iter != bodies.end(); iter++)
		{
			glColor3f(1.0, 0.0, 0.0);
			const dReal* pos = dBodyGetPosition(*iter);
			if (bodiesWithForce[count] == 1)
					glColor3f(0.0, 1.0, 0.0);

			glVertex3d(pos[0], pos[1], pos[2]);
			if (bodiesWithForce[count] == 1)
					glColor3f(1.0, 0.0, 0.0);

			count++;
		}

		// show the joints
//		glColor3f(1.0, 1.0, 0.0);
		for (unsigned int x = 0; x < joints.size(); x++)
		{

			if (joints[x] == NULL)
				continue;

			int jointType = dJointGetType(joints[x]);
			dVector3 vec;
			switch (jointType)
			{
				case dJointTypeBall:
					dJointGetBallAnchor(joints[x], vec);
					glVertex3d(vec[0], vec[1], vec[2]);
					break;

				case dJointTypeHinge:
					dJointGetHingeAnchor(joints[x], vec);
					glVertex3d(vec[0], vec[1], vec[2]);
					break;

				case dJointTypeSlider:
					break;

				case dJointTypeContact:
					break;

				case dJointTypeUniversal:
					dJointGetUniversalAnchor(joints[x], vec);
					glVertex3d(vec[0], vec[1], vec[2]);
					dJointGetUniversalAnchor2(joints[x], vec);
					glVertex3d(vec[0], vec[1], vec[2]);
					break;

				case dJointTypeHinge2:
					dJointGetHinge2Anchor(joints[x], vec);
					glVertex3d(vec[0], vec[1], vec[2]);
					break;

				case dJointTypeFixed:
					break;

				case dJointTypeAMotor:
					break;
			}
			
		}
		glEnd();

		glPopMatrix();
		glPopAttrib();
	}

	// show the attachments
	if (this->isShowAttachments())
	{
		glPushAttrib(GL_COLOR_BUFFER_BIT);
		glColor3f(1.0, 0.0, 1.0);
		glDisable(GL_LIGHTING);

		for (unsigned int x = 0; x < attachments.size(); x++)
		{
			if (attachments[x] == NULL)
				continue;

			//int jointType = dJointGetType(attachments[x]);
			dBodyID first = dJointGetBody (attachments[x], 0);
			dBodyID second = dJointGetBody (attachments[x], 1);

			Vector firstLoc;
			Vector secondLoc;
			if (first)
			{
				const dReal* pos1 = dBodyGetPosition(first);
				for (int x = 0; x < 3; x++)
					firstLoc[x] = pos1[x];
			}

			if (second)
			{
				const dReal* pos2 = dBodyGetPosition(second);
				for (int x = 0; x < 3; x++)
					secondLoc[x] = pos2[x];
			}

			double dist = 1.0;
			if (first && second)
			{
				//double dist = VecDist(firstLoc, secondLoc);
			}
			
			if (first)
			{
				// source
				glPushMatrix();
				glTranslated(firstLoc[0], firstLoc[1], firstLoc[2]);
				glutWireSphere(dist/20.0, 5, 5);
				glPopMatrix();
			}

			if (first && second)
			{
				glBegin(GL_LINES);
				glVertex3d(firstLoc[0], firstLoc[1], firstLoc[2]);
				glVertex3d(secondLoc[0], secondLoc[1], secondLoc[2]);			
				glEnd();
			}

			if (second)
			{
				// target
				glPushMatrix();
				glTranslated(secondLoc[0], secondLoc[1], secondLoc[2]);
				glutWireSphere(dist/20.0, 5, 5);
				glPopMatrix();
			}

		}
		glPopAttrib();
	}

	if (dance::AllSimulators->getSimulationMode() == DSimulatorManager::MODE_PLAYBACK)
	{
		KeyFrame* kf = anim.getKeyFrame(dance::AllSimulators->getPlaybackTime());
		if (kf == NULL)
			return;
		glPushAttrib(GL_LIGHTING_BIT | GL_DEPTH_BUFFER_BIT);
		glEnable(GL_DEPTH_TEST);
		glPointSize(7.0);

		glColor3f(1.0, 0.0, 0.0);
		glDisable(GL_LIGHTING);

		glBegin(GL_POINTS);
		for (int i = 0; i < kf->getNumParams(); i += 3)
			glVertex3f(kf->getParam(i), kf->getParam(i + 1), kf->getParam(i + 2));
		glEnd();
		glPopAttrib();

	}
}

void ODESim::FieldForce(double *accel)
{
  dMass mass;
  VectorObj force;
  
  for (unsigned int i = 0 ; i < bodies.size() ; i++)
  {
    force = accel;
    dBodyGetMass(bodies[i], &mass);
    force *= mass.mass;
    dBodyAddForce(bodies[i], force[0], force[1], force[2]);
  }
}

void ODESim::PointForce(int group, double *point, double *force) 
{
	dBodyAddForceAtRelPos(bodies[group], force[0], force[1], force[2], point[0], point[1], point[2]);
}

void ODESim::PointForce(DSystem* sys, double *point, double *force) 
{
	dBodyAddForceAtRelPos(0, force[0], force[1], force[2], point[0], point[1], point[2]);
}

void ODESim::BodyTorque(int group, double *torque)
{
	dBodyAddTorque(bodies[group], torque[0], torque[1], torque[2]);
}

int ODESim::SetPosition(int group, double *position)
{
	dBodySetPosition(bodies[group], position[0], position[1], position[2]);

	return 0;
}

int ODESim::SetOrientation(int group, double orientation[3][3])
{
	dMatrix3 dm;
	dRSetIdentity(dm);
	for (int r = 0; r < 3; r++)
		for (int c = 0; c < 3; c++)
			dm[r * 4 + c] = orientation[c][r];
	dBodySetRotation(bodies[group], dm);

	return 0;
}

int ODESim::GetOrientation(int group, double *localPoint, int targetGroup, double *rotated)
{
	if (group == -1)
		group = 0;
	dVector3 result;
	dBodyVectorToWorld(bodies[group], localPoint[0], localPoint[1], localPoint[2], result);
	rotated[0] = result[0];
	rotated[1] = result[1];
	rotated[2] = result[2];

	return 0;
}

int ODESim::GetPosition(int group, double *localPoint, double *position)
{
	dVector3 pos;
	dBodyGetRelPointPos(bodies[group], localPoint[0], localPoint[1], localPoint[2], pos);

	position[0] = pos[0];
	position[1] = pos[1];
	position[2] = pos[2];

	return 0;
}

int ODESim::GetLocalPosition(int group, double *localPoint, double *position)
{
	dVector3 pos;
	dBodyGetPosRelPoint(bodies[group], position[0], position[1], position[2], pos);

	localPoint[0] = pos[0];
	localPoint[1] = pos[1];
	localPoint[2] = pos[2];

	return 0;
}

int ODESim::GetPosition(DSystem *sys, double *localPoint, double *p)
{
	Link *link = (Link *) sys;
	int index = getBodyIndexFromSystem(link);
	if (index == -1)
	{
		danceInterp::OutputMessage("No articulated object has been attached to this simulator...");
		return 0;
	}

	return this->GetPosition(index, localPoint, p);
}

void ODESim::GetVel(DSystem *sys, double *localPoint, double *vel)
{
	this->GetVel(sys, localPoint, 0, vel);
}

void ODESim::GetVel(DSystem *sys, double *localPoint, int index, double *vel)
{
	Link *link = (Link *) sys;
	int i = getBodyIndexFromSystem(link);
	GetVel(i, localPoint, vel);
}

void ODESim::GetVel(int group, double *localPoint, double *vel)
{
	dVector3 result;
	dBodyGetRelPointVel(bodies[group], localPoint[0], localPoint[1], localPoint[2], result);

	vel[0] = result[0];
	vel[1] = result[1];
	vel[2] = result[2];
}

void ODESim::GetAngVel(int group, double *vel)
{
	const dReal* velocity = dBodyGetAngularVel(bodies[group]);
	vel[0] = velocity[0];
	vel[1] = velocity[1];
	vel[2] = velocity[2];
}

double* ODESim::GetVel()
{
	// assume a free joint w/ three DOF
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(this->getSystem(0));

	if (bodies.size() > 0)
	{
		const dReal* vel = dBodyGetLinearVel(bodies[0]);
		const dReal* angVel = dBodyGetAngularVel(bodies[0]);
		Joint* joint = ao->getJoint(0);
		int order = joint->determineRotationOrder();
		switch (order)
		{
		case Matrix3x3::XYZ:
			dstate[0] = vel[0];
			dstate[1] = vel[1];
			dstate[2] = vel[2];
			dstate[3] = angVel[0];
			dstate[4] = angVel[1];
			dstate[5] = angVel[2];
			break;
		case Matrix3x3::XZY:
			dstate[0] = vel[0];
			dstate[1] = vel[2];
			dstate[2] = vel[1];
			dstate[3] = angVel[0];
			dstate[4] = angVel[2];
			dstate[5] = angVel[1];
			break;
		case Matrix3x3::YXZ:
			dstate[0] = vel[1];
			dstate[1] = vel[0];
			dstate[2] = vel[2];
			dstate[3] = angVel[1];
			dstate[4] = angVel[0];
			dstate[5] = angVel[2];
			break;
		case Matrix3x3::YZX:
			dstate[0] = vel[1];
			dstate[1] = vel[2];
			dstate[2] = vel[0];
			dstate[3] = angVel[1];
			dstate[4] = angVel[2];
			dstate[5] = angVel[0];
			break;
		case Matrix3x3::ZXY:
			dstate[0] = vel[2];
			dstate[1] = vel[0];
			dstate[2] = vel[1];
			dstate[3] = angVel[2];
			dstate[4] = angVel[0];
			dstate[5] = angVel[1];
			break;
		case Matrix3x3::ZYX:
			dstate[0] = vel[2];
			dstate[1] = vel[1];
			dstate[2] = vel[0];
			dstate[3] = angVel[2];
			dstate[4] = angVel[1];
			dstate[5] = angVel[0];
			break;
		default:
			break;
		}
	}
	else
	{
		for (int x = 0; x < 7; x++)
			dstate[0] = 0.0;
	}
	return &dstate[0];
}

void ODESim::GetAcc(int group, double *point, double *acc)
{
	// get the linear acceleration by accumulating the joint forces and then
	// dividng by the mass of the body
	if (this->ao != NULL)
	{
		Vector forceAccum;
		zeroVector(forceAccum);
		// get the inbound link force
		if (joints[group] != NULL)
		{
			dJointFeedback* feedback1 = dJointGetFeedback(joints[group]);
			if (feedback1 != NULL)
			{
				forceAccum[0] += feedback1->f1[0];
				forceAccum[1] += feedback1->f1[1];
				forceAccum[2] += feedback1->f1[2];
			}
		}
  if (group + 1 < int(joints.size()))
		{
			if (joints[group + 1] != NULL)
			{
				// get the outbound link force
				dJointFeedback* feedback2 = dJointGetFeedback(joints[group + 1]); // THIS ISN'T RIGHT! NEED THE INDEX OF THE OUTBOUND BODY!
				if (feedback2 != NULL)
				{
					forceAccum[0] += feedback2->f1[0];
					forceAccum[1] += feedback2->f1[1];
					forceAccum[2] += feedback2->f1[2];
				}
			}
		}
		// divide the accumulated force by the mass of the body
		if (bodies[group] != NULL)
		{
			dMass mass;
			dBodyGetMass(bodies[group], &mass);
			acc[0] = forceAccum[0] / mass.mass;
			acc[1] = forceAccum[1] / mass.mass;
			acc[2] = forceAccum[2] / mass.mass;
		}
	}
	else
	{
		danceInterp::OutputMessage("No articulated object connected to this simulator, cannot retrieve linear acceleration for body %d...", group);
		zeroVector(acc);
	}
}

void ODESim::GetAcc(DSystem *sys, double *localPoint, double *acc)
{
	Link* link = (Link*) sys;
	int i = getBodyIndexFromSystem(link);
	GetAcc(i, localPoint, acc);
}

/// addSystem: Creates the ODE structures (joints, bodies) for the given
/// system
/// TRICKY points:
/// When attaching (creating)a joint or a motor the order of the two bodies
/// is important. The should be given in the (child, parent) order.
/// For example if you want to create a joint between body1 and the
/// world use the order (body1, 0)
void ODESim::addSystem(DSystem* system)
{
	DSimulator::addSystem(system);

	// create an ODE representation of the ArticulatedObject
	ao = (ArticulatedObject*) system;

	// remove the old joints
	for (vector<dJointID>::iterator iter = joints.begin(); iter != joints.end(); iter++)
	{
		if (*iter != NULL)
		{			
			// remove feedback
			delete dJointGetFeedback(*iter);
			dJointDestroy(*iter);
	}
	}
	joints.clear();

	// remove the bodies
	for (vector<dBodyID>::iterator iter = bodies.begin(); iter != bodies.end(); iter++)
	{
		dBodyDestroy(*iter);
	}
	bodies.clear();

	// remove the motor angles
	clearAmotors();

	// remove the joint attachments
	for (vector<dJointID>::iterator iter = attachments.begin(); iter != attachments.end(); iter++)
	{
		if (*iter != NULL)
			dJointDestroy(*iter);
	}
	attachments.clear();
	
	bodiesWithForce.clear();

	setIndexMapping();

	double oldState[MAX_STATE];
	ao->getState(oldState);
	ao->setZeroState();

	// add one body for each link
	int numLinks = ao->getNumLinks();
	for (int l = 0; l < numLinks; l++)
	{
		Link* link = ao->getLink(l);
		danceInterp::OutputMessage("Now processing link '%s'...", link->getName());
		// create a rigid body for each link
		dBodyID bodyID = dBodyCreate(world);
        //dBodySetGyroscopicMode(bodyID, false);
		bodies.push_back(bodyID);
		// set the position
		double matrix[4][4];
		link->getWTransMat(matrix);
		Vector origin = {0.0, 0.0, 0.0};
		transformPoint_mat(origin, matrix);

	dBodySetPosition(bodyID, origin[0], origin[1], origin[2]);
		// set the orientation
		dMatrix3 dm;
//		dRSetIdentity(dm);
//		for (int r = 0; r < 3; r++)
//			for (int c = 0; c < 3; c++)
//				dm[r * 4 + c] = matrix[c][r];
//		dQuaternion q;
//		dRtoQ(dm, q);
//		dBodySetQuaternion(bodyID, q);

		double m[4][4];
		getGlobalJointMatrix(ao->getJoint(l), m);
//danceInterp::OutputMessage("Joint: %s", link->getName());
//for (int r = 0; r < 3; r++)
//	danceInterp::OutputMessage("%6.4f %6.4f %6.4f", m[r][0], m[r][1], m[r][2]);
		dRSetIdentity(dm);
		for (int r = 0; r < 3; r++)
			for (int c = 0; c < 3; c++)
				dm[r * 4 + c] = m[r][c];
		dQuaternion q;
		dRtoQ(dm, q);
		dBodySetQuaternion(bodyID, q);

#ifdef dSINGLE
		danceInterp::OutputMessage("ODE IS RUNNING IS SINGLE PRECISION MODE - THIS IS INCORRECT!!");
#else
#endif

		// set the mass of the body
		dMass mass;
		dMassSetZero(&mass);
		// set the center of mass position relative to the body
		Vector com;
		link->getCenterMass(com);
		mass.c[0] = com[0]; mass.c[1] = com[1]; mass.c[2] = com[2];
		mass.mass = link->getMass();
		// set the inertia tensor
		double inertia[3][3];
		link->getInerTensor(inertia);
		
		dMassSetParameters(&mass, link->getMass(), 
							com[0], com[1], com[2],
							inertia[0][0], inertia[1][1], inertia[2][2],
							inertia[0][1], inertia[0][2], inertia[1][2]
							);
		dBodySetMass(bodyID, &mass);

		bodiesWithForce.push_back(-1);
	}

	// add one ODE joint for each ArticulatedObject joint
	double matrix[4][4];
	double invMatrix[4][4];

	int numJoints = ao->getNumJoints();

	for (int j = 0; j < numJoints; j++)
	{
		Joint* joint = ao->getJoint(j);
		// to which bodies do these joints apply?
		Link* inLink = joint->getInboardLink();
		// get the link id of the inboard link
		dBodyID inLinkID = NULL;
		for (unsigned int i = 0; i < bodies.size(); i++)
		{
			if (inLink == ao->getLink(i))
			{
				inLinkID = bodies[i];
				break;
			}
		}
		if (inLinkID == NULL)
		{
			if (j != 0)
				danceInterp::OutputMessage("No inboard link found for joint '%s'...", joint->getName());
			if (joint->getJointType() == J_FREE)
			{
				joints.push_back(NULL);
				motorAngles.push_back(NULL);
				// make sure that the joint resides in at the COM, since this is what ODE supports
				Vector bodyToJoint;
				joint->getBodyToJoint(bodyToJoint);
				if (VecLength(bodyToJoint) != 0.0)
				{
					danceInterp::OutputMessage("Free joints in ODE do not support body-to-joint vectors != 0.");
					danceInterp::OutputMessage("Please edit the Articulated Object so that the joint location matches the COM location.");
				}
				continue;
			}
		}

		Link* outLink = joint->getOutboardLink();
		// get the link id of the outboard link
		dBodyID outLinkID = NULL;
		for (unsigned int i = 0; i < bodies.size(); i++)
		{
			if (outLink == ao->getLink(i))
			{
				outLinkID = bodies[i];
				break;
			}
		}
		if (outLinkID == NULL)
		{
			danceInterp::OutputMessage("No outboard link found for joint '%s'...", joint->getName());
			joints.push_back(NULL);
			motorAngles.push_back(NULL);
			continue;
		}

		// determine the type of joint
		dJointID jointID = NULL;
		dJointID motorID = NULL;
		int jointType = joint->getJointType();
		double axes[3][3];
		joint->getAxis(axes);
		Vector jointPos;
		Vector globalAxis;
		joint->getPosition(jointPos);

		// apply the joint to those bodies
		// ignore joints that only apply to one body
		if (inLinkID == NULL || outLinkID == NULL)
			jointID = NULL;
		if (inLinkID == NULL && outLinkID == NULL)
		{
			joints.push_back(NULL);
			motorAngles.push_back(NULL);
			continue;
		}

		switch (jointType)
		{
		case J_PIN:
			jointID = dJointCreateHinge(world, 0);
			dJointAttach(jointID, outLinkID, inLinkID);
			// get the position of the joint
			dJointSetHingeAnchor(jointID, jointPos[0], jointPos[1], jointPos[2]);
			// retrieve the axis of rotation

			// convert the local axes into global axes
			setIdentMat(&matrix[0][0], 4);
			setIdentMat(&invMatrix[0][0], 4);
			joint->getOrientation(matrix);
			invSmart4(invMatrix, matrix);

			VecCopy(globalAxis, axes[0]);
			transformPoint_mat(globalAxis, invMatrix);
			dJointSetHingeAxis(jointID, globalAxis[0], globalAxis[1], globalAxis[2]);

			break;
		case J_CYLINDER:
			break;
		case J_SLIDER:
			jointID = dJointCreateSlider(world, 0);
			dJointAttach(jointID, outLinkID, inLinkID);
			dJointSetSliderAxis(jointID, axes[0][0], axes[0][1], axes[0][2]);
			break;
		case J_FREE:
			danceInterp::OutputMessage("Free joint, no IDE joint necessary to support the behavior of joint '%s'...", joint->getName());
			Vector bodyToJoint;
			joint->getBodyToJoint(bodyToJoint);
			if (VecLength(bodyToJoint) != 0.0)
			{
				danceInterp::OutputMessage("Free joints in ODE do not support body-to-joint vectors != 0. Resetting body-to-joint to zero.");
				Vector zero = {0.0, 0.0, 0.0};
				joint->setBodyToJoint(zero);
				ao->updateStateConfig();
			}
			break;
		case J_BALL:
		case J_GIMBAL:
			// create a ball joint
			jointID = dJointCreateBall(world, 0);
			dJointAttach(jointID, outLinkID, inLinkID);
			dJointSetBallAnchor(jointID, jointPos[0], jointPos[1], jointPos[2]);
			motorID = createAMotorBall( joint, outLinkID, inLinkID );
			motorAngles.push_back( motorID );
			break;
		case J_WELD:
			jointID = dJointCreateFixed(world,0) ;
			dJointAttach(jointID, outLinkID ,inLinkID) ;
			dJointSetFixed(jointID) ;
			//danceInterp::OutputMessage("ODE cannot support a weld joint for joint '%s'...", joint->getName());
			break;
		case J_PLANAR:
			danceInterp::OutputMessage("ODE cannot support a planar joint for joint '%s'...", joint->getName());
			break;
		case J_BEARING:
			danceInterp::OutputMessage("ODE cannot support a bearing joint for joint '%s'...", joint->getName());
			break;
		case J_UNIVERSAL:
			jointID = dJointCreateUniversal(world, 0);
			dJointAttach(jointID, outLinkID, inLinkID);
			// get the position of the joint
			dJointSetUniversalAnchor(jointID, jointPos[0], jointPos[1], jointPos[2]);
			// retrieve the axis of rotation
			outLink->getParentJoint()->getOrientation(matrix);
			VecCopy(globalAxis, axes[1]);
			transformPoint_mat(globalAxis, matrix);
			dJointSetUniversalAxis1(jointID, globalAxis[0], globalAxis[1], globalAxis[2]);
			setIdentMat(&matrix[0][0], 4);


			if (inLink != NULL)
			{
				inLink->getParentJoint()->getOrientation(matrix);
				VecCopy(globalAxis, axes[0]);
				transformPoint_mat(globalAxis, matrix);
			}
			else
			{
				VecCopy(globalAxis, axes[0]);
			}
			dJointSetUniversalAxis2(jointID, globalAxis[0], globalAxis[1], globalAxis[2]);

			break;
		case J_BUSHING:
			danceInterp::OutputMessage("ODE cannot support a bushing joint for joint '%s'...", joint->getName());
			break;
		}
		joints.push_back(jointID);
		if (joints.size() > motorAngles.size())
			motorAngles.push_back(NULL);
		dJointFeedback* fb = new dJointFeedback;
		for( int i = 0; i < 3; ++i )
		{
			fb->f1[i] = 0;
			fb->f2[i] = 0;
			fb->t1[i] = 0;
			fb->t2[i] = 0;
		}
		dJointSetFeedback( jointID, fb );  /// TODO MEMORY LEAK UNLESS DELETED WHEN JOINTS ARE DESTROYED
	}


	if (lastPosition != NULL)
		delete [] lastPosition;
	lastPosition = new double[numJoints * 3];

	for (int x = 0; x < numJoints * 3; x++)
	{
		lastPosition[x] = 0.0;
	}

	ao->setState(oldState);


	danceInterp::OutputMessage("Created ODE system with %d bodies, %d joints...", bodies.size(), joints.size());
}

// Sets the state of the simulator from the state of the articulated object.
// Uses the last keyframe in order to calculate velocities.
// The explicit velocities that are set by the articulated object will only 
// be used when there is no previous keyframe.
int ODESim::SetStateFromObjectState(DSystem* system, bool setVelocities, bool useCurrentState)
{
	ArticulatedObject* ao = (ArticulatedObject*) system;
	Link** link = ao->getLinks();
	int numLinks = ao->getNumLinks();

	AnimationSequence* anim = ao->getAnimationSequence();
	KeyFrame* prev = anim->getKeyFrame(dance::AllSimulators->getCurrentTime() - ao->getRecordStep());
	KeyFrame* cur = anim->getKeyFrame(dance::AllSimulators->getCurrentTime());
 
    if (useCurrentState)
    {
        double* params = cur->getParams();
        ao->getState(params);
    }

	Vector rootLinearVel;
	Vector angularVelocities;

	for (int i = 0; i < numLinks; i++)
	{
		

		Joint* joint = link[i]->getParentJoint();
		// set the body position
		int rotationOrder = joint->determineRotationOrder();
		double matrix[4][4];
		setIdentMat(&matrix[0][0], 4);
		link[i]->getWTransMat(matrix);
		dBodySetPosition(bodies[i], matrix[3][0], matrix[3][1], matrix[3][2]);
		dMatrix3 rotation;
		dRSetIdentity(rotation);
		for (int r = 0; r < 3; r++)
			for (int c = 0; c < 3; c++)
				rotation[r * 4 + c] = matrix[c][r];

		dBodySetRotation(bodies[i], rotation);

		double parentRotation[3][3];
		if (link[i]->getParentLink() != NULL)
			link[i]->getParentLink()->getRotation(parentRotation);

		// set the body velocities (linear & angular)

		if (setVelocities)
		{
			if (prev == NULL || prev == cur) // set all non-root joints to zero 
			{ // start all velocities at zero if not explicitly set
				if (link[i]->getParentJoint()->hasVelocity())
				{
					Vector lVel;
					Vector aVel;
					Vector finalLVel;
					Vector finalAVel;
					switch (joint->getJointType())
					{
					case J_FREE:
						zeroVector(lVel);
						zeroVector(aVel);
						zeroVector(finalLVel);
						zeroVector(finalAVel);
						for (int x = 0; x < 3; x++)
							lVel[x] = joint->getInitDState(x);
						for (int x = 3; x < 6; x++)
							aVel[x - 3] = joint->getInitDState(x);
						setOrderedParameters3(joint->determineRotationOrder(), finalLVel, lVel);
						dBodySetLinearVel(bodies[i], finalLVel[0], finalLVel[1], finalLVel[2]);
						Vector finalAVel;
						setOrderedParameters3(joint->determineRotationOrder(), finalAVel, aVel);
						dBodySetAngularVel(bodies[i], finalAVel[0], finalAVel[1], finalAVel[2]);
						break;
					case J_BALL:
						zeroVector(lVel);
						zeroVector(aVel);
						zeroVector(finalLVel);
						zeroVector(finalAVel);
						if (link[i]->getParentLink() == NULL)  
							VecCopy(rootLinearVel, finalLVel);
						else
							dBodySetLinearVel(bodies[i], 0, 0, 0);
							//dBodySetLinearVel(bodies[i], rootLinearVel[0], rootLinearVel[1], rootLinearVel[2]);
std::cout << "LINVEL = " << finalLVel[0] << " " << finalLVel[1] << " " << finalLVel[2] << std::endl;
						for (int x = 0; x < 3; x++)
							aVel[x] = joint->getInitDState(x);
						dBodySetAngularVel(bodies[i], aVel[0], aVel[1], aVel[2]);
						break;
					case J_GIMBAL:
						zeroVector(lVel);
						zeroVector(aVel);
						zeroVector(finalLVel);
						zeroVector(finalAVel);
						if (link[i]->getParentLink() == NULL)
							VecCopy(rootLinearVel, finalLVel);
						else
							dBodySetLinearVel(bodies[i], 0, 0, 0);
	//						dBodySetLinearVel(bodies[i], rootLinearVel[0], rootLinearVel[1], rootLinearVel[2]);
						for (int x = 0; x < 3; x++)
							aVel[x] = joint->getInitDState(x);
						setOrderedParameters3(joint->determineRotationOrder(), finalAVel, aVel);
						dBodySetAngularVel(bodies[i], finalAVel[0], finalAVel[1], finalAVel[2]);
						break;
					case J_UNIVERSAL:
						zeroVector(lVel);
						zeroVector(aVel);
						zeroVector(finalLVel);
						zeroVector(finalAVel);
						if (link[i]->getParentLink() == NULL)
							VecCopy(rootLinearVel, finalLVel);
						else
							dBodySetLinearVel(bodies[i], 0, 0, 0);
	//						dBodySetLinearVel(bodies[i], rootLinearVel[0], rootLinearVel[1], rootLinearVel[2]);
						for (int x = 0; x < 2; x++)
							aVel[x] = joint->getInitDState(x);
						setOrderedParameters2(joint->determineRotationOrder(), finalAVel, aVel);
						dBodySetAngularVel(bodies[i], finalAVel[0], finalAVel[1], finalAVel[2]);
						break;
					case J_PIN:
						zeroVector(lVel);
						zeroVector(aVel);
						zeroVector(finalLVel);
						zeroVector(finalAVel);
						if (link[i]->getParentLink() == NULL)
							VecCopy(rootLinearVel, finalLVel);
						else
							dBodySetLinearVel(bodies[i], 0, 0, 0);
	//						dBodySetLinearVel(bodies[i], rootLinearVel[0], rootLinearVel[1], rootLinearVel[2]);
						aVel[0] = joint->getInitDState(0);
						setOrderedParameters1(joint->determineRotationOrder(), finalAVel, aVel);
						dBodySetAngularVel(bodies[i], finalAVel[0], finalAVel[1], finalAVel[2]);
						break;
					default:
						break;
					}
				}
				else
				{
					int curIndex = this->GetIndex(i, 0);
					dBodySetLinearVel(bodies[i], 0.0, 0.0, 0.0);
					if (link[i]->getParentLink() == NULL)
						setVector(rootLinearVel, 0.0, 0.0, 0.0);
					dBodySetAngularVel(bodies[i], 0.0, 0.0, 0.0);
					switch (joint->getJointType())
					{
					case J_FREE:
						for (int x = 0; x < 7; x++)
							dstate[curIndex + x] = 0.0;
						curIndex += 7;
						break;
					case J_BALL:
						for (int x = 0; x < 4; x++)
							dstate[curIndex + x] = 0.0;
						curIndex += 4;
						break;
					case J_GIMBAL:
						for (int x = 0; x < 3; x++)
							dstate[curIndex + x] = 0.0;
						curIndex += 3;
						break;
					case J_UNIVERSAL:
						for (int x = 0; x < 2; x++)
							dstate[curIndex + x] = 0.0;
						curIndex += 2;
						break;
					case J_PIN:
						dstate[curIndex] = 0.0;
						curIndex += 1;
						break;

					default:
						break;
					}

				}
			}
			else
			{ 
				double timediff = dance::AllSimulators->getCurrentTime() - prev->getTime();
				if (timediff != 0.00)
				{
        			// get the joint type
					double axes[3][3];
					joint->getAxis(axes);
					Vector angularChangeRate;
					Vector linearVel;
					Vector temp;
					int curIndex = 0;
					double oldval = 0, newval = 0;
					VectorObj angles1, angles2;
					Matrix3x3 m1, m2;
					Quaternion q1, q2;
					double matrix[4][4];
					double rotmatrix[3][3];
					link[i]->getTransMat(matrix);
					link[i]->getRotation(rotmatrix);
					switch (joint->getJointType())
					{
					case J_FREE:
						zeroVector(angularChangeRate);
						zeroVector(linearVel);
						zeroVector(temp);

						// set the initial linear velocity
						for (int x = 0; x < 3; x++)
						{
							curIndex = this->GetIndex(i, x);
							oldval = prev->getParam(aoindex[i][x]);
							newval = cur->getParam(aoindex[i][x]);
							linearVel[x] = (newval - oldval) / timediff;
						}

						curIndex = this->GetIndex(i, 0);
						for (int x = 0; x < 3; x++)
							dstate[curIndex + x] = linearVel[x]; // set the dstate
						
						setOrderedParameters3(rotationOrder, temp, linearVel);

						VecCopy(linearVel, temp);
						if (link[i]->getParentLink() != NULL)
							rotatePoint_mat(linearVel, parentRotation);
						Vector linVel;
						setOrderedParameters3(rotationOrder, linVel, linearVel);
						dBodySetLinearVel(bodies[i], linVel[0], linVel[1], linVel[2]);
						VecCopy(rootLinearVel, linearVel);
						
						// angular change rate
						q1.set(cur->getParam(aoindex[i][3]), cur->getParam(aoindex[i][4]), cur->getParam(aoindex[i][4]), cur->getParam(aoindex[i][6]));
						q1.toMatrix(m1);
						m1.matToEuler(rotationOrder, angles1, false);
						q2.set(prev->getParam(aoindex[i][3]), prev->getParam(aoindex[i][4]), prev->getParam(aoindex[i][4]), prev->getParam(aoindex[i][6]));
						q2.toMatrix(m2);
						m2.matToEuler(rotationOrder, angles2, false);

						for (int x = 0; x < 3; x++)
							angularChangeRate[x] = (angles1[x] - angles2[x]) / timediff;
						
						curIndex = this->GetIndex(i, 3);

						setOrderedParameters3(rotationOrder, &dstate[curIndex], angularChangeRate);

						// set the angular velocity in ODE
						// convert angular change rate to angular velocity
						getAngularVelocityFromEulerDerivatives(rotationOrder, angularChangeRate, angles1.data(), angularVelocities);
						switch (rotationOrder)
						{
						case Matrix3x3::XYZ:
							dBodySetAngularVel(bodies[i], angularVelocities[0], angularVelocities[1], angularVelocities[2]);
							break;
						case Matrix3x3::XZY:
							dBodySetAngularVel(bodies[i], angularVelocities[0], angularVelocities[2], angularVelocities[1]);
							break;
						case Matrix3x3::YXZ:
							dBodySetAngularVel(bodies[i], angularVelocities[1], angularVelocities[0], angularVelocities[2]);
							break;
						case Matrix3x3::YZX:
							dBodySetAngularVel(bodies[i], angularVelocities[1], angularVelocities[2], angularVelocities[1]);
							break;
						case Matrix3x3::ZXY:
							dBodySetAngularVel(bodies[i], angularVelocities[2], angularVelocities[0], angularVelocities[1]);
							break;
						case Matrix3x3::ZYX:
							dBodySetAngularVel(bodies[i], angularVelocities[2], angularVelocities[1], angularVelocities[0]);
							break;
						}
						break;
					case J_BALL:
						{
						zeroVector(angularChangeRate);
						Vector angles;
						zeroVector(angles);

						Quaternion currentQuat;
						currentQuat.set(cur->getParam(aoindex[i][0]), cur->getParam(aoindex[i][1]), cur->getParam(aoindex[i][2]), cur->getParam(aoindex[i][3]));
						Quaternion oldQuat;
						oldQuat.set(prev->getParam(aoindex[i][0]), prev->getParam(aoindex[i][1]), prev->getParam(aoindex[i][2]), prev->getParam(aoindex[i][3]));
						Matrix3x3 curMatrix;
						currentQuat.toMatrix(curMatrix);
						Matrix3x3 oldMatrix;
						oldQuat.toMatrix(oldMatrix);
						VectorObj curAngles;
						curMatrix.matToEuler(Matrix3x3::XYZ, curAngles, false);
						VectorObj oldAngles;
						oldMatrix.matToEuler(Matrix3x3::XYZ, oldAngles, false);
						Vector rates;
						VecSubtract(rates, curAngles.data(), oldAngles.data());
						Vector angularVel;
						getAngularVelocityFromEulerDerivatives(Matrix3x3::XYZ, rates, curAngles.data(), angularVel);
						curIndex = this->GetIndex(i, 0);
						for (int x = 0; x < 3; x++)
							dstate[curIndex + x] = angularVel[x];
						if (link[i]->getParentLink() == NULL)
						{
							setVector(rootLinearVel, 0.0, 0.0, 0.0);
							dBodySetLinearVel(bodies[i], rootLinearVel[0], rootLinearVel[1], rootLinearVel[2]);
						}
						else
						{
							rotatePoint_mat(angularVel, parentRotation);
							dBodySetLinearVel(bodies[i], rootLinearVel[0], rootLinearVel[1], rootLinearVel[2]);
						}
						dReal worldAngVel[3];
						dBodyVectorToWorld(bodies[i], angularVel[0], angularVel[1], angularVel[2], worldAngVel);
						dBodySetAngularVel(bodies[i], worldAngVel[0], worldAngVel[1], worldAngVel[2]);
std::cout << "ANGVEL = " << worldAngVel[0] << " " << worldAngVel[1] << " " << worldAngVel[2] << std::endl;
						}
						break;
					case J_GIMBAL:
					case J_UNIVERSAL:
					case J_PIN:
						{
						zeroVector(angularChangeRate);
						zeroVector(temp);
						Vector angles;
						zeroVector(angles);
						for (int x = 0; x < joint->getNumDof(); x++)
						{
							curIndex = this->GetIndex(i, x);
							oldval = prev->getParam(aoindex[i][x]);
							newval = cur->getParam(aoindex[i][x]);
							angles[x] = newval;
							dstate[curIndex] = (newval - oldval) / timediff;
							if (axes[x][0] == 1.0)
								angularChangeRate[0] = dstate[curIndex];
							else if (axes[x][1] == 1.0)
								angularChangeRate[1] = dstate[curIndex];
							else if (axes[x][2] == 1.0)
								angularChangeRate[2] = dstate[curIndex];
						}

						// convert angular change rate to angular velocity
						Vector angularVelocities;
						if (joint->getJointType() == J_BALL)
						{
							curIndex = this->GetIndex(i, 0);
							for (int x = 0; x < 3; x++)
								angularVelocities[x] = dstate[curIndex + x];
						}
						else
						{
							getAngularVelocityFromEulerDerivatives(rotationOrder, angularChangeRate, angles, angularVelocities);
						}

						if (link[i]->getParentLink() == NULL)
						{
							setVector(rootLinearVel, 0.0, 0.0, 0.0);
							dBodySetLinearVel(bodies[i], rootLinearVel[0], rootLinearVel[1], rootLinearVel[2]);
						}
						else
						{
							rotatePoint_mat(angularVelocities, parentRotation);
							dBodySetLinearVel(bodies[i], rootLinearVel[0], rootLinearVel[1], rootLinearVel[2]);
						}
						dReal worldAngVel[3];
						dBodyVectorToWorld(bodies[i], angularVelocities[0], angularVelocities[1], angularVelocities[2], worldAngVel);
						dBodySetAngularVel(bodies[i], worldAngVel[0], worldAngVel[1], worldAngVel[2]);
						}
						break;					

					case J_WELD:
						// no joint, no action
						break;
					case J_PLANAR:
						break;
					default:
						break;
					}
				}
			}
		}
	}

	if (setVelocities)
		calculateState( true );

	return 0;
}

int ODESim::SetObjectStateFromState(DSystem* system, bool setVelocities)
{
	/// Never called for ODE I think (Petros: 12/15/06)	



	if( this->ao == NULL )
	{
		danceInterp::OutputMessage("No articulated object has been attached to this simulator...");
		return 0;
	}

    Vector orig	= {0.0,0.0,0.0}	;

	double x_axis[]	= {1.0,0.0,0.0};
	double y_axis[]	= {0.0,1.0,0.0};
	double z_axis[]	= {0.0,0.0,1.0};

	Link** links = this->ao->getLinks();
	int numLinks = this->ao->getNumLinks();
    for(int i = 0; i < numLinks; i++ )
    {
		// For each link, find out the position	of the origin and axes
		// of the link frame in	world space.
		CoordSystem cs;
		this->GetPosition(links[i]->getNumber(), orig, cs.origin)	;
		this->GetOrientation(links[i]->getNumber(), x_axis, -1, cs.x) ;
		this->GetOrientation(links[i]->getNumber(), y_axis, -1, cs.y) ;
		this->GetOrientation(links[i]->getNumber(), z_axis, -1, cs.z) ;
		links[i]->setTransMat(cs);
    }

 	return 0;
}

int ODESim::getBodyIndexFromSystem(Link* link)
{
	if (ao == NULL)
	{
		danceInterp::OutputMessage("No articulated object has been attached to this simulator...");
		return -1;
	}

	// determine the system -> body mapping
	Link** links = ao->getLinks();
	int numLinks = ao->getNumLinks();
	int l = 0;
	for (l = l; l < numLinks; l++)
	{
		if (link == links[l])
			break;
	}

	return l;
}

int ODESim::getStateSize()
{
	if (this->ao != NULL)
		return ao->getStateSize();
	else
		return 0;
}

int ODESim::GetIndex(int group, int subgroup)
{
	return aoindex[group][subgroup];
}

void ODESim::GeneralizedForce(int group, int subgroup, double magnitude)
{
	// apply a torque to the outbound body with the (subgroup)th DOF
	// with the specified magnitude. Also apply an equal and opposite
	// torque to the inbound body. The direction of the torque (to the
	// outbound body) is determined by the axis of the DOF.
	if (this->ao == NULL)
	{
		danceInterp::OutputMessage("No articulated object present, cannot apply torques...");
		return;
	}

	Joint* joint = this->ao->getJoint(group);
	// apply the torque to the outbound body
	double axes[3][3];
	joint->getAxis(axes);

	Link* outbound = joint->getOutboardLink();
	Link* inbound = joint->getInboardLink();

	int outId = this->getBodyIndexFromSystem(outbound);
	int inId = -1;
	if (inbound)
		inId = this->getBodyIndexFromSystem(inbound);

	// apply the torque to the outboard body, and the opposite torque to the inboard body
	dReal worldAxis[3];
	dBodyVectorToWorld(bodies[outId], axes[subgroup][0], axes[subgroup][1], axes[subgroup][2], worldAxis);

	Vector torque;
	setVector(torque, worldAxis[0] * magnitude, worldAxis[1] * magnitude, worldAxis[2] * magnitude);
	dBodyAddTorque(bodies[outId], torque[0], torque[1], torque[2]);
	if (inbound)
	{
		dBodyAddTorque(bodies[inId], -torque[0], -torque[1], -torque[2]);
	}
	accumulateTorque( group /*joint index*/, torque[0], torque[1], torque[2] );

	bodiesWithForce[outId] = 1;
	if (inbound)
	{
		bodiesWithForce[inId] = 1;
}
}

void ODESim::initializeStateMapping()
{
	// initialize the state index mapping
	for (int i = 0; i < MAX_LINKS; i++)
		for (int j = 0; j < 6; j++)
			aoindex[i][j] = -1;
}

void ODESim::setIndexMapping()
{
	if (this->ao == NULL)
	{
		danceInterp::OutputMessage("No articulated object has been attached to this simulator yet, cannot perform state indexing...");
		return;
	}

	initializeStateMapping();
	Joint** joints = this->ao->getJoints();
	int numJoints = this->ao->getNumJoints();
	int curIndex = 0;
	for (int j = 0; j < numJoints; j++)
	{
		int numDOF = joints[j]->getStateSize();
		for (int i = 0; i < numDOF; i++)
		{
			aoindex[j][i] = curIndex;
			curIndex++;
		}
	}
}

void ODESim::saveSystemState(double time)
{
	if (this->getNumSystems() == 0)
		return;

	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0); 

	calculateState(true);

	ao->setState(state);
	ao->setDState( dstate );
//	for (int x = 0; x < ao->getStateSize(); x++)
//		danceInterp::OutputMessage("%d] %6.4f", x, state[x]);
}

void ODESim::calculateState(bool calculateVelocities)
{
	if (this->getNumSystems() == 0)
		return;

	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0); 

	int numJoints = this->ao->getNumJoints();
	Joint** aojoints = this->ao->getJoints();
	int curIndex = 0;

	// loop through the links and generate the inverse transformation matrices
	int numLinks = ao->getNumLinks();

	for (int l = 0; l < numLinks; l++)
	{
		const dReal *rot = dBodyGetRotation(bodies[l]) ; // returns a 4x3 matrix
		// create the world body matrix
		for (int c = 0; c < 3; c++)
			for (int r = 0; r < 3; r++)
				holdMatrix[l][r][c] = rot[r * 4 + c];
	}

	Matrix3x3 mat;
	VectorObj vec;
	VectorObj vec2;
	Vector tempv;

	double localMatrix[4][4];
	double invMatrix[4][4];
	dReal* bodyQuat = NULL;

	Link* parentLink = NULL;
	int rotationOrder = -1;
	VectorObj vec3;
	const dReal* linearVel;
	const dReal* angularVel;

	for (int j = 0; j < numJoints; j++)
	{
//		const dReal* saveposition = dBodyGetPosition(bodies[j]);
		parentLink = aojoints[j]->getOutboardLink()->getParentLink();
		int jointType = aojoints[j]->getJointType();
		if (jointType == J_FREE)
		{	
			// for free joints in ODE, the COM is the joint position
			const dReal* bodyposition = dBodyGetPosition(bodies[j]);

			Vector inboardToJoint, finalPos;
			aojoints[j]->getInbToJoint(inboardToJoint);
			for (int x = 0; x < 3; x++)
				finalPos[x] = bodyposition[x] - inboardToJoint[x];

			rotationOrder = aojoints[j]->determineRotationOrder();
			setOrderedParameters3(rotationOrder, &state[curIndex], &finalPos[0]);

			if (calculateVelocities)
			{
				// get the linear velocity
				linearVel = dBodyGetLinearVel(bodies[j]);
				setOrderedParameters3(rotationOrder, &dstate[curIndex], (double*) linearVel);
			}
			curIndex += 3;

			bodyQuat = (dReal*) dBodyGetQuaternion(bodies[j]);
			state[curIndex] = bodyQuat[1];
			state[curIndex + 1] = bodyQuat[2];
			state[curIndex + 2] = bodyQuat[3];
			state[curIndex + 3] = bodyQuat[0];

			if (calculateVelocities)
			{
				angularVel = dBodyGetAngularVel(bodies[j]);
				setOrderedParameters3(rotationOrder, &dstate[curIndex], (double*) angularVel);
				dstate[curIndex + 3] = 0.0; // what do we do with this value??
			}
			curIndex += 4;
		}
		else if (jointType == J_BALL)
		{
				Quaternion qparent, qparentInv, qcur ;
				const dReal *qparentODE, *qcurODE ;

				qcurODE = dBodyGetQuaternion(bodies[j]) ;
				qcur.set(qcurODE[1],qcurODE[2],qcurODE[3],qcurODE[0]) ;
				qcur.normalize() ;

				Quaternion qcurRel ;
				// now get the inverse quaternion of the parent and put qcur in	relative
				if (aojoints[j]->getInboardLink() != NULL)
				{
						qparentODE = dBodyGetQuaternion(bodies[aojoints[j]->getInboardLink()->getParentJoint()->getJointNum()]) ;
		        		qparentInv.set(qparentODE[1],qparentODE[2],qparentODE[3],qparentODE[0]) ;
						qparentInv.normalize() ;
		        		qparent.set(qparentODE[1],qparentODE[2],qparentODE[3],qparentODE[0]) ;
						qparentInv.invert() ;
						qcurRel.multiply(&qparentInv, &qcur) ;
						qcurRel.normalize() ;
				}
				else
				{
						qcurRel.copy(&qcur) ;
				}
		                
				for (int x = 0; x < 4; x++)
						state[curIndex + x] = qcurRel.data()[x];

/*		else if (jointType == J_BALL)
		{
			if (aojoints[j]->getInboardLink() != NULL)
			{
				invSmart4(invMatrix, holdMatrix[aojoints[j]->getInboardLink()->getParentJoint()->getJointNum()]);
				//multArray(&localMatrix[0][0], &invMatrix[0][0], &holdMatrix[j][0][0], 4, 4, 4);
				multArray4x4(localMatrix, invMatrix, holdMatrix[j]);
			}
			else
			{
				setIdentMat(&invMatrix[0][0], 4);
				copyMatrix44(localMatrix, holdMatrix[j]);
			}
			rotationOrder = aojoints[j]->determineRotationOrder();
			mat.from4x4(localMatrix);
			Quaternion q;
			q.fromMatrix(mat);
			q.normalize();
			for (int x = 0; x < 4; x++)
				state[curIndex + x] = q.data()[x];
*/
			if (calculateVelocities)
			{
				// get the angular velocity of the outboard body		
				const dReal* jointAngularVelWorld = dBodyGetAngularVel(bodies[j]);

				// convert the angular velocity to local coordinates
				dReal jointAngularVelLocal[3];
				dBodyVectorFromWorld(bodies[j], jointAngularVelWorld[0], jointAngularVelWorld[1], jointAngularVelWorld[2], jointAngularVelLocal);

				// get the angular velocity of the inboard body
				dReal relAngVelLocal[3];
dReal worldVelParent[3];
				if (parentLink != NULL)
				{
					int parentNum = parentLink->getParentJoint()->getJointNum();
					const dReal* parentJointAngularVelWorld = dBodyGetAngularVel(bodies[parentNum]);
for (int x = 0; x < 3; x++)
					{
	worldVelParent[x] = parentJointAngularVelWorld[x];
					}
					dReal parentAngularVelLocal[3];
					dBodyVectorFromWorld(bodies[j], parentJointAngularVelWorld[0], parentJointAngularVelWorld[1], parentJointAngularVelWorld[2], parentAngularVelLocal);
					// determine the relative angular velocity of body in local coordinates
					for (int x = 0; x < 3; x++) 
					{
						relAngVelLocal[x] = jointAngularVelLocal[x] - parentAngularVelLocal[x];
					}
				}
				else
				{
					for (int x = 0; x < 3; x++)
					{
						relAngVelLocal[x] = jointAngularVelLocal[x];
						worldVelParent[x] = 0.0;
					}
				}
				for (int x = 0; x < 3; x++)
				{
					dstate[curIndex + x] = relAngVelLocal[x];
				}
				//VecCopy(&dstate[curIndex], relAngVelLocal);
				//danceInterp::OutputMessage("%d] %8.4f %8.4f %8.4f", j, relAngVelLocal[0], relAngVelLocal[1], relAngVelLocal[2]);				

				//Vector worldRelVel;
				//VecSubtract(worldRelVel, jointAngularVelWorld, worldVelParent);
				//VecCopy(&dstate[curIndex], worldRelVel);

			}
			
			curIndex += 4;
		}
		else if (jointType == J_GIMBAL)
		{
			if (aojoints[j]->getInboardLink() != NULL)
			{
				invSmart4(invMatrix, holdMatrix[aojoints[j]->getInboardLink()->getParentJoint()->getJointNum()]);
				//multArray(&localMatrix[0][0], &invMatrix[0][0], &holdMatrix[j][0][0], 4, 4, 4);
				multArray4x4(localMatrix, invMatrix, holdMatrix[j]);
			}
			else
			{
				setIdentMat(&invMatrix[0][0], 4);
				copyMatrix44(localMatrix, holdMatrix[j]);
			}
			rotationOrder = aojoints[j]->determineRotationOrder();
			mat.from4x4(localMatrix);
			mat.matToEuler(rotationOrder, vec2, false);
			for (int x =0; x < 3; x++)
				tempv[x] = vec2[x];
			
			// put vector in proper order
			setOrderedParameters3(rotationOrder, &state[curIndex], tempv);
				
			// remember the last position to avoid sudden flips 
			// when the new rotation is recalculated
			lastPosition[j * 3] = state[curIndex];
			lastPosition[j * 3 + 1] = state[curIndex + 1];
			lastPosition[j * 3 + 2] = state[curIndex + 2];

			if (calculateVelocities)
			{
				// get the angular velocity of the outboard body		
				const dReal* jointAngularVelWorld = dBodyGetAngularVel(bodies[j]);

				// convert the angular velocity to local coordinates
				dReal jointAngularVelLocal[3];
				dBodyVectorFromWorld(bodies[j], jointAngularVelWorld[0], jointAngularVelWorld[1], jointAngularVelWorld[2], jointAngularVelLocal);

				// get the angular velocity of the inboard body
				dReal relAngVelLocal[3];
				if (parentLink != NULL)
				{
					int parentNum = parentLink->getParentJoint()->getJointNum();
					const dReal* parentJointAngularVelWorld = dBodyGetAngularVel(bodies[parentNum]);
					dReal parentAngularVelLocal[3];
					dBodyVectorFromWorld(bodies[j], parentJointAngularVelWorld[0], parentJointAngularVelWorld[1], parentJointAngularVelWorld[2], parentAngularVelLocal);


					// determine the relative angular velocity of body in local coordinates
					for (int x = 0; x < 3; x++) 
						relAngVelLocal[x] = jointAngularVelLocal[x] - parentAngularVelLocal[x];

				}
				else
				{
					for (int x = 0; x < 3; x++)
						relAngVelLocal[x] = jointAngularVelLocal[x];
				}

				Vector finalAngVel;
				double temp[3];
				for (int x = 0; x < 3; x++)
					temp[x] = relAngVelLocal[x];
				getEulerDerivativesFromAngularVelocity(rotationOrder, temp, tempv, finalAngVel); 
				setOrderedParameters3(rotationOrder, &dstate[curIndex], finalAngVel);
			}

			curIndex += 3;
		}
		else if (jointType == J_UNIVERSAL)
		{
			if (aojoints[j]->getInboardLink() != NULL)
			{
				invSmart4(invMatrix, holdMatrix[aojoints[j]->getInboardLink()->getParentJoint()->getJointNum()]);
				//multArray(&localMatrix[0][0], &invMatrix[0][0], &holdMatrix[j][0][0], 4, 4, 4);
				multArray4x4(localMatrix, invMatrix, holdMatrix[j]);
			}
			else
			{
				setIdentMat(&invMatrix[0][0], 4);
				copyMatrix44(localMatrix, holdMatrix[j]);
			}
//			rotationOrder = aojoints[j]->determineRotationOrder();
//			mat.from4x4(localMatrix);
//			mat.matToEuler2D(rotationOrder, vec2, false);

			// put vector in proper order
			// already in proper order from matrix2D?
//			vec3[0] = vec2[0];
//			vec3[1] = vec2[1];

			vec3[1] = dJointGetUniversalAngle1(joints[j]);
			vec3[0] = dJointGetUniversalAngle2(joints[j]);

			// remember the last position to avoid sudden flips 
			// when the new rotation is recalculated

			state[curIndex] = vec3[0];
			state[curIndex + 1] = vec3[1];

			if (calculateVelocities)
			{
				// get the angular velocity of the outboard body		
				const dReal* jointAngularVelWorld = dBodyGetAngularVel(bodies[j]);

				// convert the angular velocity to local coordinates
				dReal jointAngularVelLocal[3];
				dBodyVectorFromWorld(bodies[j], jointAngularVelWorld[0], jointAngularVelWorld[1], jointAngularVelWorld[2], jointAngularVelLocal);

				// get the angular velocity of the inboard body
				dReal relAngVelLocal[3];
				if (parentLink != NULL)
				{
					int parentNum = parentLink->getParentJoint()->getJointNum();
					const dReal* parentJointAngularVelWorld = dBodyGetAngularVel(bodies[parentNum]);
					dReal parentAngularVelLocal[3];
					dBodyVectorFromWorld(bodies[j], parentJointAngularVelWorld[0], parentJointAngularVelWorld[1], parentJointAngularVelWorld[2], parentAngularVelLocal);

					// determine the relative angular velocity of body in local coordinates
					for (int x = 0; x < 3; x++) 
						relAngVelLocal[x] = jointAngularVelLocal[x] - parentAngularVelLocal[x];

				}
				else
				{
					for (int x = 0; x < 3; x++)
						relAngVelLocal[x] = jointAngularVelLocal[x];
				}

				Vector finalAngVel;
				getEulerDerivativesFromAngularVelocity(rotationOrder, (double*) relAngVelLocal, tempv, finalAngVel); 

//				double angle1 = dJointGetHinge2Angle1Rate(joints[j]);
//				double angle2 = dJointGetHinge2Angle2Rate(joints[j]);
				double angle1 = dJointGetUniversalAngle1Rate(joints[j]);
				double angle2 = dJointGetUniversalAngle2Rate(joints[j]);

//				danceInterp::OutputMessage("ANG VEL JOINT %d (%f %f %f) ANG RATE (%f %f) ODE (%f %f)", j, relAngVelLocal[0], relAngVelLocal[1], relAngVelLocal[2], finalAngVel[1], finalAngVel[2], angle1, angle2);

				vec3[1] = angle1;
				vec3[0] = angle2;

/*
				// put angular velocity in proper order
				switch (rotationOrder)
				{
				case Matrix3x3::XY:
					vec3[0] = finalAngVel[0];
					vec3[1] = finalAngVel[1];
					break;
				case Matrix3x3::XZ:
					vec3[0] = finalAngVel[0];
					vec3[1] = finalAngVel[2];
					break;
				case Matrix3x3::YX:
					vec3[0] = finalAngVel[1];
					vec3[1] = finalAngVel[0];
					break;
				case Matrix3x3::YZ:
					vec3[0] = finalAngVel[1];
					vec3[1] = finalAngVel[2];
					break;
				case Matrix3x3::ZX:
					vec3[0] = finalAngVel[2];
					vec3[1] = finalAngVel[0];
					break;
				case Matrix3x3::ZY:
					vec3[0] = finalAngVel[2];
					vec3[1] = finalAngVel[1];
					break;
				}
*/
				dstate[curIndex] = vec3[0];
				dstate[curIndex + 1] = vec3[1];

			}
			

			curIndex += 2;
		}
		else if (jointType == J_PIN)
		{
			if (aojoints[j]->getInboardLink() != NULL)
			{
				invSmart4(invMatrix, holdMatrix[aojoints[j]->getInboardLink()->getParentJoint()->getJointNum()]);
				//multArray(&localMatrix[0][0], &invMatrix[0][0], &holdMatrix[j][0][0], 4, 4, 4);
				multArray4x4(localMatrix, invMatrix, holdMatrix[j]);
			}
			else
			{
				setIdentMat(&invMatrix[0][0], 4);
				copyMatrix44(localMatrix, holdMatrix[j]);
			}
			rotationOrder = aojoints[j]->determineRotationOrder();
			mat.from4x4(localMatrix);
			vec3[0] = mat.matToEuler1D(rotationOrder);
	
			state[curIndex] = vec3[0];

			// remember the last position to avoid sudden flips 
			// when the new rotation is recalculated
			lastPosition[j * 3] = vec3[0];

			if (calculateVelocities)
			{
				// get the angular velocity of the outboard body		
				const dReal* jointAngularVelWorld = dBodyGetAngularVel(bodies[j]);

				// convert the angular velocity to local coordinates
				dReal jointAngularVelLocal[] = {0.0, 0.0, 0.0};
				dBodyVectorFromWorld(bodies[j], jointAngularVelWorld[0], jointAngularVelWorld[1], jointAngularVelWorld[2], jointAngularVelLocal);

				// get the angular velocity of the inboard body
				Vector relAngVelLocal;
				if (parentLink != NULL)
				{
					int parentNum = parentLink->getParentJoint()->getJointNum();
					const dReal* parentJointAngularVelWorld = dBodyGetAngularVel(bodies[parentNum]);
					dReal parentAngularVelLocal[3];
					dBodyVectorFromWorld(bodies[j], parentJointAngularVelWorld[0], parentJointAngularVelWorld[1], parentJointAngularVelWorld[2], parentAngularVelLocal);

					// determine the relative angular velocity of body in local coordinates
					for (int x = 0; x < 3; x++) 
						relAngVelLocal[x] = jointAngularVelLocal[x] - parentAngularVelLocal[x];

				}
				else
				{
					for (int x = 0; x < 3; x++)
						relAngVelLocal[x] = jointAngularVelLocal[x];
				}


				// put angular velocity in proper order
				switch (rotationOrder)
				{
				case Matrix3x3::X:
					vec3[0] = relAngVelLocal[0];
					break;
				case Matrix3x3::Y:
					vec3[0] = relAngVelLocal[1];
					break;
				case Matrix3x3::Z:
					vec3[0] = relAngVelLocal[2];
					break;
				}


				Vector finalAngVel;
                                tempv[0] = state[curIndex];
                                tempv[1] = 0;
                                tempv[2] = 0;
				getEulerDerivativesFromAngularVelocity(rotationOrder, relAngVelLocal, tempv, finalAngVel); 

				dstate[curIndex] = vec3[0];
			}	

			curIndex += 1;
		}
		else if (jointType == J_SLIDER)
		{
		}
		else if (jointType == J_WELD)
		{
		}
		else
		{
			danceInterp::OutputMessage("Unhandled joint type in ODE Sim: %d", jointType);
		}

	}


	//for (int x = 0; x < ao->getStateSize(); x++)
	//{
	//	danceInterp::OutputMessage("%d] %8.4f (%8.4f)", x, state[x], dstate[x]);
	//	// make sure values are within a reasonable range
	//	if (state[x] > 2 * M_PI || state[x] < -2 * M_PI)
	//	{
	//		danceInterp::OutputMessage("VALUES AT INDEX %d out of range: (%8.4f)", x, state[x]);
	//	}
	//}
}


void ODESim::resetPhysicalProperties(DSystem* sys)
{
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(sys);
	int numLinks = ao->getNumLinks();
	for (int l = 0; l < numLinks; l++)
	{
		Link* link = ao->getLink(l);
		dBodyID body = bodies[l];

		// set the mass of the body
		dMass mass;

		// set the center of mass position relative to the body
		Vector com;
		link->getCenterMass(com);
		mass.c[0] = com[0]; mass.c[1] = com[1]; mass.c[2] = com[2];
		mass.mass = link->getMass();


		// set the inertia tensor
		double inertia[3][3];
		link->getInerTensor(inertia);

		dMassSetParameters(&mass, link->getMass(), 
							com[0], com[1], com[2],
							inertia[0][0], inertia[1][1], inertia[2][2],
							inertia[0][1], inertia[0][2], inertia[1][2]
							);
		dBodySetMass(body, &mass);
	}
}

void ODESim::setUseJointLimits(bool val)
{
	m_isUseJointLimits = val;
	applyJointLimits();
}

bool ODESim::isUseJointLimits()
{
	return m_isUseJointLimits;
}

void ODESim::applyJointLimits()
{
	// ODE has built-in support for joint angle limits, let's use it.
	if (ao == NULL)
		return;

	for (int j = 0; j < ao->getNumJoints(); j++)
	{
		Joint* joint = ao->getJoint(j);
		double axes[3][3];
		joint->getAxis(axes);
		double low, high;
		switch (joint->getJointType())
		{
		case J_FREE:
			break;
		case J_GIMBAL:
		case J_BALL:
			if (!this->isUseJointLimits())
			{ // turn off joint limits
				dJointSetAMotorParam(motorAngles[j], dParamLoStop, -dInfinity);
				dJointSetAMotorParam(motorAngles[j], dParamHiStop, dInfinity);
				dJointSetAMotorParam(motorAngles[j], dParamLoStop, -dInfinity);
				dJointSetAMotorParam(motorAngles[j], dParamHiStop, dInfinity);

				dJointSetAMotorParam(motorAngles[j], dParamLoStop2, -dInfinity);
				dJointSetAMotorParam(motorAngles[j], dParamHiStop2, dInfinity);
				dJointSetAMotorParam(motorAngles[j], dParamLoStop2, -dInfinity);
				dJointSetAMotorParam(motorAngles[j], dParamHiStop2, dInfinity);

				dJointSetAMotorParam(motorAngles[j], dParamLoStop3, -dInfinity);
				dJointSetAMotorParam(motorAngles[j], dParamHiStop3, dInfinity);
				dJointSetAMotorParam(motorAngles[j], dParamLoStop3, -dInfinity);
				dJointSetAMotorParam(motorAngles[j], dParamHiStop3, dInfinity);    
			}
			else
			{ // turn on joint limits
				joint->getLimits(0, &low, &high);
				dJointSetAMotorParam(motorAngles[j], dParamLoStop, low * M_PI / 180.0);
				dJointSetAMotorParam(motorAngles[j], dParamHiStop, high * M_PI / 180.0);
				dJointSetAMotorParam(motorAngles[j], dParamLoStop, low * M_PI / 180.0);
				dJointSetAMotorParam(motorAngles[j], dParamHiStop, high * M_PI / 180.0);

				joint->getLimits(1, &low, &high);
				dJointSetAMotorParam(motorAngles[j], dParamLoStop2, low * M_PI / 180.0);
				dJointSetAMotorParam(motorAngles[j], dParamHiStop2, high * M_PI / 180.0);
				dJointSetAMotorParam(motorAngles[j], dParamLoStop2, low * M_PI / 180.0);
				dJointSetAMotorParam(motorAngles[j], dParamHiStop2, high * M_PI / 180.0);

				joint->getLimits(2, &low, &high);
				dJointSetAMotorParam(motorAngles[j], dParamLoStop3, low * M_PI / 180.0);
				dJointSetAMotorParam(motorAngles[j], dParamHiStop3, high * M_PI / 180.0);
				dJointSetAMotorParam(motorAngles[j], dParamLoStop3, low * M_PI / 180.0);
				dJointSetAMotorParam(motorAngles[j], dParamHiStop3, high * M_PI / 180.0);
			}
       

			break;
		case J_UNIVERSAL:
			if (!this->isUseJointLimits())
			{ // turn off joint limits
				dJointSetUniversalParam(joints[j], dParamLoStop, -dInfinity);
				dJointSetUniversalParam(joints[j], dParamHiStop, dInfinity);

				dJointSetUniversalParam(joints[j], dParamLoStop2, -dInfinity);
				dJointSetUniversalParam(joints[j], dParamHiStop2, dInfinity);
			}
			else
			{ // turn on joint limits
				// Order of axis is opposite the order of axis in DANCE.
				joint->getLimits(0, &low, &high);
				dJointSetUniversalParam(joints[j], dParamLoStop2, low * M_PI / 180.0);
				dJointSetUniversalParam(joints[j], dParamHiStop2, high * M_PI / 180.0);

				joint->getLimits(1, &low, &high);
				dJointSetUniversalParam(joints[j], dParamLoStop, low * M_PI / 180.0);
				dJointSetUniversalParam(joints[j], dParamHiStop, high * M_PI / 180.0);
			}
   
            break;
		case J_PIN:
			if (!this->isUseJointLimits())
			{ // turn off joint limits
				dJointSetHingeParam(joints[j], dParamLoStop, -dInfinity);
				dJointSetHingeParam(joints[j], dParamHiStop, dInfinity);
				dJointSetHingeParam(joints[j], dParamLoStop, -dInfinity);
				dJointSetHingeParam(joints[j], dParamHiStop, dInfinity);
			}
			else
			{ 
				// turn on joint limits
				joint->getLimits(0, &low, &high);
				dJointSetHingeParam(joints[j], dParamLoStop, low * M_PI / 180.0);
				dJointSetHingeParam(joints[j], dParamHiStop, high * M_PI / 180.0);
				dJointSetHingeParam(joints[j], dParamLoStop, low * M_PI / 180.0);
				dJointSetHingeParam(joints[j], dParamHiStop, high * M_PI / 180.0);

			}
            break;
		case J_SLIDER:
			break;
		case J_WELD:
			break;
		}
	}

}

fltk::Widget* ODESim::getInterface()
{
	if (m_odeWindow == NULL)
	{
		m_odeWindow = new ODESimWindow(this, 0, 0, 350, 400, this->getName());
	}

	return m_odeWindow;
}

void ODESim::setShowBodyPositions(bool val)
{
	m_isShowBodyPositions = val;
}

bool ODESim::isShowBodyPositions()
{
	return m_isShowBodyPositions;
}

void ODESim::setShowAttachments(bool val)
{
	m_isShowAttachments = val;
}

bool ODESim::isShowAttachments()
{
	return m_isShowAttachments;
}

void ODESim::setUseStepFast(bool val)
{
	m_useStepFast = val;
	if (this->m_odeWindow != NULL)
		this->m_odeWindow->updateGUI();
}

bool ODESim::isUseStepFast()
{
	return m_useStepFast;
}

void ODESim::setStepFastIterations(int num)
{
	m_stepFastIterations = num;
	if (world != NULL)
		dWorldSetQuickStepNumIterations (world, num);
	if (this->m_odeWindow != NULL)
		this->m_odeWindow->updateGUI();
}

int ODESim::getStepFastIterations()
{
	return m_stepFastIterations;
}

void ODESim::setWorldERP(double val)
{
	m_worldERP = val;

	if (world != NULL)
		dWorldSetERP(world, val);
}

double ODESim::getWorldERP()
{
	return m_worldERP;
}

void ODESim::setWorldCFM(double val)
{
	m_worldCFM = val;

	if (world != NULL)
		dWorldSetCFM(world, val);
}

double ODESim::getWorldCFM()
{
	return m_worldCFM;
}

void ODESim::setContactMaxCorrectingVel( double arg )
{
	m_contactMaxCorrectingVel = arg;
}
double ODESim::getContactMaxCorrectingVel( void )
{
	return m_contactMaxCorrectingVel;
}

void ODESim::save(int mode, std::ofstream& file)
{
	char buff[512];

	if (mode == 0)
	{
		file << "dance.instance(\"ODESim\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
		// step or step fast?
		if (this->isUseStepFast())
		{
			sprintf(buff, "\"use_step_fast\", \"true\"");
			pythonSave(file, buff);
			int iterations = this->getStepFastIterations();
			sprintf(buff, "\"step_fast_iterations\", %d", iterations);
			pythonSave(file, buff);
		}
		else
		{
			sprintf(buff, "\"use_step_fast\", \"false\"");
			pythonSave(file, buff);
		}

		// show body positions?
		if (this->isShowBodyPositions())
		{
			sprintf(buff, "\"show_body_positions\", \"true\"");
		}
		else
		{
			sprintf(buff, "\"show_body_positions\", \"false\"");
		}
		pythonSave(file, buff);

		// world ERP
		double erp = this->getWorldERP();
		sprintf(buff, "\"world_erp\", %g", erp);
		pythonSave(file, buff);

		// world CFM
		double cfm = this->getWorldCFM();
		sprintf(buff, "\"world_cfm\", %g", cfm);
		pythonSave(file, buff);

		// Contact Max Correcting Velocity
		double maxVel = getContactMaxCorrectingVel();
                if (maxVel > 9999999)
                        maxVel = 9999999;
		sprintf(buff, "\"max_contact_vel\", %g", maxVel);
		pythonSave(file, buff);

		// joint limits?
		if (this->isUseJointLimits())
			sprintf(buff, "\"use_joint_limits\", \"true\"");
		else
			sprintf(buff, "\"use_joint_limits\", \"false\"");
		pythonSave(file, buff);
	}

	DSimulator::save(mode, file);
}

int ODESim::getNumPluginDependents()
{
	return 1;
}

const char* ODESim::getPluginDependent(int num)
{
	if (num == 0)
		return "ArticulatedObject";
	else
		return NULL;
}

void ODESim::getJointMatrix(Joint* joint, double matrix[4][4])
{
	int order = joint->determineRotationOrder();

	int jointType = joint->getJointType();

	setIdentMat(&matrix[0][0], 4);
	Matrix3x3 rot;
	switch (jointType)
	{
	case J_FREE:
		{
		Quaternion* q = joint->getQuaternion();
		q->toMatrix(rot);
		}
		break;
	case J_BALL:
		{
			Quaternion q(joint->getState(0), joint->getState(1), joint->getState(2), joint->getState(3));
			q.toMatrix(rot);
		}
		break;
	case J_GIMBAL:
		{
		Matrix3x3 rotX;
		Matrix3x3 rotY;
		Matrix3x3 rotZ;
		switch (order)
		{
		case Matrix3x3::XYZ:
			rotX.setRotateMatrix(Matrix3x3::X, joint->getState(0));
			rotY.setRotateMatrix(Matrix3x3::Y, joint->getState(1));
			rotZ.setRotateMatrix(Matrix3x3::Z, joint->getState(2));
			rot = rotX * rotY * rotZ;
			break;
		case Matrix3x3::XZY:
			rotX.setRotateMatrix(Matrix3x3::X, joint->getState(0));
			rotZ.setRotateMatrix(Matrix3x3::Z, joint->getState(1));
			rotY.setRotateMatrix(Matrix3x3::Y, joint->getState(2));
			rot = rotX * rotZ * rotY;
			break;
		case Matrix3x3::YXZ:
			rotY.setRotateMatrix(Matrix3x3::Y, joint->getState(0));
			rotX.setRotateMatrix(Matrix3x3::X, joint->getState(1));
			rotZ.setRotateMatrix(Matrix3x3::Z, joint->getState(2));
			rot = rotY * rotX * rotZ;
			break;
		case Matrix3x3::YZX:
			rotY.setRotateMatrix(Matrix3x3::Y, joint->getState(0));
			rotZ.setRotateMatrix(Matrix3x3::Z, joint->getState(1));
			rotX.setRotateMatrix(Matrix3x3::X, joint->getState(2));
			rot = rotY * rotZ * rotX;
			break;
		case Matrix3x3::ZXY:
			rotZ.setRotateMatrix(Matrix3x3::Z, joint->getState(0));
			rotX.setRotateMatrix(Matrix3x3::X, joint->getState(1));
			rotY.setRotateMatrix(Matrix3x3::Y, joint->getState(2));
			rot = rotZ * rotX * rotY;
			break;
		case Matrix3x3::ZYX:
			rotZ.setRotateMatrix(Matrix3x3::Z, joint->getState(0));
			rotY.setRotateMatrix(Matrix3x3::Y, joint->getState(1));
			rotX.setRotateMatrix(Matrix3x3::X, joint->getState(2));
			rot = rotZ * rotY * rotX;
			break;
		}
		}
		break;
	case J_UNIVERSAL:
		{
		Matrix3x3 rotX;
		Matrix3x3 rotY;
		Matrix3x3 rotZ;
		switch (order)
		{
		case Matrix3x3::XY:
			rotX.setRotateMatrix(Matrix3x3::X, joint->getState(0));
			rotY.setRotateMatrix(Matrix3x3::Y, joint->getState(1));
			rot = rotX * rotY;
			break;
		case Matrix3x3::XZ:
			rotX.setRotateMatrix(Matrix3x3::X, joint->getState(0));
			rotZ.setRotateMatrix(Matrix3x3::Z, joint->getState(1));
			rot = rotX * rotZ;
			break;
		case Matrix3x3::YX:
			rotY.setRotateMatrix(Matrix3x3::Y, joint->getState(0));
			rotX.setRotateMatrix(Matrix3x3::X, joint->getState(1));
			rot = rotY * rotX;
			break;
		case Matrix3x3::YZ:
			rotY.setRotateMatrix(Matrix3x3::Y, joint->getState(0));
			rotZ.setRotateMatrix(Matrix3x3::Z, joint->getState(1));
			rot = rotY * rotZ;
			break;
		case Matrix3x3::ZX:
			rotZ.setRotateMatrix(Matrix3x3::Z, joint->getState(0));
			rotX.setRotateMatrix(Matrix3x3::X, joint->getState(1));
			rot = rotZ * rotX;
			break;
		case Matrix3x3::ZY:
			rotZ.setRotateMatrix(Matrix3x3::Z, joint->getState(0));
			rotY.setRotateMatrix(Matrix3x3::Y, joint->getState(1));
			rot = rotZ * rotY;
			break;
		default:
			break;
		}
		}
		break;
	case J_PIN:
		{
		rot.setRotateMatrix(order, joint->getState(0));
		}
		break;

	}
	for (int c = 0; c < 3; c++)
		for (int r = 0; r < 3; r++)
			matrix[r][c] = rot[r][c];
}

void ODESim::getGlobalJointMatrix(Joint* joint, double matrix[4][4])
{
	double tempMatrix[4][4];
	getJointMatrix(joint, tempMatrix);

	Joint* cur = NULL;
	if (joint->getInboardLink()  != NULL)
		cur = joint->getInboardLink()->getParentJoint();
	else
	{
		for (int r = 0; r < 3; r++)
			for (int c = 0; c < 3; c++)
				matrix[r][c] = tempMatrix[r][c];	
	}

	while (cur != NULL)
	{
		double m[4][4];
		getJointMatrix(cur, m);
		//multArray(&matrix[0][0], &tempMatrix[0][0], &m[0][0], 4, 4, 4);
		multArray4x4(matrix, tempMatrix, m);
		for (int r = 0; r < 3; r++)
			for (int c = 0; c < 3; c++)
				tempMatrix[r][c] = matrix[r][c];	
		if (cur->getInboardLink()  != NULL)
			cur = cur->getInboardLink()->getParentJoint();
		else
			cur = NULL;
	}
}

bool ODESim::writeODESourceCode(char* filename, ArticulatedObject* ao)
{
	ofstream file(filename, ios::out);
	if (!file.good())
	{
		danceInterp::OutputMessage("File '%s' could not be opened for writing. ODE source code was not written.", filename);
		return false;
	}

	double oldState[MAX_STATE];
	ao->getState(oldState);
	ao->setZeroState();

	int numBodies = ao->getNumLinks();

	file << "// the following ODE body and joint creation was written by the DANCE system." << endl;

	file  << "static dBodyID body[" << numBodies << "];" << endl;
	// declare the joints
	file  << "static dJointID joint[" << numBodies << "];" << endl;
	file << endl;

	// write the function header
	file << "void create(dWorldID world)" << endl;
	file << "{" << endl;

	// declare the bodies
	file << "// body creation" << endl;
	file << "\t// the following bodies are mapped to their corresponding indices:" << endl;
	for (int x = 0; x < numBodies; x++)
	{
		// show the body names
		Link* link = ao->getLink(x);
		file << "\t// " << link->getName() << " = " << x << endl;
	}
	file << endl;
	file << endl;
    
	int curMotorNum = 0;

	// add one body for each link
	int numLinks = ao->getNumLinks();
	for (int l = 0; l < numLinks; l++)
	{
		Link* link = ao->getLink(l);
		// create a rigid body for each link
		file << "// " << link->getName() << endl;
		file << "\tbody[" << l << "] = dBodyCreate(world);" << endl;
		// set the position
		double matrix[4][4];
		link->getWTransMat(matrix);
		Vector origin = {0.0, 0.0, 0.0};
		transformPoint_mat(origin, matrix);

		file << "\tdBodySetPosition(body[" << l << "], " << origin[0] << ", " << origin[1] << ", " << origin[2] << ");" << endl;
		// set the orientation
		dMatrix3 dm;

		double m[4][4];
		getGlobalJointMatrix(ao->getJoint(l), m);

		dRSetIdentity(dm);
		for (int r = 0; r < 3; r++)
			for (int c = 0; c < 3; c++)
				dm[r * 4 + c] = m[r][c];
		dQuaternion q;
		dRtoQ(dm, q);

		file << "\tdQuaternion q" << l << ";" << endl;
		file << "\tq" << l << "[0] = " << q[0] << "; ";
		file << "q" << l << "[1] = " << q[1] << "; ";
		file << "q" << l << "[2] = " << q[2] << "; ";
		file << "q" << l << "[3] = " << q[3] << "; " << endl;

		file << "\tdBodySetQuaternion(body[" << l <<"], q" << l << ");" << endl;

		// set the mass of the body5
		file << "\tdMass mass" << l << ";" << endl;
		// set the center of mass position relative to the body
		Vector com;
		link->getCenterMass(com);
		file << "\tmass" << l << ".c[0] = " << com[0] << "; mass" << l << ".c[1] = " << com[1] << "; mass" << l << ".c[2] = " << com[2] << ";" << endl;

		// set the inertia tensor
		double inertia[3][3];
		link->getInerTensor(inertia);
		file << "\tdMassSetParameters(&mass" << l << ", " << link->getMass() << ", " << com[0] << ", " << com[1] << ", " << com[2] << ", ";
		file << inertia[0][0] << ", " << inertia[1][1] << ", " << inertia[2][2] << ", " << inertia[0][1] << ", " << inertia[0][2] << ", " << inertia[1][2] << ");" << endl;
		file << "\tdBodySetMass(body[" << l << "], &mass" << l << ");" << endl;
		file << endl;
	}

	// add one ODE joint for each ArticulatedObject joint
	double matrix[4][4];
	double invMatrix[4][4];

	int inID = 0, outID = 0;

	file << "// joint creation" << endl;

	int numJoints = ao->getNumJoints();
	for (int j = 0; j < numJoints; j++)
	{
		Joint* joint = ao->getJoint(j);
		// to which bodies do these joints apply?
		Link* inLink = joint->getInboardLink();
		inID = -1;
		// get the link id of the inboard link
		for (unsigned int i = 0; i < bodies.size(); i++)
		{
			if (inLink == ao->getLink(i))
			{
				inID = i;
				break;
			}
		}
		if (inID == -1)
		{
			if (j != 0)
				danceInterp::OutputMessage("No inboard link found for joint '%s'...", joint->getName());
			if (joint->getJointType() == J_FREE)
			{
				// make sure that the joint resides in at the COM, since this is what ODE supports
				Vector bodyToJoint;
				joint->getBodyToJoint(bodyToJoint);
				if (VecLength(bodyToJoint) != 0.0)
				{
					//file << "\t// Free joints in ODE do not support body-to-joint vectors != 0." << endl;
					//file << "\t// "Please edit the Articulated Object so that the joint location matches the COM location. << endl;
				}
				continue;
			}
		}

		Link* outLink = joint->getOutboardLink();
		// get the link id of the outboard link
		for (unsigned int i = 0; i < bodies.size(); i++)
		{
			if (outLink == ao->getLink(i))
			{
				outID = i;
				break;
			}
		}
		if (outID == -1)
		{
			danceInterp::OutputMessage("No outboard link found for joint '%s'...", joint->getName());
			continue;
		}

		// determine the type of joint
		int jointType = joint->getJointType();
		double axes[3][3];
		joint->getAxis(axes);
		Vector jointPos;
		Vector globalAxis;
		joint->getPosition(jointPos);

		// apply the joint to those bodies
		// ignore joints that only apply to one body
		if (inID == -1 && outID == -1)
		{
			continue;
		}

		if (inLink != NULL)
		{
			file << "\t// joint connecting " << inLink->getName() << " and " << outLink->getName() << endl;
		}
		else
		{
			file << "\t// joint connecting " << outLink->getName() << endl;
		}

		switch (jointType)
		{
		case J_PIN:
			file << "\tjoint[" << j << "] = dJointCreateHinge(world, 0);" << endl;
			file << "\tdJointAttach(joint[" << j << "], body[" << inID << "], body[" << outID << "]);" << endl;
			// get the position of the joint
			file << "\tdJointSetHingeAnchor(joint[" << j << "], " << jointPos[0] << ", " << jointPos[1] << ", " << jointPos[2] << ");" << endl;
			// retrieve the axis of rotation
			// convert the local axes into global axes
			setIdentMat(&matrix[0][0], 4);
			setIdentMat(&invMatrix[0][0], 4);
			joint->getOrientation(matrix);
			invSmart4(invMatrix, matrix);

			VecCopy(globalAxis, axes[0]);
			transformPoint_mat(globalAxis, invMatrix);
			file << "\tdJointSetHingeAxis(joint[" << j << "], " << globalAxis[0] << ", " << globalAxis[1] << ", " << globalAxis[2] << ");" << endl;
			break;
		case J_CYLINDER:
			break;
		case J_SLIDER:
			file << "\tjoint[" << j << "] = dJointCreateSlider(world, 0);" << endl;
			file << "\tdJointAttach(joint[" << j << "], body[" << outID << "], body[" << inID << "]);" << endl;
			file << "\tdJointSetSliderAxis(joint[" << j << "], " << axes[0][0] << ", " << axes[0][1] << ", " << axes[0][2] << ");" << endl;
			break;
		case J_FREE:
			file << "\t// body[" << outID << "] is a free joint, so no PDE joint necessary to support the behavior of joint '" << joint->getName() << "'" << endl;
			Vector bodyToJoint;
			joint->getBodyToJoint(bodyToJoint);
			if (VecLength(bodyToJoint) != 0.0)
			{
				file << "\t// Free joints in ODE do not support body-to-joint vectors != 0. Resetting body-to-joint to zero." << endl;
				Vector zero = {0.0, 0.0, 0.0};
				joint->setBodyToJoint(zero);
				ao->updateStateConfig();
			}
			break;
		case J_BALL:
		case J_GIMBAL:
			// create a ball joint
			file << "\tjoint[" << j << "] = dJointCreateBall(world, 0);" << endl;
			file << "\tdJointAttach(joint[" << j << "], body[" << inID << "], body[" << outID << "]);" << endl;
			file << "\tdJointSetBallAnchor(joint[" << j << "], " << jointPos[0] << ", " << jointPos[1] << ", " << jointPos[2] << ");" << endl;

			// create the angular motor associated with the joint
			file << "\tdJointID motor" << curMotorNum << ";" << endl;
			file << "\tmotor" << curMotorNum << " = dJointCreateAMotor(world, 0);" << endl;
			file << "\tdJointAttach(motor" << curMotorNum << ", body[" << inID << "], body[" << outID << "]);" << endl;
			file << "\tdJointSetAMotorMode(motor" << curMotorNum << ", dAMotorUser);" << endl;
			file << "\tdJointSetAMotorNumAxes(motor" << curMotorNum << ", 3);" << endl;

			// convert the local axes into global axes
			setIdentMat(&matrix[0][0], 4);
			setIdentMat(&invMatrix[0][0], 4);
			joint->getOrientation(matrix);
			// zero out translation
			matrix[3][0] = 0.0;
			matrix[3][1] = 0.0;
			matrix[3][2] = 0.0;
			invSmart4(invMatrix, matrix);

			VecCopy(globalAxis, axes[0]);
			transformPoint_mat(globalAxis, invMatrix);
			file << "\tdJointSetAMotorAxis(motor" << curMotorNum << ", 0, 1, " << globalAxis[0] << ", " << globalAxis[1] << ", " << globalAxis[2] << ");" << endl;

			VecCopy(globalAxis, axes[1]);
			transformPoint_mat(globalAxis, invMatrix);
			file << "\tdJointSetAMotorAxis(motor" << curMotorNum << ", 1, 2, " << globalAxis[0] << ", " << globalAxis[1] << ", " << globalAxis[2] << ");" << endl;

			VecCopy(globalAxis, axes[2]);
			transformPoint_mat(globalAxis, invMatrix);
			file << "\tdJointSetAMotorAxis(motor" << curMotorNum << ", 2, 2, " << globalAxis[0] << ", " << globalAxis[1] << ", " << globalAxis[2] << ");" << endl;
			curMotorNum++;
			break;
		case J_WELD:
			file << "\tjoint[" << j << "] = dJointCreateFixed(world,0);" << endl;
			file << "\tdJointAttach(joint[" << j << "], body[" << inID << ", body[" << outID << "]);" << endl;
			file << "\tdJointSetFixed(joint[" << j << "]);" << endl;
			break;
		case J_PLANAR:
			file << "\t//ODE cannot support a planar joint for joint '" << joint->getName() << "'..." << endl;
			break;
		case J_BEARING:
			file << "\t//ODE cannot support a bearing joint for joint '" << joint->getName() << "'..." << endl;
			break;
		case J_UNIVERSAL:
			if (inID == -1)
			{
				danceInterp::OutputMessage("ODE cannot support a universal joint as the root joint for joint '%s'...", joint->getName());
				return false;
			}
			file << "\tjoint[" << j << "] = dJointCreateUniversal(world, 0);" << endl;
			file << "\tdJointAttach(joint[" << j << "], body[" << inID << "], body[" << outID << "]);" << endl;
			// get the position of the joint
			file << "\tdJointSetUniversalAnchor(joint[" << j << "], " << jointPos[0] << ", " << jointPos[1] << ", " << jointPos[2] << ");" << endl;

			// retrieve the axis of rotation
			setIdentMat(&matrix[0][0], 4);
			inLink->getParentJoint()->getOrientation(matrix);
			VecCopy(globalAxis, axes[0]);
			transformPoint_mat(globalAxis, matrix);

			file << "\tdJointSetUniversalAxis1(joint[" << j << "], " << globalAxis[0] << ", " << globalAxis[1] << ", " << globalAxis[2] << ");" << endl;

			outLink->getParentJoint()->getOrientation(matrix);
			VecCopy(globalAxis, axes[1]);
			transformPoint_mat(globalAxis, matrix);
			file << "\tdJointSetUniversalAxis2(joint[" << j << "], " << globalAxis[0] << ", " << globalAxis[1] << ", " << globalAxis[2] << ");" << endl;
			
			break;
		case J_BUSHING:
			file << "\t//ODE cannot support a bushing joint for joint '"<< joint->getName() << "'..." << endl;
			break;
			break;
		}
		file << endl;
	}

	ao->setState(oldState);


	// joint limits
	curMotorNum = 0;
	for (int j = 0; j < ao->getNumJoints(); j++)
	{
		Joint* joint = ao->getJoint(j);
		double axes[3][3];
		joint->getAxis(axes);
		double low, high;
		switch (joint->getJointType())
		{
		case J_FREE:
			break;
		case J_GIMBAL:
		case J_BALL:
			file << "\t// setting joint limits for joint " << joint->getName() << endl;
			for (int a = 0; a < 3; a++)
			{
				joint->getLimits(0, &low, &high);
				if (axes[a][0] == 1.0)
				{
					file <<"\tdJointSetAMotorParam(motor" << curMotorNum << ", dParamLoStop, " << low * M_PI / 180.0 << ");" << endl;
					file <<"\tdJointSetAMotorParam(motor" << curMotorNum << ", dParamHiStop, " << high * M_PI / 180.0 << ");" << endl;
					file <<"\tdJointSetAMotorParam(motor" << curMotorNum << ", dParamLoStop, " << low * M_PI / 180.0 << ");" << endl;
					file <<"\tdJointSetAMotorParam(motor" << curMotorNum << ", dParamHiStop, " << high * M_PI / 180.0 << ");" << endl;
				}
				else if (axes[a][1] == 1.0)
				{
					file <<"\tdJointSetAMotorParam(motor" << curMotorNum << ", dParamLoStop2, " << low * M_PI / 180.0 << ");" << endl;
					file <<"\tdJointSetAMotorParam(motor" << curMotorNum << ", dParamHiStop2, " << high * M_PI / 180.0 << ");" << endl;
					file <<"\tdJointSetAMotorParam(motor" << curMotorNum << ", dParamLoStop2, " << low * M_PI / 180.0 << ");" << endl;
					file <<"\tdJointSetAMotorParam(motor" << curMotorNum << ", dParamHiStop2, " << high * M_PI / 180.0 << ");" << endl;
				}
				else if (axes[a][2] == 1.0)
				{
					file <<"\tdJointSetAMotorParam(motor" << curMotorNum << ", dParamLoStop3, " << low * M_PI / 180.0 << ");" << endl;
					file <<"\tdJointSetAMotorParam(motor" << curMotorNum << ", dParamHiStop3, " << high * M_PI / 180.0 << ");" << endl;
					file <<"\tdJointSetAMotorParam(motor" << curMotorNum << ", dParamLoStop3, " << low * M_PI / 180.0 << ");" << endl;
					file <<"\tdJointSetAMotorParam(motor" << curMotorNum << ", dParamHiStop3, " << high * M_PI / 180.0 << ");" << endl;
				}
			}
			curMotorNum++;
			break;
		case J_UNIVERSAL:
			file << "\t// setting joint limits for joint " << joint->getName() << endl;
			joint->getLimits(0, &low, &high);
			if (!this->isUseJointLimits())
			{
				low = -dInfinity;
				high = dInfinity;
			}
			file <<"\tdJointSetUniversalParam(joint[" << j << "], dParamLoStop, " << -high * M_PI / 180.0 << ");" << endl;
			file <<"\tdJointSetUniversalParam(joint[" << j << "], dParamHiStop, " << -low * M_PI / 180.0 << ");" << endl;
			file <<"\tdJointSetUniversalParam(joint[" << j << "], dParamLoStop, " << -high * M_PI / 180.0 << ");" << endl;
			file <<"\tdJointSetUniversalParam(joint[" << j << "], dParamHiStop, " << -low * M_PI / 180.0 << ");" << endl;

			joint->getLimits(1, &low, &high);
			if (!this->isUseJointLimits())
			{
				low = -dInfinity;
				high = dInfinity;
			}
			file <<"\tdJointSetUniversalParam(joint[" << j << "], dParamLoStop2, " << -high * M_PI / 180.0 << ");" << endl;
			file <<"\tdJointSetUniversalParam(joint[" << j << "], dParamHiStop2, " << -low * M_PI / 180.0 << ");" << endl;
			file <<"\tdJointSetUniversalParam(joint[" << j << "], dParamLoStop, " << -high * M_PI / 180.0 << ");" << endl;
			file <<"\tdJointSetUniversalParam(joint[" << j << "], dParamHiStop2, " << -low * M_PI / 180.0 << ");" << endl;
			break;
		case J_PIN:
			file << "\t// setting joint limits for joint " << joint->getName() << endl;
			if (!this->isUseJointLimits())
			{
				low = -dInfinity;
				high = dInfinity;
			}
			joint->getLimits(0, &low, &high);
			file <<"\tdJointSetHingeParam(joint[" << j << "], dParamLoStop, " << -high * M_PI / 180.0 << ");" << endl;
			file <<"\tdJointSetHingeParam(joint[" << j << "], dParamHiStop, " << -low * M_PI / 180.0 << ");" << endl;
			file <<"\tdJointSetHingeParam(joint[" << j << "], dParamLoStop, " << -high * M_PI / 180.0 << ");" << endl;
			file <<"\tdJointSetHingeParam(joint[" << j << "], dParamHiStop, " << -low * M_PI / 180.0 << ");" << endl;
			break;
		case J_SLIDER:
			break;
		case J_WELD:
			break;
		}
		file << endl;
	}

	file << "}" << endl;

	// now set the position of the rigid body
	// write the function header
	file << "// initial body positions and orientations" << endl;
	file << "void position(dWorldID world)" << endl;
	file << "{" << endl;

	for (int l = 0; l < numBodies; l++)
	{
		Link* link = ao->getLink(l);
		Vector pos;
		link->getPosition(pos);
		file << "\tdBodySetPosition(body[" << l << "], " << pos[0] << ", " << pos[1] << ", " << pos[2] << "); // " << link->getName() << endl;

		// set the orientation
		dMatrix3 dm;

		double m[4][4];
		getGlobalJointMatrix(ao->getJoint(l), m);

		dRSetIdentity(dm);
		for (int r = 0; r < 3; r++)
			for (int c = 0; c < 3; c++)
				dm[r * 4 + c] = m[r][c];
		dQuaternion q;
		dRtoQ(dm, q);

		file << "\tdQuaternion q" << l << ";" << endl;
		file << "\tq" << l << "[0] = " << q[0] << "; ";
		file << "q" << l << "[1] = " << q[1] << "; ";
		file << "q" << l << "[2] = " << q[2] << "; ";
		file << "q" << l << "[3] = " << q[3] << "; " << endl;

		file << "\tdBodySetQuaternion(body[" << l <<"], q" << l << ");" << endl;
	}

	file << "}" << endl;

	danceInterp::OutputMessage("Wrote ODE source code to file '%s' with %d bodies and %d joints.", filename, numBodies, numBodies);

	return true;
} 


dBodyID ODESim::getODEBodyID(int num)
{
    if (int(bodies.size()) > num)
		return bodies[num];
	else
		return NULL;
}

dJointID ODESim::getODEJointID(int num)
{
    if (int(joints.size()) > num)
		return joints[num];
	else
		return NULL;
}


dWorldID ODESim::getODEWorldID()
{
	return this->world;
}

static void myMessageFunction(int errnum, const char* msg, va_list ap)
{
	danceInterp::OutputMessage("ODE error: %d %s", errnum, msg);
}

void ODESim::initializeWorld()
{
	if (world == NULL)
    {
        dRandSetSeed(0);
		world = dWorldCreate();

		// set up the error handlers
		dSetErrorHandler(&myMessageFunction);
		dSetDebugHandler(&myMessageFunction);
		dSetMessageHandler(&myMessageFunction);
    }
	danceInterp::OutputMessage("dWorld %d created", world);
	this->setWorldERP(this->getWorldERP());
}

void ODESim::setOrderedParameters3(int order, double* to, double* from)
{
	switch (order)
	{
	case Matrix3x3::XYZ:
		to[0] = from[0];
		to[1] = from[1];
		to[2] = from[2];
		break;
	case Matrix3x3::XZY:
		to[0] = from[0];
		to[1] = from[2];
		to[2] = from[1];
		break;
	case Matrix3x3::YXZ:
		to[0] = from[1];
		to[1] = from[0];
		to[2] = from[2];
		break;
	case Matrix3x3::YZX:
		to[0] = from[1];
		to[1] = from[2];
		to[2] = from[0];
		break;
	case Matrix3x3::ZXY:
		to[0] = from[2];
		to[1] = from[0];
		to[2] = from[1];
		break;
	case Matrix3x3::ZYX:
		to[0] = from[2];
		to[1] = from[1];
		to[2] = from[0];
		break;

	}
}

void ODESim::setOrderedParameters2(int order, double* to, double* from)
{
	switch (order)
	{
	case Matrix3x3::XY:
		to[0] = from[0];
		to[1] = from[1];
		to[2] = from[2];
		break;
	case Matrix3x3::XZ:
		to[0] = from[0];
		to[1] = from[2];
		to[2] = from[1];
		break;
	case Matrix3x3::YX:
		to[0] = from[1];
		to[1] = from[0];
		to[2] = from[2];
		break;
	case Matrix3x3::YZ:
		to[0] = from[1];
		to[1] = from[2];
		to[2] = from[0];
		break;
	case Matrix3x3::ZX:
		to[0] = from[2];
		to[1] = from[0];
		to[2] = from[1];
		break;
	case Matrix3x3::ZY:
		to[0] = from[2];
		to[1] = from[1];
		to[2] = from[0];
		break;
	}
}


void ODESim::setOrderedParameters1(int order, double* to, double* from)
{
	switch (order)
	{
	case Matrix3x3::X:
		to[0] = from[0];
		break;
	case Matrix3x3::Y:
		to[0] = from[1];
		break;
	case Matrix3x3::Z:
		to[0] = from[2];
		break;
	}
}

void ODESim::getGlobalAxes( int group, Vector outAxes[3] )
{
	dJointID jointID = motorAngles[group];
	if( !jointID ) 
	{
		return;
	}
	dVector3 axes[3];
	for( int i = 0; i < 3; ++i )
	{
		dJointGetAMotorAxis( jointID, i, axes[i] );
		for( int j = 0; j < 3; ++j )
		{
			outAxes[i][j] = axes[i][j];
		}
	}
}

void ODESim::getComputedLinkAxes( int group, Vector outAxes[] )
{
	dJointID jointID = motorAngles[group];
	if( !jointID ) 
	{
		return;
	}

	Vector unitAxes[3];
	for( int i = 0; i < 3; i++ )
	{
		for( int j = 0; j < 3; ++j )
		{
			unitAxes[i][j] = ( i == j ? -1.0 : 0.0 );
		}
		convertLinkLocalToJointEuler( group, outAxes[i], unitAxes[i] );
	}
}

void ODESim::convertLinkLocalToJointEuler( int group, Vector outJointEuler, Vector argLinkLocal ) const
{
	dJointID jointID = motorAngles[group];

	// convert the local axes into global axes
	double outboardToWorld[4][4];  // outbound link local coords 

	setIdentMat( &outboardToWorld[0][0], 4);
	ao->getJoint(group)->getOutboardLink()->getWTransMat( outboardToWorld );
	// zero out translation
	outboardToWorld[3][0] = 0.0;
	outboardToWorld[3][1] = 0.0;
	outboardToWorld[3][2] = 0.0;

	dVector3 eulerAxesInGlobalCoords[3]; 
	for( int i = 0; i < 3; ++i )
	{
		dJointGetAMotorAxis( jointID, i, eulerAxesInGlobalCoords[i]);
		if( group == 5 ) // left elbow on skeleton
		{
			danceInterp::OutputMessage( "Euler[%d] %f, %f, %f", i, eulerAxesInGlobalCoords[i][0],
				eulerAxesInGlobalCoords[i][1], eulerAxesInGlobalCoords[i][2] );
		}
	}


	double worldToEuler[4][4];
	setIdentMat( &worldToEuler[0][0], 4 );
	for( int i = 0; i < 3; ++i )
	{
		// each axis
		for( int j = 0; j < 3; ++j )
		{
			worldToEuler[j][i] = eulerAxesInGlobalCoords[i][j];
		}
	}
	// worldToEuler set.

	VecCopy( outJointEuler, argLinkLocal );

	double outboardToEuler[4][4];
	multArray4x4( outboardToEuler, outboardToWorld, worldToEuler );
	transformPoint_mat( outJointEuler, outboardToEuler );


	if( 0 != group ) // Root is a special case
	{
		for( int i = 0; i < 3; ++i )
		{
			outJointEuler[i] *= -1;
		}
	}
};

void ODESim::SetupVelocityDrive( int group, Vector argSpring, Vector argDamping, Vector argMaxForce )
{
	Vector eulerAngularForce;
	//////////////////////////////////////////////////////////////////////////
	//convertLinkLocalToJointEuler( group, eulerAngularForce, argMaxForce );
	VecCopy( eulerAngularForce, argMaxForce );
	//VecNumMul( eulerAngularForce, eulerAngularForce, -1 );
	//////////////////////////////////////////////////////////////////////////

	//Vector eulerAngularSpring;
	//convertLinkLocalToJointEuler( group, eulerAngularSpring, argSpring );

	//Vector eulerAngularDamping;
	//convertLinkLocalToJointEuler( group, eulerAngularDamping, argDamping );

	// Attempt to compute ERP/CFM to mimic Spring constants.
	// Problem:  AMotors don't support per-joint ERP!?!?  
	// Old ODE 0.35 patch was posted to the mailing list...  might be worth a try.
	//double dt = getTimeStep();
	//double gblERP = getWorldERP();
	//double cfm = 1.0 / (dt * argSpring[0] + argDamping[0] );
	//cfm = getWorldCFM();

	//double maxForce = std::max( abs( eulerAngularForce[0] ), abs( eulerAngularForce[1] ) );
	//maxForce = std::max( maxForce, abs( eulerAngularForce[2] ) );

	//dJointSetAMotorParam( jointID, dParamERP + i * dParamGroup, cfm );
	//dJointSetAMotorParam( jointID, dParamCFM, cfm );
	//dJointSetAMotorParam( jointID, dParamCFM2, cfm );
	//dJointSetAMotorParam( jointID, dParamCFM3, cfm );

	dJointID jointID = joints[ group ];
	int jointType = dJointGetType(jointID);
	if( dJointTypeBall == jointType )
	{
		jointID = motorAngles[group];
	}
	switch( jointType )
	{
	case dJointTypeBall:
		dJointSetAMotorParam( jointID, dParamFMax,  abs( eulerAngularForce[0] ) );
		dJointSetAMotorParam( jointID, dParamFMax2, abs( eulerAngularForce[1] ) );
		dJointSetAMotorParam( jointID, dParamFMax3, abs( eulerAngularForce[2] ) );
		break;
	case dJointTypeUniversal:
		dJointSetUniversalParam( jointID, dParamFMax, abs( eulerAngularForce[1] ) );
		dJointSetUniversalParam( jointID, dParamFMax2, abs( eulerAngularForce[0] ) );
		break;
	case dJointTypeHinge:
		dJointSetHingeParam( jointID, dParamFMax, abs( eulerAngularForce[0] ) );
		break;
	}        
}

void ODESim::ApplyVelocityDrive( int group, Vector argTargetAngularVelocity /* outbound link local coords */ )
{
	Vector eulerAngularVelocity;
	
	//////////////////////////////////////////////////////////////////////////
	//convertLinkLocalToJointEuler( group, eulerAngularVelocity, argTargetAngularVelocity );
	VecCopy( eulerAngularVelocity, argTargetAngularVelocity );
	//VecNumMul( eulerAngularVelocity, eulerAngularVelocity, -1 );
	//////////////////////////////////////////////////////////////////////////

	if( group == 5 ) // left elbow on skeleton
	{
		//danceInterp::OutputMessage( "Target LocalAngVel %f, %f, %f", argTargetAngularVelocity[0],
		//	argTargetAngularVelocity[1], argTargetAngularVelocity[2] );
		//danceInterp::OutputMessage( "Target EulerAngVel %f, %f, %f", eulerAngularVelocity[0],
		//	eulerAngularVelocity[1], eulerAngularVelocity[2] );
	}
	dJointID jointID = joints[ group ];
	int jointType = dJointGetType(jointID);
	if( dJointTypeBall == jointType )
	{
		dJointID amotorID = motorAngles[group];
		if( NULL != jointID )
		{
			jointID = amotorID;
		}
	}
	switch( jointType )
	{
	case dJointTypeBall:
		dJointSetAMotorParam( jointID, dParamVel,  eulerAngularVelocity[0] );
		dJointSetAMotorParam( jointID, dParamVel2, eulerAngularVelocity[1] );
		dJointSetAMotorParam( jointID, dParamVel3, eulerAngularVelocity[2] );
		break;
	case dJointTypeUniversal:
		dJointSetUniversalParam( jointID, dParamVel, eulerAngularVelocity[1] );
		dJointSetUniversalParam( jointID, dParamVel2, eulerAngularVelocity[0] );
		break;
	case dJointTypeHinge:
		dJointSetHingeParam( jointID, dParamVel, eulerAngularVelocity[0] );
		break;
	}

}

/// Create an AMotor for the specified joint between the indicated links.
/// Tricky issues:
/// 1. Ode considers the first body as attached to the second one. I.e. the second
/// body is the parent of the first one in a hierarchical scheme!! 
/// For example if you are creating a motor between a link the world the second
/// body argument should be the world!!
/// 2. First axis (0) is considered with respect to the first body
/// the third axis is considered with respect to the second body and the middle
/// axis is irrelevant as it will be computed automaticalle as the cross product
/// of the other two.
dJointID ODESim::createAMotorBall( Joint* joint, dBodyID childLinkID, dBodyID parentLinkID )
{
//	dJointID jointID = NULL;
	dJointID motorID = NULL;
	double matrix[4][4];
	double invMatrix[4][4];

	// create the angular motor associated with the joint
	motorID = dJointCreateAMotor(world, 0);
	dJointAttach(motorID, childLinkID, parentLinkID );
	dJointSetAMotorMode(motorID, dAMotorEuler);
	dJointSetAMotorNumAxes(motorID, 3);

	// convert the local axes into global axes
	setIdentMat(&matrix[0][0], 4);
	setIdentMat(&invMatrix[0][0], 4);
	joint->getOrientation(matrix);
	// zero out translation
	matrix[3][0] = 0.0;
	matrix[3][1] = 0.0;
	matrix[3][2] = 0.0;
	invSmart4(invMatrix, matrix);

	Vector globalAxis;
	double axes[3][3];
	int numAxes = joint->getAxis(axes);

	VecCopy(globalAxis, axes[0]);
	transformPoint_mat(globalAxis, invMatrix);
	dJointSetAMotorAxis(motorID, 0, 1, globalAxis[0], globalAxis[1], globalAxis[2]);

	VecCopy(globalAxis, axes[2]);
	transformPoint_mat(globalAxis, invMatrix);
	if( parentLinkID == 0)
		dJointSetAMotorAxis(motorID, 2, 0, globalAxis[0], globalAxis[1], globalAxis[2]);
	else
		dJointSetAMotorAxis(motorID, 2, 2, globalAxis[0], globalAxis[1], globalAxis[2]);

	dJointSetAMotorParam( motorID, dParamFudgeFactor, 0.1 );
	dJointSetAMotorParam( motorID, dParamFudgeFactor2, 0.1 );
	dJointSetAMotorParam( motorID, dParamFudgeFactor3, 0.1 );

	// Only ODE will maintain this pointer, it is destroyed in clearAmotors()
	dJointFeedback* fb = new dJointFeedback;
	for( int i = 0; i < 3; ++i )
	{
		fb->f1[i] = 0.0; 
		fb->f2[i] = 0.0;
		fb->t1[i] = 0.0;
		fb->t2[i] = 0.0;
	}
	dJointSetFeedback( motorID, fb );
	return motorID;
}

void ODESim::clearAmotors( void )
{
	// remove the motor angles
	for (vector<dJointID>::iterator iter = motorAngles.begin(); iter != motorAngles.end(); iter++)
	{
		if (*iter != NULL)
		{
			// Release feedback
			dJointFeedback* fb = dJointGetFeedback( *iter );
			delete fb;
			dJointDestroy(*iter);
		}
	}
	motorAngles.clear();
}

void ODESim::accumulateTorques( void )
{
	// Accumulate Amotors
	for (unsigned int i = 0; i < motorAngles.size(); ++i )
	{
		if( motorAngles[i] )
		{
			accumulateAmotorTorque( i );
		}
	}
	for ( unsigned int i = 0; i < joints.size(); ++i )
	{
		if( joints[i] )
		{
			accumulateJointTorque( i );
		}
	}
}

void ODESim::accumulateTorque( int argJointIdx, double argX, double argY, double argZ )
{
	m_jointTorques[ argJointIdx * 3 ] += std::abs( argX );
	m_jointTorques[ argJointIdx * 3 + 1] += std::abs( argY );
	m_jointTorques[ argJointIdx * 3 + 2] += std::abs( argZ );
}

void ODESim::zeroTorques( void )
{
	for( int i = 0; i< MAX_JOINTS; ++i )
	{
		m_jointTorques[i] = 0.0;
	}
}

void ODESim::acquireTorque( Vector outTorque, int argGroupId /*Joint*/ )
{
	assert( (argGroupId >= 0) && (argGroupId < (MAX_JOINTS*3)) );
	VecCopy( outTorque, &(m_jointTorques[argGroupId * 3]) );
}

void ODESim::acquireTorques( std::vector<double>& outTorques /* treated as state space */ )
{
	if (this->getNumSystems() == 0)
		return;

	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0); 
	for( int i = 0; i < ao->m_numJoints; ++i )
	{
		Vector torque;
		acquireTorque( torque, i );
		for( int j = 0; j < 3; ++j )
		{
			outTorques.push_back( torque[j] );
		}
	}
}

void ODESim::accumulateJointTorque( int argGroupIdx )
{
	if (this->getNumSystems() == 0)
		return;

	//ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0); 

	dJointID jID = joints[argGroupIdx];
	if( !jID )
	{
		return;
	}
	dJointFeedback* feedback = dJointGetFeedback( jID );
	Vector measuredTorque;
	zeroVector( measuredTorque );
	if( feedback )
	{
		for (int x = 0; x < 3; x++)
			measuredTorque[x] = feedback->t1[x];
		accumulateTorque( argGroupIdx, measuredTorque[0], measuredTorque[1], measuredTorque[2] );
		//dVector3 torqueOnBodyOne;
		//dVector3 forces;
		//for( int i = 0; i < 3; ++i )
		//{
		//	torqueOnBodyOne[i] = (feedback->t1)[i];
		//	forces[i] = (feedback->f1)[i];
		//}
		//danceInterp::OutputMessage( "torque on joint %d = ( %f,%f,%f | %f,%f,%f ) , forces = ( %f,%f,%f )", argGroupIdx, torqueOnBodyOne[0], torqueOnBodyOne[1], torqueOnBodyOne[2], torqueOnBodyTwo[0],torqueOnBodyTwo[1], torqueOnBodyTwo[2], forces[0], forces[1], forces[2] );
	}
	else
	{
		danceInterp::OutputMessage( "can't get feedback for joint %d", argGroupIdx );
	}
}

void ODESim::accumulateAmotorTorque( int argGroupIdx )
{
	if (this->getNumSystems() == 0)
		return;

	//ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0); 

	dJointID jID = motorAngles[argGroupIdx];
	if( !jID )
	{
		return;
	}
	dJointFeedback* feedback = dJointGetFeedback( jID );
	Vector measuredTorque;
	zeroVector( measuredTorque );
	if( feedback )
	{
		for (int x = 0; x < 3; x++)
			measuredTorque[x] = feedback->t1[x];
		accumulateTorque( argGroupIdx, measuredTorque[0], measuredTorque[1], measuredTorque[2] );
	}
	else
	{
		danceInterp::OutputMessage( "can't get feedback for amotor %d", argGroupIdx );
	}
}

void ODESim::showParameters()
{
        // erp
        dReal erp = dWorldGetERP(world);
        danceInterp::OutputMessage("ERP = %f", erp);

        dReal cfm = dWorldGetCFM(world);
        danceInterp::OutputMessage("CFM = %f", cfm);

        int numQuickSteps = dWorldGetQuickStepNumIterations(world);
        danceInterp::OutputMessage("Quick step iterations = %d", numQuickSteps);
       
        dReal maxVel = dWorldGetContactMaxCorrectingVel(world);
        danceInterp::OutputMessage("Contact Max Correcting= %f", maxVel);

}

