/**************************************************************************
	D.A.N.C.E.
	Dynamic AnimatioN and Control Environment
	----------------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
-----------------------------------------------
	
 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

 This software is distributed for noncommercial use in the hope that it will 
 be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
 to anyone for the consequences	of using it or for whether it serves any 
 particular purpose or works at all. No warranty is made about the software 
 or its performance. Commercial use is prohibited.
***************************************************************************/

#ifndef _ODESIMWINDOW_
#define _ODESIMWINDOW_

#include "opengl.h"
#include <fltk/Group.h>
#include <fltk/Input.h>
#include <fltk/IntInput.h>
#include <fltk/Button.h>
#include <fltk/CheckButton.h>
#include <fltk/MultiBrowser.h>
#include <fltk/Widget.h>
#include <fltk/Choice.h>
#include <fltk/FloatInput.h>

class ODESim;

class ODESimWindow : public fltk::Group
{
	public:
		ODESimWindow(ODESim* sim, int x, int y, int w, int h, const char* name);

		void layout();
		void updateGUI();

		static void ShowBodyCB(fltk::Widget* widget, void* data);
		static void WorldERPCB(fltk::Widget* widget, void* data);
		static void WorldCFMCB(fltk::Widget* widget, void* data);
		static void MaxContactVelCB(fltk::Widget* widget, void* data);

		static void UseStepFastCB(fltk::Widget* widget, void* data);
		static void UseJointLimitsCB(fltk::Widget* widget, void* data);
		static void StepFastIterationsCB(fltk::Widget* widget, void* data);
		static void SelectAOCB(fltk::Widget* widget, void* data);

		static void StepCB(fltk::Widget* widget, void* data);
		static void UseMainTimeStepCB(fltk::Widget* widget, void* data);
		static void ActiveCB(fltk::Widget* widget, void* data);
		static void ShowAttachmentsCB(fltk::Widget* widget, void* data);
		static void WriteODECodeCB(fltk::Widget* widget, void* data);

		fltk::CheckButton* checkShowBodyPositions;
		fltk::CheckButton* checkUseStepFast;
		fltk::CheckButton* checkUseJointLimits;
		fltk::FloatInput* inputStepFastIterations;
		fltk::FloatInput* inputAngVelDamping;
		fltk::FloatInput* inputWorldERP;
		fltk::FloatInput* inputWorldCFM;
		fltk::Input* inputMaxContactVel;
		fltk::Choice* choiceAO;
		fltk::FloatInput* inputStep;
		fltk::CheckButton* checkUseMainTimeStep;
		fltk::Button* buttonWriteODECode;
		fltk::CheckButton* checkActive;
		fltk::CheckButton* checkShowAttachments;

		ODESim* odeSim;

	private:
};


#endif


