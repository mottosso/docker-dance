/**************************************************************************
	D.A.N.C.E.
	Dynamic AnimatioN and Control Environment
	----------------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
-----------------------------------------------
	
 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

 This software is distributed for noncommercial use in the hope that it will 
 be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
 to anyone for the consequences	of using it or for whether it serves any 
 particular purpose or works at all. No warranty is made about the software 
 or its performance. Commercial use is prohibited.
***************************************************************************/

#include "ODESimWindow.h"

#include <fltk/Group.h>
#include <fltk/CheckButton.h>
#include <fltk/ask.h>
#include <fltk/file_chooser.h>
#include "ODESim.h"
#include "dance.h"
#include "ViewManager.h"

using namespace fltk;

ODESimWindow::ODESimWindow(ODESim* sim, int x, int y, int w, int h, const char* name) : Group(x, y, w, h, name)
{
	odeSim = sim;

	this->begin();

	Group* group = new Group(10, 10, 300, 280);
	group->box(fltk::BORDER_BOX);
	group->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	group->begin();

	choiceAO = new Choice(110, 10, 150, 20, "Simulated Object");
	choiceAO->callback(this->SelectAOCB, this);

	checkShowBodyPositions = new CheckButton(20, 35, 100, 20, "Show body positions");
	checkShowBodyPositions->callback(ShowBodyCB, this);

	checkActive = new CheckButton(20, 60, 100, 20, "Active");
	checkActive->callback(ActiveCB, this);

	inputStep = new FloatInput(60, 85, 50, 20, "Time step");
	inputStep->callback();
	inputStep->hide();

	checkUseMainTimeStep = new CheckButton(120, 85, 80, 20, "Use main simulator time step");
	checkUseMainTimeStep->callback(UseMainTimeStepCB, this);
	checkUseMainTimeStep->hide();

	checkShowAttachments = new CheckButton(20, 85, 100, 20, "Show Attachments");
	checkShowAttachments->callback(ShowAttachmentsCB, this);

	checkUseStepFast = new CheckButton(20, 110, 30, 20, "Use quick step");
	checkUseStepFast->callback(UseStepFastCB, this);

	inputStepFastIterations = new FloatInput(100, 140, 40, 20, "Quick Step iterations");
	inputStepFastIterations->callback(StepFastIterationsCB, this);

	inputWorldERP = new FloatInput(100, 170, 40, 20, "World ERP");
	inputWorldERP->callback(WorldERPCB, this);

	inputWorldCFM = new FloatInput(100, 195, 40, 20, "World CFM");
	inputWorldCFM->callback(WorldCFMCB, this);

	inputMaxContactVel = new Input( 250, 170, 40, 20, "Max Contact Vel" );
	inputMaxContactVel->callback( MaxContactVelCB, this );

	checkUseJointLimits = new CheckButton(20, 220, 30, 20, "Use ODE joint limits");
	checkUseJointLimits->callback(this->UseJointLimitsCB, this);

	buttonWriteODECode = new Button(20, 245, 80, 20, "Write ODE Code");
	buttonWriteODECode->callback(WriteODECodeCB, this);

	group->end();

	this->end();

	this->updateGUI();
}

void ODESimWindow::layout()
{
	this->updateGUI();

	Group::layout();
}

void ODESimWindow::updateGUI()
{
	choiceAO->clear();
	choiceAO->add("Choose an articulated object");
	for (int x = 0; x < dance::AllSystems->size(); x++)
	{
		ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get(x));
		if (ao == NULL)
		{
			// ignore, not an articulated object
		}
		else
		{
			choiceAO->add(ao->getName());
		}
	}

	// choose the appropriate articulated object
	ArticulatedObject* ao = (ArticulatedObject*) this->odeSim->getSystem(0);

	if (ao != NULL)
	{
		for (int x = 0; x < choiceAO->size(); x++)
		{
			Widget* w = choiceAO->child(x);
			if (strcmp(ao->getName(), w->label()) == 0)
			{
				choiceAO->value(x);
				break;
			}
		}
		checkShowBodyPositions->activate();
		checkShowBodyPositions->value(this->odeSim->isShowBodyPositions());

		this->checkUseStepFast->activate();
		if (this->odeSim->isUseStepFast())
		{
			this->checkUseStepFast->value(true);
			this->inputStepFastIterations->activate();
			this->inputStepFastIterations->value((float) this->odeSim->getStepFastIterations());
		}
		else
		{
			this->checkUseStepFast->value(false);
			this->inputStepFastIterations->deactivate();
		}

		this->inputWorldERP->activate();
		this->inputWorldERP->value(this->odeSim->getWorldERP());
		this->inputWorldCFM->activate();
		this->inputWorldCFM->value(this->odeSim->getWorldCFM());
		inputMaxContactVel->activate();

		static char valueStr[255];
		sprintf( valueStr, "%g", odeSim->getContactMaxCorrectingVel() );
		inputMaxContactVel->value( valueStr, strlen(valueStr) );

		checkUseMainTimeStep->activate();
		if (this->odeSim->isUseMainTimeStep())
		{
			checkUseMainTimeStep->value(true);
			inputStep->deactivate();
		}
		else
		{
			checkUseMainTimeStep->value(false);
			inputStep->activate();
			inputStep->value(this->odeSim->getTimeStep());
		}
		this->checkUseJointLimits->activate();
		if (this->odeSim->isUseJointLimits())
			this->checkUseJointLimits->value(true);
		else
			this->checkUseJointLimits->value(false);

		buttonWriteODECode->activate();
	}
	else
	{
		choiceAO->value(0);
		this->checkShowBodyPositions->deactivate();
		this->checkUseStepFast->deactivate();
		this->inputStepFastIterations->deactivate();
		this->inputWorldERP->deactivate();
		this->inputWorldCFM->deactivate();
		inputMaxContactVel->deactivate();
		inputStep->deactivate();
		checkUseMainTimeStep->deactivate();
		this->checkUseJointLimits->deactivate();
		buttonWriteODECode->deactivate();
	}
	this->checkActive->value(this->odeSim->isActive());
}

void ODESimWindow::ShowBodyCB(fltk::Widget* widget, void* data)
{
	ODESimWindow* win = (ODESimWindow*) data;

	CheckButton* check = (CheckButton*) widget;

	if (check->value() == true)
	{
		win->odeSim->setShowBodyPositions(true);
	}
	else
	{
		win->odeSim->setShowBodyPositions(false);
	}

	dance::AllViews->postRedisplay();
}


void ODESimWindow::UseStepFastCB(fltk::Widget* widget, void* data)
{
	ODESimWindow* win = (ODESimWindow*) data;

	CheckButton* check = (CheckButton*) widget;

	win->odeSim->setUseStepFast(check->value());

	win->updateGUI();
}

void ODESimWindow::UseJointLimitsCB(fltk::Widget* widget, void* data)
{
	ODESimWindow* win = (ODESimWindow*) data;

	CheckButton* check = (CheckButton*) widget;

	win->odeSim->setUseJointLimits(check->value());

	win->updateGUI();
}


void ODESimWindow::StepFastIterationsCB(fltk::Widget* widget, void* data)
{
	ODESimWindow* win = (ODESimWindow*) data;

	IntInput* input = (IntInput*) widget;

 win->odeSim->setStepFastIterations(int(input->fvalue()));

	win->updateGUI();
}

void ODESimWindow::WorldERPCB(fltk::Widget* widget, void* data)
{
	ODESimWindow* win = (ODESimWindow*) data;

	FloatInput* input = (FloatInput*) widget;

	win->odeSim->setWorldERP(input->fvalue());

	win->updateGUI();

}

void ODESimWindow::WorldCFMCB(fltk::Widget* widget, void* data)
{
	ODESimWindow* win = (ODESimWindow*) data;

	FloatInput* input = (FloatInput*) widget;

	win->odeSim->setWorldCFM(input->fvalue());

	win->updateGUI();

}

void ODESimWindow::MaxContactVelCB(fltk::Widget* widget, void* data)
{
	ODESimWindow* win = (ODESimWindow*) data;
	FloatInput* input = (FloatInput*) widget;
	if( dInfinity == input->fvalue() )
	{
		win->odeSim->setContactMaxCorrectingVel( dInfinity );
	}
	else
	{
		win->odeSim->setContactMaxCorrectingVel( input->fvalue() );
	}
	win->updateGUI();
}


void ODESimWindow::SelectAOCB(fltk::Widget *w, void *data)
{
	ODESimWindow* win = (ODESimWindow*) data;

	Widget* widget = win->choiceAO->child(win->choiceAO->value());

	DSystem* sys = (DSystem*) dance::AllSystems->get((char*) widget->label());
	if (sys != NULL)
	{
		win->odeSim->addSystem(sys);
	}
	else
	{
		if (win->odeSim->getNumSystems() > 0)
		{
			DSystem* sys = win->odeSim->getSystem(0);
			win->odeSim->removeSystem(sys);
		}
	}

	win->updateGUI();
}

void ODESimWindow::StepCB(fltk::Widget* widget, void* data)
{
	ODESimWindow* win = (ODESimWindow*) data;

	double step = win->inputStep->fvalue();

	win->odeSim->setTimeStep(step);

	win->updateGUI();
}

void ODESimWindow::ActiveCB(fltk::Widget* widget, void* data)
{
	ODESimWindow* win = (ODESimWindow*) data;

	win->odeSim->setActive(win->checkActive->value());

	win->updateGUI();
}

void ODESimWindow::ShowAttachmentsCB(fltk::Widget* widget, void* data)
{
	ODESimWindow* win = (ODESimWindow*) data;

	win->odeSim->setShowAttachments(win->checkShowAttachments->value());

	win->updateGUI();
}


void ODESimWindow::UseMainTimeStepCB(fltk::Widget* widget, void* data)
{
	ODESimWindow* win = (ODESimWindow*) data;

	win->odeSim->setUseMainTimeStep(win->checkUseMainTimeStep->value());

	win->updateGUI();
}

void ODESimWindow::WriteODECodeCB(fltk::Widget* widget, void* data)
{
	ODESimWindow* win = (ODESimWindow*) data;

	if (win->odeSim->getNumSystems() == 0)
	{
		fltk::alert("No articulated object connected to this simulator.\nPlease create one first.");
		return;
	}

	const char* filename = fltk::file_chooser("Choose a file to save the ODE source code:", NULL, "rigidbody.cpp");
	if (filename != NULL)
	{
		ArticulatedObject* ao = (ArticulatedObject*) win->odeSim->getSystem(0);
		if (win->odeSim->writeODESourceCode((char*) filename, ao))
		{
			fltk::alert("ODE source code has been written to file '%s'.", filename);
		}
		else
		{
			fltk::alert("Problem writing ODE source code. No code written.", filename);
		}
	}
}



