/**************************************************************************
	D.A.N.C.E.
	Dynamic AnimatioN and Control Environment
	----------------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
-----------------------------------------------
	
 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

 This software is distributed for noncommercial use in the hope that it will 
 be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
 to anyone for the consequences	of using it or for whether it serves any 
 particular purpose or works at all. No warranty is made about the software 
 or its performance. Commercial use is prohibited.
***************************************************************************/

#ifndef _ODESIMMANAGERWINDOW_
#define _ODESIMMANAGERWINDOW_

#include <fltk/Window.h>
#include <fltk/Input.h>
#include <fltk/Button.h>
#include <fltk/MultiBrowser.h>
#include <fltk/Widget.h>

class ODEManager;

class ODEManagerWindow : public fltk::Group
{
	public:
		ODEManagerWindow(ODEManager* mgr, int x, int y, int w, int h, const char* name);

		void show();
		void updateGUI();

		static void SystemChangeCB(Widget* widget, void* data);
		static void GeometrySimulateCB(fltk::Widget* widget, void* data);
		static void RefreshCB(fltk::Widget* widget, void* data);

		fltk::Input* inputTimeStep;
		fltk::MultiBrowser* browserSystems;
		fltk::Button* buttonAddGeometry;
		fltk::Button* buttonRefresh;
		fltk::MultiBrowser* browserGeometries;

	private:
		ODEManager* manager;

};


#endif

