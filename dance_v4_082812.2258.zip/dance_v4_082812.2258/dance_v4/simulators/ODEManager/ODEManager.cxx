/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "ODEManager.h"
#include "ArticulatedObject.h"
#include "Joint.h"
#include "Link.h"
#include "ODESim.h"
#include "DSimulatorManager.h"
#include "dance.h"

PlugIn* Proxy()
{
	return new ODEManager();
}

PlugIn* ODEManager::create(int argc, char **argv)
{
	ODEManager* t = new ODEManager();

	return t;
}

ODEManager::ODEManager()
{
	windowManager = NULL;
}

ODEManager::~ODEManager()
{
	if (windowManager != NULL)
		delete windowManager;
}

int ODEManager::commandPlugIn(int argc, char **argv)
{
	int ret = PlugIn::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

	if (strcmp(argv[0], "simulate") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: %s simulator <geometry> <aoName> <simName>");
			return DANCE_ERROR;
		}

		// get the geometry
		DGeometry* geom = (DGeometry*) dance::AllGeometry->get(argv[1]);
		if (geom == NULL)
		{
			danceInterp::OutputMessage("Geometry %s was not found.", argv[1]);
			return DANCE_ERROR;
		}

		simulateGeometry(geom, argv[2], argv[3]);
		danceInterp::OutputMessage("Geometry %s is now simulated. System '%s' and Simulator '%s' has been created.", argv[1], argv[2], argv[3]);

		return DANCE_OK;
	}

	return DANCE_CONTINUE;
}


void ODEManager::simulateGeometry(DGeometry* geometry, char* aoName, char* simName)
{
	// create an articulated object for that geometry
	ArticulatedObject* ao = new ArticulatedObject();
	ao->setName(aoName);
	ao->setPlayback(true);
	ao->setRecording(true);

	dance::AllSystems->add(ao);

	// create a free joint and associated link for this rigid body
	Link* link = new Link(0);
	link->setName("root");
	ao->addLink(link);

	Joint* joint = new Joint();
	joint->setName("root");
	joint->setInboardLink(NULL);
	joint->setOutboardLink(link);
	joint->setJointType(J_FREE);
	link->setParentJoint(joint);
	ao->addJoint(joint);
	Vector endEffector = {0.0, 0.5, 0.0};
	link->setEndEffector(endEffector);

	// set the XYZ location of the system
	// (at the center of the geometry)
	BoundingBox box;
	geometry->calcBoundingBox(&box);
	Vector center;
	box.getMidPoint(center);
	if (geometry->useTransMatrix())
	{
		double matrix[4][4];
		geometry->getTransMatrix(matrix);
		transformPoint_mat(center, matrix);
	}
	for (int x = 0; x < 3; x++)
		ao->setState(x, center[x]);

	link->replaceGeometry(geometry, true);
	// add some monitor points for easy collisions with the ground
	link->assignMonitorPoints(30);

	// attach an ODESim to this system
	ODESim* odesim = new ODESim();
	odesim->setName(simName);
	dance::AllSimulators->add(odesim);
	odesim->addSystem(ao);

	dance::AllViews->postRedisplay();
}


fltk::Widget* ODEManager::getInterface()
{
	if (windowManager == NULL)
	{
		windowManager = new ODEManagerWindow(this, 10, 10, 300, 400, this->getName());
	}

	return windowManager;
}

void ODEManager::save(int mode, std::ofstream& file)
{
	if (mode == 0)
	{
		file << "dance.instance(\"ODEManager\", \"" << this->getName() << "\")" << std::endl; 
	}

	PlugIn::save(mode, file);
}

int ODEManager::getNumPluginDependents()
{
	return 2;
}

const char* ODEManager::getPluginDependent(int num)
{
	if (num == 0)
		return "ArticulatedObject";
	else if (num == 1)
		return "ODESim";
	else
		return NULL;
}




