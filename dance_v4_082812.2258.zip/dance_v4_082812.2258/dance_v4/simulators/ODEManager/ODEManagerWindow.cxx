/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "ODEManagerWindow.h"
#include "ODEManager.h"
#include <fltk/Group.h>
#include <fltk/CheckButton.h>
#include <fltk/Widget.h>
#include <fltk/ask.h>
#include "ODESim.h"
#include "dance.h"
#include "ViewManager.h"
#include "ArticulatedObject.h"
#include "Link.h"
#include "Joint.h"

using namespace fltk;

ODEManagerWindow::ODEManagerWindow(ODEManager* mgr, int x, int y, int w, int h, const char* name) : Group(x, y, w, h, name)
{
	manager = mgr;

	this->begin();

	Group* groupSystems = new Group(10, 10, 300, 200, "Controlled Systems");
	groupSystems->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);

	groupSystems->begin();

	browserSystems = new MultiBrowser(10, 20, 200, 100);

	groupSystems->end();

	Group* groupGeometries = new Group(10, 180, 300, 200, "Geometries");
	groupGeometries->align(ALIGN_INSIDE | ALIGN_TOP | ALIGN_LEFT);
	groupGeometries->begin();

	browserGeometries = new MultiBrowser(10, 20, 200, 100);

	buttonAddGeometry = new Button(60, 120, 120, 20, "Convert Geometry");

	groupGeometries->end();

	buttonRefresh = new Button(10, 410, 60, 20, "Update");
	buttonRefresh->callback(RefreshCB, this);

	this->end();


	this->updateGUI();
}

void ODEManagerWindow::show()
{
	this->updateGUI();

	Group::show();
}

void ODEManagerWindow::updateGUI()
{
	browserSystems->clear();
	browserGeometries->clear();

	// add all articulated objects
	for (int x = 0; x < dance::AllSystems->size(); x++)
	{
		ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get(x));
		if (ao != NULL)
		{
			// is this articulated object already simulated by an ODE simulator?
			bool found = false;
			for (int x = 0; x < ao->getNumSimulators(); x++)
			{
				DSimulator* sim = ao->getSimulator(0);
				ODESim* odesim = dynamic_cast<ODESim*>(sim);
				if (odesim != NULL)
				{
					found = true;
					break;
				}
			}
			CheckButton* check = new CheckButton(0, 0, browserSystems->w() - 20, 20, ao->getName());
			check->callback(SystemChangeCB, this);

			if (found)
				check->value(1);

			browserSystems->add(check);
		}
	}

	// add all loose geometry that is not a link of another articulated object
	for (int x = 0; x < dance::AllGeometry->size(); x++)
	{
		DGeometry* geom = dynamic_cast<DGeometry*>(dance::AllGeometry->get(x));
		// make sure this geometry is not a link of any articulated object
		bool alreadyUsed = false;
		for (int x = 0; x < dance::AllSystems->size(); x++)
		{
			ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get(x));
			if (ao != NULL)
			{
				Link** links = ao->getLinks();
				for (int l = 0; l < ao->getNumLinks(); l++)
				{
					if (links[l]->getGeometry() == geom || links[l]->getGeometryCollision() == geom)
					{
						alreadyUsed = true;
						break;
					}
				}
				if (alreadyUsed)
					break;
			}
		}
		if (!alreadyUsed)
		{
			Widget* widget = new Widget(0, 0, browserGeometries->w() - 20, 20, geom->getName());
			widget->callback(GeometrySimulateCB, this);

			browserGeometries->add(widget);
		}
	}
 
}

void ODEManagerWindow::SystemChangeCB(Widget* widget, void* data)
{
	CheckButton* check = (CheckButton*) widget;
	ODEManagerWindow* win = (ODEManagerWindow*) data;

	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get((char*) check->label()));

	if (ao == NULL)
	{
		danceInterp::OutputMessage("Cannot find articulated object with name %s.", check->label());
		return;
	}

	if (check->value())
	{
		if (fltk::ask("Are you sure you want to simulate '%s' with ODE?", ao->getName()))
		{
			// create a new ODE simulator to simulate this articulated object
			ODESim* odesim = new ODESim();
			dance::AllSimulators->add(odesim);
			odesim->addSystem(ao);
		}
		else
		{
			check->value(0);
		}
	}
	else
	{
		if (fltk::ask("Are you sure you want to remove the ODE simulator from '%s'?", ao->getName()))
		{
			// remove the old simulator
			ODESim* odesim = dynamic_cast<ODESim*>(ao->getSimulator(0));
			if (odesim == NULL)
			{
				danceInterp::OutputMessage("ODE Simulator not found on articulated object %s", ao->getName());
				return;
			}
			else
			{
				ao->removeSimulator(odesim);
				dance::AllSimulators->remove(odesim);
			}
		}
		else
		{
			check->value(1);
		}
	}

	win->updateGUI();
	dance::AllViews->postRedisplay();
}

void ODEManagerWindow::GeometrySimulateCB(Widget* widget, void* data)
{
	ODEManagerWindow* win = (ODEManagerWindow*) data;

	DGeometry* geom = (DGeometry*) dance::AllGeometry->get((char*) widget->label());
	if (geom == NULL)
	{
		danceInterp::OutputMessage("No geometry with name %s found.", widget->label());
		return;
	}

	int ok = fltk::ask("Are you sure that you want to create a system and simulate this geometry?");
	if (!ok)
		return;

	char aoname[512];
	sprintf(aoname, "%s_system", geom->getName());
	char simname[512];
	sprintf(simname, "%s_simulator", geom->getName());
	win->manager->simulateGeometry(geom, aoname, simname);

	// show the interface for the system and simulator
	DSystem* sys = (DSystem*) dance::AllSystems->get(aoname);
	Widget* w1 = sys->getInterface();
	dance::rootWindow->parameterWindow->addInterface(w1, aoname);

	DSimulator* sim = (DSimulator*) dance::AllSimulators->get(simname);
	Widget* w2 = sim->getInterface();
	dance::rootWindow->parameterWindow->addInterface(w2, simname);

	win->updateGUI();
	dance::AllViews->postRedisplay();

}

void ODEManagerWindow::RefreshCB(fltk::Widget* widget, void* data)
{
	ODEManagerWindow* win = (ODEManagerWindow*) data;

	win->updateGUI();
}

