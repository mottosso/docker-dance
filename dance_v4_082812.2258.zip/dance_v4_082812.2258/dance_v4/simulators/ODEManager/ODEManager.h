/**************************************************************************
	D.A.N.C.E.
	Dynamic AnimatioN and Control Environment
	----------------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
-----------------------------------------------
	
 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

 This software is distributed for noncommercial use in the hope that it will 
 be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
 to anyone for the consequences	of using it or for whether it serves any 
 particular purpose or works at all. No warranty is made about the software 
 or its performance. Commercial use is prohibited.
***************************************************************************/

#ifndef _ODEMANAGER_H_
#define _ODEMANAGER_H_

#include "PlugIn.h"
#include "ODEManagerWindow.h"
#include <fstream>

class ODEManager : public PlugIn
{
	public:
		PlugIn* create(int argc, char **argv);

		ODEManager();	
		~ODEManager();

		int  commandPlugIn(	int argc, char **argv);
		fltk::Widget* getInterface();

		void simulateGeometry(DGeometry* geometry, char* aoName, char* simName);

		void save(int mode, std::ofstream& file);
		int getNumPluginDependents();
		const char* getPluginDependent(int num);

	private:
		ODEManagerWindow* windowManager;

};

#endif

