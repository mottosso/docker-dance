#include "SimulStateManager.h"
#include "danceTcl.h"
#include "dance.h"
#include "DActuator.h"

SimulStateManager::SimulStateManager()
{
	m_sim = NULL;
	m_obj = NULL;
	m_rate = .01;
	m_maxStates = 1000;
	m_curIndex = 0;
	m_minTime = 0.0;
	m_maxTime = 0.0;
	m_startIndex = -1;
	m_lastTimeSaved = -1;
	m_maxSaveIndex = -1;
}



SimulStateManager::~SimulStateManager()
{
	for (unsigned int x = 0; x < m_savedStates.size(); x++)
		delete m_savedStates[x];
}

void SimulStateManager::setSimulator(SdfastSimul* sim)
{
	m_sim = sim;
	for (int x = 0; x < m_maxStates; x++)
		m_savedStates.push_back(new SimulState(sim));
}

void SimulStateManager::setArticulatedObject(ArticulatedObject* obj)
{
	m_obj = obj;
}

void SimulStateManager::saveStateConditional(double time)
{
	if (m_sim == NULL)
		return;

	if (m_lastTimeSaved < 0 || (time >= m_lastTimeSaved + m_rate))
		saveState();

}

void SimulStateManager::saveState()
{
	if (m_obj == NULL)
		return;

	double time = m_sim->GetTime();
	

	int i = getNextSaveIndex(time, true);
	m_savedStates[i]->setState(time, m_obj);
	m_maxTime = time;
	m_lastTimeSaved = time;
//	danceTcl::OutputMessage("START = %d CUR = %d MAX = %d\n", m_startIndex, m_curIndex, m_maxSaveIndex);
}

SimulState* SimulStateManager::loadState(double time)
{
	danceTcl::OutputMessage("Attempting to restore to time %f\n", time);
	if (m_savedStates[m_maxSaveIndex]->getTime() < time)
	{
		danceTcl::OutputMessage("Cannot return to time > %f\n", m_savedStates[m_maxSaveIndex]->getTime());
		return m_savedStates[m_maxSaveIndex];
	}
	// find the time closest to the time desired
	SimulState* state = NULL;
	double diff = 9999999999;

	int i = getNextSaveIndex(time, false);
	state = m_savedStates[i];

	m_sim->SetTime(state->getTime());

	// copy the stored state to the simulator
	ArticulatedObject *artObj = state->getObject();
	int stateSize = artObj->getStateSize();
	for (int x = 0; x < stateSize; x++)
	{
//		danceTcl::OutputMessage("Now setting state[%d] to %f\n", x, state->getState(x));
		m_sim->m_state[x] = state->getState(x);
		m_sim->m_dstate[x] = state->getState(x + stateSize);
		m_sim->m_state[x + stateSize] = m_sim->m_dstate[x];
	}

	// set the object state
	// Loop through all	joints and set the state vector
	Joint **joint =  artObj->getJoints();
	if (joint == NULL)
	{
		danceTcl::OutputMessage("Could	not find joints	for object\n");
		return NULL;
	}

	int	m, dof, n;
	for	( m = 0; m < artObj->getNumJoints(); m++)
	{
		dof = joint[m]->getStateSize();

		for (n	= 0; n < dof; n++)
		{
			joint[m]->setState(n, m_sim->m_state[m_sim->sdindx(m,n)], TRUE);
		}
	}
	m_obj->updateStateConfig() ;


	// Update all actuators
	for (m = 0; m < dance::AllActuators->size(); m++)
	{
		DActuator *act = (DActuator *)dance::AllActuators->get(m);
		act->afterObjectUpdate(m_obj);
	}

	m_lastTimeSaved = state->getTime();

	return state;

}

void SimulStateManager::setRate(double rate)
{
	m_rate = rate;
}

double SimulStateManager::getRate()
{
	return m_rate;
}

void SimulStateManager::cleanUp(double time)
{
/*	danceTcl::OutputMessage("Cleaning up saved states after time %f...", time);
	// removes all state values with t > time
	bool flag = (m_startIndex <= m_curIndex);
	int cur = m_curIndex - 1;

	while (m_startIndex != m_curIndex)
	{
		if (flag)
		{
			if (cur >= m_startIndex)
			{
				if (m_savedStates[cur]->getTime() > time)
				{
					danceTcl::OutputMessage("Cleared state at time %f", m_savedStates[cur]->getTime());
					m_savedStates[cur]->clear();
					m_curIndex = cur;
				}
				cur--;
			}
		}
		else
		{
			if (cur >= 0)
			{
				if (m_savedStates[cur]->getTime() > time)
				{
					danceTcl::OutputMessage("Cleared state at time %f", m_savedStates[cur]->getTime());
					m_savedStates[cur]->clear();
					m_curIndex = cur;
				}
				cur--;
			}
			if (cur < 0)
				cur = m_savedStates.size() - 1;
		}
		flag = (m_startIndex <= m_curIndex);
	} 
	m_lastTimeSaved = time;
*/
}

int SimulStateManager::getNextSaveIndex(double time, bool overwrite)
{
	if (m_startIndex == -1)
	{
		m_startIndex = 0;
		m_curIndex = 0;
		m_maxSaveIndex = 0;
		return m_curIndex;
	}
	
	int i = m_maxSaveIndex;

	if (m_savedStates[i]->getTime() < time)
	{
		i++;
		if (i >= m_maxStates)
		{
			i = 0;
		}
		if (i == m_curIndex)
			i++;
		if (overwrite)
			m_maxSaveIndex = i;
		m_curIndex = i;
		return m_curIndex;
	}
	else
	{
		while (m_savedStates[i]->getTime() > time)
		{
			if (m_startIndex == i)
			{
				if (overwrite)
					m_maxSaveIndex = i;
				m_curIndex = i;
				return m_curIndex;
			}
			i--;
			if (i < 0)
				i = m_maxStates - 1;
		}
		if (overwrite)
			m_maxSaveIndex = i;
		m_curIndex = i;
		return m_curIndex;
	}
}

