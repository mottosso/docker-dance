/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include <ctype.h>
#include <cassert>
#include <cstdio>
#include <cstdlib>
#ifdef WIN32
#include "windlfcn.h"
#else
#include <dlfcn.h>
#endif

#include "defs.h"
#include "DView.h"
#include "dance.h"
#include "danceInterp.h"
#include "DActuator.h"
#include "DSystem.h"
#include "ArticulatedObject.h"
#include "SdfastSimul.h"
#include "DSimulatorManager.h"
#include "Joint.h"
#include "Link.h"
#include <fltk/glut.h>
#include "AnimationSequence.h"
#include "KeyFrame.h"
#include "SdfastSimulWindow.h"

// called from sdfast code
extern "C" {
DLLEXPORT void (*sduforce)(double,  double *, double *)	= SdfastSimul::Defaultuforce ;
DLLEXPORT void (*sdumotion)(double,  double *, double *) = SdfastSimul::Defaultumotion ;
DLLEXPORT void (*sduperr)(double, double *, double *) =	SdfastSimul::PosError;
DLLEXPORT void (*sduverr)(double, double *, double *, double *)	= SdfastSimul::VelError;
DLLEXPORT void (*sduaerr)(double, double *, double *, double *,	double *) = SdfastSimul::AccError;
DLLEXPORT void (*sduconsfrc)(double, double *, double *, double	*) = SdfastSimul::ConstraintForces;
	   }

// put here initializers for all global	variables
double DT = 0.001 ;
double CTol = 0.01;
double TOl = 0.1 ;

//static int COllisions =	TRUE ;

SdfastSimul* SdfastSimul::currentSimulator = NULL;

PlugIn *Proxy()
{
	return new SdfastSimul;
}

PlugIn *SdfastSimul::create(int argc, char **argv)
{
   
    DSystem *ao = NULL;
	if (argc > 0)
	{
		ao = (DSystem *) dance::AllSystems->get(argv[0]) ;
		if( ao == NULL ) 
		{
			danceInterp::OutputMessage("No such object: %s", argv[0]) ;
			return NULL ;
		}
	}
	
	SdfastSimul *f = new SdfastSimul();
	if (ao != NULL)
	{
		f->addSystem(ao);
		if (argc > 1)
		{
			if (!f->Load(argv[1]))
			{
				danceInterp::OutputMessage("Could not load articulated object of type %s", argv[1]);
				return NULL ;
			}
		}
	}

    return f ;
}

// end called from sdfast code

// called from lsodes
//DLLEXPORT void (*CalcDeriv)(double *y, double *dy,  double *t) = SdfastSimul::LsodesCalcDeriv ;

SdfastSimul::SdfastSimul() : DSimulator()
{
    setType("SdfastSimul") ;
    setName("");
	tol	= 0.2 ;
    m_lock = NULL ;   
    m_time = 0.0 ;
    m_isLoaded = FALSE ;
    handle = NULL ;
    m_end	= 100.0 ;
    fixedStep = TRUE ;
    m_integrator = 0 ;

    nbod = 0 ;
    njnt = 0 ;
    ndof = 0 ;
    nloop = 0 ;
    nldof = 0 ;
    nq = 0 ;
    nu = 0 ;
    nlq = 0 ;
    nlu = 0 ;
    nc = 0 ;
    nlc = 0 ;
    npresc = 0 ;
    nuserc = 0 ; 

    m_iwork = NULL ;
    m_rwork = NULL ;
    m_liw = 0 ;
    m_lrw = 0 ;
    m_istate = 1 ;

    danceInterp::OutputMessage("==========================================") ;
    danceInterp::OutputMessage("Dynamics provided by Symbolic Dynamics Inc.") ;
    danceInterp::OutputMessage("==========================================") ;

	currentSimulator = NULL;
	this->setShowBodyPositions(false);
	m_simWin = NULL;

	m_state = NULL;
	m_dstate = NULL;
	m_initVel = NULL;
}

SdfastSimul::~SdfastSimul()
{
  if (m_initVel != NULL )
	 delete [] m_initVel ;
  if (m_state != NULL )
	  ; // problem deleting state. Allocated in different memory space?
		// currently causes a memory leak. Fix this. AS 5/24/05
    //delete [] m_state	;
  if (m_lock != NULL)
    delete [] m_lock;
  if(	handle != NULL )
  {
    dlclose(handle)	;
    handle = NULL ;
  }
}

void SdfastSimul::output(int mode)
{
	if (isShowBodyPositions())
	{
		ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0);
		if( !ao )
		{
			return;
		}
		int numLinks = ao->getNumLinks();
		Vector zero = {0.0, 0.0, 0.0};

		glPushAttrib(GL_LIGHTING_BIT | GL_DEPTH_BUFFER_BIT);
		glEnable(GL_DEPTH_TEST);
		glPointSize(7.0);

		glColor3f(1.0, 0.0, 0.0);
		glDisable(GL_LIGHTING);
		glPushMatrix();
		glBegin(GL_POINTS);
		for (int x = 0; x < numLinks; x++)
		{
			glColor3f(1.0, 0.0, 0.0);
			Vector pos;
			this->GetPosition(x, zero, pos);
			glVertex3d(pos[0], pos[1], pos[2]);
		}
		glEnd();
		glPopMatrix();
		glPopAttrib();
	}
}

int SdfastSimul::Step(DSystem *sys, double destTime)
{
	double dt = this->getTimeStep();
	
//	if ((m_time + dt > destTime) && (dt != 0))
//		dt = destTime - m_time ;
 
	int numAOs = this->getNumSystems();
	if (numAOs == 0)
		return 0;

	//ArticulatedObject* artObj = (ArticulatedObject*) this->getSystem(0);

	double mainDt = dance::AllSimulators->getSimulationTimeStep();
	while (m_time < destTime + mainDt)
	{
		SdfastSimul::currentSimulator = this;

		if( fixedStep == TRUE )	// fixed step integrator
		{
			if( m_integrator == 1 )
				EulerInteg(&m_time,m_state,m_dstate,dt,ctol,&flag,&errest,&err) ;
			else
				(*sdfmotion)(&m_time,m_state,m_dstate,dt,ctol,&flag,&errest,&err) ;
			
		}
		else			// variable step integrator
			(*sdmotion)(&m_time,m_state,m_dstate,dt,ctol,tol,&flag,&err) ;
		m_time += dt;
	}
	if (err == 0)
	{
		return 1;
	}
	if (err == 1)
	{
			danceInterp::OutputMessage("sdmotion: went over a step at time: %f\n",m_time);
		return 2;
	}
	if (err == 2)
		danceInterp::OutputMessage("sdmotion: can't	continue (lock-up), time: %f\n",m_time);
	if (err == 3)
		danceInterp::OutputMessage("sdmotion: can't	continue (constraint-violated),	time: %f\n",m_time);

	// Pause simulation if something went wrong
	if( err > 2 )
	//			ao->isSimul	= FALSE;
		danceInterp::OutputMessage("Problem during simulation...");
	
  return 1 ;
}

// does	the compilation	of the name.sd file to produce the shared object
int SdfastSimul::MakeCompile(char nameObj[])
{
    char precommand[MAX_LINE] ;
    sprintf(precommand,"cd %s/sdfastobjs",getenv("DANCE_DIR"));
	danceInterp::OutputMessage("No auto-make on windows.");
	return OK;
}

// clean up at end of simulation
int SdfastSimul::Stop()
{
    return DANCE_OK ;
}


// PROC:  Start() previously called init()
// DOES:  initializes the simulator to start from the begining.
// If the dynamically loaded quantities	are not	loaded
// then	it attempts to load them, allocate state vectors and bind some functions
int SdfastSimul::Start(double time)
{
    err	= 0 ;
    errest = 0.0 ;
    flag = 1 ;
    m_time = time ;

	if (this->getNumSystems() == 0)
		return ERR;

	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0);

	this->createStateMapping();

    SetStateFromObjectState(ao);


    if( m_isLoaded == FALSE )
    {
		if( Load() == ERR ) 
			return ERR ;
    }
    else
    {
		sdinit() ;		  // initialize	sdfast
		double useTimeStep = dance::AllSimulators->getSimulationTimeStep();
		if (!this->isUseMainTimeStep())
		{
			useTimeStep = this->getTimeStep();
		}
		danceInterp::OutputMessage("Parameters for simulation dt = %lf time = %lf tol = %lf\n",
					useTimeStep,
					m_time,
					tol) ;
		
		assemblyAnalysis();
		initVelocityAnalysis();
    }
    // initialize various quantities
//    initSdState();

    // flag not to use the base code of StartBase, StepBase, StopBase.
    //    m_ignoreBase = TRUE ;

    
    //ao->InitSimulation(time, this) ;
    
    // Initialize the actuators and pass them the object that owns this simulator
   //    for	(i=0; i < dance::AllActuators->size(); i++)	{
//    	DActuator *wact = (DActuator *)dance::AllActuators->get(i);
//    	wact->InitSimul(ao, m_time) ;
//        }

    return OK ;
}

int SdfastSimul::bindPointers(char* objType)
{
    char fileName[MAX_LINE] ;
    char prefix[MAX_LINE] ;
    char routine[MAX_LINE] ;

    strcpy(prefix,objType) ;
    // construct the file name <name>.dll
#ifdef WIN32
#ifdef _DEBUG
	sprintf(fileName,"%s/plugins/win/%s_d.dll",getenv("DANCE_DIR"), objType) ;
#else
	sprintf(fileName,"%s/plugins/win/%s.dll",getenv("DANCE_DIR"), objType) ;
#endif
#else
#ifdef _MACOSX_
	sprintf(fileName,"%s/plugins/osx/%s.so",getenv("DANCE_DIR"), objType) ;
#else
	sprintf(fileName,"%s/plugins/linux/%s.so",getenv("DANCE_DIR"), objType) ;
#endif
#endif
	danceInterp::OutputMessage("Retrieving %s...");

    dlerror() ;	dlerror() ;	// clear the error messages
    if(	handle != NULL ) dlclose(handle) ;
    handle = dlopen(fileName, RTLD_NOW);
    if(	handle == NULL )
    {
		char* errorMsg = dlerror();
		danceInterp::OutputMessage("Error opening |%s|! %s\n", fileName, errorMsg) ;
		danceInterp::OutputMessage("%s\n", dlerror()) ;
		return ERR ;
    }
    else
		danceInterp::OutputMessage("Successfully linked in %s\n",fileName);
	strcpy(sdType, objType);

    // ----------------------------------------------------
    // bind some of the	function pointers
    // ----------------------------------------------------
    sprintf(routine,"%sinit", prefix) ;
    if ((sdinit	= (void	(*) () ) dlsym(handle,routine)) == NULL)
    {
	  danceInterp::OutputMessage("Cannot load routine!\n") ;
	  danceInterp::OutputMessage("%s\n", dlerror()) ;
	  return ERR ;
    }

    sprintf(routine,"%sgrav",prefix);
    if ((sdgrav	= (void	(*) (double *) ) dlsym(handle,routine))	== NULL)
    {
	  danceInterp::OutputMessage("Cannot load routine!\n") ;
	  danceInterp::OutputMessage("%s\n", dlerror()) ;
	  return ERR ;
    }

    sprintf(routine,"%sprinterr",prefix);
    if ((sdprinterr = (void (*)	(FILE *) ) dlsym(handle,routine)) == NULL)
    {
	  fprintf(stderr,"Cannot load sdprinterr routine!\n") ;
	  danceInterp::OutputResult("%s\n", dlerror()) ;
	  return ERR ;
    }

    sprintf(routine,"%sstate", prefix) ;
    if((sdstate	= (void	(*) (double, double*, double *)) dlsym(handle,routine))	== NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }
    sprintf(routine,"%sderiv", prefix) ;
    if((sdderiv	= (void	(*) (double*, double *)) dlsym(handle,routine))	== NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }
    sprintf(routine,"%sstatic",	prefix)	;
    if((sdstatic = (int	(*) (double, double*, int *, double,
		double,	int, int *, int	*)) dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load sdstatic routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%ssteady",	prefix)	;
    if((sdsteady = (int	(*) (double, double*, int *, double,
		double,	int, int *, int	*)) dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load sdsteady routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }


    sprintf(routine,"%sang2st",	prefix)	;
    if((sdang2st = (void (*) (double*, double *)) dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%sgetbtj",	prefix)	;
    if((sdgetbtj = (void (*) (int, double*)) dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%sindx", prefix);
    if((sdindx = (int (*) (int,	int)) dlsym(handle,routine)) ==	NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%sjnt", prefix);
    if((sdjnt =	(void (*) (int,	int *, int *)) dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%sitj", prefix) ;
    if((sditj =	(void (*) (int,	double *)) dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%sfmotion", prefix) ;
    if((sdfmotion = (int (*) (double *,	double *, double *, double, double, int	*,double *, int	*))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

	sprintf(routine, "%smotfunc", prefix) ;
	if( (sdmotfunc = (int (*) (double,double *,double *,double *, int *)) dlsym(handle,routine)) == NULL )
	{
		danceInterp::OutputMessage("Cannot load routine!\n") ;
		danceInterp::OutputMessage("%s\n", dlerror()) ;
		return ERR ;
	}

    sprintf(routine,"%smotion",	prefix)	;
    if((sdmotion = (int	(*) (double *, double *, double	*, double, double, double, int *, int *))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load sdmotion routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%sacc", prefix) ;
    if((sdacc =	(void (*) (int,	double *, double *))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load sdacc routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%spos", prefix) ;
    if((sdpos =	(void (*) (int,	double *, double *))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load sdpos routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%strans", prefix) ;
    if((sdtrans	= (void	(*) (int,  double *, int, double *))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

  sprintf(routine,"%serror", prefix) ;
  if((sderror = (void (*)(int *routine, int *errnum))dlsym(handle,routine)) == NULL)
  {
    danceInterp::OutputMessage("Cannot load sderror routine!\n") ;
    danceInterp::OutputMessage("%s\n", dlerror()) ;
    return ERR ;
  }

    sprintf(routine,"%sassemble", prefix) ;
    if((sdassemble = (int (*) (double,	double *, int *, double, int, int *, int *))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load sdassemble routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%sinitvel", prefix) ;
    if((sdinitvel = (int (*) (double,  double *, int *,	double,	int, int *, int	*))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load sdinitvel routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%spointf",	prefix)	;
    if((sdpointf = (void (*) (int,  double *, double *))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%shinget",	prefix)	;
    if((sdhinget = (void (*) (int,  int, double))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%sbodyt", prefix) ;
    if((sdbodyt	= (void	(*) (int, double *))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%svel", prefix) ;
    if((sdvel =	(void (*) (int,	 double	*, double *))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    sprintf(routine,"%sstab", prefix) ;
    if((sdstab = (void (*) (double , double ))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load sdstab routine!\n")	;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }



    sprintf(routine,"%spresvel", prefix) ;
    if((sdpresvel = (void (*) (int, int, double))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }
    sprintf(routine,"%sprespos", prefix) ;
    if((sdprespos = (void (*) (int, int, double))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }
    sprintf(routine,"%spresacc", prefix) ;
    if((sdpresacc = (void (*) (int, int, double))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }
    sprintf(routine,"%spres", prefix) ;
    if((sdpres = (void (*) (int, int, int))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }
    sprintf(routine,"%sfinteg", prefix) ;

	sdfinteg = (void (*)(void (*func) (double,double *,double *,double *,int *), 
			   double *time, double *st, double *dst, double *param, 
			   double step, int neq, double *work, double *errest, int *status))
	dlsym(handle,routine);

    if(sdfinteg == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }
    sprintf(routine,"%srel2cart", prefix) ;
    if((sdrel2cart = (void (*) (int, int, double *, double *, double *))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }
    sprintf(routine,"%slsslv", prefix) ;
    if((sdlsslv	= (void	(*) (int, int, int, int, int,
			     int *, int	*, double, double *,
			     double *, int *, double *,	double *, double *))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }
	sprintf(routine,"%sgetht", prefix) ;
    if((sdgetht = (void	(*) (int, int, double *))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }
	sprintf(routine,"%scomptrq", prefix) ;
    if((sdcomptrq = (void	(*) (double*, double *))
	dlsym(handle,routine)) == NULL)
    {
	danceInterp::OutputMessage("Cannot load routine!\n") ;
	danceInterp::OutputMessage("%s\n", dlerror()) ;
	return ERR ;
    }

    //  sprintf(routine,"%sMyderiv", prefix) ;
//      if((myDeriv	= (void	(*)(double time, double *state, double *dstate, 
//  			    double *param, int *status))
//  	dlsym(handle,routine)) == NULL)
//      {
//  	danceInterp::OutputMessage("Cannot load routine!\n") ;
//  	danceInterp::OutputMessage("%s\n", dlerror()) ;
//  	return ERR ;
//      }
    
	danceInterp::OutputMessage("Finished linking to %s...", fileName);
    return OK ;
}

// initialize to zero and normalize the	quaternions in the state
void SdfastSimul::initSdState()
{
	/*
  ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0);
 
  int stateSize = ao->getStateSize();

  double* aoState = new double[nq+nu];
  ao->getState(aoState);

  // convert the system state to the simulation state
  // positions
  for (int x = 0; x < stateSize; x++)
	  m_state[x] = aoState[this->convertIndexSimtoAO(x)];

  // velocities
  // should calculate initial velocities from old position values!
  for (int x = stateSize; x < stateSize * 2; x++)
	  m_state[x] = m_dstate[x] = 0.0;

  for (int i = 0 ; i < nu ; i++ )
    m_initVel[i] = 0.0 ;

//	m_state[3] = 1.5;
//	m_state[4] = 0;
//	m_state[5] = 0;
  (*sdang2st)(m_state,m_state) ;
	danceInterp::OutputMessage("***** SIM STATE AFTER SDANG");
	for (int x = 0; x < GetStateSize(); x++)
		danceInterp::OutputMessage("SIM STATE [%d] = %f", x, m_state[x]);
	danceInterp::OutputMessage("***** SIM DSTATE AFTER SDANG");
	for (int x = 0; x < GetStateSize(); x++)
		danceInterp::OutputMessage("SIM STATE [%d] = %f", x, m_dstate[x]);
*/
}

// SetObjectStateFromState previously called setJointsFromStateVector:
//	Sets the joints	from the state vector.
//
int SdfastSimul::SetObjectStateFromState(DSystem *sys)
{
	// Loop through all	joints and set the state vector.
	ArticulatedObject *artObj = (ArticulatedObject *) sys ;
	Joint **joint =  artObj->getJoints();
	if (joint == NULL)
		danceInterp::OutputMessage("Could	not find joints	for object\n");

	int dof, n;
	for	(int i = 0; i < artObj->getNumJoints(); i++)
	{
		dof = joint[i]->getStateSize();

		for (n	= 0; n < dof; n++)
		{
			joint[i]->setState(n,m_state[(*sdindx)(i,n)], TRUE);
		}
	}

	return 1 ;
}

int SdfastSimul::SetStateFromObjectState(DSystem *sys)
{
    ArticulatedObject *artObj = (ArticulatedObject *) sys ;
    // Loop through all	joints and set the state vector.
    Joint **joint =  artObj->getJoints();
    if (joint == NULL)
	  danceInterp::OutputMessage("Could	not find joints	for object\n");

	// set the joint positions & velocities
	// set velocities if they exist
	AnimationSequence* anim = artObj->getAnimationSequence();
	KeyFrame* prev = anim->getKeyFrame(dance::AllSimulators->getCurrentTime() - artObj->getRecordStep());
	int curIndex = 0; // artobj state index
    int	dof;
    for	(int i = 0; i < artObj->getNumJoints(); i++)
	{
		dof = joint[i]->getStateSize();
		for ( int n = 0; n < dof; n++)
		{
			m_state[(*sdindx)(i,n)] = joint[i]->getState(n);
			if (joint[i]->hasVelocity())
			{
				m_state[nq + (*sdindx)(i, n)] = m_dstate[(*sdindx)(i, n)] = joint[i]->getDState(n);
			}
			else
			{
				if (prev == NULL)
				{
					m_state[nq + (*sdindx)(i, n)] = m_dstate[(*sdindx)(i, n)] = 0.0;
				}
				else
				{ // simple (and incorrect) velocity calculation based on one previous value
						m_state[nq + (*sdindx)(i, n)] = m_dstate[(*sdindx)(i, n)] = (m_state[(*sdindx)(i, n)] - prev->getParam(curIndex)) /  (dance::AllSimulators->getCurrentTime() - prev->getTime());				
				}
			}
			curIndex++;
		}
		if (joint[i]->hasVelocity())
			joint[i]->setHasVelocity(false);
    }

	sdstate(m_time, m_state, m_dstate) ;

	this->assemblyAnalysis();
	this->initVelocityAnalysis();

    return 1 ;
}

void SdfastSimul::assemblyAnalysis()
{
	int fcnt, err;
	sdassemble(m_time,m_state,m_lock,ctol,MAXEVALS,&fcnt,&err);

	if (err	== 0)
	    danceInterp::OutputMessage("assembly: succeeded at constraint tolerance: %f\n",ctol);
	else if (err	== 1)
	    danceInterp::OutputMessage("assembly: Local minimum reached in assembly.\n");
	else if (err	== 2)
	    danceInterp::OutputMessage("assembly: Search stop prematurely due to MAXEVALS.\n");
       danceInterp::OutputMessage("assembly: Function Count: %d, MaxEval: %d\n",fcnt,MAXEVALS);
}

void SdfastSimul::initVelocityAnalysis()
{
	int fcnt, err;
	sdinitvel(m_time,m_state,m_lock,tol,MAXEVALS,&fcnt,&err);
	if (err	== 0)
		danceInterp::OutputMessage("initvel: All velocities within tolerance.\n");
	if (err	== 1)
		danceInterp::OutputMessage("initvel: No velocities exist that meet constraints.\n");
	if (err	== 2)
		danceInterp::OutputMessage("initvel: Search stop prematurely due to	MAXEVALS.\n");
       danceInterp::OutputMessage("initvel: Function Count: %d, MaxEval: %d\n",fcnt,MAXEVALS);
}

void SdfastSimul::staticAnalysis()
{
       int fcnt, err;
       sdstatic(m_time,m_state,m_lock,ctol,tol,MAXEVALS, &fcnt,&err);
       if (err == 0)
	    danceInterp::OutputMessage("static: succeeded at constraint tolerance: %f\n",ctol);
       if (err == 1)
	    danceInterp::OutputMessage("static: Local minimum reached in static analysis.\n");
       if (err == 2)
	    danceInterp::OutputMessage("static: Search stop	prematurely due	to MAXEVALS.\n");
       danceInterp::OutputMessage("static: Function	Count: %d, MaxEval: %d\n",fcnt,MAXEVALS);
}

void SdfastSimul::steadyStateAnalysis()
{
	int fcnt, err;
	sdsteady(m_time,m_state,m_lock,ctol,tol,MAXEVALS,&fcnt,&err);
       if (err == 0)
	    danceInterp::OutputMessage("steady: succeeded at given tolerance: %f\n",tol);
       if (err == 1)
	    danceInterp::OutputMessage("steady: Local minimum reached in static analysis.\n");
       if (err == 2)
	    danceInterp::OutputMessage("steady: Search stop prematurely due to MAXEVALS.\n");
       danceInterp::OutputMessage("steady: Function Count: %d, MaxEval: %d\n",fcnt,MAXEVALS);
}

void SdfastSimul::inverseDynamics(double time, double* state, double *dstate, double* udot, double* torques)
{
	(*sdstate)(time, state, dstate);

	(*sdcomptrq)(udot, torques);

	// revert to old state
//	(*sdstate)(m_time, m_state, m_dstate);

}


void SdfastSimul::Savedstate(FILE *fp)
{
    for( int i = 0 ; i < (nu - 1)  ; i++ )
	fprintf(fp, "%lf ", m_dstate[i]) ;
    fprintf(fp, "%lf", m_dstate[nu-1]) ;
}

void SdfastSimul::LsodesCalcDeriv(double *y, double *dy, double *t)
{
	/*
	SdfastSimul *sim = (SdfastSimul*) CurrentSimulObject->getSimulator(0);
    //    CurrentSimulObject->simulator->myDeriv(*t, y, dy, &tol, &status) ;

    int NQ = sim->nq ;
    int NC = sim->nc ;
    sim->sdstate(sim->m_time, &y[0], &y[NQ]) ;
    // penduforce(double t, double *q, double *u);
    Defaultuforce(sim->m_time, &y[0], &y[NQ]) ;
    Defaultumotion(sim->m_time, &y[0], &y[NQ]) ; // if we had prescribed motions
    sim->sdderiv(&dy[0], &dy[NQ]) ;

    // check the constraints
   // *status = 1 ;
   //   sim->sdverr(errs) ;
//      for( int i = 0 ; i < sim->nc ; i++ )
//      {
//      if ( fabs(errs[i]) > param[0] ) return ;
//      }
//      sim->sdperr(errs) ;
//      for( int i = 0 ; i < sim->nc ; i++ )
//      {
//      if ( fabs(errs[i]) > param[0] ) return ;
//      }

   // *status = 0 ;
    return ;
*/
}

//  int SdfastSimul::Step(double destTime)
//  {
//      // used by the static functions such as Default force
//      CurrentSimulObject = ao ;
//      while ( m_time < destTime )
//      {
//  	ao->BeforeSimStepBase(m_time, this) ;
//  	step(destTime) ;
//  	ao->AfterSimStepBase(m_time, this) ;
//      }
//      return 1 ;
//  }


// load()
// loads the simulator and allocates state vectors etc
int SdfastSimul::Load(char* objType)
{
    char param[MAX_LINE] ;
    char line[MAX_LINE]	;
    FILE *fp = NULL ;

    int i ;

    err	= 0 ;
    errest = 0.0 ;
    flag = 1 ;
    ctol = CTol	;
    tol	= TOl ;

    m_time = 0 ;

    if(	m_isLoaded != TRUE)
    {
		// make and compile
		//MakeCompile(ao->getName()) ;
		// construct the file name <name>_info
		sprintf(infoFileName,"%s/sdfastobjs/%s/%s_info", getenv("DANCE_DIR"),objType, objType) ;
		if((fp = fopen(infoFileName,"r")) == NULL)
		{
			danceInterp::OutputMessage("Cannot open file %s\n", infoFileName) ;
			return DANCE_ERROR ;
		}
		danceInterp::OutputMessage("Found info file %s...", infoFileName);
		
		int	nfound = 0 ;
		do {
			fgets(line,MAX_LINE,fp)	;
			strcpy(param,""); // To	clear param
			sscanf(line,"%s", param) ;
			if( strcmp(param,"nbod") == 0)
			{
				sscanf(line,"%s %d",param,&nbod) ;
				nfound++ ;
			}
			else if( strcmp(param,"njnt") == 0)
			{
				sscanf(line,"%s %d",param,&njnt) ;
				nfound++ ;
			}
			else if( strcmp(param,"ndof") == 0)
			{
				sscanf(line,"%s %d",param,&ndof) ;
				nfound++ ;
			}
			else if( strcmp(param,"nloop") == 0)
			{
				sscanf(line,"%s %d",param,&nloop) ;
				nfound++ ;
			}
			else if( strcmp(param,"nldof") == 0)
			{
				sscanf(line,"%s %d",param,&nldof) ;
				nfound++ ;
			}
			else if( strcmp(param,"nq") == 0)
			{
				sscanf(line,"%s %d",param,&nq) ;
				nfound++ ;
			}
			else if( strcmp(param,"nu") == 0)
			{
				sscanf(line,"%s %d",param,&nu) ;
				nfound++ ;
			}
			else if( strcmp(param,"nlq") ==	0)
			{
				sscanf(line,"%s %d",param,&nlq) ;
				nfound++ ;
			}
			else if( strcmp(param,"nlu") ==	0)
			{
				sscanf(line,"%s %d",param,&nlu) ;
				nfound++ ;
			}
			else if( strcmp(param,"nc") == 0)
			{
				sscanf(line,"%s %d",param,&nc) ;
				nfound++ ;
			}
			else if( strcmp(param,"nlc") ==	0)
			{
				sscanf(line,"%s %d",param,&nlc) ;
				nfound++ ;
			}
			else if( strcmp(param,"npresc")	== 0)
			{
				sscanf(line,"%s %d",param,&npresc) ;
				nfound++ ;
			}
			else if( strcmp(param,"nuserc")	== 0)
			{
				sscanf(line,"%s %d",param,&nuserc) ;
				nfound++ ;
			}
		    
		} while(!feof(fp) && (nfound < 13) ) ;
		
		if( fp ) fclose(fp) ;
		
		if (nfound != 13)
		{
			danceInterp::OutputMessage("Less or more parameters than expected!\n") ;
			danceInterp::OutputMessage("%d\n",nfound ) ;
			return DANCE_ERROR ;
		}
		
		
		// bind the	function pointers to their proper functions
		if(	bindPointers(objType) == DANCE_ERROR )
		{
			danceInterp::OutputMessage("Cannot bind pointers!\n") ;
			// remove system from simulator
			if (this->getNumSystems() > 0)
			{
				DSystem* sys = this->getSystem(0);
				this->removeSystem(sys);
			}
			return DANCE_ERROR ;
		}
		
		// we now know the dimensions of our simulation so allocate the state vectors
		
		if( nu > 0 )
		{
			m_lock = new int[nu];
			if( m_lock == NULL )
			{
			danceInterp::OutputMessage("No more memory!") ;
			return DANCE_ERROR ;
			}
			for( i=0; i < nu; i++)
			m_lock[i] = 0;
		}
		
		if( (nq+nu) > 0 )
		{
			if (m_state != NULL)
				delete [] m_state;
			m_state = new double [nq+nu] ;
			if( m_state == NULL )
			{
			if( m_lock ) delete [] m_lock ;
			danceInterp::OutputMessage("Couldn't allocate memory!\n") ;
			return DANCE_ERROR ;
			}
		}
	    
		if( (nu) > 0 )
		{
			m_dstate = new double [nq+nu] ;
			if( m_dstate == NULL )
			{
			danceInterp::OutputMessage("Couldn't allocate memory!\n") ;
			if ( m_lock ) delete [] m_lock ;
			if ( m_state ) delete [] m_state	;
			return DANCE_ERROR;
			}
		}
		
		if( nu > 0 )
		{
			m_initVel = new double [nu] ;
			if( m_initVel == NULL )
			{
			danceInterp::OutputMessage("Couldn't allocate memory!\n") ;
			if ( m_lock ) delete [] m_lock ;
			if ( m_state ) delete [] m_state ;
			return DANCE_ERROR;
			}
		}
    }

    
    sdinit() ;		  // initialize	sdfast
    danceInterp::OutputMessage("Parameters for simulation dt = %lf time = %lf tol = %lf\n",
			    getTimeStep(),
			    m_time,
			    tol) ;
    
    assemblyAnalysis();
    initVelocityAnalysis();
    
    m_isLoaded = TRUE ;
    return DANCE_OK ;
}

int SdfastSimul::commandPlugIn(int argc, char **argv)
{

	int ret = DSimulator::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

    bool new_vel = FALSE ;

    while(argc)
    {
		if (strcmp(argv[0], "loadstate") == 0)
		{
			if (argc < 2)
			{
				danceInterp::OutputMessage("ERROR: expected: loadstate <time>\n");
				return DANCE_ERROR ;
			}
			else 
			{
				double t =  atof(argv[1]);
				loadState(t);
				return DANCE_OK;
			}
		}
	
		else if( strcmp(argv[0], "integ") == 0)
		{
			if(	argc < 2 )
			{
				danceInterp::OutputMessage("ERROR: expected: integ 0|<value>\n");
				return DANCE_ERROR ;
			}
			m_integrator = atoi(argv[1]) ;
			argc -= 2 ;
			argv += 2 ;
		}
		else if( strcmp(argv[0], "tol") == 0)
		{
			if(	argc < 2 )
			{
				danceInterp::OutputMessage("ERROR: expected: tol <tol>\n");
				return DANCE_ERROR ;
			}
			if(	!isdigit(argv[1][0]) )
			{
				danceInterp::OutputMessage("ERROR: expected tol <tol>\n");
				continue ;
			}
			tol = atof(argv[1]) ;
			argc -= 2 ;
			argv += 2 ;
		}
		else if( strcmp(argv[0], "ctol") == 0)
		{
			if(	argc < 2 )
			{
				danceInterp::OutputMessage("ERROR: expected: ctol <ctol>\n");
				return DANCE_ERROR ;
			}
			if(	!isdigit(argv[1][0]) )
			{
				danceInterp::OutputMessage("ERROR: expected ctol <ctol>\n");
				argc -= 1 ;
				argv += 1 ;

				continue ;
				}
			ctol = atof(argv[1]) ;
			argc -= 2 ;
			argv += 2 ;
		}
		else if( strcmp(argv[0], "f") == 0 )
		{
			danceInterp::OutputMessage("Using fixed time step\n") ;
			fixedStep = TRUE	;
			argc -= 1 ;
			argv += 1 ;
		}
		else if( strcmp(argv[0], "v") == 0 )
		{
			danceInterp::OutputMessage("Using variable time step\n") ;
			fixedStep = FALSE ;
			argc -= 1 ;
			argv += 1 ;
		}
		else if( strcmp(argv[0], "end") == 0)
		{
			if(	argc < 2 )
			{
				danceInterp::OutputMessage("ERROR: expected: ctol <ctol>\n");
				return DANCE_ERROR ;
			}
			if(	!isdigit(argv[1][0]) )
			{
				danceInterp::OutputMessage("ERROR: expected ctol <ctol>\n");
				argc -= 1 ;
				argv += 1 ;
				
				continue ;
			}
			m_end = atof(argv[1]) ;
			argc -= 2 ;
			argv += 2 ;
		}
		else if( (strcmp(argv[0], "sstate") == 0 ) || (strcmp(argv[0], "dstate") == 0 ) )
		{
			// read the velocities from the given file
			if( argc > 1 )
			{
			FILE *fp = fopen(argv[1], "r") ;
			if( fp == NULL )
			{
				danceInterp::OutputMessage("Cannot open %s", argv[1]) ;
				danceInterp::OutputMessage("Using 0 velocities") ;
				argc -= 2 ;
				argv += 2 ;
				return DANCE_ERROR ;
			}
			for( int i = 0 ; i < nu ; i++ )
			{
				if( fscanf(fp, "%lf", &m_dstate[i]) != 1 )
				{
					danceInterp::OutputMessage("Error reading velocity file.") ;
					fclose(fp) ;
					argc -= 2 ;
					argv += 2 ;
					fclose(fp) ;
					return DANCE_ERROR ;
				}
				m_state[nq+i] = m_dstate[i] ;
			}
			danceInterp::OutputMessage("Read new velocities") ;
			new_vel = TRUE ;		
			fclose(fp) ;
		
			}
	   
			argc -= 2 ;
			argv += 2 ;

		}
		else if (strcmp(argv[0], "load_ao_params") == 0)
		{
			this->Start(dance::AllSimulators->getCurrentTime());
			danceInterp::OutputMessage("Simulator %s has loaded state from the articulated object.", this->getName());
			return DANCE_OK;
		}
		else if (strcmp(argv[0], "show_body_positions") == 0)
		{
			if (argc < 2)
			{
				danceInterp::OutputMessage("Usage: dance.simulator(\"%s\", \"show_body_positions\", \"<true|false>\")");
				return DANCE_ERROR;
			}
			if (strcmp(argv[1], "true") == 0)
			{
				this->setShowBodyPositions(true);
				danceInterp::OutputMessage("simulator %s body positions will now be shown.", this->getName());
				return DANCE_OK;
			}
			else if (strcmp(argv[1], "false") == 0)
			{
				this->setShowBodyPositions(false);
				danceInterp::OutputMessage("simulator %s body positions will no longer be shown.", this->getName());
				return DANCE_OK;
			}
			else
			{
				danceInterp::OutputMessage("Usage: dance.simulator(\"%s\", \"show_body_positions\", \"<true|false>\")");
				return DANCE_ERROR;
			}
		}
		else if (strcmp(argv[0], "load") == 0)
		{
			if (argc < 2)
			{
				danceInterp::OutputMessage("Usage: dance.simulator(\"%s\", \"load\", \"<info_filename>\")");
				return DANCE_ERROR;
			}
			int ret = this->Load(argv[1]);
			if (ret == DANCE_ERROR)
			{
				danceInterp::OutputMessage("Could not load info and bind pointers with file '%s'.", argv[1]);
				return DANCE_ERROR;
			}
			danceInterp::OutputMessage("Info loaded and pointers bound with file '%s'.", argv[1]);
			return DANCE_OK;
		}
		else
		{
			danceInterp::OutputMessage("Unknown parameter %s.", argv[0]) ;
			return DANCE_CONTINUE ;
		}
    }

    //  SetStateFromObjectState();
//      sdinit() ;		  // initialize	sdfast
//      danceInterp::OutputMessage("Parameters for simulation dt = %lf time = %lf tol = %lf\n",
//  			    m_dt,
//  			    m_time,
//  			    tol) ;
    
//      assemblyAnalysis();
//      initVelocityAnalysis();
    
    if (new_vel == TRUE) 
		sdstate(m_time, m_state, m_dstate) ;
    return DANCE_OK ;
}

void SdfastSimul::FieldForce(double *force)
{
	if (this->getNumSystems()  == 0)
		return;

	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0);

	Vector localforce ;
	for (int i = 0; i < ao->GetNumGroups(); i++)
	{
		GetOrientation(-1,force,i,localforce);
		double mass = ao->GetGroupMass(i) ;
		localforce[0] *= mass ;
		localforce[1] *= mass ;
		localforce[2] *= mass ;
		Vector point = { 0.0, 0.0, 0.0} ;
		sdpointf(i,point,localforce);
	}
	return ;
}

void SdfastSimul::Defaultuforce(double t, double *q, double *u)
{
	if (currentSimulator == NULL)
		return;
	if (currentSimulator->getNumSystems()  == 0)
		return;

	ArticulatedObject* ao = (ArticulatedObject*) currentSimulator->getSystem(0);

//    SdfastSimul  *sim = (SdfastSimul *) CurrentSimulObject->simulator ;
	SdfastSimul* sim = currentSimulator;
    

    // t is the actual time when variable time step is used
    sim->m_time = t ;

	// Actuators can apply to more than	one articulated	object.
    for	(int i = 0; i < dance::AllActuators->size(); i++)
	{
		DActuator *wact = (DActuator *)dance::AllActuators->get(i);
		wact->ExertLoad(ao, sim, sim->m_time, sim->getTimeStep(), q, u);
    }

    return ;
}

void SdfastSimul::Defaultumotion(double t, double *q, double *u)
{
	double vel[300] ;
	double pos[300] ;
	double acc[300] ;

	if (currentSimulator->getNumSystems()  == 0)
	{
		danceInterp::OutputMessage("No articulated object for simulator.\n");
		return ;
    }
	ArticulatedObject* ao = (ArticulatedObject*) currentSimulator->getSystem(0);

	
	//	SdfastSimul  *sim = (SdfastSimul *) CurrentSimulObject->simulator ;
	SdfastSimul* sim = (SdfastSimul*) ao->getSimulator(0);
	sim->m_time = t ;
		
	//int res = 0 ;
	//for	(int i  =0; i < dance::AllModifiers->size(); i++)
	//{
	//	DModifier *wact = (DModifier *)dance::AllModifiers->get(i);
	//	if (wact->IsPrescribedMotionOn() ==	1)
	//		res = wact->GetPrescribedMotion(ao, sim->m_time, sim->getTimeStep(), pos, vel, acc);
 //   } 
	//if (res == 0)
	//	return ; // no motion provided or something is wrong


    // Loop through all	joints and set the prescribed vectors.
    Joint **joint =  ao->getJoints();
    if (joint == NULL)
	  danceInterp::OutputMessage("Could	not find joints	for object\n");

    int	dof, n, count = 0 ;
    for	(int i = 0; i < ao->getNumJoints(); i++) 
	{
		if( joint[i]->getJointType() == J_WELD ) continue ;

		dof = joint[i]->getStateSize();
		for ( n = 0; n	< dof; n++)
		{
			sim->sdpres(i,n,1) ;
			sim->sdprespos(i,n,pos[count]) ;
			sim->sdpresvel(i,n,vel[count]) ;
			sim->sdpresacc(i,n,acc[count]) ;
			count++ ;
		}
    }

   return ;
}

// PosError:
//	Position error for point-to-point constraints.
//	perr = ((p1-p2)*(p1-p2)	- d*2)/2 where d = 0
//
void SdfastSimul::PosError(double t, double *q,	double *errs)
{
	return;
}

// VelError:
//	verr = (v1-v2)*(p1-p2)
//
void SdfastSimul::VelError(double t, double *q,	double *u, double *errs)
{
	return;
}

// AccError:
//	aerr = (a1-a2)*(p1-p2) + (v1-v2)*(v1-v2)
//
void SdfastSimul::AccError(double t, double *q,	double *u, double *udot, double	*errs)
{
	return;
}

// ConstraintForces:
//	Constraint forces for point to point constraint.
//	Velocity terms from VelError are:
//		v1*(p1-p2) and -v2*(p1-p2)
//	So constraint forces, calculated with multipliers are:
//	f1 = m*(p1-p2) and f2 =	-m*(p1-p2) = -f1
//	Forces are in the world	frame and must be converted into the body-local	frame.
//
void SdfastSimul::ConstraintForces(double t, double *q,	double *u, double *mults)
{
	return;
}

// dotDistance
//	Convenience function to	calculate the following	dot product.
//	dotprod	= (a1-a2)(b1-b2)
//
double SdfastSimul::dotDistance(double *a1, double *a2,	double *b1, double *b2)
{
	double dotprod = 0.0;
	for (int i = 0;	i < 3; i++)
	   dotprod += (a1[i]-a2[i])*(b1[i]-b2[i]);
	return(dotprod);
}

void SdfastSimul::PointForce(DSystem *sys, double *pointLocalCoord, double *globalForce)
{
   Link *link = (Link *) sys;
   int num = link->getNumber();
   PointForce(num, pointLocalCoord, globalForce) ;
 }

void SdfastSimul::PointForce(int group, double *pointLocalCoord, double *globalForce)
{
   Vector localforce;
   GetOrientation(WORLDFRAME, globalForce, group, localforce) ;
   sdpointf(group, pointLocalCoord, localforce) ;
 }

void SdfastSimul::PointForce(int argc, char *argv[])
{
    if( argc != 4 )
    {
	danceInterp::OutputMessage("PointForce: wrong number of arguments %d, "
				"expected 4", argc) ;
	return ;
    }
    Link *link = (Link *) argv[0] ;
    // not needed so commented out
    // int *npoint = (int *) argv[1] ;
    double *point = (double *) argv[2] ;
    double *force = (double *) argv[3] ;
    double lforce[3] ;
    // bring the force in local coordinates
    int nl = link->getNumber();
    GetOrientation(WORLDFRAME,force,nl,lforce) ;
    sdpointf(nl, point, lforce) ;
}

int SdfastSimul::GetPosition(DSystem *sys, double *localPoint, double *position)
{
	Link *l = (Link *) sys ;
	sdpos(l->getNumber(), localPoint, position) ;
	return 1 ;
}

int SdfastSimul::GetPosition(int group, double *localPoint, double *position)
{
	sdpos(group, localPoint, position);
	return 1;
}

int SdfastSimul::GetLocalPosition(int group, double *localPoint, double *position)
{
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0);
	Link* link = ao->getLink(group);
	if (link != NULL)
	{
		link->getLocalCoord(localPoint, position);
		return 1;
	}
	return 0;
}

 
void SdfastSimul::GetVel(DSystem *sys, double *point, double *vel)
{
	Link *l = (Link *) sys ;
	sdvel(l->getNumber(), point, vel) ;
	return ;
}

void SdfastSimul::GetAngVel(int group, double* vel)
{
	sdangvel(group, vel);
	return;
}

	int SdfastSimul::SetState(int index, double value)
	{
		m_state[index] = value;

//		this->assemblyAnalysis();

		return 1;
	}

	double SdfastSimul::GetState(int index)
	{
		return m_state[index];
	}

	void SdfastSimul::dumpState()
	{
		// show position & velocities
		for (int i = 0; i < nq; i++)
			danceInterp::OutputMessage("Position %d: %f", i, m_state[i]);
		for (int i = 0; i < nq; i++)
			danceInterp::OutputMessage("Velocity %d: %f", i, m_dstate[i]);
	}




void SdfastSimul::EulerInteg(double *time,
    double *state,
    double *dstate,
    double dt,
    double ctol,
    int *flag,
    double *errest,
    int *err)
{
    double ttime,param[1];
    int ferr;

    
    param[0] = ctol;
    *err = 0;
    ttime = *time;
    
       sdmotfunc(ttime,state,dstate,param,&ferr);
        *flag = 0;
	for( int i = 0 ; i < this->nq+this->nu; i++ )
	{
		state[i] += dstate[i]*dt; 
	}
    
    if (ferr != 0) {
        *err = 1;
    }
    *time = ttime+dt;
}

int SdfastSimul::convertIndexAOtoSim(int in)
{
	if (true) return aoToSimMap[in];

	if (true) return in;

	if (in < 6)
		return in;
	else if (in == 6)
		return this->getStateSize() - 1;
	else
		return in - 1;
}

int SdfastSimul::convertIndexSimtoAO(int in)
{
	if (true) return simToAOMap[in];

	if (true) return in;

	if (in < 6)
		return in;
	else if (in < this->getStateSize() - 1)
		return in + 1;
	else
		return 6;
}

void SdfastSimul::saveSystemState(double time)
{
	if (this->getNumSystems() == 0)
		return;

	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0);

	Joint **joint =  ao->getJoints();
	if (joint == NULL)
		danceInterp::OutputMessage("Could	not find joints	for object\n");

	int count = 0;
	for	(int i = 0; i < ao->getNumJoints(); i++)
	{
		int dof = joint[i]->getStateSize();
		for (int n	= 0; n < dof; n++)
		{
			int simIndex = (*sdindx)(i,n);
			tempState[this->convertIndexSimtoAO(simIndex)] = m_state[simIndex];
			count++;
		}
	}

	ao->setState(tempState);
}

void SdfastSimul::setShowBodyPositions(bool val)
{
	m_isShowBodyPositions = val;
}

bool SdfastSimul::isShowBodyPositions()
{
	return m_isShowBodyPositions;
}

fltk::Widget* SdfastSimul::getInterface()
{
	if (m_simWin == NULL)
	{
		m_simWin = new SdfastSimulWindow(this, 0, 0, 300, 200, this->getName());
	}

	return m_simWin;
}

void SdfastSimul::createStateMapping()
{
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0);
	Joint** joints = ao->getJoints();

	int count = 0;
	for	(int i = 0; i < ao->getNumJoints(); i++)
	{
		int dof = joints[i]->getStateSize();
		for (int n	= 0; n < dof; n++)
		{
			int simIndex = (*sdindx)(i,n);
			aoToSimMap[count] = simIndex;
			simToAOMap[simIndex] = count;
			count++;
		}
	}
}

void SdfastSimul::addSystem(DSystem *sys)
{
	ArticulatedObject* artObj = dynamic_cast<ArticulatedObject*>(sys);
	if (artObj == NULL)
	{
		danceInterp::OutputMessage("System %s is not an articulated object.", sys->getName());
	}

	DSimulator::addSystem(sys);
}

void SdfastSimul::removeSystem(DSystem *sys)
{
	ArticulatedObject* artObj = dynamic_cast<ArticulatedObject*>(sys);
	if (artObj == NULL)
	{
		danceInterp::OutputMessage("System %s is not an articulated object.", sys->getName());
	}
	else
	{
		if (this->getNumSystems() > 0)
		{
			ArticulatedObject* ao = (ArticulatedObject*) this->getSystem(0);
			if (ao == artObj)
			{
				DSimulator::removeSystem(sys);
			}
		}
	}
}

void SdfastSimul::onDependencyRemoval(DObject* obj)
{
	DSimulator::onDependencyRemoval(obj);
}

void SdfastSimul::save(int mode, std::ofstream& file)
{
	char buff[512];

	if (mode == 0)
	{
		file << "dance.instance(\"SdfastSimul\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
		DSimulator::save(mode, file);
	
		// show body positions?
		if (this->isShowBodyPositions())
		{
			sprintf(buff, "\"show_body_positions\", \"true\"");
		}
		else
		{
			sprintf(buff, "\"show_body_positions\", \"false\"");
		}
		pythonSave(file, buff);

		// load the info file and bind the pointers
		if (this->m_isLoaded == TRUE)
		{
			sprintf(buff, "\"load\", \"%s\"", sdType);
			pythonSave(file, buff);
		}
	}
	else if (mode == 2)
	{
		DSimulator::save(mode, file);
	}

}

int SdfastSimul::getNumPluginDependents()
{
	return 1;
}

const char* SdfastSimul::getPluginDependent(int num)
{
	if (num == 0)
		return "ArticulatedObject";
	else
		return NULL;
}


