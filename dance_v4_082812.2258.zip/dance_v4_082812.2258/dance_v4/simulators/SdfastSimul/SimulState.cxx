#include "SimulState.h"

#include "danceTcl.h"
#include "SdfastSimul.h"


SimulState::SimulState(SdfastSimul* sim)
{
	m_sim = sim;
	setTime(-1);
}

void SimulState::setTime(double t)
{
	m_time = t;
}

double SimulState::getTime()
{
	return m_time;
}

double SimulState::getState(int index)
{
	if (int(m_state.size()) > index)
	{
		return m_state[index];
	}
	else
	{
		danceTcl::OutputMessage("State index %d out of range for articulated object %s (%d)\n", index, m_artObj->getName(), m_state.size());
		return 0;
	}
}

void SimulState::setState(double time, ArticulatedObject* obj)
{
	setTime(time);
	m_artObj = obj;

	int stateSize = 2 * obj->getStateSize()();
	for (int x = 0; x < stateSize; x++)
	{
		m_state.push_back(m_sim->m_state[x]);
	}
}

void SimulState::clear()
{
	m_state.clear();
	m_time = 0;
}

ArticulatedObject* SimulState::getObject()
{
	return m_artObj;
}


