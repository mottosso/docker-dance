/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "SdfastSimulWindow.h"
#include <fltk/Group.h>
#include <fltk/CheckButton.h>
#include <fltk/ask.h>
#include "SdfastSimul.h"
#include "ArticulatedObject.h"
#include "dance.h"
#include "ViewManager.h"

using namespace fltk;

SdfastSimulWindow::SdfastSimulWindow(SdfastSimul* simulator, int x, int y, int w, int h, const char* name) : Group(x, y, w, h, name)
{
	sim = simulator;

	this->begin();

	choiceAO = new Choice(110, 10, 150, 20, "Simulated Object");
	choiceAO->callback(this->SelectAOCB, this);

	checkShowBodyPositions = new CheckButton(20, 50, 100, 20, "Show body positions");
	checkShowBodyPositions->callback(ShowBodyCB, this);

	inputStep = new FloatInput(60, 75, 50, 20, "Time step");
	inputStep->callback();

	checkUseMainTimeStep = new CheckButton(120, 75, 80, 20, "Use main simulator time step");
	checkUseMainTimeStep->callback(UseMainTimeStepCB, this);

	this->end();

	this->updateGUI();
}

void SdfastSimulWindow::layout()
{
	this->updateGUI();

	Group::layout();
}

void SdfastSimulWindow::updateGUI()
{
	choiceAO->clear();
	choiceAO->add("Choose an articulated object");
	for (int x = 0; x < dance::AllSystems->size(); x++)
	{
		ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(dance::AllSystems->get(x));
		if (ao == NULL)
		{
			// ignore, not an articulated object
		}
		else
		{
			choiceAO->add(ao->getName());
		}
	}

	// choose the appropriate articulated object
	ArticulatedObject* ao = (ArticulatedObject*) this->sim->getSystem(0);

	if (ao != NULL)
	{
		for (int x = 0; x < choiceAO->size(); x++)
		{
			Widget* w = choiceAO->child(x);
			if (strcmp(ao->getName(), w->label()) == 0)
			{
				choiceAO->value(x);
				break;
			}
		}

		checkShowBodyPositions->activate();
		checkShowBodyPositions->value(this->sim->isShowBodyPositions());

		checkUseMainTimeStep->activate();
		if (this->sim->isUseMainTimeStep())
		{
			checkUseMainTimeStep->value(true);
			inputStep->deactivate();
		}
		else
		{
			checkUseMainTimeStep->value(false);
			inputStep->activate();
			inputStep->value(this->sim->getTimeStep());
		}
	}
	else
	{
		choiceAO->value(0);
		checkShowBodyPositions->deactivate();
		inputStep->deactivate();
		checkUseMainTimeStep->deactivate();
	}

}

void SdfastSimulWindow::ShowBodyCB(fltk::Widget* widget, void* data)
{
	SdfastSimulWindow* win = (SdfastSimulWindow*) data;

	CheckButton* check = (CheckButton*) widget;

	if (check->value() == true)
	{
		win->sim->setShowBodyPositions(true);
	}
	else
	{
		win->sim->setShowBodyPositions(false);
	}

	dance::AllViews->postRedisplay();
}

void SdfastSimulWindow::SelectAOCB(fltk::Widget *w, void *data)
{
	SdfastSimulWindow* win = (SdfastSimulWindow*) data;

	Widget* widget = win->choiceAO->child(win->choiceAO->value());

	DSystem* sys = (DSystem*) dance::AllSystems->get((char*) widget->label());
	if (sys != NULL)
	{
		const char* objType = fltk::input("Please enter the articulated object type:\n(Type must have _info file under $(DANCE_DIR)/sdfastobjs/)");
		if (objType != NULL)
		{
			win->sim->addSystem(sys);
			int ret = win->sim->Load((char*) objType);
			if (ret != 1)
			{
				fltk::alert("Could not load articulated object of type '%s'.", objType);
				win->sim->removeSystem(sys);
			}
		}
	}
	else
	{
		if (win->sim->getNumSystems() > 0)
		{
			DSystem* sys = win->sim->getSystem(0);
			win->sim->removeSystem(sys);
		}
	}

	win->updateGUI();
}

void SdfastSimulWindow::StepCB(fltk::Widget* widget, void* data)
{
	SdfastSimulWindow* win = (SdfastSimulWindow*) data;

	double step = win->inputStep->fvalue();

	win->sim->setTimeStep(step);

	win->updateGUI();
}

void SdfastSimulWindow::UseMainTimeStepCB(fltk::Widget* widget, void* data)
{
	SdfastSimulWindow* win = (SdfastSimulWindow*) data;

	win->sim->setUseMainTimeStep(win->checkUseMainTimeStep->value());

	win->updateGUI();
}


