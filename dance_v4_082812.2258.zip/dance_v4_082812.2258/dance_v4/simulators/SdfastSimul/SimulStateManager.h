#ifndef SIMSTATEMANAGER_H
#define SIMSTATEMANAGER_H

#include "SdfastSimul.h"
#include "ArticulatedObject.h"
#include "SimulState.h"

class SimulStateManager
{
	public:
		SimulStateManager();
		void setSimulator(SdfastSimul* sim);
		void setArticulatedObject(ArticulatedObject* obj);
		~SimulStateManager();
		void saveStateConditional(double time);
		void saveState();
		SimulState* loadState(double time);
		void setRate(double rate);
		double getRate();
		void cleanUp(double time);

	private:
		int getNextSaveIndex(double time, bool overwrite);

		std::vector<SimulState*> m_savedStates;
		SdfastSimul* m_sim;
		ArticulatedObject* m_obj;
		double m_rate;
		double m_lastTimeSaved;
		int m_maxStates;
		int m_curIndex;
		double m_minTime;
		double m_maxTime;
		int m_startIndex;
		int m_maxSaveIndex;

};

#endif
