#ifndef SIMULSTATE_H
#define SIMULSTATE_H

#include "SdfastSimul.h"
#include "ArticulatedObject.h"
#include <vector>

class SimulState
{
	public:
		SimulState(SdfastSimul* sim);
		double getTime();
		double getState(int index);
		ArticulatedObject* getObject();
		void setState(double time, ArticulatedObject* obj);
		void clear();

	private:
		void setTime(double t);

		ArticulatedObject* m_artObj;
		double m_time;
		std::vector<double> m_state;
		SdfastSimul* m_sim;
};

#endif
