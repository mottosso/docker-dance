
/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "SmartBodyObject.h"
#include "dance.h"
#include "danceInterp.h"
#include "DAttribute.h"
#include "DGeometry.h"
#include "MotionPlayer.h"
#include "opengl.h"
#include "SmartBodyObjectWindow.h" 
#include "ParserBVH.h"
#include "DConnection.h"
#include "DConnectionManager.h"
#include "PlugInManager.h"
#include "ParserSKM.h"
#include "TrackView.h"
#include <sbm/sbm_constants.h>

#include <sbm/xercesc_utils.hpp>
#include <sbm/mcontrol_util.h>
#include <sbm/sbm_test_cmds.hpp>
#include BML_PROCESSOR_INCLUDE
#include <sbm/remote_speech.h>
#include <sbm/joint_logger.hpp>
#include <sbm/sbm_audio.h>
#include <sbm/sbm_speech_audiofile.hpp>
#include <sbm/text_speech.h> // [BMLR]
#include <sbm/locomotion_cmds.hpp>
#include <sbm/resource_cmds.h>
#include <sbm/mcontrol_callbacks.h>
#include <me/me_ct_blend.hpp>
#include <me/me_ct_time_shift_warp.hpp>
#include <sbm/time_regulator.h>

#include <sbm/sr_cmd_line.h>
#include <sr/sr_sa_bbox.h>

#include "ControllerWindow.h"
#include "BehaviorWindow.h"
#include "vhcl_log.h"

#include <iostream>
#include <sstream>

#define ENABLE_QPF_TIME 	(1)

class DanceListener : public vhcl::Log::Listener
{
	public:
		DanceListener() : vhcl::Log::Listener()
		{
		}

		virtual void OnMessage( const std::string & message )
		{
			danceInterp::OutputMessage(message.c_str());
		}
};

double get_time(void) {
#ifdef WIN32
#if ENABLE_QPF_TIME
	static int once = 1;
	static double inv_freq;
	static LONGLONG ref_quad;
	LARGE_INTEGER c;
	
	if( once )	{
		once = 0;
		LARGE_INTEGER f;
		QueryPerformanceFrequency( &f );
		inv_freq = 1.0 / (double)f.QuadPart;
		QueryPerformanceCounter( &c );
		ref_quad = c.QuadPart;
	}
	QueryPerformanceCounter( &c );
	LONGLONG diff_quad = c.QuadPart - ref_quad;
	if( diff_quad < 0 ) {
		diff_quad = 0;
	}
	return( (double)diff_quad * inv_freq );
#else
	return( (double)timeGetTime() / 1000.0 );
#endif
#else
	struct timeval tv;
	gettimeofday( &tv, NULL );
	return( tv.tv_sec + ( tv.tv_usec / 1000000.0 ) );
#endif
}

void sbm_sleep( int msec )	{
#ifdef WIN32
#if 0
	Sleep( msec );
#else
	static int once = 1;
	if( once )	{
		once = 0;
		timeBeginPeriod( 1 ); // millisecond resolution
	}
	Sleep( msec );
#endif	
#else
	printf( "sbm_sleep ERR: not implemented\n" );
#endif
}

void sbm_loop_wait( double target_fps = 100.0 )	{ // sleep to reach target loop rate
	static double prev_time = 0.0;

	double target_dt = 1.0 / target_fps;
	double curr_time = get_time();
	double dt = curr_time - prev_time;

	if( dt < target_dt )	{
		double diff = target_dt - dt;
		int wait_msec = (int)( diff * 1000.0 );
		if( wait_msec > 0 ) {
			sbm_sleep( wait_msec );
		}
	}
	prev_time = get_time();
}

SmartBodyObject* SmartBodyObject::smartInstance = NULL;

PlugIn* Proxy()
{
	return new SmartBodyObject();
}

PlugIn* SmartBodyObject::create(int argc, char **argv)
{
	SmartBodyObject* s = new SmartBodyObject() ;

    return s;	
}

SmartBodyObject::SmartBodyObject() : PlugIn()
{
	DanceListener* logListener = new DanceListener();
	vhcl::Log::g_log.AddListener(logListener);

	danceInterp::OutputMessage("SmartBody has been created!");
	gui =  NULL;

	// bonebus attributes
	m_connect = this->createBoolAttribute("connect", false, true, "BoneBus", 10);
	m_connected = this->createBoolAttribute("connected", false, true, "BoneBus", 20, true);
	m_clientConnected = this->createBoolAttribute("clientconnected", false, true, "BoneBus", 30, true);
	m_update = this->createBoolAttribute("update", false, true, "BoneBus", 40);
	m_frequency = this->createDoubleAttribute("frequency", 60.0, true, "BoneBus", 50);
	m_skeletonFile = this->createStringAttribute("skeletonfile", "", true, "BoneBus", 60);
	m_showJoints = this->createBoolAttribute("showjoints", false, true, "BoneBus", 70);
	m_showBones = this->createBoolAttribute("showbones", true, true, "BoneBus", 80);
	m_recordMotion = this->createBoolAttribute("recordmotion", false, true, "BoneBus", 90);

	// smartbody session attributes
	m_smartBodyRoot = this->createStringAttribute("smartbodyroot", "c:/users/shapiro/smartbody/trunk/", true, "Session", 100);
	m_smartBodyPaths = this->createStringAttribute("smartbodypaths", "", true, "Session", 105);
	m_arguments = this->createStringAttribute("arguments", "", true, "Session", 108);
	m_defaultSequence = this->createStringAttribute("defaultsequence", "path seq .#seq default.seq begin", true, "Session", 110);
	m_targetFps = this->createDoubleAttribute("targetFPS", 100.0, true, "Session", 120);
	m_run = this->createBoolAttribute("run", false, true, "Session", 130);
	m_update = this->createBoolAttribute("update", false, true, "Session", 140);
	m_showSkelLocal = this->createBoolAttribute("local skel", true, true, "Session", 145);
	m_showSkel = this->createBoolAttribute("skel", false, true, "Session", 150);
	m_characterBoneSize = this->createDoubleAttribute("skelbonesize", 1.0, true, "Session", 155);
	m_showGeom = this->createBoolAttribute("geom", false, true, "Session", 160);
	m_showColGeom = this->createBoolAttribute("colgeom", false, true, "Session", 170);
	m_showAxis = this->createBoolAttribute("axis", false, true, "Session", 180);
	m_showCOM = this->createBoolAttribute("com", false, true, "Session", 182);
	m_showEyeBeams = this->createBoolAttribute("showeyebeams", false, true, "Session", 182);
	m_showSupportPolygon = this->createBoolAttribute("supportpolygon", false, true, "Session", 183);
	m_useFaceBones = this->createBoolAttribute("usefacebones", false, true, "Session", 185);
	m_trackCharacter =this->createStringAttribute("character", "", true, "Session", 190);
	m_trackJoint = this->createStringAttribute("trackjoint", "", true, "Session", 200);
	m_showControllerInfo = this->createBoolAttribute("showcontrollerinfo", false, true, "Session", 210);
	m_showControllerMap = this->createBoolAttribute("showcontrollermap", false, true, "Session", 211);
	m_isolateController = this->createBoolAttribute("isolatecontroller", false, true, "Session", 214);
	m_isolateAllControllers = this->createBoolAttribute("isolateallcontrollers", false, true, "Session", 215);
	m_isolateAllControllersMaxTime = this->createDoubleAttribute("maxisolatetime", 60.0, true, "Session", 216);
	m_disableControllers = this->createBoolAttribute("disablecontrollers", false, true, "Session", 218);
	m_controller = this->createStringAttribute("controller", "", true, "Session", 220);
	m_motions = this->createStringAttribute("motions", "", true, "Session", 230);
	m_poses = this->createStringAttribute("poses", "", true, "Session", 240);

	std::string visemeNames[] = {"Ao", "D", "EE", "Er", "f", "Ih", "j", "KG", "oh", "OO", "NG", "R", "Th", "Z"};
	for (int v = 0; v < 14; v++)
	{
		DoubleAttribute* viseme = this->createDoubleAttribute(visemeNames[v], 0.0, true, "Visemes", 300 + v * 10);
		viseme->setMin(0);
		viseme->setMax(1);
		m_visemes.push_back(viseme);
	}

   m_bonebus = new BoneBusServer();

   m_bonebus->SetOnClientConnectCallback( &SmartBodyObject::OnClientConnect, this );
   m_bonebus->SetOnClientDisconnectCallback( &SmartBodyObject::OnClientDisonnect, this );
   m_bonebus->SetOnCreateCharacterFunc( &SmartBodyObject::OnCreateCharacter, this );
   m_bonebus->SetOnDeleteCharacterFunc( &SmartBodyObject::OnDeleteCharacter, this );
   m_bonebus->SetOnSetCharacterPositionFunc( &SmartBodyObject::OnSetCharacterPosition, this );
   m_bonebus->SetOnSetCharacterRotationFunc( &SmartBodyObject::OnSetCharacterRotation, this );
   m_bonebus->SetOnBoneRotationsFunc( &SmartBodyObject::OnBoneRotations, this );
   m_bonebus->SetOnBonePositionsFunc( &SmartBodyObject::OnBonePositions, this );

   m_bonebus->SetOnSetCharacterVisemeFunc( &SmartBodyObject::OnSetCharacterVisemeFunc, this );
   m_bonebus->SetOnPlaySoundFunc( &SmartBodyObject::OnPlaySoundFunc, this );
   m_bonebus->SetOnStopSoundFunc( &SmartBodyObject::OnStopSoundFunc, this );
   m_bonebus->SetOnExecScriptFunc( &SmartBodyObject::OnExecScriptFunc, this );
   m_bonebus->SetOnGeneralParamFunc( &SmartBodyObject::OnGeneralParamFunc, this );

   setUpdateTime(GetTickCount());

   SmartBodyObject::smartInstance = this;

   initSkeletonMapping();

   m_cmdLine = NULL;
   m_lookAtJoint = NULL;
   m_inControllerTraverse = false;

   XMLPlatformUtils::Initialize();  // Initialize Xerces before creating MCU
   m_controllerBuffer = NULL;
   m_controllerVizSkeleton = NULL;
}

SmartBodyObject::~SmartBodyObject()
{
	if (gui != NULL)
		delete gui;
	
	m_bonebus->CloseConnection();
	delete m_bonebus;

	for (std::map<int, Character*>::iterator iter = m_characters.begin();
		iter != m_characters.end();
		iter++)
	{
		delete (*iter).second;
	}

	fltk::remove_idle(SmartBodyObject::checkForUpdates, this);
	fltk::remove_idle(SmartBodyObject::checkForCommands, this);

	delete m_cmdLine;

	mcuCBHandle& mcu = mcuCBHandle::singleton();
	mcu.reset();
}

void SmartBodyObject::output(int mode)
{
	 glMatrixMode(GL_MODELVIEW) ;
	
	// display the characters generated from the bonebus
	for (std::map<int, Character*>::iterator iter = m_characters.begin();
		  iter != m_characters.end();
		  iter++)
	{
		(*iter).second->draw(0, true);
	}

	// draw the characters that have been created directly through the process
	if (!m_run->getValue())
		return;

	mcuCBHandle& mcu = mcuCBHandle::singleton();
	srHashMap<SbmCharacter>& character_map = mcu.character_map;

	glPushAttrib(GL_LIGHTING_BIT | GL_POLYGON_MODE);
	glDisable(GL_LIGHTING);

	glPushMatrix();

	character_map.reset(); // resets the internal iterator
	SbmCharacter* character = character_map.next();
	VectorObj color[2];
	color[0][0] = 1.0; color[0][1] = 0.0; color[0][2] = 0.0;
	color[1][0] = 1.0; color[1][1] = 1.0; color[1][2] = 0.0;
	int charNum = 0;

	while ( character )
	{	
		// set the visibility parameters of the scene
		character->scene_p->set_visibility(m_showSkel->getValue(), m_showGeom->getValue(), m_showColGeom->getValue(), m_showAxis->getValue());

		int colorIndex = charNum % 2;
		glColor3f(color[colorIndex][0], color[colorIndex][1], color[colorIndex][2]);

		character->skeleton_p->update_global_matrices();
		
		if (m_showSkelLocal->getValue())
		{
			const SrArray<SkJoint*>& joints = character->skeleton_p->joints();
			if (joints.size() > 0)
			{
				glPushMatrix();
				SkJoint* rootJoint = joints[0];
				drawJoint(character, rootJoint, NULL);
				glPopMatrix();
			}
		}

		VectorObj com(0, 0, 0);
		if (m_showCOM->getValue())
		{
			const SrArray<SkJoint*>& joints = character->skeleton_p->joints();
			
			int numJoints = 0;
			double totalMass = 0;
			for (int j = 0; j < joints.size(); j++)
			{
				double mass = joints[j]->mass();
				if (mass > 0)
				{
					totalMass += mass;
					SrMat gmat = joints[j]->gmat();
					VectorObj loc(*gmat.pt(12), *gmat.pt(13), *gmat.pt(14)); 
					com += mass * loc;
					numJoints++;
				}
			}
			if (totalMass != 0)
				com /= totalMass;
			// draw the center of mass of the character
			glColor3f(1.0, 1.0, 0.0);
			glPushMatrix();
			glTranslatef(com[0], com[1], com[2]);
			glutSolidSphere(1.0, 4, 4);
			glPopMatrix();
		}

		if (m_showEyeBeams->getValue())
		{
			SkJoint* eyeRight = character->skeleton_p->search_joint("eyeball_right");
			if (eyeRight)
			{
				SrMat gmat = eyeRight->gmat();
				glPushMatrix();
				glMultMatrixf((const float*) gmat);
				glColor3f(1.0, 0.0, 0.0);
				glBegin(GL_LINES);
				glVertex3f(0, 0, 0);
				glVertex3f(0, 0, 100);
				glEnd();
				glPopMatrix();
			}
			SkJoint* eyeLeft = character->skeleton_p->search_joint("eyeball_left");
			if (eyeLeft)
			{
				SrMat gmat = eyeLeft->gmat();
				glPushMatrix();
				glMultMatrixf((const float*) gmat);
				glColor3f(1.0, 0.0, 0.0);
				glBegin(GL_LINES);
				glVertex3f(0, 0, 0);
				glVertex3f(0, 0, 100);
				glEnd();
				glPopMatrix();
			}
		}

		if (m_showSupportPolygon->getValue())
		{
			// draw the support polygon of the character
			// get the heel/toe points for the left and right foot
			VectorObj polygon[4];
			// left heel, toe
			SkJoint* leftFoot = character->skeleton_p->search_joint("l_ankle");
			if (leftFoot)
			{
				SrMat gmat = leftFoot->gmat();
				polygon[0].assign(*gmat.pt(12), *gmat.pt(13), *gmat.pt(14)); 
			}
			SkJoint* leftToe = character->skeleton_p->search_joint("l_toe");
			if (leftToe)
			{
				SrMat gmat  = leftToe->gmat();
				polygon[1].assign(*gmat.pt(12), *gmat.pt(13), *gmat.pt(14)); 
			}			
			// right heel, toe
			SkJoint* rightFoot =character->skeleton_p->search_joint("r_ankle");
			if (rightFoot)
			{
				SrMat gmat = rightFoot->gmat();
				polygon[3].assign(*gmat.pt(12), *gmat.pt(13), *gmat.pt(14)); 
			}
			SkJoint* rightToe = character->skeleton_p->search_joint("r_toe");
			if (rightToe)
			{
				SrMat gmat = rightToe->gmat();
				polygon[2].assign(*gmat.pt(12), *gmat.pt(13), *gmat.pt(14)); 
			}			

			glColor3f(1.0, 0.0, 0.0);
			glBegin(GL_LINE_LOOP);
			for (int x = 0; x < 4; x++)
			{
				glVertex3f(polygon[x][0], polygon[x][1], polygon[x][2]);
			}
			glEnd();

			if (m_showCOM->getValue())
			{
				// show the center of mass in the support polygon as well
				double yLoc = 0;
				for (int i = 0; i < 4; i++)
					yLoc += polygon[i][1];
				yLoc /= 4.0;
				glColor3f(1.0, 1.0, 0.0);
				glPushMatrix();
				glTranslatef(com[0], yLoc, com[2]);
				glutSolidSphere(1.0, 4, 4);
				glPopMatrix();
			}

		}

		character = character_map.next();
		charNum++;
	}

	// show the controller visualization skeleton
	if (m_controllerVizSkeleton)
	{
		glColor3f(0.0, 1.0, 0.0);

		m_controllerVizSkeleton->update_global_matrices();
		
		const SrArray<SkJoint*>& joints = m_controllerVizSkeleton->joints();
		if (joints.size() > 0)
		{
			glPushMatrix();
			SkJoint* rootJoint = joints[0];
			drawJoint(character, rootJoint, NULL);
			glPopMatrix();
		}
	}

	// show all the controller visualization skeletons
	for (std::map<std::string, std::pair<SkSkeleton*, Character*>>::iterator skelIter = m_allControllerVizSkeletons.begin();
		skelIter != m_allControllerVizSkeletons.end();
		skelIter++)
	{
		SkSkeleton* skeleton = (*skelIter).second.first;
		glColor3f(0.0, 1.0, 0.0);

		skeleton->update_global_matrices();
		
		const SrArray<SkJoint*>& joints = skeleton->joints();
		if (joints.size() > 0)
		{
			glPushMatrix();
			SkJoint* rootJoint = joints[0];
			drawJoint(character, rootJoint, NULL);
			glPopMatrix();
		}
	}





	glPopMatrix();
	glPopAttrib();

	m_renderAction.apply(mcu.root_group_p);
	
	SrSaBBox srsaBox;
	glPushMatrix();
	srsaBox.apply(mcu.root_group_p);
	glPopMatrix();

	SrBox srBox = srsaBox.get();
	BoundingBox box;
	box.xMin = srBox.a.x;
	box.yMin = srBox.a.y;
	box.zMin = srBox.a.z;
	box.xMax = srBox.b.x;
	box.yMax = srBox.b.y;
	box.zMax = srBox.b.z;
	m_box.merge(box);
}

void SmartBodyObject::drawJoint(SbmCharacter* character, SkJoint* joint, VectorObj* parentPos)
{
	if (!joint)
		return;

	SrMat gmat = joint->gmat();
	VectorObj loc(*gmat.pt(12), *gmat.pt(13), *gmat.pt(14)); 

	if (0)
	{
		// draw a line from the parent to the joint
		if (parentPos)
		{
			glBegin(GL_LINES);
			glVertex3d((*parentPos)[0], (*parentPos)[1], (*parentPos)[2]);
			glVertex3d(loc[0], loc[1], loc[2]);
			glEnd();
		}
	}
	else
	{
		if (parentPos) 
		{
			SkJoint* parent = joint->parent();
			const SrMat& mat = parent->gmat();
			glPushMatrix();
			glMultMatrixf((const float*) mat);
			SrMat localMat = joint->lmat();
			VectorObj localPoint(*localMat.pt(12), *localMat.pt(13), *localMat.pt(14));
			VectorObj parentPoint(0, 0, 0);
			drawPyramid(parentPoint, localPoint);
			glPopMatrix();
		}
	}

	// draw the joint 
	glBegin(GL_POINTS);
	glVertex3d(loc[0], loc[1], loc[2]);
	glEnd();

	if (m_box.xMin > loc[0])
		m_box.xMin = loc[0];
	if (m_box.yMin > loc[1])
		m_box.yMin = loc[1];
	if (m_box.zMin > loc[2])
		m_box.zMin = loc[2];
	if (m_box.xMax < loc[0])
		m_box.xMax = loc[0];
	if (m_box.yMax < loc[1])
		m_box.yMax = loc[1];
	if (m_box.zMax < loc[2])
		m_box.zMax = loc[2];

	// check to see if this joint is in use by the controller
	if (character && m_trackCharacter->getValue() == character->name)
	{
		std::set<std::string>::iterator iter = m_jointsInUse.find(joint->name().get_string());
		if (iter != m_jointsInUse.end())
		{
			glPushMatrix();
			glTranslatef(loc[0], loc[1], loc[2]);
			glutSolidSphere(1.0, 4, 4);
			glPopMatrix();
		}
	}

	int numChildren = joint->num_children();
	for (int c = 0; c < numChildren; c++)
	{
		drawJoint(character, joint->child(c), &loc);
	}
}

int SmartBodyObject::commandPlugIn(int argc, char **argv)
{
	// let the parent class (PlugIn) handle the commands first
	int ret = PlugIn::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

	if (strcmp(argv[0], "dump") == 0)
	{
		// dump all the recorded characters
		for (std::map<int, Character*>::iterator iter = m_recordedCharacters.begin();
		     iter != m_recordedCharacters.end();
			 iter++)
		{
			Character* c = (*iter).second;
			std::stringstream str;
			str << c->getName() << ".bvh";
			c->saveBVH((char*) str.str().c_str());
		}
		return DANCE_CONTINUE;
	}
	else if (strcmp(argv[0], "start") == 0)
	{
		this->startSmartBody();
		return DANCE_CONTINUE;
	}
	else if (strcmp(argv[0], "end") == 0)
	{
		this->endSmartBody();
		return DANCE_CONTINUE;
	}
	else if (strcmp(argv[0], "cmd") == 0)
	{
		danceInterp::OutputMessage("Executing in SmartBody: %s", argv[1]);
		// send the instructions to smartbody
		mcuCBHandle& mcu = mcuCBHandle::singleton();
		int ret = mcu.execute(argv[1]);
		if (ret == CMD_SUCCESS)
			return DANCE_CONTINUE;
		else if (ret == CMD_NOT_FOUND)
		{
			danceInterp::OutputMessage("Command was not found: %s", argv[1]);
			return DANCE_ERROR;
		}
		else if (ret == CMD_FAILURE)
		{
			danceInterp::OutputMessage("Problem running command: %s", argv[1]);
			return DANCE_ERROR;
		}
	}

	return DANCE_CONTINUE; // command was not found
}

void SmartBodyObject::render(int argc, char** argv, std::ofstream& file)
{
}

void SmartBodyObject::save(int mode, std::ofstream& file)
{
//	char buff[512];

	if (mode == 0)
	{
		file << "dance.instance(\"SmartBodyObject\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
		PlugIn::save(mode, file); // let the parent class handle saving in this mode
	}
	else if (mode == 2)
	{
		// add any commands that rely upon other plugins
		PlugIn::save(mode, file); // let the parent class handle saving in this mode
	}
}

fltk::Widget* SmartBodyObject::getInterface()
{
	if (gui == NULL) 
	{
		gui = new SmartBodyObjectWindow(this, 0, 0, 300, 600, this->getName());
	}

	return gui;
}

int SmartBodyObject::interact(Event* event)
{
	double x, y;
	int button;

	switch (event->getEventType())
	{
		case fltk::KEY:
				switch (fltk::event_key())
				{
				case 'u':
					danceInterp::OutputMessage("Attempting to update...");
					m_bonebus->Update();
					break;		
				case 'o':
					if (!m_bonebus->IsOpen()) 
					{
						danceInterp::OutputMessage("Attempting to connect...");
						m_bonebus->OpenConnection();
						if (m_bonebus->IsOpen()) 
						{
							m_connected->setValue(true);
						}
					}
					else
					{
						danceInterp::OutputMessage("Connection already open. Please close connection first with 'c'.");
					}

					break;
				case 'c':
					if (m_bonebus->IsOpen()) 
					{
						danceInterp::OutputMessage("Attempting to close connection...");
						m_bonebus->CloseConnection();
						if (!m_bonebus->IsOpen()) 
						{
							m_connected->setValue(false);
						}
					}
					else
					{
						danceInterp::OutputMessage("Connection is closed. Please open connection first with 'o'.");
					}

					break;
				default:
					//danceInterp::OutputMessage("Keyboard button %c was pushed.", fltk::event_key());
					break;
				}
				return -1;
			break;
		case fltk::PUSH:
			button = fltk::event_button();
			x = (float) fltk::event_x();
			y = (float) fltk::event_x();
			//danceInterp::OutputMessage("Mouse button %d was pushed at (%f, %f)", button, x, y);
			return -1;

			break;
		case fltk::RELEASE:
			//danceInterp::OutputMessage("Mouse button was released...");
			return -1;
			break;
		case fltk::DRAG:
			//danceInterp::OutputMessage("Mouse was dragged...");
			return -1;
			break;
		default:
			break;
	}

	return 0;
}

void SmartBodyObject::notify(DSubject* subject)
{
	PlugIn::notify(subject);

	if (subject == m_update)
	{
		if (m_update->getValue() == true)
		{
			if (m_bonebus->IsOpen())
			{
				fltk::remove_idle(SmartBodyObject::checkForUpdates, this);
				fltk::add_idle(SmartBodyObject::checkForUpdates, this);
			}
		}
		else
		{
				fltk::remove_idle(SmartBodyObject::checkForUpdates, this);
		}
	}
	else if (subject == m_connect)
	{
		if (m_connect->getValue() == true)
		{
			if (!m_bonebus->IsOpen()) 
			{
				bool success = m_bonebus->OpenConnection();
				m_connected->setValue(success);
			}
		}
		else
		{
			if (m_bonebus->IsOpen()) 
			{
				bool success = m_bonebus->CloseConnection();
				m_connected->setValue(!success);
			}
		}
	}
	else if (subject == m_showJoints)
	{
		std::map<int, Character*>& characters = this->getCharacters();
		for (std::map<int, Character*>::iterator iter = characters.begin();
			iter != characters.end();
			iter++)
		{
			(*iter).second->setShowJoints(m_showJoints->getValue());
		}
	}
	else if (subject == m_showBones)
	{
		std::map<int, Character*>& characters = this->getCharacters();
		for (std::map<int, Character*>::iterator iter = characters.begin();
			iter != characters.end();
			iter++)
		{
			(*iter).second->setShowBones(m_showBones->getValue());
		}
	}
	else if (subject == m_showCOM)
	{

	}
	else if (subject == m_recordMotion)
	{
		#ifdef WIN32
		m_startTime = GetTickCount();
#else
		gettimeofday(&m_startTime, NULL);
#endif
	}
	else if (subject == m_run)
	{
		if (m_run->getValue())
		{
			this->startSmartBody();
		}
		else
		{
			this->endSmartBody();
		}
	}
	else if (subject == m_trackCharacter)
	{
		if (!m_inControllerTraverse)
			getControllerInfo(false, true, true, true, false, false);
	}
	else if (subject == m_trackJoint)
	{
		std::string whichCharacter = m_trackCharacter->getValue();
		if (whichCharacter == "")
			return;

		mcuCBHandle& mcu = mcuCBHandle::singleton();
		SbmCharacter* character = mcu.character_map.lookup(whichCharacter.c_str());
		if (!character)
			return;

		std::string whichJoint = m_trackJoint->getValue();
		if (whichJoint == "")
			return;
		SkJoint* joint = character->skeleton_p->search_joint(whichJoint.c_str());
		if (!joint)
			return;

		m_lookAtJoint = joint;
	}
	else if (subject == m_controller)
	{
		if (!m_inControllerTraverse)
			getControllerInfo(false, false, false, true, false, false);
		if (m_isolateController->getValue())
		{
			std::string whichCharacter = m_trackCharacter->getValue();
			if (whichCharacter == "")
				return;

			std::string controllerName = m_controller->getValue();
			if (controllerName == "")
				return;

			if (m_controllerVizSkeleton)
				delete m_controllerVizSkeleton;
			m_controllerVizSkeleton = NULL;
			m_controllerVizSkeleton = setUpControllerVisualization(whichCharacter, controllerName, m_isolateController->getValue());
		}
	}
	else if (subject == m_motions)
	{
		// make sure that a character has been selected
		if (m_trackCharacter->getValue() == "")
			return;
		// get the name of the motion
		std::string motionName = m_motions->getValue();
		std::stringstream strstr;
		strstr << "dance.generic(\"" << getName() << "\", \"cmd\", \"test bml char " << m_trackCharacter->getValue() << " anim " << motionName << "\")";
		danceInterp::ExecuteCommand(strstr.str().c_str());
	}
	else if (subject == m_poses)
	{
	}
	else if (subject == m_useFaceBones)
	{
	}
	else if (dynamic_cast<DAttribute*>(subject)->getObject() != this)
	{
		DAttribute* attribute = dynamic_cast<DAttribute*>(subject);
		std::vector<DConnection*> list;
		dance::connectionManager->getFromConnections("gazetarget", this, list);
		if (list.size() > 0)
		{
			for (int i = 0; i < list.size(); i++)
			{
				DGeometry* geometry = dynamic_cast<DGeometry*>(list[i]->getTo());
				if (geometry)
				{
					std::string characterName = m_trackCharacter->getValue();
					// send the gaze command that will update the gaze target to the new location
					std::stringstream strstr;
					double matrix[4][4];
					geometry->getTransMatrix(matrix);;
					strstr << "dance.generic(\"" << getName() << "\", \"cmd\", \"gaze gazecontroller_" << characterName.c_str() << " target point " << matrix[3][0] << " " << matrix[3][1] << " " << matrix[3][2] << "\")";
					danceInterp::ExecuteCommand(strstr.str().c_str());
					return;
				}
			}
			return;	
		}
		dance::connectionManager->getFromConnections("locomotiontarget", this, list);
		if (list.size() > 0)
		{
			for (int i = 0; i < list.size(); i++)
			{
				DGeometry* geometry = dynamic_cast<DGeometry*>(list[i]->getTo());
				if (geometry)
				{
					std::string characterName = m_trackCharacter->getValue();
					// send the locomotion command that will update the locomotion target to the new location
					std::stringstream strstr;
					double matrix[4][4];
					geometry->getTransMatrix(matrix);;
					strstr << "dance.generic(\"" << getName() << "\", \"cmd\", \"test loco char " << characterName.c_str() << " tx " << matrix[3][0] << " tz " << matrix[3][2] << "\")";
					danceInterp::ExecuteCommand(strstr.str().c_str());
					return;
				}
			}
			return;	
		}		
	}
	else if (subject == m_isolateController)
	{
		std::string whichCharacter = m_trackCharacter->getValue();
		if (whichCharacter == "")
			return;

		std::string controllerName = m_controller->getValue();
		if (controllerName == "")
			return;

		if (m_controllerVizSkeleton)
			delete m_controllerVizSkeleton;
		m_controllerVizSkeleton = NULL;
		m_controllerVizSkeleton = setUpControllerVisualization(whichCharacter, controllerName, m_isolateController->getValue());
			return;
	}
	else if (subject == m_isolateAllControllers)
	{
		if (m_isolateAllControllers->getValue())
		{
			std::string whichCharacter = m_trackCharacter->getValue();
			if (whichCharacter == "")
				return;

			mcuCBHandle& mcu = mcuCBHandle::singleton();
			cleanUpMultipleControllerVisualizations();
			setUpMultipleControllerVisualizations(whichCharacter, "", mcu.time);
		}
		else
		{
			cleanUpMultipleControllerVisualizations();
		}
		return;
	}
	else if (subject == m_showControllerInfo)
	{
		getControllerInfo(true, true, true, true, true, false);
	}
	else if (subject == m_showControllerMap)
	{
		getControllerInfo(true, true, true, true, true, true);
	}
	else if (subject == m_disableControllers)
	{
		mcuCBHandle& mcu = mcuCBHandle::singleton();
		srHashMap<SbmCharacter>& character_map = mcu.character_map;
		character_map.reset(); // resets the internal iterator
		SbmCharacter* character = character_map.next();
		while (character)
		{	
			MeControllerTreeRoot* controllerTree = character->ct_tree_p;
			int numControllers = controllerTree->count_controllers();

			for (int c = 0; c < numControllers; c++)
			{
				MeController* controller = controllerTree->controller(c);
				if (controller->is_pass_through() != m_disableControllers->getValue())
				{
					controller->set_pass_through(m_disableControllers->getValue());
				}
			}
			character = character_map.next();
		}
	}
	else 
	{
		for (int x = 0; x < m_visemes.size(); x++)
		{
			if (subject == m_visemes[x])
			{
				// make sure that a character has been selected
				std::string whichCharacter = "*";
				if (m_trackCharacter->getValue() != "")
					whichCharacter = m_trackCharacter->getValue();
				// get the name of the viseme
				std::string visemeName = m_visemes[x]->getName();
				std::stringstream strstr;
				strstr << "dance.generic(\"" << getName() << "\", \"cmd\", \"char " << whichCharacter << " viseme " << visemeName << " " << m_visemes[x]->getValue() << " 0\")";
				danceInterp::ExecuteCommand(strstr.str().c_str());
				break;
			}
		}
	}
}

void SmartBodyObject::cleanUpMultipleControllerVisualizations()
{
	// remove the old skeletons
	for (std::map<std::string, std::pair<SkSkeleton*, Character*> >::iterator iter = m_allControllerVizSkeletons.begin();
		iter != m_allControllerVizSkeletons.end();
		iter++)
	{
		SkSkeleton* skeleton = (*iter).second.first;
		delete skeleton;
		Character* character = (*iter).second.second;
		std::vector<DConnection*> list;
		dance::connectionManager->getFromConnections("joint", character, list); 
		for (int c = 0; c < list.size(); c++)
		{
			DObject* object = list[c]->getTo();
			dance::AllGenericPlugins->remove(object);

		}

		dance::AllGenericPlugins->remove(character);
	}
	m_allControllerVizSkeletons.clear();
}

void SmartBodyObject::setUpMultipleControllerVisualizations(std::string whichCharacter, std::string controllerToWatch, double time)
{
	mcuCBHandle& mcu = mcuCBHandle::singleton();
	SbmCharacter* character = mcu.character_map.lookup(whichCharacter.c_str());
	if (!character)
		return;

	// make sure that a MotionPlayer exists
	std::string mpName = "smartbody motion player";
	MotionPlayer* motionPlayer = dynamic_cast<MotionPlayer*>(dance::getObject((char*) mpName.c_str()));
	
	if (!motionPlayer)
	{	
		danceInterp::ExecuteCommand("dance.instance(\"MotionPlayer\", \"smartbody motion player\")");
		DObject* object = dance::getObject((char*) mpName.c_str());
		motionPlayer = dynamic_cast<MotionPlayer*>(object);
	}

	MeControllerTreeRoot* controllerTree = character->ct_tree_p;
	int numControllers = controllerTree->count_controllers();

	for (int c = 0; c < numControllers; c++)
	{
		MeController* controller = controllerTree->controller(c);
		bool addNew = false;
		if (controllerToWatch == controller->name())
			addNew = true;
		setUpMultipleControllerVisualizationsRecurse(controller, whichCharacter, m_allControllerVizSkeletons, addNew, time);
	}

	if (!motionPlayer)
		return;

	for (std::map<std::string, std::pair<SkSkeleton*, Character*> >::iterator iter = m_allControllerVizSkeletons.begin();
		iter != m_allControllerVizSkeletons.end();
		iter++)
	{
		Character* character = (*iter).second.second;
		dance::connectionManager->makeConnection(motionPlayer, "plays", character);
	}
}

void SmartBodyObject::setUpMultipleControllerVisualizationsRecurse(MeController* controller, std::string characterName, 
																   std::map<std::string, std::pair<SkSkeleton*, Character*> >& allSkeletons, bool addNewControllers, double time)
{
	bool add = false;
	if (addNewControllers)
	{
		std::map<std::string, std::pair<SkSkeleton*, Character*> >::iterator controllerIter = allSkeletons.find(std::string(controller->name()));
		if (controllerIter == allSkeletons.end())
			add = true;
	}

	if (add)
	{
		SkSkeleton* skeleton = NULL;
		// don't set up skeletons for blend or timing controllers
		MeCtBlend* blendController = dynamic_cast<MeCtBlend*>(controller);
		MeCtTimeShiftWarp* timeShiftController = dynamic_cast<MeCtTimeShiftWarp*>(controller);
		
		bool isVisemeController = false;
		std::string controllerName = controller->name();
		if (controllerName.find("Viseme") == 0)
			isVisemeController = true;

		if (!blendController && !timeShiftController && !isVisemeController)
		{
			// make sure this is not a viseme
			skeleton = setUpControllerVisualization(characterName, controller->name(), true);
		}
		
		if (skeleton)
		{
			Character* character = createCharacterFromSkeleton(skeleton, controller->name());
			if (character)
			{
				character->setOffsetTime(time);
				dance::AllGenericPlugins->add(character);
				allSkeletons.insert(std::pair<std::string, std::pair<SkSkeleton*, Character*> >(controller->name(), std::pair<SkSkeleton*, Character*>(skeleton, character)));
			}
			else
			{
				delete skeleton;
			}
		}
	}

	int numChildren = controller->count_children();
	for (int c = 0; c < numChildren; c++)
	{
		MeController* childController = controller->child(c);
		setUpMultipleControllerVisualizationsRecurse(childController, characterName, allSkeletons, addNewControllers, time);
	}
}

SkSkeleton* SmartBodyObject::setUpControllerVisualization(std::string characterName, std::string controllerName, bool enable)
{
	MeController* controller = getController(characterName, controllerName);
	if (controller)
	{
		controller->record_buffer_changes(enable);
		m_controllerBuffer = NULL;
		SkSkeleton* vizSkeleton = NULL;

		if (enable)
		{
			// create a new skeleton from the same .sk file as the original skeleton
			mcuCBHandle& mcu = mcuCBHandle::singleton();
			SbmCharacter* character = mcu.character_map.lookup(characterName.c_str());
			if (!character)
				return NULL;
			SkSkeleton* origSkeleton = character->skeleton_p;

			// copy the orig skeleton
			std::string filename = "vizskeleton.sk";
			FILE* outfp = fopen(filename.c_str(), "wt" );
			if (!outfp)
			{
				danceInterp::OutputMessage("Could not save .sk skeleton file %s. Controller effects will not be shown.", filename.c_str());
				return NULL;
			}
			SrOutput output( outfp );
			if( !output.valid() ) {
				danceInterp::OutputMessage("Could not save .sk skeleton file %s. Controller effects will not be shown.", filename.c_str());
				fclose(outfp);
				return NULL;
			}
			origSkeleton->save(output);
			output.close();

			vizSkeleton = new SkSkeleton();
			FILE* fp = fopen( filename.c_str(), "rt" );
			if (!fp)
			{
				danceInterp::OutputMessage("Could not load .sk skeleton file %s. Controller effects will not be shown.", filename.c_str());
				return NULL;
			}
			SrInput input( fp );
			if( !input.valid() ) {
				danceInterp::OutputMessage("Could not load .sk skeleton file %s. Controller effects will not be shown.", filename.c_str());
				return NULL;
			}
			vizSkeleton->load(input);
			danceInterp::OutputMessage("Loaded controller visualization skeleton from sk file: %s.", filename.c_str());
			input.close();

			// reset that SkSkeleton to zero
			float zeros[4] = {0, 0, 0, 0};
			SkChannelArray& channels = vizSkeleton->channels();
			int size = channels.size();
			for (int i = 0; i < size; i++ )
			{
				SkChannel& channel = channels.get(i);
				int channelSize = channel.size();
				int numInserted = channel.set (zeros);
			}
		}
		else
		{

		}
		return vizSkeleton;
	}
	else
	{
		return NULL;
	}
}

Character* SmartBodyObject::createCharacterFromSkeleton(SkSkeleton* skeleton, std::string name)
{
	// copy the orig skeleton
	std::string filename = "vizcharacterskeleton.sk";
	FILE* outfp = fopen(filename.c_str(), "wt" );
	if (!outfp)
	{
		danceInterp::OutputMessage("Could not save .sk skeleton file %s.", filename.c_str());
		return NULL;
	}
	SrOutput output( outfp );
	if( !output.valid() ) {
		danceInterp::OutputMessage("Could not save .sk skeleton file %s.", filename.c_str());
		fclose(outfp);
		return NULL;
	}
	skeleton->save(output);
	output.close();

	// load a new character from the skeleton file
	std::ifstream metafile(filename.c_str(), std::ios::in);
	if (!metafile.good())
	{
		danceInterp::OutputMessage("sk file '%s' is not valid.", filename.c_str());
		return NULL;
	}
	std::ifstream datafile(filename.c_str(), std::ios::in); // use the same file for .skm, since we won't start with any data
											   // this should fail gracefully
	if (!datafile.good())
	{
		danceInterp::OutputMessage("skm file '%s' is not valid.\n", filename.c_str());
		return NULL;
	}
	Character* character = ParserSKM::parse(name, metafile, datafile);
	
	return character;
}

MeController* SmartBodyObject::getController(std::string characterName, std::string controllerName)
{
	mcuCBHandle& mcu = mcuCBHandle::singleton();
	SbmCharacter* character = mcu.character_map.lookup(characterName.c_str());
	if (!character)
		return NULL;
	
	// find the controller on the character
	MeControllerTreeRoot* controllerTree = character->ct_tree_p;
	int numControllers = controllerTree->count_controllers();

	for (int c = 0; c < numControllers; c++)
	{
		MeController* controller = getControllerRecurse(character, controllerTree->controller(c), controllerName);
		if (controller)
			return controller;
	}
	return NULL;
}

MeController* SmartBodyObject::getControllerRecurse(SbmCharacter* character, MeController* controller, std::string name)
{
	if (controller->name() == name)
		return controller;

	int numControllers = controller->count_children();
	for (int c = 0; c < numControllers; c++)
	{
		MeController* childController = getControllerRecurse(character, controller->child(c), name);
		if (childController)
			return childController;
	}

	return NULL;
}

void SmartBodyObject::checkForUpdates(void* data)
{
	SmartBodyObject* smartBody = (SmartBodyObject*) data;

#ifdef WIN32
		DWORD curTime = GetTickCount();
		DWORD timeDiff = curTime - smartBody->getUpdateTime();
#else
		timeval curTime;
		gettimeofday(&curTime, NULL);

		long currentMillis = curTime.tv_sec * 1000 + curTime.tv_usec / 1000;
		long lastMillis = mplayer->getUpdateTime().tv_sec * 1000 + mplayer->getUpdateTime().tv_usec / 1000;
		long timeDiff = currentMillis - lastMillis;
#endif

		DoubleAttribute* dattr = dynamic_cast<DoubleAttribute*>(smartBody->getAttribute("frequency"));
		if (timeDiff >= (1.0 / dattr->getValue()) * 1000)
		{
			if (smartBody->getBoneBusServer()->IsOpen())
			{
				smartBody->getBoneBusServer()->Update();
				smartBody->setUpdateTime(curTime);
			}
		}

		std::map<int, Character*>& characters = smartBody->getCharacters();
		std::map<int, Character*>& recordedCharacters = smartBody->getRecordCharacters();

		if (characters.size() == 0 || recordedCharacters.size() == 0)
		{
			return;
		}
		// record the frame if needed
		BoolAttribute* recordMotion = dynamic_cast<BoolAttribute*>(smartBody->getAttribute("recordmotion"));
		if (recordMotion)
		{
			#ifdef WIN32
				DWORD lastUpdateTimeDiff = curTime - smartBody->getStartTime();
			#else
				timeval curTime;
				gettimeofday(&curTime, NULL);

				long currentMillis = curTime.tv_sec * 1000 + curTime.tv_usec / 1000;
				long lastMillis = smartBody->getStartTime().tv_sec * 1000 + mplayer->getUpdateTime().tv_usec / 1000;
				long lastUpdateTimeDiff = currentMillis - lastMillis;
			#endif
			if (lastUpdateTimeDiff > .033 * 1000)
			{
				// save the motion to the character
				danceInterp::OutputMessage("Recording the motion at time %ld", curTime);
				#ifdef WIN32
						DWORD startTime = GetTickCount();
						smartBody->setStartTime(startTime);
				#else
						timeval startTime;
						gettimeofday(&startTime, NULL);
						smartBody->setStartTime(startTime);
				#endif

					
				

				for (std::map<int, Character*>::iterator iter = characters.begin();
					iter != characters.end();
					iter++)
				{
					Character* character = (*iter).second;

					std::map<int, Character*>::iterator recordIter = recordedCharacters.find((*iter).first);
					if (recordIter != recordedCharacters.end())
					{
						Character* recordChar = (*recordIter).second;
						character->copyFrames(recordChar, 0);
					}
				}
			}
		}
}

#ifdef WIN32
DWORD SmartBodyObject::getUpdateTime()
#else
timeval SmartBodyObject::getUpdateTime()
#endif
{
	return m_updateTime;
}

#ifdef WIN32
DWORD SmartBodyObject::getStartTime()
#else
timeval SmartBodyObject::getStartTime()
#endif
{
	return m_startTime;
}

#ifdef WIN32
void SmartBodyObject::setUpdateTime(DWORD time)
{
	m_updateTime = time;
}
void SmartBodyObject::setStartTime(DWORD time)
{
	m_startTime = time;
}
#else
void SmartBodyObject::setUpdateTime(timeval time)
{
	m_updateTime.tv_sec = time.tv_sec;
	m_updateTime.tv_usec = time.tv_usec;
}
void SmartBodyObject::setStartTime(timeval time)
{
	m_startTime.tv_sec = time.tv_sec;
	m_startTime.tv_usec = time.tv_usec;
}
#endif

BoneBusServer* SmartBodyObject::getBoneBusServer()
{
	return m_bonebus;
}

void SmartBodyObject::OnClientConnect( std::string clientName, void * userData )
{
   danceInterp::OutputMessage( "Client Connected! - %s", clientName.c_str() );

   SmartBodyObject* smartBody = (SmartBodyObject*) userData;

   BoolAttribute* battr = dynamic_cast<BoolAttribute*>(smartBody->getAttribute("clientconnected"));
   battr->setValue(true);
}

void SmartBodyObject::OnClientDisonnect( )
{
	danceInterp::OutputMessage( "Client Disconnected!" );

	// since the OnClientDisconnect callback doesn't include any user data,
	// we need another way to access the SmartBodyObject instance.
	SmartBodyObject* smartBody = SmartBodyObject::smartInstance;

	BoolAttribute* battr = dynamic_cast<BoolAttribute*>(smartBody->getAttribute("clientconnected"));
	battr->setValue(false);
}

void SmartBodyObject::OnCreateCharacter( const int characterID, const std::string characterType, const std::string characterName, const int skeletonType, void * userData )
{
	SmartBodyObject* smartBody = (SmartBodyObject*) userData;

	danceInterp::OutputMessage( "Character Create! - %d, %s, %s, %d", characterID, characterType.c_str(), characterName.c_str(), skeletonType );

	std::map<std::string, DAttribute*>& attributes = smartBody->getAttributeList();

	StringAttribute* skelAttr = dynamic_cast<StringAttribute*>(attributes["skeletonfile"]);
	std::string fileLocation = skelAttr->getValue();
	
	std::ifstream file(fileLocation.c_str(), std::ios::in);
	if (!file.good())
	{
		danceInterp::OutputMessage("Skeleton file '%s' is not valid.\n", fileLocation.c_str());
		return;
	}
	Character* character = ParserBVH::parse(characterName.c_str(), file);
	dance::AllGenericPlugins->add(character);
	character->setScale(1.0); // the character ~might~ need to be scaled, since DANCE usually handles meters, not centimeters
	BoolAttribute* showJoints = dynamic_cast<BoolAttribute*>(attributes["showjoints"]);
	character->setShowBones(showJoints->getValue());
	BoolAttribute* showBones = dynamic_cast<BoolAttribute*>(attributes["showbones"]);
	character->setShowJoints(showBones->getValue());

	std::map<int, Character*>& characters = smartBody->getCharacters();
	characters[characterID] = character; 
	character->calculateMatrices(0);

	// create a duplicate character on which to save the animation
	std::map<int, Character*>& recordedCharacters = smartBody->getRecordCharacters();
	Character* recChar = character->copy((char*) character->getName());
	recordedCharacters[characterID] = recChar; 

	dance::AllViews->postRedisplay();
}

void SmartBodyObject::OnDeleteCharacter( const int characterID, void * userData )
{
	SmartBodyObject* smartBody = (SmartBodyObject*) userData;
   
	danceInterp::OutputMessage( "Character Delete! - %d", characterID );
	std::map<int, Character*>& characters = smartBody->getCharacters();

	std::map<int, Character*>::iterator iter = characters.find(characterID);
	if (iter != characters.end())
	{
	   delete (*iter).second;
	   characters.erase(iter);
	}
	dance::AllViews->postRedisplay();
}

void SmartBodyObject::OnSetCharacterPosition( const int characterID, const float one, const float two, const float three, void * userData )
{
	SmartBodyObject* smartBody = (SmartBodyObject*) userData;

	std::map<int, Character*>& characters = smartBody->getCharacters();
	std::map<int, Character*>::iterator iter = characters.find(characterID);
	if (iter == characters.end())
	{
		danceInterp::OutputMessage( "No character with id %d found.", characterID);
		return;
	}

	Character* c = (*iter).second;
	CharJoint* root = c->getRoot();
	root->setFrame(0, one, 0);
	root->setFrame(0, two, 1);
	root->setFrame(0, three, 2);
	c->calculateMatrices(0);
	dance::AllViews->postRedisplay();
}

void SmartBodyObject::OnSetCharacterRotation( const int characterID, const float w, const float x, const float y, const float z, void * userData )
{
	SmartBodyObject* smartBody = (SmartBodyObject*) userData;

	std::map<int, Character*>& characters = smartBody->getCharacters();
	std::map<int, Character*>::iterator iter = characters.find(characterID);
	if (iter == characters.end())
	{
		danceInterp::OutputMessage( "No character with id %d found.", characterID);
		return;
	}

	Character* c = (*iter).second;
	CharJoint* root = c->getRoot();

	VectorObj position;
	double frame[6];
	root->getFrames(0, frame);

	Quaternion q1(x, y, z, w);
	//Quaternion q1(-y, z, x, w);
	root->setFrame(0, &q1);
	for (int i = 0; i < 3; i++) // reset the position
		root->setFrame(0, frame[i], x);

	c->calculateMatrices(0);
	dance::AllViews->postRedisplay();

}

void SmartBodyObject::OnBoneRotations( const BulkBoneRotations* bulkBoneRotations, void * userData )
{
	SmartBodyObject* smartBody = (SmartBodyObject*) userData;

	std::map<int, Character*>& characters = smartBody->getCharacters();
	std::map<int, Character*>::iterator iter = characters.find(bulkBoneRotations->charId);
	if (iter == characters.end())
	{
		danceInterp::OutputMessage( "No character with id %d found.", bulkBoneRotations->charId);
		return; 
	}

	Character* c = (*iter).second;

	int numRotations =  bulkBoneRotations->numBoneRotations;
	for (int r = 0; r < numRotations; r++)
	{
		CharJoint* joint = smartBody->getJointIndexFromBoneId(c, bulkBoneRotations->bones[r].boneId);
		Quaternion q1(bulkBoneRotations->bones[r].rot_x, bulkBoneRotations->bones[r].rot_y, bulkBoneRotations->bones[r].rot_z, bulkBoneRotations->bones[r].rot_w);
		q1.normalize();
		q1 *= -1;
		if (joint)
			joint->setFrame(0, &q1);
		else
			danceInterp::OutputMessage("Cannot find joint with id %d", bulkBoneRotations->bones[r].boneId);
	}

	c->calculateMatrices(0);
	dance::AllViews->postRedisplay();
}

void SmartBodyObject::OnBonePositions( const BulkBonePositions* bulkBonePositions, void * userData )
{
	SmartBodyObject* smartBody = (SmartBodyObject*) userData;

	std::map<int, Character*>& characters = smartBody->getCharacters();
	std::map<int, Character*>::iterator iter = characters.find(bulkBonePositions->charId);
	if (iter == characters.end())
	{
		danceInterp::OutputMessage( "No character with id %d found.", bulkBonePositions->charId);
		return; 
	}

	Character* c = (*iter).second;

	int numPositions =  bulkBonePositions->numBonePositions;
	for (int r = 0; r < numPositions; r++)
	{
		CharJoint* joint = smartBody->getJointIndexFromBoneId(c, bulkBonePositions->bones[r].boneId);
		if (joint)
		{
			int startTransChannel = joint->getFirstTranslationChannel();
			int endTransChannel = joint->getLastTranslationChannel();
			double frames[6];
			joint->getFrames(0, frames);
			frames[startTransChannel] = bulkBonePositions->bones[r].pos_x;
			frames[startTransChannel + 1] = bulkBonePositions->bones[r].pos_y;
			frames[startTransChannel + 2] = bulkBonePositions->bones[r].pos_z;
			joint->setFrame(0, frames);
		}
		else
		{
			danceInterp::OutputMessage("Cannot find joint with id %d", bulkBonePositions->bones[r].boneId);
		}
	}

	c->calculateMatrices(0);
	dance::AllViews->postRedisplay();
}

void SmartBodyObject::OnSetCharacterVisemeFunc( const int characterID, const int visemeId, const float weight, const float blendTime, void * userData )
{
   danceInterp::OutputMessage( "Set Viseme! - %d %d %f %f", characterID, visemeId, weight, blendTime);
}

void SmartBodyObject::OnPlaySoundFunc( const std::string & soundFile, const std::string & characterName, void * userData )
{
	danceInterp::OutputMessage( "Sound played! - %s %s %d", soundFile.c_str(), characterName.c_str() );
}

void SmartBodyObject::OnStopSoundFunc(  const std::string & soundFile, void * userData )
{
	danceInterp::OutputMessage( "Sound stopped! - %s %s %d", soundFile.c_str());
}

void SmartBodyObject::OnExecScriptFunc(  const char * command, void * userData )
{
	danceInterp::OutputMessage( "Script executed! - %s", command );
}

void SmartBodyObject::OnSetCharacterShaderParamFunc(const char * name,const int name_id, void * userData)
{
	danceInterp::OutputMessage( "Shader parameter! - %s %d %d", name, name_id);
}

void SmartBodyObject::OnGeneralParamFunc(const BulkGeneralParams* bulkShaderParams, void * userData)
{
	danceInterp::OutputMessage( "Bulk shader params!");
}

std::map<int, Character*>& SmartBodyObject::getCharacters()
{
	return m_characters;
}

std::map<int, Character*>& SmartBodyObject::getRecordCharacters()
{
	return m_recordedCharacters;
}

CharJoint* SmartBodyObject::getJointIndexFromBoneId(Character* character, int id)
{
	std::map<int, std::string>::iterator iter = m_skeleton.find(id);
	if (iter != m_skeleton.end())
	{
		std::string boneName = (*iter).second;
		return character->getJointByName((char*) boneName.c_str());
	}

	return 0;
}

void SmartBodyObject::initSkeletonMapping()
{
	m_skeleton[ 0 ] = ""; // unused
	m_skeleton[ 1 ] = ""; //"skeleton";
	m_skeleton[ 2 ] = "base";
	m_skeleton[ 3 ] = "l_hip";
	m_skeleton[ 4 ] = "l_knee";
	m_skeleton[ 5 ] = "l_ankle";
	m_skeleton[ 6 ] = "l_forefoot";
	m_skeleton[ 7 ] = "l_toe";
	m_skeleton[ 8 ] = "r_hip";
	m_skeleton[ 9 ] = "r_knee";
	m_skeleton[ 10 ] = "r_ankle";
	m_skeleton[ 11 ] = "r_forefoot";
	m_skeleton[ 12 ] = "r_toe";
	m_skeleton[ 13 ] = "spine1";
	m_skeleton[ 14 ] = "spine2";
	m_skeleton[ 15 ] = "spine3";
	m_skeleton[ 16 ] = "spine4";
	m_skeleton[ 17 ] = "spine5";
	m_skeleton[ 18 ] = "skullbase";
	m_skeleton[ 19 ] = "face_top_parent";
	m_skeleton[ 20 ] = "brow_parent_left";
	m_skeleton[ 21 ] = "brow01_left";
	m_skeleton[ 22 ] = "brow02_left";
	m_skeleton[ 23 ] = "brow03_left";
	m_skeleton[ 24 ] = "brow04_left";
	m_skeleton[ 25 ] = "brow_parent_right";
	m_skeleton[ 26 ] = "brow01_right";
	m_skeleton[ 27 ] = "brow02_right";
	m_skeleton[ 28 ] = "brow03_right";
	m_skeleton[ 29 ] = "brow05_right";
	m_skeleton[ 30 ] = "ear_left";
	m_skeleton[ 31 ] = "eyeball_left";
	m_skeleton[ 32 ] = "upper_nose_left";
	m_skeleton[ 33 ] = "lower_nose_left";
	m_skeleton[ 34 ] = "upper_nose_right";
	m_skeleton[ 35 ] = "lower_nose_right";
	m_skeleton[ 36 ] = "lower_eyelid_right";
	m_skeleton[ 37 ] = "upper_eyelid_right";
	m_skeleton[ 38 ] = "eyeball_right";
	m_skeleton[ 39 ] = "ear_right";
	m_skeleton[ 40 ] = "lower_eyelid_left";
	m_skeleton[ 41 ] = "upper_eyelid_left";
	m_skeleton[ 42 ] = "joint18";
	m_skeleton[ 43 ] = "face_bottom_parent";
	m_skeleton[ 44 ] = "Jaw";
	m_skeleton[ 45 ] = "Jaw_back";
	m_skeleton[ 46 ] = "Jaw_front";
	m_skeleton[ 47 ] = "Lip_bttm_mid";
	m_skeleton[ 48 ] = "Lip_bttm_right";
	m_skeleton[ 49 ] = "Lip_bttm_left";
	m_skeleton[ 50 ] = "Tongue_back";
	m_skeleton[ 51 ] = "Tongue_mid";
	m_skeleton[ 52 ] = "Tongue_front";
	m_skeleton[ 53 ] = "Lip_top_left";
	m_skeleton[ 54 ] = "Lip_top_right";
	m_skeleton[ 55 ] = "Cheek_low_right";
	m_skeleton[ 56 ] = "Cheek_up_right";
	m_skeleton[ 57 ] = "cheek_low_left";
	m_skeleton[ 58 ] = "Cheek_up_left";
	m_skeleton[ 59 ] = "Lip_out_left";
	m_skeleton[ 60 ] = "Lip_out_right";
	m_skeleton[ 61 ] = "Lip_top_mid";
	m_skeleton[ 62 ] = "l_sternoclavicular";
	m_skeleton[ 63 ] = "l_acromioclavicular";
	m_skeleton[ 64 ] = "l_shoulder";
	m_skeleton[ 65 ] = "l_elbow";
	m_skeleton[ 66 ] = "l_forearm";
	m_skeleton[ 67 ] = "l_wrist";
	m_skeleton[ 68 ] = "l_pinky1";
	m_skeleton[ 69 ] = "l_pinky2";
	m_skeleton[ 70 ] = "l_pinky3";
	m_skeleton[ 71 ] = "l_pinky4";
	m_skeleton[ 72 ] = "l_ring1";
	m_skeleton[ 73 ] = "l_ring2";
	m_skeleton[ 74 ] = "l_ring3";
	m_skeleton[ 75 ] = "l_ring4";
	m_skeleton[ 76 ] = "l_middle1";
	m_skeleton[ 77 ] = "l_middle2";
	m_skeleton[ 78 ] = "l_middle3";
	m_skeleton[ 79 ] = "l_middle4";
	m_skeleton[ 80 ] = "l_index1";
	m_skeleton[ 81 ] = "l_index2";
	m_skeleton[ 82 ] = "l_index3";
	m_skeleton[ 83 ] = "l_index4";
	m_skeleton[ 84 ] = "l_thumb1";
	m_skeleton[ 85 ] = "l_thumb2";
	m_skeleton[ 86 ] = "l_thumb3";
	m_skeleton[ 87 ] = "l_thumb4";
	m_skeleton[ 88 ] = "r_sternoclavicular";
	m_skeleton[ 89 ] = "r_acromioclavicular";
	m_skeleton[ 90 ] = "r_shoulder";
	m_skeleton[ 91 ] = "r_elbow";
	m_skeleton[ 92 ] = "r_forearm";
	m_skeleton[ 93 ] = "r_wrist";
	m_skeleton[ 94 ] = "r_pinky1";
	m_skeleton[ 95 ] = "r_pinky2";
	m_skeleton[ 96 ] = "r_pinky3";
	m_skeleton[ 97 ] = "r_pinky4";
	m_skeleton[ 98 ] = "r_ring1";
	m_skeleton[ 99 ] = "r_ring2";
	m_skeleton[ 100 ] = "r_ring3";
	m_skeleton[ 101 ] = "r_ring4";
	m_skeleton[ 102 ] = "r_middle1";
	m_skeleton[ 103 ] = "r_middle2";
	m_skeleton[ 104 ] = "r_middle3";
	m_skeleton[ 105 ] = "r_middle4";
	m_skeleton[ 106 ] = "r_index1";
	m_skeleton[ 107 ] = "r_index2";
	m_skeleton[ 108 ] = "r_index3";
	m_skeleton[ 109 ] = "r_index4";
	m_skeleton[ 110 ] = "r_thumb1";
	m_skeleton[ 111 ] = "r_thumb2";
	m_skeleton[ 112 ] = "r_thumb3";
	m_skeleton[ 113 ] = "r_thumb4";
}

void SmartBodyObject::setPhysicalProperties(SbmCharacter* character)
{
	m_skeletonMasses["base"] = 16.61; 
	m_skeletonMasses["l_hip"] = 8.35;
	m_skeletonMasses["l_knee"] = 4.16;
	m_skeletonMasses["l_ankle"] = .67;
	m_skeletonMasses["l_forefoot"] = .67; 
	m_skeletonMasses["l_toe"] = 0;
	m_skeletonMasses["r_hip"] = 8.35;
	m_skeletonMasses["r_knee"] = 4.16;
	m_skeletonMasses["r_ankle"] = .67;
	m_skeletonMasses["r_forefoot"] = .67; 
	m_skeletonMasses["spine1"] = 7.5;
	m_skeletonMasses["spine2"] = 7.5;
	m_skeletonMasses["spine3"] = 7.5;
	m_skeletonMasses["spine4"] = 7.5;
	m_skeletonMasses["spine5"] = 7.5;
	m_skeletonMasses["skullbase"] = 3; 
	m_skeletonMasses["face_top_parent"] = 3; 
	m_skeletonMasses["l_shoulder"] = 1.79; 
	m_skeletonMasses["l_elbow"] = 1.21; 
	m_skeletonMasses["l_forearm"] = 1.21; 
	m_skeletonMasses["l_wrist"] = 1; 
	m_skeletonMasses["r_shoulder"] = 1.79; 
	m_skeletonMasses["r_elbow"] = 1.21; 
	m_skeletonMasses["r_forearm"] = 1.21; 
	m_skeletonMasses["r_wrist"] = 1; 

	SrArray<SkJoint*> joints = character->skeleton_p->get_joint_array();
	for (std::map<std::string, double>::iterator iter = m_skeletonMasses.begin();
		iter != m_skeletonMasses.end();
		iter++)
	{
		std::string jointName = (*iter).first;
		SkJoint* joint = character->skeleton_p->search_joint(jointName.c_str());
		if (joint)
			joint->mass((*iter).second);
	}
}

BoundingBox* SmartBodyObject::calcBoundingBox(BoundingBox *box)
{
	BoundingBox b;
	std::map<int, Character*>& characters = this->getCharacters();
	for (std::map<int, Character*>::iterator iter = characters.begin();
		iter != characters.end();
		iter++)
	{
		Character* character = (*iter).second;
		
		Vector min;
		Vector max;
		character->getBoundingBox(0, min, max);
		b.xMin = min[0];
		b.yMin = min[1];
		b.zMin = min[2];
		b.xMax = max[0];
		b.yMax = max[1];
		b.zMax = max[2];
	}

	// include the bounding box of the characers produced directly from SmartBody
	m_box.merge(b);

	box->merge(m_box);



	return box;
}

void sbm_vhmsg_callback( const char *op, const char *args, void * user_data ) {
	// Replace singleton with a user_data pointer
	switch( mcuCBHandle::singleton().execute( op, (char *)args ) ) {
        case CMD_NOT_FOUND:
            fprintf( stdout, "SBM ERR: command NOT FOUND: '%s' + '%s'\n> ", op, args );
            break;
        case CMD_FAILURE:
            fprintf( stdout, "SBM ERR: command FAILED: '%s' + '%s'\n> ", op, args );
            break;
    }
}

void exit_callback( void )	{
	{
		mcuCBHandle& mcu = mcuCBHandle::singleton();
		if( mcu.loop )	{
			printf( "SBM NOTE: unexpected exit\n> " );
			mcu.loop = false;
		}

		if ( mcu.play_internal_audio )
		{
			AUDIO_Close();
		}


		// Shutdown notifications
		SbmCharacter::remove_from_scene( "*" );
		mcu.vhmsg_send( "vrProcEnd sbm" );
	}

	mcuCBHandle::destroy_singleton();
	
	XMLPlatformUtils::Terminate();

	printf( "SBM: terminated gracefully.\n> " );


#if SBM_REPORT_MEMORY_LEAKS
	_CrtMemState  state;
	_CrtMemCheckpoint( &state );
	_CrtMemDumpStatistics( &state );
#endif
}

std::vector<std::string> &split(const std::string &s, char delim, std::vector<std::string> &elems) {
    std::stringstream ss(s);
    std::string item;
    while(std::getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return elems;
}


std::vector<std::string> split(const std::string &s, char delim) {
    std::vector<std::string> elems;
    return split(s, delim, elems);
}


std::vector< std::pair<std::string, std::string> > SmartBodyObject::getArguments(std::string args)
{
	std::vector< std::pair<std::string, std::string> > options;

	std::vector<std::string> tokens = split(args, ' ');

	std::string opt;
	std::string value;
	bool isOpt = true;
	for (int t = 0; t < tokens.size(); t++)
	{
		if (isOpt)
		{
			int pos = tokens[t].find("-");
			if (pos == 0)
			{
				opt = tokens[t];
				isOpt = false;
			}
		}
		else
		{
			value = tokens[t];
			if (value.find("-") != 0)
			{
				options.push_back(std::pair<std::string, std::string>(opt, value));
				opt = "";
				value = "";
				isOpt = true;
			}
			else
			{ // some options do not have an associated value, and are combined with their option string
				options.push_back(std::pair<std::string, std::string>(opt, ""));
				opt = value;
				isOpt = false;
			}
		
		}
	}

	if (!isOpt)
	{
		value = "";
		options.push_back(std::pair<std::string, std::string>(opt, value));
	}

	return options;
}

void SmartBodyObject::startSmartBody()
{
	SmartBodyObjectWindow* window = dynamic_cast<SmartBodyObjectWindow*>(getInterface());
//	window->behaviorWindow->getEditorWidget()->getModel()->clearContexts();
//	window->behaviorWindow->getEditorWidget()->getModel()->setEndTime(5.0);

	// change the working directory to the proper smartbody directory
#ifdef WIN32
	::SetCurrentDirectory(m_smartBodyRoot->getValue().c_str());
#else
	setenv("PWD", m_smartBodyRoot->getValue().c_str(), 1);
#endif 
	int argc = 0;
	char** argv = NULL;

	std::string net_host;
	std::vector<std::string> seq_paths;
	std::vector<std::string> me_paths;
	std::vector<std::string> init_seqs;
	std::string proc_id;

	mcuCBHandle& mcu = mcuCBHandle::singleton();

	mcu.register_bmlviewer_factory(new BehaviorViewerFactory());

	mcu_register_callbacks();

	TimeIntervalProfiler* profiler = new TimeIntervalProfiler();
	mcu.register_profiler( *profiler );

	bool lock_dt_mode = false;
	// process the arguments
	std::vector< std::pair<std::string, std::string> >  options = getArguments(m_arguments->getValue());
	for (int x = 0; x < options.size(); x++)
	{
		std::string opt = options[x].first;
		std::string value = options[x].second;

		if (opt.find("-host=") == 0)  // argument starts with -host=
		{
			value = opt.substr(6, opt.size() - 6);
			net_host = value;
		}
		else if(opt == "-mepath" )  // -mepath <dirpath> to specify where Motion Engine files (.sk, .skm) should be loaded from
		{
			danceInterp::OutputMessage("Adding ME path '%s'\n", value.c_str());
			me_paths.push_back(value);
		}
		else if(opt ==  "-seqpath" )  // -mepath <dirpath> to specify where sequence files (.seq) should be loaded from
		{
			danceInterp::OutputMessage("Adding sequence path '%s'\n", value.c_str());

			seq_paths.push_back( value );
		}
		else if(opt ==  "-seq" )  // -seq <filename> to load seq file (replaces old -initseq notation)
		{
			danceInterp::OutputMessage("Loading sequence '%s'\n", value );
			init_seqs.push_back( value );
		}
		else if(opt.find("-procid=") == 0)  // argument starts with -procid=
		{
			proc_id = value;
		}
		else if (opt == "-audio")  // argument equals -audio
		{
			mcu.play_internal_audio = true;
		}
		else if (opt == "-lockdt")  // argument equals -lockdt
		{
			lock_dt_mode = true;
		}
		else if (opt.find("-fps=") == 0) // argument starts with -fps=
		{
			value = opt.substr(5, opt.size() - 5);
			//timer.set_sleep_fps( atof( value.c_str() ) );
		}
		else if (opt == "-perf=")  // argument starts with -perf=
		{
			value = opt.substr(6, opt.size() - 6);
			//timer.set_perf(atof(value.c_str()));
		}
		else if (opt == "-facebone")
		{
			mcu.net_face_bones = true;
		}
		else
		{
			danceInterp::OutputMessage("%s: Unrecognized command line argument: \"%s\"\n", getName(), opt.c_str() );
		}
	}

	if( lock_dt_mode )	{ 
//		timer.set_sleep_lock();
	}

	#if LINK_VHMSG_CLIENT
	char * vhmsg_server = getenv( "VHMSG_SERVER" );
	bool vhmsg_disabled = ( vhmsg_server && strcmp( vhmsg_server, "none" ) == 0 );  // hope there is no valid server named "none"

	int err;

	if( !vhmsg_disabled &&
		vhmsg::ttu_open()==vhmsg::TTU_SUCCESS )
	{
		vhmsg::ttu_set_client_callback( sbm_vhmsg_callback );
		err = vhmsg::ttu_register( "sbm" );
		err = vhmsg::ttu_register( "vrAgentBML" );
		err = vhmsg::ttu_register( "vrSpeak" );
		err = vhmsg::ttu_register( "RemoteSpeechReply" );
		err = vhmsg::ttu_register( "PlaySound" );
		err = vhmsg::ttu_register( "StopSound" );
		err = vhmsg::ttu_register( "CommAPI" );
		err = vhmsg::ttu_register( "object-data" );
		err = vhmsg::ttu_register( "vrAllCall" );
		err = vhmsg::ttu_register( "vrKillComponent" );
		err = vhmsg::ttu_register( "wsp" );

		mcu.vhmsg_enabled = true;
	} else {
		if( vhmsg_disabled ) {
			printf( "SBM: VHMSG_SERVER='%s': Messaging disabled.\n", vhmsg_server?"NULL":vhmsg_server );
		} else {
#if 0 // disable server name query until vhmsg is fixed
			const char* vhmsg_server_actual = vhmsg::ttu_get_server();
			printf( "SBM ERR: ttu_open VHMSG_SERVER='%s' FAILED\n", vhmsg_server_actual?"NULL":vhmsg_server_actual );
#else
			printf( "SBM ERR: ttu_open FAILED\n" );
#endif
		}
		mcu.vhmsg_enabled = false;
	}
#endif
	

	// Sets up the network connection for sending bone rotations over to Unreal
	if( net_host != "" )
	{
		char* netHost = new char[net_host.size()];
		sprintf(netHost, "%s", net_host.c_str());
		mcu.set_net_host( netHost );
	}
	if( proc_id != "" ) {
		mcu.set_process_id( proc_id.c_str() );

		// Using a process id is a sign that we're running in a multiple SBM environment.
		// So.. ignore BML requests with unknown agents by default
		mcu.bml_processor.set_warn_unknown_agents( false );
	}
	

	if ( mcu.play_internal_audio )
	{
		if ( !AUDIO_Init() )
		{
			printf( "ERROR: Audio initialization failed\n" );
		}
	}

	mcu.speech_audiofile_base_path = "../../../../";

	atexit( exit_callback );

	m_cmdLine = new srCmdLine();
	fprintf( stdout, "> " );
	

	setSmartBodyStartTime(get_time());

	std::vector<std::string>::iterator it;

	for( it = me_paths.begin();
	     it != me_paths.end();
		 ++it )
	{
		SrString seq_command = SrString( "path me " ) << (it->c_str());
		mcu.execute( (char *)(const char *)seq_command );
	}

	if( seq_paths.empty() ) {
		danceInterp::OutputMessage( "No sequence paths specified. Adding current working directory to seq path\n" );
		seq_paths.push_back( "." );
	}
	for( it = seq_paths.begin();
	     it != seq_paths.end();
		 ++it )
	{
		SrString seq_command = SrString( "path seq " ) << (it->c_str());
		mcu.execute( (char *)(const char *)seq_command );
	}

	if( init_seqs.empty() ) {
		danceInterp::OutputMessage( "No sequences specified. Loading sequence '%s'\n", "default.seq" );
		init_seqs.push_back( "default.seq"  );
	}

	for( it = init_seqs.begin();
	     it != init_seqs.end();
		 ++it )
	{
		SrString seq_command = SrString( "seq " ) << (it->c_str()) << " begin";
		mcu.execute( (char *)(const char *)seq_command );
	}

	me_paths.clear();
	seq_paths.clear();
	init_seqs.clear();

	/*
	// add any initial seq paths
	std::string initialPaths = m_smartBodyPaths->getValue();
	if (initialPaths != "")
	{
		// parse the initial command by '#'
		int pos = 0;
		do
		{
			pos = initialPaths.find_first_of("#");
			if (pos != std::string::npos)
			{
				std::string path = initialPaths.substr(0, pos);
				mcu.seq_paths.insert((char*) path.c_str());
				initialPaths = initialPaths.substr(pos + 1, initialPaths.length() - pos - 1);
			}
			else
			{
				mcu.seq_paths.insert((char*) initialPaths.c_str());
			}
		} while (pos != std::string::npos);
	}
	*/


	// Notify world SBM is ready to receive messages
	mcu_vrAllCall_func( srArgBuffer(""), &mcu );


	if (m_run->getValue())
		mcuCBHandle::singleton().net_face_bones = m_useFaceBones->getValue();

// execute the initial instruction, if any
	std::string initialCommand = m_defaultSequence->getValue();
	if (initialCommand != "")
	{
		// parse the initial command by '#'
		int pos = 0;
		do
		{
			pos = initialCommand.find_first_of("#");
			if (pos != std::string::npos)
			{
				std::string command = initialCommand.substr(0, pos);
				mcu.execute((char*) command.c_str());
				initialCommand = initialCommand.substr(pos + 1, initialCommand.length() - pos - 1);
			}
			else
			{
				mcu.execute((char*) initialCommand.c_str());
			}
		} while (pos != std::string::npos);
	}

	//timer.start(0);
	this->setSmartBodyCurrentTime(get_time());
	fltk::add_idle(SmartBodyObject::checkForCommands, this);
}

srCmdLine* SmartBodyObject::getCmdLine()
{
	return m_cmdLine;
}

void SmartBodyObject::endSmartBody()
{
	mcuCBHandle& mcu = mcuCBHandle::singleton();
	mcu.reset();
	delete m_cmdLine;
	m_cmdLine = NULL;
	
	fltk::remove_idle(SmartBodyObject::checkForCommands, this);
}

int sbm_main_func( srArgBuffer& args, mcuCBHandle *mcu_p  )	{

	const char* token = args.read_token();
	if( strcmp(token,"id")==0 ) {  // Process specific
		token = args.read_token(); // Process id
		std::string process_id = mcu_p->process_id;
		if( process_id == "") // or doesn't match
			return CMD_SUCCESS;                 // Ignore.
		token = args.read_token(); // Sub-command
	}

	const char* args_raw = args.read_remainder_raw();
	int result = mcu_p->execute( token, srArgBuffer( args_raw ) );
	switch( result ) {
		case CMD_NOT_FOUND:
			fprintf( stdout, "SBM ERR: command NOT FOUND: '%s %s'\n> ", token, args_raw );
			break;
		case CMD_FAILURE:
			fprintf( stdout, "SBM ERR: command FAILED: '%s %s'\n> ", token, args_raw );
			break;
		case CMD_SUCCESS:
			break;
	}
	return CMD_SUCCESS;
}

int sbm_vhmsg_register_func( srArgBuffer& args, mcuCBHandle *mcu_p  )	{
	
	return( CMD_SUCCESS );
}

int sbm_vhmsg_send_func( srArgBuffer& args, mcuCBHandle *mcu_p  )	{
	char* cmdName = args.read_token();
	char* cmdArgs = args.read_remainder_raw();
	return mcu_p->vhmsg_send( cmdName, cmdArgs );
}

int mcu_echo_func( srArgBuffer& args, mcuCBHandle *mcu_p  )	{
	
    fprintf( stdout, "%s\n> ", args.read_remainder_raw() );
	return( CMD_SUCCESS );
}

int mcu_reset_func( srArgBuffer& args, mcuCBHandle *mcu_p  )	{
	// TODO: If arg, call as init, else call previous init
	mcu_p->reset();
	return( CMD_SUCCESS );
}

int mcu_quit_func( srArgBuffer& args, mcuCBHandle *mcu_p  )	{

	mcu_p->loop = false;
	return( CMD_SUCCESS );
}

int show_directory( srArgBuffer& args, mcuCBHandle *mcu_p  )	{

	TCHAR curWorkingDir[MAX_PATH]; 
	::GetCurrentDirectory(MAX_PATH, curWorkingDir);
	std::cout << curWorkingDir << std::endl;
	return( CMD_SUCCESS );
}

void SmartBodyObject::mcu_register_callbacks( void )
{
	
	mcuCBHandle& mcu = mcuCBHandle::singleton();

	mcu.cmd_map.reset();
	mcu.test_cmd_map.reset();
	mcu.print_cmd_map.reset();

	mcu.insert( "pwd",			show_directory );
	mcu.insert( "sbm",			sbm_main_func );

	mcu.insert( "q",			mcu_quit_func );
	mcu.insert( "quit",			mcu_quit_func );
	mcu.insert( "reset",		mcu_reset_func );
	mcu.insert( "echo",			mcu_echo_func );
	
	mcu.insert( "path",			mcu_filepath_func );
	mcu.insert( "seq",			mcu_sequence_func );
	mcu.insert( "seq-chain",	mcu_sequence_chain_func );
	mcu.insert( "send",			sbm_vhmsg_send_func );

	//  cmd prefixes "set" and "print"
	mcu.insert( "set",          mcu_set_func );
	mcu.insert( "print",        mcu_print_func );
	mcu.insert( "test",			mcu_test_func );

	mcu.insert( "viewer",		mcu_viewer_func );
	mcu.insert( "bmlviewer",    mcu_bmlviewer_func);
	mcu.insert( "camera",		mcu_camera_func );
	mcu.insert( "time",		mcu_time_func );

	mcu.insert( "load",			mcu_load_func );
	mcu.insert( "pawn",			SbmPawn::pawn_cmd_func );
	mcu.insert( "char",			SbmCharacter::character_cmd_func );

	mcu.insert( "ctrl",			mcu_controller_func );
	mcu.insert( "sched",		mcu_sched_controller_func );
	mcu.insert( "motion",		mcu_motion_controller_func );
	mcu.insert( "stepturn",		mcu_stepturn_controller_func );
	mcu.insert( "quickdraw",	mcu_quickdraw_controller_func );
	mcu.insert( "gazelimits",   mcu_gaze_limit_func );
	mcu.insert( "gaze",			mcu_gaze_controller_func );
	mcu.insert( "snod",			mcu_snod_controller_func );
	mcu.insert( "lilt",			mcu_lilt_controller_func );
	mcu.insert( "divulge",		mcu_divulge_content_func );
	mcu.insert( "wsp",			mcu_wsp_cmd_func );
	mcu.insert( "create_remote_pawn", SbmPawn::create_remote_pawn_func );

	mcu.insert( "vrAgentBML",   BML_PROCESSOR::vrAgentBML_cmd_func );
	mcu.insert( "bp",		    BML_PROCESSOR::bp_cmd_func );
	mcu.insert( "vrSpeak",		BML_PROCESSOR::vrSpeak_func );

	mcu.insert( "net_reset",           mcu_net_reset );
	mcu.insert( "RemoteSpeechReply",   remoteSpeechResult_func );
	mcu.insert( "RemoteSpeechTimeOut", remoteSpeechTimeOut_func);  // internally routed message
	mcu.insert( "joint_logger",        joint_logger::start_stop_func );
	mcu.insert( "J_L",                 joint_logger::start_stop_func );  // shorthand
	mcu.insert( "locomotion",          locomotion_cmd_func );
	mcu.insert( "loco",                locomotion_cmd_func ); // shorthand
	mcu.insert( "resource",            resource_cmd_func );
	
	mcu.insert( "RemoteSpeechReplyRecieved", remoteSpeechReady_func);  // TODO: move to test commands

	mcu.insert_set_cmd( "bp",             BML_PROCESSOR::set_func );
	mcu.insert_set_cmd( "pawn",           SbmPawn::set_cmd_func );
	mcu.insert_set_cmd( "character",      SbmCharacter::set_cmd_func );
	mcu.insert_set_cmd( "char",           SbmCharacter::set_cmd_func );
	mcu.insert_set_cmd( "face",           mcu_set_face_func );
	mcu.insert_set_cmd( "joint_logger",   joint_logger::set_func );
	mcu.insert_set_cmd( "J_L",            joint_logger::set_func );  // shorthand
	mcu.insert_set_cmd( "test",           sbm_set_test_func );

	mcu.insert_print_cmd( "bp",           BML_PROCESSOR::print_func );
	mcu.insert_print_cmd( "pawn",         SbmPawn::print_cmd_func );
	mcu.insert_print_cmd( "character",    SbmCharacter::print_cmd_func );
	mcu.insert_print_cmd( "char",         SbmCharacter::print_cmd_func );
	mcu.insert_print_cmd( "face",         mcu_print_face_func );
	mcu.insert_print_cmd( "joint_logger", joint_logger::print_func );
	mcu.insert_print_cmd( "J_L",          joint_logger::print_func );  // shorthand
	mcu.insert_print_cmd( "mcu",          mcu_divulge_content_func );
	mcu.insert_print_cmd( "test",         sbm_print_test_func );

	mcu.insert_test_cmd( "args", test_args_func );
	mcu.insert_test_cmd( "bml",  test_bml_func );
	mcu.insert_test_cmd( "fml",  test_fml_func );
	mcu.insert_test_cmd( "locomotion", test_locomotion_cmd_func );
	mcu.insert_test_cmd( "loco",       test_locomotion_cmd_func );  // shorthand
	mcu.insert_test_cmd( "rhet", remote_speech_test);
	mcu.insert_test_cmd( "bone_pos", test_bone_pos_func );
	

	mcu.insert( "net",	mcu_net_func );

	mcu.insert( "PlaySound", mcu_play_sound_func );
	mcu.insert( "StopSound", mcu_stop_sound_func );

	mcu.insert( "uscriptexec", mcu_uscriptexec_func );

	mcu.insert( "CommAPI", mcu_commapi_func );

	mcu.insert( "vrKillComponent", mcu_vrKillComponent_func );
	mcu.insert( "vrAllCall", mcu_vrAllCall_func );
	mcu.insert("vrQuery", mcu_vrQuery_func );

	mcu.insert( "text_speech", text_speech::text_speech_func ); // [BMLR]
}

double SmartBodyObject::getSmartBodyStartTime()
{
	return m_smartBodyStartTime;
}

void SmartBodyObject::setSmartBodyStartTime(double time)
{
		m_smartBodyStartTime = time;
}

double SmartBodyObject::getSmartBodyCurrentTime()
{
	return m_smartBodyCurrentTime;
}

void SmartBodyObject::setSmartBodyCurrentTime(double time)
{
	m_smartBodyCurrentTime = time;
}

void SmartBodyObject::checkForCommands(void* data)
{
	SmartBodyObject* smartBody = (SmartBodyObject*) data;
	mcuCBHandle& mcu = mcuCBHandle::singleton();

	srCmdLine* cmdl = smartBody->getCmdLine();

	double startTime = smartBody->getSmartBodyStartTime();
	double curTime = smartBody->getSmartBodyCurrentTime();
	DoubleAttribute* targetFpsAttr = dynamic_cast<DoubleAttribute*>(smartBody->getAttribute("targetFPS"));
	double desiredFps = 60;
	if (targetFpsAttr)
		targetFpsAttr->getValue();

	double nowTime = get_time();

	double diff = nowTime - curTime;

	if (diff > 1.0 / desiredFps)
	{
		bool update_sim = mcu.update_timer(nowTime);
		//mcu.set_time( nowTime - startTime );
		smartBody->setSmartBodyCurrentTime(nowTime);

		#if LINK_VHMSG_CLIENT
		if( mcu.vhmsg_enabled )	{
			int err = vhmsg::ttu_poll();
			if( err == vhmsg::TTU_ERROR )	{
				fprintf( stderr, "ttu_poll ERROR\n" );
			}
		}
		#endif

		if( cmdl->pending_cmd() )	{
			char *cmd = cmdl->read_cmd();
			if( strlen( cmd ) )	{
				switch( mcu.execute( cmd ) ) {
					case CMD_NOT_FOUND:
						fprintf( stdout, "SBM ERR: command NOT FOUND: '%s'\n> ", cmd );
						break;
					case CMD_FAILURE:
						fprintf( stdout, "SBM ERR: command FAILED: '%s'\n> ", cmd );
						break;
					case CMD_SUCCESS:
						fprintf( stdout, "> " );  // new prompt
						break;
				}
			}
			else	{
				fprintf( stdout, "> " );
			}
			fflush( stdout );
		}

		mcu.theWSP->broadcast_update();
		mcu.update();

		// if the camera is being tracked, change the camera location and lookat parameters
		// the camera should look at the proper joint
		std::vector<DConnection*> conns;
		dance::connectionManager->getConnections("track", conns); // this should be replaced with an object-local version
		for (int i = 0; i < conns.size(); i++)
		{
			if (conns[i]->getFrom() == smartBody)
			{
				DView* trackView = dynamic_cast<DView*>(conns[i]->getTo());
				if (!trackView)
					break;
				if (!smartBody->m_lookAtJoint)
					break;
				smartBody->m_lookAtJoint->update_gmat_up();
				SrMat gmat = smartBody->m_lookAtJoint->gmat();
				VectorObj jointLoc(*gmat.pt(12), *gmat.pt(13), *gmat.pt(14)); 
				VectorObj cameraPos = jointLoc + smartBody->m_trackVector;
				DoubleAttribute* targetAttr[3];
				targetAttr[0] = dynamic_cast<DoubleAttribute*>(trackView->getAttribute("targetx"));
				targetAttr[1] = dynamic_cast<DoubleAttribute*>(trackView->getAttribute("targety"));
				targetAttr[2] = dynamic_cast<DoubleAttribute*>(trackView->getAttribute("targetz"));
				DoubleAttribute* cameraAttr[3];
				cameraAttr[0] = dynamic_cast<DoubleAttribute*>(trackView->getAttribute("posx"));
				cameraAttr[1] = dynamic_cast<DoubleAttribute*>(trackView->getAttribute("posy"));
				cameraAttr[2] = dynamic_cast<DoubleAttribute*>(trackView->getAttribute("posz"));	
				for (int x = 0; x < 3; x++)
				{
					targetAttr[x]->setValue(jointLoc[x]);
					cameraAttr[x]->setValue(cameraPos[x]);
				}
				break;
			}
		}
		// get the latest controller data
		if (smartBody->m_isolateController->getValue())
		{
			SbmCharacter* character = mcu.character_map.lookup(smartBody->m_trackCharacter->getValue().c_str());
			if (character)
			{
				SkSkeleton* origSkeleton = character->skeleton_p;
				MeController* controller = smartBody->getController(smartBody->m_trackCharacter->getValue(), smartBody->m_controller->getValue());
				if (controller)
				{
					//SrBuffer<float>& controllerBuffer = controller->get_buffer_changes();
					//smartBody->m_controllerBuffer = &controllerBuffer;
					std::vector<float>& controllerBuffer = controller->get_buffer_changes();
					smartBody->m_controllerBuffer = &controllerBuffer;

					//if (smartBody->m_controllerBuffer->size() > 0)
					if (smartBody->m_controllerBuffer)
					{
						// update a skeleton that shows only the changes from the controller
						if (smartBody->m_controllerVizSkeleton)
						{
							// NOTE: This will insert zeroes when the controller channel is not in use
							// which is wasteful. It would be better to only insert the values from 
							// the controller channels in use.

							SkChannelArray& controllerChannels = controller->controller_channels();						
							SkChannelArray& channels = smartBody->m_controllerVizSkeleton->channels();
							SkChannelArray& origChannels = origSkeleton->channels();
							int origSize = origChannels.size();
							for (int i = 0; i < origSize; i++ )
							{
								SkChannel& origChannel = origChannels.get(i);
								SkJointName jointName = origChannels.name(i);
								std::string jname = jointName.get_string();
								int origPos = origChannels.float_position(i);
								SkChannel::Type origType = origChannels.type(i);

								// now find the corresponding join in the viz skeleton
								int channelPos = channels.search(jointName, origType);
								if (channelPos != -1)
								{
									SkChannel& channel = channels.get(channelPos);

									int controllerChannelPos = controllerChannels.search(jointName, origType);
									if (controllerChannelPos != -1)
									{
										int floatPos = controllerChannels.float_position(controllerChannelPos);
										int numInserted = channel.set ( &controllerBuffer[floatPos] );
									}
									
								}

							}
							smartBody->m_controllerVizSkeleton->update_global_matrices();					
						}
					}
				}
			}
		}

		if (smartBody->m_isolateAllControllers->getValue())
		{
			SbmCharacter* character = mcu.character_map.lookup(smartBody->m_trackCharacter->getValue().c_str());
			if (character)
			{
				MeControllerTreeRoot* controllerTree = character->ct_tree_p;

				// check to see if any controllers were added. If so, create a corresponding Character object
				smartBody->setUpMultipleControllerVisualizations(smartBody->m_trackCharacter->getValue(), smartBody->m_controller->getValue(), mcu.time);

				SkSkeleton* origSkeleton = character->skeleton_p;
				
				for (std::map<std::string, std::pair<SkSkeleton*, Character*> >::iterator iter = smartBody->m_allControllerVizSkeletons.begin();
					iter != smartBody->m_allControllerVizSkeletons.end();
					iter++)
				{
					SkSkeleton* vizSkeleton = (*iter).second.first;
					MeController* controller = smartBody->getController(smartBody->m_trackCharacter->getValue(), (*iter).first);
					if (controller)
					{
//						SrBuffer<float>& controllerBuffer = controller->get_buffer_changes();
						std::vector<float>& controllerBuffer = controller->get_buffer_changes();

						if (controllerBuffer.size() > 0)
						{
							// update a skeleton that shows only the changes from the controller
							if (vizSkeleton)
							{								
								// NOTE: This will insert zeroes when the controller channel is not in use
								// which is wasteful. It would be better to only insert the values from 								
								// the controller channels in use.							
								SkChannelArray& controllerChannels = controller->controller_channels();						
								SkChannelArray& channels = vizSkeleton->channels();
								SkChannelArray& origChannels = origSkeleton->channels();
								int origSize = origChannels.size();
								for (int i = 0; i < origSize; i++ )
								{
									SkChannel& origChannel = origChannels.get(i);
									SkJointName jointName = origChannels.name(i);
									std::string jname = jointName.get_string();
									int origPos = origChannels.float_position(i);
									SkChannel::Type origType = origChannels.type(i);

									// now find the corresponding join in the viz skeleton
									int channelPos = channels.search(jointName, origType);
									if (channelPos != -1)
									{
										SkChannel& channel = channels.get(channelPos);

										int controllerChannelPos = controllerChannels.search(jointName, origType);
										if (controllerChannelPos != -1)
										{
											int floatPos = controllerChannels.float_position(controllerChannelPos);
											int numInserted = channel.set ( &controllerBuffer[floatPos] );
										}
										
									}

								}					
								
								/*
								// the following will write the data from all the channels 								
								SkChannelArray& channels = vizSkeleton->channels();
								SkChannelArray& origChannels = origSkeleton->channels();
								int numChannels = channels.size();
								for (int i = 0; i < numChannels; i++ )
								{
									SkChannel& channel = channels.get(i);
									SkChannel& origChannel = origChannels.get(i);
									int curPos = channels.float_position(i);
									int origPos = origChannels.float_position(i);
									if (curPos != origPos)
									{
										std::cout << "NO MATCH! " << curPos << " " << origPos << std::endl;
									}

									int bufferIndex = controllerTree->toBufferIndex(i);
									if (bufferIndex >= 0)
									{
										int numInserted = channel.set ( &controllerBuffer[bufferIndex] );
									}
								}			
								*/
								
								
								/*
								// the following will only write the values of the channels in use 								
								SkChannelArray& channels = vizSkeleton->channels();
								SkChannelArray& channelsInUse = controller->controller_channels();
								int numChannelsInUse = channelsInUse.size();
								for( int i = 0 ; i < numChannelsInUse; i++ )
								{
									SkChannel& channel = channelsInUse.get(i);
									int channelSize = channel.size();
									int channelIndex = controller->getContextChannel(i);
									int bufferIndex = controllerTree->toBufferIndex(Z);
									if (bufferIndex == -1)
										continue;
									int numInserted = channel.set(&controllerBuffer[bufferIndex]);
								}
								*/

								vizSkeleton->update_global_matrices();
							}
						}
					}
				}
				// now copy this data to the Character object
				for (std::map<std::string, std::pair<SkSkeleton*, Character*> >::iterator skelIter = smartBody->m_allControllerVizSkeletons.begin();
					skelIter != smartBody->m_allControllerVizSkeletons.end();
					skelIter++)
				{
					SkSkeleton* skeleton = (*skelIter).second.first;
					// transfer the data onto the associated character
					double frame[6];
					Character* character = (*skelIter).second.second;
					const SrArray<SkJoint*>& joints = skeleton->joints();

					double frameTime = 0.033;
					for (int j = 0; j < joints.size(); j++)
					{
						SkJoint* skJoint = joints[j];
						CharJoint* charJoint = character->getJointByIndex(j);
						int nextFrameNum = charJoint->getNumFrames();
						frameTime = charJoint->getFrameTime();

						SkJointQuat* quat = skJoint->quat();
						const SrQuat& theQuat = quat->value();
						Quaternion altQuat(theQuat.x, theQuat.y, theQuat.z, theQuat.w);
						altQuat *= -1.0; // convert from SmartBody quaternions to DANCE quaternions
						Matrix3x3 altMatrix;
						altQuat.toMatrix(altMatrix);
						VectorObj altAngles;
						altMatrix.matToEuler(Matrix3x3::XYZ, altAngles, false);

						int firstTransChannel = charJoint->getFirstTranslationChannel();
						int lastTransChannel = charJoint->getLastTranslationChannel();
						if (firstTransChannel >= 0)
						{
							SkJointPos* pos = skJoint->pos();
							
							// assumes XYZ order
							frame[firstTransChannel] = pos->value()[0];
							frame[firstTransChannel + 1] = pos->value()[1];
							frame[firstTransChannel + 2] = pos->value()[2];

							frame[firstTransChannel + 3] = altAngles.x() * 180.0 / M_PI;
							frame[firstTransChannel + 4] = altAngles.y() * 180.0 / M_PI;
							frame[firstTransChannel + 5] = altAngles.z() * 180.0 / M_PI;
						}
						else
						{
							frame[0] = altAngles.x() * 180.0 / M_PI;
							frame[1] = altAngles.y() * 180.0 / M_PI;
							frame[2] = altAngles.z() * 180.0 / M_PI;
							frame[3] = 0.0;
							frame[4] = 0.0;
							frame[5] = 0.0;
						}
						charJoint->addFrame(frame);

					}
					int numFrames = character->getNumFrames();
					character->setTime(double(numFrames) * frameTime + character->getOffsetTime());
				}
			}
		}

		dance::Refresh();
	}
}

void SmartBodyObject::onConnect(DConnection* connection)
{
	if (connection->getType() == "track")
	{
		// create a tracked view

		TrackView* view = dynamic_cast<TrackView*>(connection->getTo());
		if (!view)
			return;
		std::string whichCharacter = m_trackCharacter->getValue();
		if (whichCharacter == "")
			return;

		mcuCBHandle& mcu = mcuCBHandle::singleton();
		SbmCharacter* character = mcu.character_map.lookup(whichCharacter.c_str());
		if (!character)
			return;

		std::string whichJoint = m_trackJoint->getValue();
		if (whichJoint == "")
			return;
		SkJoint* joint = character->skeleton_p->search_joint(whichJoint.c_str());
		if (!joint)
			return;

		m_lookAtJoint = joint;
		connectTrackCamera(view, joint);
	}
	else if (connection->getType() == "gazetarget")
	{
		// make sure that one of the characters has been selected
		std::string character = m_trackCharacter->getValue();
		if (character == "")
			return;

		// make sure that we are looking at a geometry object
		DGeometry* geometry = dynamic_cast<DGeometry*>(connection->getTo());
		if (!geometry)
			return;


		// listen to the geometry's transformation channels
		DAttribute* matrixAttr = geometry->getAttribute("transmatrix");
		matrixAttr->registerObserver(this);

		// instantiate a gaze controller
		std::stringstream strstr;
		strstr << "dance.generic(\"" << getName() << "\", \"cmd\", \"ctrl gazecontroller_" << character << " gaze\")";
		int ret = danceInterp::ExecuteCommand(strstr.str().c_str());
		if (ret == DANCE_ERROR)
		{
			// could be because the controller already exists - ignore
		}

		strstr.str("");
		Vector loc;
		geometry->getCenter(loc);
		strstr << "dance.generic(\"" << getName() << "\", \"cmd\", \"gaze gazecontroller_" << character << " target point " << loc[0] << " " << loc[1] << " " << loc[2] << "\")";
		ret = danceInterp::ExecuteCommand(strstr.str().c_str());
		if (ret == DANCE_ERROR)
		{
			danceInterp::OutputMessage("Could not set gaze controller gazecontroller_%s to target point %f %f %f", character.c_str(), loc[0], loc[1], loc[2]);
			return;
		}

		strstr.str("");
		strstr << "dance.generic(\"" << getName() << "\", \"cmd\", \"char " << character << " ctrl gazecontroller_" << character << " begin\")";
		ret = danceInterp::ExecuteCommand(strstr.str().c_str());
		if (ret == DANCE_ERROR)
		{
			danceInterp::OutputMessage("Could not begin gaze controller gazecontroller_%s", character.c_str(), loc[0], loc[1], loc[2]);
			return;
		}
	}
	else if (connection->getType() == "locomotiontarget")
	{
		// make sure that one of the characters has been selected
		std::string character = m_trackCharacter->getValue();
		if (character == "")
			return;

		// make sure that we are looking at a geometry object
		DGeometry* geometry = dynamic_cast<DGeometry*>(connection->getTo());
		if (!geometry)
			return;

		// listen to the geometry's transformation channels
		DAttribute* attr = geometry->getAttribute("transmatrix");
		attr->registerObserver(this);

		double xTarget = 0;
		double zTarget = 0;
		if (attr)
		{
			MatrixAttribute* matrixAttr = dynamic_cast<MatrixAttribute*>(attr);
			if (matrixAttr)
			{
				ArbMatrix& matrix = matrixAttr->getValue();
				if (matrix.getRow() < 4 || matrix.getCol() < 4)
					return;
				xTarget = matrix.elem(3, 0);
				zTarget = matrix.elem(3, 2);
			}
		}
		
		std::stringstream strstr;
		strstr << "dance.generic(\"" << getName() << "\", \"cmd\", \"test loco char " << character << " tx " << xTarget << " tz " << zTarget << "\")";
		int ret = danceInterp::ExecuteCommand(strstr.str().c_str());
		if (ret == DANCE_ERROR)
		{
			danceInterp::OutputMessage("Could not set locomotion controller for character %s to location %f %f", character.c_str(), xTarget, zTarget);
			return;
		}
	}
}

void SmartBodyObject::connectTrackCamera(TrackView* view, SkJoint* joint)
{
	// take the relative positioning between the desired joint and the camera position
	joint->update_gmat_up();
	SrMat gmat = joint->gmat();
	VectorObj jointLoc(*gmat.pt(12), *gmat.pt(13), *gmat.pt(14)); 

	DoubleAttribute* cameraAttr[3];
	cameraAttr[0] = dynamic_cast<DoubleAttribute*>(view->getAttribute("posx"));
	cameraAttr[1] = dynamic_cast<DoubleAttribute*>(view->getAttribute("posy"));
	cameraAttr[2] = dynamic_cast<DoubleAttribute*>(view->getAttribute("posz"));	
	VectorObj camLoc(cameraAttr[0]->getValue(), cameraAttr[1]->getValue(), cameraAttr[2]->getValue());
	m_trackVector = camLoc - jointLoc; 
}

void SmartBodyObject::onDisconnect(DConnection* connection)
{
	if (connection->getType() == "track")
	{

	}
	else if (connection->getType() == "gazetarget")
	{
		// disconnect the geometry's transformation channels
		DGeometry* geometry = dynamic_cast<DGeometry*>(connection->getTo());
		if (!geometry)
			return;

		// listen to the geometry's transformation channels
		DAttribute* matrixAttr = geometry->getAttribute("transmatrix");
		matrixAttr->unregisterObserver(this);
	}
	else if (connection->getType() == "locomotiontarget")
	{
		// disconnect the geometry's transformation channels
		DGeometry* geometry = dynamic_cast<DGeometry*>(connection->getTo());
		if (!geometry)
			return;

		// listen to the geometry's transformation channels
		DAttribute* matrixAttr = geometry->getAttribute("transmatrix");
		matrixAttr->unregisterObserver(this);
	}
}

void SmartBodyObject::getControllerInfo(bool showHierarchy, bool populateControllers, bool populateJointList, 
										bool populateJointsInUse, bool populateMotions, bool showMap)
{
	if (!m_run->getValue())
		return;
	m_inControllerTraverse = true;
	mcuCBHandle& mcu = mcuCBHandle::singleton();
	srHashMap<SbmCharacter>& character_map = mcu.character_map;

	character_map.reset(); 

	std::vector<std::string>& validCharacters = m_trackCharacter->getValidValues();
	validCharacters.clear();
	SbmCharacter* character = character_map.next();

	if (populateControllers)
	{
		m_controller->setValidValues(std::vector<std::string>());
	}

	while (character)
	{
		std::cout << "Character name: " << character->name  << std::endl;
		// set the physical properties
		setPhysicalProperties(character);

		validCharacters.push_back(character->name);
		MeControllerTreeRoot* controllerTree = character->ct_tree_p;
		int numControllers = controllerTree->count_controllers();
	
		for (int c = 0; c < numControllers; c++)
		{
			recurseControllerInfo(character, controllerTree->controller(c), 1, showHierarchy, populateControllers, populateJointList, populateJointsInUse, showMap);
		}

		if (populateJointList && m_trackCharacter->getValue() == character->name)
		{
			const SrArray<SkJoint*>& joints = character->skeleton_p->joints();
			m_trackJoint->getValidValues().clear();
			for (int j = 0; j < joints.size(); j++)
			{
				SkJoint* curJoint = joints.get(j);
				m_trackJoint->getValidValues().push_back(curJoint->name().get_string());
			}
			m_trackJoint->notifyObservers();
		}

		character = character_map.next();
	}
	if (populateControllers)
	{
		if (m_trackCharacter->getValue() == "")
			m_controller->setValue("");
		else
			m_controller->notifyObservers();
	}

	m_trackCharacter->notifyObservers();

	if (populateMotions)
	{
		// populate the motions list with all the available motions
		std::vector<std::string>& validMotions = m_motions->getValidValues();
		validMotions.clear();
		std::vector<std::string>& validPoses = m_poses->getValidValues();
		validPoses.clear();

		for(std::map<std::string, SkMotion*>::iterator it = mcu.motion_map.begin(); it != mcu.motion_map.end(); it++)
		{
			validMotions.push_back((*it).first);
		}

		for(std::map<std::string, SkPosture*>::iterator it =  mcu.pose_map.begin(); it != mcu.pose_map.end(); it++)
		{
			validPoses.push_back((*it).first);
		}
	}

	m_inControllerTraverse = false;

	if (populateMotions)
	{
		m_motions->notifyObservers();
		m_poses->notifyObservers();
	}


}

void SmartBodyObject::recurseControllerInfo(SbmCharacter* character, MeController* controller, int level,  
											bool showHierarchy, bool populateControllers, bool populateJointList, bool populateJointsInUse, bool showMap)
{
	if (showHierarchy)
	{
		for (int t = 0; t < level; t++)
			std::cout << "  ";
		std::cout << "Controller name: " << controller->name() << std::endl;
	}
	if (populateControllers && m_trackCharacter->getValue() == character->name)
	{
		if (strcmp(controller->name(), "") != 0) // need to handle controllers without names
		{
			m_controller->getValidValues().push_back(controller->name());
		}
	}

	if (populateJointsInUse && m_controller->getValue() != "" && m_controller->getValue() == controller->name())
	{
		SkChannelArray& channelsUsed = controller->controller_channels();
		m_jointsInUse.clear();
		for (int c = 0; c < channelsUsed.size(); c++)
		{
			SkJointName& jointName = channelsUsed.name(c);
			m_jointsInUse.insert(std::string(jointName.get_string()));
		}
	}

	if (showHierarchy && m_showControllerInfo->getValue())
	{
		for (int t = 0; t < level + 1; t++)
				std::cout << "\t";
		std::cout << controller->controller_type() << std::endl;
	}
	
	if (showMap)
		controller->dumpChannelMap();

	//controller->print_state(level);
	// traverse the children controllers
	int numControllers = controller->count_children();
	for (int c = 0; c < numControllers; c++)
	{
		recurseControllerInfo(character, controller->child(c), level + 1, showHierarchy, populateControllers, populateJointList, populateJointsInUse, showMap);
	}
}


void SmartBodyObject::drawPyramid(VectorObj from, VectorObj to)
{
	VectorObj diff = to - from;

	glPushMatrix();

	// determine the orientation to the joint
	VectorObj up(0, 1, 0);
	VectorObj jointDir(diff[0], diff[1], diff[2]);
	jointDir.normalize();
	VectorObj axis;
	if (fabs((up - jointDir).length()) < .00001)
		axis.assign(0, 1, 0);
	else
		axis = up.cross(jointDir).normalize();

	double angle = -acos(up.dot(jointDir));
	
	Quaternion q(axis.data(), angle);
	Matrix3x3 rotMat;
	q.toMatrix(rotMat);
	double rotMatrix[4][4];
	setIdentMat(&rotMatrix[0][0], 4);
	for (int r = 0; r < 3; r++)
		for (int c = 0; c < 3; c++)
			rotMatrix[r][c] = rotMat[r][c];
	glMultMatrixd(&rotMatrix[0][0]);
	
	double length = diff.length();
	double m[4][4];
	setIdentMat(&m[0][0], 4);
	m[0][0] = 1.0;
	m[1][1] = length;
	m[2][2] = 1.0;
	glMultMatrixd(&m[0][0]);
	
	double boneScale = m_characterBoneSize->getValue();
	double halfBoneScale = boneScale / 2.0;

	glBegin(GL_LINE_LOOP);
	glVertex3d(-halfBoneScale, 0.0, -halfBoneScale);
	glVertex3d(-halfBoneScale, 0.0, halfBoneScale);
	glVertex3d(halfBoneScale, 0.0, halfBoneScale);
	glVertex3d(halfBoneScale, 0.0, -halfBoneScale);
	glEnd();
	glBegin(GL_LINES);
	glVertex3d(-halfBoneScale, 0.0, -halfBoneScale);
	glVertex3d(0, 1.0, 0);
	glEnd();

	glBegin(GL_LINES);
	glVertex3d(-halfBoneScale, 0.0, halfBoneScale);
	glVertex3d(0, 1.0, 0);
	glEnd();

	glBegin(GL_LINES);
	glVertex3d(halfBoneScale, 0.0, halfBoneScale);
	glVertex3d(0, 1.0, 0);
	glEnd();

	glBegin(GL_LINES);
	glVertex3d(halfBoneScale, 0.0, -halfBoneScale);
	glVertex3d(0, 1.0, 0);
	glEnd();
	
	glPopMatrix();
}

