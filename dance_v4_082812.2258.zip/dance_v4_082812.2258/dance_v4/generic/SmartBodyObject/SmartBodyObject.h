/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef _MYPLUGIN_H
#define _MYPLUGIN_H

#define SBM_REPORT_MEMORY_LEAKS  0
#define SBM_EMAIL_CRASH_REPORTS  1

#include "PlugIn.h"
#include <fltk/Widget.h>
#include "Character.h"
#include "TrackView.h"
#include <sk/sk_joint.h>
#include <sr/sr_sa_gl_render.h>
#include <me/me_controller.h>
#include <sbm/sbm_character.hpp>
#include <sbm/bml.hpp>
#include <bonebus.h> // SmartBody bonebus interface

class SmartBodyObjectWindow;
class srCmdLine;

class SmartBodyObject : public PlugIn
{
	public:
		PlugIn* create(int argc, char **argv);

		SmartBodyObject();
		~SmartBodyObject();

		int interact(Event* event);
		void output(int mode);
		int commandPlugIn(int argc, char **argv);
		void render(int argc, char ** argv, std::ofstream & file);

		void save(int mode, std::ofstream& file);

		void notify(DSubject* subject);

		virtual BoundingBox *calcBoundingBox(BoundingBox *box);
		
		fltk::Widget* getInterface();

		BoneBusServer* getBoneBusServer();

		static void OnClientConnect( std::string clientName, void * userData );
		static void OnClientDisonnect( );
		static void OnCreateCharacter( const int characterID, const std::string characterType, const std::string characterName, const int skeletonType, void * userData );
		static void OnDeleteCharacter( const int characterID, void * userData );
		static void OnSetCharacterPosition( const int characterID, const float x, const float y, const float z, void * userData );
		static void OnSetCharacterRotation( const int characterID, const float w, const float x, const float y, const float z, void * userData );
		static void OnBoneRotations( const BulkBoneRotations * bulkBoneRotations, void * userData );
		static void OnBonePositions( const BulkBonePositions * bulkBonePositions, void * userData );
		static void OnSetCharacterVisemeFunc( const int characterID, const int visemeId, const float weight, const float blendTime, void * userData );
		static void OnPlaySoundFunc( const std::string & soundFile, const std::string & characterName, void * userData );
		static void OnStopSoundFunc(  const std::string & soundFile, void * userData );
		static void OnExecScriptFunc(  const char * command, void * userData );
		static void OnSetCharacterShaderParamFunc(const char * name,const int name_id, void * userData);
		static void OnGeneralParamFunc(const BulkGeneralParams * bulkGeneralParams, void * userData);

		static void checkForUpdates(void* data);
		static void checkForCommands(void* data);

		void initSkeletonMapping();
		CharJoint*  getJointIndexFromBoneId(Character* character, int id);
		std::map<int, Character*>& getCharacters();
		std::map<int, Character*>& getRecordCharacters();

		#ifdef WIN32
		DWORD getUpdateTime();
		void setUpdateTime(DWORD time);
		DWORD getStartTime();
		void setStartTime(DWORD time);
		#else
		timeval getUpdateTime();
		void setUpdateTime(timeval time);
		timeval getStartTime();
		void setStartTime(timeval time);
		#endif

		static SmartBodyObject* smartInstance;

		void startSmartBody();
		void endSmartBody();
		void mcu_register_callbacks( void );

		srCmdLine* getCmdLine();

		double getSmartBodyStartTime();
		void setSmartBodyStartTime(double time);
		double getSmartBodyCurrentTime();
		void setSmartBodyCurrentTime(double time);

		void drawJoint(SbmCharacter* characer, SkJoint* joint, VectorObj* parentPos);

		void onConnect(DConnection* connection);
		void onDisconnect(DConnection* connection);

	private:
		void drawPyramid(VectorObj from, VectorObj to);
		std::vector< std::pair<std::string, std::string> > getArguments(std::string);
		void connectTrackCamera(TrackView* baseView, SkJoint* joint);
		void setPhysicalProperties(SbmCharacter* character);
		void getControllerInfo(bool showHierarchy, bool populateControllers,  bool populateJointList, bool populateJointsInUse, bool populateMotions, bool showMap);
		void recurseControllerInfo(SbmCharacter* character, MeController* controller, int level, bool showHierarchy, bool populateControllers, bool populateJointList, bool populateJointsInUse, bool showMap);
		SkSkeleton* setUpControllerVisualization(std::string characterName, std::string controllerName, bool value);
		MeController* getController(std::string characterName, std::string controllerName);
		MeController* getControllerRecurse(SbmCharacter* c, MeController* controller, std::string name);

		void cleanUpMultipleControllerVisualizations();
		void setUpMultipleControllerVisualizations(std::string whichCharacter, std::string controllerToWatch, double time);
		void setUpMultipleControllerVisualizationsRecurse(MeController* controller, std::string characterName, std::map<std::string, std::pair<SkSkeleton*, Character*> >& allSkeletons, bool addNewControllers, double time);
		Character* createCharacterFromSkeleton(SkSkeleton* skeleton, std::string name);

		bool m_inControllerTraverse;

		SmartBodyObjectWindow* gui;
		BoneBusServer* m_bonebus;

		// bone bus attributes
		StringAttribute* m_skeletonFile;
		BoolAttribute* m_connect;
		BoolAttribute* m_connected;
		BoolAttribute* m_clientConnected;
		BoolAttribute* m_update;
		DoubleAttribute* m_frequency;
		BoolAttribute* m_showJoints;
		BoolAttribute* m_showBones;
		BoolAttribute* m_recordMotion;

		// SmartBody attributes
		StringAttribute* m_smartBodyRoot;
		StringAttribute* m_smartBodyPaths;
		StringAttribute* m_arguments;
		StringAttribute* m_defaultSequence;
		DoubleAttribute* m_targetFps;
		BoolAttribute* m_run;
		BoolAttribute* m_showSkelLocal;
		BoolAttribute* m_showSkel;
		BoolAttribute* m_showGeom;
		BoolAttribute* m_showColGeom;
		BoolAttribute* m_showAxis;
		BoolAttribute* m_showCOM;
		BoolAttribute* m_showEyeBeams;
		BoolAttribute* m_showSupportPolygon;
		BoolAttribute* m_useFaceBones;
		BoolAttribute* m_showControllerInfo;
		BoolAttribute* m_showControllerMap;
		BoolAttribute* m_isolateController;
		BoolAttribute* m_disableControllers;
		BoolAttribute* m_isolateAllControllers;
		DoubleAttribute* m_isolateAllControllersMaxTime;
		DoubleAttribute* m_characterBoneSize;
		StringAttribute* m_trackCharacter;
		StringAttribute* m_trackJoint;
		VectorObj m_trackVector;
		SkJoint* m_lookAtJoint;
		StringAttribute* m_motions;
		StringAttribute* m_poses;

		StringAttribute* m_controller;
		std::set<std::string> m_jointsInUse;

		// visemes
		std::vector<DoubleAttribute*> m_visemes;

		//SrBuffer<float>* m_controllerBuffer;
		std::vector<float>* m_controllerBuffer;
		SkSkeleton* m_controllerVizSkeleton;

		std::map<std::string, std::pair<SkSkeleton*, Character*> > m_allControllerVizSkeletons;

		srCmdLine* m_cmdLine;
		double m_smartBodyStartTime;
		double m_smartBodyCurrentTime;

		BoundingBox m_box;

		// SmartBody scene graph renderere
		SrSaGlRender m_renderAction;

		#ifdef WIN32
		DWORD m_updateTime;
		#else
		timeval m_sysStartTime;
		#endif
		
		std::map<int, Character*> m_characters;
		std::map<int, Character*> m_recordedCharacters;
		std::map<int, std::string> m_skeleton;
		std::map<std::string, double> m_skeletonMasses;

#ifdef WIN32
		DWORD m_startTime;
#else
		timeval m_startTime;
#endif

};

#endif

