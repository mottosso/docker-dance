
/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "Sample.h"
#include "dance.h"
#include "danceInterp.h"
#include <fltk/gl.h>
#include "SampleWindow.h"

PlugIn* Proxy()
{
	return new Sample();
}

PlugIn* Sample::create(int argc, char **argv)
{
	Sample* s = new Sample() ;

    return s;	
}

Sample::Sample() : PlugIn()
{
	danceInterp::OutputMessage("Sample has been created!");
	setColor(1.0, 0.0, 0.0); // set the initial color to red
	gui =  NULL;

	dance::AllSimulators->addSimStepCB(this, 100, simstep);
}

Sample::~Sample()
{
	if (gui != NULL)
		delete gui;
}

void Sample::setColor(float r, float g, float b)
{
	color[0] = r;
	color[1] = g;
	color[2] = b;
}

float* Sample::getColor()
{
	return &color[0];
}


void Sample::output(int mode)
{


	glPushAttrib(GL_ENABLE_BIT);


	glDisable(GL_LIGHTING);	
	glColor3f(color[0], color[1], color[2]);
	glBegin(GL_POLYGON);
	glVertex3f(0.0, 0.0, 0.0);
	glVertex3f(0.0, 1.0, 0.0);
	glVertex3f(1.0, 1.0, 0.0);
	glVertex3f(1.0, 0.0, 0.0);
	glEnd();

	glPopAttrib();
}

int Sample::commandPlugIn(int argc, char **argv)
{
	// let the parent class (PlugIn) handle the commands first
	int ret = PlugIn::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;


	if (strcmp(argv[0], "color") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("%s 'color' parameter requires 3 parameters.", this->getName());
			return DANCE_ERROR;
		}
		else
		{
			setColor(atof(argv[1]), atof(argv[2]), atof(argv[3]));
			danceInterp::OutputMessage("%s 'color' has been set to %4.2f, %4.2f, %4.2f.", this->getName(), color[0], color[1], color[2]);
			dance::Refresh();
			return DANCE_OK;
		}
	}

	return DANCE_CONTINUE; // command was not found
}

void Sample::render(int argc, char** argv, std::ofstream& file)
{
	file << "polygon {\n";
	file << "	4\n";
	file << "	<0.0, 0.0, 0.0>\n";
	file << "	<0.0, 1.0, 0.0>\n";
	file << "	<1.0, 1.0, 0.0>\n";
	file << "	<1.0, 0.0, 0.0>\n";
	file << "	pigment { color rgb <" << color[0] << " " << color[1] << " " << color[2] << ">}\n";
	file << "}\n";
}

void Sample::save(int mode, std::ofstream& file)
{
	char buff[512];

	if (mode == 0)
	{
		file << "dance.instance(\"Sample\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
		PlugIn::save(mode, file); // let the parent class handle saving in this mode
		// set the color
		sprintf(buff, "\"color\", %4.2f, %4.2f, %4.3f", color[0], color[1], color[2]);
		pythonSave(file, buff);
	}
	else if (mode == 2)
	{
		// add any commands that rely upon other plugins
		PlugIn::save(mode, file); // let the parent class handle saving in this mode
	}
}

fltk::Widget* Sample::getInterface()
{
	if (gui == NULL) 
	{
		gui = new SampleWindow(this, 0, 0, 300, 400, this->getName());
	}

	return gui;
}

int Sample::interact(Event* event)
{
	double x, y;
	int button;

	switch (event->getEventType())
	{
		case fltk::KEY:
				switch (fltk::event_key())
				{
				case 'r':
					this->setColor(1.0, 0.0, 0.0);
					danceInterp::OutputMessage("Color set to red.");
					dance::Refresh();
					if (this->gui != NULL)
						this->gui->updateGUI();
					break;
				case 'g':
					this->setColor(0.0, 1.0, 0.0);
					danceInterp::OutputMessage("Color set to green.");
					dance::Refresh();
					if (this->gui != NULL)
						this->gui->updateGUI();
					break;
				case 'b':
					this->setColor(0.0, 0.0, 1.0);
					danceInterp::OutputMessage("Color set to blue.");
					dance::Refresh();
					if (this->gui != NULL)
						this->gui->updateGUI();
					break;
				default:
					danceInterp::OutputMessage("Keyboard button %c was pushed.", fltk::event_key());
					break;
				}
				return -1;
			break;
		case fltk::PUSH:
			button = fltk::event_button();
			x = (float) fltk::event_x();
			y = (float) fltk::event_x();
			danceInterp::OutputMessage("Mouse button %d was pushed at (%f, %f)", button, x, y);
			return -1;

			break;
		case fltk::RELEASE:
			danceInterp::OutputMessage("Mouse button was released...");
			return -1;
			break;
		case fltk::DRAG:
			danceInterp::OutputMessage("Mouse was dragged...");
			return -1;
			break;
		default:
			break;
	}

	return 0;
}


void Sample::step(double time)
{
	color[0] = sin(time);
	color[1] = cos(time);
}

void Sample::simstep(DObject* obj, double time)
{
	Sample* sample = (Sample*) obj;
	sample->step(time);
}


