/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef _SensorSkel18_H_
#define _SensorSkel18_H_

#include "PlugIn.h"
#include "SensorSkel18Window.h"
#include "DSystem.h"
#include "Sensor.h"
#include "ArticulatedObject.h"
#include "SupportPolygon.h"

enum LinkAndJoint_indx { Hip, Trunk, Neck, Head, Left_Shoulder,
		  Left_Forearm, Left_Hand, Right_Shoulder,
		  Right_Forearm, Right_Hand,
		  Left_Thigh, Left_Shin, Left_Foot,
		  Right_Thigh, Right_Shin, Right_Foot } ;

// Joint axis indices
enum { Hip_x, Hip_z, Hip_y } ;
enum { Trunk_x, Trunk_z, Trunk_y } ;
enum { Neck_x, Neck_z, Neck_y } ;
enum { Head_x } ;
enum { Left_Shoulder_z, Left_Shoulder_y } ;
enum { Left_FA_y, Left_FA_x } ;
enum { Left_Hand_z, Left_Hand_y } ;
enum { Right_Shoulder_z, Right_Shoulder_y } ;
enum { Right_FA_y, Right_FA_x } ;
enum { Right_Hand_z, Right_Hand_y } ;
enum { Left_Thigh_x, Left_Thigh_z, Left_Thigh_y} ;
enum { Left_Shin_x } ;
enum { Left_Foot_x, Left_Foot_z } ;
enum { Right_Thigh_x, Right_Thigh_z, Right_Thigh_y} ;
enum { Right_Shin_x } ;
enum { Right_Foot_x, Right_Foot_z } ;

#ifdef WIN32
#ifndef SENSORSKEL18_EXPORTS
#define	DLLSENSORSKEL18 __declspec(dllexport)
#else
#define	DLLSENSORSKEL18 __declspec(dllimport)
#endif
#else
#define DLLSENSORSKEL18 
#endif


class DLLSENSORSKEL18 SensorSkel18 : public Sensor
{
	public:
		PlugIn* create(int argc, char **argv);

		SensorSkel18();	
		~SensorSkel18();

		virtual bool isValidSystem(DSystem* sys);

		void readSensor(double time);

		int commandPlugIn(int argc, char **argv);
		fltk::Widget* getInterface();
		void save(int mode, std::ofstream& file);
		int getNumPluginDependents();
		const char* getPluginDependent(int num);

		virtual double *getUpVectorHip(Vector v);
		virtual double *getFacingHip(Vector v);
		virtual double *getHipCenterMass(Vector v);
		virtual double *getHipCMRelativeDistance(Vector v);
		//virtual double *getCMRelativeDistance(Vector v);
		virtual double *getHipCMVel(Vector v);
		virtual double *getHipAcc(Vector v);
		//virtual double *getCenterMass(Vector v);
		virtual double *getCMvel(Vector v);
		virtual double *getCMacc(Vector v);
		virtual double *getGeomCenterSp(Vector v);
		virtual bool isHandsOnGround() { return m_isHandsOnGround ;} ;
		virtual bool isLeftHandOnGround() { return m_isLeftHandOnGround ;} ;
		virtual bool isRightHandOnGround() { return m_isRightHandOnGround ;} ;
		virtual bool isFeetOnGround() { return m_isFeetOnGround ;} ;
		virtual bool isLeftFootOnGround() { return m_isLeftFootOnGround ;} ;
		virtual bool isRightFootOnGround() { return m_isRightFootOnGround ;} ;
		virtual bool isHipOnGround() { return m_isHipOnGround ;} ;
		virtual bool isHeadOnGround() { return m_isHeadOnGround ;} ;
		virtual bool isRightThighOnGround() { return m_isRightThighOnGround ;} ;
		virtual bool isLeftThighOnGround() { return m_isLeftThighOnGround ;} ;
		virtual bool isThighsOnGround() { return m_isThighsOnGround ;} ;
		virtual void computeSensors();	// to be called at every time step

		virtual void setArtObj(ArticulatedObject *ao) { m_artObj = ao ;};

	protected:
		virtual int initSupportPolygon();

		virtual void computeHipCMVel();
		virtual void computeUpVectorHip();
		virtual bool computeRelativeDistance(Vector point, Vector dist);
		virtual void computeFacingHip();
		virtual void computeHipCenterMass();
		virtual void computeCenterMass();
		virtual void computeFeetOnGround();
		virtual void computeHandsOnGround();
		virtual void computeThighsOnGround();
		virtual void computeHeadOnGround();
		virtual void computeHipOnGround();
		virtual void computeSupportPolygon();
		virtual void computeHipAcc();
		virtual void computeCMAcc();
		virtual void computeCMVel();
//		virtual void ComputeGroundNormal();

	private:
		SensorSkel18Window* sensorSkel18Window;
		ArticulatedObject* m_artObj;

		SupportPolygon m_sp;
		int m_isInitSP;

		bool m_isHeadOnGround;
		bool m_isHipOnGround;
		bool m_isHandsOnGround;
		bool m_isFeetOnGround;
		bool m_isLeftHandOnGround;
		bool m_isRightHandOnGround;
		bool m_isLeftFootOnGround;
		bool m_isRightFootOnGround;
		bool m_isLeftThighOnGround;
		bool m_isRightThighOnGround;
		bool m_isThighsOnGround;

		bool m_isHipOut;
		bool m_isCMOut;
		Vector m_facing;
		Vector m_dHeadCM;
		Vector m_upVectorHip;
		Vector m_hipVel;
		Vector m_hipAcc;
		Vector m_hipCM;
		Vector m_CMacc;
		Vector m_CMvel;
		Vector m_cm;
		Vector m_dcm;
		Vector m_groundNormal;
		Vector m_geomCenterSp;

		double m_height;
		double m_footLength;

		bool m_colliding;
		std::vector<bool> m_dirty;

		enum SensorTypes {
			FLAG_computeHipCMVel,
			FLAG_computeUpVectorHip,
			FLAG_computeRelativeDistance,
			FLAG_computeFacingHip,
			FLAG_computeHipCenterMass,
			FLAG_computeCenterMass,
			FLAG_computeFeetOnGround,
			FLAG_computeHandsOnGround,
			FLAG_computeThighsOnGround,
			FLAG_computeHeadOnGround,
			FLAG_computeHipOnGround,
			FLAG_computeSupportPolygon,
			FLAG_computeHipAcc,
			FLAG_computeCMAcc,
			FLAG_computeCMVel,
			FLAG_END
		};

		void resetFlags();
};

#endif
