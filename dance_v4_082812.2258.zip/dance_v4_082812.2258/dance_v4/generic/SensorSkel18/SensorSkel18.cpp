/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "SensorSkel18.h"
#include "dance.h"
#include "DSimulatorManager.h"
#include "Link.h"
#include "DCollision.h"

PlugIn* Proxy()
{
	return new SensorSkel18();
}

PlugIn* SensorSkel18::create(int argc, char **argv)
{
	SensorSkel18* t = new SensorSkel18();

	return t;
}

SensorSkel18::SensorSkel18() : Sensor()
{
	sensorSkel18Window = NULL;
	m_artObj = NULL;

    m_isInitSP = false;
    m_isHandsOnGround = false;
    m_isFeetOnGround = false;
    m_isHeadOnGround = false;
    m_isHipOnGround = false;
    m_isHipOut = false;
    m_isCMOut = false;
    m_isLeftFootOnGround = false;
    m_isRightFootOnGround = false;
    m_isLeftHandOnGround = false;
    m_isRightHandOnGround = false;
    m_isLeftThighOnGround = false;
    m_isRightThighOnGround = false;
    m_isThighsOnGround = false;

    m_height = 1.8;
    m_footLength = 0.215;

	m_colliding = false;

	for (int i = 0; i < FLAG_END; i++)
	{
		m_dirty.push_back(true);
	}

	resetFlags();
}

SensorSkel18::~SensorSkel18()
{
	if (sensorSkel18Window != NULL)
		delete sensorSkel18Window;
}

int SensorSkel18::commandPlugIn(int argc, char **argv)
{
	int ret = Sensor::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

	return DANCE_CONTINUE;
}

bool SensorSkel18::isValidSystem(DSystem* sys)
{
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(sys);
	if (ao != NULL)
		return true;
	else
		return false;
}

void SensorSkel18::readSensor(double time)
{
	DSystem* sys = this->getSystem();
	if (sys != NULL)
	{
		m_artObj = (ArticulatedObject*) sys;
		this->computeSensors();
	}
	else
	{
		m_artObj = NULL;

	}
}

fltk::Widget* SensorSkel18::getInterface()
{
	if (sensorSkel18Window == NULL)
	{
		sensorSkel18Window = new SensorSkel18Window(this, 10, 10, 300, 400, this->getName());
	}

	return sensorSkel18Window;
}

void SensorSkel18::save(int mode, std::ofstream& file)
{
//	char buff[512];

	if (mode == 0)
	{
		file << "dance.instance(\"SensorSkel18\", \"" << this->getName() << "\")" << std::endl; 
	}
	else
	{
		Sensor::save(mode, file) ;
		PlugIn::save(mode, file);
	}
}

int SensorSkel18::getNumPluginDependents()
{
	return 2;
}

const char* SensorSkel18::getPluginDependent(int num)
{
	if (num == 0)
		return "Sensor";
	else if (num == 1)
		return "ArticulatedObject";
	else
		return NULL;
}

// DOES:    computes and returns the up	vector of the hip
//	    of the associated articulated object.
//	    This direction coincides with the POSITIVE y-direction
//	    of	link 0.
void SensorSkel18::computeUpVectorHip()
{
	if (this->getSystem() == NULL || this->getSystem()->getNumSimulators() == 0)
		return;

    if (m_artObj->getNumLinks()  < 1)
		return ;

	DSimulator *sim = m_artObj->getSimulator(0);
    if (sim == NULL)
		return;

    setVector(m_upVectorHip, 0.0, 1.0, 0.0) ;
    sim->GetOrientation(Hip, m_upVectorHip, WORLDFRAME, m_upVectorHip) ;
}

// computes the relative distance between the support polugon
// boundary and 
bool SensorSkel18::computeRelativeDistance(Vector point, Vector dist)
{
    Vector intersect;
    if (m_sp.intersectLineSeg(m_geomCenterSp, point, intersect) == NULL)
		return false;
    
    VecSubtract(dist, point, intersect);

    return true;
}

// PROC:   computeSupportPolygon
// DOES:   computes the	support	polygon	in wolrd cordinates
//	   after transforming all the possible vertices	in
//	   world coordinates.
void SensorSkel18::computeSupportPolygon()
{
    Link **link	;

    link = m_artObj->getLinks() ;
    if(	link ==	NULL )
    {
		danceInterp::OutputMessage( "computeSupportPolygon: object has no links!\n") ;
		return ;
    }

    if(	m_isInitSP == false )
    {
		if( !initSupportPolygon() )
			return ;
    }


	int i ;
	for( i = 0 ; i <  m_sp.nl ; i++ )
	{
		link[Left_Foot]->getWorldCoord(m_sp.wVertices[i], m_sp.lVertices[i]) ;
	}
	for( i = 0 ; i <  m_sp.nr ; i++ )
	{
		link[Right_Foot]->getWorldCoord(m_sp.wVertices[m_sp.nl+i], m_sp.lVertices[m_sp.nl+i]) ;
	}

	// compute the support polygon
    m_sp.compute() ;
    // compute its geometric center
    m_sp.computeGeometricCenter(m_geomCenterSp) ;
}

// PROC:  InitSupportPolygon
// DOES:  Initializes the support polygon structure.
//	  It fills in the local	coordinates of the
//	  points which can participate in the construction
//	  of the support polygon.
int SensorSkel18::initSupportPolygon()
{

    if(	m_artObj == NULL )
    {
		danceInterp::OutputMessage("SensorSkel18::initSupportPolygon: No object present!\n") ;
		return 0 ;
    }
    // use only	the feet links
    Link **link	= m_artObj->getLinks() ;
    if(	link ==	NULL )
    {
		danceInterp::OutputMessage( "SensorSkel18::initSupportPolygon: Object doesn't have links!\n") ;
		return 0 ;
    }

	if ((m_sp.nl = link[Left_Foot]->getGeometry()->getNumMonitorPoints()) == 0)
    {
		danceInterp::OutputMessage( "SensorSkel18::initSupportPolygon: Left foot doesn't have monitor points!\n") ;
		return 0 ;
    }

    if ((m_sp.nr = link[Right_Foot]->getGeometry()->getNumMonitorPoints()) == 0)
    {
	danceInterp::OutputMessage( "SensorSkel18::initSupportPolygon: "
		      "Right foot doesn't have monitor points!\n") ;
	return 0 ;
    }

    Vector *lmpts ;
    Vector *rmpts ;
    link[Left_Foot]->getMonitorPoints(&lmpts) ;
    link[Right_Foot]->getMonitorPoints(&rmpts) ;

    m_sp.nl = 4 ;
    VecCopy(m_sp.lVertices[0], lmpts[2]) ;
    VecCopy(m_sp.lVertices[1],lmpts[3]) ;
    VecCopy(m_sp.lVertices[2], lmpts[4]) ;
    VecCopy(m_sp.lVertices[3], lmpts[5] ) ;

    m_sp.nr = 4 ;
    VecCopy(m_sp.lVertices[4], rmpts[2]) ;
    VecCopy(m_sp.lVertices[5], rmpts[3]) ;
    VecCopy(m_sp.lVertices[6], rmpts[4]) ;
    VecCopy(m_sp.lVertices[7], rmpts[5]) ;

    m_isInitSP = true ;

    return 1 ;

}

// PROC:    Facing()
// DOES:    computes and returns the direction where the
//	    associated articulated object is facing.
//	    This direction coincides with the z-direction
//	    of link 0.
void SensorSkel18::computeFacingHip()
{
	if (this->getSystem() == NULL || this->getSystem()->getNumSimulators() == 0)
		return;

    setVector(m_facing, 0.0, 0.0, 1.0)	;
	m_artObj->getSimulator(0)->GetOrientation(Hip, m_facing, WORLDFRAME, m_facing);
}

// PROC:   computeHipCenterMass()
// DOES:   computes the	center of mass of the associated ArticulatedObject's
//	   hip	using the sdfast simulator
void SensorSkel18::computeHipCenterMass()
{
  	if (this->getSystem() == NULL || this->getSystem()->getNumSimulators() == 0)
		return;

    int	nlinks =  m_artObj->getNumLinks();

    if(	nlinks == 0 )
    {
		danceInterp::OutputMessage( "SensorSkel18::computeHipCenterMass:"
				"	object has no links!\n") ;
		return ;
    }

    Vector cm0 = { 0.0,	0.0, 0.0} ;
	m_artObj->getSimulator(0)->GetPosition(0, cm0, m_hipCM) ;
    return  ;
}
// PROC:   computeHipCenterMass()
// DOES:   computes the	center of mass of the associated ArticulatedObject
//	   using the sdfast simulator. It also stores in link->cm the cm
//         of each link.
void SensorSkel18::computeCenterMass()
{
    if (this->getSystem() == NULL || this->getSystem()->getNumSimulators() == 0)
	return;

    int	nlinks =  m_artObj->getNumLinks();

    if(	nlinks == 0 )
    {
		danceInterp::OutputMessage( "SensorSkel18::computeCenterMass: object has no links!\n") ;
		return ;
    }

    Link **link = m_artObj->getLinks() ;
    setVector(m_cm, 0.0, 0.0, 0.0) ;
	double totalMass = 0.0 ;
    for( int i = 0 ; i < nlinks ; i++ )
    {
		Vector cm0 = { 0.0, 0.0, 0.0}, cm ;
		m_artObj->getSimulator(0)->GetPosition(i, cm0, cm) ;
		link[i]->setCenterMass(cm) ;
		double m = link[i]->getMass() ;
		VecNumMul(cm,cm,m) ;
		totalMass += m ;
		VecAdd(m_cm, m_cm, cm) ;
    }
    VecScale(m_cm, 1.0 / totalMass) ;
    return  ;
}

void SensorSkel18::computeCMVel()
{
   	if (this->getSystem() == NULL || this->getSystem()->getNumSimulators() == 0)
		return;

    int	nlinks =  m_artObj->getNumLinks()	;

    if(	nlinks == 0 )
    {
		danceInterp::OutputMessage( "SensorSkel18::computeCenterMass: object has no links!\n") ;
		return ;
    }

    setVector(m_CMvel, 0.0, 0.0, 0.0) ;
    for( int i = 0 ; i < nlinks ; i++ )
    {
		Vector vcm0 = { 0.0, 0.0, 0.0}, vcm ;
		m_artObj->getSimulator(0)->GetVel(i, vcm0, vcm) ;
		VecAdd(m_CMvel, m_CMvel, vcm) ;
    }
    VecScale(m_CMvel, 1.0 / nlinks) ;
    return  ;
}

void SensorSkel18::computeCMAcc()
{
    if (this->getSystem() == NULL || this->getSystem()->getNumSimulators() == 0)
	return;

    int	nlinks =  m_artObj->getNumLinks()	;

    if(	nlinks == 0 )
    {
		danceInterp::OutputMessage( "SensorSkel18::computeCenterMass: object has no links!\n") ;
		return ;
    }

    //Link **link = m_artObj->getLinks() ;
    setVector(m_CMacc, 0.0, 0.0, 0.0) ;
    for( int i = 0 ; i < nlinks ; i++ )
    {
		Vector acm0 = { 0.0, 0.0, 0.0}, acm ;
		m_artObj->getSimulator(0)->GetAcc(i, acm0, acm) ;
		VecAdd(m_CMacc, m_CMacc, acm) ;
//		link[i]->setCenterMass(acm) ;
    }
    VecScale(m_CMacc, 1.0 / nlinks) ;
    return  ;
}

// PROC:  computeSensors()
// DOES: computes all the sensor info that can then be accessed with the access functions
//       It is supposed to be called in the beginning of every time step so that
//       sensors are calculated only once every time step.
void SensorSkel18::computeSensors()
{
	if (1) // using dirty flags for efficiency instead
		return;

    if (m_artObj == NULL)
    {
		danceInterp::OutputMessage("WARNING: SensorSkel18::computeSensors: no articulated object present!\n") ;
		return ;
    }
    if( m_artObj->getNumLinks()  < 1 )
    {
		danceInterp::OutputMessage("WARNING: SensorSkel18::computeSensors: articulated object has no links!\n") ;
		return ;
    }

//	static Vector max_vel = {0.0, 0.0, 0.0} ;

    computeCenterMass() ;
    computeHipCenterMass() ; 
    computeSupportPolygon() ;
    computeUpVectorHip() ;
    computeFacingHip() ;
    m_isHipOut = computeRelativeDistance(m_hipCM, m_dHeadCM) ; // needs HipCenterMass abd SupportPolygon
    m_isCMOut = computeRelativeDistance(m_cm, m_dcm) ; // needs m_cm and SupportPolygon
    computeHandsOnGround() ;
    computeFeetOnGround() ;
    computeHipOnGround() ;
    computeHeadOnGround() ;
    computeThighsOnGround() ;
    computeCMVel() ;
    computeCMAcc() ;
    computeHipCMVel() ;
//    computeGroundNormal() ;	// has to be after the computation of the Hip CM

//	if( VecLength( max_vel) < VecLength(m_CMvel) )
//		VecCopy(max_vel, m_CMvel) ;
}

double *SensorSkel18::getGeomCenterSp(Vector v)
{
	if (m_dirty[FLAG_computeSupportPolygon])
		computeSupportPolygon();

    VecCopy(v, m_geomCenterSp) ;
    return &v[0] ;
}

double *SensorSkel18::getHipAcc(Vector v)
{
	if (m_dirty[FLAG_computeHipAcc])
		computeHipAcc();

    VecCopy(v, m_hipAcc) ;
    return &v[0] ;
}

double *SensorSkel18::getHipCenterMass(Vector v)
{
	if (m_dirty[FLAG_computeHipCenterMass])
		computeHipCenterMass();

    VecCopy(v, m_hipCM) ;
    return &v[0] ;
}

/*
double *SensorSkel18::getCenterMass(Vector v)
{
    VecCopy(v, m_cm) ;
    return &v[0] ;
}
*/

double *SensorSkel18::getHipCMVel(Vector v)
{
	if (m_dirty[FLAG_computeHipCMVel])
		computeHipCMVel();

    VecCopy(v, m_hipVel) ;
    return &v[0] ;
}

double *SensorSkel18::getUpVectorHip(Vector v)
{
	if (m_dirty[FLAG_computeUpVectorHip])
		computeUpVectorHip();

    VecCopy(v, m_upVectorHip) ;
    return &v[0] ;
}

double *SensorSkel18::getHipCMRelativeDistance(Vector v)
{
	if (m_dirty[FLAG_computeHipCenterMass])
	    computeHipCenterMass() ; 

	if (m_dirty[FLAG_computeSupportPolygon])
	    computeSupportPolygon() ;

	m_isHipOut = computeRelativeDistance(m_hipCM, m_dHeadCM);

    if( m_isHipOut == false ) return NULL ;
    VecCopy(v, m_dHeadCM) ;
    return &v[0] ;
}

/*
double *SensorSkel18::getCMRelativeDistance(Vector v)
{
    if( m_isCMOut == false ) return NULL ;
    VecCopy(v, m_dcm) ;
    return &v[0] ;
}
*/

double *SensorSkel18::getFacingHip(Vector v)
{
	if (m_dirty[FLAG_computeFacingHip])
		computeFacingHip();

	VecCopy(v, m_facing) ;
    return &v[0] ;
}
    
// PROC:  computeHandsOnGround
// DOES:  checks the monitorPoints to see if any of them are labelled
//        as undergound. 
void SensorSkel18::computeHandsOnGround()
{
    m_isLeftHandOnGround = false ;
    m_isRightHandOnGround = false ;
    m_isHandsOnGround = false ;

	DCollision** col = m_artObj->getPointCollisionData();
	
	int ptsRight = col[Right_Hand]->getNumPoints();
	int ptsLeft = col[Left_Hand]->getNumPoints();

    if (ptsRight > 0)
    {
		for (int i = 0; i < ptsRight; i++)
		{
			if (col[Right_Hand]->isPointInCollision(i))
			{
				m_isHandsOnGround = true ;
				m_isRightHandOnGround = true ;
				break ;
			}
		}
    }
	
	if (ptsLeft > 0)
    {
		for (int i = 0; i < ptsRight; i++)
		{
			if (col[Left_Hand]->isPointInCollision(i))
			{
				m_isHandsOnGround = true ;
				m_isRightHandOnGround = true ;
				break ;
			}
		}
    }
}  

void SensorSkel18::computeThighsOnGround()
{
    m_isLeftThighOnGround = false ;
    m_isRightThighOnGround = false ;
    m_isThighsOnGround = false ;
 
	DCollision** col = m_artObj->getPointCollisionData();
	
	int ptsRight = col[Right_Thigh]->getNumPoints();
	int ptsLeft = col[Left_Thigh]->getNumPoints();

    if (ptsRight > 0)
    {
		for (int i = 0; i < ptsRight; i++)
		{
			if (col[Right_Thigh]->isPointInCollision(i))
			{
				m_isThighsOnGround = true ;
				m_isRightThighOnGround = true ;
				break ;
			}
		}
    }
	
	if (ptsLeft > 0)
    {
		for (int i = 0; i < ptsRight; i++)
		{
			if (col[Left_Thigh]->isPointInCollision(i))
			{
				m_isHandsOnGround = true ;
				m_isRightHandOnGround = true ;
				break ;
			}
		}
    }
}

// PROC:  computeFeetOnGround
// DOES:  checks the monitorPoints to see if any of them are labelled
//        as undergound. 
void SensorSkel18::computeFeetOnGround()
{
    m_isLeftFootOnGround = false ;
    m_isRightFootOnGround = false ;
    m_isFeetOnGround = false ;

	DCollision** col = m_artObj->getPointCollisionData();
	
	int ptsRight = col[Right_Foot]->getNumPoints();
	int ptsLeft = col[Left_Foot]->getNumPoints();

    if (ptsRight > 0)
    {
		for (int i = 0; i < ptsRight; i++)
		{
			if (col[Right_Foot]->isPointInCollision(i))
			{
				m_isFeetOnGround = true ;
				m_isRightThighOnGround = true ;
				break ;
			}
		}
    }
	
	if (ptsLeft > 0)
    {
		for (int i = 0; i < ptsRight; i++)
		{
			if (col[Left_Foot]->isPointInCollision(i))
			{
				m_isFeetOnGround = true ;
				m_isLeftFootOnGround = true ;
				break ;
			}
		}
    }
}  

void SensorSkel18::computeHeadOnGround()
{
	m_isHeadOnGround = false ;
	
	DCollision** col = m_artObj->getPointCollisionData();
	
	int pts = col[Head]->getNumPoints();

    if (pts > 0)
    {
		for (int i = 0; i < pts; i++)
		{
			if (col[Head]->isPointInCollision(i))
			{
				m_isHeadOnGround = true ;
				break ;
			}
		}
    }    
}   

void SensorSkel18::computeHipOnGround()
{
	m_isHipOnGround = false ;
	
	DCollision** col = m_artObj->getPointCollisionData();
	
	int pts = col[Hip]->getNumPoints();

    if (pts > 0)
    {
		for (int i = 0; i < pts; i++)
		{
			if (col[Hip]->isPointInCollision(i))
			{
				m_isHipOnGround = true ;
				break ;
			}
		}
    }
}   

void SensorSkel18::computeHipCMVel()
{
	if (this->getSystem() == NULL || this->getSystem()->getNumSimulators() == 0)
	return;

	Vector orig = {0.0,0.0,0.0} ;
	m_artObj->getSimulator(0)->GetVel(0, orig, m_hipVel) ;
}

void SensorSkel18::computeHipAcc()
{
	if (this->getSystem() == NULL || this->getSystem()->getNumSimulators() == 0)
		return;

    Vector orig = {0.0,0.0,0.0} ;
    m_artObj->getSimulator(0)->GetAcc(0, orig, m_hipAcc) ;
}

double *SensorSkel18::getCMvel(Vector v)
{
	if (m_dirty[FLAG_computeCMVel])
		computeCMVel();

	VecCopy(v, m_CMvel) ;
    return &v[0] ;
}

double *SensorSkel18::getCMacc(Vector v)
{
	if (m_dirty[FLAG_computeCMAcc])
		computeCMAcc();
	
	VecCopy(v, m_CMacc) ;
    return &v[0] ;
}

void SensorSkel18::resetFlags()
{
	for (int i = 0; i < FLAG_END; i++)
	{
		m_dirty[i] = true;
	}
}





