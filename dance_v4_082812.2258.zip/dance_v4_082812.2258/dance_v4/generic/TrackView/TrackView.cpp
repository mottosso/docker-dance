
/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#include "TrackView.h"
#include "dance.h"
#include "danceInterp.h"
#include <fltk/gl.h>
#include <fltk/glut.h>

#include "TrackViewWindow.h"

PlugIn* Proxy()
{
	return new TrackView();
}

PlugIn* TrackView::create(int argc, char **argv)
{
	TrackView* s = new TrackView() ;

    return s;	
}


TrackView::TrackView() : DView()
{
	gui = NULL;
	danceInterp::OutputMessage("TrackView has been created!");

	std::string positionNames[3] = {"posx", "posy", "posz"};
	for (int x = 0; x < 3; x++)
		m_position[x] = this->createDoubleAttribute(positionNames[x], 0, true, "Camera", 10 + x);
	std::string targetNames[3] = {"targetx", "targety", "targetz"};
	for (int x = 0; x < 3; x++)
		m_target[x] = this->createDoubleAttribute(targetNames[x], 0, true, "Camera", 20 + x);
	m_up = this->createVec3Attribute("up",  0, 1, 0, true, "Camera", 30);
	m_fov = this->createDoubleAttribute("fov", 45, true, "Camera", 40);
	m_nearPlane = this->createDoubleAttribute("near", 1.0, true, "Camera", 50);
	m_farPlane = this->createDoubleAttribute("far", 1000.0, true, "Camera", 60);

	m_zoom = this->createDoubleAttribute("zoomrate", 50.0, false, "Camera Parameters", 70);
	m_dolly = this->createDoubleAttribute("dollyrate", .02, false, "Camera Parameters", 80);
	m_pan = this->createDoubleAttribute("panrate", .5, false, "Camera Parameters", 90);
	m_showTarget = this->createBoolAttribute("showtarget", false, false, "Camera Parameters", 95);
	m_showCamera = this->createBoolAttribute("showcamera", false, false, "Camera Parameters", 96);

	ArbMatrix mat(4,4) ;
	m_camTransformation = this->createMatrixAttribute("transform", mat, false, "Camera Parameters", 100, false, false, false) ;
	//m_camTransformation = this->createMatrixAttribute("transform", ArbMatrix(4, 4), false, "Camera Parameters", 100) ;
	m_camTransformation->getAttributeInfo()->setHidden(true);
	m_useShadows = this->createBoolAttribute("useshadows", false, true, "Camera Parameters", 130);
	m_shadowMapSize = this->createIntAttribute("shadowmapsize", 512, true, "Camera Parameters", 140);

	initCamera();

	int w = dance::rootWindow->danceWindow ->w();
	int h = dance::rootWindow->danceWindow ->h();

	setX(0);
	setY(0);
	setWidth(w);
	setHeight(h);
}

TrackView::~TrackView()
{
	if (gui != NULL)
		delete gui;
}

/*
int TrackView::interact(Event* event)
{

}
*/

void TrackView::output(int mode)
{
	if (m_visible->getValue())
	{
		glPushAttrib(GL_LIGHTING_BIT | GL_COLOR_BUFFER_BIT);
		glDisable(GL_LIGHTING);
		if (m_showTarget->getValue())
		{
			glPushMatrix();
			glColor3f(1.0, 0.0, 0.0);
			glTranslatef(m_target[0]->getValue(), m_target[1]->getValue(), m_target[2]->getValue());  
			glutWireSphere(1.0, 10.0, 10.0);
			glPopMatrix();
		}
		if (m_showCamera->getValue() && dance::AllViews->currentView != this)
		{
			glPushMatrix();
			glColor3f(1.0, 0.0, 0.0);
			glTranslatef(m_position[0]->getValue(), m_position[1]->getValue(), m_position[2]->getValue());  
			glutWireCube(1.0);
			glPopMatrix();

			// draw a line from the camera to the target
			glColor3f(0.7f, 0.0, 0.0);
			glBegin(GL_LINES);
			glVertex3f(m_position[0]->getValue(), m_position[1]->getValue(), m_position[2]->getValue());  
			glVertex3f(m_target[0]->getValue(), m_target[1]->getValue(), m_target[2]->getValue());  
			glEnd();
		}
		
		
		glPopAttrib();
	}
}

int TrackView::commandPlugIn(int argc, char **argv)
{
	// let the parent class (PlugIn) handle the commands first
	int ret = PlugIn::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;



	return DANCE_CONTINUE; // command was not found
}

void TrackView::render(int argc, char** argv, std::ofstream& file)
{

}

void TrackView::save(int mode, std::ofstream& file)
{
	//char buff[512];

	if (mode == 0)
	{
		file << "dance.instance(\"TrackView\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
		PlugIn::save(mode, file); // let the parent class handle saving in this mode
	
	}
	else if (mode == 2)
	{
		// add any commands that rely upon other plugins
		PlugIn::save(mode, file); // let the parent class handle saving in this mode
	}
}

fltk::Widget* TrackView::getInterface()
{
	if (gui == NULL) 
	{
		gui = new TrackViewWindow(this, 0, 0, 300, 400, this->getName());
	}

	return gui;
}


void TrackView::PositionCamera()
{
	 glMatrixMode(GL_MODELVIEW);
	 glLoadIdentity();

	 double* up = m_up->getValue();
	 gluLookAt(m_position[0]->getValue(), m_position[1]->getValue(), m_position[2]->getValue(),
		       m_target[0]->getValue(), m_target[1]->getValue(),  m_target[2]->getValue(), 
			   up[0], up[1], up[2]);

	 // store the camera position	
	 glGetDoublev(GL_MODELVIEW_MATRIX, Modelview);
}

void TrackView::pickProjection(int x, int y, double delX, double delY)
{
    GLint rm ;
    glGetIntegerv(GL_RENDER_MODE, &rm) ;  
    
    // Get viewport	data.
    GLint viewport[4];
    glGetIntegerv(GL_VIEWPORT,viewport);
    // Load	special	Picking	Matrix Projection
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPickMatrix(x ,viewport[3] - y, delX, delY, viewport);
	gluPerspective(m_fov->getValue(), double(getWidth()) / double(getHeight()), m_nearPlane->getValue(), m_farPlane->getValue());
	setNeedsReset(false);
}


void TrackView::setProjection()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(m_fov->getValue(), double(getWidth()) / double(getHeight()), m_nearPlane->getValue(), m_farPlane->getValue());

	setNeedsReset(false);

}

void TrackView::notify(DSubject* subject)
{
	if (subject == m_fov || subject == m_farPlane || subject == m_nearPlane)
	{	
		setNeedsReset(true);
		dance::Refresh();
	}
	else if (subject == m_position[0] || subject == m_position[1] || subject == m_position[2])
	{
		dance::Refresh();
	}
	else if (subject == m_target[0] || subject == m_target[1] || subject == m_target[2])
	{
		dance::Refresh();
	}
	else if (subject == m_up)
	{
		dance::Refresh();
	}
	else if (subject == m_showTarget)
	{
		dance::Refresh();
	}
	else if (subject == m_showCamera)
	{
		dance::Refresh();
	}
	else if (subject == m_useShadows)
	{
		dance::Refresh();
	}
	else if (subject == m_shadowMapSize)
	{
		this->setNeedsReset(true);
		dance::Refresh();
	}


}


void TrackView::moveCamera(double dist, double panx, double pany, double target[3], HVect arccoords)
{
}

void TrackView::panCamera(double panx, double pany)
{
	int w = dance::rootWindow->danceWindow ->w();
	int h = dance::rootWindow->danceWindow ->h();

	setX(0);
	setY(0);
	setWidth(w);
	setHeight(h);

	double width = double(getWidth());
	double height = double (getHeight());

	double deltaX = panx / double(width) * m_pan->getValue();
	double deltaY = pany / double(height) * m_pan->getValue();

	VectorObj cameraPos(m_position[0]->getValue(), m_position[1]->getValue(), m_position[2]->getValue());
	VectorObj targetPos(m_target[0]->getValue(), m_target[1]->getValue(), m_target[2]->getValue());
	VectorObj diff = targetPos - cameraPos;
	double distance = diff.length();

	double windowHeight = 2 * diff.length() * atan(m_fov->getValue() * M_PI / 180.0 / 2.0);

	VectorObj up(m_up->getValue()[0], m_up->getValue()[1], m_up->getValue()[2]);
	VectorObj dirX = up;
	VectorObj cross = up.cross(diff);
	VectorObj dirY = cross / cross.length();

	
	VectorObj targetPosNew = targetPos + dirY * deltaX * windowHeight * width / height + dirX * deltaY * windowHeight;
	cameraPos += (targetPosNew - targetPos);

		
	for (int x = 0; x < 3; x++)
		m_position[x]->setValue(cameraPos[x]);
	for (int x = 0; x < 3; x++)
		m_target[x]->setValue(targetPosNew[x]);
}

void TrackView::dollyCamera(double amount)
{
	// move the distance closer to the target
	VectorObj cameraPos(m_position[0]->getValue(), m_position[1]->getValue(), m_position[2]->getValue());
	VectorObj targetPos(m_target[0]->getValue(), m_target[1]->getValue(), m_target[2]->getValue());
	VectorObj diff = targetPos - cameraPos;
	double distance = diff.length();
	// make sure that the camera does not go past the object
	if (amount >= distance)
		amount = distance - .000001;
	VectorObj diffVector = diff.normalize();
	VectorObj adjustment = diffVector * distance * amount;
	cameraPos = cameraPos + adjustment;

	for (int x = 0; x < 3; x++)
		m_position[x]->setValue(cameraPos[x]);
}

void TrackView::zoomCamera(double amount)
{
	m_fov->setValue(m_fov->getValue() * amount);
}


void TrackView::rotateCamera(double x, double y)
{
	double width = double(getWidth());
	double height = double (getHeight());

	double deltaX = (x - double(m_origMouseX)) / width;
	double deltaY = (y - double(m_origMouseY)) / height;
	if (deltaX == 0.0 && deltaY == 0.0)
		return;
	
	VectorObj up = m_origUp;
	VectorObj target = m_origTarget;
	VectorObj camera = m_origPosition;
//	VectorObj camera2(m_position[0]->getValue(), m_position[1]->getValue(), m_position[2]->getValue()); 

	VectorObj dirX = up;
	VectorObj dirY = up.cross(target - camera);
//	VectorObj dirY = up.cross(target - camera2); // calculate the y-direction based on the current camera
	dirY /= dirY.length();

	camera = rotatePoint(camera, target, dirX, -deltaX * M_PI);
	camera = rotatePoint(camera, target, dirY, deltaY * M_PI);
//	up = rotatePoint(target + up, target, dirY, deltaY * M_PI) - target;

	up.normalize();

//	m_up->setValue(up.data());

	for (int x = 0; x < 3; x++)
	{
		m_position[x]->setValue(camera[x]);
	}
}

VectorObj TrackView::rotatePoint(VectorObj point, VectorObj origin, VectorObj direction, double angle)
{
	double originalLength = point.length();
	if (0)
	{
		point -= origin;

		Quaternion q(direction.data(), angle);
		Matrix3x3 mat;
		q.toMatrix(mat);
		VectorObj newpoint = mat * point;

		point = newpoint + origin;

		return point;
	}
	else if(0)
	{
		Quaternion q(point[0], point[1], point[2], 0.0);
		Quaternion dir(direction[0] * sin(angle/2.0),
					   direction[1] * sin(angle/2.0),
			           direction[2] * sin(angle/2.0),
			           cos(angle/2.0));
		double length = dir.length();
		dir.normalize();
		Quaternion dirInverse(dir);
		dirInverse.invert();
		dirInverse.normalize();
		Quaternion qResult = dir * q * dirInverse;
		VectorObj pointResult(qResult[0], qResult[1], qResult[2]);

		double finalLength = pointResult.length();
		return pointResult;

	}
	else
	{
		VectorObj v = direction;
		VectorObj o = origin;
		VectorObj p = point;
		double c = cos(angle);
		double s = sin(angle);
		double C = 1.0 - c;

		Matrix3x3 mat;
		mat[0][0] = v[0] * v[0] * C + c;
		mat[0][1] = v[0] * v[1] * C - v[2] * s;
		mat[0][2] = v[0] * v[2] * C + v[1] * s;
		mat[1][0] = v[1] * v[0] * C + v[2] * s;
		mat[1][1] = v[1] * v[1] * C + c;
		mat[1][2] = v[1] * v[2] * C - v[0] * s;
		mat[2][0] = v[2] * v[0] * C - v[1] * s;
		mat[2][1] = v[2] * v[1] * C + v[0] * s;
		mat[2][2] = v[2] * v[2] * C + c;
		mat.transpose();

		VectorObj result = origin + mat * (point - origin);

		return result;
	}
}

void TrackView::handleCameraMotions(int eventType, int x, int y, int width, int height, int diffx, int diffy)
{	
	switch(getMode())
	{
	   case DView::MODE_ARCBALL:
	   {
	     rotateCamera(x, y);
		 resetLights();
		 postRedisplay();
	   }
	   break;
	   case	DView::MODE_PAN:
	   {		   
		 if (diffx != 0 || diffy != 0)
			panCamera(diffx, diffy);
		 resetLights();
	     postRedisplay();
	   }
	   break;
	   case	DView::MODE_ZOOM:
	     //	Orthographic zoom and non-forshortening	zoom
	     if	(diffx + diffy > 0)
		     zoomCamera(1 + m_zoom->getValue());
	     else
		     zoomCamera(1 - m_zoom->getValue());
		 resetLights();
	     postRedisplay();
	   break;
	   case	DView::MODE_DOLLY:
	     //	Only for Perspective window, displays forshortening effects.		
		 if (diffx != 0 || diffy != 0)
		 {
			 if	(diffx + diffy > 0)
				 dollyCamera(m_dolly->getValue());
			 else
				 dollyCamera(-m_dolly->getValue());
			 resetLights();
			 postRedisplay();
		 }
	   break;
	}
}

void TrackView::handleCameraButtons(int eventType, int button, int state, int x, int y, int width, int height)
{
	bool alt = (fltk::get_key_state(fltk::LeftAltKey) || fltk::get_key_state(fltk::RightAltKey));
	if (!alt)
		return;

	switch (button) {
	    case 1:
			if (eventType == fltk::PUSH)
			{
				setMode(DView::MODE_ARCBALL);
				resetLights();
				postRedisplay();
			}
			else
			{
				setMode(DView::MODE_NONE);
				resetLights();
				postRedisplay();
			}
			break;
	     case 2:
			if (eventType == fltk::PUSH)
			{
				setMode(DView::MODE_PAN);
				
				resetLights();
				postRedisplay();
			}
			else
			{
				setMode(DView::MODE_NONE);
				resetLights();
				postRedisplay();
			}
			break;
	     case 3:
			if (eventType == fltk::PUSH)
			{
				setMode(DView::MODE_DOLLY);
				
				resetLights();
				postRedisplay();
			}
			else
			{
				setMode(DView::MODE_NONE);
				resetLights();
				postRedisplay();
			}
			break;
		 default:
			 break;
	}

}

void TrackView::AttachCamera(BoundingBox *box)
{
	VectorObj b1(box->xMin, box->yMin, box->zMin);
	VectorObj b2(box->xMax, box->yMax, box->zMax);

	VectorObj target = b1 + .5 * (b2 - b1);
	for (int x = 0; x < 3; x++)
		this->m_target[x]->setValue(target[x]);

	VectorObj up(0,1,0);
	m_up->setValue(up.data());

	double max1 = fabs(b2[0] - b1[0]);
	double max2 = fabs(b2[1] - b1[1]);
	double length = 1.2 * (max1 > max2? max1 : max2);

	double denom = 2 * tan(m_fov->getValue() * M_PI / 180.0 / 2.0);
	VectorObj position(target[0], target[1], b2[2] + (length / denom));
	for (int x = 0; x < 3; x++)
		this->m_position[x]->setValue(position[x]);

	setNeedsReset(true);
}

void TrackView::saveCurrentState(int lastMouseX, int lastMouseY)
{
	m_origMouseX = lastMouseX;
	m_origMouseY = lastMouseY;
	m_origUp = VectorObj(m_up->getValue()[0], m_up->getValue()[1], m_up->getValue()[2]);
	m_origTarget = VectorObj(m_target[0]->getValue(), m_target[1]->getValue(), m_target[2]->getValue());
	m_origPosition = VectorObj(m_position[0]->getValue(), m_position[1]->getValue(), m_position[2]->getValue());
}

void TrackView::calcNearFar(double& near, double& far)
{
	VectorObj eye(m_position[0]->getValue(), m_position[1]->getValue(), m_position[2]->getValue());
	VectorObj lookat(m_target[0]->getValue(), m_target[1]->getValue(), m_target[2]->getValue());
	VectorObj direction(lookat - eye);
	direction.normalize();

	BoundingBox tbox;
	BoundingBox* bbox = calcBoundingBox(&tbox);

	VectorObj minVec(bbox->xMin - eye[0], bbox->yMin - eye[1], bbox->zMin - eye[2]);
	VectorObj maxVec(bbox->xMax - eye[0], bbox->yMax - eye[1], bbox->zMax - eye[2]);

	near = .4 * minVec.dot(direction); 
	far = 1.7 * maxVec.dot(direction); 

	if (near < 0)
		near = .00001;
	
}

void TrackView::initCamera()
{
	VectorObj up(0, 1, 0);
	m_up->setValue(up.data());
	m_nearPlane->setMin(.00000001);
	m_fov->setMin(.00000001);
	m_fov->setMax(180.0);
	m_farPlane->setMin(.00000001);

	m_fov->setValue(54.43);
	m_nearPlane->setValue(.1);
	m_farPlane->setValue(1000.0);
	m_position[0]->setValue(48.0);
	m_position[1]->setValue(36.0);
	m_position[2]->setValue(-48.0);

	m_cameraMoved = true;
}

void TrackView::resetCamera()
{
	VectorObj up(0, 1, 0);
	m_up->setValue(up.data());
	m_cameraMoved = true;
}

void TrackView::setTarget(Vector t)
{
	for (int x = 0; x < 3; x++)
		m_target[x]->setValue(t[x]);
}

double* TrackView::getTarget()
{
	// this is a little awkward, since I can't return the three m_target values
	for (int x = 0; x < 3; x++)
		Target[x] = m_target[x]->getValue();
	return &Target[0];
}

void TrackView::setCamera(Vector t)
{
	for (int x = 0; x < 3; x++)
		m_position[x]->setValue(t[x]);
}

double* TrackView::getCamera()
{
	// this is a little awkward, since I can't return the three m_position values
	for (int x = 0; x < 3; x++)
		Camera[x] = m_position[x]->getValue();
	return &Camera[0];
}

int TrackView::isShadows()
{
	return m_useShadows->getValue();
}