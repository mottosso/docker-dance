/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef _BETTERCAMERA_H
#define _BETTERCAMERA_H

#include "PlugIn.h"
#include "DView.h"
#include <fltk/Widget.h>
#include "DAttribute.h"

class TrackViewWindow;

class TrackView : public DView
{
	public:
		PlugIn* create(int argc, char **argv);

		TrackView();
		~TrackView();

		virtual void output(int mode);
		virtual int commandPlugIn(int argc, char **argv);
		virtual void render(int argc, char ** argv, std::ofstream & file);

		virtual void save(int mode, std::ofstream& file);

		virtual fltk::Widget* getInterface();

		virtual void PositionCamera();
		virtual void setProjection();
		void pickProjection(int x, int y, double delX, double delY);
		void AttachCamera(BoundingBox *box);

		virtual void moveCamera(double dist, double panx, double pany, double target[3], HVect arccoords);
		virtual void panCamera(double panx, double pany);
		virtual void dollyCamera(double	percentage);
		virtual void zoomCamera(double percentage);
		virtual void rotateCamera(double x, double y);

		virtual void handleCameraMotions(int eventType, int x, int y,	int width, int height, int diffx, int diffy);
		virtual void handleCameraButtons(int eventType, int button, int state, int	x, int y, int width, int height);

		virtual void notify(DSubject* subject);


		virtual void saveCurrentState(int lastMouseX, int lastMouseY);
		virtual void calcNearFar(double& near, double& far);
		virtual void resetCamera();
		virtual void initCamera();

		virtual void setTarget(Vector t);
		virtual double* getTarget();
		virtual void setCamera(Vector t);
		virtual double* getCamera();

		virtual int isShadows();

	private:
		VectorObj rotatePoint(VectorObj point, VectorObj origin, VectorObj direction, double angle);
		TrackViewWindow* gui;

		DoubleAttribute* m_position[3];
		DoubleAttribute* m_target[3];
		Vec3Attribute* m_up;
		DoubleAttribute* m_fov;
		DoubleAttribute* m_nearPlane;
		DoubleAttribute* m_farPlane;

		DoubleAttribute* m_zoom;
		DoubleAttribute* m_dolly;
		DoubleAttribute* m_pan;
		MatrixAttribute* m_camTransformation;

		BoolAttribute* m_showTarget;
		BoolAttribute* m_showCamera;
		BoolAttribute* m_useShadows;
		IntAttribute* m_shadowMapSize;

		VectorObj m_origUp;
		VectorObj m_origTarget;
		VectorObj m_origPosition;
		int m_origMouseX;
		int m_origMouseY;

};

#endif

