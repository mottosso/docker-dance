/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "SensorSkeleton.h"
#include "SensorSkeletonWindow.h"
#include "SensorWindow.h"
#include <fltk/Group.h>
#include <fltk/CheckButton.h>
#include <fltk/Widget.h>
#include <fltk/ask.h>
#include "dance.h"
#include "ViewManager.h"


using namespace fltk;

SensorSkeletonWindow::SensorSkeletonWindow(SensorSkeleton* s, int x, int y, int w, int h, char* name) : Group(x, y, w, h, name)
{
	sensorSkeleton = s;

	this->begin();

	checkEnabled = new CheckButton(10, 10, 80, 20, "Enable SensorSkeleton");
	checkEnabled->callback(enableCB, this);

	choiceSystem = new Choice(110, 35, 120, 20, "System to monitor");
	choiceSystem->callback(chooseSystemCB, this);


	this->end();

	this->updateGUI();
}

void SensorSkeletonWindow::show()
{
	this->updateGUI();

	Group::show();
}

void SensorSkeletonWindow::updateGUI()
{
	choiceSystem->clear();
	choiceSystem->add("Choose an system object");
	for (int x = 0; x < dance::AllSystems->size(); x++)
	{
		DSystem* sys = (DSystem*) dance::AllSystems->get(x);
		if (this->sensorSkeleton->isValidSystem(sys))
		{
			this->choiceSystem->add(sys->getName());
		}
	}

	// choose the appropriate articulated object
	DSystem* sys = this->sensorSkeleton->getSystem();

	if (sys != NULL)
	{
		for (int x = 0; x < choiceSystem->size(); x++)
		{
			Widget* w = choiceSystem->child(x);
			if (strcmp(sys->getName(), w->label()) == 0)
			{
				choiceSystem->value(x);
				break;
			}
		}
	}
	else
	{
		choiceSystem->value(0);
	}

	if (this->sensorSkeleton->isSensorsEnabled())
	{
		this->checkEnabled->value(true);
	}
	else
	{
		this->checkEnabled->value(false);
	}
}

void SensorSkeletonWindow::enableCB(fltk::Widget* widget, void* data)
{
	SensorSkeletonWindow* win = (SensorSkeletonWindow*) data;

	win->sensorSkeleton->enableSensors(win->checkEnabled->value());

	win->updateGUI();

}

void SensorSkeletonWindow::chooseSystemCB(fltk::Widget* widget, void* data)
{
	SensorSkeletonWindow* win = (SensorSkeletonWindow*) data;

	Widget* w = win->choiceSystem->child(win->choiceSystem->value());

	DSystem* sys = (DSystem*) dance::AllSystems->get((char*) w->label());
	if (sys != NULL)
	{
		win->sensorSkeleton->setSystem(sys);
	}
	else
	{
		danceInterp::OutputMessage("Unknown system '%s'.", w->label());
	}

	win->updateGUI();
}



