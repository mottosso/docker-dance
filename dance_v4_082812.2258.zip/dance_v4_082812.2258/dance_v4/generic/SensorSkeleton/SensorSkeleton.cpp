/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "SensorSkeleton.h"
#include "dance.h"
#include "DSimulatorManager.h"
#include "SensorSkeletonWindow.h"
#include "Link.h"

PlugIn* Proxy()
{
	return new SensorSkeleton();
}

PlugIn* SensorSkeleton::create(int argc, char **argv)
{
	SensorSkeleton* t = new SensorSkeleton();

	return t;
}

SensorSkeleton::SensorSkeleton() : Sensor()
{
	this->sensorSkelWindow = NULL;
	this->enableSensors(false);
	this->setSystem(NULL);
	this->m_isInitSP = false;
}

SensorSkeleton::~SensorSkeleton()
{
	if (sensorSkelWindow != NULL)
		delete sensorSkelWindow;
}

int SensorSkeleton::commandPlugIn(int argc, char **argv)
{
	int ret = Sensor::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

	return DANCE_CONTINUE;
}

bool SensorSkeleton::isValidSystem(DSystem* sys)
{
	ArticulatedObject* ao = dynamic_cast<ArticulatedObject*>(sys);
	if (ao != NULL)
		return true;
	else
		return false;
}

//void SensorSkeleton::computeSensors()
//{
//	return;
//}

//int SensorSkeleton::getLeftFootIndex()
//{
//	return 0;
//}
//
//int SensorSkeleton::getRightFootIndex()
//{
//	return 0;
//}
//
//bool SensorSkeleton::isFootLink()
//{
//	return true;
//}

void SensorSkeleton::computeSupportPolygon( void )
{
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem();
	Link **link = ao->getLinks();
	double tm[4][4] ;

    if(	link ==	NULL )
    {
		danceInterp::OutputMessage( "ComputeSupportPolygon: object has no links!\n") ;
		return ;
    }

    if(	m_isInitSP == false )
    {
		if( !this->InitSupportPolygon() ) return ;
    }

	int numLinks = ao->getNumLinks();
	if (numLinks < 16) 
	{
		//danceInterp::OutputMessage( "ComputeSupportPolygon: object does not have enough links!\n") ;
		return ;
	}

	int Left_Foot = 12;
	int Right_Foot = 15;

    // find the	vertices in world coordinates
	if( link[Left_Foot]->getArticulatedObject()->getNumSimulators() == 0)
    {
		link[Left_Foot]->getWTransMat(tm) ;
		transformPoints_mat(m_sp.lVertices, m_sp.nl, m_sp.wVertices, tm) ;
		link[Right_Foot]->getWTransMat(tm) ;
		transformPoints_mat(&m_sp.lVertices[m_sp.nl], m_sp.nr, &m_sp.wVertices[m_sp.nl], tm) ;
    }
    else
    {
		for( int i = 0 ; i <  m_sp.nl ; i++ )
		{
			link[Left_Foot]->getWorldCoord(m_sp.wVertices[i], m_sp.lVertices[i]) ;
		}
		for( int i = 0 ; i <  m_sp.nr ; i++ )
		{
			link[Right_Foot]->getWorldCoord(m_sp.wVertices[m_sp.nl+i], m_sp.lVertices[m_sp.nl+i]) ;
		}
    }
    // compute the support polygon
    m_sp.compute() ;
    // compute its geometric center
 //   double center = m_sp.computeGeometricCenter() ;

	//// set the feet contact points in wolrd coordinates
	//VecCopy(m_LeftFootCP[0], m_sp.wVertices[0]) ;
	//VecCopy(m_LeftFootCP[1], m_sp.wVertices[1]) ;

	//VecCopy(m_RightFootCP[0], m_sp.wVertices[2]) ;
	//VecCopy(m_RightFootCP[1], m_sp.wVertices[3]) ;

}

int SensorSkeleton::InitSupportPolygon( void )
{
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem();
	Link **link = ao->getLinks();
    if(	ao == NULL )
    {
		danceInterp::OutputMessage("SensorsSkeleton::InitSupportPolygon: "
		      "No object present!\n") ;
		return 0 ;
    }
    // use only	the feet links
    if(	link ==	NULL )
    {
		danceInterp::OutputMessage( "SensorsRobot::InitSupportPolygon: "
				"Object doesn't have links!\n") ;
		return 0 ;
    }

	int numLinks = ao->getNumLinks();
	if (numLinks < 16)
	{
		//danceInterp::OutputMessage( "SensorsRobot::InitSupportPolygon: "
			//	"Object doesn't have enough links!\n") ;
		return 1 ;
	}
	
	int Left_Foot = 12;
	int Right_Foot = 15;

    if ((m_sp.nl = link[Left_Foot]->getGeometry()->getNumMonitorPoints()) == 0)
    {
		danceInterp::OutputMessage( "SensorsRobot::InitSupportPolygon: "
				"Left foot doesn't have monitor points!\n") ;
		return 0 ;
    }

    if ((m_sp.nr = link[Right_Foot]->getGeometry()->getNumMonitorPoints()) == 0)
    {
		danceInterp::OutputMessage( "SensorsRobot::InitSupportPolygon: "
				"Right foot doesn't have monitor points!\n") ;
		return 0 ;
    }

    Vector *lmpts ;
    Vector *rmpts ;
    link[Left_Foot]->getMonitorPoints(&lmpts) ;
    link[Right_Foot]->getMonitorPoints(&rmpts) ;

    m_sp.nl = 2 ;
    VecCopy(m_sp.lVertices[0], lmpts[2]) ;
    VecCopy(m_sp.lVertices[1], lmpts[4]) ;

    m_sp.nr = 2 ;
    VecCopy(m_sp.lVertices[2], rmpts[2]) ;
    VecCopy(m_sp.lVertices[3], rmpts[4]) ;

    m_isInitSP = true ;

    return 1 ;

}

void SensorSkeleton::save(int mode, std::ofstream& file)
{
	if (mode == 0)
	{
		file << "dance.instance(\"SensorSkeleton\", \"" << this->getName() << "\")" << std::endl; 
	}
	else
	{
		Sensor::save(mode,file) ;
		PlugIn::save(mode, file);

	}

	Sensor::save(mode, file);
}


