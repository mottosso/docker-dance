#include <cstdio>
#include "opengl.h"
#include "dance.h"
#include "myMath.h"
//#include "convexHull.h"
#include "SupportPolygon2D.h"

SupportPolygon2D::SupportPolygon2D()
{
    nl = nr = 0	;
    for( int i = 0 ; i < SP2D_MAX_NUM_PTS ; i++ )
    {
        zeroVector(lVertices[i]) ;
	zeroVector(wVertices[i]) ;
    }
	m_low = MINFLOAT ;
	m_high = MAXFLOAT ;
}

void 
SupportPolygon2D::output(int mode)
{

    int	light =	0 ;

    if (glIsEnabled(GL_LIGHTING) == GL_TRUE )
    {
	glDisable(GL_LIGHTING) ;
	light =	1 ;
    }

    // DRAW the	polygon as lines cause it may not be planar.
    //if( mode & LDISPLAY_WIRE)
    //	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)  ;
    //else
    //	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL) ;

    glLineWidth(8.0) ;
    glPointSize(8.0) ;
    glColor4f(0.0, 0.0, 1.0, 1.0) ;
    glBegin(GL_LINES) ;

    double v[3] = {0.0, 0.0, 0.0} ;
    v[2] = m_low ;
    glVertex3dv(v) ;
    v[2] = m_high ;
    glVertex3dv(v) ;
    glEnd() ;
    glLineWidth(1.0) ;
    glPointSize(1.0) ;

    // restore lighting	if needed
    if(	light == 1 )
	glEnable(GL_LIGHTING) ;
}

// PROC:   compute
// DOES:   given that all the fields have already been filled
//	   properly it computes	the support polygon
void SupportPolygon2D::compute()
{

	m_low = wVertices[0][2] ;
	m_high = wVertices[0][2] ;
	for( int i = 1 ; i < 4 ; i++ )
	{
		if( wVertices[i][2] < m_low )
			m_low = wVertices[i][2] ;
		if( wVertices[i][2] > m_high )
			m_high = wVertices[i][2] ;
	}
}

/** in wolrd coordinates */
double SupportPolygon2D::computeGeometricCenter()
{
    return 0.5*(m_high + m_low) ;
}
    







