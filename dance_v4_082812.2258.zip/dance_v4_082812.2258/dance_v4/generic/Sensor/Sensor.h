/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _Sensor_H_
#define _Sensor_H_

#include "PlugIn.h"
#include "DSystem.h"
#include "SupportPolygon.h"
#include "ArticulatedObject.h"

#include "assert.h"

class SensorWindow;

#ifdef WIN32
#ifndef SENSOR_EXPORTS
#define	DLLSENSOR __declspec(dllexport)
#else
#define	DLLSENSOR __declspec(dllimport)
#endif
#else
#define DLLSENSOR 
#endif

class DLLSENSOR Sensor : public PlugIn
{
	public:
		PlugIn* create(int argc, char **argv);

		Sensor();	
		~Sensor();

		virtual bool isValidSystem(DSystem* sys);
		void setSystem(DSystem* sys);
		DSystem* getSystem();

		void enableSensors(bool val);
		bool isSensorsEnabled();
		virtual void readSensor(double time);

		virtual double getTime() ;
		virtual void getPosition(int bodyNum, Vector v);
		virtual void getVelocity(int bodyNum, Vector v);
		virtual void getAngularVelocity(int bodyNum, Vector v);
		virtual void getCenterMass(Vector v);
		virtual void getCMVelocity(Vector v);

		virtual bool isLinkOnGround(int bodyNum) ;
		virtual bool isLinkColliding(int bodyNum) ;

		virtual void getFacing(Vector v);
		virtual void getUpVector(Vector v) ;
		virtual void computeCM(Vector v) ;
		virtual int getIndxFirstConDof( void ) ;
		virtual int getStateSize( void ) ;
		virtual int getNumJoints( void ) ;
		
		virtual double getState(int index) ;
		
		virtual void getOrientation(int source, Vector sourceVec, int target, Vector targetVec) ;
		virtual void getCMRelativeDistance(Vector dist);

		virtual void computeSupportPolygon( void );
		virtual double computeNearestPointOnSupportPolygon( Vector outPointOnSP, Vector argPoint );

		//virtual int InitSupportPolygon( void ) { assert( false ); return 0; }

		void onDependencyRemoval(DObject* obj);
		int commandPlugIn(int argc, char **argv);
		fltk::Widget* getInterface();
		void save(int mode, std::ofstream& file);
		int getNumPluginDependents();
		const char* getPluginDependent(int num);

		//extra
		bool func1();
		bool func2();
		bool func3(int value);

	protected:
		virtual void computeSensors( void ) { assert( false ); }

		//////////////////////////////////////////////////////////////////////////
		// Clients need to override
		virtual int getLeftFootIndex( void ) { assert( false ); return -1;}
		virtual int getRightFootIndex( void ) { assert( false ); return -1;}
		virtual bool isFootLink( int argLinkIdx ) { assert( false ); return false; }
		//////////////////////////////////////////////////////////////////////////

		SupportPolygon m_sp ;
		ArticulatedObject* m_artObj;

	private:
		static void sensorCB(DObject* object, double time);

		SensorWindow* sensorWindow;
		DSystem* system;
		bool isEnabled;

		/// Move this to SupportPolygon
		void sortIncreasingXY(Vector* in, int n, Vector* out);
		float isLeft(Vector P0, Vector P1, Vector P2);
		int chainHull_2D(Vector* P, int n, Vector* H);
	protected:
		Vector m_supportPolygon[MAX_STATE];
		Vector m_tempSupportPolygon[MAX_STATE];
		int m_supportPolygonCount;

};

#endif
