/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "Sensor.h"
#include "dance.h"
#include "DSimulatorManager.h"
#include "SensorWindow.h"

#include "DSystem.h"
#include "ArticulatedObject.h"
#include "Link.h"

#include <vector>

PlugIn* Proxy()
{
	return new Sensor();
}

PlugIn* Sensor::create(int argc, char **argv)
{
	Sensor* t = new Sensor();

	return t;
}

Sensor::Sensor() : PlugIn(), m_artObj( 0 )
{
	sensorWindow = NULL;
        isEnabled = false;
	this->enableSensors(false);
	this->setSystem(NULL);
}

Sensor::~Sensor()
{
	if (sensorWindow != NULL)
		delete sensorWindow;
}

int Sensor::commandPlugIn(int argc, char **argv)
{
	int ret = PlugIn::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

	if (strcmp(argv[0], "enable") == 0)
	{
		this->enableSensors(true);
		danceInterp::OutputMessage("Sensor '%s' has been enabled.",
this->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "disable") == 0)
	{
		this->enableSensors(false);
		danceInterp::OutputMessage("Sensor '%s' has been disabled.");
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "system") == 0)
	{
		if (argc == 2)
		{
			DSystem* sys = (DSystem*) dance::AllSystems->get(argv[1]);
			if (sys == NULL)
			{
				danceInterp::OutputMessage("No system named '%s' found.", argv[1]);
				return DANCE_ERROR;
			}
			this->setSystem(sys);
			danceInterp::OutputMessage("System '%s' attached to sensor '%s'.", sys->getName(), this->getName());
			return DANCE_OK;
		}
		else
		{
			this->setSystem(NULL);
			danceInterp::OutputMessage("Sensor '%s' is not attached to any system.", this->getName());
			return DANCE_OK;
		}
	}

	return DANCE_CONTINUE;
}

bool Sensor::isValidSystem(DSystem* sys)
{
	// subclasses should validate that the system is an appropriate system for the sensor
	return true;
}

void Sensor::setSystem(DSystem* sys)
{
	system = sys;
	this->addDependency(sys);
	if (sys != NULL)
		this->enableSensors(true);
}

DSystem* Sensor::getSystem()
{
	return system;
}

void Sensor::enableSensors(bool val)
{
	if (!isEnabled && val) // add a sensor callback 
	{
		dance::AllSimulators->addBeforeSimStepCB(this, -1, sensorCB);
	}
	else if (isEnabled && !val)
	{
		dance::AllSimulators->removeBeforeSimStepCB(this);
	}

	isEnabled = val;
}

bool Sensor::isSensorsEnabled()
{
	return isEnabled;
}

void Sensor::readSensor(double time)
{
	DSystem* sys = getSystem();
	if (sys != NULL)
	{
		m_artObj = dynamic_cast< ArticulatedObject* > ( sys );
		computeSensors();
	}
	else
	{
		m_artObj = NULL;
	}
}


void Sensor::onDependencyRemoval(DObject* obj)
{
	if (obj != NULL && this->getSystem() == obj)
	{
		this->system = NULL;
	}
}

fltk::Widget* Sensor::getInterface()
{
	if (sensorWindow == NULL)
	{
		sensorWindow = new SensorWindow(this, 10, 10, 300, 400, this->getName());
	}

	return sensorWindow;
}

void Sensor::save(int mode, std::ofstream& file)
{
	char buff[512];

	if (mode == 0)
	{
		file << "dance.instance(\"Sensor\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
		PlugIn::save(mode, file);
		if (this->isSensorsEnabled())
		{
			sprintf(buff, "\"enable\"");
		}
		else
		{
			sprintf(buff, "\"disable\"");
		}
		pythonSave(file, buff);
	}
	else if (mode == 2)
	{
		if (this->getSystem() != NULL)
		{
			sprintf(buff, "\"system\", \"%s\"", this->getSystem()->getName());
		}
		else
		{
			sprintf(buff, "\"system\"");
		}
		pythonSave(file, buff);

	}
	else
	{
		PlugIn::save(mode, file);

	}

}

int Sensor::getNumPluginDependents()
{
	return 0;
}

const char* Sensor::getPluginDependent(int num)
{
	return NULL;
}

void Sensor::sensorCB(DObject* object, double time)
{
	Sensor* sensor = (Sensor*) object;
	sensor->readSensor(time);
}

bool Sensor::func1()
{
	return true;
}

bool Sensor::func2()
{
	return false;
}

bool Sensor::func3(int value)
{
	if (value > 10)
		return true;
	else
		return false;
}

double Sensor::getTime()
{
	return dance::AllSimulators->getCurrentTime();
}



void Sensor::getPosition(int bodyNum, Vector v)
{
	//no checks for NULL
	DSimulator* sim = this->getSystem()->getSimulator(0);
	Vector zero = {0.0, 0.0, 0.0};
	sim->GetPosition(bodyNum, zero, v);
}

void Sensor::getVelocity(int bodyNum, Vector v)
{
	//no checks for NULL or bodyNum
	DSimulator* sim = this->getSystem()->getSimulator(0);
	Vector zero = {0.0, 0.0, 0.0};
	sim->GetVel(bodyNum, zero, v);
}

void Sensor::getAngularVelocity(int bodyNum, Vector v)
{
	DSimulator* sim = this->getSystem()->getSimulator(0);
	sim->GetAngVel(bodyNum, v);
}

void Sensor::getCenterMass(Vector v)
{
	//no checks for NULL
	if( !this || !getSystem() )
	{
		return;
	}
	DSimulator* sim = this->getSystem()->getSimulator(0);
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem();
	Link **link = ao->getLinks() ;
	setVector(v, 0.0, 0.0, 0.0) ;
	double totalMass = 0.0 ;
	int numLinks = ao->getNumLinks();
	for( int i = 0 ; i < numLinks ; i++ )
	{
		Vector cm0 = { 0.0, 0.0, 0.0}, cm ;
		sim->GetPosition(i, cm0, cm) ;
		link[i]->setCenterMass(cm) ;
		double m = link[i]->getMass() ;
		VecNumMul(cm,cm,m) ;
		totalMass += m ;
		VecAdd(v, v, cm) ;
	}
	VecScale(v, 1.0 / totalMass) ;

}

void Sensor::getCMVelocity(Vector v)
{
	//no checks for null
	DSimulator* sim = this->getSystem()->getSimulator(0);
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem();
	setVector(v, 0.0, 0.0, 0.0) ;
	int numLinks = ao->getNumLinks();
	for( int i = 0 ; i < numLinks ; i++ )
	{
		Vector vcm0 = { 0.0, 0.0, 0.0}, vcm ;
		sim->GetVel(i, vcm0, vcm) ;
		VecAdd(v, v, vcm) ;
	}
	VecScale(v, 1.0 / numLinks) ;
}



bool Sensor::isLinkOnGround(int bodyNum)
{
	DSimulator* sim = this->getSystem()->getSimulator(0);
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem();
	DCollision **cols = ao->getPointCollisionData() ;
	if (sim == NULL || ao == NULL)
		return false;

	int nmpts = cols[bodyNum]->getNumPoints();
	if( nmpts != 0 )
	{
		for( int i = 0 ; i < nmpts ; i++ )
		{
			if( cols[bodyNum]->isPointInCollision(i) )
				return true;
		}
	}
	return false;
}

bool Sensor::isLinkColliding(int bodyNum)
{
	DSimulator* sim = this->getSystem()->getSimulator(0);
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem();
	DCollision **cols = ao->getPointCollisionData() ;
	if (sim == NULL || ao == NULL)
		return false;

	int nmpts = cols[bodyNum]->getNumPoints();
	if( nmpts != 0 )
	{
		for( int i = 0 ; i < nmpts ; i++ )
		{
			if( cols[bodyNum]->isPointInCollision(i) )
				return true;
		}
	}
	return false;
}

void Sensor::getFacing(Vector v)
{
	DSimulator* sim = this->getSystem()->getSimulator(0);
	setVector(v, 0.0, 0.0, 1.0)	;
	sim->GetOrientation(0, v, -1, v);
}

void Sensor::getUpVector(Vector v)
{
	DSimulator* sim = this->getSystem()->getSimulator(0);
	if (sim == NULL)
		return;

	setVector(v, 0.0, 1.0, 0.0) ;
	sim->GetOrientation(0, v, -1, v) ;
}

void Sensor::computeCM(Vector v)
{
	DSimulator* sim = this->getSystem()->getSimulator(0);
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem();
	Link **link = ao->getLinks();
	if (sim == NULL)
		return;

	int	nlinks =  ao->getNumLinks();

	if(	nlinks == 0 )
		return;

	setVector(v, 0.0, 0.0, 0.0);

	for( int i = 0 ; i < nlinks ; i++ )
	{
		Vector cm0 = { 0.0, 0.0, 0.0}, cm ;
		sim->GetPosition(i, cm0, cm) ;
		VecAdd(v, v, cm) ;
		link[i]->setCenterMass(cm) ;
	}
	VecScale(v, 1.0 / nlinks) ;
	return ;
}

int Sensor::getIndxFirstConDof( void )
{
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem();
	if (ao == NULL)
		return 0;

	return ao->GetIndxFirstConDof();
}

int Sensor::getStateSize( void )
{
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem();
	if (ao == NULL)
		return 0;

	return ao->getStateSize();
}

double Sensor::getState(int index)
{
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem();
	if (ao == NULL)
		return 0.0;

	return ao->getState(index);
}

int Sensor::getNumJoints()
{
	ArticulatedObject* ao = (ArticulatedObject*) this->getSystem();
	if (ao == NULL)
		return 0;

	return ao->getNumJoints();
}

void Sensor::getOrientation(int source, Vector sourceVec, int target, Vector targetVec)
{
	DSimulator* sim = this->getSystem()->getSimulator(0);
	sim->GetOrientation(source, sourceVec, target, targetVec);
}


void Sensor::getCMRelativeDistance(Vector dist)
{
	Vector cm;
	computeCM(cm);
	computeSupportPolygon();

	// TMP
	// for now, just return the distance of the CM from center of SP
	Vector centerOfSP;
	for( int i = 0; i < 3; ++i )
	{
		centerOfSP[i] = 0.0;
	}
	for( int j = 0; j < 3; ++j )
	{
		for( int i = 0; i < m_sp.nvertex; ++i )
		{
			centerOfSP[j] += (m_sp.spVertices[i])[j];
		}
		centerOfSP[j] /= m_sp.nvertex;
		dist[j] = cm[j] - centerOfSP[j];
	}
}



////////////////////////////////////////////////////////////////////////////////////////////
// TMP -- Move to Support Polygon

double distanceToGround( Vector argPoint )
{
	// for now, assume a y=0 ground plane
	return abs( argPoint[1] );
}

void Sensor::computeSupportPolygon( void )
{
	m_supportPolygonCount = 0;
	if( !m_artObj )
	{
		return;
	}
	const double contactEpsilonM = 0.06; // 1cm

	for( int i = 0; i < MAX_NUM_PTS; ++i )
	{
		zeroVector( m_sp.wVertices[i] );
	}
	m_sp.contactPointCount = 0;

	DCollision** allCollisions = m_artObj->getPointCollisionData();
	if( !allCollisions )
	{
		return;
	}
	int collisionCount = m_artObj->getNumPointCollisionData();
	for( int i = 0; i < collisionCount; ++i )
	{
		DCollision* col = allCollisions[i];
		if( !col )
		{
			continue;
		}

		int linkId = col->getID();
		if( isFootLink( linkId ) ) 
		{
			Link* link = m_artObj->getLink( linkId );
			int pointCount = col->getNumPoints();
			for( int j = 0; j < pointCount; ++j )
			{
				double* linkLocalPt = col->getPoint(j);
				double worldPt[3] = {0,0,0};
				link->getWorldCoord( worldPt, linkLocalPt );
				DSystem* sys = col->getSystem();
				if( !sys )
				{
					continue;
				}
				/*if( worldPt )
				{
					continue;
				}
				*/

				if( contactEpsilonM > distanceToGround( worldPt ) )
				{
					VecCopy( m_sp.wVertices[m_sp.contactPointCount++], worldPt );
					VecCopy( m_supportPolygon[ m_supportPolygonCount++ ], worldPt );
					if( m_supportPolygonCount == MAX_NUM_PTS )
					{
						break;
					}
				}		
			}
		}
	}

	sortIncreasingXY(m_supportPolygon, m_supportPolygonCount, m_tempSupportPolygon);
	m_supportPolygonCount = chainHull_2D(m_tempSupportPolygon, m_supportPolygonCount, m_supportPolygon);

	// Compute the m_sp version of the support polygon
	m_sp.compute();
}

double Sensor::computeNearestPointOnSupportPolygon( Vector outPointOnSP, Vector argPoint )
{
	return m_sp.nearestPoint( outPointOnSP, argPoint );
}

void Sensor::sortIncreasingXY(Vector* in, int n, Vector* out)
{
	for (int c = 0; c < n; c++)
		VecCopy(out[c], in[c]);

	// quick and dirty bubble sort
	Vector temp;
	for (int i = 0; i < n - 1; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (out[i][0] > out[j][0])
			{
				VecCopy(temp, out[i]);
				VecCopy(out[i], out[j]);
				VecCopy(out[j], temp);
			}
		}
	}
}

// convex hull calculation
// from http://www.geometryalgorithms.com/Archive/algorithm_0109/algorithm_0109.htm
// isLeft(): tests if a point is Left|On|Right of an infinite line.
//    Input:  three points P0, P1, and P2
//    Return: >0 for P2 left of the line through P0 and P1
//            =0 for P2 on the line
//            <0 for P2 right of the line
//    See: the January 2001 Algorithm on Area of Triangles
float Sensor::isLeft(Vector P0, Vector P1, Vector P2)
{
	return (P1[0] - P0[0])*(P2[1] - P0[1]) - (P2[0] - P0[0])*(P1[1] - P0[1]);
}

int Sensor::chainHull_2D(Vector* P, int n, Vector* H )
{
	// the output array H[] will be used as the stack
	int    bot=0, top=(-1);  // indices for bottom and top of the stack
	int    i;                // array scan index

	// Get the indices of points with min x-coord and min|max y-coord
	int minmin = 0, minmax;
	float xmin = P[0][0];
	for (i=1; i<n; i++)
		if (P[i][0] != xmin) break;
	minmax = i-1;
	if (minmax == n-1) {       // degenerate case: all x-coords == xmin
		VecCopy(H[++top], P[minmin]);
		if (P[minmax][1] != P[minmin][1]) // a nontrivial segment
			VecCopy(H[++top], P[minmax]);
		VecCopy(H[++top], P[minmin]); // add polygon endpoint
		return top+1;
	}

	// Get the indices of points with max x-coord and min|max y-coord
	int maxmin, maxmax = n-1;
	float xmax = P[n-1][0];
	for (i=n-2; i>=0; i--)
		if (P[i][0] != xmax) break;
	maxmin = i+1;

	// Compute the lower hull on the stack H
	VecCopy(H[++top], P[minmin]);      // push minmin point onto stack
	i = minmax;
	while (++i <= maxmin)
	{
		// the lower line joins P[minmin] with P[maxmin]
		if (isLeft( P[minmin], P[maxmin], P[i]) >= 0 && i < maxmin)
			continue;          // ignore P[i] above or on the lower line

		while (top > 0)        // there are at least 2 points on the stack
		{
			// test if P[i] is left of the line at the stack top
			if (isLeft( H[top-1], H[top], P[i]) > 0)
				break;         // P[i] is a new hull vertex
			else
				top--;         // pop top point off stack
		}
		VecCopy(H[++top], P[i]); // push P[i] onto stack
	}

	// Next, compute the upper hull on the stack H above the bottom hull
	if (maxmax != maxmin)      // if distinct xmax points
		VecCopy(H[++top], P[maxmax]); // push maxmax point onto stack
	bot = top;                 // the bottom point of the upper hull stack
	i = maxmin;
	while (--i >= minmax)
	{
		// the upper line joins P[maxmax] with P[minmax]
		if (isLeft( P[maxmax], P[minmax], P[i]) >= 0 && i > minmax)
			continue;          // ignore P[i] below or on the upper line

		while (top > bot)    // at least 2 points on the upper stack
		{
			// test if P[i] is left of the line at the stack top
			if (isLeft( H[top-1], H[top], P[i]) > 0)
				break;         // P[i] is a new hull vertex
			else
				top--;         // pop top point off stack
		}

		VecCopy(H[++top], P[i]);// push P[i] onto stack
	}
	if (minmax != minmin)
		VecCopy(H[++top], P[minmin]); // push joining endpoint onto stack

	return top+1;
}


