#ifndef SupportPolygon2D_h
#define SupportPolygon2D_h

static const int SP2D_MAX_NUM_PTS = 4 ;

class DLLEXPORT SupportPolygon2D {
public:
  SupportPolygon2D() ;		

  int index[SP2D_MAX_NUM_PTS] ;	// it holds the	index of the vertices that
				// actually belong to
				// the support polygon
  Vector lVertices[SP2D_MAX_NUM_PTS]	;	// vertices in local coordinates
  Vector wVertices[SP2D_MAX_NUM_PTS]	;	// vertices in world coordinates
  int nl ;			// number of left foot points in lVertices
  int nr ;			// number of right foot	points in lVertices
  
  double m_low ;
  double m_high ;
  void output(int mode)	;
  void compute() ;
  double computeGeometricCenter() ;
  
} ;

#endif


