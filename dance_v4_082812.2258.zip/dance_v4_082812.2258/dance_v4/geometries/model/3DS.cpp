/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "dance.h"
#include "Model.h"
#include "danceInterp.h"

#include "lib3ds/file.h"
#include "lib3ds/material.h"
#include "lib3ds/matrix.h"
#include "lib3ds/mesh.h"
#include "lib3ds/light.h"
#include "stuff.h"

int Model::Read3DS(char* filename)
{
	
	int n, meshCount;
	GLuint firstFace, firstVertex, firstNormal, firstTexCoord, lastSubgroupFirstId;
	GLMgroup *m;
	Material *last_material, mat;


	danceInterp::OutputMessage("Loading 3DS file %s...\n", filename);

	this->pathname    = strdup(filename);


	Lib3dsFile* file3ds = lib3ds_file_load(filename);
	if (!file3ds)
	{
		danceInterp::OutputMessage("3DS file %s could not be loaded...\n", filename);
		return DANCE_ERROR;
	}
	lib3ds_file_eval(file3ds, 0);

	// retrieve all of the materials
	Lib3dsMaterial* material = file3ds->materials;
	n=0;
	while (material != NULL)
	{
		// add the corresponding material
		mat.setMaterialName(material->name);
		mat.setAmbientColor(material->ambient);
		mat.setDiffuseColor(material->diffuse);
		mat.setSpecularColor(material->specular);
		float emissive[4] = {0.0, 0.0, 0.0, 1.0};
		mat.setEmissiveColor(emissive);
		mat.setShininess(material->shininess);
		dance::MaterialManager->addMaterial(&mat);
		material = material->next;
		n++;
	}
	danceInterp::OutputMessage("Added %d materials", n);

	// get the meshes
	Lib3dsMesh* mesh = file3ds->meshes;


	meshCount = 0;
	firstFace = firstVertex = firstNormal = firstTexCoord = 0;

	while (mesh)
	{
		m=addGroup(mesh->name);
		meshCount++;
		danceInterp::OutputMessage("Mesh #%d", meshCount);


		// Vertices in the mesh
		for (unsigned int p = 0; p < mesh->points; p++)
			addVertex(mesh->pointL[p].pos[0], mesh->pointL[p].pos[1], mesh->pointL[p].pos[2]);

		danceInterp::OutputMessage("Added %d points...", mesh->points);

#if 0
		// Vertex normals
		Lib3dsVector *normalL = new Lib3dsVector[mesh->faces * 3];
		lib3ds_mesh_calculate_normals(mesh, normalL);

		// new method! smooth shading - AChu & AShapiro 11/7/03
		// this method rewrites several times each vertex's normal. If the normals are properly calculated,
		// they should all be the same for the same vertex
		for (int n = 0; n < mesh->faces; n++)
			for (int j=0; j<3; j++)
				setNormal(mesh->faceL[n].points[j], normalL[n][0], normalL[n][1], normalL[n][2]);

		delete[] normalL;
#endif

		// Texels (ideally, mesh->points == mesh->texels
		danceInterp::OutputMessage("Texels: %d", mesh->texels);
		for (unsigned int t = 0; t < mesh->texels; t++)
			addTexCoord(mesh->texelL[t][0], mesh->texelL[t][1]);

		lastSubgroupFirstId = 0;
		// Triangles
		for (unsigned int f = 0; f < mesh->faces; f++)
		{
			Lib3dsFace *face = &mesh->faceL[f];

			int faceNum = addFace();

	
			// XXX: improvement: put all the triangles with the same material in the same group
			
			Material *mtmp;
			char materialname[512];
			eliminatespaces(face->material, materialname);
			mtmp=dance::MaterialManager->getMaterialbyName(materialname);
			if (mtmp==NULL) {
				if (face->material[0]) danceInterp::OutputMessage("Could not find material \"%s\". Using the default", face->material);
				mtmp=dance::MaterialManager->getDefaultMaterial();
			}

			if (f==0) 
				m->material=last_material=mtmp;
			else 
				if (last_material != mtmp) {
					// There has been  a change of material inside a group: close this group...
					m->triangles=(GLuint *)malloc(sizeof(GLuint)*(f-lastSubgroupFirstId));
					if (m->triangles==NULL) {
						danceInterp::OutputMessage("Not enough memory. Possibly the file is corrupted");
						return DANCE_ERROR;
					}
					m->numtriangles=f-lastSubgroupFirstId;
					for (GLuint i=0;i<m->numtriangles;i++)
						m->triangles[i]=firstFace+i+lastSubgroupFirstId;

					lastSubgroupFirstId = f;

					danceInterp::OutputMessage("triangles in submesh: #%d", m->numtriangles);

					// ... and open a new one
					char tmp[100];

					sprintf(tmp, "%s%d", mesh->name, lastSubgroupFirstId);
					m=addGroup(tmp);
					m->material=last_material=mtmp;
					meshCount++;
					danceInterp::OutputMessage("SubMesh #%d", meshCount);
				}
				

			int facePoints[3];
			facePoints[0] = (int) face->points[0]+firstVertex;
			facePoints[1] = (int) face->points[1]+firstVertex;
			facePoints[2] = (int) face->points[2]+firstVertex;
			//danceInterp::OutputMessage("ADDING POINTS (%d, %d, %d) to FACE #%d", facePoints[0], facePoints[1], facePoints[2], faceNum);
			addCoordsToFace(faceNum, facePoints);
			// There is the same number of texture coordinates than vertices (hopefully, it has to exist the texture coordinates)
			addTexCoordsToFace(faceNum, facePoints);

//			int normalIndices[3] = {  firstNormal+f, firstNormal+f+ 1, firstNormal+f+ 2 };
//			addNormalToFace(faceNum, normalIndices);
		}

		firstVertex+=mesh->points;
		firstTexCoord+=mesh->texels;
		firstNormal += mesh->faces;


		m->triangles=(GLuint *)malloc(sizeof(GLuint)*(mesh->faces-lastSubgroupFirstId));
		if (m->triangles==NULL) {
			danceInterp::OutputMessage("Not enough memory. Possibly the file is corrupted");
			return DANCE_ERROR;
		}
        m->numtriangles=mesh->faces-lastSubgroupFirstId;
		for (GLuint i=0;i<m->numtriangles;i++)
			m->triangles[i]=firstFace+i+lastSubgroupFirstId;

		//danceInterp::OutputMessage("Added %d faces...", mesh->faces);
		danceInterp::OutputMessage("triangles in submesh: %d   (total faces in mesh %d)", m->numtriangles, mesh->faces);

		
		// read the flags
		danceInterp::OutputMessage("Flags: %d", mesh->flags);
		danceInterp::OutputMessage("Color: %d", mesh->color);
		danceInterp::OutputMessage("Box Map: %s %s %s %s %s %s ", mesh->box_map.back, mesh->box_map.bottom, mesh->box_map.front, mesh->box_map.left, mesh->box_map.right, mesh->box_map.top);

		firstFace += mesh->faces;

		mesh = mesh->next;
	}

	// are there any lights in this file?
	Lib3dsLight* light = file3ds->lights;
	while (light)
	{
		danceInterp::OutputMessage("Found light %s, ignoring...", light->name);
		light = light->next;
	}

	lib3ds_file_free(file3ds);

	computeVerticesNormals();

	this->computeFacetNormals();

	return DANCE_OK;
}
