/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
/*    
      glm.c
      Nate Robins, 1997, 2000
      nate@pobox.com, http://www.pobox.com/~nate
 
      Wavefront OBJ model file format reader/writer/manipulator.

      Includes routines for generating smooth normals with
      preservation of edges, welding redundant vertices & texture
      coordinate generation (spheremap and planar projections) + more.
  
*/
#ifdef WIN32
#include <windows.h>
#endif

#include "dance.h"
#include "danceInterp.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>

#include <fltk/string.h>
#include <fltk/ask.h>
//#include "GLSL/GL2_simple_shader/simpleShader.h"
//#include "GLSL/include/extsetup.h"
#include "Model.h"
#include "ModelWindow.h"
#include "stuff.h"
#include "ModelWindow.h"
#include <fltk/filename.h>
#include "OBJ.h"


using namespace fltk;

static  std::list<Texture> allTextures;
static  std::list<int> texUserCounters;


static int memError(const char *m = NULL)
{
	if( m != NULL )
		danceInterp::OutputMessage("ERROR: %s Cannot allocate memory!", m) ;
	else
		danceInterp::OutputMessage("ERROR: Cannot allocate memory!") ;
	return DANCE_ERROR ;
}

PlugIn *Proxy()
{
	return new Model();
}

PlugIn *Model::create(int argc, char **argv)
{
	Model *geo = new Model;
	if (geo	== NULL)
	{
		danceInterp::OutputMessage("Cannot allocate memory for geometry plugin.\n");
		return NULL;
	}

	if (argc >= 1)
	{
		char *ext;

		// deciding if we support the file format
		ext=strrchr(argv[0],'.');
		if (ext==NULL) {
			danceInterp::OutputMessage("File format not recognized.");
			return NULL;
		}

		ext++;
		if (!filename_match(ext, "obj") && !filename_match(ext, "wrl") && !filename_match(ext, "vrml") && !filename_match(ext, "3ds"))
		{
			danceInterp::OutputMessage("Unsupported file format.");
			return NULL;
		}

		int result;

		if ( filename_match(ext, "obj")) 
			result=geo->ReadOBJ(argv[0]);
		else if (filename_match(ext, "3ds")) 
			result=geo->Read3DS(argv[0]);
		else 
			result=geo->ReadVRML(argv[0]);

		if (result == DANCE_ERROR) {
				delete geo;
				return NULL;
			}

		if( geo->numfacetnorms == 0) 
			geo->computeFacetNormals();
		if (geo->m_NoNormalsRead== 1)
			geo->computeVerticesNormals();
			//glmVertexNormals(geo, 90) ;
	}

	return geo;

}

Model::Model(void)
{
	this->pathname    =  NULL ;
    this->mtllibname    = NULL;
    this->numvertices   = 0;
    this->vertices    = NULL;
    this->normals     = NULL;
    this->numtexcoords  = 0;
    this->texcoords       = NULL;
    this->numfacetnorms = 0;
    this->facetnorms    = NULL;
    this->numtriangles  = 0;
    this->triangles       = NULL;
    this->numgroups       = 0;
    this->groups      = NULL;
    this->position[0]   = 0.0;
    this->position[1]   = 0.0;
    this->position[2]   = 0.0;
	this->UseShaders = 0 ;
	
	this->m_NoNormalsRead = 1 ;
	// edges
	m_NumEdges = 0;
	m_EdgeList = NULL;
	m_VertexEdges = NULL;


	m_noisy=false;
	m_MirrorGeometry=0;
	m_showSelf = true;
	m_renderType=GEOMETRY_SOLID;

	m_checkPoint=0;

	maxNumVertices = maxNumTexCoords = maxNumFacetNorms = \
		maxNumTriangles = maxNumGroups = 0;

	this->m_modelWindow = NULL;

	this->setMutable(false);

	setShowNormals(false);
}

Model::Model(Model& model)
{
	this->pathname    =  NULL ;
    this->mtllibname    = NULL;
	this->numvertices   = model.GetNumVertices();
    this->vertices    = NULL;
    this->normals     = NULL;
    this->numtexcoords  = 0;
    this->texcoords       = NULL;
    this->numfacetnorms = 0;
    this->facetnorms    = NULL;
    this->numtriangles  = 0;
    this->triangles       = NULL;
    this->numgroups       = 0;
    this->groups      = NULL;
    this->position[0]   = 0.0;
    this->position[1]   = 0.0;
    this->position[2]   = 0.0;
	this->UseShaders = 0 ;
	
	// edges
	m_NumEdges = 0;
	m_EdgeList = NULL;
	m_VertexEdges = NULL;


	m_noisy=false;
	m_MirrorGeometry=0;
	m_showSelf = true;
	m_renderType=SOLID;

	m_checkPoint=0;

	maxNumVertices = maxNumTexCoords = maxNumFacetNorms = \
		maxNumTriangles = maxNumGroups = 0;

	this->m_modelWindow = NULL;
	this->setMutable(model.isMutable());
	
	setShowNormals(model.isShowNormals());

}

Model::~Model()
{
    GLMgroup* group;
    
	if (m_VertexEdges) {
		for (unsigned int i = 0; i < numvertices; i++) 
			m_VertexEdges[i].Cleanup();
		delete [] m_VertexEdges;
	}

	if (m_EdgeList) delete [] m_EdgeList;

    if (this->pathname) FREE_CLEAR(this->pathname);
    if (this->mtllibname) FREE_CLEAR(this->mtllibname);
    if (this->vertices)     FREE_CLEAR(this->vertices);
    if (this->normals)  FREE_CLEAR(this->normals);
    if (this->texcoords)  FREE_CLEAR(this->texcoords);
    if (this->facetnorms) FREE_CLEAR(this->facetnorms);
    if (this->triangles)  FREE_CLEAR(this->triangles);
    while(this->groups) {
        group = this->groups;
        this->groups = this->groups->next;
        if( group->name) FREE_CLEAR(group->name);
        if( group->numtriangles > 0) FREE_CLEAR(group->triangles);
        free(group);
    }

	if (this->m_modelWindow != NULL)
		delete this->m_modelWindow;
}


// Sets the normal of the given vertex
int Model::setNormal(unsigned int vid, float x, float y, float z) {
	if (vid<0 || vid>=numvertices) 
		return DANCE_ERROR;

	vid*=3;
	normals[vid]=x;
	normals[vid+1]=y;
	normals[vid+2]=z;

	return DANCE_OK;
}


BoundingBox *Model::calcBoundingBox(BoundingBox *box)
{
	if (vertices==NULL) return NULL;

	// run through all the vertices and	calculate
    // a general bounding box
	m_BoundingBox.xMin = MAXFLOAT;
	m_BoundingBox.yMin = MAXFLOAT;
	m_BoundingBox.zMin = MAXFLOAT;
	m_BoundingBox.xMax = MINFLOAT;
	m_BoundingBox.yMax = MINFLOAT;
	m_BoundingBox.zMax = MINFLOAT;
		
	double matrix[4][4];
	this->getTransMatrix(matrix);
	for(unsigned int i = 0 ; i <  numvertices ; i++ )
	{
		Vector curPoint;
		setVector(curPoint, vertices[i * 3], vertices[i * 3 + 1], vertices[i * 3 + 2]);

		if (this->useTransMatrix())
			transformPoint_mat(curPoint, matrix);

		if( curPoint[0] < m_BoundingBox.xMin )
			m_BoundingBox.xMin = curPoint[0];
		if( curPoint[1] < m_BoundingBox.yMin )
			m_BoundingBox.yMin = curPoint[1];
		if( curPoint[2] < m_BoundingBox.zMin )
			m_BoundingBox.zMin = curPoint[2];
		if( curPoint[0] > m_BoundingBox.xMax )
			m_BoundingBox.xMax = curPoint[0];
		if( curPoint[1] > m_BoundingBox.yMax )
			m_BoundingBox.yMax = curPoint[1];
		if( curPoint[2] > m_BoundingBox.zMax )
			m_BoundingBox.zMax = curPoint[2];
	}

	if (box) {
		box->copy(&m_BoundingBox);
		return (box) ;
	} else
		return &m_BoundingBox;
}


Widget* Model::getInterface()
{
	if (m_modelWindow == NULL)
	{
		m_modelWindow = new ModelWindow(this, 0, 0, 330, 400, this->getName());
	}

	return m_modelWindow;
}


int Model::commandPlugIn(int argc, char	**argv)
{
	int ret = DGeometry::commandPlugIn(argc, argv);
	if (ret == DANCE_OK || ret == DANCE_ERROR)
		return ret;

	const char *usage = {"Usage: reverse_order|scale <x> <y> <z>"} ;
	if (strcmp(argv[0], "scale") == 0)
	{
		if (argc < 4)
		{
			danceInterp::OutputMessage("Usage: scale <x> <y> <z>");
			return DANCE_ERROR;
		}
		float x = (float) atof(argv[1]);
		float y = (float) atof(argv[2]);
		float z = (float) atof(argv[3]);
		this->scaleGeometry(x, y, z) ;
		return DANCE_OK;
	}
	else if( strcmp(argv[0], "reverse_order") == 0 )
	{
		reverseWinding() ;
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "loadShader") == 0 )
	{
		danceInterp::OutputMessage("Loading shaders.") ;
			
		// removed by AS 1/13/04
/*		setUp(0,NULL) ;
		ProcessCommandLine(argc-1, &argv[1]) ;
*/		UseShaders = 1 ;
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "show") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: show <vertices|mesh|solid>\n");
			return DANCE_ERROR;
		}
		if (strcmp(argv[1], "vertices") == 0)
		{
			this->showVertices();
			danceInterp::OutputMessage("Vertices will now be shown.\n");
			dance::AllViews->postRedisplay();
		}
		else if (strcmp(argv[1], "mesh") == 0)
		{
			this->showMesh();
			danceInterp::OutputMessage("Mesh will now be shown.\n");
			dance::AllViews->postRedisplay();
		}
		else if (strcmp(argv[1], "solid") == 0)
		{
			this->showSolid();
			danceInterp::OutputMessage("Solids will now be shown.\n");
			dance::AllViews->postRedisplay();
		}
	}
	else
	{
		danceInterp::OutputMessage(usage) ;
		return DANCE_ERROR;
	}
	dance::Refresh() ;

	return DANCE_CONTINUE ;
}



// Find a group in the model
GLMgroup* Model::findGroup(const char* name)
{
    GLMgroup* group;
    
    group = groups;
    while(group) {
        if (!strcmp(name, group->name))
            break;
        group = group->next;
    }
    return group;
}


/* glmAddGroup: Add a group to the model */
GLMgroup* Model::addGroup(const char* name)
{
    GLMgroup* group, *last;
    
 	group = (GLMgroup*)malloc(sizeof(GLMgroup));
	if (group==NULL) return NULL;
	group->name = strdup(name);
	group->material = dance::MaterialManager->getDefaultMaterial();
	group->numtriangles = 0;
	group->triangles = NULL;
	group->next = NULL;

	if (groups==NULL) 
		groups = group;
	else {
		last=groups;
		while (last->next!=NULL)
			last=last->next;
		last->next=group;
	}
    numgroups++;
    return group;
}


// Scales all the vertices in the model by the given amount.
void Model::scaleGeometry(GLfloat x, GLfloat y, GLfloat z)
{
    for (unsigned i = 0; i < numvertices; i++) {
        vertices[3 * i + 0] *= x;
        vertices[3 * i + 1] *= y;
        vertices[3 * i + 2] *= z;
    }
}



/* _GLMnode: general purpose node */
typedef struct _GLMnode {
    GLuint         index;
    GLboolean      averaged;
    struct _GLMnode* next;
} GLMnode;



/* glmDot: compute the dot product of two vectors
 *
 * u - array of 3 GLfloats (GLfloat u[3])
 * v - array of 3 GLfloats (GLfloat v[3])
 */
static GLfloat
glmDot(GLfloat* u, GLfloat* v)
{
    assert(u); assert(v);
    
    return u[0]*v[0] + u[1]*v[1] + u[2]*v[2];
}

/* glmCross: compute the cross product of two vectors
 *
 * u - array of 3 GLfloats (GLfloat u[3])
 * v - array of 3 GLfloats (GLfloat v[3])
 * n - array of 3 GLfloats (GLfloat n[3]) to return the cross product in
 */
static GLvoid
glmCross(GLfloat* u, GLfloat* v, GLfloat* n)
{
    assert(u); assert(v); assert(n);
    
    n[0] = u[1]*v[2] - u[2]*v[1];
    n[1] = u[2]*v[0] - u[0]*v[2];
    n[2] = u[0]*v[1] - u[1]*v[0];
}

/* glmNormalize: normalize a vector
 *
 * v - array of 3 GLfloats (GLfloat v[3]) to be normalized
 */
static GLvoid
glmNormalize(GLfloat* v)
{
    GLfloat l;
    
    assert(v);
    
    l = (GLfloat)sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
    v[0] /= l;
    v[1] /= l;
    v[2] /= l;
}

/* glmEqual: compares two vectors and returns GL_TRUE if they are
 * equal (within a certain threshold) or GL_FALSE if not. An epsilon
 * that works fairly well is 0.000001.
 *
 * u - array of 3 GLfloats (GLfloat u[3])
 * v - array of 3 GLfloats (GLfloat v[3]) 
 */
static GLboolean
glmEqual(double* u, double* v, GLfloat epsilon)
{
    if (fabs(u[0] - v[0]) < epsilon &&
        fabs(u[1] - v[1]) < epsilon &&
        fabs(u[2] - v[2]) < epsilon) 
    {
        return GL_TRUE;
    }
    return GL_FALSE;
}

/* glmWeldVectors: eliminate (weld) vectors that are within an
 * epsilon of each other.
 *
 * vectors     - array of GLfloat[3]'s to be welded
 * numvectors - number of GLfloat[3]'s in vectors
 * epsilon     - maximum difference between vectors 
 *
 */
double*
glmWeldVectors(double* vectors, GLuint* numvectors, GLfloat epsilon)
{
    double* copies;
    GLuint   copied;
    GLuint   i, j;
    
    copies = (double*)malloc(sizeof(double) * 3 * (*numvectors + 1));
    memcpy(copies, vectors, (sizeof(double) * 3 * (*numvectors + 1)));
    
    copied = 0;
    for (i = 0; i < *numvectors; i++) {
        for (j = 0; j < copied; j++) {
            if (glmEqual(&vectors[3 * i], &copies[3 * j], epsilon)) {
                goto duplicate;
            }
        }
        
        /* must not be any duplicates -- add to the copies array */
        copies[3 * copied + 0] = vectors[3 * i + 0];
        copies[3 * copied + 1] = vectors[3 * i + 1];
        copies[3 * copied + 2] = vectors[3 * i + 2];
        j = copied;             /* pass this along for below */
        copied++;
        
duplicate:
/* set the first component of this vector to point at the correct
        index into the new copies array */
        vectors[3 * i + 0] = (GLfloat)j;
    }
    
    *numvectors = copied-1;
    return copies;
}





/* glmReverseWinding: Reverse the polygon winding for all polygons in
 * this model.   Default winding is counter-clockwise.  Also changes
 * the direction of the normals.
 */
void Model::reverseWinding(void)
{
    GLuint i, swap;
    
    for (i = 0; i < numtriangles; i++) {
        swap = triangles[i].vindices[0];
        triangles[i].vindices[0] = triangles[i].vindices[2];
        triangles[i].vindices[2] = swap;
        
/*        if (normals) {
            swap = triangles[i].nindices[0];
            triangles[i].nindices[0] = triangles[i].nindices[2];
            triangles[i].nindices[2] = swap;
        }
		*/
        
        if (numtexcoords) {
            swap = triangles[i].tindices[0];
            triangles[i].tindices[0] = triangles[i].tindices[2];
            triangles[i].tindices[2] = swap;
        }
    }
    
    /* reverse facet normals */
    for (i = 0; i < numfacetnorms; i++) {
        facetnorms[3 * i + 0] = -facetnorms[3 * i + 0];
        facetnorms[3 * i + 1] = -facetnorms[3 * i + 1];
        facetnorms[3 * i + 2] = -facetnorms[3 * i + 2];
    }
    
    /* reverse vertex normals */
    for (i = 0; i < numvertices; i++) {
        normals[3 * i + 0] = -normals[3 * i + 0];
        normals[3 * i + 1] = -normals[3 * i + 1];
        normals[3 * i + 2] = -normals[3 * i + 2];
    }
}


/* Generates facet normals for a model (by taking the
 * cross product of the two vectors derived from the sides of each
 * triangle).  Assumes a counter-clockwise winding.
 */
void Model::computeFacetNormals(void)
{
    GLuint  i;
    GLfloat u[3];
    GLfloat v[3];
    
    assert(vertices);
    
    /* clobber any old facetnormals */
    if (facetnorms)
        free(facetnorms);
    
    /* allocate memory for the new facet normals */
    facetnorms = (GLfloat*)malloc(sizeof(GLfloat) *
                       3 * (numtriangles + 1));
	if (facetnorms==NULL) {
		danceInterp::OutputMessage("Out of memory computing facet normals");
		return;
	}
    numfacetnorms = maxNumFacetNorms = numtriangles;
	

    for (i = 0; i < numtriangles; i++) {
        triangles[i].findex = i;
        
        u[0] = (float) (vertices[3 * triangles[i].vindices[1] + 0] -
            vertices[3 * triangles[i].vindices[0] + 0]);
        u[1] = (float) (vertices[3 * triangles[i].vindices[1] + 1] -
            vertices[3 * triangles[i].vindices[0] + 1]);
        u[2] = (float) (vertices[3 * triangles[i].vindices[1] + 2] -
            vertices[3 * triangles[i].vindices[0] + 2]);
        
        v[0] = (float) (vertices[3 * triangles[i].vindices[2] + 0] -
            vertices[3 * triangles[i].vindices[0] + 0]);
        v[1] = (float) (vertices[3 * triangles[i].vindices[2] + 1] -
            vertices[3 * triangles[i].vindices[0] + 1]);
        v[2] = (float) (vertices[3 * triangles[i].vindices[2] + 2] -
            vertices[3 * triangles[i].vindices[0] + 2]);
        
        glmCross(u, v, &facetnorms[3 * i]);
        glmNormalize(&facetnorms[3 * i]);
    }
}


#if 0
/* glmVertexNormals: Generates smooth vertex normals for a model.
 * First builds a list of all the triangles each vertex is in.   Then
 * loops through each vertex in the the list averaging all the facet
 * normals of the triangles each vertex is in.   Finally, sets the
 * normal index in the triangle for the vertex to the generated smooth
 * normal.   If the dot product of a facet normal and the facet normal
 * associated with the first triangle in the list of triangles the
 * current vertex is in is greater than the cosine of the angle
 * parameter to the function, that facet normal is not added into the
 * average normal calculation and the corresponding vertex is given
 * the facet normal.  This tends to preserve hard edges.  The angle to
 * use depends on the model, but 90 degrees is usually a good start.
 *
 * model - initialized Model structure
 * angle - maximum angle (in degrees) to smooth across
 */
GLvoid
glmVertexNormals(Model* model, GLfloat angle)
{
    GLMnode*    node;
    GLMnode*    tail;
    GLMnode** members;
    GLfloat*    normals;
    GLuint  numnormals;
    GLfloat average[3];
    GLfloat dot, cos_angle;
    GLuint  i, avg;
    
    assert(model);
    assert(model->facetnorms);
    
    /* calculate the cosine of the angle (in degrees) */
    cos_angle = (float) cos( angle * M_PI / 180.0f);
    
    /* nuke any previous normals */
	if (model->normals) 
        FREE_CLEAR(model->normals);
    
    /* allocate space for new normals */
    model->normals = (GLfloat*)malloc(sizeof(GLfloat)* 3* model->maxNumVertices);
    
    /* allocate a structure that will hold a linked list of triangle
    indices for each vertex */
    members = (GLMnode**)malloc(sizeof(GLMnode*) * model->numvertices );
    for (i = 0; i < model->numvertices; i++)
        members[i] = NULL;
    
    /* for every triangle, create a node for each vertex in it */
    for (i = 0; i < model->numtriangles; i++) {
        node = (GLMnode*)malloc(sizeof(GLMnode));
        node->index = i;
        node->next  = members[T(i).vindices[0]];
        members[T(i).vindices[0]] = node;
        
        node = (GLMnode*)malloc(sizeof(GLMnode));
        node->index = i;
        node->next  = members[T(i).vindices[1]];
        members[T(i).vindices[1]] = node;
        
        node = (GLMnode*)malloc(sizeof(GLMnode));
        node->index = i;
        node->next  = members[T(i).vindices[2]];
        members[T(i).vindices[2]] = node;
    }
    
    /* calculate the average normal for each vertex */
    numnormals = 0;
    for (i = 0; i < model->numvertices; i++) {
    /* calculate an average normal for this vertex by averaging the
        facet normal of every triangle this vertex is in */
        node = members[i];
        if (!node)
            danceInterp::OutputMessage( "glmVertexNormals(): vertex w/o a triangle\n");
        average[0] = 0.0; average[1] = 0.0; average[2] = 0.0;
        avg = 0;
        while (node) {
        /* only average if the dot product of the angle between the two
        facet normals is greater than the cosine of the threshold
        angle -- or, said another way, the angle between the two
            facet normals is less than (or equal to) the threshold angle */
            dot = glmDot(&model->facetnorms[3 * T(node->index).findex],
                &model->facetnorms[3 * T(members[i]->index).findex]);
            if (dot > cos_angle) {
                node->averaged = GL_TRUE;
                average[0] += model->facetnorms[3 * T(node->index).findex + 0];
                average[1] += model->facetnorms[3 * T(node->index).findex + 1];
                average[2] += model->facetnorms[3 * T(node->index).findex + 2];
                avg = 1;            /* we averaged at least one normal! */
            } else {
                node->averaged = GL_FALSE;
            }
            node = node->next;
        }
        
        if (avg) {
            /* normalize the averaged normal */
            glmNormalize(average);
            
            /* add the normal to the vertex normals list */
            model->normals[3 * numnormals + 0] = average[0];
            model->normals[3 * numnormals + 1] = average[1];
            model->normals[3 * numnormals + 2] = average[2];
            avg = numnormals;
            numnormals++;
        }
        
        /* set the normal of this vertex in each triangle it is in */
        node = members[i];
        while (node) {
            if (node->averaged) {
                /* if this node was averaged, use the average normal */
                if (T(node->index).vindices[0] == i)
                    T(node->index).nindices[0] = avg;
                else if (T(node->index).vindices[1] == i)
                    T(node->index).nindices[1] = avg;
                else if (T(node->index).vindices[2] == i)
                    T(node->index).nindices[2] = avg;
            } else {
                /* if this node wasn't averaged, use the facet normal */
                model->normals[3 * numnormals + 0] = 
                    model->facetnorms[3 * T(node->index).findex + 0];
                model->normals[3 * numnormals + 1] = 
                    model->facetnorms[3 * T(node->index).findex + 1];
                model->normals[3 * numnormals + 2] = 
                    model->facetnorms[3 * T(node->index).findex + 2];
                if (T(node->index).vindices[0] == i)
                    T(node->index).nindices[0] = numnormals;
                else if (T(node->index).vindices[1] == i)
                    T(node->index).nindices[1] = numnormals;
                else if (T(node->index).vindices[2] == i)
                    T(node->index).nindices[2] = numnormals;
                numnormals++;
            }
            node = node->next;
        }
    }
    
    model->numnormals = numnormals;
    
    /* free the member information */
    for (i = 0; i < model->numvertices; i++) {
        node = members[i];
        while (node) {
            tail = node;
            node = node->next;
            free(tail);
        }
    }
    free(members);
    
    /* pack the normals array (we previously allocated the maximum
    number of normals that could possibly be created (numtriangles *
    3), so get rid of some of them (usually alot unless none of the
    facet normals were averaged)) */
    normals = model->normals;
    model->normals = (GLfloat*)malloc(sizeof(GLfloat)* 3* (model->numnormals+1));
	model->maxNumNormals = model->numnormals+1;

	memcpy(model->normals, normals, sizeof(GLfloat)*model->numnormals*3);

	free(normals);
}

#endif

/* glmLinearTexture: Generates texture coordinates according to a
 * linear projection of the texture map.  It generates these by
 * linearly mapping the vertices onto a square.
 *
 * model - pointer to initialized Model structure
 */
GLvoid
glmLinearTexture(Model* model)
{
    GLMgroup *group;
    GLuint i;
	double x, spanx, spany, spanz, scalefactor;

    assert(model);
    
    if (model->texcoords)
        free(model->texcoords);
    model->numtexcoords = model->numvertices;
    model->texcoords=(GLfloat*)malloc(sizeof(GLfloat)*2*(model->numtexcoords+1));
	model->maxNumTexCoords = model->numtexcoords+1;
    
    BoundingBox  *bb=model->calcBoundingBox();
	//model->getDimensions(dimensions);
    spanx=bb->xMax-bb->xMin;
	spany=bb->yMax-bb->yMin;
	spanz=bb->zMax-bb->zMin;
	scalefactor = 1.0 / MAX(MAX(spanx, spany), spanz);
    
	int offset=0;

	if (spanx>=spany || spanx>=spanz) {
		for(i = 0; i < model->numvertices; i++) {
			x = (model->vertices[3 * i + 0] - bb->xMin) * scalefactor;
	        model->texcoords[2 * i + 0] = (float)x;
	    }
		offset++;
	}

	if (spany>spanx || spany>spanz) {
		for(i = 0; i < model->numvertices; i++) {
			x = (model->vertices[3 * i + 1] - bb->yMin) * scalefactor;
	        model->texcoords[2 * i + offset] = (float)x;
	    }
		offset++;
	}

	if (offset<=1) {
		for(i = 0; i < model->numvertices; i++) {
			x = (model->vertices[3 * i + 2] - bb->zMin) * scalefactor;
	        model->texcoords[2 * i + offset] = (float)x;
	    }
	}

  
    /* put texture coordinate indices in all the triangles */
    group = model->groups;
    while(group) {
        for(i = 0; i < group->numtriangles; i++) {
            T(group->triangles[i]).tindices[0] = T(group->triangles[i]).vindices[0];
            T(group->triangles[i]).tindices[1] = T(group->triangles[i]).vindices[1];
            T(group->triangles[i]).tindices[2] = T(group->triangles[i]).vindices[2];
        }    
        group = group->next;
    }
    
#if 0
    danceInterp::OutputMessage("glmLinearTexture(): generated %d linear texture coordinates\n",
        model->numtexcoords);
#endif
}

/* glmSpheremapTexture: Generates texture coordinates according to a
 * spherical projection of the texture map.  Sometimes referred to as
 * spheremap, or reflection map texture coordinates.  It generates
 * these by using the normal to calculate where that vertex would map
 * onto a sphere.  Since it is impossible to map something flat
 * perfectly onto something spherical, there is distortion at the
 * poles.  This particular implementation causes the poles along the X
 * axis to be distorted.
 *
 * model - pointer to initialized Model structure
 */
GLvoid
glmSpheremapTexture(Model* model)
{
    GLMgroup* group;
    GLfloat theta, phi, rho, x, y, z, r;
    GLuint i;
    
    assert(model);
    assert(model->normals);
    
    if (model->texcoords)
        free(model->texcoords);
    model->numtexcoords = model->numvertices;
    model->texcoords=(GLfloat*)malloc(sizeof(GLfloat)*2*model->numtexcoords);
	model->maxNumTexCoords = model->numtexcoords;
    
    for (i = 0; i < model->numvertices; i++) {
        z = model->normals[3 * i + 0];  /* re-arrange for pole distortion */
        y = model->normals[3 * i + 1];
        x = model->normals[3 * i + 2];
        r = (float) sqrt((x * x) + (y * y));
        rho = (float) sqrt((r * r) + (z * z));
        
        if(r == 0.0) {
            theta = 0.0;
            phi = 0.0;
        } else {
            if(z == 0.0)
                phi = 3.14159265f / 2.0f;
            else
                phi = (float) acos(z / rho);
            
            if(y == 0.0)
                theta = 3.141592365f / 2.0f;
            else
                theta = (float) asin(y / r) + (3.14159265f / 2.0f);
        }
        
        model->texcoords[2 * i + 0] = theta / 3.14159265f;
        model->texcoords[2 * i + 1] = phi / 3.14159265f;
    }
    
    /* go through and put texcoord indices in all the triangles */
    group = model->groups;
    while(group) {
        for (i = 0; i < group->numtriangles; i++) {
            T(group->triangles[i]).tindices[0] = T(group->triangles[i]).vindices[0];
            T(group->triangles[i]).tindices[1] = T(group->triangles[i]).vindices[1];
            T(group->triangles[i]).tindices[2] = T(group->triangles[i]).vindices[2];
        }
        group = group->next;
    }
}

/* ~Model: Deletes a Model structure.
 */

void CopyGroup(GLMgroup *t, GLMgroup *s)
{
	int sname = strlen(s->name) ;
	if( sname > 0 )
	{
		t->name = new char[sname+1] ;
		if( t->name == NULL ) memError("CopyGroup") ;
		strcpy(t->name, s->name) ;
	}
	if( s->numtriangles > 0 )
	{
		t->triangles = new GLuint[s->numtriangles] ;
		if( t->triangles == NULL ) memError("CopyGroup") ;
		memcpy(t->triangles, s->triangles, sizeof(GLuint)*s->numtriangles) ;
	}
	else
		t->triangles = NULL ;
	t->numtriangles = s->numtriangles ;

	t->material = s->material ;
	t->next = NULL ;
	
}

//** ParialCopy:
//** Copies only vertices, normals, texures. For the rest copies the pointers!!
//** Use only in specific case, such as blenshapes
int Model::PartialCopy(Model *src)
{
	this->pathname = strdup(src->pathname) ;
	if( src->mtllibname)  this->mtllibname    =  strdup(src->mtllibname) ; //***
	this->UseShaders = src->UseShaders ;

	if( src->GetNumVertices() > 0 )
	{
		this->vertices = (double *) malloc(src->numvertices *3*sizeof(double));
		if( this->vertices == NULL )
		{
			danceInterp::OutputMessage("Model: Error: cannot allocate memory for vertices.") ;
			return DANCE_ERROR;
		}
		this->numvertices  = this->maxNumVertices = src->numvertices ;
		memcpy(this->vertices,src->vertices,this->numvertices*3*sizeof(double)) ;
	}
	if( src->GetNumNormals() > 0 )
	{
		normals = (GLfloat *) malloc(src->numvertices*3*sizeof(GLfloat));
		if( normals == NULL )
		{
			danceInterp::OutputMessage("Model: Error: cannot allocate memory for normals.") ;
			return DANCE_ERROR;
		}
		memcpy(this->normals,src->normals,this->numvertices*3*sizeof(GLfloat)) ;
	}
	if( src->GetNumTexCoords() > 0 )
	{

		this->texcoords = (GLfloat *) malloc(src->numtexcoords*2*sizeof(GLfloat));
		if( this->texcoords == NULL )
		{
			danceInterp::OutputMessage("Model: Error: cannot allocate memory for texture coordinates.") ;
			return DANCE_ERROR ;
		}
		this->numtexcoords   = this->maxNumTexCoords = src->numtexcoords;
		memcpy(this->texcoords,src->texcoords,this->numtexcoords*2*sizeof(GLfloat)) ;
	}

	if( src->numfacetnorms > 0 )
	{
		this->facetnorms = (GLfloat *) malloc(src->numfacetnorms*3*sizeof(GLfloat));
		if( this->facetnorms == NULL )
		{
			danceInterp::OutputMessage("Model: Error: cannot allocate memory for facet normals.") ;
			return DANCE_ERROR;
		}
		
		this->numfacetnorms = this->maxNumFacetNorms = src->numfacetnorms;
		memcpy(this->facetnorms,src->facetnorms,this->numfacetnorms*3*sizeof(GLfloat)) ;
	}
    
	// /copy the triangles
    this->numtriangles  = src->numtriangles;
    //this->triangles       =  src->triangles;
	if( this->numtriangles > 0 )
	{
		this->triangles = new GLMtriangle[src->numtriangles] ;
		if( this->triangles == NULL ) memError("PartialCopy") ;
		memcpy(this->triangles,src->triangles, sizeof(GLMtriangle)*src->numtriangles) ;
	}


	this->maxNumTriangles = src->maxNumTriangles;

    this->numgroups       =  src->numgroups ;
   // this->groups      =  src->groups;

	
	// copy the groups
	if( src->groups ) this->groups = new GLMgroup ;
	if( src->groups == NULL ) return memError("PartialCopy") ;

	GLMgroup *tgroup = this->groups ;
	GLMgroup *sgroup = src->groups ;
	CopyGroup(tgroup, sgroup) ;
	sgroup = sgroup->next ;
	while(sgroup) {
		tgroup->next = new GLMgroup ;
		if( tgroup->next == NULL ) return memError("PartialCopy") ;
		tgroup = tgroup->next ;
		CopyGroup(tgroup, sgroup) ;
		sgroup = sgroup->next ;
    }

    this->maxNumGroups = src->maxNumGroups;
	
	this->position[0]   = src->position[0];
    this->position[1]   = src->position[1];
    this->position[2]   = src->position[2];

	// copy stuff from geometry
	double transMatrix[4][4];
	src->getTransMatrix(transMatrix) ;
	this->setTransMatrix(transMatrix) ;
	
	m_tx->setValue(src->m_tx->getValue());
	m_ty->setValue(src->m_ty->getValue());
	m_tz->setValue(src->m_tz->getValue());
	m_rx->setValue(src->m_rx->getValue());
	m_ry->setValue(src->m_ry->getValue());
	m_rz->setValue(src->m_rz->getValue());
	m_sx->setValue(src->m_sx->getValue());
	m_sy->setValue(src->m_sy->getValue());
	m_sz->setValue(src->m_sz->getValue());
	VecCopy(m_rotationCenter, src->m_rotationCenter) ;
	
	return DANCE_OK ;
}

void Model::copyVertices(double* v, int numVertices)
{
	if (this->vertices != NULL)
	{
		delete [] vertices;
	}

	this->vertices = new double[3 * numVertices];
	memcpy(this->vertices, v, sizeof(double) * 3 * numVertices);
	this->numvertices = numVertices;
}

void Model::copyNormals(GLfloat* n, int numNormals)
{
	if (this->normals != NULL)
	{
		delete [] normals;
	}

	this->normals = new GLfloat[3 * numNormals];
	memcpy(this->normals, n, sizeof(GLfloat) * 3 * numNormals);
}

void Model::copyFaceNormals(GLfloat* f, int numFaces)
{
	if (this->facetnorms != NULL)
	{
		delete [] facetnorms;
	}

	this->facetnorms = new GLfloat[3 * numFaces];
	memcpy(this->facetnorms, f, sizeof(GLfloat) * 3 * numFaces);
	this->numfacetnorms = numFaces;
}


void Model::output(int mode)
{
	int i1 ;

	if (!m_showSelf) return;


    GLuint i;
    GLMgroup* group;
    GLMtriangle* triangle;

	glPushAttrib(GL_ENABLE_BIT);
	glEnable(GL_NORMALIZE);

	glPushMatrix();
	if (useTransMatrix())
		glMultMatrixd(&m_transMatrix[0][0]);

	

    group = groups;
    while (group)
	{
		bool doNotRender = false ;
		// ejem...
		if (group->numtriangles<=0) {
			group=group->next;
			continue;
		}
		//danceInterp::OutputMessage("drawing group %s numtriangles %d material %s", group->name,
		//	group->numtriangles, group->material->getMaterialName()) ;
		bool texturing = false ;
		
		bool shadows = false;
		if( mode & LDISPLAY_COMPUTE_SHADOW_MAP )
		{
			setUpShadowMapPass1() ;
			shadows = true ;
		}
		else if (mode & LDISPLAY_USE_SHADOW_MAP)
		{
			setUpShadowMapPass3() ;
			shadows = true ;
		}
		else if( mode & LDISPLAY_SHADOW_MAP_PASS4) 
		{
			setUpShadowMapPass4() ;
			group->material->setOpenGLMaterial(dance::shadowAlpha);
		}
		else
		{
			group->material->setOpenGLMaterial();
		}
		if( !shadows )
		{
			texturing= group->material->has_texture();
			if (texturing && (texcoords==NULL)) 
			{
				glmLinearTexture(this);
				glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE) ;
				glDepthMask(GL_TRUE) ;
			}
			/** -------------------------*/
			if( strstr(group->material->getMaterialName(), "xxxxxx") != NULL )
			{
				danceInterp::OutputMessage("found transparency map") ;
				glEnable(GL_BLEND) ;
				glDepthMask(GL_FALSE) ;
				glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA) ;
				glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE) ;
			}
			else if(strstr(group->material->getMaterialName(), "lashes") != NULL )
			{
				doNotRender = true ;
				danceInterp::OutputMessage("Skipping group %s", group->name) ;
			}
			else if(strstr(group->material->getMaterialName(), "brow") != NULL )
			{
				doNotRender = true ;
				danceInterp::OutputMessage("Skipping group %s", group->name) ;
			}
			/** ------------------- **/
		}
		
		if( doNotRender == false )
		{
		if (m_renderType==GEOMETRY_MESH) {
			for (i = 0; i < group->numtriangles; i++) {
				glBegin(GL_LINE_LOOP);
				triangle = &triangles[(group->triangles[i])];
	           
				i1= 3 * triangle->vindices[0];
				glNormal3fv(&normals[i1]);
				glVertex3dv(&vertices[i1]);

				i1= 3 * triangle->vindices[1];
				glNormal3fv(&normals[i1]);
				glVertex3dv(&vertices[i1]);
	            
				i1= 3 * triangle->vindices[2];
				glNormal3fv(&normals[i1]);
				glVertex3dv(&vertices[i1]);
				glEnd();
			}
		} else if (m_renderType==GEOMETRY_SOLID) {
			glBegin(GL_TRIANGLES);
			for (i = 0; i < group->numtriangles; i++) {
				triangle = &triangles[(group->triangles[i])];

				i1= 3 * triangle->vindices[0];
				glNormal3fv(&normals[i1]);
				if (texturing) glTexCoord2fv(&texcoords[2 * triangle->tindices[0]]);
				glVertex3dv(&vertices[i1]);
	            
				i1= 3 * triangle->vindices[1];
				glNormal3fv(&normals[i1]);
				if (texturing) glTexCoord2fv(&texcoords[2 * triangle->tindices[1]]);
				glVertex3dv(&vertices[i1]);
	            
				i1= 3 * triangle->vindices[2];
				glNormal3fv(&normals[i1]);
				if (texturing) glTexCoord2fv(&texcoords[2 * triangle->tindices[2]]);
				glVertex3dv(&vertices[i1]);
			}
			glEnd();
		} else {
			glBegin(GL_POINTS);
			for (i = 0; i < group->numtriangles; i++) {
				triangle = &triangles[(group->triangles[i])];
				glVertex3dv(&vertices[3 * triangle->vindices[0]]);
				glVertex3dv(&vertices[3 * triangle->vindices[1]]);
				glVertex3dv(&vertices[3 * triangle->vindices[2]]);
			}
			glEnd();

		}
		}
		group = group->next;

	}
	glDepthMask(GL_TRUE) ;
	if (this->isShowNormals())
		outputNormals();

	if( mode & LDISPLAY_COMPUTE_SHADOW_MAP) 
	{
		cleanUpAfterShadowMapPass1() ;
	}

	glPopMatrix() ;
	glPopAttrib();
}

void Model::outputNormals()
{
	if (this->facetnorms == NULL)
		return;

	glPushAttrib(GL_COLOR_BUFFER_BIT | GL_LIGHTING_BIT);
	glDisable(GL_LIGHTING);
	glColor3f(1.0, 0.0, 0.0);

	GLMgroup* group = groups;
	while (group)
	{
		for (unsigned int i = 0; i < group->numtriangles; i++)
		{
			int triangleNum = group->triangles[i];
			GLMtriangle* triangle = &triangles[triangleNum];
			// show the normals
			// calculate the face center
			Vector faceCenter = {0.0, 0.0, 0.0};
			for (int x = 0; x < 3; x++)
			{
				int index = 3 * triangle->vindices[x];
				faceCenter[0] += vertices[index];
				faceCenter[1] += vertices[index + 1];
				faceCenter[2] += vertices[index + 2];
			}
			VecScale(faceCenter, 1.0 / 3.0);

			// get the face normals
			Vector faceNormal = { this->facetnorms[triangleNum * 3], this->facetnorms[triangleNum * 3 + 1], this->facetnorms[triangleNum * 3 + 2] };
			VecAdd(faceNormal, faceNormal, faceCenter);

			glColor3f(1.0, 0.0, 0.0);
			glBegin(GL_LINES);
			glVertex3dv(faceCenter);
			glVertex3dv(faceNormal);
			glEnd();
		}
		group = group->next;
	}

	glPopAttrib();
}


// eliminate (weld) vectors that are within an epsilon of each other.
void Model::weld(GLfloat epsilon)
{
    double* vectors;
    double* copies;
    GLuint   numvectors;
    GLuint   i;
    
    /* vertices */
    numvectors = numvertices;
    vectors  = vertices;
    copies = glmWeldVectors(vectors, &numvectors, epsilon);
    
    for (i = 0; i < numtriangles; i++) {
        triangles[i].vindices[0] = (GLuint)vectors[3 * triangles[i].vindices[0] + 0];
        triangles[i].vindices[1] = (GLuint)vectors[3 * triangles[i].vindices[1] + 0];
        triangles[i].vindices[2] = (GLuint)vectors[3 * triangles[i].vindices[2] + 0];
    }
    
    /* free space for old vertices */
    free(vectors);
    
    /* allocate space for the new vertices */
    numvertices = numvectors;
    vertices = (double*)malloc(sizeof(double)*3*(numvertices + 1));
    maxNumVertices = (numvertices + 1);

    /* copy the optimized vertices into the actual vertex list */
    memcpy(vertices, copies, 3*sizeof(double)*numvertices);
    
    free(copies);
}


void Model::setMutable(bool val)
{
	m_isMutable = val;
}

bool Model::isMutable()
{
	return m_isMutable;
}


void Model::render(int argc, char ** argv, std::ofstream & file)
{
	GLMgroup* group;
	GLMtriangle* triangle;

	if (argc > 0 && strcmp(argv[0],"povray") == 0)
	{
#ifdef _DEBUG
		file << "/* Model: \n";
		write_properties(file);
		file << "*/\n\n";
#endif
		if (!this->isMutable())
		{
			// HACK ! REMOVE ME!

			if (strcmp(filename_name(this->pathname), "sphere.3ds") == 0)
			{
				std::ofstream* objfile = dance::AllRenderers->getObjectFileStream();
				*objfile << "#declare " << this->getName() << " = \n";
				*objfile << "sphere {\n  <0, 0, 0>, 1\n";
				*objfile  << "\n  texture { "; 
				*objfile  << groups->material->getSafeMaterialName();
				// 'default' is a reserved word in povray
				if (!strcmp("default", groups->material->getSafeMaterialName())) *objfile << "_";
				*objfile << "}\n";
				*objfile << "}\n";
			}
			else
			{
				std::ofstream* objfile = dance::AllRenderers->getObjectFileStream();
				*objfile << "#declare " << this->getName() << " = \n";
							*objfile  << "mesh {\n";
				group = groups;
				bool texturing= group->material->has_texture() && (texcoords!=NULL);
				while (group)
				{
					for (unsigned int i = 0; i < group->numtriangles; i++) {
						triangle = &triangles[group->triangles[i]];

						*objfile << "  smooth_triangle {\n";
						for (int j=0; j<3; j++) {
							*objfile  << "    ";
							write_vector(*objfile , &vertices[3 * triangle->vindices[j]], 3, VPOVRAY);
							*objfile  << ", ";
							write_vector(*objfile , &normals[3 * triangle->vindices[j]], 3, VPOVRAY);
							if (j!=2) *objfile << ",";
							*objfile  << "\n";
						}
						if (texturing) {
							*objfile  << "   uv_vectors ";
							for (int j=0; j<3; j++) {
								write_vector(*objfile , &texcoords[2 * triangle->tindices[j]], 2, VPOVRAY);
								if (j!=2) *objfile << ", ";
							}
						}
						*objfile  << " }\n";
					}
					group = group->next;
				}

				*objfile  << "\n  texture { "; 
				if (texturing) *objfile << "uv_mapping ";
				*objfile  << groups->material->getSafeMaterialName();
				// 'default' is a reserved word in povray
				if (!strcmp("default", groups->material->getSafeMaterialName())) *objfile << "_";
				*objfile  << " }\n";
				*objfile  << "}\n";
			}

			file << "\nobject {" << this->getName() << "\n";
			file << "matrix\n  <";
			for (int j=0; j<4; j++) {
				for (int i=0; i<3; i++) 
					file << m_transMatrix[j][i] << ((j==3 && i==2) ? ">" : ",");
				file << "\n";
			}
			file << "#ifdef (SETMATRIX2)\n";
			file << "transform SETMATRIX2\n";
			file << "#end\n";
			file << "#ifdef (SETMATRIX)\n";
			file << "transform SETMATRIX\n";
			file << "#end\n";

			file << "}\n\n";
		}
		else 
		{
			file << "mesh {\n";
			group = groups;
			bool texturing= group->material->has_texture() && (texcoords!=NULL);
			while (group)
			{
				for (unsigned int i = 0; i < group->numtriangles; i++) {
					triangle = &triangles[group->triangles[i]];

					file << "  smooth_triangle {\n";
					for (int j=0; j<3; j++) {
						file << "    ";
						write_vector(file, &vertices[3 * triangle->vindices[j]], 3, VPOVRAY);
						file << ", ";
						write_vector(file, &normals[3 * triangle->vindices[j]], 3, VPOVRAY);
						if (j!=2) file << ",";
						file << "\n";
					}
					if (texturing) {
						file << "   uv_vectors ";
						for (int j=0; j<3; j++) {
							write_vector(file, &texcoords[2 * triangle->tindices[j]], 2, VPOVRAY);
							if (j!=2) file << ", ";
						}
					}
					file << " }\n";
				}
			group = group->next;
			}

			file << "\n  texture { "; 
			if (texturing) file << "uv_mapping ";
			file << groups->material->getSafeMaterialName();
			// 'default' is a reserved word in povray
			if (!strcmp("default", groups->material->getMaterialName())) file << "_";
			file << " }\n";

			file << "  matrix\n  <";
			for (int j=0; j<4; j++) {
				for (int i=0; i<3; i++) 
					file << m_transMatrix[j][i] << ((j==3 && i==2) ? ">" : ",");
				file << "\n";
			}
			file << "#ifdef (SETMATRIX2)\n";
			file << "transform SETMATRIX2\n";
			file << "#end\n";
			file << "#ifdef (SETMATRIX)\n";
			file << "transform SETMATRIX\n";
			file << "#end\n";

			file << "}\n\n";
		}
	}
}


int Model::addVertex(double x, double y, double z, float nx, float ny, float nz) {
	int i;
	if (maxNumVertices==0) {
		normals = (GLfloat*)malloc(sizeof(GLfloat) * 3 * CHUNK_SIZE_ARRAY);
		if (normals == NULL) {
			danceInterp::OutputMessage("Out of memory");
			return DANCE_ERROR;
		}

		vertices = (double*)malloc(sizeof(double) * 3 * CHUNK_SIZE_ARRAY);
		if (vertices == NULL) {
			danceInterp::OutputMessage("Out of memory");
			FREE_CLEAR(normals);
			return DANCE_ERROR;
		}
		maxNumVertices = CHUNK_SIZE_ARRAY;
	} else 
		if (numvertices+1>=maxNumVertices)
			enlargeVectors();


	i=numvertices*3;
	vertices[i] = x;
	vertices[i+1] = y;
	vertices[i+2] = z;

	normals[i] = nx;
	normals[i+1] = ny;
	normals[i+2] = nz;

	numvertices++;

	return DANCE_OK;
}

int Model::enlargeVectors(void) {
	GLfloat *p;
	double *q;
	
	// enlarge the normals array
	p = (GLfloat *)realloc (normals, sizeof(GLfloat) * 3 * (maxNumVertices+CHUNK_SIZE_ARRAY));
	if (p==NULL) {
		danceInterp::OutputMessage("Out of memory");
		return DANCE_ERROR;
	}
	normals = p;

	q = (double *)realloc (vertices, sizeof(double) * 3 * (maxNumVertices+CHUNK_SIZE_ARRAY));
	if (q==NULL) {
		danceInterp::OutputMessage("Out of memory");
		return DANCE_ERROR;
	}
	vertices = q;
	maxNumVertices += CHUNK_SIZE_ARRAY;

	return DANCE_OK;
}


/*
int	Model::addNormal(double x, double y, double z) {
	if (maxNumNormals==0) {
		normals = (GLfloat*)malloc(sizeof(GLfloat) * 3 * CHUNK_SIZE_ARRAY);
		if (normals == NULL) {
			danceInterp::OutputMessage("Out of memory");
			return DANCE_ERROR;
		}
		maxNumNormals = CHUNK_SIZE_ARRAY;
	} else 
		if (numnormals+1 >= maxNumNormals && enlargeVectors()!=DANCE_OK) 
			return DANCE_ERROR;

	normals[this->numnormals*3] = (GLfloat)x;
	normals[this->numnormals*3+1] = (GLfloat)y;
	normals[this->numnormals*3+2] = (GLfloat)z;

	numnormals++;
	return DANCE_OK;
}
*/



int Model::addFace(void) {
	int nextID;

	nextID=this->numtriangles;
	if (addFace(nextID) == DANCE_OK)
		return nextID;
	else 
		return -1;
}


int Model::addFace(int index) {
	
	if (maxNumTriangles==0) {
		triangles = (GLMtriangle *)malloc(sizeof(GLMtriangle) *MAX(CHUNK_SIZE_ARRAY, index+1));
		if (triangles == NULL) {
			danceInterp::OutputMessage("Out of memory");
			return DANCE_ERROR;
		}
		maxNumTriangles = MAX(CHUNK_SIZE_ARRAY, index+1);
	} else 
		if (index >= maxNumTriangles) {
			GLMtriangle *p;

			p = (GLMtriangle *)realloc (triangles, sizeof(GLMtriangle) * (MAX(maxNumTriangles, index+1)+CHUNK_SIZE_ARRAY));
			if (p==NULL) {
				danceInterp::OutputMessage("Out of memory");
				return DANCE_ERROR;
			}
			triangles = p;
			maxNumTriangles = (MAX(maxNumTriangles, index+1)+CHUNK_SIZE_ARRAY);
		}

	numtriangles++;	
	return DANCE_OK;
}


// adds the texture coordinates into the database
int Model::addTexCoord(float x, float y) {
	if (maxNumTexCoords==0) {
		texcoords = (GLfloat*)malloc(sizeof(GLfloat) * 2 * CHUNK_SIZE_ARRAY);
		if (texcoords == NULL) {
			danceInterp::OutputMessage("Out of memory");
			return DANCE_ERROR;
		}
		maxNumTexCoords = CHUNK_SIZE_ARRAY;
	} else 
		if (numtexcoords+1 >= maxNumTexCoords) {
			GLfloat *p;

			p = (GLfloat *)realloc (texcoords, sizeof(GLfloat) * 2 * (maxNumTexCoords+CHUNK_SIZE_ARRAY));
			if (p==NULL) {
				danceInterp::OutputMessage("Out of memory");
				return DANCE_ERROR;
			}
			texcoords = p;
			maxNumTexCoords += CHUNK_SIZE_ARRAY;
		}

	texcoords[numtexcoords*2] = x;
	texcoords[numtexcoords*2+1] = y;

	numtexcoords++;

	return DANCE_OK;
}


/// Polygon index, indexes of coordinates
int Model::addTexCoordsToFace(int index, int *coordIndices) {

	triangles[index].tindices[0] = coordIndices[0];
	triangles[index].tindices[1] = coordIndices[1];
	triangles[index].tindices[2] = coordIndices[2];
	return DANCE_OK;
}


/// Polygon index, number of vertex, indexes of coordinates

int Model::addCoordsToFace(int index, int *coordIndices) {

	triangles[index].findex=-1;
	for (int i=0; i<3; i++) {
		triangles[index].vindices[i] = coordIndices[i];
		triangles[index].tindices[i] = -1;
	}
	return DANCE_OK;
}




// Sets the same materials for all the groups in the model
void Model::setMaterial(Material* m) {
	GLMgroup* group;

	group=this->groups;
	while (group!=NULL) {
		group->material=m;
		group=group->next;
	}
}

// Returns the material of the first group
Material* Model::getMaterial() {
	if (groups) 
		return groups->material;
	else 
		return NULL;
}

// Sets material for the given group (0 based ids)
void Model::setGroupMaterial(int group, Material *m) {
	GLMgroup* pgroup;
	int i;

	pgroup=this->groups;
	i=0;
	while (pgroup!=NULL && i!=group) {
		pgroup=pgroup->next;
		i++;
	}
	if (pgroup)	pgroup->material=m;
}

// Returns the material of the given group
Material *Model::getGroupMaterial(int group) {
	GLMgroup* pgroup;
	int i;

	pgroup=this->groups;
	i=0;
	while (pgroup!=NULL && i!=group) {
		pgroup=pgroup->next;
		i++;
	}
	if (pgroup)	
		return pgroup->material;
	else
		return NULL;
}

// Returns the number of groups
int Model::getNumGroups(void) {
	return numgroups;
}

void Model::assignMonitorPoints(int argc, char *argv[])
{
    if( AllocateMonitorPoints(argc) != argc )
		return ;

    for( int i = 0 ; i < argc ; i++ )
    {
		int indx = atoi(argv[i]) ;
		if( (indx < 0) || (indx >= this->GetNumVertices() ))
		{
			danceInterp::OutputMessage("Error: index out of bounds!") ;
			danceInterp::OutputMessage("MonitorPoints not assigned!\n") ;
			DeleteMonitorPoints() ;
			return ;
		}

		m_MonitorPoints.m_Point[i][0] = vertices[indx * 3];
		m_MonitorPoints.m_Point[i][1] = vertices[indx * 3 + 1];
		m_MonitorPoints.m_Point[i][2] = vertices[indx * 3 + 2];
    }
}

int Model::createMonitorPoints(int npoints, bool random)
{   
	if( (this->GetNumVertices() == 0) || (npoints <= 0) )
		return 0 ;

    if( this->GetNumVertices() < npoints )
		m_MonitorPoints.m_NumPoints = this->GetNumVertices() ;
    else 
		m_MonitorPoints.m_NumPoints = npoints ;
   
	if (random)
	{
		// take vertices at random
		// the downside to using this method is that repeated simulations might not give
		// you the same results since the collision points will be different every time
		int* alreadyUsed = new int[this->GetNumVertices()];
		assert(alreadyUsed != NULL ) ;
		for (int x = 0; x < this->GetNumVertices(); x++)
			alreadyUsed[x] = -1;

		for (int x = 0; x < npoints; x++)
		{
			// pick a random vertex
			bool found = false;
			int i = 0;
			while (!found)
			{
		#ifdef WIN32
				DWORD curTime = GetTickCount();
				i = rand() % this->GetNumVertices();
		#else
				timeval curTime;
				gettimeofday(&curTime, NULL);
				i = rand() % this->GetNumVertices();
		#endif
				if (alreadyUsed[i] == -1) // make sure that we haven't already used this vertex
				{ 
					alreadyUsed[i] = 0;
					found = true;
				}
			}
			m_MonitorPoints.m_Point[x][0] = vertices[i * 3];
			m_MonitorPoints.m_Point[x][1] = vertices[i * 3 + 1];
			m_MonitorPoints.m_Point[x][2] = vertices[i * 3 + 2];
		}
		if( alreadyUsed) delete [] alreadyUsed;

	}
	else
	{
		int skip = (int) (this->GetNumVertices() / npoints ) ;
		if( skip == 0 )
			skip = 1 ;
		int count = 0, numPoints = 0  ;
		for( int i = 0 ; (i < this->GetNumVertices()) && ( numPoints < npoints) ; i++ )
		{
			count++ ;
			if( count == skip )
			{
				m_MonitorPoints.m_Point[numPoints][0] = vertices[i * 3];
				m_MonitorPoints.m_Point[numPoints][1] = vertices[i * 3 + 1];
				m_MonitorPoints.m_Point[numPoints][2] = vertices[i * 3 + 2];
				count = 0 ;
				numPoints++ ;
			}	    
		}
	}

	// modify monitor points by transformation matrix, if appropriate
	if (this->useTransMatrix())
	{
		double transMatrix[4][4];
		this->getTransMatrix(transMatrix);

		for (int x = 0; x < m_MonitorPoints.m_NumPoints; x++)
			transformPoint_mat(m_MonitorPoints.m_Point[x], transMatrix);
	}

	danceInterp::OutputMessage("Number of vertices %d number of mnts %d\n", this->GetNumVertices(), m_MonitorPoints.m_NumPoints) ;
	
    return m_MonitorPoints.m_NumPoints ;
}

void Model::applyTransMatrix()
{
	// this function should only be called only if it is mutable
	double m[4][4];
	double p[3];

	getTransMatrix(m);

	// change the monitor points if available
	int num = this->m_MonitorPoints.m_NumPoints;
	for (int x = 0; x < num; x++)
	{
		transformPoint_mat(this->m_MonitorPoints.m_Point[x], m);
	}

	// apply trans matrix on all points
	for( int i = 0; i < this->GetNumVertices(); i++)
	{
		p[0] = vertices[i * 3];
		p[1] = vertices[i * 3 + 1];
		p[2] = vertices[i * 3 + 2];

		vertices[i * 3] = (float) (p[0]*m[0][0] + p[1]*m[1][0] + p[2]*m[2][0] + m[3][0]);
		vertices[i * 3 + 1] = (float) (p[0]*m[0][1] + p[1]*m[1][1] + p[2]*m[2][1] + m[3][1]);
		vertices[i * 3 + 2] = (float) (p[0]*m[0][2] + p[1]*m[1][2] + p[2]*m[2][2] + m[3][2]);
	}

	// reset trans matrix
	m_tx->setValue(0);
	m_ty->setValue(0);
	m_tz->setValue(0);
	m_rx->setValue(0);
	m_ry->setValue(0);
	m_rz->setValue(0);
	m_sx->setValue(1);
	m_sy->setValue(1);
	m_sz->setValue(1);
	calcTransMatrix();
	
	this->computeFacetNormals();

	this->setUseTransMatrix(true);
	m_checkPoint = 0;

}

void Model::Rotate(const char *axis, double degrees, int center)
{
	if (useTransMatrix())
	{
		DGeometry::Rotate(axis, degrees, center);
	}
	else
	{
		if( this->GetNumVertices() == 0 ) return ;
	    
		Vector gcenter ;

		if( center == 1 )
		{
			calcBoundingBox() ;
			gcenter[0] = (m_BoundingBox.xMax + m_BoundingBox.xMin)*0.5 ;
			gcenter[1] = (m_BoundingBox.yMax + m_BoundingBox.yMin)*0.5 ;
			gcenter[2] = (m_BoundingBox.zMax + m_BoundingBox.zMin)*0.5 ;
		    
			SetOrigin(gcenter) ;
		}
	    
		if(axis[0] == 'x')
		{
			XRotatePoints(vertices, this->GetNumVertices(), degrees) ;
			XRotatePoints(normals, this->GetNumNormals(), degrees) ;
		}
		else if(axis[0] == 'y')
		{
			YRotatePoints(vertices, this->GetNumVertices(), degrees) ;
			YRotatePoints(normals, this->GetNumNormals(), degrees) ;
		}
		else  if(axis[0] == 'z')
		{
			ZRotatePoints(vertices, this->GetNumVertices(), degrees) ;
			ZRotatePoints(normals, this->GetNumNormals(), degrees) ;
		}
		else
		{
			danceInterp::OutputMessage("ERROR: Model:Rotate: Invalid axis.\n") ;
		}

		if( center == 1 )
		{
			// bring the origin back to its original place
			for( int i = 0 ; i < this->GetNumVertices() ; i++ )
			{
				vertices[i * 3] += (float) gcenter[0];
				vertices[i * 3 + 1] += (float) gcenter[1];
				vertices[i * 3 + 2] += (float) gcenter[2];
			}
		}

		this->computeFacetNormals();
		m_checkPoint = 1;
	}
}

// relative translation
void Model::Translate(double x, double y, double z, bool relative)
{
	if (useTransMatrix())
	{
		DGeometry::Translate(x, y, z, relative);
	}
	else
	{
		if( this->GetNumVertices() == 0 ) return ;

		for( int i = 0 ; i < this->GetNumVertices() ; i++ )
		{
			vertices[i * 3] = vertices[i * 3] + (float) x;
			vertices[i * 3 + 1] = vertices[i * 3 + 1] + (float) y;
			vertices[i * 3 + 2] = vertices[i * 3 + 2] + (float) z;
		}
		if( m_checkPoint == 0 )
			m_checkPoint = 1;
	}
}


// scaling. If center is 1 then rotate around the center 
// of the bounding box of this geometry.
void Model::Scale(double sx, double sy, double sz, int center)
{
	if( this->GetNumVertices() == 0 ) return ;

	if (useTransMatrix())
	{
		DGeometry::Scale(sx, sy, sz, center);
	}
	else
	{
		for (unsigned int i = 0; i < numvertices; i++) {
			vertices[3 * i + 0] *= (float) sx;
			vertices[3 * i + 1] *= (float) sy;
			vertices[3 * i + 2] *= (float) sz;
		}
		this->computeFacetNormals();
		m_checkPoint = 2;
	}
    
}


// Returns the total number of triangles in the model
int Model::getNumFaces(void) 
{
	return numtriangles;
}


// Compute the bounding sphere 
void Model::calcBoundingSphere(double *center, double *radius)
{
	double avg[3], Min[3], Max[3], rd, *vt;
	int i, j;

	if (vertices==NULL) {
		center[0]=center[1]=center[2]=*radius=0.0f;
		return;
	}
	// run through all the vertices and	calculate
    // a general bounding box
	Min[0] = Max[0] = vertices[0];
	Min[1] = Max[1] = vertices[1];
	Min[2] = Max[2] = vertices[2];
	vt = vertices + 3;
    for( i = 1 ; i < (int) numvertices ; i++ )
    {
		for (j=0; j<3; j++) {
			if( *vt < Min[j] )
				Min[j] = *vt ;
			else if( *vt > Max[j] )
				Max[j] = *vt ;
			// There might be a lost of precision here, but if we sum every coordinate and then
			// divide, we can get overflows... life's hard
			avg[j]+=(*vt/numvertices);
			vt++;
		}
	}

	rd=0.0;
	vt=vertices;
    for(i = 0 ; i < (int) numvertices ; i++ ) {
		rd = MAX(rd, (vt[0]-avg[0])*(vt[0]-avg[0]) + 
			(vt[1]-avg[1])*(vt[1]-avg[1]) +
			(vt[2]-avg[2])*(vt[2]-avg[2]));
	}
	
	for (i=0; i<3; i++)
		center[i] = avg[i];
	*radius=sqrt(rd);
}



// Returns the coordinates of the 'id'-nth triangle in the model. If the
// useTransMatrix is set, then the transformation matrix is applied
int Model::getTriangle(unsigned int id, double p1[], double p2[], double p3[]) {
	double p[3];

	if (id<0 || id>numtriangles) return DANCE_ERROR;
	
	if (useTransMatrix()) {
		double (*m)[4];
		m=this->m_transMatrix;

		p[0]=vertices[triangles[id].vindices[0]*3];
		p[1]=vertices[triangles[id].vindices[0]*3+1];
		p[2]=vertices[triangles[id].vindices[0]*3+2];
		
		p1[0] = m[0][0] * p[0] + m[1][0] * p[1] + m[2][0] * p[2] + m[3][0];
		p1[1] = m[0][1] * p[0] + m[1][1] * p[1] + m[2][1] * p[2] + m[3][1];
		p1[2] = m[0][2] * p[0] + m[1][2] * p[1] + m[2][2] * p[2] + m[3][2];

		p[0]=vertices[triangles[id].vindices[1]*3];
		p[1]=vertices[triangles[id].vindices[1]*3+1];
		p[2]=vertices[triangles[id].vindices[1]*3+2];

		p2[0] = m[0][0] * p[0] + m[1][0] * p[1] + m[2][0] * p[2] + m[3][0];
		p2[1] = m[0][1] * p[0] + m[1][1] * p[1] + m[2][1] * p[2] + m[3][1];
		p2[2] = m[0][2] * p[0] + m[1][2] * p[1] + m[2][2] * p[2] + m[3][2];

		p[0]=vertices[triangles[id].vindices[2]*3];
		p[1]=vertices[triangles[id].vindices[2]*3+1];
		p[2]=vertices[triangles[id].vindices[2]*3+2];

		p3[0] = m[0][0] * p[0] + m[1][0] * p[1] + m[2][0] * p[2] + m[3][0];
		p3[1] = m[0][1] * p[0] + m[1][1] * p[1] + m[2][1] * p[2] + m[3][1];
		p3[2] = m[0][2] * p[0] + m[1][2] * p[1] + m[2][2] * p[2] + m[3][2];
	} else {
		p1[0]=vertices[triangles[id].vindices[0]*3];
		p1[1]=vertices[triangles[id].vindices[0]*3+1];
		p1[2]=vertices[triangles[id].vindices[0]*3+2];

		p2[0]=vertices[triangles[id].vindices[1]*3];
		p2[1]=vertices[triangles[id].vindices[1]*3+1];
		p2[2]=vertices[triangles[id].vindices[1]*3+2];

		p3[0]=vertices[triangles[id].vindices[2]*3];
		p3[1]=vertices[triangles[id].vindices[2]*3+1];
		p3[2]=vertices[triangles[id].vindices[2]*3+2];
	}

	return DANCE_OK;
}


// Returns the id (offset into the ddbb) of the n (=1,2,3) vertex of the 'tid' triangle
int Model::getVertexId(unsigned int tid, int n) {
	if (tid<0 || tid>=numtriangles)
		return -1;

	return triangles[tid].vindices[n-1];
}




void Model::enableAutoShow()
{
	m_showSelf = true;
}

bool Model::isAutoShow()
{
	return m_showSelf;
}


void Model::disableAutoShow()
{
	m_showSelf = false;
}

void Model::setShowNormals(bool val)
{
	showNormals = val;
}

bool Model::isShowNormals()
{
	return showNormals;
}


void Model::computeVerticesNormals(float max_ang) 
{
	double ab[3], ac[3], n[3];
	double m;

	for(unsigned  int i = 0; i < numvertices*3; i++)
		normals[i] = 0.0f;

	for(unsigned int i = 0; i < numtriangles; i++)
	{

#define VV(vtx, axe) vertices[triangles[i].vindices[vtx]*3+axe]

		// ab = vertex1 - vertex0
		ab[0] = VV(1, 0) - VV(0, 0);
		ab[1] = VV(1, 1) - VV(0, 1);
		ab[2] = VV(1, 2) - VV(0, 2);

		// ac = vertex2 - vertex0
		ac[0] = VV(2, 0) - VV(0, 0); 
		ac[1] = VV(2, 1) - VV(0, 1); 
		ac[2] = VV(2, 2) - VV(0, 2); 

		// n = ab cross ac
		n[0] = ab[1]*ac[2] - ab[2]*ac[1];
		n[1] = ab[2]*ac[0] - ab[0]*ac[2];
		n[2] = ab[0]*ac[1] - ab[1]*ac[0];

		// normalize n
		m = sqrt( n[0]*n[0] + n[1]*n[1] + n[2]*n[2] );
		if( m != 0 )
		{
			n[0] /= m;
			n[1] /= m;
			n[2] /= m;
		}

		int i1;
		// add face normal to each vertex normal
		for( int j = 0; j < 3; j++)
		{
			i1=triangles[i].vindices[j]*3;
			normals[i1] += (float)n[0];
			normals[i1+1] += (float)n[1];
			normals[i1+2] += (float)n[2];
		}
	}

	// normalize the normals => taking average of the face normals
	for(unsigned int i = 0; i < numvertices; i++)
	{
		m = sqrt( normals[i*3]*normals[i*3] + normals[i*3+1]*normals[i*3+1] + normals[i*3+2]*normals[i*3+2]);
		if( m != 0 )
		{
			normals[i*3] /= (float)m;
			normals[i*3+1] /= (float)m;
			normals[i*3+2] /= (float)m;
		}
	}
}


// BuildEdges:
//
// Loops through all stored polygons and builds up the edge lists for each vertex.
// Also fills in the WingedEdge data structure via a method call. 
//
// Returns the number of edges created.
int Model::BuildEdges()
{
	// comment out by RayH 10-1-2003
	// otherwise calling BuildEdges second time will result in m_NumEdges = 0
	//m_NumEdges = 0;
	
	

	if (m_VertexEdges) {
	    // Remove all entries first.
		for (unsigned int i = 0; i < numvertices; i++) 
			m_VertexEdges[i].Cleanup();
		if (m_VertexEdges) delete [] m_VertexEdges;
	}

	m_VertexEdges = new EdgeList[numvertices] ;
	if (m_VertexEdges == NULL) {
		danceInterp::OutputMessage("ERR: Model::BuildEdges cannot allocate memory for vertex edges.\n");
		return DANCE_ERROR;
	}

	// Loop through all faces.
	for (unsigned int i = 0; i < numtriangles; i++) {
		// Loop through all edges of this face.
		for (int j = 0; j < 3; j++) {
			int v1 = triangles[i].vindices[j];
			int v2 = triangles[i].vindices[(j+1) % 3];
			ProcessEdge(v1,v2,i);
		}
	}

	/*

	char pp[256], p[10];

	for (i=0; i<numvertices; i++) {
		pp[0]=0;
		for (int j=0; j<m_VertexEdges[i].m_numEdges; j++) {
			sprintf(p, "%d ", m_VertexEdges[i].m_Edges[j]);
			strcat(pp, p);
		}
		if (i==0 || i==440) {
			if (m_VertexEdges[i].m_numEdges!=3) 
				strcat(pp, "++++++++++++++++++++++");
		} else 
			if (i==20 || i==420) {
				if (m_VertexEdges[i].m_numEdges!=2)
					strcat(pp, "++++++++++++++++++++++");
			} else 
				if ((i>0 && i<20) || (i>420) || ((i-20)%21==0) || (i%21==0)) {
					if (m_VertexEdges[i].m_numEdges!=4)
                        strcat(pp, "***********************");
				} else if (m_VertexEdges[i].m_numEdges!=6)
				strcat(pp, "&&&&&&&&&&&&&&&&&&&&&");

		danceInterp::OutputMessage("V%04d -> %d edges (%s)", i, m_VertexEdges[i].m_numEdges, pp);

	}
	*/

	/*int total=0;

	for (i=0; i<numvertices; i++)
		total+=m_VertexEdges[i].m_numEdges;*/

//	return (numtriangles);
	return (this->m_NumEdges);
}

// ProcessEdge:
//		Adds to the list of WingedEdges if applicable.
//	
// Returns 1 if modified a WingedEdge structure, 0 if WingedEdge already defined.
//
int Model::ProcessEdge(int v1, int v2, int face)
{
	// Check if v2 is in v1's edgelist.
	WingedEdge *foundedge = NULL;
	int inList = 0;
	for (int i = 0; i < m_VertexEdges[v1].m_numEdges; i++) {
		WingedEdge *edge = &(m_EdgeList[m_VertexEdges[v1].m_Edges[i]]);
		if (edge->v1 == v2) {
			inList = 1; foundedge = edge;
			break;
		}
		if (edge->v2 == v2) {
			inList = 2; foundedge = edge;
			break;
		}		
	}

	if (inList == 1) { // Edge found but traversing in opposite direction.
		// Add face to f2 of WingedEdge
		foundedge->f2 = face;
		return 1;
	}

	if (inList == 2) // Found a duplicate edge, so we just return.
		return 0;
	
    // Create a WingedEdge structure.
    if(m_NumEdges % EDGE_CHUNK_SIZE == 0 )
    {
		int numChunks = m_NumEdges	/ EDGE_CHUNK_SIZE ;
		// time	to allocate a chunk of memory
		numChunks++ ;
		WingedEdge *tmp = new WingedEdge[numChunks*EDGE_CHUNK_SIZE] ;
		if( tmp == NULL )
		{
			danceInterp::OutputMessage("Model::ProcessEdge Cannot allocate memory!\n") ;
			return ERR;
		}
	
		if (m_EdgeList) {
			memcpy(tmp,m_EdgeList,m_NumEdges*sizeof(WingedEdge));
			delete [] m_EdgeList;
		}
		m_EdgeList = tmp;
    }

	m_EdgeList[m_NumEdges].v1 = v1;
	m_EdgeList[m_NumEdges].v2 = v2;
	m_EdgeList[m_NumEdges].f1 = face;
	m_EdgeList[m_NumEdges].f2 = -1;

	// Add this edge to each of the vertices.
	int nEdges = ++m_VertexEdges[v1].m_numEdges;
	int *tmpEdge = m_VertexEdges[v1].m_Edges;
	
	m_VertexEdges[v1].m_Edges = new int[nEdges];
	if (nEdges > 1)
		memcpy(m_VertexEdges[v1].m_Edges,tmpEdge,(nEdges-1)*sizeof(int));
	m_VertexEdges[v1].m_Edges[nEdges-1] = m_NumEdges;
	if (tmpEdge) delete [] tmpEdge;

	nEdges = ++m_VertexEdges[v2].m_numEdges;
	tmpEdge = m_VertexEdges[v2].m_Edges;
	m_VertexEdges[v2].m_Edges = new int[nEdges];
	if (nEdges > 1)
		memcpy(m_VertexEdges[v2].m_Edges,tmpEdge,(nEdges-1)*sizeof(int));
	m_VertexEdges[v2].m_Edges[nEdges-1] = m_NumEdges;
	if (tmpEdge) delete [] tmpEdge;

	m_NumEdges++;

	return(1);
}


int Model::takeCheckPoint()
{
	int temp = m_checkPoint;
	m_checkPoint = 0;
	return temp;
}

void Model::save(int mode, std::ofstream& file)
{
	if (mode == 0)
	{
		if (this->pathname == NULL)
		{
			char newpathname[1024];
			convertbackslashes(pathname, newpathname);
			file << "dance.instance(\"Model\", \"" << this->getName() << "\", \"" << newpathname << "\")" << std::endl; 
		}
		else
		{
			// save the model
			char modelfilename[512];
			sprintf(modelfilename, "%s.obj", this->getName());
			std::string libname = this->getName();
			libname.append("_materials.mat");
			glmWriteOBJ(this, modelfilename, GLM_NONE | GLM_MATERIAL, (char*) libname.c_str());
			// replace all backslashes by forward slashes
			file << "dance.instance(\"Model\", \"" << this->getName() << "\", \"" << modelfilename  << "\")" << std::endl; 
			
			//char newpathname[1024];
			//convertbackslashes(pathname, newpathname);
			//file << "dance.instance(\"Model\", \"" << this->getName() << "\", \"" << newpathname << "\")" << std::endl; 
		}
	}
	else if (mode == 1)
	{

	}


	DGeometry::save(mode, file);
}

/* glmWriteOBJ: Writes a model description in Wavefront .OBJ format to
 * a file.
 *
 * model - initialized GLMmodel structure
 * filename - name of the file to write the Wavefront .OBJ format data to
 * mode  - a bitwise or of values describing what is written to the file
 *             GLM_NONE     -  render with only vertices
 *             GLM_FLAT     -  render with facet normals
 *             GLM_SMOOTH   -  render with vertex normals
 *             GLM_TEXTURE  -  render with texture coords
 *             GLM_COLOR    -  render with colors (color material)
 *             GLM_MATERIAL -  render with materials
 *             GLM_COLOR and GLM_MATERIAL should not both be specified.  
 *             GLM_FLAT and GLM_SMOOTH should not both be specified.  
 */
GLvoid
glmWriteOBJ(Model* model, const char* filename, GLuint mode, const char* libname)
{
     FILE*   file;
     GLMgroup* group;

     assert(model);

     /* do a bit of warning */
     if (mode & GLM_FLAT && !model->facetnorms) {
         danceInterp::OutputMessage("glmWriteOBJ() warning: flat normal output requested "
             "with no facet normals defined.\n");
         mode &= ~GLM_FLAT;
     }
     if (mode & GLM_SMOOTH && !model->normals) {
         danceInterp::OutputMessage("glmWriteOBJ() warning: smooth normal output requested "
             "with no normals defined.\n");
         mode &= ~GLM_SMOOTH;
     }
     if (mode & GLM_TEXTURE && !model->texcoords) {
         danceInterp::OutputMessage("glmWriteOBJ() warning: texture coordinate output requested "
             "with no texture coordinates defined.\n");
         mode &= ~GLM_TEXTURE;
     }
     if (mode & GLM_FLAT && mode & GLM_SMOOTH) {
         danceInterp::OutputMessage("glmWriteOBJ() warning: flat normal output requested "
             "and smooth normal output requested (using smooth).\n");
         mode &= ~GLM_FLAT;
     }
        if (mode & GLM_COLOR && model->numgroups == 0) {
         danceInterp::OutputMessage("glmWriteOBJ() warning: color output requested "
             "with no colors (materials) defined.\n");
         mode &= ~GLM_COLOR;
     }
     if (mode & GLM_MATERIAL && model->numgroups == 0) {
         danceInterp::OutputMessage("glmWriteOBJ() warning: material output requested "
             "with no materials defined.\n");
         mode &= ~GLM_MATERIAL;
     }
     if (mode & GLM_COLOR && mode & GLM_MATERIAL) {
         danceInterp::OutputMessage("glmWriteOBJ() warning: color and material output requested "
             "outputting only materials.\n");
         mode &= ~GLM_COLOR;
     }

     /* open the file */
     file = fopen(filename, "w");
     if (!file) {
         danceInterp::OutputMessage( "glmWriteOBJ() failed: can't open file \"%s\" to write.\n", filename);
                return ;
     }

     /* spit out a header */
     fprintf(file, "#  \n");
     fprintf(file, "#  Wavefront OBJ generated by GLM library\n");
     fprintf(file, "#  \n");
     fprintf(file, "#  GLM library\n");
     fprintf(file, "#  Nate Robins\n");
     fprintf(file, "#  ndr@pobox.com\n");
     fprintf(file, "#  http://www.pobox.com/~ndr\n");
     fprintf(file, "#  \n");

        if (mode & GLM_MATERIAL) {//&& model->mtllibname) {
         fprintf(file, "\nmtllib %s\n\n", libname);
         glmWriteMTL(model, filename, libname);
     }

     /* spit out the vertices */
     fprintf(file, "\n");
     fprintf(file, "# %d vertices\n", model->numvertices);
     for (unsigned int i = 0; i < model->numvertices; i++) {
         fprintf(file, "v %f %f %f\n",
             model->vertices[3 * i + 0],
             model->vertices[3 * i + 1],
             model->vertices[3 * i + 2]);
     }

     /* spit out the smooth/flat normals */
     if (mode & GLM_SMOOTH) {
         fprintf(file, "\n");
                fprintf(file, "# %d normals\n", model->GetNumNormals());
                for (int i = 0; i < model->GetNumNormals(); i++) {
             fprintf(file, "vn %f %f %f\n",
                 model->normals[3 * i + 0],
                 model->normals[3 * i + 1],
                 model->normals[3 * i + 2]);
         }
     } else if (mode & GLM_FLAT) {
         fprintf(file, "\n");
         fprintf(file, "# %d normals\n", model->numfacetnorms);
         for (int i = 0; i < model->GetNumNormals(); i++) {
             fprintf(file, "vn %f %f %f\n",
                 model->facetnorms[3 * i + 0],
                 model->facetnorms[3 * i + 1],
                 model->facetnorms[3 * i + 2]);
         }
     }

     /* spit out the texture coordinates */
     if (mode & GLM_TEXTURE) {
         fprintf(file, "\n");
         fprintf(file, "# %u texcoords\n", model->texcoords);
         for (unsigned int i = 0; i < model->numtexcoords; i++) {
             fprintf(file, "vt %f %f\n",
                 model->texcoords[2 * i + 0],
                 model->texcoords[2 * i + 1]);
         }
     }

     fprintf(file, "\n");
     fprintf(file, "# %d groups\n", model->numgroups);
     fprintf(file, "# %d faces (triangles)\n", model->numtriangles);
     fprintf(file, "\n");

     group = model->groups;
     while(group) {
         fprintf(file, "g %s\n", group->name);
         if (mode & GLM_MATERIAL)
                        fprintf(file, "usemtl %s\n",
group->material->getSafeMaterialName());
         for (unsigned i = 0; i < group->numtriangles; i++) {
             if (mode & GLM_SMOOTH && mode & GLM_TEXTURE) {
                 fprintf(file, "f %d/%d/%d %d/%d/%d %d/%d/%d\n",
                     T(group->triangles[i]).vindices[0],
//                    T(group->triangles[i]).nindices[0],
                                        T(group->triangles[i]).findex + 1,
                     T(group->triangles[i]).tindices[0]+ 1,
                     T(group->triangles[i]).vindices[1]+ 1,
//                    T(group->triangles[i]).nindices[1],
                                        T(group->triangles[i]).findex+ 1,
                     T(group->triangles[i]).tindices[1]+ 1,
                     T(group->triangles[i]).vindices[2]+ 1,
//                    T(group->triangles[i]).nindices[2]+ 1,
                                        T(group->triangles[i]).findex,
                     T(group->triangles[i]).tindices[2]);
             } else if (mode & GLM_FLAT && mode & GLM_TEXTURE) {
                 fprintf(file, "f %d/%d %d/%d %d/%d\n",
                     T(group->triangles[i]).vindices[0]+ 1,
                     T(group->triangles[i]).findex+ 1,
                     T(group->triangles[i]).vindices[1]+ 1,
                     T(group->triangles[i]).findex+ 1,
                     T(group->triangles[i]).vindices[2]+ 1,
                     T(group->triangles[i]).findex+ 1);
             } else if (mode & GLM_TEXTURE) {
                 fprintf(file, "f %d/%d %d/%d %d/%d\n",
                     T(group->triangles[i]).vindices[0]+ 1,
                     T(group->triangles[i]).tindices[0]+ 1,
                     T(group->triangles[i]).vindices[1]+ 1,
                     T(group->triangles[i]).tindices[1]+ 1,
                     T(group->triangles[i]).vindices[2]+ 1,
                     T(group->triangles[i]).tindices[2]+ 1);
             } else if (mode & GLM_SMOOTH) {
                 fprintf(file, "f %d//%d %d//%d %d//%d\n",
                     T(group->triangles[i]).vindices[0]+ 1,
//                    T(group->triangles[i]).nindices[0]+ 1,
                                        T(group->triangles[i]).findex+ 1,
                     T(group->triangles[i]).vindices[1]+ 1,
//                    T(group->triangles[i]).nindices[1]+ 1,
                                        T(group->triangles[i]).findex+ 1,
                     T(group->triangles[i]).vindices[2]+ 1,
//                    T(group->triangles[i]).nindices[2])+ 1;
                                        T(group->triangles[i]).findex+ 1);
             } else if (mode & GLM_FLAT) {
                 fprintf(file, "f %d//%d %d//%d %d//%d\n",
                     T(group->triangles[i]).vindices[0]+ 1,
                     T(group->triangles[i]).findex+ 1,
                     T(group->triangles[i]).vindices[1]+ 1,
                     T(group->triangles[i]).findex+ 1,
                     T(group->triangles[i]).vindices[2]+ 1,
                     T(group->triangles[i]).findex+ 1);
             } else {
                  fprintf(file, "f %d %d %d\n",
                     T(group->triangles[i]).vindices[0]+ 1,
                     T(group->triangles[i]).vindices[1]+ 1,
                     T(group->triangles[i]).vindices[2]+ 1);
             }
         }
         fprintf(file, "\n");
         group = group->next;
     }

     fclose(file);
}
  
/* glmWriteMTL: write a wavefront material library file
 *
 * model   - properly initialized GLMmodel structure
 * modelpath  - pathname of the model being written
 * mtllibname - name of the material library to be written
 */
GLvoid
glmWriteMTL(Model* model, const char* modelpath, const char* mtllibname)
{
    FILE* file;
    Material* material;
   
    
    /* open the file */
    file = fopen(mtllibname, "w");
    if (!file) {
        danceInterp::OutputMessage( "glmWriteMTL() failed: can't open file \"%s\".\n",
            mtllibname);
    }
    
    /* spit out a header */
    fprintf(file, "#  \n");
    fprintf(file, "#  Wavefront MTL generated by GLM library\n");
    fprintf(file, "#  \n");
    fprintf(file, "#  GLM library\n");
    fprintf(file, "#  Nate Robins\n");
    fprintf(file, "#  ndr@pobox.com\n");
    fprintf(file, "#  http://www.pobox.com/~ndr\n");
    fprintf(file, "#  \n\n");
    
	GLMgroup* curGroup = model->groups;
	while (curGroup != NULL)
	{
		if (curGroup->material != NULL)
		{
//			danceInterp::OutputMessage("writing group %s material %s",  curGroup->name, curGroup->material->getMaterialName()) ;
			material = curGroup->material;
			fprintf(file, "newmtl %s\n", material->getMaterialName());
			fprintf(file, "Ka %f %f %f\n", 
				material->getAmbientColor()[0], material->getAmbientColor()[1], material->getAmbientColor()[2]);
			fprintf(file, "Kd %f %f %f\n", 
				material->getDiffuseColor()[0], material->getDiffuseColor()[1], material->getDiffuseColor()[2]);
			fprintf(file, "Ks %f %f %f\n", 
				material->getSpecularColor()[0],material->getSpecularColor()[1],material->getSpecularColor()[2]);
			fprintf(file, "Ns %f\n", material->getShininess() / 128.0 * 1000.0);
			fprintf(file, "\n");
		}
		curGroup = curGroup->next;
    }

	fclose(file);
}


