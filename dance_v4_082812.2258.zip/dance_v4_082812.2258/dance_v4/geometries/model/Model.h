/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef _INC_GLM_
#define _INC_GLM_
/*    
      glm.h
      Nate Robins, 1997, 2000
      nate@pobox.com, http://www.pobox.com/~nate
 
      Wavefront OBJ model file format reader/writer/manipulator.

      Includes routines for generating smooth normals with
      preservation of edges, welding redundant vertices & texutre
      coordinate generation (spheremap and planar projections) + more.

 */
#ifdef WIN32
#include <windows.h>
#endif

#include "opengl.h"

#include "DGeometry.h"

#include "texture.h"
#include <list> 
#include <algorithm>

#include "Material.h"
#include "WingedEdge.h"

#ifdef WIN32
#ifdef MODEL_EXPORTS
#define	DLLMODEL __declspec(dllexport)
#else
#define	DLLMODEL __declspec(dllimport)
#endif
#else
#define DLLMODEL 
#endif

// Values for m_renderType 
enum { RT_SOLID, RT_MESH, RT_VERTICES };


#ifndef M_PI
#define M_PI 3.14159265f
#endif

#define GLM_NONE     (0)            /* render with only vertices */
#define GLM_FLAT     (1 << 0)       /* render with facet normals */
#define GLM_SMOOTH   (1 << 1)       /* render with vertex normals */
#define GLM_TEXTURE  (1 << 2)       /* render with texture coords */
#define GLM_COLOR    (1 << 3)       /* render with colors */
#define GLM_MATERIAL (1 << 4)       /* render with materials */


#define MAX_TRANSFORM_LEVELS 10
#define MAX_VERT_FACE 16 


// Size of the growth in each Model realloc
#define CHUNK_SIZE_ARRAY 512

// similarly for edges
#define EDGE_CHUNK_SIZE 1000 


/* GLMtriangle: Structure that defines a triangle in a model.
 */
typedef struct _GLMtriangle {
  GLuint vindices[3];           /* array of triangle vertex indices */
//  GLuint nindices[3];           /* array of triangle normal indices */
  GLuint tindices[3];           /* array of triangle texcoord indices*/
  GLuint findex;                /* index of triangle facet normal */
} GLMtriangle;

/* GLMgroup: Structure that defines a group in a model.
 */
typedef struct _GLMgroup {
  char*             name;           /* name of this group */
  GLuint            numtriangles;   /* number of triangles in this group */
  GLuint*           triangles;      /* array of triangle indices */
  Material * material;
  struct _GLMgroup* next;           /* pointer to next group in model */
} GLMgroup;


class EdgeList
{
	public:
		int m_numEdges;
		int *m_Edges;
		void Cleanup() { if (m_Edges) delete [] m_Edges; };
		EdgeList() { m_numEdges = 0; m_Edges = NULL; };
		EdgeList(EdgeList &src)
		{
			m_Edges = NULL;
			m_numEdges = src.m_numEdges;
			if( src.m_Edges )
			{
				m_Edges = new int[m_numEdges];
				memcpy(m_Edges, src.m_Edges, sizeof(int)*m_numEdges);
			}
		}
		EdgeList& operator =(EdgeList &src)
		{
			if( m_Edges )
				delete [] m_Edges;
			m_Edges = NULL;
			m_numEdges = src.m_numEdges;
			if( src.m_Edges )
			{
				m_Edges = new int[m_numEdges];
				memcpy(m_Edges, src.m_Edges, sizeof(int)*m_numEdges);
			}
			return (*this);
		}
};

class ModelWindow;

/* Model: Structure that defines a model.
 */
class DLLEXPORT Model : public DGeometry {
public:
	Model(void) ;
	Model(Model& model);
	~Model() ;
	char*    pathname;            /* path to this model */
	char*    mtllibname;          /* name of the material library */

	GLuint   numvertices;         /* number of vertices in model */
	double* vertices;            /* array of vertices  */
	int maxNumVertices;			  /* maximum number of vertices in the array */

//	GLuint   numnormals;          /* number of normals in model */
	GLfloat* normals;             /* array of normals */
//	int maxNumNormals;			  /* maximum number of normals in the array */

	GLuint   numtexcoords;        /* number of texcoords in model */
	GLfloat* texcoords;           /* array of texture coordinates */
	int maxNumTexCoords;		  /* maximum number of texture coordinates in the array */

	GLuint   numfacetnorms;       /* number of facetnorms in model */
	GLfloat* facetnorms;          /* array of facetnorms */
	int maxNumFacetNorms;		  /* maximum number of facet norms in the array */


	GLuint       numtriangles;    /* number of triangles in model */
	GLMtriangle* triangles;       /* array of triangles */
	int maxNumTriangles;		  /* maximum number of triangles in the array */

	GLuint       numgroups;       /* number of groups in model */
	GLMgroup*    groups;          /* linked list of groups */
	int maxNumGroups;			  /* maximum number of groups in the array */


	GLfloat position[3];          /* position of the model */

	int m_NoNormalsRead ;


	int ReadOBJ(char* filename);
	/* ReadVRML: Reads a model description from a VRML file.
	* Returns DANCE_OK or DANCE_ERROR
	*
	* filename - name of the file containing the VRML format data.  
	*/
	int ReadVRML(char* filename);

	int Read3DS(char *filename);


	int PartialCopy(Model *m) ;
	void copyVertices(double* vertices, int numvertices);
	void copyNormals(GLfloat* normals, int numvertices);
	void copyFaceNormals(GLfloat* faces, int numvertices);

	// virtual methods in geometry that have to be implemented
	BoundingBox *calcBoundingBox(BoundingBox *box = NULL) ;
   inline double *GetVertices() { return vertices;} ;
   inline int GetNumVertices() { return numvertices;} ;
   inline GLfloat *GetTexCoords() { return texcoords;} ;
   inline int GetNumTexCoords() { return numtexcoords;} ;
   inline GLfloat *GetNormals() { return normals;} ;
   inline int GetNumNormals() { return numvertices;} ;
   inline GLfloat *GetFacetNormals() { return facetnorms; }
   inline int GetNumFacetNormals() { return numfacetnorms; }
	
   // Compute the bounding sphere 
   void calcBoundingSphere(double *center, double *radius);

   // Returns the total number of triangles in the model
   int getNumFaces(void);

	void output(int mode) ;
	void calcInerTensor(double inerTensor[3][3], double	mass) { return ;} ;

	PlugIn* create(int argc, char **argv);
	int commandPlugIn(int argc, char	**argv) ;

	void setMutable(bool val);
	bool isMutable();

	bool isShowNormals();
	void setShowNormals(bool val);
	
	void outputNormals();
	
	// Sets the same materials for all the groups in the model
	void setMaterial(Material* m);
	// Returns the material of the first group
	Material* getMaterial();
	// Sets material for the given group (0 based ids)
	void setGroupMaterial(int group, Material *m);
	// Returns the material of the given group
	Material *getGroupMaterial(int group);

	int UseShaders ;

	fltk::Widget* getInterface();
	void render(int argc, char ** argv, std::ofstream & file);

	
	// Groups management
	// Finds a group in the model
	GLMgroup *findGroup(const char* name);
	// Adds a group to the model 
	GLMgroup *addGroup(const char* name);
	// Returns the number of groups
	int getNumGroups(void);

	// Returns the coordinates of the 'id'-nth triangle in the model. If the
	// useTransMatrix is set, then the transformation matrix is applied
	int getTriangle(unsigned int id, double p1[], double p2[], double p3[]);	

	// Returns the id (offset into the ddbb) of the n (=1,2,3) vertex of the 'tid' triangle
	int getVertexId(unsigned int tid, int n);
	// As before, but all of them
	inline void getVerticesIds(int tid, int &p1, int &p2, int &p3) { 
		p1=triangles[tid].vindices[0]; 
		p2=triangles[tid].vindices[1]; 
		p3=triangles[tid].vindices[2]; 
	}

	// Returns a pointer to the given vertex
	inline double *getVertexPointer(unsigned int vid) { return ( vid >= numvertices) ? NULL: vertices+3*vid; } 


	// Set/Check/Query visibility
	void enableAutoShow();
	void disableAutoShow();
	bool isAutoShow();


	// Scales all the vertices in the model by the given amount.
	void scaleGeometry(GLfloat x, GLfloat y, GLfloat z);
	/* Reverse the polygon winding for all polygons in
	* this model.   Default winding is counter-clockwise.  Also changes
	* the direction of the normals.
	*/
	void reverseWinding(void);
	// eliminate (weld) vectors that are within an epsilon of each other.
	void weld(GLfloat epsilon);
	// Calculates the dimensions (width, height, depth) of the model.
	//void getDimensions(GLfloat* dimensions);
	/* Generates facet normals for a model (by taking the
	* cross product of the two vectors derived from the sides of each
	* triangle).  Assumes a counter-clockwise winding.
	*/
	void computeFacetNormals(void);
	// 	maximum angle (in degrees) to smooth across
	void computeVerticesNormals(float max_ang=90.0f);

	void assignMonitorPoints(int argc, char *argv[]) ;
	int	createMonitorPoints(int npoints, bool random) ;
	void applyTransMatrix();

	void Scale(double sx, double sy, double sz, int center = 0);
	void Translate(double x, double y, double z, bool relative);
	void Rotate(const char *axis, double degrees, int center);

	// Edges stuff
	int BuildEdges();
	WingedEdge *m_EdgeList; // List of edges
	inline int GetNumEdges() { return m_NumEdges;} ;

	int takeCheckPoint();

	int setNormal(unsigned int vid, float x, float y, float z);

	void save(int mode, std::ofstream& file);

private:
	ModelWindow* m_modelWindow;
	bool m_isMutable;
	bool m_noisy;
	bool m_showSelf;
	int m_checkPoint;


	// VRML loading auxiliary stuff
	int m_MirrorGeometry;
	int parseShapeNode( std::ifstream &file, int level);
	int parseIndexedFaceSetNode( std::ifstream &file, int level);
	int parseAppearanceNode(std::ifstream &file);
	int parseNode(std::ifstream &file);
	int parseCoordinateNode( std::ifstream &file, int level, double mat[16]);
	int parseCoordIndexField( std::ifstream &file);
	int parseNormalNode(std::ifstream &file, int level, double mat[16]);
	int parseNormalIndexField(std::ifstream &file);
	int parseTransform( std::ifstream &file, int level);
	void BuildTranslate(double mat[16], double x, double y, double z);
	void BuildScale(double mat[16], double sx, double sy, double sz);
	void BuildRotate(double mat[16], double x, double y, double z, double rad);
	void TransformPoint(double mat[16], double point[3], int normal);
	void TransformPoint(double mat[16], float point[3], int normal);
	int parseChildren(std::ifstream &file, int level);
	
	// Construction functions
	int addVertex(double x,	double y, double z, float nx=0.0f, float ny=0.0f, float nz=0.0f);

	// Add a new polygon to the database and returns its id. 
	// -1 if it fails
	int addFace(void);
	// Add a polygon to the database in --index-- position
	int addFace(int index) ;
	
//	int	addNormal(double x, double y, double z); 
	/// Polygon index, number of vertex, indexes of coordinates
	int addCoordsToFace(int index, int *coordIndices);
//	int addNormalToFace(int index,  int *normIndices);

	// adds the texture coordinates into the database
	int addTexCoord(float x, float y);
	/// Polygon index, indexes of coordinates
	int addTexCoordsToFace(int index, int *coordIndices);


    // XXXXX: This should a pointer, and be allocated when really needed
	double m_TransformStack[MAX_TRANSFORM_LEVELS][16];
	void BuildTransform(int level, double mat[16]);


	// Edges structure
	EdgeList *m_VertexEdges;		// Edge list for a vertex.
	int m_NumEdges;
	int ProcessEdge(int v1, int v2, int face);

	int enlargeVectors(void);
	bool showNormals;
	
} ;

//#ifdef __cplusplus
//extern "C"
//{
//#endif

/* glmUnitize: "unitize" a model by translating it to the origin and
 * scaling it to fit in a unit cube around the origin.  Returns the
 * scalefactor used.
 *
 * model - properly initialized Model structure 
 */
GLfloat
glmUnitize(Model* model);


/* glmVertexNormals: Generates smooth vertex normals for a model.
 * First builds a list of all the triangles each vertex is in.  Then
 * loops through each vertex in the the list averaging all the facet
 * normals of the triangles each vertex is in.  Finally, sets the
 * normal index in the triangle for the vertex to the generated smooth
 * normal.  If the dot product of a facet normal and the facet normal
 * associated with the first triangle in the list of triangles the
 * current vertex is in is greater than the cosine of the angle
 * parameter to the function, that facet normal is not added into the
 * average normal calculation and the corresponding vertex is given
 * the facet normal.  This tends to preserve hard edges.  The angle to
 * use depends on the model, but 90 degrees is usually a good start.
 *
 * model - initialized Model structure
 * angle - maximum angle (in degrees) to smooth across
 */
GLvoid
glmVertexNormals(Model* model, GLfloat angle);

/* glmLinearTexture: Generates texture coordinates according to a
 * linear projection of the texture map.  It generates these by
 * linearly mapping the vertices onto a square.
 *
 * model - pointer to initialized Model structure
 */
GLvoid
glmLinearTexture(Model* model);

/* glmSpheremapTexture: Generates texture coordinates according to a
 * spherical projection of the texture map.  Sometimes referred to as
 * spheremap, or reflection map texture coordinates.  It generates
 * these by using the normal to calculate where that vertex would map
 * onto a sphere.  Since it is impossible to map something flat
 * perfectly onto something spherical, there is distortion at the
 * poles.  This particular implementation causes the poles along the X
 * axis to be distorted.
 *
 * model - pointer to initialized Model structure
 */
GLvoid
glmSpheremapTexture(Model* model);



/* glmWriteOBJ: Writes a model description in Wavefront .OBJ format to
 * a file.
 *
 * model    - initialized Model structure
 * filename - name of the file to write the Wavefront .OBJ format data to
 * mode     - a bitwise or of values describing what is written to the file
 *            GLM_NONE    -  write only vertices
 *            GLM_FLAT    -  write facet normals
 *            GLM_SMOOTH  -  write vertex normals
 *            GLM_TEXTURE -  write texture coords
 *            GLM_FLAT and GLM_SMOOTH should not both be specified.
 */
GLvoid
glmWriteOBJ(Model* model, const char* filename, GLuint mode, const char* libname);

GLvoid
glmWriteMTL(Model* model, const char* modelpath, const char* mtllibname);


//#ifdef __cplusplus
//}
//#endif

#endif /*#ifndef _INC_GLM*/
