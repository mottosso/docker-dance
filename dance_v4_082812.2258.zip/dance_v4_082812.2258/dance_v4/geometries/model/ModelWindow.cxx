/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "ModelWindow.h"

#include "opengl.h"
#include "GeometryWindow.h"
#include <fltk/file_chooser.h>
#include <fltk/ask.h>
#include <fltk/string.h>
#include <fltk/filename.h>
#include "dance.h"


using namespace fltk;

ModelWindow::ModelWindow(Model* m, int x, int y, int w, int h, const char* name) : Group(x, y, w, h, name)
{
	model = m;
	this->begin();

	buttonLoad = new Button(10, 10, 60, 20, "Load");
	buttonLoad->callback(LoadCB, this);

	checkShowNormals = new CheckButton(100, 10, 80, 20, "Show Normals");
	checkShowNormals->callback(ShowNormalsCB, this);

	// obtain the panel from the DGeometry class
	groupGeom = new GeometryWindow(model, 10, 35, 300, 550, "");
	groupGeom->activate();

	this->end();

	this->updateGUI();
}

void ModelWindow::show()
{
	this->updateGUI();

	Group::show();
}

void ModelWindow::updateGUI()
{
	if (this->model->GetNumVertices() > 0)
	{
		buttonLoad->deactivate();
		groupGeom->activate();
		groupGeom->updateGUI();
		checkShowNormals->activate();
		checkShowNormals->value(this->model->isShowNormals());
	}
	else
	{
		buttonLoad->activate();
		groupGeom->deactivate();
		groupGeom->updateGUI();
		checkShowNormals->deactivate();
	}
}



void ModelWindow::LoadCB(fltk::Widget* widget, void* data)
{
	ModelWindow* window = (ModelWindow*) data;

	const char* file = fltk::file_chooser("Choose a geometry file to load:", "{*.wrl|*.3ds|*.obj}", NULL, true);
	if (file != NULL)
	{
		const char *ext = strrchr(file, '.');
		if (ext==NULL)
		{
			alert("File format not recognized.");
			return;
		}

		ext++;
		if (!filename_match(ext, "obj") && !filename_match(ext, "wrl") && !filename_match(ext, "vrml") && !filename_match(ext, "3ds")) {
			alert("Unsupported file format.");
			return;
		}

		int result;

		if ( filename_match(ext, "obj")) 
			result = window->model->ReadOBJ((char*) file);
		else if (filename_match(ext, "3ds")) 
			result = window->model->Read3DS((char*) file);
		else 
			result = window->model->ReadVRML((char*) file);

		if (result == DANCE_ERROR)
		{
			alert("Problem loading file '%s'.", file);
			return;
		}

		window->updateGUI();
	}
}

void ModelWindow::ShowNormalsCB(fltk::Widget* widget, void* data)
{
	ModelWindow* window = (ModelWindow*) data;

	window->model->setShowNormals(window->checkShowNormals->value());

	window->updateGUI();

	dance::Refresh();
}






