/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include <vector>

#include "dance.h"
#include "danceInterp.h"

#include "stuff.h"
#include "Model.h"


static char seps[]="[{,<>}=\"]";
static int FaceOffset;
static int NormalOffset;
static int VertexOffset;

typedef struct { float v[3]; } af3;

static std::vector<af3> tempV;


/* ReadVRML: Reads a model description from a VRML file.
 * Returns DANCE_OK or DANCE_ERROR
 *
 * filename - name of the file containing the VRML format data.  
 */
int
Model::ReadVRML(char* filename)
{
		std::string tok;
	int begin, end;

    /* open the file */
	if( filename == NULL ) 
	{
		danceInterp::OutputMessage("ReadVRML() failed: got a null pointer.") ;
		return DANCE_ERROR ;
	}

    std::ifstream file(filename);

	if (!file.is_open()) {
		danceInterp::OutputMessage("ReadVRML() failed: can't open data file \"%s\".\n",
            filename);
        return DANCE_ERROR;
    }
    
	danceInterp::OutputMessage("Loading in %s",filename);

    /* allocate a new model */
    this->pathname = strdup(filename);

	my_VRML_tokenizer(file, NULL);


	// Parse only geometry nodes until end-of-file
	FaceOffset = 0;
	NormalOffset = 0;
	VertexOffset = 0;
	
	while ((tok=my_VRML_tokenizer(file, seps))!="") 
	{
		if (tok=="Shape" || tok=="Separator") {
			GLMgroup *grp=addGroup("default");
			begin=this->numtriangles;
			if (DANCE_ERROR ==  parseShapeNode(file,-1)) {
				danceInterp::OutputMessage("Parse Error: in Shape Node.");
				file.close();
				return DANCE_ERROR;
			}
			end=this->numtriangles;
			grp->material=getMaterial();
			grp->numtriangles=end-begin;
			grp->triangles=(GLuint *)malloc(sizeof(GLuint)*grp->numtriangles);
			if (grp->triangles==NULL) {
				danceInterp::OutputMessage("Out of memory.");
				file.close();
				return DANCE_ERROR;
			}
			for (int i=0;i<grp->numtriangles;i++)
				grp->triangles[i]=begin+i;

		}
		else if (tok=="Transform") {
			if (DANCE_ERROR == parseTransform(file,0)) {
				danceInterp::OutputMessage("Parse Error: in Transform Node.");
				file.close();
				return DANCE_ERROR;
			}
		}
	} 

	file.close();
	tempV.clear();

/*
	// A successfully parsed VRML ensures all faces are triangles.
	bool allTriangles = true;
	for (int x = 0; x < this->m_NumFaces; x++)
	{
		if (m_Faces[x].numVertices!= 3)
		{
			allTriangles = false;
		}
		else
		{
			int y = 0;
		}
	}
	if (allTriangles)
		m_AllTriangles = TRUE;
	else
		m_AllTriangles = FALSE;

	danceInterp::OutputResult("Read in %d vertices, %d normals, %d faces\n",m_NumVertices, m_NumNormals, m_NumFaces);

	// Build edge list.
	BuildEdges();
	danceInterp::OutputResult("Number of edges found: %d\n",m_NumEdges);
*/
    return DANCE_OK;
}





// parseShapeNode:
int Model::parseShapeNode( std::ifstream &file, int level)
{
	std::string tok;
		
	if (m_noisy)
		danceInterp::OutputMessage("Parsing Shape node.\n");
	
	if (my_VRML_tokenizer(file, seps)!="{") {
		danceInterp::OutputMessage("Parse error: expected { for Shape.\n");
		return DANCE_ERROR;
	}

	while ((tok=my_VRML_tokenizer(file, seps))!="}") // Loop until end of shape node.
	{ 
		if (tok=="") {
			danceInterp::OutputMessage("Parse error: unexpected end of file.\n");
			return DANCE_ERROR;
		}

		if (tok=="geometry") {
			tok=my_VRML_tokenizer(file, seps);

			// Handle (well, ignore) DEF if present.
			if (tok=="DEF") {
				tok=my_VRML_tokenizer(file, seps); // Reads in label.
				tok=my_VRML_tokenizer(file, seps); // Reads next token.
			}

			if (tok=="IndexedFaceSet") {
				if (DANCE_ERROR == parseIndexedFaceSetNode(file,level)) {
					danceInterp::OutputMessage("Parse error: in IndexedFaceSet Node.\n");
					return DANCE_ERROR;
				}
			}

		}
		// Some VRML files have an IndexedFaceSet node without the geometry field
		// label. Example, files from Alias PowerAnimator.
		else if (tok=="IndexedFaceSet") {
			if (DANCE_ERROR == parseIndexedFaceSetNode(file,level)) {
				danceInterp::OutputMessage("Parse error: in IndexedFaceSet Node.\n");
				return DANCE_ERROR;
			}
		}
		else if (tok=="appearance") {
			// Parse until Appearance keyword found, or }
			tok=my_VRML_tokenizer(file, seps);
			while (tok!="Appearance" && tok!="}" && tok!="") 
				tok=my_VRML_tokenizer(file, seps);

			if (tok=="Appearance")
				if (DANCE_ERROR == parseAppearanceNode(file)) {
					danceInterp::OutputMessage("Parse error: in Appearance Node.\n");
					return DANCE_ERROR;
				}
		}
		else {
			danceInterp::OutputMessage("Found node: %s, doing nothing.\n",tok.c_str());
			if (DANCE_ERROR == parseNode(file)) { // Just verifies node is properly delimited.
					danceInterp::OutputMessage("Parse error: unbalanced Node.\n");
					return DANCE_ERROR;
			}
		}

		if( file.eof() ) 
		{
		    danceInterp::OutputMessage("Vrml: Unexpected end of file!") ;
		    return DANCE_ERROR ;
		}
	}

	if (tok!="}") {
		danceInterp::OutputMessage("Parse error: expected } for node.");
		return DANCE_ERROR;
	}


	if (m_noisy)
		danceInterp::OutputMessage("Finished parsing Shape node.");
	return DANCE_OK;
}


int Model::parseIndexedFaceSetNode( std::ifstream &file, int level) {
	danceInterp::OutputMessage("parseIndexedFaceSetNode");
	std::string tok;
	int colorPerVertex, normalPerVertex ;
	
	if (m_noisy) danceInterp::OutputMessage("Parsing IndexedFaceSet node.\n");
	
	// Build up transformation matrix (if applicable)
	double mat[16];
	if (level != -1) 
		BuildTransform(level,mat);
	

	if (my_VRML_tokenizer(file, seps)!="{") {
		danceInterp::OutputMessage("Parse error: expected { for IndexedFaceSet.\n");
		return -1;
	}


	tok=my_VRML_tokenizer(file, seps);

	// Some files store the information within a vertexProperty field.
	int vertexPropertyFlag = 0;
	if (tok=="vertexProperty") {
		vertexPropertyFlag = 1;
		if (my_VRML_tokenizer(file, seps)!="VertexProperty") {
			danceInterp::OutputMessage("Parse Error: Expected VertexProperty keyword.\n");
			return -1;
		}
		if (my_VRML_tokenizer(file, seps)!="{") {
			danceInterp::OutputMessage("Parse error: expected { for VertexProperty.\n");
			return -1;
		}
		tok=my_VRML_tokenizer(file, seps);
	}

	if (tok=="colorPerVertex") {
		colorPerVertex = (my_VRML_tokenizer(file, seps)=="TRUE");
		tok=my_VRML_tokenizer(file, seps);
	}

	if (tok=="normalPerVertex") {
		normalPerVertex = (my_VRML_tokenizer(file, seps)=="TRUE");
		tok=my_VRML_tokenizer(file, seps);
	}

  	int numVerticesRead = 0;
	int numFacesRead = 0;
	int numNormalsRead = 0;
	int numNormalFacesRead = 0;

	while (tok!="}" && tok!="") {
		if (tok=="coord" || tok=="vertex") {
		    if (-1 == (numVerticesRead = parseCoordinateNode(file,level,mat))) 
			return DANCE_ERROR;
		}
		else if (tok=="coordIndex") {
			if (-1 == (numFacesRead = parseCoordIndexField(file)))
				return DANCE_ERROR;
		}
		else if (tok=="normal") {
			if (-1 == (numNormalsRead = parseNormalNode(file,level,mat)))
				return DANCE_ERROR;
		}
		else if (tok=="normalIndex") {
			if (-1 == (numNormalFacesRead = parseNormalIndexField(file)))
				return DANCE_ERROR;
		}
		else if (tok=="texCoordIndex" || tok=="texCoord") 
			parseNode(file);		
		
	    tok=my_VRML_tokenizer(file, seps);
	}

	// Look for delimiter } of VertexProperty node if used.
	if (vertexPropertyFlag) {
		if (tok!="}") {
			danceInterp::OutputMessage("Parse error: expected } for VertexProperty node.\n");
			return -1;
		}
		tok=my_VRML_tokenizer(file, seps);
	}

	if (tok!="}") {
		danceInterp::OutputMessage("Parse error: expected } for IndexedFaceSet node.\n");
		return DANCE_ERROR;
	}

	if (numNormalFacesRead > 0 && numFacesRead > 0) {
		if (numNormalFacesRead != numFacesRead) {
			danceInterp::OutputMessage("VRML error: Number of faces do not match for coordinate index list and normal index list.\n");
		}
	}

	// Now add normals to face.
	VertexOffset += numVerticesRead;
	FaceOffset += numFacesRead;
	NormalOffset += numNormalsRead ;
	
//	danceInterp::OutputMessage("Finished parsing IndexedFaceSet node.\n");
	danceInterp::OutputMessage("%d vertices with %d faces.\n",numVerticesRead,numFacesRead);
	danceInterp::OutputMessage("%d normals with %d faces.\n",numNormalsRead,numNormalFacesRead);

	return DANCE_OK;
}



/* XXXXX: This function should check the balance of (), [], {}. Now it doesn't do it */
int Model::parseNode(std::ifstream &file) {
	std::string tok;
	char beginBracket = '[';
	char endBracket = ']';

	if (m_noisy)
		danceInterp::OutputMessage("Parsing node.\n");
	
	// Read until encounter { or [ bracket.

	tok=my_VRML_tokenizer(file, seps);
	while(tok!="{" && tok!="[" && tok!="")
		tok=my_VRML_tokenizer(file, seps);
	
	if (tok=="") {
		danceInterp::OutputMessage("Parse error: expected } or ] for node.\n");
		return DANCE_ERROR;
	}

	// Chooses to match brace or square brackets.
	if (tok=="{") {
		beginBracket='{';
		endBracket='}';
	}
	else if (tok=="[")  {
		beginBracket='[';
		endBracket=']';
	}

	// Ensures brackets match.
	int count = 1;
	while  (count != 0 && tok!="") {
		tok=my_VRML_tokenizer(file, seps);
		if (tok.c_str()[0]==endBracket) 
			count--;
		else if (tok.c_str()[0]==beginBracket) 
			count++;
	}

	if (count != 0) {
		danceInterp::OutputMessage("Parse error: expected } or ] for node.\n");
		return DANCE_ERROR;
	}

	if (m_noisy)
		danceInterp::OutputMessage("Finished parsing node.\n");
	return DANCE_OK;
}



void Model::BuildTransform(int level, double mat[16])
{
	double mat1[4][4], mat2[4][4];
	if (level < 0) {
		danceInterp::OutputMessage("BuildTransform called with negative level.");
		return;
	}

	if (level == 0) {
		memcpy(mat,m_TransformStack[level],16*sizeof(double));
		return;
	}

	memcpy(mat1,m_TransformStack[0],16*sizeof(double));
	for (int k = 1; k <= level; k++) {
		memcpy(mat2,m_TransformStack[k],16*sizeof(double));

		for (int i = 0; i < 4; i++)
			for (int j = 0; j < 4; j++) 
				mat[j*4+i] = mat1[0][i]*mat2[j][0] + mat1[1][i]*mat2[j][1] 
							+ mat1[2][i]*mat2[j][2] + mat1[3][i]*mat2[j][3];;
			
		memcpy(mat1,mat,16*sizeof(double));
	}
}


int Model::parseAppearanceNode(std::ifstream &file) {
	Material tmp;

	if (m_noisy)
		danceInterp::OutputMessage("Parsing appearance node.\n");

	if (tmp.read_vrml(file)==DANCE_ERROR)
		return DANCE_ERROR;
	else 
	{
		// We have successfully read a new material: add to the material manager
		char tempfilename[MAXPATHLENGTH];

		getFilename(pathname, true, tempfilename);
		char filename[MAXPATHLENGTH];
		eliminatespaces(tempfilename, filename);
		tmp.setMaterialName(filename);

		// this material should not be used (it is inherited from geometry). I use it only
		// temporarily (see ReadVRML)
		setMaterial(dance::MaterialManager->addMaterial(&tmp)) ;
		if (getMaterial()==NULL) {
			setMaterial(dance::MaterialManager->getMaterialbyName(filename)) ;
			if (getMaterial()==NULL) {
				danceInterp::OutputMessage("Error trying to load material %s. Using default material", filename);
				setMaterial(dance::MaterialManager->getDefaultMaterial()) ;
			} else 
				danceInterp::OutputMessage("Material %s already present in the database. Using the old material", filename);
		}
	}
	return DANCE_OK;
}

int Model::parseTransform( std::ifstream &file, int level) {
	std::string tok;
	double tmp[4];

	if (m_noisy)
		danceInterp::OutputMessage("Parsing Transform node at level %d.",level);

	if (my_VRML_tokenizer(file, seps)!="{") {
		danceInterp::OutputMessage("Parse error: expected { for transform.");
		return DANCE_ERROR;
	}

	// Initialize transform matrix to identity.
	for (int i = 0; i < 16; i++) {
		if (i == 0 || i == 5 || i == 10 || i == 15)
			m_TransformStack[level][i] = 1.0;
		else
			m_TransformStack[level][i] = 0.0;
	}

	tok=my_VRML_tokenizer(file, seps);

	// What happen with the }, --> strcmp(token,"},") != 0

	while (tok!="}" && tok!="") { // Loop until end of transform node.
		if (tok=="translation") {
			if (m_noisy)
				danceInterp::OutputMessage("Parsing translation field.");
	
			for (int i=0;i<3;i++) {
				if ((tok=my_VRML_tokenizer(file, seps))=="") {
					danceInterp::OutputMessage("Parse error reading transform\n"); 
					return DANCE_ERROR;
				}
				tmp[i]=atof(tok.c_str());
			}
			BuildTranslate(m_TransformStack[level],tmp[0], tmp[1], tmp[2]);
		}
		else if (tok=="rotation") {
			if (m_noisy)
				danceInterp::OutputMessage("Parsing rotation field.");
			for (int i=0;i<4;i++) {
				if ((tok=my_VRML_tokenizer(file, seps))=="") {
					danceInterp::OutputMessage("Parse error reading transform\n"); 
					return DANCE_ERROR;
				}
				tmp[i]=atof(tok.c_str());
			}
			BuildRotate(m_TransformStack[level],tmp[0], tmp[1], tmp[2], tmp[3]);
		}
		else if (tok=="scale") {
			if (m_noisy)
				danceInterp::OutputMessage("Parsing scale field.");

			for (int i=0;i<3;i++) {
				if ((tok=my_VRML_tokenizer(file, seps))=="") {
					danceInterp::OutputMessage("Parse error reading transform\n"); 
					return DANCE_ERROR;
				}
				tmp[i]=atof(tok.c_str());
			}
			BuildScale(m_TransformStack[level],tmp[0], tmp[1], tmp[2]);
		}
		else if (tok=="children") {
			if (DANCE_ERROR == parseChildren(file,level)) {
				danceInterp::OutputMessage("Parse Error: Children field in transform node.");
				return DANCE_ERROR;
			}
		}

		tok=my_VRML_tokenizer(file, seps);
	}
	return DANCE_OK;
}


void Model::BuildTranslate(double mat[16], double x, double y, double z) {
	mat[12]  = x;
	mat[13]  = y;
	mat[14]  = z;
}

void Model::BuildScale(double mat[16], double sx, double sy, double sz)
{
	mat[0] *= sx;
	mat[5] *= sy;
	mat[10] *= sz;
}

void Model::BuildRotate(double mat[16], double x, double y, double z, double rad)
{
	// Taken from VRML 97 SFRotation Field specification
	double c = cos(rad);
	double s = sin(rad);
	double t = 1 - c;
	mat[0] = t*x*x + c;
	mat[1] = t*x*y + s*z;
	mat[2] = t*x*z - s*y;
	mat[4] = t*x*y - s*z;
	mat[5] = t*y*y + c;
	mat[6] = t*y*z + s*x;
	mat[8] = t*x*z + s*y;
	mat[9] = t*y*z - s*x;
	mat[10] = t*z*z + c;
}


void Model::TransformPoint(double mat[16], double point[3], int normal)
{
	double newpoint[3];
	newpoint[0] = mat[0]*point[0] + mat[4]*point[1] + mat[8]*point[2];
	newpoint[1] = mat[1]*point[0] + mat[5]*point[1] + mat[9]*point[2];
	newpoint[2] = mat[2]*point[0] + mat[6]*point[1] + mat[10]*point[2];
	if (normal == 0) { // Add translation component.
		newpoint[0] += mat[3];
		newpoint[1] += mat[7];
		newpoint[2] += mat[11];
	}
	memcpy(point,newpoint,3*sizeof(double));
}


void Model::TransformPoint(double mat[16], float point[3], int normal)
{
	double newpoint[3];
	newpoint[0] = mat[0]*point[0] + mat[4]*point[1] + mat[8]*point[2];
	newpoint[1] = mat[1]*point[0] + mat[5]*point[1] + mat[9]*point[2];
	newpoint[2] = mat[2]*point[0] + mat[6]*point[1] + mat[10]*point[2];
	if (normal == 0) { // Add translation component.
		newpoint[0] += mat[3];
		newpoint[1] += mat[7];
		newpoint[2] += mat[11];
	}
	point[0]=(float)newpoint[0];
	point[1]=(float)newpoint[1];
	point[2]=(float)newpoint[2];

}


int Model::parseChildren(std::ifstream &file, int level) {
	std::string tok;

	if (m_noisy) danceInterp::OutputMessage("Parsing children node.");

	if (my_VRML_tokenizer(file, seps)!="[") {
		danceInterp::OutputMessage("Parse Error: children node expecting [");
		return DANCE_ERROR;
	}

	tok=my_VRML_tokenizer(file, seps);
	while (tok!="]" && tok!="") {
		if (tok=="Shape") {
			if (DANCE_ERROR == parseShapeNode(file,level)) {
				danceInterp::OutputMessage("Parse Error: in Shape Node.");
				return DANCE_ERROR;
			}
		}
		else if (tok=="Transform") {
			if (DANCE_ERROR == parseTransform(file,level+1)) {
				danceInterp::OutputMessage("Parse Error: in children's Transform node.");
				return DANCE_ERROR;
			}
		}
		tok=my_VRML_tokenizer(file, seps);
	}
	return DANCE_OK;

}





int Model::parseCoordinateNode( std::ifstream &file, int level, double mat[16]) {
	std::string tok;

	if (m_noisy) danceInterp::OutputMessage("Parsing Coordinate node.\n");

	// Encountered use of DEF for instantiation purposes. We will ignore it
	// for now, as we don't use it.
	tok=my_VRML_tokenizer(file, seps);
	if (tok=="DEF") {
		// Read in instance label to skip it.
		tok=my_VRML_tokenizer(file, seps);
		tok=my_VRML_tokenizer(file, seps);
	}

	// Some files use a coordinate node flag to store the vertices.
	int coordinateNodeFlag = 0;
	if (tok=="Coordinate") {
		coordinateNodeFlag = 1;
	    
	    if (my_VRML_tokenizer(file, seps)!="{") {
		   danceInterp::OutputMessage("Parse error: expected { for Coordinate node.\n");
		   return -1;
		}		
	}

	// Read until find first [ for vertices.
	do {
		tok=my_VRML_tokenizer(file, seps);
	} while (tok!="[" && tok!="");

	if (tok!="[") {
		danceInterp::OutputMessage("Parse error: expected [ for coordinate vertex list.\n");
		return -1;
	}

    	int numVerticesRead = 0;
	tok=my_VRML_tokenizer(file, seps);
	while (tok!="]" && tok!="") {
		if (tok!=",") {
			 // Read vertex values.
			double point[3];
			for (int i=0;i<3;i++) {
                point[i] = atof(tok.c_str());
				if (m_MirrorGeometry) point[i] = -1.0*point[i];

				tok=my_VRML_tokenizer(file, seps);
				if (tok=="") {
					danceInterp::OutputMessage("Parse Error: Expected ] for coordinate list.\n");
					return -1;
				}
			}
			if (level != -1)
				TransformPoint(mat,point,0);

			addVertex(point[0],point[1],point[2]);
			numVerticesRead++;
		}	
		else
			tok=my_VRML_tokenizer(file, seps);
	} // end of point parsing

	if (tok!="]") {
		danceInterp::OutputMessage("Parse Error: Expected ] for coordinate list.\n");
		return -1;
	}

	if (coordinateNodeFlag) {
		if (my_VRML_tokenizer(file, seps)!="}")  {
			danceInterp::OutputMessage("Parse Error: Expected } for Coordinate node.\n");
			return -1;
		}
	}

	return numVerticesRead;
}


int Model::parseCoordIndexField( std::ifstream &file) {
	std::string tok;

	if (m_noisy) 
		danceInterp::OutputMessage("Parsing CoordIndex Field.\n");
    
	if (my_VRML_tokenizer(file, seps)!="[") {
		danceInterp::OutputMessage("Parse error: expected [ for CoordIndex.\n");
		return -1;
	}


	int index = 0;
	int numVertices = 0;
	int vertIndex[MAX_VERT_FACE];
	int numFacesRead = 0;

	tok=my_VRML_tokenizer(file, seps);
	while (tok!="]" && tok!="") {
		// There is a chance that a token may contain a list of numbers
		// delimited by commas
	
		if (tok==",")
			tok=my_VRML_tokenizer(file, seps);

		index=atoi(tok.c_str());
		if (index == -1) {
			if( numVertices < 3 )
				continue ;
			// get read of triangles with same vertices
			if( (vertIndex[0] == vertIndex[1]) ||
				(vertIndex[1] == vertIndex[2]) ||
				(vertIndex[2] == vertIndex[0]) )
				continue ;

			if (m_MirrorGeometry) {
				// flip all vertices in vertIndex.
				int tempVert[MAX_VERT_FACE];
				for (int i = 0; i < numVertices; i++)
					tempVert[i] = vertIndex[numVertices-1-i];
				memcpy(vertIndex,tempVert,numVertices*sizeof(int));
			}

			addFace(FaceOffset+numFacesRead);
			addCoordsToFace(FaceOffset+numFacesRead,vertIndex);
			numFacesRead++;
	
			numVertices = 0;
		}
        else if (numVertices < MAX_VERT_FACE) 
				vertIndex[numVertices++] = VertexOffset+index;
        else {
            danceInterp::OutputMessage(
			    "Parse error: Face encountered which exceeds maximum vertices.\n");
            return DANCE_ERROR;
		}
		tok=my_VRML_tokenizer(file, seps);
	} // end while


	if (tok!="]") {
		danceInterp::OutputMessage("Parse error: expected ] for CoordIndex.\n");
		return DANCE_ERROR;
	}
	return numFacesRead;
}


int Model::parseNormalNode( std::ifstream &file, int level, double mat[16]) {
	std::string tok;

	tok=my_VRML_tokenizer(file, seps); 

	// Some files use a normal node flag to store the normals
	int normalNodeFlag = 0;
	if (tok=="Normal") {
		normalNodeFlag = 1;
	    if (my_VRML_tokenizer(file, seps)!="{") {
		   danceInterp::OutputMessage("Parse error: expected { for Normal node.\n");
		   return -1;
		}		
	}

	// Read until find first [ for normals.
	while (tok!="[" && tok!="") {
		tok=my_VRML_tokenizer(file, seps); 
    }

	if (tok!="[") {
		danceInterp::OutputMessage("Parse error: expected [ for normal list.\n");
		return -1;
	}

    int numNormalsRead = 0;
	tok=my_VRML_tokenizer(file, seps); 
	while (tok!="]" && tok!="") {
		if (tok!=",") {
			 // Read normal values.
			//float normal[3];
			af3 normal;
			for (int i=0;i<3;i++) {
				normal.v[i] = (float)atof(tok.c_str());
				if ((tok=my_VRML_tokenizer(file, seps))=="") {
					danceInterp::OutputMessage("Parse error reading transform\n"); 
					return DANCE_ERROR;
				}
			}

			if (level != -1)
				TransformPoint(mat,normal.v,1);

			tempV.push_back(normal);
			//addNormal(normal[0],normal[1],normal[2]);
			numNormalsRead++;
		} 
		else 
			tok=my_VRML_tokenizer(file, seps); 
	} // end of point parsing

	if (tok!="]") {
		danceInterp::OutputMessage("Parse Error: Expected ] for normal list.\n");
		return -1;
	}

	// Looks for delimiter } if a Normal node was encountered.
	if (normalNodeFlag) {
		if (my_VRML_tokenizer(file, seps)!="}") {
			danceInterp::OutputMessage("Parse Error: Expected } for Normal node.\n");
			return -1;
		}
	}

	return numNormalsRead;
}


int Model::parseNormalIndexField(std::ifstream &file) {
	std::string tok;

	if (m_noisy) 
		danceInterp::OutputMessage("Parsing Normal index field.\n");

	if (my_VRML_tokenizer(file, seps)!="[")  {
		danceInterp::OutputMessage("Parse error: expected [ for normalIndex.\n");
		return -1;
	}


	int index = 0;
	int numVertices = 0;
	int vertIndex[MAX_VERT_FACE];
	int faceIndex = 0;
	int numFacesRead = 0;

	tok=my_VRML_tokenizer(file, seps);
	while (tok!="]"  && tok!="") {
		if (tok==",") 
			tok=my_VRML_tokenizer(file, seps);

		index=atoi(tok.c_str());
		if (index == -1) {
			// This code guarantees all faces are triangles.
			if (numVertices == 3) {
				//addFace(FaceOffset+faceIndex);
				//addNormalToFace(FaceOffset+faceIndex,vertIndex);
				// here we will rewrite each normal several times...
				for (int j=0; j<3; j++)
					setNormal(triangles[FaceOffset+faceIndex].vindices[j], 
						tempV[vertIndex[j]].v[0], tempV[vertIndex[j]].v[1], tempV[vertIndex[j]].v[2]);

				numFacesRead++;
				faceIndex++;
			}
			else {
				int numTriangles = numVertices - 2;
				// First index is common to all triangles. We must ensure
				// the vertex order is counter-clockwise for front facing.
				int triVertices[3];
				triVertices[0] = vertIndex[0];
				for (int i = 1; i <= numTriangles; i++) {
					triVertices[1] = vertIndex[i];
					triVertices[2] = vertIndex[i+1];
					//addFace(FaceOffset+faceIndex);
					//addNormalToFace(FaceOffset+faceIndex,triVertices);
					for (int j=0; j<3; j++)
						setNormal(triangles[FaceOffset+faceIndex].vindices[j], 
							tempV[vertIndex[j]].v[0], tempV[vertIndex[j]*3].v[1], tempV[vertIndex[j]*3].v[2]);

					numFacesRead++;
					faceIndex++;
				}
			}
			numVertices = 0;
		}
        else if (numVertices < MAX_VERT_FACE) 
			vertIndex[numVertices++] = NormalOffset+index;
        else {
            danceInterp::OutputMessage("Parse error: Face encountered which exceeds maximum vertices.\n");
              	return -1;
       	}
		tok=my_VRML_tokenizer(file, seps);
	}

	if (tok!="]") {
		danceInterp::OutputMessage("Parse error: expected ] for normalIndex.\n");
		return -1;
	}
	return numFacesRead;
}

