/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "dance.h"
#include "danceInterp.h"

#include <fltk/ask.h>
#include <vector>

#include "Model.h"
#include "OBJ.h"
#include "stuff.h"


static std::vector<float> tempV;


/* ReadOBJ: Reads a model description from a Wavefront .OBJ file.
 * Returns DANCE_OK or DANCE_ERROR
 *
 * filename - name of the file containing the Wavefront .OBJ format data.  
 */
int
Model::ReadOBJ(char* filename)
{
    FILE*   file;
    
    /* open the file */
	if( filename == NULL ) 
	{
		danceInterp::OutputMessage("ReadOBJ() failed: got a null pointer.") ;
		return DANCE_ERROR ;
	}
    file = fopen(filename, "r");
    if (!file) {
		danceInterp::OutputMessage("ReadOBJ() failed: can't open data file \"%s\".\n",
            filename);
        return DANCE_ERROR;
    }
    
    /* allocate a new model */
    this->pathname    = strdup(filename);
        
    /* make a first pass through the file to get a count of the number
    of vertices, normals, texcoords & triangles */
    if (glmFirstPass(this, file)) return DANCE_ERROR;
    

    /* allocate memory */
    this->vertices = (double*)malloc(sizeof(double) *
        3 * (this->numvertices + 1));
	this->maxNumVertices = this->numvertices + 1;

    this->normals = (GLfloat*)malloc(sizeof(GLfloat) *
        3 * (this->numvertices + 1));

	this->triangles = (GLMtriangle*)malloc(sizeof(GLMtriangle) *
        this->numtriangles);
	this->maxNumTriangles = this->numtriangles;

    if (this->numtexcoords) {
        this->texcoords = (GLfloat*)malloc(sizeof(GLfloat) *
            2 * (this->numtexcoords + 1));
		this->maxNumTexCoords = this->numtexcoords + 1;
    }
    
    /* rewind to beginning of file and read in the data this pass */
    rewind(file);
    
    glmSecondPass(this, file);
    
    /* close the file */
    fclose(file);

	tempV.clear();

    return DANCE_OK;
}



/* glmFirstPass: first pass at a Wavefront OBJ file that gets all the
 * statistics of the model (such as #vertices, #normals, etc)
 *
 * model - properly initialized Model structure
 * file  - (fopen'd) file descriptor 
 */
static int
glmFirstPass(Model* model, FILE* file) 
{
    GLuint  numvertices;        /* number of vertices in model */
    GLuint  numnormals;         /* number of normals in model */
    GLuint  numtexcoords;       /* number of texcoords in model */
    GLuint  numtriangles;       /* number of triangles in model */
    GLMgroup* group;            /* current group */
    unsigned    v, n, t;
    char        buf[128];
    
    /* make a default group */
    group = model->addGroup("default");
    
    numvertices = numnormals = numtexcoords = numtriangles = 0;
    while(fscanf(file, "%s", buf) != EOF) {
        switch(buf[0]) {
        case '#':               /* comment */
            /* eat up rest of line */
            fgets(buf, sizeof(buf), file);
            break;
        case 'v':               /* v, vn, vt */
            switch(buf[1]) {
            case '\0':          /* vertex */
                /* eat up rest of line */
                fgets(buf, sizeof(buf), file);
                numvertices++;
                break;
            case 'n':           /* normal */
                /* eat up rest of line */
                fgets(buf, sizeof(buf), file);
                numnormals++;
                break;
            case 't':           /* texcoord */
                /* eat up rest of line */
                fgets(buf, sizeof(buf), file);
                numtexcoords++;
                break;
            default:
                printf("glmFirstPass(): Unknown token \"%s\".\n", buf);
                //exit(1);
				return -1;
                break;
            }
            break;
            case 'm':
				{
				char buffer[MAXPATHLENGTH];

                fgets(buf, sizeof(buf), file);
                sscanf(buf, "%s %s", buf, buf);
                model->mtllibname = strdup(buf);
				strcpy(buffer, model->pathname);

				// 
				removeFilename(buffer);
				strcat(buffer, buf);


				if (dance::MaterialManager->load(buffer, WAVEFRONT_MTL)) {
					fltk::alert("Material file %s could not be loaded", buf);
					return -1;
				}
				//glmReadMTL(model, buf);
				}
                break;
            case 'u':
                /* eat up rest of line */
				fgets(buf, sizeof(buf), file);
				if (group->numtriangles>0) {
					// We are changing the material without changing the group. 
					// Open a new group
					sscanf(buf, "%s", buf);
					group = model->addGroup(buf);
					if (group==NULL) {
						fltk::alert("Memory full");
						exit(-1);
					}
				}
                break;
            case 'g':               /* group */
                /* eat up rest of line */
                fgets(buf, sizeof(buf), file);
#if SINGLE_STRING_GROUP_NAMES
                sscanf(buf, "%s", buf);
#else
                buf[strlen(buf)-1] = '\0';  /* nuke '\n' */
#endif
                group = model->addGroup(buf);
				if (group==NULL) {
					fltk::alert("Memory full");
					exit(-1);
				}
                break;
            case 'f':               /* face */
                v = n = t = 0;
                fscanf(file, "%s", buf);
                /* can be one of %d, %d//%d, %d/%d, %d/%d/%d %d//%d */
                if (strstr(buf, "//")) {
                    /* v//n */
                    sscanf(buf, "%d//%d", &v, &n);
                    fscanf(file, "%d//%d", &v, &n);
                    fscanf(file, "%d//%d", &v, &n);
                    numtriangles++;
                    group->numtriangles++;
                    while(fscanf(file, "%d//%d", &v, &n) > 0) {
                        numtriangles++;
                        group->numtriangles++;
                    }
                } else if (sscanf(buf, "%d/%d/%d", &v, &t, &n) == 3) {
                    /* v/t/n */
                    fscanf(file, "%d/%d/%d", &v, &t, &n);
                    fscanf(file, "%d/%d/%d", &v, &t, &n);
                    numtriangles++;
                    group->numtriangles++;
                    while(fscanf(file, "%d/%d/%d", &v, &t, &n) > 0) {
                        numtriangles++;
                        group->numtriangles++;
                    }
                } else if (sscanf(buf, "%d/%d", &v, &t) == 2) {
                    /* v/t */
                    fscanf(file, "%d/%d", &v, &t);
                    fscanf(file, "%d/%d", &v, &t);
                    numtriangles++;
                    group->numtriangles++;
                    while(fscanf(file, "%d/%d", &v, &t) > 0) {
                        numtriangles++;
                        group->numtriangles++;
                    }
                } else {
                    /* v */
                    fscanf(file, "%d", &v);
                    fscanf(file, "%d", &v);
                    numtriangles++;
                    group->numtriangles++;
                    while(fscanf(file, "%d", &v) > 0) {
                        numtriangles++;
                        group->numtriangles++;
                    }
                }
                break;
                
            default:
                /* eat up rest of line */
                fgets(buf, sizeof(buf), file);
                break;
        }
  }
  
  /* set the stats in the model structure */
  model->numvertices  = numvertices;
  model->numtexcoords = numtexcoords;
  model->numtriangles = numtriangles;
  if( numnormals == 0 ) model->m_NoNormalsRead = 1 ;
  else model->m_NoNormalsRead = 0 ;
  
  /* allocate memory for the triangles in each group */
  group = model->groups;
  while(group) {
      group->triangles = (GLuint*)malloc(sizeof(GLuint) * group->numtriangles);
      group->numtriangles = 0;
      group = group->next;
  }


  return 0;
}




/* glmSecondPass: second pass at a Wavefront OBJ file that gets all
 * the data.
 *
 * model - properly initialized Model structure
 * file  - (fopen'd) file descriptor 
 */
static GLvoid
glmSecondPass(Model* model, FILE* file) 
{
    GLuint  numvertices;        /* number of vertices in model */
    GLuint  numnormals;         /* number of normals in model */
    GLuint  numtexcoords;       /* number of texcoords in model */
    GLuint  numtriangles;       /* number of triangles in model */
    double*    vertices;           /* array of vertices  */
    GLfloat   normals[3];            /* array of normals */
    GLfloat*    texcoords;          /* array of texture coordinates */
    GLMgroup* group;            /* current group pointer */
    Material *material;           /* current material */
    GLuint  v, n, t;
    char        buf[128];
    
    /* set the pointer shortcuts */
    vertices       = model->vertices;
    texcoords    = model->texcoords;
    group      = model->groups;
    
    /* on the second pass through the file, read all the data into the
    allocated arrays */
    numvertices = numnormals = numtexcoords = 0;
    numtriangles = 0;
	material = dance::MaterialManager->getDefaultMaterial();

    while(fscanf(file, "%s", buf) != EOF) {

#ifdef _DEBUG
		if (!group) {
			fltk::alert("GLMSECONDPASS DOES NOT WORK");
			exit(-1);
		}
#endif


		switch(buf[0]) {
        case '#':               /* comment */
            /* eat up rest of line */
            fgets(buf, sizeof(buf), file);
            break;
        case 'v':               /* v, vn, vt */
            switch(buf[1]) {
            case '\0':          /* vertex */
                fscanf(file, "%lf %lf %lf", 
                    &vertices[3 * numvertices + 0], 
                    &vertices[3 * numvertices + 1], 
                    &vertices[3 * numvertices + 2]);
                numvertices++;
                break;
            case 'n':           /* normal */
                fscanf(file, "%f %f %f", 
                    &normals[0],
                    &normals[1], 
                    &normals[2]);
				tempV.push_back(normals[0]);
				tempV.push_back(normals[1]);
				tempV.push_back(normals[2]);

				numnormals++;
                break;
            case 't':           /* texcoord */
                fscanf(file, "%f %f", 
                    &texcoords[2 * numtexcoords + 0],
                    &texcoords[2 * numtexcoords + 1]);
                numtexcoords++;
                break;
            }
            break;
            case 'u':
				{
					Material *tmp;
	
					fgets(buf, sizeof(buf), file);
					if (group->numtriangles>0) 
						group=group->next;

					sscanf(buf, "%s %s", buf, buf);
					tmp=dance::MaterialManager->getMaterialbyName(buf);   //glmFindMaterial(model, buf);
					if (tmp == NULL) 
						danceInterp::OutputMessage("Material %s used by no defined. Using the default", buf);
					else 
						group->material = material = tmp;
                break;
				}
            case 'g':               /* group */
                /* eat up rest of line */
                fgets(buf, sizeof(buf), file);
				group=group->next;
				//group = glmFindGroup(model, buf);
                group->material = material;
                break;
            case 'f':               /* face */
                v = n = t = 0;
                fscanf(file, "%s", buf);
                /* can be one of %d, %d//%d, %d/%d, %d/%d/%d %d//%d */
                if (strstr(buf, "//")) {
                    /* v//n */
                    sscanf(buf, "%d//%d", &v, &n);
					// In memory, indices start in 0
					 v--; n--;
					T(numtriangles).vindices[0] = v;
                    //T(numtriangles).nindices[0] = n;
					model->setNormal(v, tempV[3*n],tempV[3*n+1],tempV[3*n+2]);
                    fscanf(file, "%d//%d", &v, &n);
					// In memory, indices start in 0
					v--; n--;
                    T(numtriangles).vindices[1] = v;
                    //T(numtriangles).nindices[1] = n;
					model->setNormal(v, tempV[3*n],tempV[3*n+1],tempV[3*n+2]);
                    fscanf(file, "%d//%d", &v, &n);
					// In memory, indices start in 0
					 v--; n--;
                    T(numtriangles).vindices[2] = v;
					model->setNormal(v, tempV[3*n],tempV[3*n+1],tempV[3*n+2]);
//                    T(numtriangles).nindices[2] = n;
                    group->triangles[group->numtriangles++] = numtriangles;
                    numtriangles++;
                    while(fscanf(file, "%d//%d", &v, &n) > 0) {
						// In memory, indices start in 0
					v--; n--;
                        T(numtriangles).vindices[0] = T(numtriangles-1).vindices[0];
                        T(numtriangles).vindices[1] = T(numtriangles-1).vindices[2];
                        T(numtriangles).vindices[2] = v;

						//T(numtriangles).nindices[0] = T(numtriangles-1).nindices[0];
                        //T(numtriangles).nindices[1] = T(numtriangles-1).nindices[2];
//                        T(numtriangles).nindices[2] = n;
						model->setNormal(v, tempV[3*n],tempV[3*n+1],tempV[3*n+2]);
                        group->triangles[group->numtriangles++] = numtriangles;
                        numtriangles++;
                    }
                } else if (sscanf(buf, "%d/%d/%d", &v, &t, &n) == 3) {
                    /* v/t/n */
					// In memory, indices start in 0
					 v--; n--; t--;
                    T(numtriangles).vindices[0] = v;
                    T(numtriangles).tindices[0] = t;
                    //T(numtriangles).nindices[0] = n;
					model->setNormal(v, tempV[3*n],tempV[3*n+1],tempV[3*n+2]);
                    fscanf(file, "%d/%d/%d", &v, &t, &n);
					// In memory, indices start in 0
					 v--; n--; t--;
                    T(numtriangles).vindices[1] = v;
                    T(numtriangles).tindices[1] = t;
                    //T(numtriangles).nindices[1] = n;
					model->setNormal(v, tempV[3*n],tempV[3*n+1],tempV[3*n+2]);
                    fscanf(file, "%d/%d/%d", &v, &t, &n);
					// In memory, indices start in 0
					 v--; n--; t--;
                    T(numtriangles).vindices[2] = v;
                    T(numtriangles).tindices[2] = t;
                    //T(numtriangles).nindices[2] = n;
					model->setNormal(v, tempV[3*n],tempV[3*n+1],tempV[3*n+2]);
                    group->triangles[group->numtriangles++] = numtriangles;
                    numtriangles++;
                    while(fscanf(file, "%d/%d/%d", &v, &t, &n) > 0) {
						// In memory, indices start in 0
						 v--; n--; t--;
                        T(numtriangles).vindices[0] = T(numtriangles-1).vindices[0];
                        T(numtriangles).vindices[1] = T(numtriangles-1).vindices[2];
                        T(numtriangles).vindices[2] = v;

                        T(numtriangles).tindices[0] = T(numtriangles-1).tindices[0];
                        T(numtriangles).tindices[1] = T(numtriangles-1).tindices[2];
                        T(numtriangles).tindices[2] = t;

//						T(numtriangles).nindices[0] = T(numtriangles-1).nindices[0];
  //                      T(numtriangles).nindices[1] = T(numtriangles-1).nindices[2];
                        //T(numtriangles).nindices[2] = n;
						model->setNormal(v, tempV[3*n],tempV[3*n+1],tempV[3*n+2]);
						group->triangles[group->numtriangles++] = numtriangles;
                        numtriangles++;
                    }
                } else if (sscanf(buf, "%d/%d", &v, &t) == 2) {
                    /* v/t */
					// In memory, indices start in 0
					 v--; t--;
                    T(numtriangles).vindices[0] = v;
                    T(numtriangles).tindices[0] = t;
                    fscanf(file, "%d/%d", &v, &t);
					// In memory, indices start in 0
					 v--; t--;
                    T(numtriangles).vindices[1] = v;
                    T(numtriangles).tindices[1] = t;
                    fscanf(file, "%d/%d", &v, &t);
					// In memory, indices start in 0
					 v--; t--;
                    T(numtriangles).vindices[2] = v;
                    T(numtriangles).tindices[2] = t;
                    group->triangles[group->numtriangles++] = numtriangles;
                    numtriangles++;
                    while(fscanf(file, "%d/%d", &v, &t) > 0) {
						// In memory, indices start in 0
					 	v--; t--;
                        T(numtriangles).vindices[0] = T(numtriangles-1).vindices[0];
                        T(numtriangles).tindices[0] = T(numtriangles-1).tindices[0];
                        T(numtriangles).vindices[1] = T(numtriangles-1).vindices[2];
                        T(numtriangles).tindices[1] = T(numtriangles-1).tindices[2];
                        T(numtriangles).vindices[2] = v;
                        T(numtriangles).tindices[2] = t;
                        group->triangles[group->numtriangles++] = numtriangles;
                        numtriangles++;
                    }
                } else {
                    /* v */
                    sscanf(buf, "%d", &v);
					// In memory, indices start in 0
					 v--; 
                    T(numtriangles).vindices[0] = v;
                    fscanf(file, "%d", &v);
					// In memory, indices start in 0
				 	v--; 
                    T(numtriangles).vindices[1] = v;
                    fscanf(file, "%d", &v);
					// In memory, indices start in 0
					 v--; 
                    T(numtriangles).vindices[2] = v;
                    group->triangles[group->numtriangles++] = numtriangles;
                    numtriangles++;
                    while(fscanf(file, "%d", &v) > 0) {
						// In memory, indices start in 0
					 	v--; 
                        T(numtriangles).vindices[0] = T(numtriangles-1).vindices[0];
                        T(numtriangles).vindices[1] = T(numtriangles-1).vindices[2];
                        T(numtriangles).vindices[2] = v;
                        group->triangles[group->numtriangles++] = numtriangles;
                        numtriangles++;
                    }
                }
                break;
                
            default:
                /* eat up rest of line */
                fgets(buf, sizeof(buf), file);
                break;
    }
  }

  GLMgroup* curGroup = model->groups;
  while (curGroup != NULL)
  {
	 //danceInterp::OutputMessage("read group %s material %s",  curGroup->name, curGroup->material->getMaterialName()) ;
	 curGroup = curGroup->next;
  }

#if 0
  /* announce the memory requirements */
  danceInterp::OutputMessage(" Memory: %d bytes\n",
      numvertices  * 3*sizeof(GLfloat) +
      numnormals   * 3*sizeof(GLfloat) * (numnormals ? 1 : 0) +
      numtexcoords * 3*sizeof(GLfloat) * (numtexcoords ? 1 : 0) +
      numtriangles * sizeof(GLMtriangle));
#endif
}

