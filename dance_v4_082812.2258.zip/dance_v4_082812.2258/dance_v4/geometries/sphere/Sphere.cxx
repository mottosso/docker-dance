/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed:
*/

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "Sphere.h"
#include "danceInterp.h"
#include "dance.h"

PlugIn* Proxy()
{
	return new Sphere();
}

PlugIn* Sphere::create(int argc, char **argv)
{
	return new Sphere();
}


Sphere::Sphere(): DGeometry()
{
	this->setNumSubdivisions(20);
	
	qobj=gluNewQuadric();
	gluQuadricDrawStyle(qobj, GLU_FILL);
	gluQuadricNormals(qobj, GLU_SMOOTH);
	gluQuadricTexture(qobj, GL_TRUE);

	setIdentMat(&appliedMatrix[0][0], 4);
}

Sphere::~Sphere() {
	gluDeleteQuadric(qobj);
}


void Sphere::output(int mode)
{
	DGeometry::output(mode);

	Material* material = NULL ;
	if( mode & LDISPLAY_COMPUTE_SHADOW_MAP) 
	{
		setUpShadowMapPass1() ;
	}
	else if( mode & LDISPLAY_USE_SHADOW_MAP) 
	{
		setUpShadowMapPass3() ;
	}
	else if( mode & LDISPLAY_SHADOW_MAP_PASS4) 
	{
		setUpShadowMapPass4() ;
		material = this->getMaterial();
		if ( material != NULL)
		{
			material->setOpenGLMaterial(dance::shadowAlpha);
		}
		else
		{
			danceInterp::OutputMessage("%s has no material. Why?. It won't be shown", this->getName());
			return;
		}
	}
	else // set up material
	{
		material = this->getMaterial();
		if ( material != NULL)
		{
			material->setOpenGLMaterial();
		}
		else
		{
			danceInterp::OutputMessage("%s has no material. Why?. It won't be shown", this->getName());
			return;
		}
	}

	glPushAttrib(GL_LIGHTING_BIT);


	glPushMatrix();
	if (this->useTransMatrix())
	{
		double matrix[4][4];
		this->getTransMatrix(matrix);
		glMultMatrixd(&matrix[0][0]);
	}
	if ((mode & LDISPLAY_SOLID) && this->isShowSolid()) {
		if (material && material->has_texture()) {
			gluSphere(qobj, 1, this->getNumSubdivisions(), this->getNumSubdivisions());
		} else 
			glutSolidSphere(1, this->getNumSubdivisions(), this->getNumSubdivisions());
	}
	else if ((mode & LDISPLAY_WIRE) || this->isShowMesh() || this->isShowVertices())
	{
		glDisable(GL_LIGHTING);
		glutWireSphere(1, 10, 10);
	}
	
	

	glPopMatrix();

	glPopAttrib();

	if( mode & LDISPLAY_COMPUTE_SHADOW_MAP) 
	{
		cleanUpAfterShadowMapPass1() ;
	}
}

void Sphere::setNumSubdivisions(int num)
{
	numSubdivisions = num;
}

int Sphere::getNumSubdivisions()
{
	return numSubdivisions;
}

int Sphere::commandPlugIn(int argc, char **argv)
{
	int ret = DGeometry::commandPlugIn(argc, argv);
	if (ret != DANCE_CONTINUE)
		return ret;

	if (strcmp(argv[0], "subdivisions") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: geometry sphere subdivisions <num>");
			return DANCE_ERROR;
		}
		else
		{
			int num = atoi(argv[1]);
			this->setNumSubdivisions(num);
			danceInterp::OutputMessage("Sphere %s now has  %d subdivisions.", this->getName(), this->getNumSubdivisions());
			return DANCE_OK;
		}
	}

	return DANCE_OK;
}

BoundingBox* Sphere::calcBoundingBox(BoundingBox* box)
{

	// put a box around a unit sphere and then multiply
	// by the transformation matrix

	Vector points[8];
	setVector(points[0], 1.0, 1.0, 1.0);
	setVector(points[1], 1.0, -1.0, 1.0);
	setVector(points[2], 1.0, 1.0, -1.0);
	setVector(points[3], 1.0, -1.0, -1.0);
	setVector(points[4], -1.0, 1.0, 1.0);
	setVector(points[5], -1.0, -1.0, 1.0);
	setVector(points[6], -1.0, 1.0, -1.0);
	setVector(points[7], -1.0, -1.0, -1.0);

    // a general bounding box
	m_BoundingBox.xMin = MAXFLOAT; 
	m_BoundingBox.xMax = MINFLOAT;;
	m_BoundingBox.yMin = MAXFLOAT;
	m_BoundingBox.yMax = MINFLOAT;
	m_BoundingBox.zMin = MAXFLOAT;
	m_BoundingBox.zMax = MINFLOAT;

	double matrix[4][4];
	this->getTransMatrix(matrix);

	for( int i = 0 ; i <  8 ; i++ )
	{
		Vector curPoint;
		VecCopy(curPoint, points[i]);
		if (this->useTransMatrix())
			transformPoint_mat(curPoint, matrix);

		if (curPoint[0] < m_BoundingBox.xMin)
			m_BoundingBox.xMin = curPoint[0];
		if (curPoint[0] > m_BoundingBox.xMax)
			m_BoundingBox.xMax = curPoint[0];

		if (curPoint[1] < m_BoundingBox.yMin)
			m_BoundingBox.yMin = curPoint[1];
		if (curPoint[1] > m_BoundingBox.yMax)
			m_BoundingBox.yMax = curPoint[1];

		if (curPoint[2] < m_BoundingBox.zMin)
			m_BoundingBox.zMin = curPoint[2];
		if (curPoint[2] > m_BoundingBox.zMax)
			m_BoundingBox.zMax = curPoint[2];
	}
	if (box)
		box->copy(&m_BoundingBox);

	return &m_BoundingBox;
}

void Sphere::isAOGeom(bool val)
{
	this->aoGeom = val;
}

bool Sphere::getAOGeom()
{
	return this->aoGeom;
}
void Sphere::render(int argc, char ** argv, std::ofstream & file)
{
	int i, j;

	if (argc > 0 && strcmp(argv[0],"povray") == 0)
	{
#ifdef _DEBUG
		file << "/* Sphere: \n";
		write_properties(file);
		file << "numSubdivisions: " << numSubdivisions << "\n";
		file << "*/\n\n";
#endif
		std::ofstream* objfile = dance::AllRenderers->getObjectFileStream();
		std::string spherename = this->getName();
		if (spherename == "sphere")
		{
			spherename.append("_");
		}
		*objfile << "#declare " << spherename.c_str() << " = \n";
        *objfile << "sphere {\n  <0, 0, 0>, 1\n";

		*objfile << "  texture {";
		
		// 'default' is a reserved word in povray
		if (m_material->getTexture() == NULL)
		{
			*objfile << m_material->getSafeMaterialName();
			if (!strcmp("default", getMaterial()->getSafeMaterialName()))
				*objfile << "_}\n";
			else
				*objfile << "}\n";
		}
		else
		{
			*objfile << "\n  ";
			m_material->getTexture()->write_texture_povray(*objfile, "map_type 1", "rotate <90, 0, -90>");
		}
		
		*objfile << "}\n";


		//.pov file
		if (this->isVisible() == false)
			return;
		
		file << "object {" << spherename.c_str() << "\n";
		

		file << "matrix\n  <";
		for (j=0; j<4; j++) {
			for (i=0; i<3; i++) 
				file << m_transMatrix[j][i] << ((j==3 && i==2) ? ">" : ",");
			file << (j==3 ? "\n" : "\n  ");
		}
		file << "#ifdef (SETMATRIX2)\n";
		file << "transform SETMATRIX2\n";
		file << "#end\n";
		file << "#ifdef (SETMATRIX)\n";
		file << "transform SETMATRIX\n";
		file << "#end\n";

		file << "}\n\n";



	}
}

void Sphere::applyTransMatrix()
{
	double matrix[4][4];
	this->getTransMatrix(matrix);

	double temp[4][4];
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			temp[r][c] = appliedMatrix[r][c];
	
	//multArray(&appliedMatrix[0][0], &temp[0][0], &matrix[0][0], 4, 4, 4);
	multArray4x4(appliedMatrix, temp, matrix);
}

int Sphere::createMonitorPoints(int npoints, bool random)
{
    AllocateMonitorPoints(npoints);

	double transMatrix[4][4];
	this->getTransMatrix(transMatrix);
	
	if (true) // always use random (until someone programs a good spherical sampling routine)
	{
		// take vertices at random
		// the downside to using this method is that repeated simulations might not give
		// you the same results since the collision points will be different every time
		for (int x = 0; x < npoints; x++)
		{
			// pick a random x, y, z value and normalize it
			Vector point;
	#ifdef WIN32
			DWORD curTime = GetTickCount();
			for (int i = 0; i < 3; i++)
			{
				point[i] = rand()/((double)RAND_MAX + 1);
				// make each positive or negative
				double posneg = rand()/((double)RAND_MAX + 1);
				if (posneg < .5)
					point[i] = -point[i];
			}

	#else
			timeval curTime;
			gettimeofday(&curTime, NULL);
			for (int i = 0; i < 3; i++)
			{
				point[i] = rand()/((double)RAND_MAX + 1);
				// make each positive or negative
				double posneg = rand()/((double)RAND_MAX + 1);
				if (posneg < .5)
					point[i] = -point[i];
			}	
	#endif
			VecNormalize(point);
			if (this->useTransMatrix())
				transformPoint_mat(point, transMatrix);
			m_MonitorPoints.m_Point[x][0] = point[0];
			m_MonitorPoints.m_Point[x][1] = point[1];
			m_MonitorPoints.m_Point[x][2] = point[2];
		}
	}

	return m_MonitorPoints.m_NumPoints ;
}

fltk::Widget* Sphere::getInterface()
{
	return DGeometry::getInterface();
}

void Sphere::save(int mode, std::ofstream& file)
{
	if (mode == 0)
	{
		file << "dance.instance(\"Sphere\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
		char buff[512];
		// subdivisions
		sprintf(buff, "\"subdivisions\", %d", this->getNumSubdivisions());
		pythonSave(file, buff);
	}

	DGeometry::save(mode, file);
}




