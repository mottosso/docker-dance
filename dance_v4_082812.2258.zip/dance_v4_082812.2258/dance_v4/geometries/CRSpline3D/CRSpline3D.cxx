/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "CRSpline3D.h"
#include "opengl.h"
#include "danceInterp.h"
#include "dance.h"
#include <stdio.h>
#include "GLutilities.h"
#include "DGeometry.h"

PlugIn* Proxy()
{
	return new CRSpline3D();
}

PlugIn* CRSpline3D::create(int argc, char **argv)
{
	return new CRSpline3D();
}


CRSpline3D::CRSpline3D(): DGeometry()
{
	setName("dummySpline") ;
	m_size = 0  ;
	m_arcLengthLUT = NULL ;
	m_ALLUTsize = 0 ;
	m_numSubdivisions = 10 ;
	SetIsClosed(false, false) ;
	setIdentMat(&appliedMatrix[0][0], 4);
	SetShowTangents(false) ;
	m_first = NULL ;
	m_last = NULL ;
}


BoundingBox* CRSpline3D::calcBoundingBox(BoundingBox* box)
{

	// put a box around a unit sphere and then multiply
	// by the transformation matrix


	
    // a general bounding box
	m_BoundingBox.xMin = MAXFLOAT; 
	m_BoundingBox.xMax = MINFLOAT;;
	m_BoundingBox.yMin = MAXFLOAT;
	m_BoundingBox.yMax = MINFLOAT;
	m_BoundingBox.zMin = MAXFLOAT;
	m_BoundingBox.zMax = MINFLOAT;

	double matrix[4][4];
	this->getTransMatrix(matrix);

	for( int i = 0 ; i < GetSize() ; i++ )
	{
		Vector p ; 
		GetPoint(i)->GetPosition(p) ;
		Vector curPoint;
		VecCopy(curPoint, p);
		if (this->useTransMatrix())
			transformPoint_mat(curPoint, matrix);

		if (curPoint[0] < m_BoundingBox.xMin)
			m_BoundingBox.xMin = curPoint[0];
		if (curPoint[0] > m_BoundingBox.xMax)
			m_BoundingBox.xMax = curPoint[0];

		if (curPoint[1] < m_BoundingBox.yMin)
			m_BoundingBox.yMin = curPoint[1];
		if (curPoint[1] > m_BoundingBox.yMax)
			m_BoundingBox.yMax = curPoint[1];

		if (curPoint[2] < m_BoundingBox.zMin)
			m_BoundingBox.zMin = curPoint[2];
		if (curPoint[2] > m_BoundingBox.zMax)
			m_BoundingBox.zMax = curPoint[2];
	}
	if (box)
		box->copy(&m_BoundingBox);

	return &m_BoundingBox;
}

void CRSpline3D::render(int argc, char ** argv, std::ofstream & file)
{
	int i, j;

	if (argc > 0 && strcmp(argv[0],"povray") == 0)
	{
#ifdef _DEBUG
		file << "/* CRSpline3D: \n";
		write_properties(file);
		file << "*/\n\n";
#endif
		file << "sphere {\n  <0, 0, 0>, 1\n";
		file << "  texture {" << getMaterial()->getSafeMaterialName();
		
		// 'default' is a reserved word in povray
		if (!strcmp("default", getMaterial()->getSafeMaterialName())) file << "_";

		file << "}\n  matrix\n  <";
		for (j=0; j<4; j++) {
			for (i=0; i<3; i++) 
				file << m_transMatrix[j][i] << ((j==3 && i==2) ? ">" : ",");
			file << (j==3 ? "\n" : "\n  ");
		}
		file << "#ifdef (SETMATRIX2)\n";
		file << "transform SETMATRIX2\n";
		file << "#end\n";
		file << "#ifdef (SETMATRIX)\n";
		file << "transform SETMATRIX\n";
		file << "#end\n";

		file << "}\n\n";



	}
}

void CRSpline3D::applyTransMatrix()
{
	double matrix[4][4];
	this->getTransMatrix(matrix);

	double temp[4][4];
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			temp[r][c] = appliedMatrix[r][c];
	
	multArray(&appliedMatrix[0][0], &temp[0][0], &matrix[0][0], 4, 4, 4);
}

int CRSpline3D::createMonitorPoints(int npoints, bool random)
{
    AllocateMonitorPoints(npoints);

	double transMatrix[4][4];
	this->getTransMatrix(transMatrix);
	
	if (true) // always use random (until someone programs a good spherical sampling routine)
	{
		// take vertices at random
		// the downside to using this method is that repeated simulations might not give
		// you the same results since the collision points will be different every time
		for (int x = 0; x < npoints; x++)
		{
			// pick a random x, y, z value and normalize it
			Vector point;
	#ifdef WIN32
			DWORD curTime = GetTickCount();
			for (int i = 0; i < 3; i++)
			{
				point[i] = rand()/((double)RAND_MAX + 1);
				// make each positive or negative
				double posneg = rand()/((double)RAND_MAX + 1);
				if (posneg < .5)
					point[i] = -point[i];
			}

	#else
			timeval curTime;
			gettimeofday(&curTime, NULL);
			for (int i = 0; i < 3; i++)
			{
				point[i] = rand()/((double)RAND_MAX + 1);
				// make each positive or negative
				double posneg = rand()/((double)RAND_MAX + 1);
				if (posneg < .5)
					point[i] = -point[i];
			}
	#endif
			VecNormalize(point);
			if (this->useTransMatrix())
				transformPoint_mat(point, transMatrix);
			m_MonitorPoints.m_Point[x][0] = point[0];
			m_MonitorPoints.m_Point[x][1] = point[1];
			m_MonitorPoints.m_Point[x][2] = point[2];
		}
	}

	return m_MonitorPoints.m_NumPoints ;
}

fltk::Widget* CRSpline3D::getInterface()
{
	return DGeometry::getInterface();
}

void CRSpline3D::save(int mode, std::ofstream& file)
{
	if (mode == 0)
	{
		file << "dance.instance(\"CRSpline3D\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
		char buff[512];
		// subdivisions
		sprintf(buff, "\"subdivisions\", %d", this->getNumSubdivisions());
		pythonSave(file, buff);

		// points
		for( int ii = 0 ; ii < GetSize() ; ii++)
		{
			Vector p ;
			GetPoint(ii)->GetPosition(p) ;
			double t = GetPoint(ii)->GetT();
			if( ii != (GetSize()-1)) 
				sprintf(buff, "\"addPointNoUpdate\", %lf, %lf, %lf, %lf", p[0],p[1],p[2],t) ;
			else
				sprintf(buff, "\"addPoint\", %lf, %lf, %lf, %lf", p[0],p[1],p[2],t) ;
			pythonSave(file, buff);
		}

		// ALUT
		if( GetALLUTSize() )
		{
			sprintf(buff, "\"computeALLUT\", %d", GetALLUTSize()) ;
			pythonSave(file, buff);
		}
		// close|open
		if( IsClosed() )
			sprintf(buff, "\"close\"");
		else
			sprintf(buff, "\"open\"");
		pythonSave(file, buff);
	}

	DGeometry::save(mode, file);
}




CRControlPoint3D::CRControlPoint3D() 
{ 
	SetColor(1,1,1,1) ;
	m_s[0] = '\0' ; 
	m_next = NULL ;
	m_prev = NULL ;
	return ; 
}
void CRControlPoint3D::print(FILE *fp)
{
	fprintf(fp,"P <%f %f %f> R1 <%f %f %f> R2 <%f %f %f> t %f label %s", 
			    m_P[0], m_P[1], m_P[2], 
			    m_R1[0], m_R1[1], m_R1[2],
				m_R2[0], m_R2[1], m_R2[2],
			    m_t, GetLabel());
}


void CRControlPoint3D::print(void)
{
	danceInterp::OutputMessage("%f %f %f %f %f %f %f %f %f %f %s", 
			    m_P[0], m_P[1],m_P[2], 
			    m_R1[0], m_R1[1], m_R1[2],
				m_R2[0], m_R2[1], m_R2[2],
			    m_t, GetLabel());
}

void CRControlPoint3D::SetNext(CRControlPoint3D *p)
{
	m_next = p ;
}

void CRControlPoint3D::SetPrev(CRControlPoint3D *p)
{
	m_prev = p ;
}


void CRControlPoint3D::Get(Vector p, Vector r, double &tt)
{
	GetPosition(p) ;
	GetTangent(r) ;
	tt = GetT() ;
}

void CRControlPoint3D::Set(Vector p, Vector r1, Vector r2, double t, char *s)
{
	SetPosition(p) ;
	SetLeftTangent(r1) ;
	SetRightTangent(r2) ;
	SetT(t) ;
	SetLabel(s) ;
}

void CRControlPoint3D::Get(Vector p, Vector r1, Vector r2, double &tt)
{
	VecCopy(p,m_P) ;
	VecCopy(r1,m_R1) ;
	VecCopy(r2,m_R2) ;
	tt = GetT();
}

void CRControlPoint3D::Get(Vector p, Vector r1, Vector r2, double &tt, char *s, int size_s)
{
	VecCopy(p,m_P) ;
	VecCopy(r1,m_R1) ;
	VecCopy(r2,m_R2) ;
	tt = GetT();
	strncpy(s,GetLabel(),size_s); // to avoid overflow
	s[size_s-1] = '\0' ;
}

void CRControlPoint3D::Get(Vector p, Vector r)
{
	VecCopy(p,m_P) ;
	VecCopy(r,m_R1) ;
}

void CRControlPoint3D::Set(CRControlPoint3D *cp)
{
	cp->GetPosition(m_P) ;
	cp->GetLeftTangent(m_R1) ;
	cp->GetRightTangent(m_R2) ;
	SetT( cp->GetT() ) ;
	SetLabel(cp->GetLabel()) ;
}



void CRSpline3D::Clear(void)
{
	if (this->GetSize() > 0)
	{
		CRControlPoint3D *p = GetFirstPoint() ;
		while(p)
		{
			CRControlPoint3D *t = p ;
			p = p->GetNext() ;
			delete t ;
		}
	}
	SetSize(0) ;
	SetALLUTSize(0) ;
	SetFirstPoint(NULL) ;
	SetLastPoint(NULL) ;
}

// allocates n CMpoints and sets the positions and automatically assings uniform ts.
int CRSpline3D::Set(Vector *points,int n, bool update)
{
	if( n < 2) 
	{
		danceInterp::OutputMessage("CRSpline3D::CRSpline3D: ERROR: less than 2 points provided.\n") ;
		return -1 ;
	}
	double *t = new double[n] ;
	if( t == NULL ) 
	{
		danceInterp::OutputMessage("CRSpline3D::CRSpline3D: ERROR: cannot allocate memory.\n") ;
		return -1 ;
	}
	for( int i = 0 ; i < n ; i++ )
		t[i] = (double) i ;
	int res = Set(points, t,n, update) ;
	delete [] t ;
	return res ;
}

// allocates n CMpoints and sets the position and the ts
int CRSpline3D::Set(Vector *points, double *t, int n, bool update)
{
	if( n < 2) 
	{
		danceInterp::OutputMessage("CRSpline3D::Assign: ERROR: less than 3 points provided\n") ;
		return -1 ;
	}

	
	for( int i = 0 ; i < GetSize() ; i++ )
	{
		SetPosition(i,points[i], false) ;
		SetT(i,t[i], false) ;
	}

	if( update ) Update() ;
	return n ;
}

// allocates n CMpoints and sets the position,  tangents and the ts
int CRSpline3D::Set(Vector *points, Vector *tangents, double *t, int n, bool update)
{
	if( n < 2) 
	{
		danceInterp::OutputMessage("CRSpline3D::Assign: ERROR: less than 3 points provided\n") ;
		return -1 ;
	}

	

	for( int i = 0 ; i < GetSize() ; i++ )
	{
		SetPosition(i,points[i], false) ;
		SetTangent(i,tangents[i], false) ;
		SetT(i,t[i], false) ;
	}

	if( update ) Update() ;
	return n ;
}

void CRSpline3D::print(FILE *fp) {

	int i;

	fprintf(fp,"NumPoints %d LUT size %d ", GetSize(), GetALLUTSize()) ;
	for (i=0 ; i < GetSize() ; i++) { 
		GetPoint(i)->print(fp) ;
		fprintf(fp, "\n") ;
	}
}

void CRSpline3D::print(void) {

	int i;

	danceInterp::OutputMessage("CRSpline3D %s", getName()) ;
	danceInterp::OutputMessage("NumPoints %d LUT size %d ", GetSize(), GetALLUTSize()) ;
	for (i=0 ; i < GetSize() ; i++) 
	{
		GetPoint(i)->print() ;
	}
}

void CRSpline3D::displayPR(GLenum mode)
{

	// show tangents
	if( GetShowTangents() )
	{
		if( mode != GL_SELECT )
		{
			
			glColor3f(0,1,0) ;
			GLfloat m[4] = {1,1,0,1} ;
			glMaterialfv(GL_FRONT,GL_DIFFUSE,m);
			for( int i = 0 ; i < GetSize() ; i++ )
			{
				CRControlPoint3D *p = GetPoint(i) ;
				GLdrawVector(p->m_P,p->m_R1) ;
			}
		}
	}

	glPushAttrib(GL_LIGHTING) ;
	glDisable(GL_LIGHTING) ;
	if( mode == GL_SELECT)
	{
		
		glPointSize(5.0) ;	
	}
	
	if( mode != GL_SELECT) 
	{
		
		glPointSize(5.0) ;
		glBegin(GL_POINTS) ;
	}
	
	for( int i = 0 ; i < GetSize() ; i++ )
	{
		CRControlPoint3D *cp = GetPoint(i);
		if( mode == GL_SELECT)
		{
			glPushName(i) ;
			glBegin(GL_POINTS) ;
		}
		float r,g,b,a ;
		cp->GetColor(r,g,b,a);
		glColor3f(r,g,b) ;
		glVertex3dv(cp->m_P) ;
		if( mode == GL_SELECT) 
		{
			glEnd() ;
			glPopName() ;
		}
	}
	if( mode != GL_SELECT) glEnd() ;
	glPopAttrib() ;
	
}

// display the spline
// numDiv == 0 show only the control points and the tangents
void CRSpline3D::output(int mode)
{
	glPushAttrib(GL_LIGHTING) ;
	glDisable(GL_LIGHTING) ;

	glMatrixMode(GL_MODELVIEW) ;

	glPushMatrix();
	if (this->useTransMatrix())
	{
		double matrix[4][4];
		this->getTransMatrix(matrix);
		glMultMatrixd(&matrix[0][0]);
	}

	if( mode == GL_SELECT ) 
	{
		
		displayPR(GL_SELECT) ;
	}
	else
	{
		if( GetNumSubdivisions() == 0 )
		{
			displayPR(GL_RENDER) ;
		}
		else
		{
			double dt = (double) 1.0 / GetNumSubdivisions() ;
			double t = 0 ;
			glBegin(GL_POINTS) ;
			for( int i = 0 ; i < (GetSize()-1) ; i++ )
			{
				//danceInterp::OutputMessage("Segment [%d, %d]", i, i+1) ;
				for( t = 0; t < 1 ; t += dt )
				{
					Vector p,r ;
					Eval(t,i,p,r) ;
					glVertex3dv(p) ;
				//	danceInterp::OutputMessage("\tPoint %lf %lf %lf", p[0],p[1],p[2]) ;
				}
			}
			glEnd() ;
		}
	}
	glPopAttrib() ;

	displayPR(GL_RENDER) ;
	glPopMatrix() ;

}


int CRSpline3D::Eval(double t, Vector p)
{
	Vector r ;
	CRControlPoint3D *cp = GetFirstPoint() ;
	if( t <= cp->GetT() )
	{
		cp->Get(p,r) ;
		return 0 ;
	}
	if( t >= GetLastPoint()->m_t )
	{
		GetLastPoint()->Get(p,r) ;
		return 0 ;
	}


	for( int i = 0 ; i < (m_size-1) ; i++ )
	{
		CRControlPoint3D *cp = GetPoint(i) ; ;
		double t1 = cp->GetT() ;
		double t2 = cp->GetNext()->GetT() ;
		double tscaled = (t - t1)/(t2-t1) ;
		if( (tscaled >=0) && (tscaled < 1) )
		{
			Eval(tscaled,i,p,r) ;
		}
	}

	if( this->useTransMatrix() )
	{
		double tm[4][4] ;
		this->getTransMatrix(tm) ;
		transformPoint_mat(p,tm) ;
	}
	return DANCE_OK ;
}


int CRSpline3D::Eval(double t, Vector p, Vector r)
{

	CRControlPoint3D *cp = GetFirstPoint() ;
	if( t <= cp->GetT() )
	{
		cp->Get(p,r) ;
		return 0 ;
	}
	if( t >= GetLastPoint()->GetT() )
	{
		GetLastPoint()->Get(p,r) ;
		return 0 ;
	}


	for( int i = 0 ; i < (m_size-1) ; i++ )
	{
		CRControlPoint3D *cp = GetPoint(i) ; ;
		double t1 = cp->GetT() ;
		double t2 = cp->GetNext()->GetT() ;
		double tscaled = (t - t1)/(t2-t1) ;
		if( (tscaled >=0) && (tscaled < 1) )
		{
			Eval(tscaled,i,p,r) ;
		}
	}


	if( this->useTransMatrix() )
	{
		double tm[4][4] ;
		this->getTransMatrix(tm) ;
		transformPoint_mat(p,tm) ;
		rotPoint_mat4(r,tm) ;
	}
	
	return 1 ;
}

// Eval: In this case we know the i.
//       t is in [0,1]
void CRSpline3D::Eval(double t,int i,  Vector p, Vector r)
{
	
	double tt = t*t ;
	double ttt = t*tt ;
	double f1 = 2*ttt - 3*tt +1  ;
	double f2 = -2*ttt + 3*tt ;
	double f3 = ttt -2*tt + t ;
	double f4 = ttt - tt ;
	Vector v1,v2,v3,v4 ;

	CRControlPoint3D *cp = GetPoint(i) ;
	CRControlPoint3D *cpnext = cp->GetNext() ;

	VecNumMul(v1,cp->m_P,f1) ;
	VecNumMul(v2,cpnext->m_P,f2) ;
	VecNumMul(v3,cp->m_R2,f3) ;
	VecNumMul(v4,cpnext->m_R1,f4) ;
	VecAdd(p,v2,v1) ;
	VecAdd(p,p,v3) ;
	VecAdd(p,p,v4) ;

	//danceInterp::OutputMessage("t %lf point %lf %lf %lf", t, p[0], p[1], p[2]) ;
	f1 = 6*tt - 6*t  ;
	f2 = -6*tt + 6*t ;
	f3 = 3*tt -4*t + 1 ;
	f4 = 3*tt - 2*t ;

	VecNumMul(v1,cp->m_P,f1) ;
	VecNumMul(v2,cpnext->m_P,f2) ;
	VecNumMul(v3,cp->m_R2,f3) ;
	VecNumMul(v4,cpnext->m_R1,f4) ;
	VecAdd(r,v2,v1) ;
	VecAdd(r,r,v3) ;
	VecAdd(r,r,v4) ;
}


/*
void CRSpline3D::CalculateTangents(void)
{
	if( size < 2 ) return ;

	// boundaries
	CRControlPoint3D *cp = &m_controlPoints[0] ;
	VecSubtract(cp->R,m_controlPoints[1].m_P, cp->m_P) ;
	cp = &m_controlPoints[size-1] ;
	VecSubtract(cp->R,cp->m_P, m_controlPoints[size-2].m_P) ;
	
	// interior 
	for( int i = 1 ; i < (size - 1) ;	i++ )
	{
		VecSubtract(m_controlPoints[i].R, m_controlPoints[i+1].m_P, m_controlPoints[i-1].m_P) ;
		VecScale(m_controlPoints[i].R,0.5) ;
	}

}
*/

// Second order accurate boundaries
void CRSpline3D::CalculateTangents(void)
{
	if( GetSize() < 2 ) return ;
	
	// set the tangents of the boundary points
	if( GetSize() < 3) 
	{
		CRControlPoint3D *cp = GetFirstPoint() ;
		CRControlPoint3D *cpnext = cp->GetNext() ;
		VecSubtract(cp->m_R1,cpnext->m_P, cp->m_P) ;
		VecCopy(cp->m_R2,cp->m_R1) ;
		cp = GetLastPoint() ;
		CRControlPoint3D *cpprev = cp->GetPrev() ;
		VecSubtract(cp->m_R2,cp->m_P, cpprev->m_P) ;
		VecCopy(cp->m_R1,cp->m_R2) ;
	}
	else if( IsClosed() == false )
	{
		// Second order accurate
		Vector a, b ;
		CRControlPoint3D *cp = GetFirstPoint() ;
		CRControlPoint3D *cpnext = cp->GetNext() ;
		VecSubtract(a,cpnext->m_P, cp->m_P) ;
		VecScale(a,2) ;
		VecSubtract(b,cpnext->GetNext()->m_P, cp->m_P) ;
		VecScale(b,-0.5) ;
		VecAdd(cp->m_R1,a,b) ;
		VecCopy(cp->m_R2,cp->m_R1) ;
	
		cp = GetLastPoint() ;
		CRControlPoint3D *cpprev = cp->GetPrev() ;
		VecSubtract(a,cp->m_P, cpprev->m_P) ;
		VecScale(a,2) ;
		VecSubtract(b,cp->m_P, cpprev->GetPrev()->m_P) ;
		VecScale(b,-0.5) ;
		VecAdd(cp->m_R2,a,b) ;
		VecCopy(cp->m_R1,cp->m_R2) ;
	}
	else
	{
		// first and last points are the same
		VecSubtract(GetFirstPoint()->m_R1, GetFirstPoint()->GetNext()->m_P, 
			GetLastPoint()->GetPrev()->m_P) ;
		VecScale(GetFirstPoint()->m_R1,0.5) ;
		VecCopy(GetFirstPoint()->m_R2,GetFirstPoint()->m_R1) ;

		// set the tangents for the last point
		VecCopy(GetLastPoint()->m_R1,GetFirstPoint()->m_R1) ;
		VecCopy(GetLastPoint()->m_R2,GetFirstPoint()->m_R1) ;
	}
	
	// set the tangents of interior points
	for( int i = 1 ; i < (GetSize() - 1) ;	i++ )
	{
		CRControlPoint3D *cp = GetPoint(i);
		VecSubtract(cp->m_R1, cp->GetNext()->m_P, cp->GetPrev()->m_P) ;
		VecScale(cp->m_R1,0.5) ;
		VecCopy(cp->m_R2,cp->m_R1) ;
	}

}

int CRSpline3D::SetALLUTSize(int n)
{
	if( GetALLUTSize() == n ) return n ;

	if( m_arcLengthLUT != NULL) 
	{
		delete [] m_arcLengthLUT ;
		m_arcLengthLUT = NULL ;
	}
	if( n < 1 ) 
	{
		m_ALLUTsize = 0 ;
		return 0 ;
	}

	m_arcLengthLUT = new struct st[n] ;
	if( m_arcLengthLUT == NULL )
	{
		danceInterp::OutputMessage("CRSpline3D::SetALLUTSize: Cannot allocate memory\n") ;
		return -1 ;
	}

	m_ALLUTsize = n ;
	return n;
}

int CRSpline3D::ComputeArcLengthLUT(int n)
{
	if (n < 1 ) 
	{
		return 0;
	}
	if( GetSize() < 2 ) 
	{
		danceInterp::OutputMessage("size < 2: %d", GetSize()) ;
		return 0 ;
	}

	if( SetALLUTSize(n) < 0 ) 
	{
		danceInterp::OutputMessage("CRSpline3D::ComputeArcLengthLUT: ERROR: Cannot allocate memory!") ;
		return -1 ;
	}
	
	Vector p, pnext, dummy, dsV ;

	
	double dt = (GetEndT() - GetStartT()) / (float) (n-1)  ;
	double t = GetStartT() ;	
	m_arcLengthLUT[0].t = t ;
	m_arcLengthLUT[0].s = 0 ;
	Eval(t,p, dummy) ;
	t += dt ;
	for( int i = 1 ; i < n ; i++, t+= dt )
	{
		Eval(t,pnext, dummy) ;
		VecSubtract(dsV, pnext,p) ;
		double ds = VecLength(dsV) ;
		m_arcLengthLUT[i].t = t ;
		m_arcLengthLUT[i].s = m_arcLengthLUT[i-1].s + ds ;
		VecCopy(p, pnext) ;
	}
	danceInterp::OutputMessage("Computed Arc Lengh table of size: %d", n) ;
	return n ;
}

double CRSpline3D::ComputeArcLengthFromT(double t)
{
	if( GetALLUTSize() == 0 )
	{
		if( ComputeArcLengthLUT() < -1 ) return -1 ;
	}
	if ( t <= GetStartT() ) return 0 ;
	if ( t >= GetEndT() ) 
		return m_arcLengthLUT[m_ALLUTsize-1].s ;

	int i = 0 ;
	while( t > m_arcLengthLUT[i].t)
	{
		i++ ;
	}
	// linear interpolation
	double s1 = m_arcLengthLUT[i-1].s ;
	double s2 = m_arcLengthLUT[i].s ;
	double t1 = m_arcLengthLUT[i-1].t ;
	double t2 = m_arcLengthLUT[i].t ;
	double tt = (t-t1) / (t2 - t1) ; 
	return s1*(1-tt)+tt*s2 ;
}

double CRSpline3D::ComputeTFromArcLength(double s)
{
	if( GetALLUTSize() < 1 )
	{
		if( ComputeArcLengthLUT() < -1 ) return -1 ;
	}

	if ( s <= m_arcLengthLUT[0].s ) return 0 ;
	if ( s >= m_arcLengthLUT[GetALLUTSize()-1].s ) 
		return  m_arcLengthLUT[GetALLUTSize()-1].t  ;

	int i = 0 ;
	while( s > m_arcLengthLUT[i].s)
	{
		i++ ;
	}
	// linear interpolation
	double s1 = m_arcLengthLUT[i-1].s ;
	double s2 = m_arcLengthLUT[i].s ;
	double t1 = m_arcLengthLUT[i-1].t ;
	double t2 = m_arcLengthLUT[i].t ;
	double stemp = (s-s1) / (s2 - s1) ; 
	return t1*(1-stemp)+stemp*t2 ;
}

// Adds an offset to the desired control point and if specified it
// updates the tangents.
void CRSpline3D::OffsetPoint(int index, double x, double y, double z, bool update)
{
	CRControlPoint3D *p = this->GetPoint(index) ;
	if( !p )
	{
		danceInterp::OutputMessage("CRSpline3D::AddOffset: index %d out of range [0,%d]", 
			index, GetSize()) ;
		return ;
	}
	
	Vector v ; v[0] = x; v[1] = y;  v[2] = z ;
	 p->OffsetPoint(v) ;
	 if( update ) Update() ;
	 
	 return ;
}


void CRSpline3D::OffsetPoints(double x, double y, double z, bool update)
{
	for( int i = 0 ; i < GetSize() ; i++ )
	{
		OffsetPoint(i,x,y,z, false) ;
	}
	if( update) Update() ;
}

// Sets the desired coordinate of all points to zero
// and calculates the tangents
void CRSpline3D::ZeroCoord(char c, bool update)
{
	int x ;

	if( c == 'x' ) x = 0 ;
	else if( c == 'y' ) x = 1 ;
	else if ( c == 'z' ) x = 2 ;
	else
	{
		danceInterp::OutputMessage("CRSpline3D::ZeroCoord: no such coordinate %c", c) ;
		return ;
	}

	Vector offset,p,r ;
	zeroVector(offset) ;
	for( int i = 0 ; i < GetSize() ; i++ )
	{
		GetPoint(i)->Get(p,r) ;
		offset[x] = -p[x] ;
		OffsetPoint(i,offset[0], offset[1], offset[2], false) ;
	}
	if( update) Update() ;
}

double CRSpline3D::GetEndTime(void)
{
	if( GetSize() < 2 ) return 0 ;
	return GetPoint(GetSize()-1)->GetT() ;	
}

double CRSpline3D::GetStartTime(void)
{
	if( GetSize() < 2 ) return 0 ;
	return GetPoint(0)->GetT() ;	
}

double CRSpline3D::GetDuration(void)
{
	if( GetSize() < 2 ) return 0 ;
	return  GetPoint(GetSize()-1)->GetT() - GetPoint(0)->GetT() ;	
}
void CRSpline3D::ScaleTime(double a, bool update)
{
	int i ;
	for( i = 0 ; i < GetSize() ; i++)
	{
		GetPoint(i)->ScaleTime(a) ;
	}
	if( update) Update() ; // update tangents and if needed the ALLUT
}

// Sets the duration leaving the first point's time unchanged.
void CRSpline3D::SetDuration(double dur, bool update)
{
	if( GetSize() < 2 )  return ;
	if( isZero(this->GetDuration())) return ;
	if( isZero(dur)) return ;

	// save the start time
	double startTime = GetStartTime() ;
	double a = dur / this->GetDuration() ;
	ScaleTime(a, false) ;
	// restore the start time
	SetStartTime(startTime) ;

	if( update) Update() ; // update tangents and if needed the ALLUT
}

void CRSpline3D::SetStartTime(double t)
{
	if( GetSize() < 2) return ;
	double offset = t - GetPoint(0)->GetT() ;
	OffsetTime(offset, false) ;
}

void CRSpline3D::SetEndTime(double t)
{
	if( GetSize() < 2) return ;
	double offset = t - GetPoint(GetSize()-1)->GetT() ;
	OffsetTime(offset, false) ;
}


// Adds an offset to the desired control point's time and if specified it
// update quantities such as the tangents or the ALLUT.
void CRSpline3D::OffsetTime(int index, double offset, bool update)
{
	CRControlPoint3D *p = this->GetPoint(index) ;
	if( !p )
	{
		danceInterp::OutputMessage("CRSpline3D::OffsetTime: index %d out of range [0,%d]", 
			index, GetSize()) ;
		return ;
	}
	
	 p->OffsetTime(offset) ;
	 if( update ) Update() ;
	 	 
	 return ;
}

// Adds a time offset and if specified recalculates the tangets
void CRSpline3D::OffsetTime(double offset, bool update)
{
	for( int i = 0 ; i < GetSize() ; i++ )
	{
		OffsetTime(i, offset, false) ;
	}
	if (update) Update() ;
}

int CRSpline3D::SetPoint(int i, Vector point, Vector lTangent, Vector rTangent, double t, char *s, bool update)
{
	CRControlPoint3D *p = GetPoint(i) ;
	if( p == NULL ) return -1 ;
	p->Set(point, lTangent, rTangent,t,s) ;
	if( update ) Update() ;
	return i ;
}

int CRSpline3D::SetPosition(int i, Vector point, bool update)
{
	CRControlPoint3D *p = GetPoint(i) ;
	if( p == NULL ) return -1 ;
	p->SetPosition(point) ;
	if( update ) Update() ;
	return i ;
}

int CRSpline3D::SetT(int i, double t, bool update)
{
	CRControlPoint3D *p = GetPoint(i) ;
	if( p == NULL ) return -1 ;
	p->SetT(t) ;
	if( update ) Update() ;
	return i ;
}

int CRSpline3D::SetLeftTangent(int i, Vector r, bool update)
{
	CRControlPoint3D *p = GetPoint(i) ;
	if( p == NULL ) return -1 ;
	p->SetLeftTangent(r) ;
	if( update ) Update() ;
	return i ;
}
int CRSpline3D::SetRightTangent(int i, Vector r, bool update)
{
	CRControlPoint3D *p = GetPoint(i) ;
	if( p == NULL ) return -1 ;
	p->SetRightTangent(r) ;
	if( update ) Update() ;
	return i ;
}

int CRSpline3D::SetTangent(int i, Vector r, bool update)
{
	CRControlPoint3D *p = GetPoint(i) ;
	if( p == NULL ) return -1 ;
	p->SetLeftTangent(r) ;
	p->SetRightTangent(r) ;
	if( update ) ComputeArcLengthLUT() ;
	return i ;
}

int CRSpline3D::SetLabel(int i, char *s)
{
	CRControlPoint3D *p = GetPoint(i) ;
	if( p == NULL ) return -1 ;
	p->SetLabel(s) ;
	return i ;
}


// Append: Append s on this. If any of them had LUT
// then it computes a new LUT of size the sum of the original
// sizes. S loses its points
int CRSpline3D::Append(CRSpline3D *s, bool update)
{
	if( s->GetSize() < 1 ) return -1;
	// check if any of the path has ALLUT allocated
	int n =  GetALLUTSize() +  s->GetALLUTSize() ;

	if( s->GetSize() < 1 ) return GetSize() ;
	
	if( this->GetSize() == 0 )
	{
		this->SetFirstPoint(s->GetFirstPoint()) ;
	}
	else
	{
		s->GetFirstPoint()->SetPrev(this->GetLastPoint()) ;
		this->GetLastPoint()->SetNext(s->GetFirstPoint()) ;
	}
	
	this->SetLastPoint(s->GetLastPoint()) ;
	this->SetSize(GetSize()+s->GetSize()) ;
	s->SetSize(0) ;
	s->Clear() ;

	if( n ) this->ComputeArcLengthLUT(n) ;

	return GetSize() ;
}

int CRSpline3D::AddPoint(CRControlPoint3D *p, bool update)
{
	if( GetSize() == 0 )
	{
		SetFirstPoint(p) ;
		SetLastPoint(p) ;
	}
	else
	{
		p->SetPrev(GetLastPoint()) ;
		GetLastPoint()->SetNext(p) ;
		SetLastPoint(p) ;
	}

	// update the size
	SetSize(GetSize() + 1 ) ;
	return GetSize() ;
}

int CRSpline3D::AddPoint(Vector p, double t, bool update)
{
	danceInterp::OutputMessage("Added point: %lf %lf %lf %lf", 
		p[0], p[1], p[2], t) ;
	CRControlPoint3D *cp = new CRControlPoint3D;
	if( cp == NULL )
	{
		danceInterp::OutputMessage("CRSpline3D::AddPoint: Error cannot allocate memorry") ;
		return -1 ;
	}
	cp->SetPosition(p) ;
	cp->SetT(t) ;
	return AddPoint(cp,update) ;
	
}

int CRSpline3D::AddPoint(Vector p, bool update)
{
	double t = 0 ;
	if( GetSize() > 0 ) t = GetLastPoint()->GetT()  + 1 ;
	danceInterp::OutputMessage("Added point: %lf %lf %lf %lf", 
		p[0], p[1], p[2], t) ;
	CRControlPoint3D *cp = new CRControlPoint3D;
	if( cp == NULL )
	{
		danceInterp::OutputMessage("CRSpline3D::AddPoint: Error cannota allocate memorry") ;
		return -1 ;
	}
	cp->SetPosition(p) ;
	Vector z = {0,0,0} ;
	cp->SetTangent(z) ;
	cp->SetT(t) ;
	return AddPoint(cp,update) ;
	
}

int CRSpline3D::AddPoint(Vector p, Vector tangent, double t, bool update)
{
	CRControlPoint3D *cp = new CRControlPoint3D;
	if( cp == NULL )
	{
		danceInterp::OutputMessage("CRSpline3D::AddPoint: Error cannota allocate memorry") ;
		return -1 ;
	}
	cp->SetPosition(p) ;
	cp->SetTangent(tangent) ;
	cp->SetT(t) ;
	return AddPoint(cp,update) ;	
}

int CRSpline3D::AddPoint(Vector p, Vector lTangent, Vector rTangent, double t, bool update)
{
	CRControlPoint3D *cp = new CRControlPoint3D;
	if( cp == NULL )
	{
		danceInterp::OutputMessage("CRSpline3D::AddPoint: Error cannota allocate memorry") ;
		return -1 ;
	}
	
	cp->SetPosition(p) ;
	cp->SetLeftTangent(lTangent) ;
	cp->SetRightTangent(rTangent) ;
	cp->SetT(t) ;
	return AddPoint(cp,update) ;	
}

int CRSpline3D::RemovePoint(int index, bool update) 
{
	if( index < 0 ) return -1 ;
	if( index >  GetSize()-1) return -1 ;

	CRControlPoint3D *p = GetPoint(index) ;
	if( index == 0 )
	{ 
		SetFirstPoint(p->GetNext()) ;
	}
	if( index == GetSize()-1 )
	{ 
		SetLastPoint(p->GetPrev()) ;
	}
	if( p->GetPrev() ) p->GetPrev()->SetNext(p->GetNext()) ;
	if( p->GetNext() ) p->GetNext()->SetPrev(p->GetPrev()) ;
	
	// delete the point
	delete p ;
	// update the size
	SetSize(GetSize() - 1 ) ;
	
	if( update ) Update() ;
	return 1 ;
}

int CRSpline3D::commandPlugIn(int argc, char **argv)
{
	int ret = DGeometry::commandPlugIn(argc, argv);
	if (ret != DANCE_CONTINUE)
		return ret;

	if( strcmp(argv[0], "setFromPointsAndTs") == 0 )
	{
		int np = argc / 4 ;
		if( np < 2 )
		{
			danceInterp::OutputMessage("CRSpline3D::ERROR: provide at least two points.\n") ;
			return DANCE_ERROR ;
		}
		for( int i = 0 ; i < np*4 ; i += 4 )
		{
			Vector p ;
			double t ;
			p[0] = atof(argv[i+1]) ; 
			p[1] = atof(argv[i+2]) ; 
			p[2] = atof(argv[i+3]) ;
			t    = atof(argv[i+4]) ;
			if( AddPoint(p,t, false) < 0 )
			{
				danceInterp::OutputMessage("CRSpline3D::AddPoint: Cannot add point.\n") ;
				return DANCE_ERROR ;
			}
		}
		Update() ;
		return DANCE_OK;
	}
	if( strcmp(argv[0], "addPoint") == 0 )
	{
		if( argc !=5 )
		{
			danceInterp::OutputMessage("CRSpline3D::ERROR: syntax: addPoint x y z t\n") ;
			return DANCE_ERROR ;
		}
		Vector p ;
		double t ;
		p[0] = atof(argv[1]) ; 
		p[1] = atof(argv[2]) ; 
		p[2] = atof(argv[3]) ;
		t    = atof(argv[4]) ;
		if( AddPoint(p,t, false) < 0 )
		{
			danceInterp::OutputMessage("CRSpline3D::AddPoint: Cannot add point.\n") ;
			return DANCE_ERROR ;
		}
		Update() ;
		return DANCE_OK;
	}
	if( strcmp(argv[0], "addPointNoUpdate") == 0 )
	{
		if( argc !=5 )
		{
			danceInterp::OutputMessage("CRSpline3D::ERROR: syntax: addPoint x y z t\n") ;
			return DANCE_ERROR ;
		}
		Vector p ;
		double t ;
		p[0] = atof(argv[1]) ; 
		p[1] = atof(argv[2]) ; 
		p[2] = atof(argv[3]) ;
		t    = atof(argv[4]) ;
		if( AddPoint(p,t, false) < 0 )
		{
			danceInterp::OutputMessage("CRSpline3D::AddPoint: Cannot add point.\n") ;
			return DANCE_ERROR ;
		}
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "subdivisions") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage:subdivisions <num>");
			return DANCE_ERROR;
		}
		else
		{
			int num = atoi(argv[1]);
			this->setNumSubdivisions(num);
			danceInterp::OutputMessage("CRSpline3D %s now has  %d subdivisions.", this->getName(), 
				this->getNumSubdivisions());
			return DANCE_OK;
		}
	}
	else if (strcmp(argv[0], "computeALLUT") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage:computeALLUT <size>");
			return DANCE_ERROR;
		}
		else
		{
			int n = atoi(argv[1]);
			this->ComputeArcLengthLUT(n);
			danceInterp::OutputMessage("CRSpline3D %s now has LUT of size %d.", this->getName(), 
				this->GetALLUTSize());
			return DANCE_OK;
		}
	}
	else if (strcmp(argv[0], "showTangents") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage:showTangents yes/no");
			return DANCE_ERROR;
		}
		else
		{
			if( strcmp(argv[1], "yes") == 0) SetShowTangents(true) ;
			else SetShowTangents(false) ;
			return DANCE_OK;
		}
	}
	else if( strcmp(argv[0], "getPosition") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage:getPosition t");
			return DANCE_ERROR;
		}
		else
		{
			Vector p ;
			double t = atof(argv[1]) ;
			this->Eval(t,p) ;
			danceInterp::OutputListElement("%lf %lf %lf", p[0], p[1], p[2]) ;
			return DANCE_OK;
		}
	}
	else if( strcmp(argv[0], "getTangent") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage:getTangent t");
			return DANCE_ERROR;
		}
		else
		{
			Vector p,r ;
			double t = atof(argv[1]) ;
			this->Eval(t,p,r) ;
			danceInterp::OutputListElement("%lf %lf %lf", r[0], r[1], r[2]) ;
			return DANCE_OK;
		}
	}
	else if (strcmp(argv[0], "close") == 0)
	{
		danceInterp::OutputMessage("Make sure you have given the first point as last as well!") ;
		this->SetIsClosed(true,true) ;
			return DANCE_OK;
	}
	else if (strcmp(argv[0], "open") == 0)
	{
		this->SetIsClosed(false,true) ;
		return DANCE_OK;
	}

	return DANCE_OK;
}

int CRSpline3D::GetALLUTSize(void)
{
	return m_ALLUTsize ;
}

CRControlPoint3D *CRSpline3D::GetPoint(int index)
{ 
	CRControlPoint3D *p = NULL ;
	if ((index < -1) || ( index >= GetSize()) )
		return NULL ; 
	
	p = GetFirstPoint() ;
	for( int i = 0 ; i < index ; i++ )
	{
		p = p->GetNext() ;
	}
	return p ;
}

CRControlPoint3D *CRSpline3D::GetLastPoint(void)
{ 
	return m_last ;
}

CRControlPoint3D *CRSpline3D::GetFirstPoint(void)
{ 
	return m_first ;
}

void CRSpline3D::OffsetPoints(Vector v, bool update)
{
	OffsetPoints(v[0],v[1],v[2],update);
}

void CRSpline3D::Update(void)
{
	CalculateTangents() ;
	ComputeArcLengthLUT(GetALLUTSize()) ;
}

double CRSpline3D::GetStartT(void)
{
		if ( GetSize() > 0 ) 
			return m_first->GetT() ; 
		else return -1 ;
}

double CRSpline3D::GetEndT(void)
{
	if ( GetSize() > 0 )
		return m_last->GetT(); 
	else
		return -1 ;
}

bool CRSpline3D::IsClosed(void)
{
	return m_closed ;
}

void CRSpline3D::SetIsClosed(bool c, bool update)
{
	m_closed = c ; 
	if (update)
		Update();
}
void CRSpline3D::setNumSubdivisions(int num)
{
	m_numSubdivisions = num;
}

int CRSpline3D::getNumSubdivisions()
{
	return m_numSubdivisions;
}

bool CRSpline3D::GetShowTangents(void)
{
	return m_showTangents;
}

void CRSpline3D::SetShowTangents(bool c)
{
	m_showTangents = c;
}


int CRSpline3D::SetPoint(int i, CRControlPoint3D *newp, bool update)
{
	CRControlPoint3D *cp = this->GetPoint(i) ;
	cp->Set(newp) ; // doesn't copy the next and prev fields
	return 1 ;
}

CRSiterator::CRSiterator(CRSpline3D *s)
{
	if( s == NULL )
	{
		m_first = NULL ;
		m_s = NULL ;
		m_current = NULL ;
		return ;
	}
	m_s = s ;
	m_first = s->GetFirstPoint() ;
	m_current = m_first ;
}

CRControlPoint3D *CRSiterator::GetNext()
{
	m_current = m_current->GetNext() ;
	return m_current ;
}

// Samples the spline and produces a new version with numpoints.
// The smaple happens using uniform arc length parameterization
void CRSpline3D::Resample(int numpoints)
{
	if( GetSize() < 2) return ;
	if( this->GetALLUTSize() < 1) this->ComputeArcLengthLUT(100) ;

	double arcLength = this->ComputeArcLengthFromT(this->GetEndT()) ;
	if( arcLength < 10e-16) 
	{
		danceInterp::OutputMessage("CRSpline3D::Resample:Cannot compute arc length") ;
		return ;
	}
	double dl = arcLength / (numpoints - 1);
	CRSpline3D tempsp ;
	Vector p ;
	CRControlPoint3D *cp = this->GetPoint(0);
 	cp->GetPosition(p) ;
	if( tempsp.AddPoint(p,0,false) < -1 ) return ; //error
	double l = dl ;
	for( int i = 1 ; i < numpoints ; i++ )
	{
		double t = this->ComputeTFromArcLength(l) ;
		this->Eval(t,p);
		if( tempsp.AddPoint(p,(double) i, false) < 0 ) return ; //error
		l += dl ;
	}
	// switch the points now
	this->Clear() ;
	this->Append(&tempsp, false) ;

}


void CRSpline3D::RemoveDuplicates(double threshold)
{
	int np = 0 ;
	bool done = false ;
	while( !done )
	{
		
		done = true ;
		int i = 0 ;
		while( i < this->GetSize() ) 
		{
			CRControlPoint3D *cp1 = GetPoint(i) ;
			Vector p1 ;
			cp1->GetPosition(p1) ;
			bool startAgain = false ;
			for( int j = i+1 ; j < this->GetSize() && !startAgain ; j++ )
			{
				CRControlPoint3D *cp2 = GetPoint(j) ;
				Vector p2 ;		
				cp2->GetPosition(p2) ;
				Vector dist ;
				VecSubtract(dist,p1,p2) ;
				if( VecLength(dist) < threshold)
				{
					RemovePoint(j, false) ;
					done = false ;
					startAgain = true ;
					np++ ;
				}
			}
			if( !startAgain ) i = i+1 ;
		}
	}
	danceInterp::OutputMessage("Removed %d duplicate points", np) ;
	// now fix the Ts
	for( int i = 0 ; i < this->GetSize(); i++ )
	{
		this->GetPoint(i)->SetT(i) ;
	}
	this->SetALLUTSize(0) ;
}



