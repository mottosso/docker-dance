/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#ifndef _CRSpline3D_H_
#define _CRSpline3D_H_

#include "defs.h"
//#include <GL/glu.h>
#include "DGeometry.h"
#include <fstream>

#ifdef WIN32
#ifndef CRSPLINE3D_EXPORTS
#define	DLLCRSPLINE3D __declspec(dllimport)
#else
#define	DLLCRSPLINE3D __declspec(dllexport)
#endif
#else
#define DLLCRSPLINE3D 
#endif


class DLLCRSPLINE3D CRControlPoint3D {
	friend class CRSpline3D ;
public:
	CRControlPoint3D();
	~CRControlPoint3D() { return ; } ;
    
	int commandPlugIn(int argc, char **argv);
	void output(int mode) ;

	
	void SetPosition(Vector p) { VecCopy(m_P, p); } ;
	void SetT(double t) { m_t = t ; } ;
	void SetLeftTangent(Vector r) { VecCopy(m_R1, r) ; } ;
	void SetRightTangent(Vector r) { VecCopy(m_R2, r) ; } ;
	void SetTangent(Vector r) { SetLeftTangent(r); SetRightTangent(r);} ;
	void SetLabel(char *s) { strncpy(m_s, s, LabelSize) ; m_s[LabelSize] = '\0' ;} ;
	void Set(Vector p, Vector r1, Vector r2, double t) { Set(p,r1,r2,t,NULL ) ; } ;
	void Set(Vector p, Vector r, double t) { Set(p,r,r,t,NULL ) ; } ;
	void Set(Vector p, Vector r1, Vector r2, double t, char *s) ;
	void Get(Vector p, Vector r, double &tt) ;
	void Get(Vector p, Vector r) ;
	void Get(Vector p, Vector r1, Vector r2) ;
	void Get(Vector p, Vector r1, Vector r2, double &tt) ;
	void Get(Vector p, Vector r1, Vector r2, double &tt, char *s, int size_s) ;
	double GetT(void) { return m_t;} ;
	void GetPosition(Vector p) { VecCopy(p,m_P) ;} ;
	void GetTangent(Vector r) { VecCopy(r,m_R1) ;} ;
	void GetLeftTangent(Vector r) { VecCopy(r,m_R1) ;} ;
	void GetRightTangent(Vector r) { VecCopy(r,m_R2) ;} ;
	char *GetLabel(void) { return m_s ;} ;

	void OffsetPoint(Vector offset) { VecAdd(m_P, m_P, offset) ;} ;
	void OffsetTime(double dt) { m_t = m_t + dt ;} ;
	void ScaleTime(double a) { m_t = m_t * a ;} ;
	void print(FILE *fp) ;
	void print(void) ;
	void Set(CRControlPoint3D *cp) ;
	void SetColor(float r,float g,float b,float a) { m_c[0] = r ; m_c[1] = g ; m_c[2] = b ; m_c[3] = a ;} ;
	void GetColor(float &r,float &g,float &b,float &a) { r = m_c[0] ; g =  m_c[1] ; b = m_c[2] ; a = m_c[3]; } ;
	void SetNext(CRControlPoint3D *p) ;
	void SetPrev(CRControlPoint3D *p) ;
	CRControlPoint3D *GetNext(void) { return m_next ;} ;
	CRControlPoint3D *GetPrev(void) { return m_prev ;} ;

protected:
	static const int LabelSize = 100 ;
	Vector m_P, m_R1, m_R2;
    double m_t;
	char m_s[LabelSize+1] ;
	double m_c[4] ;
	CRControlPoint3D *m_next ;
	CRControlPoint3D *m_prev ;
};


class DLLCRSPLINE3D CRSpline3D : public DGeometry
{
public:

	PlugIn* create(int argc, char **argv);

	CRSpline3D();
		~CRSpline3D() { Clear() ; } ;


	int commandPlugIn(int argc, char **argv);
	void output(int mode);

		
	BoundingBox *calcBoundingBox(BoundingBox *box);
	void render(int argc, char ** argv, std::ofstream & file);

	void applyTransMatrix();
	int createMonitorPoints(int npoints, bool random);

	fltk::Widget* getInterface();
	void save(int mode, std::ofstream& file);


	void Clear(void) ;
	//CRSpline3D(Vector *points,int n) { Set(points,n, true); } ;
	//CRSpline3D(Vector *points,double *t, int n) { Set(points,t,n, true); } ;
	//CRSpline3D(Vector *points,Vector *tangents, double *t, int n) { Set(points,tangents,t,n, false); } ;
	int Set(Vector *points,int n, bool update) ;
	int Set(Vector *points, double *t, int n, bool update) ;
	int Set(Vector *points, Vector *tangents, double *t, int n, bool update) ;

	int Append(CRSpline3D *s, bool update) ;
	int AddPoints(CRControlPoint3D **p, int n, bool update) ;
	int AddPoint(Vector p, bool update) ;
	int AddPoint(Vector p, double t, bool update) ;
	int AddPoint(Vector p, Vector tangent, double t, bool update) ;
	int AddPoint(Vector p, Vector lTangent, Vector rTangent, double t, bool update) ;
	int AddPoint(CRControlPoint3D *p, bool update) ;
	int SetPoint(int i, CRControlPoint3D *newp, bool update) ;
	int SetPoint(int i, Vector point, Vector lTangent, Vector rTangent, double t, char *label, bool update) ;
	int SetPosition(int i, Vector point, bool update) ;
	int SetTangent(int i, Vector r, bool update) ;
	int SetLeftTangent(int i, Vector lr, bool update) ;
	int SetRightTangent(int i, Vector rr, bool update) ;
	int SetT(int i, double t, bool update) ;
	int SetLabel(int i, char *s) ;
	void SetNumSubdivisions(int n) { m_numSubdivisions = n;} ;
	int GetNumSubdivisions(void) { return m_numSubdivisions;} ;
	void SetSize(int s) { m_size = s;} ;
	int GetSize(void) { return m_size ;} ;
	int GetALLUTSize(void) ;
	int SetALLUTSize(int n) ;
	//CRControlPoint3D GetPoint(int i) { return m_controlPoints[i];}

	// time related manipulation
	void ScaleTime(double a, bool update) ;
	void SetDuration(double dur, bool update) ;
	double GetDuration(void) ;
	void SetStartTime(double t) ;
	double GetStartTime(void) ;
	double GetEndTime(void) ;
	void SetEndTime(double t) ;
	void OffsetTime(double t, bool update) ;
	void OffsetTime(int index, double t, bool update = true) ;

	void display(int numSubdiv=10, GLenum mode = GL_RENDER);
	void print(FILE *fp);
	void print(void);
	void CalculateTangents(void) ;
	void displayPR(GLenum mode) ;
	int Eval(double t, Vector p, Vector R) ;
	int Eval(double t, Vector p) ;
	void Eval(double t, int i, Vector p, Vector R) ;
	CRControlPoint3D *GetPoint(int i);
	CRControlPoint3D *GetLastPoint(void);
	CRControlPoint3D *GetFirstPoint(void);
	void SetFirstPoint(CRControlPoint3D *p) { m_first = p ;} ;
	void SetLastPoint(CRControlPoint3D *p) { m_last = p;} ;

	void OffsetPoints(Vector v, bool update);
	void OffsetPoints(double x, double y, double z, bool update) ;
	void OffsetPoint(int index, double x, double y, double z, bool update) ;
	void ZeroCoord(char coord, bool update) ; // coord = 'x' | 'y' | 'z'

	void Update(void);
	double ComputeArcLengthFromT(double t) ;
	double ComputeTFromArcLength(double s) ;
	int  ComputeArcLengthLUT(int n = 100) ;
	double GetStartT(void);
	double GetEndT(void);
	bool IsClosed(void);
	void SetIsClosed(bool c, bool update);
	void setNumSubdivisions(int num);
	int getNumSubdivisions();
	bool GetShowTangents(void);
	void SetShowTangents(bool c);
	void Resample(int numpoints = 20) ;
	void RemoveDuplicates(double threshold) ;

	int RemovePoint(int index, bool update) ;

private:
	int m_size;
	struct st { double s; double t; }  *m_arcLengthLUT; // Arc length Look Up table
	int m_ALLUTsize ;
	int m_numSubdivisions ;
	bool m_closed ;
	double appliedMatrix[4][4];
	bool m_showTangents ;
	CRControlPoint3D *m_first ;
	CRControlPoint3D *m_last ;



};

class CRSiterator {
	friend class CRSpline3D ;
public:
	CRSiterator() { m_first = NULL ; m_s = NULL ; m_current = NULL;} ;
	CRSiterator(CRSpline3D *s) ;
	CRControlPoint3D *GetNext() ;
private:
	CRSpline3D *m_s ;
	CRControlPoint3D *m_first ;
	CRControlPoint3D *m_current ;
} ;


#endif
