/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "CompositeGeometry.h"
#include <fltk/glut.h>
#include <fltk/gl.h>
#include "danceInterp.h"
#include "dance.h"
#include "DRendererManager.h"
#include "CompositeGeometryWindow.h"

PlugIn* Proxy()
{
	return new CompositeGeometry();
}

PlugIn* CompositeGeometry::create(int argc, char **argv)
{
	return new CompositeGeometry();
}


CompositeGeometry::CompositeGeometry(): DGeometry()
{
	compositeWindow = NULL;
}

void CompositeGeometry::output(int mode)
{
	DGeometry::output(mode);

	glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT);
	glEnable(GL_NORMALIZE);
	glEnable(GL_LIGHTING);

	glPushMatrix();
	if (this->useTransMatrix())
	{
		double matrix[4][4];
		this->getTransMatrix(matrix);
		glMultMatrixd(&matrix[0][0]);
	}

	for (unsigned int x = 0; x < geometries.size(); x++)
	{
		geometries[x]->output(mode);
	}

	glPopMatrix();

	glPopAttrib();

}

int CompositeGeometry::commandPlugIn(int argc, char **argv)
{
	int ret = DGeometry::commandPlugIn(argc, argv);
	if (ret != DANCE_CONTINUE)
		return ret;

	if (strcmp(argv[0], "add_geometry") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.geometry(\"%s\", \"add_geometry\", \"<geometry>\")", this->getName());
			return DANCE_ERROR;
		}

		DGeometry* geom = (DGeometry*) dance::AllGeometry->get(argv[1]);
		if (geom == NULL)
		{
			danceInterp::OutputMessage("No geometry named '%s' found.", argv[1]);
			return DANCE_ERROR;
		}
		this->addGeometry(geom);
		if (this->compositeWindow != NULL)
			compositeWindow->updateGUI();
		danceInterp::OutputMessage("Geometry %s added to composite geometry.", geom->getName());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "remove_geometry") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.geometry(\"%s\", \"remove_geometry\", \"<geometry>\")", this->getName());
			return DANCE_ERROR;
		}

		DGeometry* geom = (DGeometry*) dance::AllGeometry->get(argv[1]);
		if (geom == NULL)
		{
			danceInterp::OutputMessage("No geometry named '%s' found.", argv[1]);
			return DANCE_ERROR;
		}
		bool val = this->removeGeometry(geom);
		if (val)
		{
			danceInterp::OutputMessage("Geometry %s removed from composite geometry.", geom->getName());
		}
		else
		{
			danceInterp::OutputMessage("Geometry %s was not present in the composite geometry.", geom->getName());
		}
		if (this->compositeWindow != NULL)
			compositeWindow->updateGUI();
		return DANCE_OK;
	}

	return DANCE_OK;
}


void CompositeGeometry::render(int argc, char ** argv, std::ofstream & file)
{
	int i, j;

	if (argc > 0 && strcmp(argv[0],"povray") == 0)
	{
#ifdef _DEBUG
		file << "/* CompositeGeometry: \n";
		write_properties(file);
		file << "*/\n\n";
#endif

		std::ofstream* objfile = dance::AllRenderers->getObjectFileStream();
		std::string compositeGeometryname = this->getName();

		*objfile << "#declare "<< compositeGeometryname.c_str() << " = \n";
		*objfile << "union {\n";
		for (unsigned int x = 0; x < geometries.size(); x++)
		{
			geometries[x]->setVisible(true);
			geometries[x]->Translate( m_transMatrix[3][0], m_transMatrix[3][1], m_transMatrix[3][2], true );
			geometries[x]->render(argc, argv, file);
			geometries[x]->Translate( - m_transMatrix[3][0], - m_transMatrix[3][1], - m_transMatrix[3][2] );
			geometries[x]->setVisible(false);
		}
		*objfile << "}\n";

		file << "object {" << compositeGeometryname << "\n";
		file << "matrix\n  <";
		for (j=0; j<4; j++) {
			for (i=0; i<3; i++) 
				file << m_transMatrix[j][i] << ((j==3 && i==2) ? ">" : ",");
			file << "\n";
		}

		file << "#ifdef (SETMATRIX2)\n";
		file << "transform SETMATRIX2\n";
		file << "#end\n";
		file << "#ifdef (SETMATRIX)\n";
		file << "transform SETMATRIX\n";
		file << "#end\n";



		file << "}\n\n";


	}

}

BoundingBox* CompositeGeometry::calcBoundingBox(BoundingBox* box)
{
	BoundingBox b;
    // a general bounding box
	m_BoundingBox.xMin = MAXFLOAT; 
	m_BoundingBox.xMax = MINFLOAT;;
	m_BoundingBox.yMin = MAXFLOAT;
	m_BoundingBox.yMax = MINFLOAT;
	m_BoundingBox.zMin = MAXFLOAT;
	m_BoundingBox.zMax = MINFLOAT;

	for (unsigned int x = 0; x < geometries.size(); x++)
	{
		geometries[x]->calcBoundingBox(&b);
		if (b.xMin < m_BoundingBox.xMin)
			m_BoundingBox.xMin = b.xMin;
		if (b.xMax > m_BoundingBox.xMax)
			m_BoundingBox.xMax = b.xMax;
		if (b.yMin < m_BoundingBox.yMin)
			m_BoundingBox.yMin = b.yMin;
		if (b.yMax> m_BoundingBox.yMax)
			m_BoundingBox.yMax = b.yMax;
		if (b.zMin < m_BoundingBox.zMin)
			m_BoundingBox.zMin = b.zMin;
		if (b.zMax > m_BoundingBox.zMax)
			m_BoundingBox.zMax = b.zMax;
	}

	double matrix[4][4];
	this->getTransMatrix(matrix);

	Vector min = {m_BoundingBox.xMin, m_BoundingBox.yMin, m_BoundingBox.zMin};
	Vector max = {m_BoundingBox.xMax, m_BoundingBox.yMax, m_BoundingBox.zMax};

	transformPoint_mat(min, matrix);
	transformPoint_mat(max, matrix);

	m_BoundingBox.xMin = min[0];
	m_BoundingBox.xMin = min[1];
	m_BoundingBox.xMin = min[2];
	m_BoundingBox.xMax = max[0];
	m_BoundingBox.xMax = max[1];
	m_BoundingBox.xMax = max[2];
	
	if (box)
		box->copy(&m_BoundingBox);

	return &m_BoundingBox;
}

void CompositeGeometry::applyTransMatrix()
{
	double matrix[4][4];
	this->getTransMatrix(matrix);
}

int CompositeGeometry::createMonitorPoints(int npoints, bool random)
{
	int numPoints = 0;
	for (unsigned int x = 0; x < geometries.size(); x++)
	{
		numPoints += geometries[x]->createMonitorPoints(npoints, random);
	}

	return numPoints;
}

void CompositeGeometry::save(int mode, std::ofstream& file)
{
	char buff[1024];

	if (mode == 0)
	{
		file << "dance.instance(\"CompositeGeometry\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
	
	}
	else if (mode == 2)
	{
		for (int x = 0; x < this->getNumGeometries(); x++)
		{
			DGeometry* geom = this->getGeometry(x);
			sprintf(buff, "\"add_geometry\", \"%s\"", geom->getName());
			pythonSave(file, buff);
		}
	}

	DGeometry::save(mode, file);
}

int CompositeGeometry::getNumGeometries()
{
	return geometries.size();
}

DGeometry* CompositeGeometry::getGeometry(unsigned int num)
{
	if (geometries.size() > num)
		return geometries[num];
	else
		return NULL;
}

void CompositeGeometry::addGeometry(DGeometry* geom)
{
	for (unsigned int x = 0; x < geometries.size(); x++)
	{
		if (geometries[x] == geom)
			return;
	}

	CompositeGeometry* cgeometry = dynamic_cast<CompositeGeometry*>(geom);
	if (cgeometry != NULL)
	{
		danceInterp::OutputMessage("Cannot add composite geometry %s to this composite geometry %s.", cgeometry->getName(), geom->getName());
		return;
	}

	geometries.push_back(geom);
	geom->setVisible(false);
	this->addDependency(geom);
}

bool CompositeGeometry::removeGeometry(DGeometry* geom)
{
	for (std::vector<DGeometry*>::iterator iter = geometries.begin(); iter != geometries.end(); iter++)
	{
		if (*iter == geom)
		{
			geometries.erase(iter);
			geom->setVisible(true);
			this->removeDependency(geom);
			return true;
		}
	}
	return false;
}

bool CompositeGeometry::removeGeometry(unsigned int index)
{
	if (index < geometries.size())
	{
		return this->removeGeometry(geometries[index]);
	}
	else
	{
		return false;
	}
}

bool CompositeGeometry::isPart(DGeometry* geom)
{
	for (unsigned int x = 0; x < geometries.size(); x++)
	{
		if (geometries[x] == geom)
			return true;
	}

	return false;

}

void CompositeGeometry::onDependendyRemoval(DObject* obj)
{
	for (std::vector<DGeometry*>::iterator iter = geometries.begin(); iter != geometries.end(); iter++)
	{
		if (*iter == obj)
		{
			geometries.erase(iter);
			obj->setVisible(true);
		}
	}

	DGeometry::onDependencyRemoval(obj);
}

fltk::Widget* CompositeGeometry::getInterface()
{
	if (compositeWindow == NULL)
	{
		compositeWindow = new CompositeGeometryWindow(this, 0, 0, 330, 640, this->getName());
	}
	return compositeWindow;

}


