/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/
#ifndef _CompositeGeometry_H_
#define _CompositeGeometry_H_

#include "DGeometry.h"
#include <vector>
#include "CompositeGeometryWindow.h"

#ifdef WIN32
#ifndef DLLCOMPOSITEGEOMETRY_EXPORTS
#define	DLLCOMPOSITEGEOMETRY __declspec(dllexport)
#else
#define	DLLCOMPOSITEGEOMETRY __declspec(dllimport)
#endif
#else
#define DLLCOMPOSITEGEOMETRY
#endif

class DLLCOMPOSITEGEOMETRY CompositeGeometry : public DGeometry
{
	public:
		PlugIn* create(int argc, char **argv);

		CompositeGeometry();
	
		int commandPlugIn(int argc, char **argv);
		void output(int mode);
		void render(int argc, char ** argv, std::ofstream & file);
		int createMonitorPoints(int npoints, bool random);
		BoundingBox* calcBoundingBox(BoundingBox* box);
		void applyTransMatrix();
		fltk::Widget* getInterface();
		void save(int mode, std::ofstream& file);

		int getNumGeometries();
		DGeometry* getGeometry(unsigned int num);
		void addGeometry(DGeometry* geom);
		bool removeGeometry(DGeometry* geom);
		bool removeGeometry(unsigned int index);
		bool isPart(DGeometry* geom);

		void onDependendyRemoval(DObject* obj);

	private:
		std::vector<DGeometry*> geometries;
		CompositeGeometryWindow* compositeWindow;


};
#endif
