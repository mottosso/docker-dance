#ifndef COMPOSITEGEOMETRYWINDOW_H
#define COMPOSITEGEOMETRYWINDOW_H

#include "defs.h"
#include "GeometryWindow.h"
#include <fltk/Browser.h>

class CompositeGeometry;

class CompositeGeometryWindow : public fltk::Group
{
	public:
		CompositeGeometryWindow(CompositeGeometry* c, int x, int y, int width, int height, const char* name);
		void updateGUI();

		static void CompositeGeometryCB(Widget* widget, void* data);
		static void UpdatePartsCB(Widget* widget, void* data);

		GeometryWindow* geomWindow;
		CompositeGeometry* composite;
		fltk::Browser* browserGeometry;
		fltk::Button* buttonUpdateParts;

};
#endif

