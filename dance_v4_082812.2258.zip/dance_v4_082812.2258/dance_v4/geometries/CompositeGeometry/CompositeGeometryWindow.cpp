#include "CompositeGeometryWindow.h"
#include "CompositeGeometry.h"
#include "dance.h"

using namespace fltk;

CompositeGeometryWindow::CompositeGeometryWindow(CompositeGeometry* c, int x, int y, int width, int height, const char* name) : Group(x, y, width, height, name)
{
	this->composite = c;

	this->begin();

	geomWindow = new GeometryWindow(c, x, y, width, 440, NULL);

	this->browserGeometry = new Browser(10, 500, 150, 150, "Geometry Affected");
	this->buttonUpdateParts = new Button(10, 660, 100, 20, "Update Parts");
	this->buttonUpdateParts->callback(UpdatePartsCB, this);

	this->end();

	this->updateGUI();
}

void CompositeGeometryWindow::updateGUI()
{
	geomWindow->updateGUI();

	// update the fixed geometry list
	this->browserGeometry->clear();
	for (int x = 0; x < dance::AllGeometry->size(); x++)
	{
		DGeometry* geometry = (DGeometry*) dance::AllGeometry->get(x);
		if (geometry == this->composite)
			continue;
		CompositeGeometry* cgeometry = dynamic_cast<CompositeGeometry*>(geometry);
		if (cgeometry != NULL) // do not allow composites of other composites
			continue;
		CheckButton* check = new CheckButton(0, 0, this->browserGeometry->w() - 20, 20, geometry->getName());
		check->callback(CompositeGeometryCB, this);
		check->value(this->composite->isPart(geometry));
		this->browserGeometry->add(check);
	}

}

void CompositeGeometryWindow::CompositeGeometryCB(Widget* widget, void* data)
{
	CompositeGeometryWindow* win = (CompositeGeometryWindow*) data;

	CheckButton* check = (CheckButton*) widget;

	if (check->value())
	{
		DGeometry* geom = (DGeometry*) dance::AllGeometry->get((char*) check->label());
		if (geom != NULL)
		{
			win->composite->addGeometry(geom);
		}
	}
	else
	{
		DGeometry* geom = (DGeometry*) dance::AllGeometry->get((char*) check->label());
		if (geom != NULL)
		{
			win->composite->removeGeometry(geom);
		}
	}

	win->updateGUI();
}


void CompositeGeometryWindow::UpdatePartsCB(Widget* widget, void* data)
{
	CompositeGeometryWindow* win = (CompositeGeometryWindow*) data;

	win->updateGUI();
}

 
