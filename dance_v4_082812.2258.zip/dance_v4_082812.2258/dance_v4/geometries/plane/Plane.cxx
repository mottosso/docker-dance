/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "Plane.h"
#include <fltk/glut.h>
#include <fltk/gl.h>
#include "danceInterp.h"
#include "dance.h"
#include "DRendererManager.h"

PlugIn* Proxy()
{
	return new Plane();
}

PlugIn* Plane::create(int argc, char **argv)
{
	return new Plane();
}


Plane::Plane(): DGeometry()
{
	// front is CW
	setVector(points[0], -.5, 0.0, -.5);
	setVector(points[1], .5, 0.0, -.5);
	setVector(points[2], .5, 0.0, .5);
	setVector(points[3], -.5, 0.0, .5);

	double min = -1000;//-std::numeric_limits<double>::max();
	double max = 1000;//std::numeric_limits<double>::max();
	setVector(infinitePoints[0], min, 0.0, min);
	setVector(infinitePoints[1], max, 0.0, min);
	setVector(infinitePoints[2], max, 0.0, max);
	setVector(infinitePoints[3], min, 0.0, max);

	setVector(normal, 0, 1, 0);

	m_infinite = new BoolAttribute("infinite", false);
	m_infinite->getAttributeInfo()->setPriority(250);
	m_infinite->getAttributeInfo()->setLocked(true);
	m_infinite->registerObserver(this);
	this->addAttribute(m_infinite);
}

void Plane::output(int mode)
{
	DGeometry::output(mode);

	bool isInfinite = m_infinite->getValue();
	glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT);
	glEnable(GL_NORMALIZE);
	glEnable(GL_LIGHTING);

	Material* material = NULL ;
	if( mode & LDISPLAY_COMPUTE_SHADOW_MAP) 
	{
		setUpShadowMapPass1() ;
	}
	else if( mode & LDISPLAY_USE_SHADOW_MAP) 
	{
		setUpShadowMapPass3() ;
	}
	else if( mode & LDISPLAY_SHADOW_MAP_PASS4) 
	{
		setUpShadowMapPass4() ;
		material = this->getMaterial();
		if ( material != NULL)
		{
			material->setOpenGLMaterial(dance::shadowAlpha);
		}
		else
		{
			danceInterp::OutputMessage("%s has no material. Why?. It won't be shown", this->getName());
			return;
		}
	}
	else // set up material
	{
		material = this->getMaterial();
		if ( material != NULL)
		{
			material->setOpenGLMaterial();
		}
		else
		{
			danceInterp::OutputMessage("This cube has no material. Why?. It won't be shown");
			return;
		}
	}

	glPushMatrix();
	if (this->useTransMatrix())
	{
		double matrix[4][4];
		this->getTransMatrix(matrix);
		glMultMatrixd(&matrix[0][0]);
	}
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE,GL_FALSE) ;
	glFrontFace(GL_CCW) ;
	if (mode && LDISPLAY_SOLID && this->isShowSolid())
	{
		bool text = false ;
		glNormal3dv(normal);
		if ( material != NULL && material->has_texture() && !(mode & LDISPLAY_COMPUTE_SHADOW_MAP) ) {
			glEnable(GL_TEXTURE_2D);
			text = true ;
		}
		glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f); 
		if (!isInfinite)
			glVertex3dv(points[3]);
		else
			glVertex3dv(infinitePoints[3]);
		glTexCoord2f(1.0f, 0.0f); 
		if (!isInfinite)
			glVertex3dv(points[2]);
		else
			glVertex3dv(infinitePoints[2]);
		glTexCoord2f(1.0f, 1.0f);
		if (!isInfinite)
			glVertex3dv(points[1]);
		else
			glVertex3dv(infinitePoints[1]);
		glTexCoord2f(0.0f, 1.0f); 
		if (!isInfinite)
			glVertex3dv(points[0]);
		else
			glVertex3dv(infinitePoints[0]);
		glEnd();
		if( text ) glDisable(GL_TEXTURE_2D) ;

	}
	else if ((mode && LDISPLAY_WIRE) || (this->isShowMesh() || this->isShowVertices()))
	{
		glBegin(GL_LINE_LOOP);
		for (int x = 0; x < 4; x++)
			if (!isInfinite)
				glVertex3dv(points[x]);
			else
				glVertex3dv(infinitePoints[x]);
		glEnd();
	}

	if (mode & LDISPLAY_COMPUTE_SHADOW_MAP)
	{
		cleanUpAfterShadowMapPass1() ;
	}
	glPopMatrix();

	glPopAttrib();
	if( mode & LDISPLAY_COMPUTE_SHADOW_MAP) 
	{
		cleanUpAfterShadowMapPass1() ;
	}

}

int Plane::commandPlugIn(int argc, char **argv)
{
	int ret = DGeometry::commandPlugIn(argc, argv);
	if (ret != DANCE_CONTINUE)
		return ret;

	return DANCE_OK;
}


void Plane::render(int argc, char ** argv, std::ofstream & file)
{
	int i, j;

	if (argc > 0 && strcmp(argv[0],"povray") == 0)
	{
#ifdef _DEBUG
		file << "/* Plane: \n";
		write_properties(file);
		file << "*/\n\n";
#endif

		// correct this code! Must use points array and not explicit values AS 8/10/05
//		file << "box {\n  <-0.5, -0.00001, -0.5>, <0.5, 0.00001, 0.5>\n";

		std::ofstream* objfile = dance::AllRenderers->getObjectFileStream();
		std::string planename = this->getName();
		if (planename == "plane")
		{
			planename.append("_");
		}

		*objfile << "#declare " << planename.c_str() << " = \n";
		*objfile << "polygon {\n   4, <-0.5, 0, -0.5>, <-0.5, 0, 0.5>, <0.5, 0, 0.5>, <0.5, 0, -0.5>\n";
		*objfile << "  texture {";
		
		if (m_material->getTexture() == NULL)
		{
			*objfile << getMaterial()->getSafeMaterialName();
		// 'default' is a reserved word in povray
			if (!strcmp("default", getMaterial()->getSafeMaterialName()))
				*objfile << "_}\n";
			else
				*objfile << "}\n";
		}
		else
		{
			*objfile << "\n  ";
			m_material->getTexture()->write_texture_povray(*objfile, NULL, "rotate<-90, 0, 0>\n  translate<-0.5, 0.5, 0.5>");
		}

		*objfile << "}\n";

		//.pov file

		if (this->isVisible() == false)
			return;

		file << "object {" << planename.c_str() << "\n";
		file << "matrix\n  <";

		for (j=0; j<4; j++) {
			for (i=0; i<3; i++) 
				file << m_transMatrix[j][i] << ((j==3 && i==2) ? ">" : ",");
			file << "\n";
		}

		file << "#ifdef (SETMATRIX2)\n";
		file << "transform SETMATRIX2\n";
		file << "#end\n";
		file << "#ifdef (SETMATRIX)\n";
		file << "transform SETMATRIX\n";
		file << "#end\n";

		file << "}\n\n";


	}

}

BoundingBox* Plane::calcBoundingBox(BoundingBox* box)
{
    // a general bounding box
	m_BoundingBox.xMin = MAXFLOAT; 
	m_BoundingBox.xMax = MINFLOAT;;
	m_BoundingBox.yMin = MAXFLOAT;
	m_BoundingBox.yMax = MINFLOAT;
	m_BoundingBox.zMin = MAXFLOAT;
	m_BoundingBox.zMax = MINFLOAT;

	double matrix[4][4];
	this->getTransMatrix(matrix);
	for( int i = 0 ; i <  4 ; i++ )
	{
		Vector curPoint;
		VecCopy(curPoint, points[i]);
		if (this->useTransMatrix())
			transformPoint_mat(curPoint, matrix);

		if (curPoint[0] < m_BoundingBox.xMin)
			m_BoundingBox.xMin = curPoint[0];
		if (curPoint[0] > m_BoundingBox.xMax)
			m_BoundingBox.xMax = curPoint[0];

		if (curPoint[1] < m_BoundingBox.yMin)
			m_BoundingBox.yMin = curPoint[1];
		if (curPoint[1] > m_BoundingBox.yMax)
			m_BoundingBox.yMax = curPoint[1];

		if (curPoint[2] < m_BoundingBox.zMin)
			m_BoundingBox.zMin = curPoint[2];
		if (curPoint[2] > m_BoundingBox.zMax)
			m_BoundingBox.zMax = curPoint[2];
	}
	if (box)
		box->copy(&m_BoundingBox);

	return &m_BoundingBox;
	}

double* Plane::getNormal()
{
	return &normal[0];
}

// Transformation of the normal works only for rigid body transformations.
void Plane::applyTransMatrix()
{
	double matrix[4][4];
	this->getTransMatrix(matrix);
	for (int x = 0; x < 4; x++)
		transformPoint_mat(points[x], matrix);
	transformPoint_mat(normal, matrix);
	VecNormalize(normal);
}

int Plane::createMonitorPoints(int npoints, bool random)
{
      AllocateMonitorPoints(4);

	  for (int x = 0; x < 4; x++)
		  VecCopy(m_MonitorPoints.m_Point[x], points[x]);

    return m_MonitorPoints.m_NumPoints ;
}


fltk::Widget* Plane::getInterface()
{
	return DGeometry::getInterface();
}

void Plane::save(int mode, std::ofstream& file)
{
	if (mode == 0)
	{
		file << "dance.instance(\"Plane\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
	}

	DGeometry::save(mode, file);
}

void Plane::notify(DSubject* subject)
{
	DGeometry::notify(subject);

	if (subject == m_infinite)
	{
		dance::AllViews->postRedisplay();
	}
}