/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "Cube.h"
#include "opengl.h"
#include "danceInterp.h"
#include "dance.h"
#include "DRendererManager.h"

PlugIn* Proxy()
{
	return new Cube();
}

PlugIn* Cube::create(int argc, char **argv)
{
	return new Cube();
}


Cube::Cube(): DGeometry()
{
	setVector(points[0], .5, .5, .5);
	setVector(points[1], .5, -.5, .5);
	setVector(points[2], .5, .5, -.5);
	setVector(points[3], .5, -.5, -.5);
	setVector(points[4], -.5, .5, .5);
	setVector(points[5], -.5, -.5, .5);
	setVector(points[6], -.5, .5, -.5);
	setVector(points[7], -.5, -.5, -.5);

	setVector(normals[0], -1.0, 0.0, 0.0);
	setVector(normals[1], 1.0, 0.0, 0.0);
	setVector(normals[2], 0.0, -1.0, 0.0);
	setVector(normals[3], 0.0, 1.0, 0.0);
	setVector(normals[4], 0.0, 0.0, 1.0);
	setVector(normals[5], 0.0, 0.0, -1.0);
}


void Cube::output(int mode)
{
	DGeometry::output(mode);

	Material* material = NULL ;
	if( mode & LDISPLAY_COMPUTE_SHADOW_MAP) 
	{
		setUpShadowMapPass1() ;
	}
	else if( mode & LDISPLAY_USE_SHADOW_MAP) 
	{
		setUpShadowMapPass3() ;
	}
	else if( mode & LDISPLAY_SHADOW_MAP_PASS4) 
	{
		setUpShadowMapPass4() ;
		material = this->getMaterial();
		if ( material != NULL)
		{
			material->setOpenGLMaterial(dance::shadowAlpha);
		}
		else
		{
			danceInterp::OutputMessage("%s has no material. Why?. It won't be shown", this->getName());
			return;
		}
	}
	else // set up material
	{
		material = this->getMaterial();
		if ( material != NULL)
		{
			material->setOpenGLMaterial();
		}
		else
		{
			danceInterp::OutputMessage("This cube has no material. Why?. It won't be shown");
			return;
		}
	}
	
	if ( material && material->has_texture())
		glPushAttrib(GL_LIGHTING_BIT|GL_TEXTURE_2D);
	else
		glPushAttrib(GL_LIGHTING_BIT);


	glPushMatrix();
	if (this->useTransMatrix())
	{
		double matrix[4][4];
		this->getTransMatrix(matrix);
		glMultMatrixd(&matrix[0][0]);
	}


	if ((mode & LDISPLAY_SOLID) && this->isShowSolid())
	{
		glEnable(GL_NORMALIZE);
		if ( material && material->has_texture() ) 
		{
			glBegin(GL_QUADS);		

			// -X SIDE
			glNormal3dv(normals[0]);
			glTexCoord2f(1.0f, 0.0f); glVertex3dv(points[5]);
			glTexCoord2f(1.0f, 1.0f); glVertex3dv(points[4]);
			glTexCoord2f(0.0f, 1.0f); glVertex3dv(points[6]);
			glTexCoord2f(0.0f, 0.0f); glVertex3dv(points[7]);


			// +X SIDE
			glNormal3dv(normals[1]);
			glTexCoord2f(0.0f, 1.0f); glVertex3dv(points[0]);
			glTexCoord2f(0.0f, 0.0f); glVertex3dv(points[1]);
			glTexCoord2f(1.0f, 0.0f); glVertex3dv(points[3]);
			glTexCoord2f(1.0f, 1.0f); glVertex3dv(points[2]);

			// -Y SIDE  //
			glNormal3dv(normals[2]);
			glTexCoord2f(0.0f, 0.0f); glVertex3dv(points[7]);
			glTexCoord2f(1.0f, 0.0f); glVertex3dv(points[3]);
			glTexCoord2f(1.0f, 1.0f); glVertex3dv(points[1]);
			glTexCoord2f(0.0f, 1.0f); glVertex3dv(points[5]);

			// +Y SIDE 
			glNormal3dv(normals[3]);
			glTexCoord2f(0.0f, 0.0f); glVertex3dv(points[4]);
			glTexCoord2f(1.0f, 0.0f); glVertex3dv(points[0]);
			glTexCoord2f(1.0f, 1.0f); glVertex3dv(points[2]);
			glTexCoord2f(0.0f, 1.0f); glVertex3dv(points[6]);

			// +Z side
			glNormal3dv(normals[4]);
			glTexCoord2f(0.0f, 0.0f); glVertex3dv(points[5]);
			glTexCoord2f(1.0f, 0.0f); glVertex3dv(points[1]);
			glTexCoord2f(1.0f, 1.0f); glVertex3dv(points[0]);
			glTexCoord2f(0.0f, 1.0f); glVertex3dv(points[4]);

			// -Z side
			glNormal3dv(normals[5]);
			glTexCoord2f(1.0f, 1.0f); glVertex3dv(points[6]);
			glTexCoord2f(0.0f, 1.0f); glVertex3dv(points[2]);
			glTexCoord2f(0.0f, 0.0f); glVertex3dv(points[3]);
			glTexCoord2f(1.0f, 0.0f); glVertex3dv(points[7]);

			glEnd();
		} 
		else 
		{
			glBegin(GL_QUADS);		

			// -X SIDE
			glNormal3dv(normals[0]);
			glVertex3dv(points[5]);
			glVertex3dv(points[4]);
			glVertex3dv(points[6]);
			glVertex3dv(points[7]);


			// +X SIDE
			glNormal3dv(normals[1]);
			glVertex3dv(points[0]);
			glVertex3dv(points[1]);
			glVertex3dv(points[3]);
			glVertex3dv(points[2]);

			// -Y SIDE  
			glNormal3dv(normals[2]);
			glVertex3dv(points[7]);
			glVertex3dv(points[3]);
			glVertex3dv(points[1]);
			glVertex3dv(points[5]);

			// +Y SIDE 
			glNormal3dv(normals[3]);
			glVertex3dv(points[4]);
			glVertex3dv(points[0]);
			glVertex3dv(points[2]);
			glVertex3dv(points[6]);

			// +Z side
			glNormal3dv(normals[4]);
			glVertex3dv(points[5]);
			glVertex3dv(points[1]);
			glVertex3dv(points[0]);
			glVertex3dv(points[4]);

			// -Z side
			glNormal3dv(normals[5]);
			glVertex3dv(points[6]);
			glVertex3dv(points[2]);
			glVertex3dv(points[3]);
			glVertex3dv(points[7]);

			glEnd();
		}
	}
	else if ((mode & LDISPLAY_WIRE) || this->isShowMesh())
	{
			glDisable(GL_LIGHTING);
			glColor3f(1.0f, 1.0f, 1.0f);
			// -X SIDE
			glBegin(GL_LINE_STRIP);		
			glVertex3dv(points[5]);
			glVertex3dv(points[4]);
			glVertex3dv(points[6]);
			glVertex3dv(points[7]);
			glEnd();

			// +X SIDE
			glBegin(GL_LINE_LOOP);		
			glVertex3dv(points[0]);
			glVertex3dv(points[1]);
			glVertex3dv(points[3]);
			glVertex3dv(points[2]);
			glEnd();

			// -Y SIDE  //
			glBegin(GL_LINE_LOOP);		
			glVertex3dv(points[7]);
			glVertex3dv(points[3]);
			glVertex3dv(points[1]);
			glVertex3dv(points[5]);
			glEnd();

			// +Y SIDE 
			glBegin(GL_LINE_LOOP);		
			glVertex3dv(points[4]);
			glVertex3dv(points[0]);
			glVertex3dv(points[2]);
			glVertex3dv(points[6]);
			glEnd();

			// +Z side
			glBegin(GL_LINE_LOOP);		
			glVertex3dv(points[5]);
			glVertex3dv(points[1]);
			glVertex3dv(points[0]);
			glVertex3dv(points[4]);
			glEnd();

			// -Z side
			glBegin(GL_LINE_LOOP);		
			glVertex3dv(points[6]);
			glVertex3dv(points[2]);
			glVertex3dv(points[3]);
			glVertex3dv(points[7]);
			glEnd();
	}
	else if (this->isShowVertices())
	{
		glDisable(GL_LIGHTING);
		glColor3f(1.0f, 1.0f, 1.0f);

		glBegin(GL_POINTS);		
		for (int x = 0; x < 8; x++)
		{
			glVertex3dv(points[x]);
		}
		glEnd();
	}
	
	if( mode & LDISPLAY_COMPUTE_SHADOW_MAP) 
	{
		cleanUpAfterShadowMapPass1() ;
	}
	glPopMatrix();

	glPopAttrib();
}

int Cube::commandPlugIn(int argc, char **argv)
{
	int ret = DGeometry::commandPlugIn(argc, argv);
	if (ret != DANCE_CONTINUE)
		return ret;

	return DANCE_OK;
}

// Rendering a cube
void Cube::render(int argc, char ** argv, std::ofstream & file)
{
	int i, j;

	if (argc > 0 && strcmp(argv[0],"povray") == 0)
	{
#ifdef _DEBUG
		file << "/* Cube: \n";
		this->write_properties(file);
		file << "*/\n\n";
#endif

		char materialName[512];
		sprintf(materialName, "%s", getMaterial()->getSafeMaterialName());
		if (!strcmp("default", getMaterial()->getSafeMaterialName())) 
			strcat(materialName, "_");
		char side[512];
		sprintf(side, "polygon {\n4, <-0.5, -0.5>, <-0.5, 0.5>, <0.5, 0.5>, <0.5, -0.5>\n");
		
		std::ofstream* objfile = dance::AllRenderers->getObjectFileStream();
		char cubename[512];
		strcpy(cubename, this->getName());
		if (strcmp(cubename, "cube") == 0)
		{
			strcat(cubename, "_");
		}
		*objfile << "#declare "<< cubename << " = \n";
		*objfile << "union {\nobject {\n";
		*objfile << side;
		*objfile << "translate <0,0,0.5>\n";
		
		//Changed!!
		//*objfile << "   texture {" << materialName << "}\n";
		*objfile << "   texture {";

		if (m_material->getTexture() == NULL)
			*objfile << materialName << "}\n";
		else
		{
			*objfile << "\n  ";
			m_material->getTexture()->write_texture_povray(*objfile, NULL, "translate<-0.5, -0.5, 0>");
		}

		*objfile << "}\n";
		*objfile << "}\n";
		*objfile << "object {\n";
		*objfile << side;
		*objfile << "rotate<0,180,0>\n";
		*objfile << "translate <0,0,-0.5>\n";

		*objfile << "   texture {";
		if (m_material->getTexture() == NULL)
			*objfile << materialName << "}\n";
		else
		{
			*objfile << "\n  ";
			m_material->getTexture()->write_texture_povray(*objfile, NULL, "rotate<0, 180, 0>\n   translate<0.5, -0.5, -.5>");
		}

		*objfile << "}\n";
		*objfile << "}\n";
		*objfile << "object {\n";
		*objfile << side;
		*objfile << "rotate<0,-90,0>\n";
		*objfile << "translate <-0.5,0,0>\n";

		*objfile << "   texture {";
		if (m_material->getTexture() == NULL)
			*objfile << materialName << "}\n";
		else
		{
			*objfile << "\n  ";
			m_material->getTexture()->write_texture_povray(*objfile, NULL, "rotate<0, -90, 0>\n   translate<-0.5, -0.5, -.5>");
		}

		*objfile << "}\n";
		*objfile << "}\n";
		*objfile << "object {\n";
		*objfile << side;
		*objfile << "rotate<0,90,0>\n";
		*objfile << "translate <0.5,0,0>\n";

		*objfile << "   texture {";
		if (m_material->getTexture() == NULL)
			*objfile << materialName << "}\n";
		else
		{
			*objfile << "\n  ";
			m_material->getTexture()->write_texture_povray(*objfile, NULL, "rotate<0, 90, 0>\n   translate<0.5, -0.5, 0.5>");
		}

		*objfile << "}\n";
		*objfile << "}\n";
		*objfile << "object {\n";
		*objfile << side;
		*objfile << "rotate<-90,0,0>\n";
		*objfile << "translate <0,0.5,0>\n";

		*objfile << "   texture {";
		if (m_material->getTexture() == NULL)
			*objfile << materialName << "}\n";
		else
		{
			*objfile << "\n  ";
			m_material->getTexture()->write_texture_povray(*objfile, NULL, "rotate<-90, 0, 0>\n   translate<-0.5, -0.5, 0.5>");
		}

		*objfile << "}\n";
		*objfile << "}\n";
		*objfile << "object {\n";
		*objfile << side;
		*objfile << "rotate<90,0,0>\n";
		*objfile << "translate <0,-0.5,0>\n";

		*objfile << "   texture {";
		if (m_material->getTexture() == NULL)
			*objfile << materialName << "}\n";
		else
		{
			*objfile << "\n  ";
			m_material->getTexture()->write_texture_povray(*objfile, NULL, "rotate<90, 0, 0>\n   translate<-0.5, -0.5, -.5>");
		}

		*objfile << "}\n";
		*objfile << "}\n";
		*objfile << "}\n";

		//.pov file

		if (this->isVisible() == false)
			return;

		file << "object {" << cubename << "\n";
		file << "matrix\n  <";
		for (j=0; j<4; j++) {
			for (i=0; i<3; i++) 
				file << m_transMatrix[j][i] << ((j==3 && i==2) ? ">" : ",");
			file << "\n";
		}

		file << "#ifdef (SETMATRIX2)\n";
		file << "transform SETMATRIX2\n";
		file << "#end\n";
		file << "#ifdef (SETMATRIX)\n";
		file << "transform SETMATRIX\n";
		file << "#end\n";


		file << "}\n\n";



	}
}

void Cube::applyTransMatrix()
{
	double matrix[4][4];
	this->getTransMatrix(matrix);
	for (int x = 0; x < 8; x++)
	{
		transformPoint_mat(points[x], matrix);
	}
	for (int x = 0; x < 6; x++)
	{
		transformPoint_mat(normals[x], matrix);
		VecNormalize(normals[x]);
	}
			
	this->setUseTransMatrix(false);
}

int Cube::createMonitorPoints(int npoints, bool random)
{
    AllocateMonitorPoints(8);

	double transMatrix[4][4];
	this->getTransMatrix(transMatrix);
	for (int x = 0; x < 8; x++)
	{
		VecCopy(m_MonitorPoints.m_Point[x], points[x]);
		if (this->useTransMatrix())
			transformPoint_mat(m_MonitorPoints.m_Point[x], transMatrix);
	}
	
    return m_MonitorPoints.m_NumPoints ;
}

BoundingBox* Cube::calcBoundingBox(BoundingBox* box)
{
    // a general bounding box
	m_BoundingBox.xMin = MAXFLOAT; 
	m_BoundingBox.xMax = MINFLOAT;;
	m_BoundingBox.yMin = MAXFLOAT;
	m_BoundingBox.yMax = MINFLOAT;
	m_BoundingBox.zMin = MAXFLOAT;
	m_BoundingBox.zMax = MINFLOAT;

	double matrix[4][4];
	this->getTransMatrix(matrix);
	for( int i = 0 ; i <  8 ; i++ )
	{
		Vector curPoint;
		VecCopy(curPoint, points[i]);
		if (this->useTransMatrix())
			transformPoint_mat(curPoint, matrix);

		if (curPoint[0] < m_BoundingBox.xMin)
			m_BoundingBox.xMin = curPoint[0];
		if (curPoint[0] > m_BoundingBox.xMax)
			m_BoundingBox.xMax = curPoint[0];

		if (curPoint[1] < m_BoundingBox.yMin)
			m_BoundingBox.yMin = curPoint[1];
		if (curPoint[1] > m_BoundingBox.yMax)
			m_BoundingBox.yMax = curPoint[1];

		if (curPoint[2] < m_BoundingBox.zMin)
			m_BoundingBox.zMin = curPoint[2];
		if (curPoint[2] > m_BoundingBox.zMax)
			m_BoundingBox.zMax = curPoint[2];
	}
	if (box)
		box->copy(&m_BoundingBox);

	return &m_BoundingBox;
}

fltk::Widget* Cube::getInterface()
{
	return DGeometry::getInterface();
}

void Cube::save(int mode, std::ofstream& file)
{
	if (mode == 0)
	{
		file << "dance.instance(\"Cube\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
		// material
		char buff[512];
		Material* m = this->getMaterial();

		if (m != NULL)
		{
			sprintf(buff, "\"material\", \"%s\"", this->getMaterial()->getMaterialName());
			pythonSave(file, buff);
		}

	}

	DGeometry::save(mode, file);
}


