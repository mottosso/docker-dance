/**************************************************
Copyright 2005 by Ari Shapiro and Petros Faloutsos

DANCE
Dynamic ANimation and Control Environment

 ***************************************************************
 ******General License Agreement and Lack of Warranty ***********
 ****************************************************************

This software is distributed for noncommercial use in the hope that it will 
be useful but WITHOUT ANY WARRANTY. The author(s) do not accept responsibility
to anyone for the consequences	of using it or for whether it serves any 
particular purpose or works at all. No warranty is made about the software 
or its performance. Commercial use is prohibited. 

Any plugin code written for DANCE belongs to the developer of that plugin,
who is free to license that code in any manner desired.

Content and code development by third parties (such as FLTK, Python, 
ImageMagick, ODE) may be governed by different licenses.
You may modify and distribute this software as long as you give credit 
to the original authors by including the following text in every file 
that is distributed: */

/*********************************************************
	Copyright 2005 by Ari Shapiro and Petros Faloutsos

	DANCE
	Dynamic ANimation and Control Environment
	-----------------------------------------
	AUTHOR:
		Ari Shapiro (ashapiro@cs.ucla.edu)
	ORIGINAL AUTHORS: 
		Victor Ng (victorng@dgp.toronto.edu)
		Petros Faloutsos (pfal@cs.ucla.edu)
	CONTRIBUTORS:
		Yong Cao (abingcao@cs.ucla.edu)
		Paco Abad (fjabad@dsic.upv.es)
**********************************************************/

#include "opengl.h"
#include "danceInterp.h"
#include "Capsule.h"
#include "dance.h"
#include "DRendererManager.h"

static int CAP_NUM_SUBDIVISIONS = 10 ;

PlugIn* Proxy()
{
	return new Capsule();
}

PlugIn* Capsule::create(int argc, char **argv)
{
	return new Capsule();
}

void Capsule::UpdatePoints(void)
{
	setVector(m_points[0], this->getRadius(), 0, this->getLength()*0.5);
	setVector(m_points[1], 0, -this->getRadius(), this->getLength()*0.5);
	setVector(m_points[2], this->getRadius(), 0, -this->getLength()*0.5);
	setVector(m_points[3], 0, -this->getRadius(), -this->getLength()*0.5);
	setVector(m_points[4], 0, this->getRadius(), this->getLength()*0.5);
	setVector(m_points[5], -this->getRadius(), 0, this->getLength()*0.5);
	setVector(m_points[6], 0, this->getRadius(), -this->getLength()*0.5);
	setVector(m_points[7], -this->getRadius(), 0, -this->getLength()*0.5);

	setVector(m_points[8], this->getRadius(), 0,0);
	setVector(m_points[9], 0, -this->getRadius(),0);
	setVector(m_points[10], 0, this->getRadius(), 0) ;
	setVector(m_points[11], -this->getRadius(), 0, 0) ;

}

Capsule::Capsule(): DGeometry()
{
	qobj=gluNewQuadric();
	gluQuadricDrawStyle(qobj, GLU_FILL);
	gluQuadricNormals(qobj, GLU_SMOOTH);
	gluQuadricTexture(qobj, GL_TRUE);

	setIdentMat(&appliedMatrix[0][0], 4);

	m_radius = new DoubleAttribute("radius", .2);
	m_radius->getAttributeInfo()->setPriority(210);
	m_radius->getAttributeInfo()->setLocked(true);
	m_radius->setMin(0);
	m_radius->registerObserver(this);
	this->addAttribute(m_radius);

	m_length = new DoubleAttribute("length", 1);
	m_length->getAttributeInfo()->setPriority(220);
	m_length->getAttributeInfo()->setLocked(true);
	m_length->setMin(0);
	m_length->registerObserver(this);
	this->addAttribute(m_length);

	UpdatePoints();
}

Capsule::~Capsule()
{
	gluDeleteQuadric(qobj);
}

void Capsule::output(int mode)
{
	DGeometry::output(mode);

	Material* material = NULL ;
	if( mode & LDISPLAY_COMPUTE_SHADOW_MAP) 
	{
		setUpShadowMapPass1() ;
	}
	else if( mode & LDISPLAY_USE_SHADOW_MAP) 
	{
		setUpShadowMapPass3() ;
	}
	else if( mode & LDISPLAY_SHADOW_MAP_PASS4) 
	{
		setUpShadowMapPass4() ;
		material = this->getMaterial();
		if ( material != NULL)
		{
			material->setOpenGLMaterial(dance::shadowAlpha);
		}
		else
		{
			danceInterp::OutputMessage("%s has no material. Why?. It won't be shown", this->getName());
			return;
		}
	}
	else // set up material
	{
		material = this->getMaterial();
		if ( material != NULL)
		{
			material->setOpenGLMaterial();
		}
		else
		{
			danceInterp::OutputMessage("This cube has no material. Why?. It won't be shown");
			return;
		}
	}

	glPushAttrib(GL_LIGHTING_BIT);

	
	glPushMatrix();

	
	if (this->useTransMatrix())
	{
		double matrix[4][4];
		this->getTransMatrix(matrix);
		glMultMatrixd(&matrix[0][0]);
	}
	if ((mode & LDISPLAY_SOLID) && this->isShowSolid()) {
			glTranslated(0, 0, -getLength() / 2.0);
			gluCylinder(qobj, getRadius(), getRadius(), getLength(), CAP_NUM_SUBDIVISIONS, CAP_NUM_SUBDIVISIONS);
			glutSolidSphere(getRadius(), CAP_NUM_SUBDIVISIONS, CAP_NUM_SUBDIVISIONS);
			glTranslated(0, 0, getLength());
			glutSolidSphere(getRadius(), CAP_NUM_SUBDIVISIONS, CAP_NUM_SUBDIVISIONS);
	}
	else if ((mode & LDISPLAY_WIRE) || this->isShowMesh() || this->isShowVertices())
	{
		glDisable(GL_LIGHTING);
		glTranslated(0, 0, -getLength() / 2.0);
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE) ;
		gluCylinder(qobj, getRadius(), getRadius(), getLength(), CAP_NUM_SUBDIVISIONS, CAP_NUM_SUBDIVISIONS);
		glutWireSphere(getRadius(), CAP_NUM_SUBDIVISIONS, CAP_NUM_SUBDIVISIONS) ;
		glTranslated(0, 0, getLength());
		glutWireSphere(getRadius(), CAP_NUM_SUBDIVISIONS, CAP_NUM_SUBDIVISIONS) ;
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL) ;
	}
	
	
	glPopMatrix();


	glPopAttrib();

	if( mode & LDISPLAY_COMPUTE_SHADOW_MAP) 
	{
		cleanUpAfterShadowMapPass1() ;
	}



}

int Capsule::commandPlugIn(int argc, char **argv)
{
	int ret = DGeometry::commandPlugIn(argc, argv);
	if (ret != DANCE_CONTINUE)
		return ret;

	if (strcmp(argv[0], "radius") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.geometry(\"%s\", \"radius\", <radius>)", this->getName());
			return DANCE_ERROR;
		}
		double r = atof(argv[1]);
		this->setRadius(r);
		danceInterp::OutputMessage("Radius of capsule %s set to %f", this->getName(), this->getRadius());
		return DANCE_OK;
	}
	else if (strcmp(argv[0], "length") == 0)
	{
		if (argc < 2)
		{
			danceInterp::OutputMessage("Usage: dance.geometry(\"%s\", \"length\", <length>)", this->getName());
			return DANCE_ERROR;
		}
		double r = atof(argv[1]);
		this->setLength(r);
		danceInterp::OutputMessage("Length of capsule %s set to %f", this->getName(), this->getRadius());
		return DANCE_OK;
	}	 

	return DANCE_CONTINUE;
}

// Rendering a Capsule
void Capsule::render(int argc, char ** argv, std::ofstream & file)
{
	int i, j;

	if (argc > 0 && strcmp(argv[0],"povray") == 0)
	{
#ifdef _DEBUG
		file << "/* Capsule: \n";
		write_properties(file);
		file << "length: " << this->getLength() << "\n";
		file << "radius: " << this->getRadius() << "\n";
		file << "*/\n\n";
#endif
		std::ofstream* objfile = dance::AllRenderers->getObjectFileStream();
		std::string capsulename = this->getName();
		if (capsulename == "capsule")
		{
			capsulename.append("_");
		}
		*objfile << "#declare " << capsulename.c_str() << " = \n";
		*objfile << "union {\n";
		*objfile << "sphere {\n  <0, 0, " << -this->getLength() / 2.0 << ">, " << this->getRadius() << "\n";
		*objfile << "  texture {" << m_material->getSafeMaterialName();
		
		// 'default' is a reserved word in povray
		if (!strcmp("default", m_material->getSafeMaterialName()))
			*objfile << "_";
		*objfile << "}\n";
		*objfile << "}\n";

		*objfile << "cylinder {\n  <0, 0, " << -this->getLength() / 2.0 << ">, <0, 0, " << this->getLength() / 2.0 << ">, " << this->getRadius() << "\n";
		*objfile << "  texture {" << m_material->getSafeMaterialName();
		
		// 'default' is a reserved word in povray
		if (!strcmp("default", m_material->getSafeMaterialName()))
			*objfile << "_";
		*objfile << "}\n";
		*objfile << "}\n";

		*objfile << "sphere {\n  <0, 0, " << this->getLength() / 2.0 << ">, " << this->getRadius() << "\n";
		*objfile << "  texture {" << m_material->getSafeMaterialName();
		
		// 'default' is a reserved word in povray
		if (!strcmp("default", m_material->getSafeMaterialName()))
			*objfile << "_";
		*objfile << "}\n";
		*objfile << "}\n";


		*objfile << "}\n";

		//.pov file
		if (this->isVisible() == false)
			return;

		file << "object {" << capsulename.c_str() << "\n";
		

		file << "matrix\n  <";
		for (j=0; j<4; j++) {
			for (i=0; i<3; i++) 
				file << m_transMatrix[j][i] << ((j==3 && i==2) ? ">" : ",");
			file << (j==3 ? "\n" : "\n  ");
		}
		file << "#ifdef (SETMATRIX2)\n";
		file << "transform SETMATRIX2\n";
		file << "#end\n";
		file << "#ifdef (SETMATRIX)\n";
		file << "transform SETMATRIX\n";
		file << "#end\n";

		file << "}\n\n";



	}
}

void Capsule::applyTransMatrix()
{
	double matrix[4][4];
	this->getTransMatrix(matrix);

	double temp[4][4];
	for (int r = 0; r < 4; r++)
		for (int c = 0; c < 4; c++)
			temp[r][c] = appliedMatrix[r][c];
	
	//multArray(&appliedMatrix[0][0], &temp[0][0], &matrix[0][0], 4, 4, 4);
	multArray4x4(appliedMatrix, temp, matrix);

}

int Capsule::createMonitorPoints(int npoints, bool random)
{ 
    AllocateMonitorPoints(12);
	UpdatePoints();

	double transMatrix[4][4];
	this->getTransMatrix(transMatrix);
	for (int x = 0; x < 12; x++)
	{
		VecCopy(m_MonitorPoints.m_Point[x], m_points[x]);
		if (this->useTransMatrix())
			transformPoint_mat(m_MonitorPoints.m_Point[x], transMatrix);
	}
	
    return m_MonitorPoints.m_NumPoints ;

}

BoundingBox* Capsule::calcBoundingBox(BoundingBox* box)
{
    
	// put a box around a unit sphere and then multiply
	// by the transformation matrix

	Vector points[8];
	setVector(points[0], this->getRadius(), this->getRadius(), this->getLength());
	setVector(points[1], this->getRadius(), -this->getRadius(), this->getLength());
	setVector(points[2], this->getRadius(), this->getRadius(), -this->getLength());
	setVector(points[3], this->getRadius(), -this->getRadius(), -this->getLength());
	setVector(points[4], -this->getRadius(), this->getRadius(), this->getLength());
	setVector(points[5], -this->getRadius(), -this->getRadius(), this->getLength());
	setVector(points[6], -this->getRadius(), this->getRadius(), -this->getLength());
	setVector(points[7], -this->getRadius(), -this->getRadius(), -this->getLength());

    // a general bounding box
	m_BoundingBox.xMin = MAXFLOAT; 
	m_BoundingBox.xMax = MINFLOAT;;
	m_BoundingBox.yMin = MAXFLOAT;
	m_BoundingBox.yMax = MINFLOAT;
	m_BoundingBox.zMin = MAXFLOAT;
	m_BoundingBox.zMax = MINFLOAT;

	double matrix[4][4];
	this->getTransMatrix(matrix);

	for( int i = 0 ; i <  8 ; i++ )
	{
		Vector curPoint;
		VecCopy(curPoint, points[i]);
		if (this->useTransMatrix())
			transformPoint_mat(curPoint, matrix);

		if (curPoint[0] < m_BoundingBox.xMin)
			m_BoundingBox.xMin = curPoint[0];
		if (curPoint[0] > m_BoundingBox.xMax)
			m_BoundingBox.xMax = curPoint[0];

		if (curPoint[1] < m_BoundingBox.yMin)
			m_BoundingBox.yMin = curPoint[1];
		if (curPoint[1] > m_BoundingBox.yMax)
			m_BoundingBox.yMax = curPoint[1];

		if (curPoint[2] < m_BoundingBox.zMin)
			m_BoundingBox.zMin = curPoint[2];
		if (curPoint[2] > m_BoundingBox.zMax)
			m_BoundingBox.zMax = curPoint[2];
	}
	if (box)
		box->copy(&m_BoundingBox);

	return &m_BoundingBox;
}

void Capsule::save(int mode, std::ofstream& file)
{
	if (mode == 0)
	{
		file << "dance.instance(\"Capsule\", \"" << this->getName() << "\")" << std::endl; 
	}
	else if (mode == 1)
	{
	}

	DGeometry::save(mode, file);
}

fltk::Widget* Capsule::getInterface()
{
	return DGeometry::getInterface();
}

void Capsule::setLength(double val)
{
	m_length->setValue(val);
}

double Capsule::getLength()
{
	return m_length->getValue();
}

void Capsule::setRadius(double val)
{
	m_radius->setValue(val);
}

double Capsule::getRadius()
{
	return m_radius->getValue();
}

void Capsule::notify(DSubject* subject)
{
	DGeometry::notify(subject);
	
	if (subject == m_radius || subject == m_length)
	{
		UpdatePoints();
		dance::AllViews->postRedisplay();
	}
}
