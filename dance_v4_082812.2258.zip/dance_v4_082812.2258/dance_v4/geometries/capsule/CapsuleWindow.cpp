#include "CapsuleWindow.h"
#include "Capsule.h"
#include "dance.h"

using namespace fltk;

CapsuleWindow::CapsuleWindow(Capsule* c, int x, int y, int width, int height, const char* name) : GeometryWindow((DGeometry*) c, x, y, width, height, name)
{
	this->capsule = c;

	this->begin();

	this->inputLength = new FloatInput(95, 200, 40, 20, "Length");
	this->inputLength->callback(length_cb, this);
	this->wheelLength = new ThumbWheel(160, 200, 80, 20);
	this->wheelLength->range(0, 10000000);
	this->wheelLength->callback(length_cb, this);

	this->inputRadius = new FloatInput(95, 235, 40, 20, "Radius");
	this->inputRadius->callback(radius_cb, this);
	this->wheelRadius = new ThumbWheel(160, 235, 80, 20);
	this->wheelRadius->range(0, 10000000);
	this->wheelRadius->callback(radius_cb, this);


	this->end();

	this->updateGUI();
}

void CapsuleWindow::updateGUI()
{
	GeometryWindow::updateGUI();

	this->inputScaleUniform->hide();
	this->ThumbWheelScaleUniform->hide();
	this->ThumbWheelScaleUniform->hide();
	for (int x = 0; x < 3; x++)
	{
		this->inputScale[x]->hide();
		this->ThumbWheelScale[x]->hide();
	}

	this->inputLength->value(this->capsule->getLength());
	this->inputRadius->value(this->capsule->getRadius());
	this->wheelLength->value(this->capsule->getLength());
	this->wheelRadius->value(this->capsule->getRadius());
}

void CapsuleWindow::radius_cb(Widget* widget, void* data)
{
	CapsuleWindow* cwin = (CapsuleWindow*) data;

	if (widget == cwin->inputRadius)
	{
		cwin->capsule->setRadius(cwin->inputRadius->fvalue());
	}
	else
	{
		cwin->capsule->setRadius(cwin->wheelRadius->value());
	}

	cwin->updateGUI();
	dance::Refresh();
}

void CapsuleWindow::length_cb(Widget* widget, void* data)
{
	CapsuleWindow* cwin = (CapsuleWindow*) data;

	if (widget == cwin->inputLength)
	{
		cwin->capsule->setLength(cwin->inputLength->fvalue());
	}
	else
	{
		cwin->capsule->setLength(cwin->wheelLength->value());
	}

	cwin->updateGUI();
	dance::Refresh();
}



 
