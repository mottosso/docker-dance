#ifndef CAPSULEWINDOW_H
#define CAPSULEWINDOW_H

#include "defs.h"
#include "GeometryWindow.h"
#include <fltk/FloatInput.h>
#include <fltk/ThumbWheel.h>

class Capsule;

class CapsuleWindow : public GeometryWindow
{
	public:
		CapsuleWindow(Capsule* c, int x, int y, int width, int height, const char* name);
		void updateGUI();

		static void radius_cb(Widget* widget, void* data); 
		static void length_cb(Widget* widget, void* data); 

		Capsule* capsule;

		fltk::FloatInput* inputRadius;
        fltk::ThumbWheel* wheelRadius;
        fltk::FloatInput* inputLength;
        fltk::ThumbWheel* wheelLength;


};
#endif

